# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	OO00OO0O0O0OOO000 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O0OO0OO0OO00OOOO0 =[];OOO000OO00OOO0OOO =[]#line:261
	for OO000O0O0OO0O0000 in sorted (OO00OO0O0O0OOO000 ,key =lambda OO00O00000OO00O00 :OO00O00000OO00O00 ):#line:262
		O0OO0O0O0OO0OO0OO =os .path .split (OO000O0O0OO0O0000 [:-1 ])[1 ]#line:263
		O000O0O000O0OOOOO =os .path .join (OO000O0O0OO0O0000 ,'addon.xml')#line:264
		if os .path .exists (O000O0O000O0OOOOO ):#line:265
			O000O00OO00O00O00 =open (O000O0O000O0OOOOO )#line:266
			OO00000O00OO0OO00 =O000O00OO00O00O00 .read ()#line:267
			O0000O0O0OO00O00O =parseDOM2 (OO00000O00OO0OO00 ,'addon',ret ='id')#line:268
			O000O000OOOOO0OOO =O0OO0O0O0OO0OO0OO if len (O0000O0O0OO00O00O )==0 else O0000O0O0OO00O00O [0 ]#line:269
			try :#line:270
				O0OO00OOOOO0OOOOO =xbmcaddon .Addon (id =O000O000OOOOO0OOO )#line:271
				O0OO0OO0OO00OOOO0 .append (O0OO00OOOOO0OOOOO .getAddonInfo ('name'))#line:272
				OOO000OO00OOO0OOO .append (O000O000OOOOO0OOO )#line:273
			except :#line:274
				pass #line:275
	OOO0OOO0O00OO0OO0 =[];O0OO000OO000O0OOO =0 #line:276
	OOOOO0O0OOO00OOO0 =["Current Skin -- %s"%currSkin ()]+O0OO0OO0OO00OOOO0 #line:277
	O0OO000OO000O0OOO =DIALOG .select ("Select the Skin you want to swap with.",OOOOO0O0OOO00OOO0 )#line:278
	if O0OO000OO000O0OOO ==-1 :return #line:279
	else :#line:280
		OO000O0OO0OO00OOO =(O0OO000OO000O0OOO -1 )#line:281
		OOO0OOO0O00OO0OO0 .append (OO000O0OO0OO00OOO )#line:282
		OOOOO0O0OOO00OOO0 [O0OO000OO000O0OOO ]="%s"%(O0OO0OO0OO00OOOO0 [OO000O0OO0OO00OOO ])#line:283
	if OOO0OOO0O00OO0OO0 ==None :return #line:284
	for OOOOOOOOO0OO00O0O in OOO0OOO0O00OO0OO0 :#line:285
		swapSkins (OOO000OO00OOO0OOO [OOOOOOOOO0OO00O0O ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (OOO00O0OOO0O00000 ,title ="Error"):#line:290
	O000000OO00O0OOOO ='lookandfeel.skin'#line:291
	OOOO0OOO0OO00O000 =OOO00O0OOO0O00000 #line:292
	O0OOO0OO0O000O0O0 =getOld (O000000OO00O0OOOO )#line:293
	OO00OO0O00OO0O00O =O000000OO00O0OOOO #line:294
	setNew (OO00OO0O00OO0O00O ,OOOO0OOO0OO00O000 )#line:295
	O0O000O0O00OO00OO =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O000O0O00OO00OO <100 :#line:297
		O0O000O0O00OO00OO +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (O00OOOO00O00O0000 ):#line:304
	try :#line:305
		O00OOOO00O00O0000 ='"%s"'%O00OOOO00O00O0000 #line:306
		OOO0OO0OOO0OOO0O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O00OOOO00O00O0000 )#line:307
		OOO0000O000OOOO0O =xbmc .executeJSONRPC (OOO0OO0OOO0OOO0O0 )#line:309
		OOO0000O000OOOO0O =simplejson .loads (OOO0000O000OOOO0O )#line:310
		if OOO0000O000OOOO0O .has_key ('result'):#line:311
			if OOO0000O000OOOO0O ['result'].has_key ('value'):#line:312
				return OOO0000O000OOOO0O ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (OOOOO00O0O0OO0O0O ,OO0OO000OOOOOO0O0 ):#line:319
	try :#line:320
		OOOOO00O0O0OO0O0O ='"%s"'%OOOOO00O0O0OO0O0O #line:321
		OO0OO000OOOOOO0O0 ='"%s"'%OO0OO000OOOOOO0O0 #line:322
		OOOOOOO000OOO0O0O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOOOO00O0O0OO0O0O ,OO0OO000OOOOOO0O0 )#line:323
		OOO000O00OO0O0OOO =xbmc .executeJSONRPC (OOOOOOO000OOO0O0O )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			O00OOOO00OOO0OO0O =xbmcgui .DialogProgress ()#line:334
			O00OOOO00OOO0OO0O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			O00OOOO00OOO0OO0O .update (0 )#line:338
			for O00OO00000O0O000O in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				O00OOOO00OOO0OO0O .update (int ((5 -O00OO00000O0O000O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O00OO00000O0O000O ),'')#line:341
				if O00OOOO00OOO0OO0O .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			O00OOOO00OOO0OO0O =xbmcgui .DialogProgress ()#line:347
			O00OOOO00OOO0OO0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			O00OOOO00OOO0OO0O .update (0 )#line:351
			for O00OO00000O0O000O in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				O00OOOO00OOO0OO0O .update (int ((5 -O00OO00000O0O000O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O00OO00000O0O000O ),'')#line:354
				if O00OOOO00OOO0OO0O .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:364
			indicatorfastupdate ()#line:365
def rdoff ():#line:367
	resloginit .resloginit ('restore','all')#line:369
	O000OOO00O000O00O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:370
	OOO0O000O0O0000OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:371
	copyfile (O000OOO00O000O00O ,OOO0O000O0O0000OO )#line:372
def rdon ():#line:374
	loginit .loginIt ('restore','all')#line:375
	OO000O0OOO00O0O00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:377
	OO0O0O0O00O0O000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:378
	copyfile (OO000O0OOO00O0O00 ,OO0O0O0O00O0O000O )#line:379
def adults18 ():#line:381
  O00O000O0OO000OO0 =(ADDON .getSetting ("adults"))#line:382
  if O00O000O0OO000OO0 =='true':#line:383
    O00O0OOOOO0OO000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:384
    with open (O00O0OOOOO0OO000O ,'r')as OOO00000O000OOO0O :#line:385
      OO0OOO000OO000OOO =OOO00000O000OOO0O .read ()#line:386
    OO0OOO000OO000OOO =OO0OOO000OO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:404
    with open (O00O0OOOOO0OO000O ,'w')as OOO00000O000OOO0O :#line:407
      OOO00000O000OOO0O .write (OO0OOO000OO000OOO )#line:408
def rdbuildaddon ():#line:409
  O0000O0O0O000OO00 =(ADDON .getSetting ("rdbuild"))#line:410
  if O0000O0O0O000OO00 =='true':#line:411
    O0O0OO0OO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:412
    with open (O0O0OO0OO0OOOOO00 ,'r')as O0000OO000000O00O :#line:413
      O00O0OOOO0000OO00 =O0000OO000000O00O .read ()#line:414
    O00O0OOOO0000OO00 =O00O0OOOO0000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:432
    with open (O0O0OO0OO0OOOOO00 ,'w')as O0000OO000000O00O :#line:435
      O0000OO000000O00O .write (O00O0OOOO0000OO00 )#line:436
    O0O0OO0OO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:440
    with open (O0O0OO0OO0OOOOO00 ,'r')as O0000OO000000O00O :#line:441
      O00O0OOOO0000OO00 =O0000OO000000O00O .read ()#line:442
    O00O0OOOO0000OO00 =O00O0OOOO0000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:460
    with open (O0O0OO0OO0OOOOO00 ,'w')as O0000OO000000O00O :#line:463
      O0000OO000000O00O .write (O00O0OOOO0000OO00 )#line:464
    O0O0OO0OO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:468
    with open (O0O0OO0OO0OOOOO00 ,'r')as O0000OO000000O00O :#line:469
      O00O0OOOO0000OO00 =O0000OO000000O00O .read ()#line:470
    O00O0OOOO0000OO00 =O00O0OOOO0000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:488
    with open (O0O0OO0OO0OOOOO00 ,'w')as O0000OO000000O00O :#line:491
      O0000OO000000O00O .write (O00O0OOOO0000OO00 )#line:492
    O0O0OO0OO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:496
    with open (O0O0OO0OO0OOOOO00 ,'r')as O0000OO000000O00O :#line:497
      O00O0OOOO0000OO00 =O0000OO000000O00O .read ()#line:498
    O00O0OOOO0000OO00 =O00O0OOOO0000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:516
    with open (O0O0OO0OO0OOOOO00 ,'w')as O0000OO000000O00O :#line:519
      O0000OO000000O00O .write (O00O0OOOO0000OO00 )#line:520
    O0O0OO0OO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:523
    with open (O0O0OO0OO0OOOOO00 ,'r')as O0000OO000000O00O :#line:524
      O00O0OOOO0000OO00 =O0000OO000000O00O .read ()#line:525
    O00O0OOOO0000OO00 =O00O0OOOO0000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:543
    with open (O0O0OO0OO0OOOOO00 ,'w')as O0000OO000000O00O :#line:546
      O0000OO000000O00O .write (O00O0OOOO0000OO00 )#line:547
    O0O0OO0OO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:549
    with open (O0O0OO0OO0OOOOO00 ,'r')as O0000OO000000O00O :#line:550
      O00O0OOOO0000OO00 =O0000OO000000O00O .read ()#line:551
    O00O0OOOO0000OO00 =O00O0OOOO0000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:569
    with open (O0O0OO0OO0OOOOO00 ,'w')as O0000OO000000O00O :#line:572
      O0000OO000000O00O .write (O00O0OOOO0000OO00 )#line:573
    O0O0OO0OO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:575
    with open (O0O0OO0OO0OOOOO00 ,'r')as O0000OO000000O00O :#line:576
      O00O0OOOO0000OO00 =O0000OO000000O00O .read ()#line:577
    O00O0OOOO0000OO00 =O00O0OOOO0000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:595
    with open (O0O0OO0OO0OOOOO00 ,'w')as O0000OO000000O00O :#line:598
      O0000OO000000O00O .write (O00O0OOOO0000OO00 )#line:599
    O0O0OO0OO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:602
    with open (O0O0OO0OO0OOOOO00 ,'r')as O0000OO000000O00O :#line:603
      O00O0OOOO0000OO00 =O0000OO000000O00O .read ()#line:604
    O00O0OOOO0000OO00 =O00O0OOOO0000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:622
    with open (O0O0OO0OO0OOOOO00 ,'w')as O0000OO000000O00O :#line:625
      O0000OO000000O00O .write (O00O0OOOO0000OO00 )#line:626
def rdbuildinstall ():#line:629
  try :#line:630
   OOO00OOOO0O0O0OOO =(ADDON .getSetting ("rdbuild"))#line:631
   if OOO00OOOO0O0O0OOO =='true':#line:632
     OO0OO00000000O0O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:633
     OOO0O0000O0OOO0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:634
     copyfile (OO0OO00000000O0O0 ,OOO0O0000O0OOO0OO )#line:635
  except :#line:636
     pass #line:637
def rdbuildaddonoff ():#line:640
    O000OOOOOO0OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:643
    with open (O000OOOOOO0OOO0OO ,'r')as OOOOO000000OO0O00 :#line:644
      O0000O0OOO0O00O0O =OOOOO000000OO0O00 .read ()#line:645
    O0000O0OOO0O00O0O =O0000O0OOO0O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:663
    with open (O000OOOOOO0OOO0OO ,'w')as OOOOO000000OO0O00 :#line:666
      OOOOO000000OO0O00 .write (O0000O0OOO0O00O0O )#line:667
    O000OOOOOO0OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:671
    with open (O000OOOOOO0OOO0OO ,'r')as OOOOO000000OO0O00 :#line:672
      O0000O0OOO0O00O0O =OOOOO000000OO0O00 .read ()#line:673
    O0000O0OOO0O00O0O =O0000O0OOO0O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:691
    with open (O000OOOOOO0OOO0OO ,'w')as OOOOO000000OO0O00 :#line:694
      OOOOO000000OO0O00 .write (O0000O0OOO0O00O0O )#line:695
    O000OOOOOO0OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:699
    with open (O000OOOOOO0OOO0OO ,'r')as OOOOO000000OO0O00 :#line:700
      O0000O0OOO0O00O0O =OOOOO000000OO0O00 .read ()#line:701
    O0000O0OOO0O00O0O =O0000O0OOO0O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:719
    with open (O000OOOOOO0OOO0OO ,'w')as OOOOO000000OO0O00 :#line:722
      OOOOO000000OO0O00 .write (O0000O0OOO0O00O0O )#line:723
    O000OOOOOO0OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:727
    with open (O000OOOOOO0OOO0OO ,'r')as OOOOO000000OO0O00 :#line:728
      O0000O0OOO0O00O0O =OOOOO000000OO0O00 .read ()#line:729
    O0000O0OOO0O00O0O =O0000O0OOO0O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:747
    with open (O000OOOOOO0OOO0OO ,'w')as OOOOO000000OO0O00 :#line:750
      OOOOO000000OO0O00 .write (O0000O0OOO0O00O0O )#line:751
    O000OOOOOO0OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:754
    with open (O000OOOOOO0OOO0OO ,'r')as OOOOO000000OO0O00 :#line:755
      O0000O0OOO0O00O0O =OOOOO000000OO0O00 .read ()#line:756
    O0000O0OOO0O00O0O =O0000O0OOO0O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:774
    with open (O000OOOOOO0OOO0OO ,'w')as OOOOO000000OO0O00 :#line:777
      OOOOO000000OO0O00 .write (O0000O0OOO0O00O0O )#line:778
    O000OOOOOO0OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:780
    with open (O000OOOOOO0OOO0OO ,'r')as OOOOO000000OO0O00 :#line:781
      O0000O0OOO0O00O0O =OOOOO000000OO0O00 .read ()#line:782
    O0000O0OOO0O00O0O =O0000O0OOO0O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:800
    with open (O000OOOOOO0OOO0OO ,'w')as OOOOO000000OO0O00 :#line:803
      OOOOO000000OO0O00 .write (O0000O0OOO0O00O0O )#line:804
    O000OOOOOO0OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:806
    with open (O000OOOOOO0OOO0OO ,'r')as OOOOO000000OO0O00 :#line:807
      O0000O0OOO0O00O0O =OOOOO000000OO0O00 .read ()#line:808
    O0000O0OOO0O00O0O =O0000O0OOO0O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:826
    with open (O000OOOOOO0OOO0OO ,'w')as OOOOO000000OO0O00 :#line:829
      OOOOO000000OO0O00 .write (O0000O0OOO0O00O0O )#line:830
    O000OOOOOO0OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:833
    with open (O000OOOOOO0OOO0OO ,'r')as OOOOO000000OO0O00 :#line:834
      O0000O0OOO0O00O0O =OOOOO000000OO0O00 .read ()#line:835
    O0000O0OOO0O00O0O =O0000O0OOO0O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:853
    with open (O000OOOOOO0OOO0OO ,'w')as OOOOO000000OO0O00 :#line:856
      OOOOO000000OO0O00 .write (O0000O0OOO0O00O0O )#line:857
def rdbuildinstalloff ():#line:860
    try :#line:861
       O00000000000O00O0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:862
       OO0OOO00O0OO0OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:863
       copyfile (O00000000000O00O0 ,OO0OOO00O0OO0OOO0 )#line:865
       O00000000000O00O0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:867
       OO0OOO00O0OO0OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:868
       copyfile (O00000000000O00O0 ,OO0OOO00O0OO0OOO0 )#line:870
       O00000000000O00O0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:872
       OO0OOO00O0OO0OOO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:873
       copyfile (O00000000000O00O0 ,OO0OOO00O0OO0OOO0 )#line:875
       O00000000000O00O0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:878
       OO0OOO00O0OO0OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:879
       copyfile (O00000000000O00O0 ,OO0OOO00O0OO0OOO0 )#line:881
    except :#line:883
       pass #line:884
def rdbuildaddonON ():#line:891
    O00OO0O0OOOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:893
    with open (O00OO0O0OOOO0OOO0 ,'r')as O0000O0000OOOOOOO :#line:894
      O00O00OOO00O0OO0O =O0000O0000OOOOOOO .read ()#line:895
    O00O00OOO00O0OO0O =O00O00OOO00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:913
    with open (O00OO0O0OOOO0OOO0 ,'w')as O0000O0000OOOOOOO :#line:916
      O0000O0000OOOOOOO .write (O00O00OOO00O0OO0O )#line:917
    O00OO0O0OOOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:921
    with open (O00OO0O0OOOO0OOO0 ,'r')as O0000O0000OOOOOOO :#line:922
      O00O00OOO00O0OO0O =O0000O0000OOOOOOO .read ()#line:923
    O00O00OOO00O0OO0O =O00O00OOO00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:941
    with open (O00OO0O0OOOO0OOO0 ,'w')as O0000O0000OOOOOOO :#line:944
      O0000O0000OOOOOOO .write (O00O00OOO00O0OO0O )#line:945
    O00OO0O0OOOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:949
    with open (O00OO0O0OOOO0OOO0 ,'r')as O0000O0000OOOOOOO :#line:950
      O00O00OOO00O0OO0O =O0000O0000OOOOOOO .read ()#line:951
    O00O00OOO00O0OO0O =O00O00OOO00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:969
    with open (O00OO0O0OOOO0OOO0 ,'w')as O0000O0000OOOOOOO :#line:972
      O0000O0000OOOOOOO .write (O00O00OOO00O0OO0O )#line:973
    O00OO0O0OOOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:977
    with open (O00OO0O0OOOO0OOO0 ,'r')as O0000O0000OOOOOOO :#line:978
      O00O00OOO00O0OO0O =O0000O0000OOOOOOO .read ()#line:979
    O00O00OOO00O0OO0O =O00O00OOO00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:997
    with open (O00OO0O0OOOO0OOO0 ,'w')as O0000O0000OOOOOOO :#line:1000
      O0000O0000OOOOOOO .write (O00O00OOO00O0OO0O )#line:1001
    O00OO0O0OOOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1004
    with open (O00OO0O0OOOO0OOO0 ,'r')as O0000O0000OOOOOOO :#line:1005
      O00O00OOO00O0OO0O =O0000O0000OOOOOOO .read ()#line:1006
    O00O00OOO00O0OO0O =O00O00OOO00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1024
    with open (O00OO0O0OOOO0OOO0 ,'w')as O0000O0000OOOOOOO :#line:1027
      O0000O0000OOOOOOO .write (O00O00OOO00O0OO0O )#line:1028
    O00OO0O0OOOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1030
    with open (O00OO0O0OOOO0OOO0 ,'r')as O0000O0000OOOOOOO :#line:1031
      O00O00OOO00O0OO0O =O0000O0000OOOOOOO .read ()#line:1032
    O00O00OOO00O0OO0O =O00O00OOO00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1050
    with open (O00OO0O0OOOO0OOO0 ,'w')as O0000O0000OOOOOOO :#line:1053
      O0000O0000OOOOOOO .write (O00O00OOO00O0OO0O )#line:1054
    O00OO0O0OOOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1056
    with open (O00OO0O0OOOO0OOO0 ,'r')as O0000O0000OOOOOOO :#line:1057
      O00O00OOO00O0OO0O =O0000O0000OOOOOOO .read ()#line:1058
    O00O00OOO00O0OO0O =O00O00OOO00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1076
    with open (O00OO0O0OOOO0OOO0 ,'w')as O0000O0000OOOOOOO :#line:1079
      O0000O0000OOOOOOO .write (O00O00OOO00O0OO0O )#line:1080
    O00OO0O0OOOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1083
    with open (O00OO0O0OOOO0OOO0 ,'r')as O0000O0000OOOOOOO :#line:1084
      O00O00OOO00O0OO0O =O0000O0000OOOOOOO .read ()#line:1085
    O00O00OOO00O0OO0O =O00O00OOO00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1103
    with open (O00OO0O0OOOO0OOO0 ,'w')as O0000O0000OOOOOOO :#line:1106
      O0000O0000OOOOOOO .write (O00O00OOO00O0OO0O )#line:1107
def rdbuildinstallON ():#line:1110
    try :#line:1112
       O0OO0O0O000OO0OOO =ADDONPATH +"/resources/rd/victory.xml"#line:1113
       O0O0OO0OOOOOOO000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1114
       copyfile (O0OO0O0O000OO0OOO ,O0O0OO0OOOOOOO000 )#line:1116
       O0OO0O0O000OO0OOO =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1118
       O0O0OO0OOOOOOO000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1119
       copyfile (O0OO0O0O000OO0OOO ,O0O0OO0OOOOOOO000 )#line:1121
       O0OO0O0O000OO0OOO =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1123
       O0O0OO0OOOOOOO000 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1124
       copyfile (O0OO0O0O000OO0OOO ,O0O0OO0OOOOOOO000 )#line:1126
       O0OO0O0O000OO0OOO =ADDONPATH +"/resources/rd/Splash.png"#line:1129
       O0O0OO0OOOOOOO000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1130
       copyfile (O0OO0O0O000OO0OOO ,O0O0OO0OOOOOOO000 )#line:1132
    except :#line:1134
       pass #line:1135
def rdbuild ():#line:1145
	OOO00000OO0OO00OO =(ADDON .getSetting ("rdbuild"))#line:1146
	if OOO00000OO0OO00OO =='true':#line:1147
		OOO000000O00OO000 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1148
		OOO000000O00OO000 .setSetting ('all_t','0')#line:1149
		OOO000000O00OO000 .setSetting ('rd_menu_enable','false')#line:1150
		OOO000000O00OO000 .setSetting ('magnet_bay','false')#line:1151
		OOO000000O00OO000 .setSetting ('magnet_extra','false')#line:1152
		OOO000000O00OO000 .setSetting ('rd_only','false')#line:1153
		OOO000000O00OO000 .setSetting ('ftp','false')#line:1155
		OOO000000O00OO000 .setSetting ('fp','false')#line:1156
		OOO000000O00OO000 .setSetting ('filter_fp','false')#line:1157
		OOO000000O00OO000 .setSetting ('fp_size_en','false')#line:1158
		OOO000000O00OO000 .setSetting ('afdah','false')#line:1159
		OOO000000O00OO000 .setSetting ('ap2s','false')#line:1160
		OOO000000O00OO000 .setSetting ('cin','false')#line:1161
		OOO000000O00OO000 .setSetting ('clv','false')#line:1162
		OOO000000O00OO000 .setSetting ('cmv','false')#line:1163
		OOO000000O00OO000 .setSetting ('dl20','false')#line:1164
		OOO000000O00OO000 .setSetting ('esc','false')#line:1165
		OOO000000O00OO000 .setSetting ('extra','false')#line:1166
		OOO000000O00OO000 .setSetting ('film','false')#line:1167
		OOO000000O00OO000 .setSetting ('fre','false')#line:1168
		OOO000000O00OO000 .setSetting ('fxy','false')#line:1169
		OOO000000O00OO000 .setSetting ('genv','false')#line:1170
		OOO000000O00OO000 .setSetting ('getgo','false')#line:1171
		OOO000000O00OO000 .setSetting ('gold','false')#line:1172
		OOO000000O00OO000 .setSetting ('gona','false')#line:1173
		OOO000000O00OO000 .setSetting ('hdmm','false')#line:1174
		OOO000000O00OO000 .setSetting ('hdt','false')#line:1175
		OOO000000O00OO000 .setSetting ('icy','false')#line:1176
		OOO000000O00OO000 .setSetting ('ind','false')#line:1177
		OOO000000O00OO000 .setSetting ('iwi','false')#line:1178
		OOO000000O00OO000 .setSetting ('jen_free','false')#line:1179
		OOO000000O00OO000 .setSetting ('kiss','false')#line:1180
		OOO000000O00OO000 .setSetting ('lavin','false')#line:1181
		OOO000000O00OO000 .setSetting ('los','false')#line:1182
		OOO000000O00OO000 .setSetting ('m4u','false')#line:1183
		OOO000000O00OO000 .setSetting ('mesh','false')#line:1184
		OOO000000O00OO000 .setSetting ('mf','false')#line:1185
		OOO000000O00OO000 .setSetting ('mkvc','false')#line:1186
		OOO000000O00OO000 .setSetting ('mjy','false')#line:1187
		OOO000000O00OO000 .setSetting ('hdonline','false')#line:1188
		OOO000000O00OO000 .setSetting ('moviex','false')#line:1189
		OOO000000O00OO000 .setSetting ('mpr','false')#line:1190
		OOO000000O00OO000 .setSetting ('mvg','false')#line:1191
		OOO000000O00OO000 .setSetting ('mvl','false')#line:1192
		OOO000000O00OO000 .setSetting ('mvs','false')#line:1193
		OOO000000O00OO000 .setSetting ('myeg','false')#line:1194
		OOO000000O00OO000 .setSetting ('ninja','false')#line:1195
		OOO000000O00OO000 .setSetting ('odb','false')#line:1196
		OOO000000O00OO000 .setSetting ('ophd','false')#line:1197
		OOO000000O00OO000 .setSetting ('pks','false')#line:1198
		OOO000000O00OO000 .setSetting ('prf','false')#line:1199
		OOO000000O00OO000 .setSetting ('put18','false')#line:1200
		OOO000000O00OO000 .setSetting ('req','false')#line:1201
		OOO000000O00OO000 .setSetting ('rftv','false')#line:1202
		OOO000000O00OO000 .setSetting ('rltv','false')#line:1203
		OOO000000O00OO000 .setSetting ('sc','false')#line:1204
		OOO000000O00OO000 .setSetting ('seehd','false')#line:1205
		OOO000000O00OO000 .setSetting ('showbox','false')#line:1206
		OOO000000O00OO000 .setSetting ('shuid','false')#line:1207
		OOO000000O00OO000 .setSetting ('sil_gh','false')#line:1208
		OOO000000O00OO000 .setSetting ('spv','false')#line:1209
		OOO000000O00OO000 .setSetting ('subs','false')#line:1210
		OOO000000O00OO000 .setSetting ('tvs','false')#line:1211
		OOO000000O00OO000 .setSetting ('tw','false')#line:1212
		OOO000000O00OO000 .setSetting ('upto','false')#line:1213
		OOO000000O00OO000 .setSetting ('vel','false')#line:1214
		OOO000000O00OO000 .setSetting ('vex','false')#line:1215
		OOO000000O00OO000 .setSetting ('vidc','false')#line:1216
		OOO000000O00OO000 .setSetting ('w4hd','false')#line:1217
		OOO000000O00OO000 .setSetting ('wav','false')#line:1218
		OOO000000O00OO000 .setSetting ('wf','false')#line:1219
		OOO000000O00OO000 .setSetting ('wse','false')#line:1220
		OOO000000O00OO000 .setSetting ('wss','false')#line:1221
		OOO000000O00OO000 .setSetting ('wsse','false')#line:1222
		OOO000000O00OO000 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1223
		OOO000000O00OO000 .setSetting ('debrid.only','true')#line:1224
		OOO000000O00OO000 .setSetting ('hosts.captcha','false')#line:1225
		OOO000000O00OO000 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1226
		OOO000000O00OO000 .setSetting ('provider.123moviehd','false')#line:1227
		OOO000000O00OO000 .setSetting ('provider.300mbdownload','false')#line:1228
		OOO000000O00OO000 .setSetting ('provider.alltube','false')#line:1229
		OOO000000O00OO000 .setSetting ('provider.allucde','false')#line:1230
		OOO000000O00OO000 .setSetting ('provider.animebase','false')#line:1231
		OOO000000O00OO000 .setSetting ('provider.animeloads','false')#line:1232
		OOO000000O00OO000 .setSetting ('provider.animetoon','false')#line:1233
		OOO000000O00OO000 .setSetting ('provider.bnwmovies','false')#line:1234
		OOO000000O00OO000 .setSetting ('provider.boxfilm','false')#line:1235
		OOO000000O00OO000 .setSetting ('provider.bs','false')#line:1236
		OOO000000O00OO000 .setSetting ('provider.cartoonhd','false')#line:1237
		OOO000000O00OO000 .setSetting ('provider.cdahd','false')#line:1238
		OOO000000O00OO000 .setSetting ('provider.cdax','false')#line:1239
		OOO000000O00OO000 .setSetting ('provider.cine','false')#line:1240
		OOO000000O00OO000 .setSetting ('provider.cinenator','false')#line:1241
		OOO000000O00OO000 .setSetting ('provider.cmovieshdbz','false')#line:1242
		OOO000000O00OO000 .setSetting ('provider.coolmoviezone','false')#line:1243
		OOO000000O00OO000 .setSetting ('provider.ddl','false')#line:1244
		OOO000000O00OO000 .setSetting ('provider.deepmovie','false')#line:1245
		OOO000000O00OO000 .setSetting ('provider.ekinomaniak','false')#line:1246
		OOO000000O00OO000 .setSetting ('provider.ekinotv','false')#line:1247
		OOO000000O00OO000 .setSetting ('provider.filiser','false')#line:1248
		OOO000000O00OO000 .setSetting ('provider.filmpalast','false')#line:1249
		OOO000000O00OO000 .setSetting ('provider.filmwebbooster','false')#line:1250
		OOO000000O00OO000 .setSetting ('provider.filmxy','false')#line:1251
		OOO000000O00OO000 .setSetting ('provider.fmovies','false')#line:1252
		OOO000000O00OO000 .setSetting ('provider.foxx','false')#line:1253
		OOO000000O00OO000 .setSetting ('provider.freefmovies','false')#line:1254
		OOO000000O00OO000 .setSetting ('provider.freeputlocker','false')#line:1255
		OOO000000O00OO000 .setSetting ('provider.furk','false')#line:1256
		OOO000000O00OO000 .setSetting ('provider.gamatotv','false')#line:1257
		OOO000000O00OO000 .setSetting ('provider.gogoanime','false')#line:1258
		OOO000000O00OO000 .setSetting ('provider.gowatchseries','false')#line:1259
		OOO000000O00OO000 .setSetting ('provider.hackimdb','false')#line:1260
		OOO000000O00OO000 .setSetting ('provider.hdfilme','false')#line:1261
		OOO000000O00OO000 .setSetting ('provider.hdmto','false')#line:1262
		OOO000000O00OO000 .setSetting ('provider.hdpopcorns','false')#line:1263
		OOO000000O00OO000 .setSetting ('provider.hdstreams','false')#line:1264
		OOO000000O00OO000 .setSetting ('provider.horrorkino','false')#line:1266
		OOO000000O00OO000 .setSetting ('provider.iitv','false')#line:1267
		OOO000000O00OO000 .setSetting ('provider.iload','false')#line:1268
		OOO000000O00OO000 .setSetting ('provider.iwaatch','false')#line:1269
		OOO000000O00OO000 .setSetting ('provider.kinodogs','false')#line:1270
		OOO000000O00OO000 .setSetting ('provider.kinoking','false')#line:1271
		OOO000000O00OO000 .setSetting ('provider.kinow','false')#line:1272
		OOO000000O00OO000 .setSetting ('provider.kinox','false')#line:1273
		OOO000000O00OO000 .setSetting ('provider.lichtspielhaus','false')#line:1274
		OOO000000O00OO000 .setSetting ('provider.liomenoi','false')#line:1275
		OOO000000O00OO000 .setSetting ('provider.magnetdl','false')#line:1278
		OOO000000O00OO000 .setSetting ('provider.megapelistv','false')#line:1279
		OOO000000O00OO000 .setSetting ('provider.movie2k-ac','false')#line:1280
		OOO000000O00OO000 .setSetting ('provider.movie2k-ag','false')#line:1281
		OOO000000O00OO000 .setSetting ('provider.movie2z','false')#line:1282
		OOO000000O00OO000 .setSetting ('provider.movie4k','false')#line:1283
		OOO000000O00OO000 .setSetting ('provider.movie4kis','false')#line:1284
		OOO000000O00OO000 .setSetting ('provider.movieneo','false')#line:1285
		OOO000000O00OO000 .setSetting ('provider.moviesever','false')#line:1286
		OOO000000O00OO000 .setSetting ('provider.movietown','false')#line:1287
		OOO000000O00OO000 .setSetting ('provider.mvrls','false')#line:1289
		OOO000000O00OO000 .setSetting ('provider.netzkino','false')#line:1290
		OOO000000O00OO000 .setSetting ('provider.odb','false')#line:1291
		OOO000000O00OO000 .setSetting ('provider.openkatalog','false')#line:1292
		OOO000000O00OO000 .setSetting ('provider.ororo','false')#line:1293
		OOO000000O00OO000 .setSetting ('provider.paczamy','false')#line:1294
		OOO000000O00OO000 .setSetting ('provider.peliculasdk','false')#line:1295
		OOO000000O00OO000 .setSetting ('provider.pelisplustv','false')#line:1296
		OOO000000O00OO000 .setSetting ('provider.pepecine','false')#line:1297
		OOO000000O00OO000 .setSetting ('provider.primewire','false')#line:1298
		OOO000000O00OO000 .setSetting ('provider.projectfreetv','false')#line:1299
		OOO000000O00OO000 .setSetting ('provider.proxer','false')#line:1300
		OOO000000O00OO000 .setSetting ('provider.pureanime','false')#line:1301
		OOO000000O00OO000 .setSetting ('provider.putlocker','false')#line:1302
		OOO000000O00OO000 .setSetting ('provider.putlockerfree','false')#line:1303
		OOO000000O00OO000 .setSetting ('provider.reddit','false')#line:1304
		OOO000000O00OO000 .setSetting ('provider.cartoonwire','false')#line:1305
		OOO000000O00OO000 .setSetting ('provider.seehd','false')#line:1306
		OOO000000O00OO000 .setSetting ('provider.segos','false')#line:1307
		OOO000000O00OO000 .setSetting ('provider.serienstream','false')#line:1308
		OOO000000O00OO000 .setSetting ('provider.series9','false')#line:1309
		OOO000000O00OO000 .setSetting ('provider.seriesever','false')#line:1310
		OOO000000O00OO000 .setSetting ('provider.seriesonline','false')#line:1311
		OOO000000O00OO000 .setSetting ('provider.seriespapaya','false')#line:1312
		OOO000000O00OO000 .setSetting ('provider.sezonlukdizi','false')#line:1313
		OOO000000O00OO000 .setSetting ('provider.solarmovie','false')#line:1314
		OOO000000O00OO000 .setSetting ('provider.solarmoviez','false')#line:1315
		OOO000000O00OO000 .setSetting ('provider.stream-to','false')#line:1316
		OOO000000O00OO000 .setSetting ('provider.streamdream','false')#line:1317
		OOO000000O00OO000 .setSetting ('provider.streamflix','false')#line:1318
		OOO000000O00OO000 .setSetting ('provider.streamit','false')#line:1319
		OOO000000O00OO000 .setSetting ('provider.swatchseries','false')#line:1320
		OOO000000O00OO000 .setSetting ('provider.szukajkatv','false')#line:1321
		OOO000000O00OO000 .setSetting ('provider.tainiesonline','false')#line:1322
		OOO000000O00OO000 .setSetting ('provider.tainiomania','false')#line:1323
		OOO000000O00OO000 .setSetting ('provider.tata','false')#line:1326
		OOO000000O00OO000 .setSetting ('provider.trt','false')#line:1327
		OOO000000O00OO000 .setSetting ('provider.tvbox','false')#line:1328
		OOO000000O00OO000 .setSetting ('provider.ultrahd','false')#line:1329
		OOO000000O00OO000 .setSetting ('provider.video4k','false')#line:1330
		OOO000000O00OO000 .setSetting ('provider.vidics','false')#line:1331
		OOO000000O00OO000 .setSetting ('provider.view4u','false')#line:1332
		OOO000000O00OO000 .setSetting ('provider.watchseries','false')#line:1333
		OOO000000O00OO000 .setSetting ('provider.xrysoi','false')#line:1334
		OOO000000O00OO000 .setSetting ('provider.library','false')#line:1335
def fixfont ():#line:1338
	OO0O000OOO00O0000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1339
	O00OOO00O000000O0 =json .loads (OO0O000OOO00O0000 );#line:1341
	OOO0OO00O0OOOOO0O =O00OOO00O000000O0 ["result"]["settings"]#line:1342
	OO00O00OO0OOOO000 =[OO0000000OOOO00OO for OO0000000OOOO00OO in OOO0OO00O0OOOOO0O if OO0000000OOOO00OO ["id"]=="audiooutput.audiodevice"][0 ]#line:1344
	O0000000OOO000OOO =OO00O00OO0OOOO000 ["options"];#line:1345
	O0O0OOO000OOO0OOO =OO00O00OO0OOOO000 ["value"];#line:1346
	OOO0OO0OOO0OOOO00 =[OOOO0O000O0000000 for (OOOO0O000O0000000 ,OOOOOOOO0OOOOOOOO )in enumerate (O0000000OOO000OOO )if OOOOOOOO0OOOOOOOO ["value"]==O0O0OOO000OOO0OOO ][0 ];#line:1348
	O00O00O0OOOO0O00O =(OOO0OO0OOO0OOOO00 +1 )%len (O0000000OOO000OOO )#line:1350
	OO0000OO000O0OOO0 =O0000000OOO000OOO [O00O00O0OOOO0O00O ]["value"]#line:1352
	OOO0OO0OO00O000O0 =O0000000OOO000OOO [O00O00O0OOOO0O00O ]["label"]#line:1353
	O0O0O000OOOO0O00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1355
	try :#line:1357
		OOOOO000O00OOO0O0 =json .loads (O0O0O000OOOO0O00O );#line:1358
		if OOOOO000O00OOO0O0 ["result"]!=True :#line:1360
			raise Exception #line:1361
	except :#line:1362
		sys .stderr .write ("Error switching audio output device")#line:1363
		raise Exception #line:1364
def parseDOM2 (O0OO0O0000000OOOO ,name =u"",attrs ={},ret =False ):#line:1365
	if isinstance (O0OO0O0000000OOOO ,str ):#line:1368
		try :#line:1369
			O0OO0O0000000OOOO =[O0OO0O0000000OOOO .decode ("utf-8")]#line:1370
		except :#line:1371
			O0OO0O0000000OOOO =[O0OO0O0000000OOOO ]#line:1372
	elif isinstance (O0OO0O0000000OOOO ,unicode ):#line:1373
		O0OO0O0000000OOOO =[O0OO0O0000000OOOO ]#line:1374
	elif not isinstance (O0OO0O0000000OOOO ,list ):#line:1375
		return u""#line:1376
	if not name .strip ():#line:1378
		return u""#line:1379
	O0O0O0OO0OOO0OO0O =[]#line:1381
	for OO000OO0OOO0OO00O in O0OO0O0000000OOOO :#line:1382
		OO0O0OO0O00OO0O0O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO000OO0OOO0OO00O )#line:1383
		for OO0O0OO00O0OO00O0 in OO0O0OO0O00OO0O0O :#line:1384
			OO000OO0OOO0OO00O =OO000OO0OOO0OO00O .replace (OO0O0OO00O0OO00O0 ,OO0O0OO00O0OO00O0 .replace ("\n"," "))#line:1385
		OO0O0O0OO00OOO00O =[]#line:1387
		for O0O00OOO0OO0000O0 in attrs :#line:1388
			O0O00O000O000O00O =re .compile ('(<'+name +'[^>]*?(?:'+O0O00OOO0OO0000O0 +'=[\'"]'+attrs [O0O00OOO0OO0000O0 ]+'[\'"].*?>))',re .M |re .S ).findall (OO000OO0OOO0OO00O )#line:1389
			if len (O0O00O000O000O00O )==0 and attrs [O0O00OOO0OO0000O0 ].find (" ")==-1 :#line:1390
				O0O00O000O000O00O =re .compile ('(<'+name +'[^>]*?(?:'+O0O00OOO0OO0000O0 +'='+attrs [O0O00OOO0OO0000O0 ]+'.*?>))',re .M |re .S ).findall (OO000OO0OOO0OO00O )#line:1391
			if len (OO0O0O0OO00OOO00O )==0 :#line:1393
				OO0O0O0OO00OOO00O =O0O00O000O000O00O #line:1394
				O0O00O000O000O00O =[]#line:1395
			else :#line:1396
				O00OOOO00000OOO00 =range (len (OO0O0O0OO00OOO00O ))#line:1397
				O00OOOO00000OOO00 .reverse ()#line:1398
				for OOOOOO0O00OO00000 in O00OOOO00000OOO00 :#line:1399
					if not OO0O0O0OO00OOO00O [OOOOOO0O00OO00000 ]in O0O00O000O000O00O :#line:1400
						del (OO0O0O0OO00OOO00O [OOOOOO0O00OO00000 ])#line:1401
		if len (OO0O0O0OO00OOO00O )==0 and attrs =={}:#line:1403
			OO0O0O0OO00OOO00O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO000OO0OOO0OO00O )#line:1404
			if len (OO0O0O0OO00OOO00O )==0 :#line:1405
				OO0O0O0OO00OOO00O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO000OO0OOO0OO00O )#line:1406
		if isinstance (ret ,str ):#line:1408
			O0O00O000O000O00O =[]#line:1409
			for OO0O0OO00O0OO00O0 in OO0O0O0OO00OOO00O :#line:1410
				O00O00O000OO0O00O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0O0OO00O0OO00O0 )#line:1411
				if len (O00O00O000OO0O00O )==0 :#line:1412
					O00O00O000OO0O00O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0O0OO00O0OO00O0 )#line:1413
				for OOO00O000OO000000 in O00O00O000OO0O00O :#line:1414
					OOO0OOO0O0OO0OOO0 =OOO00O000OO000000 [0 ]#line:1415
					if OOO0OOO0O0OO0OOO0 in "'\"":#line:1416
						if OOO00O000OO000000 .find ('='+OOO0OOO0O0OO0OOO0 ,OOO00O000OO000000 .find (OOO0OOO0O0OO0OOO0 ,1 ))>-1 :#line:1417
							OOO00O000OO000000 =OOO00O000OO000000 [:OOO00O000OO000000 .find ('='+OOO0OOO0O0OO0OOO0 ,OOO00O000OO000000 .find (OOO0OOO0O0OO0OOO0 ,1 ))]#line:1418
						if OOO00O000OO000000 .rfind (OOO0OOO0O0OO0OOO0 ,1 )>-1 :#line:1420
							OOO00O000OO000000 =OOO00O000OO000000 [1 :OOO00O000OO000000 .rfind (OOO0OOO0O0OO0OOO0 )]#line:1421
					else :#line:1422
						if OOO00O000OO000000 .find (" ")>0 :#line:1423
							OOO00O000OO000000 =OOO00O000OO000000 [:OOO00O000OO000000 .find (" ")]#line:1424
						elif OOO00O000OO000000 .find ("/")>0 :#line:1425
							OOO00O000OO000000 =OOO00O000OO000000 [:OOO00O000OO000000 .find ("/")]#line:1426
						elif OOO00O000OO000000 .find (">")>0 :#line:1427
							OOO00O000OO000000 =OOO00O000OO000000 [:OOO00O000OO000000 .find (">")]#line:1428
					O0O00O000O000O00O .append (OOO00O000OO000000 .strip ())#line:1430
			OO0O0O0OO00OOO00O =O0O00O000O000O00O #line:1431
		else :#line:1432
			O0O00O000O000O00O =[]#line:1433
			for OO0O0OO00O0OO00O0 in OO0O0O0OO00OOO00O :#line:1434
				OOOO0O00OO0O0O00O =u"</"+name #line:1435
				O0000OOO00OOOOOO0 =OO000OO0OOO0OO00O .find (OO0O0OO00O0OO00O0 )#line:1437
				O0OO00O000O0O0O00 =OO000OO0OOO0OO00O .find (OOOO0O00OO0O0O00O ,O0000OOO00OOOOOO0 )#line:1438
				O00O0OO0O0O00OO00 =OO000OO0OOO0OO00O .find ("<"+name ,O0000OOO00OOOOOO0 +1 )#line:1439
				while O00O0OO0O0O00OO00 <O0OO00O000O0O0O00 and O00O0OO0O0O00OO00 !=-1 :#line:1441
					O00O0OOO0O0OOO000 =OO000OO0OOO0OO00O .find (OOOO0O00OO0O0O00O ,O0OO00O000O0O0O00 +len (OOOO0O00OO0O0O00O ))#line:1442
					if O00O0OOO0O0OOO000 !=-1 :#line:1443
						O0OO00O000O0O0O00 =O00O0OOO0O0OOO000 #line:1444
					O00O0OO0O0O00OO00 =OO000OO0OOO0OO00O .find ("<"+name ,O00O0OO0O0O00OO00 +1 )#line:1445
				if O0000OOO00OOOOOO0 ==-1 and O0OO00O000O0O0O00 ==-1 :#line:1447
					O0OOOO0OO0O000OOO =u""#line:1448
				elif O0000OOO00OOOOOO0 >-1 and O0OO00O000O0O0O00 >-1 :#line:1449
					O0OOOO0OO0O000OOO =OO000OO0OOO0OO00O [O0000OOO00OOOOOO0 +len (OO0O0OO00O0OO00O0 ):O0OO00O000O0O0O00 ]#line:1450
				elif O0OO00O000O0O0O00 >-1 :#line:1451
					O0OOOO0OO0O000OOO =OO000OO0OOO0OO00O [:O0OO00O000O0O0O00 ]#line:1452
				elif O0000OOO00OOOOOO0 >-1 :#line:1453
					O0OOOO0OO0O000OOO =OO000OO0OOO0OO00O [O0000OOO00OOOOOO0 +len (OO0O0OO00O0OO00O0 ):]#line:1454
				if ret :#line:1456
					OOOO0O00OO0O0O00O =OO000OO0OOO0OO00O [O0OO00O000O0O0O00 :OO000OO0OOO0OO00O .find (">",OO000OO0OOO0OO00O .find (OOOO0O00OO0O0O00O ))+1 ]#line:1457
					O0OOOO0OO0O000OOO =OO0O0OO00O0OO00O0 +O0OOOO0OO0O000OOO +OOOO0O00OO0O0O00O #line:1458
				OO000OO0OOO0OO00O =OO000OO0OOO0OO00O [OO000OO0OOO0OO00O .find (O0OOOO0OO0O000OOO ,OO000OO0OOO0OO00O .find (OO0O0OO00O0OO00O0 ))+len (O0OOOO0OO0O000OOO ):]#line:1460
				O0O00O000O000O00O .append (O0OOOO0OO0O000OOO )#line:1461
			OO0O0O0OO00OOO00O =O0O00O000O000O00O #line:1462
		O0O0O0OO0OOO0OO0O +=OO0O0O0OO00OOO00O #line:1463
	return O0O0O0OO0OOO0OO0O #line:1465
def addItem (O0OO0OO0O00OOOO00 ,O00OOO0O00OO0OOOO ,O0OOO0O00OO00OO0O ,O000OOOOOOOOO0OO0 ,OO00O0000000O0OO0 ,description =None ):#line:1467
	if description ==None :description =''#line:1468
	description ='[COLOR white]'+description +'[/COLOR]'#line:1469
	O0OO0000O0OOO0O00 =sys .argv [0 ]+"?url="+urllib .quote_plus (O00OOO0O00OO0OOOO )+"&mode="+str (O0OOO0O00OO00OO0O )+"&name="+urllib .quote_plus (O0OO0OO0O00OOOO00 )+"&iconimage="+urllib .quote_plus (O000OOOOOOOOO0OO0 )+"&fanart="+urllib .quote_plus (OO00O0000000O0OO0 )#line:1470
	O00O0OOOO00000OOO =True #line:1471
	OOOO0O0OOO000OO00 =xbmcgui .ListItem (O0OO0OO0O00OOOO00 ,iconImage =O000OOOOOOOOO0OO0 ,thumbnailImage =O000OOOOOOOOO0OO0 )#line:1472
	OOOO0O0OOO000OO00 .setInfo (type ="Video",infoLabels ={"Title":O0OO0OO0O00OOOO00 ,"Plot":description })#line:1473
	OOOO0O0OOO000OO00 .setProperty ("fanart_Image",OO00O0000000O0OO0 )#line:1474
	OOOO0O0OOO000OO00 .setProperty ("icon_Image",O000OOOOOOOOO0OO0 )#line:1475
	O00O0OOOO00000OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO0000O0OOO0O00 ,listitem =OOOO0O0OOO000OO00 ,isFolder =False )#line:1476
	return O00O0OOOO00000OOO #line:1477
def get_params ():#line:1479
		O00O0O0000O00O0O0 =[]#line:1480
		OO0000O0000000000 =sys .argv [2 ]#line:1481
		if len (OO0000O0000000000 )>=2 :#line:1482
				OO00OO00OOO0O0000 =sys .argv [2 ]#line:1483
				OO0OOOOO0OO0O0OOO =OO00OO00OOO0O0000 .replace ('?','')#line:1484
				if (OO00OO00OOO0O0000 [len (OO00OO00OOO0O0000 )-1 ]=='/'):#line:1485
						OO00OO00OOO0O0000 =OO00OO00OOO0O0000 [0 :len (OO00OO00OOO0O0000 )-2 ]#line:1486
				OO00000OOO0OO00O0 =OO0OOOOO0OO0O0OOO .split ('&')#line:1487
				O00O0O0000O00O0O0 ={}#line:1488
				for O0O0OOO0O000OOOOO in range (len (OO00000OOO0OO00O0 )):#line:1489
						OOOOOOO000O0O0O0O ={}#line:1490
						OOOOOOO000O0O0O0O =OO00000OOO0OO00O0 [O0O0OOO0O000OOOOO ].split ('=')#line:1491
						if (len (OOOOOOO000O0O0O0O ))==2 :#line:1492
								O00O0O0000O00O0O0 [OOOOOOO000O0O0O0O [0 ]]=OOOOOOO000O0O0O0O [1 ]#line:1493
		return O00O0O0000O00O0O0 #line:1495
def decode (OOO000000O0OOO00O ,OO0OOO0OO0000O000 ):#line:1500
    import base64 #line:1501
    OOO00OO00OOO0OOOO =[]#line:1502
    if (len (OOO000000O0OOO00O ))!=4 :#line:1504
     return 10 #line:1505
    OO0OOO0OO0000O000 =base64 .urlsafe_b64decode (OO0OOO0OO0000O000 )#line:1506
    for O000O00OO0000O00O in range (len (OO0OOO0OO0000O000 )):#line:1508
        O000OO0000OO0000O =OOO000000O0OOO00O [O000O00OO0000O00O %len (OOO000000O0OOO00O )]#line:1509
        O0O0OOOOO0O00O0O0 =chr ((256 +ord (OO0OOO0OO0000O000 [O000O00OO0000O00O ])-ord (O000OO0000OO0000O ))%256 )#line:1510
        OOO00OO00OOO0OOOO .append (O0O0OOOOO0O00O0O0 )#line:1511
    return "".join (OOO00OO00OOO0OOOO )#line:1512
def tmdb_list (OO0O0OO0O0O0000O0 ):#line:1513
    OOOO0O0OOOO0OOOOO =decode ("7643",OO0O0OO0O0O0000O0 )#line:1516
    return int (OOOO0O0OOOO0OOOOO )#line:1519
def u_list (OO0OO000O000O0OOO ):#line:1520
    from math import sqrt #line:1522
    OOOOO0OOO000O000O =tmdb_list (TMDB_NEW_API )#line:1523
    OOO0OOO00O0000OOO =str ((getHwAddr ('eth0'))*OOOOO0OOO000O000O )#line:1525
    O0OO0OO0OO0OOO0O0 =int (OOO0OOO00O0000OOO [1 ]+OOO0OOO00O0000OOO [2 ]+OOO0OOO00O0000OOO [5 ]+OOO0OOO00O0000OOO [7 ])#line:1526
    O00O0000000OO00OO =(ADDON .getSetting ("pass"))#line:1528
    O0O0O0O0OOO000O0O =(str (round (sqrt ((O0OO0OO0OO0OOO0O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1533
    if '.'in O0O0O0O0OOO000O0O :#line:1534
     O0O0O0O0OOO000O0O =(str (round (sqrt ((O0OO0OO0OO0OOO0O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1535
    logging .warning (O0O0O0O0OOO000O0O )#line:1536
    if O00O0000000OO00OO ==O0O0O0O0OOO000O0O :#line:1537
      OO0OOOO000O0OOOO0 =OO0OO000O000O0OOO #line:1539
    else :#line:1541
       if STARTP2 ()and STARTP ()=='ok':#line:1542
         return OO0OO000O000O0OOO #line:1545
       OO0OOOO000O0OOOO0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1546
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1547
       sys .exit ()#line:1548
    return OO0OOOO000O0OOOO0 #line:1549
def disply_hwr ():#line:1551
   O0000O00000OO0OO0 =tmdb_list (TMDB_NEW_API )#line:1552
   OOOOOOOOOO00O0O0O =str ((getHwAddr ('eth0'))*O0000O00000OO0OO0 )#line:1553
   O000OO0OOO00O0000 =(OOOOOOOOOO00O0O0O [1 ]+OOOOOOOOOO00O0O0O [2 ]+OOOOOOOOOO00O0O0O [5 ]+OOOOOOOOOO00O0O0O [7 ])#line:1560
   OO0O000O00000000O =(ADDON .getSetting ("action"))#line:1561
   wiz .setS ('action',str (O000OO0OOO00O0000 ))#line:1563
def disply_hwr2 ():#line:1564
   OO0O0O00OO0O0O0O0 =tmdb_list (TMDB_NEW_API )#line:1565
   OO0O0000O0000O0OO =str ((getHwAddr ('eth0'))*OO0O0O00OO0O0O0O0 )#line:1566
   OOO0OO0000O00O00O =(OO0O0000O0000O0OO [1 ]+OO0O0000O0000O0OO [2 ]+OO0O0000O0000O0OO [5 ]+OO0O0000O0000O0OO [7 ])#line:1573
   OOO00O0OO0OOO0O0O =(ADDON .getSetting ("action"))#line:1574
   xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOO0OO0000O00O00O )#line:1577
def getHwAddr (O000O0O00O00O0OOO ):#line:1579
   import subprocess ,time #line:1580
   OO0OO0OOO0000O00O ='windows'#line:1581
   if xbmc .getCondVisibility ('system.platform.android'):#line:1582
       OO0OO0OOO0000O00O ='android'#line:1583
   if xbmc .getCondVisibility ('system.platform.android'):#line:1584
     O0O0OOOO00OOO0OO0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1585
     O00O0OO0OO0OOOO00 =re .compile ('link/ether (.+?) brd').findall (str (O0O0OOOO00OOO0OO0 ))#line:1587
     OO00O000000OO00O0 =0 #line:1588
     for OOOOO0OO00O0O0O00 in O00O0OO0OO0OOOO00 :#line:1589
      if O00O0OO0OO0OOOO00 !='00:00:00:00:00:00':#line:1590
          O0O0OOO0000OO0OO0 =OOOOO0OO00O0O0O00 #line:1591
          OO00O000000OO00O0 =OO00O000000OO00O0 +int (O0O0OOO0000OO0OO0 .replace (':',''),16 )#line:1592
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1594
       OO00OOO0O0O00O00O =0 #line:1595
       OO00O000000OO00O0 =0 #line:1596
       O0O0OOO0O0OOO00OO =[]#line:1597
       O0OOOO0O00OO0000O =os .popen ("getmac").read ()#line:1598
       O0OOOO0O00OO0000O =O0OOOO0O00OO0000O .split ("\n")#line:1599
       for OOO000O0OOOO0OO0O in O0OOOO0O00OO0000O :#line:1601
            OO00OOO00000OO00O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO000O0OOOO0OO0O ,re .I )#line:1602
            if OO00OOO00000OO00O :#line:1603
                O00O0OO0OO0OOOO00 =OO00OOO00000OO00O .group ().replace ('-',':')#line:1604
                O0O0OOO0O0OOO00OO .append (O00O0OO0OO0OOOO00 )#line:1605
                OO00O000000OO00O0 =OO00O000000OO00O0 +int (O00O0OO0OO0OOOO00 .replace (':',''),16 )#line:1608
   else :#line:1610
       OO00OOO0O0O00O00O =0 #line:1611
       OO00O000000OO00O0 =0 #line:1612
       while (1 ):#line:1613
         O0O0OOO0000OO0OO0 =xbmc .getInfoLabel ("network.macaddress")#line:1614
         logging .warning (O0O0OOO0000OO0OO0 )#line:1615
         if O0O0OOO0000OO0OO0 !="Busy"and O0O0OOO0000OO0OO0 !=' עסוק':#line:1616
            break #line:1618
         else :#line:1619
           OO00OOO0O0O00O00O =OO00OOO0O0O00O00O +1 #line:1620
           time .sleep (1 )#line:1621
           if OO00OOO0O0O00O00O >30 :#line:1622
            break #line:1623
       OO00O000000OO00O0 =OO00O000000OO00O0 +int (O0O0OOO0000OO0OO0 .replace (':',''),16 )#line:1624
   return OO00O000000OO00O0 #line:1626
def getpass ():#line:1627
	disply_hwr2 ()#line:1629
def setpass ():#line:1630
    O00OO00O00O0O0000 =xbmcgui .Dialog ()#line:1631
    OOOO00O00O0OOOOO0 =O00OO00O00O0O0000 .numeric (0 ,'הכנס סיסמה')#line:1633
    wiz .setS ('pass',str (OOOO00O00O0OOOOO0 ))#line:1638
def setuname ():#line:1639
    OO0O0O0OOOO000O0O =''#line:1640
    O00O0OO000O0O00O0 =xbmc .Keyboard (OO0O0O0OOOO000O0O ,'הכנס שם משתמש')#line:1641
    O00O0OO000O0O00O0 .doModal ()#line:1642
    if O00O0OO000O0O00O0 .isConfirmed ():#line:1643
           OO0O0O0OOOO000O0O =O00O0OO000O0O00O0 .getText ()#line:1644
           wiz .setS ('user',str (OO0O0O0OOOO000O0O ))#line:1645
def powerkodi ():#line:1646
    os ._exit (1 )#line:1647
def buffer1 ():#line:1649
	OO000O0O0O0O00O00 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1650
	OOO0O00OOO000O00O =xbmc .getInfoLabel ("System.Memory(total)")#line:1651
	OOO0000OOO0000OO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1652
	OOOO00OO0O00OO0O0 =re .sub ('[^0-9]','',OOO0000OOO0000OO0 )#line:1653
	OOOO00OO0O00OO0O0 =int (OOOO00OO0O00OO0O0 )/3 #line:1654
	OO0000OOOO0O0000O =OOOO00OO0O00OO0O0 *1024 *1024 #line:1655
	try :OO0O000OOO00OO000 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1656
	except :OO0O000OOO00OO000 =16 #line:1657
	O0OO0O00OOO0O0000 =DIALOG .yesno ('FREE MEMORY: '+str (OOO0000OOO0000OO0 ),'Based on your free Memory your optimal buffersize is: '+str (OOOO00OO0O00OO0O0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1660
	if O0OO0O00OOO0O0000 ==1 :#line:1661
		with open (OO000O0O0O0O00O00 ,"w")as OOO000000O0OO0O00 :#line:1662
			if OO0O000OOO00OO000 >=17 :O0O00O0OO0OO0O0O0 =xml_data_advSettings_New (str (OO0000OOOO0O0000O ))#line:1663
			else :O0O00O0OO0OO0O0O0 =xml_data_advSettings_old (str (OO0000OOOO0O0000O ))#line:1664
			OOO000000O0OO0O00 .write (O0O00O0OO0OO0O0O0 )#line:1666
			DIALOG .ok ('Buffer Size Set to: '+str (OO0000OOOO0O0000O ),'Please restart Kodi for settings to apply.','')#line:1667
	elif O0OO0O00OOO0O0000 ==0 :#line:1669
		OO0000OOOO0O0000O =_O00O00OO00000000O (default =str (OO0000OOOO0O0000O ),heading ="INPUT BUFFER SIZE")#line:1670
		with open (OO000O0O0O0O00O00 ,"w")as OOO000000O0OO0O00 :#line:1671
			if OO0O000OOO00OO000 >=17 :O0O00O0OO0OO0O0O0 =xml_data_advSettings_New (str (OO0000OOOO0O0000O ))#line:1672
			else :O0O00O0OO0OO0O0O0 =xml_data_advSettings_old (str (OO0000OOOO0O0000O ))#line:1673
			OOO000000O0OO0O00 .write (O0O00O0OO0OO0O0O0 )#line:1674
			DIALOG .ok ('Buffer Size Set to: '+str (OO0000OOOO0O0000O ),'Please restart Kodi for settings to apply.','')#line:1675
def xml_data_advSettings_old (OOOOO0OOO0OO00OOO ):#line:1676
	O0OO0OO0O0000OO0O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOOOO0OOO0OO00OOO #line:1686
	return O0OO0OO0O0000OO0O #line:1687
def xml_data_advSettings_New (OO0O00000OOO00O00 ):#line:1689
	OOO0000000OOO00O0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO0O00000OOO00O00 #line:1701
	return OOO0000000OOO00O0 #line:1702
def write_ADV_SETTINGS_XML (OO0O000O0O0O00O0O ):#line:1703
    if not os .path .exists (xml_file ):#line:1704
        with open (xml_file ,"w")as O00000000O000OOOO :#line:1705
            O00000000O000OOOO .write (xml_data )#line:1706
def _O00O00OO00000000O (default ="",heading ="",hidden =False ):#line:1707
    ""#line:1708
    O00OOOO0O00000O0O =xbmc .Keyboard (default ,heading ,hidden )#line:1709
    O00OOOO0O00000O0O .doModal ()#line:1710
    if (O00OOOO0O00000O0O .isConfirmed ()):#line:1711
        return unicode (O00OOOO0O00000O0O .getText (),"utf-8")#line:1712
    return default #line:1713
def index ():#line:1715
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1716
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1717
	if AUTOUPDATE =='Yes':#line:1718
		if wiz .workingURL (WIZARDFILE )==True :#line:1719
			OO0OO0OO00O000O0O =wiz .checkWizard ('version')#line:1720
			if OO0OO0OO00O000O0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO0OO0OO00O000O0O ),'wizardupdate',themeit =THEME2 )#line:1721
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1722
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1723
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1724
	if len (BUILDNAME )>0 :#line:1725
		OO0O00OOO0O0O0000 =wiz .checkBuild (BUILDNAME ,'version')#line:1726
		OOO00OO0OOOOO0O00 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1727
		if OO0O00OOO0O0O0000 >BUILDVERSION :OOO00OO0OOOOO0O00 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OOO00OO0OOOOO0O00 ,OO0O00OOO0O0O0000 )#line:1728
		addDir (OOO00OO0OOOOO0O00 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1730
		try :#line:1732
		     O0O0OO0000O000O0O =wiz .themeCount (BUILDNAME )#line:1733
		except :#line:1734
		   O0O0OO0000O000O0O =False #line:1735
		if not O0O0OO0000O000O0O ==False :#line:1736
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1737
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1738
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1741
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1742
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1743
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1747
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1749
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1751
def morsetup ():#line:1753
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1754
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1755
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1756
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1760
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1761
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1764
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1765
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1766
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1767
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1775
	setView ('files','viewType')#line:1776
def morsetup2 ():#line:1777
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1778
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1779
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1780
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1781
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1782
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1783
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1784
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1785
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1786
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1787
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1788
def fastupdate ():#line:1789
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1790
def forcefastupdate ():#line:1792
			OOO00OO0O000O0OOO ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1793
			wiz .ForceFastUpDate (ADDONTITLE ,OOO00OO0O000O0OOO )#line:1794
def rdsetup ():#line:1798
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1799
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1800
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1801
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1802
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1803
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1804
	setView ('files','viewType')#line:1805
def traktsetup ():#line:1807
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1808
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1809
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1810
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1811
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1812
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1813
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1814
	setView ('files','viewType')#line:1815
def resolveurlsetup ():#line:1817
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1818
def urlresolversetup ():#line:1819
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1820
def placentasetup ():#line:1822
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1823
def reptiliasetup ():#line:1824
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1825
def flixnetsetup ():#line:1826
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1827
def yodasetup ():#line:1828
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1829
def numberssetup ():#line:1830
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1831
def uranussetup ():#line:1832
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1833
def genesissetup ():#line:1834
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1835
def net_tools (view =None ):#line:1837
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1838
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1839
	setView ('files','viewType')#line:1841
def speedMenu ():#line:1842
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1843
def viewIP ():#line:1844
	O0000O0OOO00000OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1858
	OO0OOO0OO0OO00OO0 =[];OO0OOO0OOO0O0OOOO =0 #line:1859
	for O0OO00O000O00O0OO in O0000O0OOO00000OO :#line:1860
		OO0O000O0OO00OOOO =wiz .getInfo (O0OO00O000O00O0OO )#line:1861
		OO00O00O0O0O00O0O =0 #line:1862
		while OO0O000O0OO00OOOO =="Busy"and OO00O00O0O0O00O0O <10 :#line:1863
			OO0O000O0OO00OOOO =wiz .getInfo (O0OO00O000O00O0OO );OO00O00O0O0O00O0O +=1 ;wiz .log ("%s sleep %s"%(O0OO00O000O00O0OO ,str (OO00O00O0O0O00O0O )));xbmc .sleep (1000 )#line:1864
		OO0OOO0OO0OO00OO0 .append (OO0O000O0OO00OOOO )#line:1865
		OO0OOO0OOO0O0OOOO +=1 #line:1866
	O0OO0OO000O00OOO0 ,O00OO000OO0OOO00O ,OO000000O0O0OOO0O =getIP ()#line:1867
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0OO0OO00OO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1868
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OO000O00OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1869
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO000OO0OOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1870
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000000O0O0OOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1871
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0OO0OO00OO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1872
	setView ('files','viewType')#line:1873
def buildMenu ():#line:1875
	if USERNAME =='':#line:1876
		ADDON .openSettings ()#line:1877
		sys .exit ()#line:1878
	if PASSWORD =='':#line:1879
		ADDON .openSettings ()#line:1880
	O0O000O0O0OOO0O00 =u_list (SPEEDFILE )#line:1881
	(O0O000O0O0OOO0O00 )#line:1882
	OO00OO0000000O0OO =(wiz .workingURL (O0O000O0O0OOO0O00 ))#line:1883
	(OO00OO0000000O0OO )#line:1884
	OO00OO0000000O0OO =wiz .workingURL (SPEEDFILE )#line:1885
	if not OO00OO0000000O0OO ==True :#line:1886
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1887
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1888
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1889
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1890
		addFile ('%s'%OO00OO0000000O0OO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1891
	else :#line:1892
		O0OO0OOO000O0OO00 ,OOO00OO0O0O0OO0O0 ,OO0OO0O0O00OO00O0 ,OO000O0000O000OOO ,OOOOOOO000O0OO000 ,O0000OO00OO0O00O0 ,O0O0O0OO00O000OOO =wiz .buildCount ()#line:1893
		OOOO000OOO0O00O0O =False ;OOO0O0OO000000000 =[]#line:1894
		if THIRDPARTY =='true':#line:1895
			if not THIRD1NAME ==''and not THIRD1URL =='':OOOO000OOO0O00O0O =True ;OOO0O0OO000000000 .append ('1')#line:1896
			if not THIRD2NAME ==''and not THIRD2URL =='':OOOO000OOO0O00O0O =True ;OOO0O0OO000000000 .append ('2')#line:1897
			if not THIRD3NAME ==''and not THIRD3URL =='':OOOO000OOO0O00O0O =True ;OOO0O0OO000000000 .append ('3')#line:1898
		O0O000O00OO0O0O0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1899
		OO0OO0O0O0O0OOOO0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O000O00OO0O0O0O )#line:1900
		if O0OO0OOO000O0OO00 ==1 and OOOO000OOO0O00O0O ==False :#line:1901
			for OOOO0OOOO0000OOOO ,O0OO0OOO000OO0000 ,O00OOO0OO0OO0O0O0 ,O0OO00O0OO0O00OOO ,O00O00O0OOOOO0OO0 ,OO000O00O00O0000O ,OOO0O000OOO0O000O ,O00O0000O000OO00O ,O00000OO0OOO000OO ,OO0OO000O0OO0OO00 in OO0OO0O0O0O0OOOO0 :#line:1902
				if not SHOWADULT =='true'and O00000OO0OOO000OO .lower ()=='yes':continue #line:1903
				if not DEVELOPER =='true'and wiz .strTest (OOOO0OOOO0000OOOO ):continue #line:1904
				viewBuild (OO0OO0O0O0O0OOOO0 [0 ][0 ])#line:1905
				return #line:1906
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1909
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1910
		if OOOO000OOO0O00O0O ==True :#line:1911
			for OO00O000OOO0O0OO0 in OOO0O0OO000000000 :#line:1912
				OOOO0OOOO0000OOOO =eval ('THIRD%sNAME'%OO00O000OOO0O0OO0 )#line:1913
		if len (OO0OO0O0O0O0OOOO0 )>=1 :#line:1915
			if SEPERATE =='true':#line:1916
				for OOOO0OOOO0000OOOO ,O0OO0OOO000OO0000 ,O00OOO0OO0OO0O0O0 ,O0OO00O0OO0O00OOO ,O00O00O0OOOOO0OO0 ,OO000O00O00O0000O ,OOO0O000OOO0O000O ,O00O0000O000OO00O ,O00000OO0OOO000OO ,OO0OO000O0OO0OO00 in OO0OO0O0O0O0OOOO0 :#line:1917
					if not SHOWADULT =='true'and O00000OO0OOO000OO .lower ()=='yes':continue #line:1918
					if not DEVELOPER =='true'and wiz .strTest (OOOO0OOOO0000OOOO ):continue #line:1919
					O0OOO00O0OOO0O000 =createMenu ('install','',OOOO0OOOO0000OOOO )#line:1920
					addDir ('[%s] %s (v%s)'%(float (O00O00O0OOOOO0OO0 ),OOOO0OOOO0000OOOO ,O0OO0OOO000OO0000 ),'viewbuild',OOOO0OOOO0000OOOO ,description =OO0OO000O0OO0OO00 ,fanart =O00O0000O000OO00O ,icon =OOO0O000OOO0O000O ,menu =O0OOO00O0OOO0O000 ,themeit =THEME2 )#line:1921
			else :#line:1922
				if OO000O0000O000OOO >0 :#line:1923
					OOO0O0OOO00OOOO00 ='+'if SHOW17 =='false'else '-'#line:1924
					if SHOW17 =='true':#line:1926
						for OOOO0OOOO0000OOOO ,O0OO0OOO000OO0000 ,O00OOO0OO0OO0O0O0 ,O0OO00O0OO0O00OOO ,O00O00O0OOOOO0OO0 ,OO000O00O00O0000O ,OOO0O000OOO0O000O ,O00O0000O000OO00O ,O00000OO0OOO000OO ,OO0OO000O0OO0OO00 in OO0OO0O0O0O0OOOO0 :#line:1928
							if not SHOWADULT =='true'and O00000OO0OOO000OO .lower ()=='yes':continue #line:1929
							if not DEVELOPER =='true'and wiz .strTest (OOOO0OOOO0000OOOO ):continue #line:1930
							OO000000000OOO0O0 =int (float (O00O00O0OOOOO0OO0 ))#line:1931
							if OO000000000OOO0O0 ==17 :#line:1932
								O0OOO00O0OOO0O000 =createMenu ('install','',OOOO0OOOO0000OOOO )#line:1933
								addDir ('[%s] %s (v%s)'%(float (O00O00O0OOOOO0OO0 ),OOOO0OOOO0000OOOO ,O0OO0OOO000OO0000 ),'viewbuild',OOOO0OOOO0000OOOO ,description =OO0OO000O0OO0OO00 ,fanart =O00O0000O000OO00O ,icon =OOO0O000OOO0O000O ,menu =O0OOO00O0OOO0O000 ,themeit =THEME2 )#line:1934
				if OOOOOOO000O0OO000 >0 :#line:1935
					OOO0O0OOO00OOOO00 ='+'if SHOW18 =='false'else '-'#line:1936
					if SHOW18 =='true':#line:1938
						for OOOO0OOOO0000OOOO ,O0OO0OOO000OO0000 ,O00OOO0OO0OO0O0O0 ,O0OO00O0OO0O00OOO ,O00O00O0OOOOO0OO0 ,OO000O00O00O0000O ,OOO0O000OOO0O000O ,O00O0000O000OO00O ,O00000OO0OOO000OO ,OO0OO000O0OO0OO00 in OO0OO0O0O0O0OOOO0 :#line:1940
							if not SHOWADULT =='true'and O00000OO0OOO000OO .lower ()=='yes':continue #line:1941
							if not DEVELOPER =='true'and wiz .strTest (OOOO0OOOO0000OOOO ):continue #line:1942
							OO000000000OOO0O0 =int (float (O00O00O0OOOOO0OO0 ))#line:1943
							if OO000000000OOO0O0 ==18 :#line:1944
								O0OOO00O0OOO0O000 =createMenu ('install','',OOOO0OOOO0000OOOO )#line:1945
								addDir ('[%s] %s (v%s)'%(float (O00O00O0OOOOO0OO0 ),OOOO0OOOO0000OOOO ,O0OO0OOO000OO0000 ),'viewbuild',OOOO0OOOO0000OOOO ,description =OO0OO000O0OO0OO00 ,fanart =O00O0000O000OO00O ,icon =OOO0O000OOO0O000O ,menu =O0OOO00O0OOO0O000 ,themeit =THEME2 )#line:1946
				if OO0OO0O0O00OO00O0 >0 :#line:1947
					OOO0O0OOO00OOOO00 ='+'if SHOW16 =='false'else '-'#line:1948
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOO0O0OOO00OOOO00 ,OO0OO0O0O00OO00O0 ),'togglesetting','show16',themeit =THEME3 )#line:1949
					if SHOW16 =='true':#line:1950
						for OOOO0OOOO0000OOOO ,O0OO0OOO000OO0000 ,O00OOO0OO0OO0O0O0 ,O0OO00O0OO0O00OOO ,O00O00O0OOOOO0OO0 ,OO000O00O00O0000O ,OOO0O000OOO0O000O ,O00O0000O000OO00O ,O00000OO0OOO000OO ,OO0OO000O0OO0OO00 in OO0OO0O0O0O0OOOO0 :#line:1951
							if not SHOWADULT =='true'and O00000OO0OOO000OO .lower ()=='yes':continue #line:1952
							if not DEVELOPER =='true'and wiz .strTest (OOOO0OOOO0000OOOO ):continue #line:1953
							OO000000000OOO0O0 =int (float (O00O00O0OOOOO0OO0 ))#line:1954
							if OO000000000OOO0O0 ==16 :#line:1955
								O0OOO00O0OOO0O000 =createMenu ('install','',OOOO0OOOO0000OOOO )#line:1956
								addDir ('[%s] %s (v%s)'%(float (O00O00O0OOOOO0OO0 ),OOOO0OOOO0000OOOO ,O0OO0OOO000OO0000 ),'viewbuild',OOOO0OOOO0000OOOO ,description =OO0OO000O0OO0OO00 ,fanart =O00O0000O000OO00O ,icon =OOO0O000OOO0O000O ,menu =O0OOO00O0OOO0O000 ,themeit =THEME2 )#line:1957
				if OOO00OO0O0O0OO0O0 >0 :#line:1958
					OOO0O0OOO00OOOO00 ='+'if SHOW15 =='false'else '-'#line:1959
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOO0O0OOO00OOOO00 ,OOO00OO0O0O0OO0O0 ),'togglesetting','show15',themeit =THEME3 )#line:1960
					if SHOW15 =='true':#line:1961
						for OOOO0OOOO0000OOOO ,O0OO0OOO000OO0000 ,O00OOO0OO0OO0O0O0 ,O0OO00O0OO0O00OOO ,O00O00O0OOOOO0OO0 ,OO000O00O00O0000O ,OOO0O000OOO0O000O ,O00O0000O000OO00O ,O00000OO0OOO000OO ,OO0OO000O0OO0OO00 in OO0OO0O0O0O0OOOO0 :#line:1962
							if not SHOWADULT =='true'and O00000OO0OOO000OO .lower ()=='yes':continue #line:1963
							if not DEVELOPER =='true'and wiz .strTest (OOOO0OOOO0000OOOO ):continue #line:1964
							OO000000000OOO0O0 =int (float (O00O00O0OOOOO0OO0 ))#line:1965
							if OO000000000OOO0O0 <=15 :#line:1966
								O0OOO00O0OOO0O000 =createMenu ('install','',OOOO0OOOO0000OOOO )#line:1967
								addDir ('[%s] %s (v%s)'%(float (O00O00O0OOOOO0OO0 ),OOOO0OOOO0000OOOO ,O0OO0OOO000OO0000 ),'viewbuild',OOOO0OOOO0000OOOO ,description =OO0OO000O0OO0OO00 ,fanart =O00O0000O000OO00O ,icon =OOO0O000OOO0O000O ,menu =O0OOO00O0OOO0O000 ,themeit =THEME2 )#line:1968
		elif O0O0O0OO00O000OOO >0 :#line:1969
			if O0000OO00OO0O00O0 >0 :#line:1970
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:1971
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:1972
			else :#line:1973
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1974
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:1975
	setView ('files','viewType')#line:1976
def viewBuild (O00OO0O000OOO000O ):#line:1978
	OO00O00OO0O00OO0O =wiz .workingURL (SPEEDFILE )#line:1979
	if not OO00O00OO0O00OO0O ==True :#line:1980
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:1981
		addFile ('%s'%OO00O00OO0O00OO0O ,'',themeit =THEME3 )#line:1982
		return #line:1983
	if wiz .checkBuild (O00OO0O000OOO000O ,'version')==False :#line:1984
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:1985
		addFile ('%s was not found in the builds list.'%O00OO0O000OOO000O ,'',themeit =THEME3 )#line:1986
		return #line:1987
	OOOOOOOO000O0O0OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:1988
	O0000OOOO0O0O0OOO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00OO0O000OOO000O ).findall (OOOOOOOO000O0O0OO )#line:1989
	for O00O0OOOOOOOOOOOO ,OO00O0O00OO0O0OOO ,O0OO0OOO000OOOOOO ,OO0O0OO000OO00O00 ,O00OO000OOO0O000O ,O0O00O0O00OOO0000 ,O000OO0OO00O000O0 ,O0O000O0OOO0OOOOO ,O00000O00OO0O00OO ,O0OOOOOOO00OO0O00 in O0000OOOO0O0O0OOO :#line:1990
		O0O00O0O00OOO0000 =O0O00O0O00OOO0000 if wiz .workingURL (O0O00O0O00OOO0000 )else ICON #line:1991
		O000OO0OO00O000O0 =O000OO0OO00O000O0 if wiz .workingURL (O000OO0OO00O000O0 )else FANART #line:1992
		OOO0000OOO000000O ='%s (v%s)'%(O00OO0O000OOO000O ,O00O0OOOOOOOOOOOO )#line:1993
		if BUILDNAME ==O00OO0O000OOO000O and O00O0OOOOOOOOOOOO >BUILDVERSION :#line:1994
			OOO0000OOO000000O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOO0000OOO000000O ,BUILDVERSION )#line:1995
		O0O0O00OO0OOO000O =int (float (KODIV ));OO000O00O0O0OO00O =int (float (OO0O0OO000OO00O00 ))#line:2004
		if not O0O0O00OO0OOO000O ==OO000O00O0O0OO00O :#line:2005
			if O0O0O00OO0OOO000O ==16 and OO000O00O0O0OO00O <=15 :OO0000O0O000O000O =False #line:2006
			else :OO0000O0O000O000O =True #line:2007
		else :OO0000O0O000O000O =False #line:2008
		addFile ('התקנה','install',O00OO0O000OOO000O ,'fresh',description =O0OOOOOOO00OO0O00 ,fanart =O000OO0OO00O000O0 ,icon =O0O00O0O00OOO0000 ,themeit =THEME1 )#line:2012
		if not O00OO000OOO0O000O =='http://':#line:2015
			if wiz .workingURL (O00OO000OOO0O000O )==True :#line:2016
				addFile (wiz .sep ('THEMES'),'',fanart =O000OO0OO00O000O0 ,icon =O0O00O0O00OOO0000 ,themeit =THEME3 )#line:2017
				OOOOOOOO000O0O0OO =wiz .openURL (O00OO000OOO0O000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2018
				O0000OOOO0O0O0OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOOOOO000O0O0OO )#line:2019
				for O0O0O0000O0OOOOOO ,OOO00OOOOO0O000O0 ,O0OOOO0O0O00OOOO0 ,O00OO00OO0OO0OO00 ,OOO0O0O00O0O0O000 ,O0OOOOOOO00OO0O00 in O0000OOOO0O0O0OOO :#line:2020
					if not SHOWADULT =='true'and OOO0O0O00O0O0O000 .lower ()=='yes':continue #line:2021
					O0OOOO0O0O00OOOO0 =O0OOOO0O0O00OOOO0 if O0OOOO0O0O00OOOO0 =='http://'else O0O00O0O00OOO0000 #line:2022
					O00OO00OO0OO0OO00 =O00OO00OO0OO0OO00 if O00OO00OO0OO0OO00 =='http://'else O000OO0OO00O000O0 #line:2023
					addFile (O0O0O0000O0OOOOOO if not O0O0O0000O0OOOOOO ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0O0O0000O0OOOOOO ,'theme',O00OO0O000OOO000O ,O0O0O0000O0OOOOOO ,description =O0OOOOOOO00OO0O00 ,fanart =O00OO00OO0OO0OO00 ,icon =O0OOOO0O0O00OOOO0 ,themeit =THEME3 )#line:2024
	setView ('files','viewType')#line:2025
def viewThirdList (O0OOO0O00OOO0OO0O ):#line:2027
	O0000OO0O00OOO000 =eval ('THIRD%sNAME'%O0OOO0O00OOO0OO0O )#line:2028
	O000OO000O000OOOO =eval ('THIRD%sURL'%O0OOO0O00OOO0OO0O )#line:2029
	O0O0000OO0OOOOO0O =wiz .workingURL (O000OO000O000OOOO )#line:2030
	if not O0O0000OO0OOOOO0O ==True :#line:2031
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2032
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2033
	else :#line:2034
		OOOOOO00OOOO00000 ,OOO0OOO0OO00OO000 =wiz .thirdParty (O000OO000O000OOOO )#line:2035
		addFile ("[B]%s[/B]"%O0000OO0O00OOO000 ,'',themeit =THEME3 )#line:2036
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2037
		if OOOOOO00OOOO00000 :#line:2038
			for O0000OO0O00OOO000 ,OO000OOO0O0OO00O0 ,O000OO000O000OOOO ,O00000OO0OO0O000O ,OO0OOOOOOOOOOO000 ,O0OO0000OOOOOOO00 ,O00O00OOO0000OO00 ,OO00O0O00O00OO00O in OOO0OOO0OO00OO000 :#line:2039
				if not SHOWADULT =='true'and O00O00OOO0000OO00 .lower ()=='yes':continue #line:2040
				addFile ("[%s] %s v%s"%(O00000OO0OO0O000O ,O0000OO0O00OOO000 ,OO000OOO0O0OO00O0 ),'installthird',O0000OO0O00OOO000 ,O000OO000O000OOOO ,icon =OO0OOOOOOOOOOO000 ,fanart =O0OO0000OOOOOOO00 ,description =OO00O0O00O00OO00O ,themeit =THEME2 )#line:2041
		else :#line:2042
			for O0000OO0O00OOO000 ,O000OO000O000OOOO ,OO0OOOOOOOOOOO000 ,O0OO0000OOOOOOO00 ,OO00O0O00O00OO00O in OOO0OOO0OO00OO000 :#line:2043
				addFile (O0000OO0O00OOO000 ,'installthird',O0000OO0O00OOO000 ,O000OO000O000OOOO ,icon =OO0OOOOOOOOOOO000 ,fanart =O0OO0000OOOOOOO00 ,description =OO00O0O00O00OO00O ,themeit =THEME2 )#line:2044
def editThirdParty (OOO00OO0000OO0O0O ):#line:2046
	OO0000OOOOO0O00OO =eval ('THIRD%sNAME'%OOO00OO0000OO0O0O )#line:2047
	OO0O0000O0O0O0O0O =eval ('THIRD%sURL'%OOO00OO0000OO0O0O )#line:2048
	O0O0000O0O00O0000 =wiz .getKeyboard (OO0000OOOOO0O00OO ,'Enter the Name of the Wizard')#line:2049
	OO0000000O0O0O00O =wiz .getKeyboard (OO0O0000O0O0O0O0O ,'Enter the URL of the Wizard Text')#line:2050
	wiz .setS ('wizard%sname'%OOO00OO0000OO0O0O ,O0O0000O0O00O0000 )#line:2052
	wiz .setS ('wizard%surl'%OOO00OO0000OO0O0O ,OO0000000O0O0O00O )#line:2053
def apkScraper (name =""):#line:2055
	if name =='kodi':#line:2056
		OOO000OO00OO0OO0O ='http://mirrors.kodi.tv/releases/android/arm/'#line:2057
		O000OO00O0O0O0O0O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2058
		OO0000OO0OO0OO0OO =wiz .openURL (OOO000OO00OO0OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2059
		O00O0000OO00OOOOO =wiz .openURL (O000OO00O0O0O0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2060
		O0OO0OO0O0O0O0O0O =0 #line:2061
		O00OO0OOO0OOOOOOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0000OO0OO0OO0OO )#line:2062
		OO000O00OO0000OOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00O0000OO00OOOOO )#line:2063
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2065
		OO0O0O0O00O000O0O =False #line:2066
		for OO0OO0OO000OOO000 ,name ,OO000000OOO000OOO ,O000O0000O00O0OOO in O00OO0OOO0OOOOOOO :#line:2067
			if OO0OO0OO000OOO000 in ['../','old/']:continue #line:2068
			if not OO0OO0OO000OOO000 .endswith ('.apk'):continue #line:2069
			if not OO0OO0OO000OOO000 .find ('_')==-1 and OO0O0O0O00O000O0O ==True :continue #line:2070
			try :#line:2071
				OO0O00O0O0OOO0OO0 =name .split ('-')#line:2072
				if not OO0OO0OO000OOO000 .find ('_')==-1 :#line:2073
					OO0O0O0O00O000O0O =True #line:2074
					OOOOOO0O000O0OOO0 ,OO000OO00O0O00000 =OO0O00O0O0OOO0OO0 [2 ].split ('_')#line:2075
				else :#line:2076
					OOOOOO0O000O0OOO0 =OO0O00O0O0OOO0OO0 [2 ]#line:2077
					OO000OO00O0O00000 =''#line:2078
				O0OO00OO0O0OOOOOO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0O0OOO0OO0 [0 ].title (),OO0O00O0O0OOO0OO0 [1 ],OO000OO00O0O00000 .upper (),OOOOOO0O000O0OOO0 ,COLOR2 ,OO000000OOO000OOO .replace (' ',''),COLOR1 ,O000O0000O00O0OOO )#line:2079
				OOOOO00O00O0O0O00 =urljoin (OOO000OO00OO0OO0O ,OO0OO0OO000OOO000 )#line:2080
				addFile (O0OO00OO0O0OOOOOO ,'apkinstall',"%s v%s%s %s"%(OO0O00O0O0OOO0OO0 [0 ].title (),OO0O00O0O0OOO0OO0 [1 ],OO000OO00O0O00000 .upper (),OOOOOO0O000O0OOO0 ),OOOOO00O00O0O0O00 )#line:2081
				O0OO0OO0O0O0O0O0O +=1 #line:2082
			except :#line:2083
				wiz .log ("Error on: %s"%name )#line:2084
		for OO0OO0OO000OOO000 ,name ,OO000000OOO000OOO ,O000O0000O00O0OOO in OO000O00OO0000OOO :#line:2086
			if OO0OO0OO000OOO000 in ['../','old/']:continue #line:2087
			if not OO0OO0OO000OOO000 .endswith ('.apk'):continue #line:2088
			if not OO0OO0OO000OOO000 .find ('_')==-1 :continue #line:2089
			try :#line:2090
				OO0O00O0O0OOO0OO0 =name .split ('-')#line:2091
				O0OO00OO0O0OOOOOO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0O0OOO0OO0 [0 ].title (),OO0O00O0O0OOO0OO0 [1 ],OO0O00O0O0OOO0OO0 [2 ],COLOR2 ,OO000000OOO000OOO .replace (' ',''),COLOR1 ,O000O0000O00O0OOO )#line:2092
				OOOOO00O00O0O0O00 =urljoin (O000OO00O0O0O0O0O ,OO0OO0OO000OOO000 )#line:2093
				addFile (O0OO00OO0O0OOOOOO ,'apkinstall',"%s v%s %s"%(OO0O00O0O0OOO0OO0 [0 ].title (),OO0O00O0O0OOO0OO0 [1 ],OO0O00O0O0OOO0OO0 [2 ]),OOOOO00O00O0O0O00 )#line:2094
				O0OO0OO0O0O0O0O0O +=1 #line:2095
			except :#line:2096
				wiz .log ("Error on: %s"%name )#line:2097
		if O0OO0OO0O0O0O0O0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2098
	elif name =='spmc':#line:2099
		OOO0000O0OO0000OO ='https://github.com/koying/SPMC/releases'#line:2100
		OO0000OO0OO0OO0OO =wiz .openURL (OOO0000O0OO0000OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2101
		O0OO0OO0O0O0O0O0O =0 #line:2102
		O00OO0OOO0OOOOOOO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO0000OO0OO0OO0OO )#line:2103
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2105
		for name ,O00O000O000OO00OO in O00OO0OOO0OOOOOOO :#line:2107
			O0OOOO0OO0OO00O00 =''#line:2108
			OO000O00OO0000OOO =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O00O000O000OO00OO )#line:2109
			for OOOO0OO0O00OOOO00 ,OOOO0OO000000O0OO ,OOOOOO00OO0O0000O in OO000O00OO0000OOO :#line:2110
				if OOOOOO00OO0O0000O .find ('armeabi')==-1 :continue #line:2111
				if OOOOOO00OO0O0000O .find ('launcher')>-1 :continue #line:2112
				O0OOOO0OO0OO00O00 =urljoin ('https://github.com',OOOO0OO0O00OOOO00 )#line:2113
				break #line:2114
		if O0OO0OO0O0O0O0O0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2116
def apkMenu (url =None ):#line:2118
	if url ==None :#line:2119
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2122
	if not APKFILE =='http://':#line:2123
		if url ==None :#line:2124
			O000000O0OOO00OOO =wiz .workingURL (APKFILE )#line:2125
			O0O0OOO0OO0OOO0OO =uservar .APKFILE #line:2126
		else :#line:2127
			O000000O0OOO00OOO =wiz .workingURL (url )#line:2128
			O0O0OOO0OO0OOO0OO =url #line:2129
		if O000000O0OOO00OOO ==True :#line:2130
			O0O0OOO00O00000O0 =wiz .openURL (O0O0OOO0OO0OOO0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2131
			O0O0OO0000O0O00OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0OOO00O00000O0 )#line:2132
			if len (O0O0OO0000O0O00OO )>0 :#line:2133
				OO0O0O000OO000O00 =0 #line:2134
				for OOO00O0O00OOO00O0 ,OOOO00O00000O0O0O ,url ,OO00O00O000O0O00O ,O0O0O00OO000000O0 ,OOOOOO00OO0000000 ,O00000O000OOOO00O in O0O0OO0000O0O00OO :#line:2135
					if not SHOWADULT =='true'and OOOOOO00OO0000000 .lower ()=='yes':continue #line:2136
					if OOOO00O00000O0O0O .lower ()=='yes':#line:2137
						OO0O0O000OO000O00 +=1 #line:2138
						addDir ("[B]%s[/B]"%OOO00O0O00OOO00O0 ,'apk',url ,description =O00000O000OOOO00O ,icon =OO00O00O000O0O00O ,fanart =O0O0O00OO000000O0 ,themeit =THEME3 )#line:2139
					else :#line:2140
						OO0O0O000OO000O00 +=1 #line:2141
						addFile (OOO00O0O00OOO00O0 ,'apkinstall',OOO00O0O00OOO00O0 ,url ,description =O00000O000OOOO00O ,icon =OO00O00O000O0O00O ,fanart =O0O0O00OO000000O0 ,themeit =THEME2 )#line:2142
					if OO0O0O000OO000O00 <1 :#line:2143
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2144
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2145
		else :#line:2146
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2147
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2148
			addFile ('%s'%O000000O0OOO00OOO ,'',themeit =THEME3 )#line:2149
		return #line:2150
	else :wiz .log ("[APK Menu] No APK list added.")#line:2151
	setView ('files','viewType')#line:2152
def addonMenu (url =None ):#line:2154
	if not ADDONFILE =='http://':#line:2155
		if url ==None :#line:2156
			OOOO0OOO0OOO0OO00 =wiz .workingURL (ADDONFILE )#line:2157
			OOOO00OO0O00000O0 =uservar .ADDONFILE #line:2158
		else :#line:2159
			OOOO0OOO0OOO0OO00 =wiz .workingURL (url )#line:2160
			OOOO00OO0O00000O0 =url #line:2161
		if OOOO0OOO0OOO0OO00 ==True :#line:2162
			O0000OOOO00OO00OO =wiz .openURL (OOOO00OO0O00000O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2163
			O000O0O000000OOO0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000OOOO00OO00OO )#line:2164
			if len (O000O0O000000OOO0 )>0 :#line:2165
				O0OOO00OOOOOO0O00 =0 #line:2166
				for OOO00O0OOO00OOO00 ,O00O0OO0O0O0OOOO0 ,url ,O0OOOO000O000000O ,OO0O00O0OOOOO0OOO ,OOOO000000OO0O0OO ,O00O0OOO000OOOOO0 ,OOO0O0O0000OOO000 ,OOOO000OO0O0OOOOO ,OO0OOOOOO0000O000 in O000O0O000000OOO0 :#line:2167
					if O00O0OO0O0O0OOOO0 .lower ()=='section':#line:2168
						O0OOO00OOOOOO0O00 +=1 #line:2169
						addDir ("[B]%s[/B]"%OOO00O0OOO00OOO00 ,'addons',url ,description =OO0OOOOOO0000O000 ,icon =O00O0OOO000OOOOO0 ,fanart =OOO0O0O0000OOO000 ,themeit =THEME3 )#line:2170
					else :#line:2171
						if not SHOWADULT =='true'and OOOO000OO0O0OOOOO .lower ()=='yes':continue #line:2172
						try :#line:2173
							O0O000O0OO0OOOO00 =xbmcaddon .Addon (id =O00O0OO0O0O0OOOO0 ).getAddonInfo ('path')#line:2174
							if os .path .exists (O0O000O0OO0OOOO00 ):#line:2175
								OOO00O0OOO00OOO00 ="[COLOR green][Installed][/COLOR] %s"%OOO00O0OOO00OOO00 #line:2176
						except :#line:2177
							pass #line:2178
						O0OOO00OOOOOO0O00 +=1 #line:2179
						addFile (OOO00O0OOO00OOO00 ,'addoninstall',O00O0OO0O0O0OOOO0 ,OOOO00OO0O00000O0 ,description =OO0OOOOOO0000O000 ,icon =O00O0OOO000OOOOO0 ,fanart =OOO0O0O0000OOO000 ,themeit =THEME2 )#line:2180
					if O0OOO00OOOOOO0O00 <1 :#line:2181
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2182
			else :#line:2183
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2184
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2185
		else :#line:2186
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2187
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2188
			addFile ('%s'%OOOO0OOO0OOO0OO00 ,'',themeit =THEME3 )#line:2189
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2190
	setView ('files','viewType')#line:2191
def addonInstaller (O00OOOOO0O00O0O0O ,OO0OOOO0OO0OOOOO0 ):#line:2193
	if not ADDONFILE =='http://':#line:2194
		OOO0OO00O00OOOOOO =wiz .workingURL (OO0OOOO0OO0OOOOO0 )#line:2195
		if OOO0OO00O00OOOOOO ==True :#line:2196
			OO00OOOO0O00OOOO0 =wiz .openURL (OO0OOOO0OO0OOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2197
			OOO000OOO00OO0O0O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00OOOOO0O00O0O0O ).findall (OO00OOOO0O00OOOO0 )#line:2198
			if len (OOO000OOO00OO0O0O )>0 :#line:2199
				for O0OOO0O00O0000OO0 ,OO0OOOO0OO0OOOOO0 ,O000O0O00OOO00OOO ,OO0OOOO00000O0O00 ,O0O0OOOO00OOOOOOO ,O00O00000OOOO0OOO ,O0OOO00000OOO00OO ,OOOOOOO0O0000OOO0 ,OOOO0O000OOOOO000 in OOO000OOO00OO0O0O :#line:2200
					if os .path .exists (os .path .join (ADDONS ,O00OOOOO0O00O0O0O )):#line:2201
						O000000O0OOO000OO =['Launch Addon','Remove Addon']#line:2202
						OO0OOOO0O000O000O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O000000O0OOO000OO )#line:2203
						if OO0OOOO0O000O000O ==0 :#line:2204
							wiz .ebi ('RunAddon(%s)'%O00OOOOO0O00O0O0O )#line:2205
							xbmc .sleep (1000 )#line:2206
							return True #line:2207
						elif OO0OOOO0O000O000O ==1 :#line:2208
							wiz .cleanHouse (os .path .join (ADDONS ,O00OOOOO0O00O0O0O ))#line:2209
							try :wiz .removeFolder (os .path .join (ADDONS ,O00OOOOO0O00O0O0O ))#line:2210
							except :pass #line:2211
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OOOOO0O00O0O0O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2212
								removeAddonData (O00OOOOO0O00O0O0O )#line:2213
							wiz .refresh ()#line:2214
							return True #line:2215
						else :#line:2216
							return False #line:2217
					OOO0OOOOO0O0O0O0O =os .path .join (ADDONS ,O000O0O00OOO00OOO )#line:2218
					if not O000O0O00OOO00OOO .lower ()=='none'and not os .path .exists (OOO0OOOOO0O0O0O0O ):#line:2219
						wiz .log ("Repository not installed, installing it")#line:2220
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O00OOOOO0O00O0O0O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000O0O00OOO00OOO ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2221
							OO00OO0000OOOO00O =wiz .parseDOM (wiz .openURL (OO0OOOO00000O0O00 ),'addon',ret ='version',attrs ={'id':O000O0O00OOO00OOO })#line:2222
							if len (OO00OO0000OOOO00O )>0 :#line:2223
								OO0OOOOOO0OOO0OOO ='%s%s-%s.zip'%(O0O0OOOO00OOOOOOO ,O000O0O00OOO00OOO ,OO00OO0000OOOO00O [0 ])#line:2224
								wiz .log (OO0OOOOOO0OOO0OOO )#line:2225
								if KODIV >=17 :wiz .addonDatabase (O000O0O00OOO00OOO ,1 )#line:2226
								installAddon (O000O0O00OOO00OOO ,OO0OOOOOO0OOO0OOO )#line:2227
								wiz .ebi ('UpdateAddonRepos()')#line:2228
								wiz .log ("Installing Addon from Kodi")#line:2230
								OOO000OO0OOOO00OO =installFromKodi (O00OOOOO0O00O0O0O )#line:2231
								wiz .log ("Install from Kodi: %s"%OOO000OO0OOOO00OO )#line:2232
								if OOO000OO0OOOO00OO :#line:2233
									wiz .refresh ()#line:2234
									return True #line:2235
							else :#line:2236
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O000O0O00OOO00OOO )#line:2237
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O00OOOOO0O00O0O0O ,O000O0O00OOO00OOO ))#line:2238
					elif O000O0O00OOO00OOO .lower ()=='none':#line:2239
						wiz .log ("No repository, installing addon")#line:2240
						OO00000OOO00000O0 =O00OOOOO0O00O0O0O #line:2241
						OOOOO00O0OO000O0O =OO0OOOO0OO0OOOOO0 #line:2242
						installAddon (O00OOOOO0O00O0O0O ,OO0OOOO0OO0OOOOO0 )#line:2243
						wiz .refresh ()#line:2244
						return True #line:2245
					else :#line:2246
						wiz .log ("Repository installed, installing addon")#line:2247
						OOO000OO0OOOO00OO =installFromKodi (O00OOOOO0O00O0O0O ,False )#line:2248
						if OOO000OO0OOOO00OO :#line:2249
							wiz .refresh ()#line:2250
							return True #line:2251
					if os .path .exists (os .path .join (ADDONS ,O00OOOOO0O00O0O0O )):return True #line:2252
					O0OOOO00000OO0O0O =wiz .parseDOM (wiz .openURL (OO0OOOO00000O0O00 ),'addon',ret ='version',attrs ={'id':O00OOOOO0O00O0O0O })#line:2253
					if len (O0OOOO00000OO0O0O )>0 :#line:2254
						OO0OOOO0OO0OOOOO0 ="%s%s-%s.zip"%(OO0OOOO0OO0OOOOO0 ,O00OOOOO0O00O0O0O ,O0OOOO00000OO0O0O [0 ])#line:2255
						wiz .log (str (OO0OOOO0OO0OOOOO0 ))#line:2256
						if KODIV >=17 :wiz .addonDatabase (O00OOOOO0O00O0O0O ,1 )#line:2257
						installAddon (O00OOOOO0O00O0O0O ,OO0OOOO0OO0OOOOO0 )#line:2258
						wiz .refresh ()#line:2259
					else :#line:2260
						wiz .log ("no match");return False #line:2261
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2262
		else :wiz .log ("[Addon Installer] Text File: %s"%OOO0OO00O00OOOOOO )#line:2263
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2264
def installFromKodi (OO00OOOO000O0O0O0 ,over =True ):#line:2266
	if over ==True :#line:2267
		xbmc .sleep (2000 )#line:2268
	wiz .ebi ('RunPlugin(plugin://%s)'%OO00OOOO000O0O0O0 )#line:2270
	if not wiz .whileWindow ('yesnodialog'):#line:2271
		return False #line:2272
	xbmc .sleep (1000 )#line:2273
	if wiz .whileWindow ('okdialog'):#line:2274
		return False #line:2275
	wiz .whileWindow ('progressdialog')#line:2276
	if os .path .exists (os .path .join (ADDONS ,OO00OOOO000O0O0O0 )):return True #line:2277
	else :return False #line:2278
def installAddon (OOOOOO0OOO0OO00O0 ,O0OOOO0O00000000O ):#line:2280
	if not wiz .workingURL (O0OOOO0O00000000O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OOOOOO0OOO0OO00O0 ,COLOR2 ));return #line:2281
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2282
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOO0OO00O0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2283
	OOO000OOOOOOO0OOO =O0OOOO0O00000000O .split ('/')#line:2284
	OO00OOOOO0OO00OO0 =os .path .join (PACKAGES ,OOO000OOOOOOO0OOO [-1 ])#line:2285
	try :os .remove (OO00OOOOO0OO00OO0 )#line:2286
	except :pass #line:2287
	downloader .download (O0OOOO0O00000000O ,OO00OOOOO0OO00OO0 ,DP )#line:2288
	OO0000OO00O0O0OOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOO0OO00O0 )#line:2289
	DP .update (0 ,OO0000OO00O0O0OOO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2290
	O0O000O0OO0O0O00O ,OOO00OOO0OO0OOO00 ,O0OO000000OOO0O00 =extract .all (OO00OOOOO0OO00OO0 ,ADDONS ,DP ,title =OO0000OO00O0O0OOO )#line:2291
	DP .update (0 ,OO0000OO00O0O0OOO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2292
	installed (OOOOOO0OOO0OO00O0 )#line:2293
	installDep (OOOOOO0OOO0OO00O0 ,DP )#line:2294
	DP .close ()#line:2295
	wiz .ebi ('UpdateAddonRepos()')#line:2296
	wiz .ebi ('UpdateLocalAddons()')#line:2297
	wiz .refresh ()#line:2298
def installDep (O00OOO00OOOO00000 ,DP =None ):#line:2300
	O0OO000O00O00OOO0 =os .path .join (ADDONS ,O00OOO00OOOO00000 ,'addon.xml')#line:2301
	if os .path .exists (O0OO000O00O00OOO0 ):#line:2302
		O00OOOOO000O0OOO0 =open (O0OO000O00O00OOO0 ,mode ='r');O0O00OO0O0O00OOO0 =O00OOOOO000O0OOO0 .read ();O00OOOOO000O0OOO0 .close ();#line:2303
		OOOO0OOOO00OO000O =wiz .parseDOM (O0O00OO0O0O00OOO0 ,'import',ret ='addon')#line:2304
		for O000O0O0O000OOOOO in OOOO0OOOO00OO000O :#line:2305
			if not 'xbmc.python'in O000O0O0O000OOOOO :#line:2306
				if not DP ==None :#line:2307
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000O0O0O000OOOOO ))#line:2308
				wiz .createTemp (O000O0O0O000OOOOO )#line:2309
def installed (O0O00O0OOO00OO000 ):#line:2336
	O0O000OOO000OO000 =os .path .join (ADDONS ,O0O00O0OOO00OO000 ,'addon.xml')#line:2337
	if os .path .exists (O0O000OOO000OO000 ):#line:2338
		try :#line:2339
			OO000OOOOO0O0000O =open (O0O000OOO000OO000 ,mode ='r');O0O00OOO0O000OOOO =OO000OOOOO0O0000O .read ();OO000OOOOO0O0000O .close ()#line:2340
			OOOO000OO00O0O000 =wiz .parseDOM (O0O00OOO0O000OOOO ,'addon',ret ='name',attrs ={'id':O0O00O0OOO00OO000 })#line:2341
			O0O0O00O00OO00OOO =os .path .join (ADDONS ,O0O00O0OOO00OO000 ,'icon.png')#line:2342
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO000OO00O0O000 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O0O0O00O00OO00OOO )#line:2343
		except :pass #line:2344
def youtubeMenu (url =None ):#line:2346
	if not YOUTUBEFILE =='http://':#line:2347
		if url ==None :#line:2348
			O00OO0OO000O00O00 =wiz .workingURL (YOUTUBEFILE )#line:2349
			OO0O00OOOOOOOO00O =uservar .YOUTUBEFILE #line:2350
		else :#line:2351
			O00OO0OO000O00O00 =wiz .workingURL (url )#line:2352
			OO0O00OOOOOOOO00O =url #line:2353
		if O00OO0OO000O00O00 ==True :#line:2354
			OO000000OOO0OOO0O =wiz .openURL (OO0O00OOOOOOOO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2355
			OOO00O00OOO00OO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO000000OOO0OOO0O )#line:2356
			if len (OOO00O00OOO00OO0O )>0 :#line:2357
				for OO00OOOO0O0O00O0O ,OOOO00O000OO0O0OO ,url ,OO000OOO00O00O00O ,OOOO00OO0OO00O0O0 ,OO00O00OOO00O0000 in OOO00O00OOO00OO0O :#line:2358
					if OOOO00O000OO0O0OO .lower ()=="yes":#line:2359
						addDir ("[B]%s[/B]"%OO00OOOO0O0O00O0O ,'youtube',url ,description =OO00O00OOO00O0000 ,icon =OO000OOO00O00O00O ,fanart =OOOO00OO0OO00O0O0 ,themeit =THEME3 )#line:2360
					else :#line:2361
						addFile (OO00OOOO0O0O00O0O ,'viewVideo',url =url ,description =OO00O00OOO00O0000 ,icon =OO000OOO00O00O00O ,fanart =OOOO00OO0OO00O0O0 ,themeit =THEME2 )#line:2362
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2363
		else :#line:2364
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2365
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2366
			addFile ('%s'%O00OO0OO000O00O00 ,'',themeit =THEME3 )#line:2367
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2368
	setView ('files','viewType')#line:2369
def STARTP ():#line:2370
	OO0OOOO0OOO00O0OO =(ADDON .getSetting ("pass"))#line:2371
	if BUILDNAME =="":#line:2372
	 if not NOTIFY =='true':#line:2373
          O000OO0OOOOOOO0OO =wiz .workingURL (NOTIFICATION )#line:2374
	 if not NOTIFY2 =='true':#line:2375
          O000OO0OOOOOOO0OO =wiz .workingURL (NOTIFICATION2 )#line:2376
	 if not NOTIFY3 =='true':#line:2377
          O000OO0OOOOOOO0OO =wiz .workingURL (NOTIFICATION3 )#line:2378
	O000OO00OOOO0O00O =OO0OOOO0OOO00O0OO #line:2379
	O000OO0OOOOOOO0OO =urllib2 .Request (SPEED )#line:2380
	OOOO0O00OOO00000O =urllib2 .urlopen (O000OO0OOOOOOO0OO )#line:2381
	OOOO00O000O00000O =OOOO0O00OOO00000O .read ()#line:2382
	if OO0OOOO0OOO00O0OO ==O000OO00OOOO0O00O :#line:2383
				O000OO0OOOOOOO0OO =list #line:2384
				if O000OO00OOOO0O00O !=OOOO00O000O00000O :#line:2385
					OOO0OO0O0OOO000OO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2386
					if OOO0OO0O0OOO000OO :#line:2388
						ADDON .openSettings ()#line:2390
						STARTP ()#line:2391
						sys .exit ()#line:2392
					else :#line:2393
						sys .exit ()#line:2394
	return 'ok'#line:2398
def STARTP2 ():#line:2399
	O0000OOOO000OOO00 =(ADDON .getSetting ("user"))#line:2400
	O0OO00OO00O0OO000 =(UNAME )#line:2402
	O0OOO0OO00OOOOOOO =urllib2 .urlopen (O0OO00OO00O0OO000 )#line:2403
	OO0000OOO00OOO00O =O0OOO0OO00OOOOOOO .readlines ()#line:2404
	O0000O0OO00O0OOOO =0 #line:2405
	for O0O0O000O0OO0O000 in OO0000OOO00OOO00O :#line:2408
		if O0O0O000O0OO0O000 .split (' ==')[0 ]==O0000OOOO000OOO00 or O0O0O000O0OO0O000 .split ()[0 ]==O0000OOOO000OOO00 :#line:2409
			O0000O0OO00O0OOOO =1 #line:2410
			break #line:2411
	if O0000O0OO00O0OOOO ==0 :#line:2412
		O00O0O00OOO0OO0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2413
		if O00O0O00OOO0OO0O0 :#line:2415
			ADDON .openSettings ()#line:2417
			STARTP2 ()#line:2419
			sys .exit ()#line:2420
		else :#line:2421
			sys .exit ()#line:2422
	return 'ok'#line:2426
def passandpin ():#line:2427
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2428
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2429
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2430
def passandUsername ():#line:2431
	ADDON .openSettings ()#line:2432
def folderback ():#line:2435
    OO00O000O0OO00O0O =ADDON .getSetting ("path")#line:2436
    if OO00O000O0OO00O0O :#line:2437
      OO00O000O0OO00O0O =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2438
      ADDON .setSetting ("path",OO00O000O0OO00O0O )#line:2439
def backmyupbuild ():#line:2442
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2446
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2447
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2448
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2450
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2451
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2452
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2454
def maintMenu (view =None ):#line:2458
	O0OO0O00000O00O0O ='[B][COLOR green]ON[/COLOR][/B]';O0000O00OOO000000 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2460
	O000OOO0O0OO0O0O0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2461
	O0OOO0O0000000O0O ='true'if AUTOCACHE =='true'else 'false'#line:2462
	OO0OO00O0O00OO00O ='true'if AUTOPACKAGES =='true'else 'false'#line:2463
	O00OOOOOO0000OOO0 ='true'if AUTOTHUMBS =='true'else 'false'#line:2464
	O000OO00000OOO00O ='true'if SHOWMAINT =='true'else 'false'#line:2465
	O00OO0OO00OOOO0OO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2466
	O0000000O0OOO0O0O ='true'if INCLUDEALL =='true'else 'false'#line:2467
	O000OO00OO0O0OO0O ='true'if THIRDPARTY =='true'else 'false'#line:2468
	if wiz .Grab_Log (True )==False :O0O000OO0OO000OOO =0 #line:2469
	else :O0O000OO0OO000OOO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2470
	if wiz .Grab_Log (True ,True )==False :OOOO000O0OO0O00OO =0 #line:2471
	else :OOOO000O0OO0O00OO =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2472
	O00O000O00O0O00OO =int (O0O000OO0OO000OOO )+int (OOOO000O0OO0O00OO )#line:2473
	O00OOO0O00O0O0O0O =str (O00O000O00O0O00OO )+' Error(s) Found'if O00O000O00O0O00OO >0 else 'None Found'#line:2474
	OOO00OO0OOO0O00OO =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2475
	if O0000000O0OOO0O0O =='true':#line:2476
		O0O00OOO00OO0OOOO ='true'#line:2477
		OOOO000O0OO00OO00 ='true'#line:2478
		OO0O000OO0OOO0OO0 ='true'#line:2479
		OO00O00O00OOO0O0O ='true'#line:2480
		OOO00O0OO0O000O0O ='true'#line:2481
		OOO000OO000OOOO0O ='true'#line:2482
		O0000OO00O00O0O00 ='true'#line:2483
		OOOO00OOOOOOO0O0O ='true'#line:2484
	else :#line:2485
		O0O00OOO00OO0OOOO ='true'if INCLUDEBOB =='true'else 'false'#line:2486
		OOOO000O0OO00OO00 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2487
		OO0O000OO0OOO0OO0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2488
		OO00O00O00OOO0O0O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2489
		OOO00O0OO0O000O0O ='true'if INCLUDEEXODUS =='true'else 'false'#line:2490
		OOO000OO000OOOO0O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2491
		O0000OO00O00O0O00 ='true'if INCLUDESALTS =='true'else 'false'#line:2492
		OOOO00OOOOOOO0O0O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2493
	OO000OOO0O0000OOO =wiz .getSize (PACKAGES )#line:2494
	OOO000O00OO0OO0OO =wiz .getSize (THUMBS )#line:2495
	OO0OO0OO0OO0O000O =wiz .getCacheSize ()#line:2496
	OOOOO0O0O00OO00OO =OO000OOO0O0000OOO +OOO000O00OO0OO0OO +OO0OO0OO0OO0O000O #line:2497
	O00OO0O0O000OO00O =['Daily','Always','3 Days','Weekly']#line:2498
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2499
	if view =="clean"or SHOWMAINT =='true':#line:2500
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOO0O0O00OO00OO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2501
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0OO0OO0OO0O000O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2502
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000OOO0O0000OOO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2503
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO000O00OO0OO0OO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2504
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2505
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2506
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2507
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2508
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2509
	if view =="addon"or SHOWMAINT =='false':#line:2510
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2511
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2512
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2513
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2514
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2515
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2516
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2517
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2518
	if view =="misc"or SHOWMAINT =='true':#line:2519
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2520
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2521
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2522
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2523
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2524
		addFile ('View Errors in Log: %s'%(O00OOO0O00O0O0O0O ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2525
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2526
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2527
		addFile ('Clear Wizard Log File%s'%OOO00OO0OOO0O00OO ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2528
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2529
	if view =="backup"or SHOWMAINT =='true':#line:2530
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2532
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2533
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2534
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2535
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2536
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2537
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2538
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2539
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2540
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2541
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2542
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2543
	if view =="tweaks"or SHOWMAINT =='true':#line:2544
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2545
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2546
		else :#line:2547
			if os .path .exists (ADVANCED ):#line:2548
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2549
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2550
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2551
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2552
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2553
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2554
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2555
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2556
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2557
	addFile ('Show All Maintenance: %s'%O000OO00000OOO00O .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2558
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2559
	addFile ('Third Party Wizards: %s'%O000OO00OO0O0OO0O .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2560
	if O000OO00OO0O0OO0O =='true':#line:2561
		OO0OOO000O0000OO0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2562
		O000OOOO00O0OOO00 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2563
		O00OOO0000OO000O0 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2564
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OOO000O0000OO0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2565
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000OOOO00O0OOO00 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2566
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00OOO0000OO000O0 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2567
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2568
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O000OOO0O0OO0O0O0 .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2569
	if O000OOO0O0OO0O0O0 =='true':#line:2570
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O00OO0O0O000OO00O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2571
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0OOO0O0000000O0O .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2572
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO0OO00O0O00OO00O .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2573
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O00OOOOOO0000OOO0 .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2574
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2575
	addFile ('Include Video Cache in Clear Cache: %s'%O00OO0OO00OOOO0OO .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2576
	if O00OO0OO00OOOO0OO =='true':#line:2577
		addFile ('--- Include All Video Addons: %s'%O0000000O0OOO0O0O .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2578
		addFile ('--- Include Bob: %s'%O0O00OOO00OO0OOOO .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2579
		addFile ('--- Include Phoenix: %s'%OOOO000O0OO00OO00 .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2580
		addFile ('--- Include Specto: %s'%OO0O000OO0OOO0OO0 .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2581
		addFile ('--- Include Exodus: %s'%OOO00O0OO0O000O0O .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2582
		addFile ('--- Include Salts: %s'%O0000OO00O00O0O00 .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2583
		addFile ('--- Include Salts HD Lite: %s'%OOOO00OOOOOOO0O0O .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2584
		addFile ('--- Include One Channel: %s'%OOO000OO000OOOO0O .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2585
		addFile ('--- Include Genesis: %s'%OO00O00O00OOO0O0O .replace ('true',O0OO0O00000O00O0O ).replace ('false',O0000O00OOO000000 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2586
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2587
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2588
	setView ('files','viewType')#line:2589
def advancedWindow (url =None ):#line:2591
	if not ADVANCEDFILE =='http://':#line:2592
		if url ==None :#line:2593
			OOOO0O0OOO00O0000 =wiz .workingURL (ADVANCEDFILE )#line:2594
			OOO00OO0O000O0O00 =uservar .ADVANCEDFILE #line:2595
		else :#line:2596
			OOOO0O0OOO00O0000 =wiz .workingURL (url )#line:2597
			OOO00OO0O000O0O00 =url #line:2598
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2599
		if os .path .exists (ADVANCED ):#line:2600
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2601
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2602
		if OOOO0O0OOO00O0000 ==True :#line:2603
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2604
			O000000000O0O0000 =wiz .openURL (OOO00OO0O000O0O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2605
			OO00O0O0O0O0O0O00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000000000O0O0000 )#line:2606
			if len (OO00O0O0O0O0O0O00 )>0 :#line:2607
				for OOO0OOO0O0O00OO0O ,OO0OOO0O00OOOOO0O ,url ,OOOO000OOOOO000O0 ,O0O00O0O00OOOOO0O ,O00O000000OOOO00O in OO00O0O0O0O0O0O00 :#line:2608
					if OO0OOO0O00OOOOO0O .lower ()=="yes":#line:2609
						addDir ("[B]%s[/B]"%OOO0OOO0O0O00OO0O ,'advancedsetting',url ,description =O00O000000OOOO00O ,icon =OOOO000OOOOO000O0 ,fanart =O0O00O0O00OOOOO0O ,themeit =THEME3 )#line:2610
					else :#line:2611
						addFile (OOO0OOO0O0O00OO0O ,'writeadvanced',OOO0OOO0O0O00OO0O ,url ,description =O00O000000OOOO00O ,icon =OOOO000OOOOO000O0 ,fanart =O0O00O0O00OOOOO0O ,themeit =THEME2 )#line:2612
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2613
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOO0O0OOO00O0000 )#line:2614
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2615
def writeAdvanced (OOOO0O0O0O0OOO0OO ,OO00OOOOOO00OOOO0 ):#line:2617
	O0OOOO0O0OO0OO0OO =wiz .workingURL (OO00OOOOOO00OOOO0 )#line:2618
	if O0OOOO0O0OO0OO0OO ==True :#line:2619
		if os .path .exists (ADVANCED ):OO0OOOO0O0OO00OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0O0O0O0OOO0OO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2620
		else :OO0OOOO0O0OO00OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0O0O0O0OOO0OO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2621
		if OO0OOOO0O0OO00OOO ==1 :#line:2623
			O0O0O00OOOOOOOOOO =wiz .openURL (OO00OOOOOO00OOOO0 )#line:2624
			OOO0OO0O00OOO0OOO =open (ADVANCED ,'w');#line:2625
			OOO0OO0O00OOO0OOO .write (O0O0O00OOOOOOOOOO )#line:2626
			OOO0OO0O00OOO0OOO .close ()#line:2627
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2628
			wiz .killxbmc (True )#line:2629
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2630
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OOOO0O0OO0OO0OO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2631
def viewAdvanced ():#line:2633
	OO0O00000000OOOO0 =open (ADVANCED )#line:2634
	OOO000OOO0OOOOOOO =OO0O00000000OOOO0 .read ().replace ('\t','    ')#line:2635
	wiz .TextBox (ADDONTITLE ,OOO000OOO0OOOOOOO )#line:2636
	OO0O00000000OOOO0 .close ()#line:2637
def removeAdvanced ():#line:2639
	if os .path .exists (ADVANCED ):#line:2640
		wiz .removeFile (ADVANCED )#line:2641
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2642
def showAutoAdvanced ():#line:2644
	notify .autoConfig ()#line:2645
def getIP ():#line:2647
	OOOOOO0O0OO000000 ='http://whatismyipaddress.com/'#line:2648
	if not wiz .workingURL (OOOOOO0O0OO000000 ):return 'Unknown','Unknown','Unknown'#line:2649
	O00O000OOO00O0O00 =wiz .openURL (OOOOOO0O0OO000000 ).replace ('\n','').replace ('\r','')#line:2650
	if not 'Access Denied'in O00O000OOO00O0O00 :#line:2651
		O000OO0OO0OO0O000 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O00O000OOO00O0O00 )#line:2652
		OOO0000000000O000 =O000OO0OO0OO0O000 [0 ]if (len (O000OO0OO0OO0O000 )>0 )else 'Unknown'#line:2653
		O00O0O0000OOOO000 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O00O000OOO00O0O00 )#line:2654
		OO0OOO0O0O0O0O00O =O00O0O0000OOOO000 [0 ]if (len (O00O0O0000OOOO000 )>0 )else 'Unknown'#line:2655
		O0O0O0OO000OOO0OO =O00O0O0000OOOO000 [1 ]+', '+O00O0O0000OOOO000 [2 ]+', '+O00O0O0000OOOO000 [3 ]if (len (O00O0O0000OOOO000 )>2 )else 'Unknown'#line:2656
		return OOO0000000000O000 ,OO0OOO0O0O0O0O00O ,O0O0O0OO000OOO0OO #line:2657
	else :return 'Unknown','Unknown','Unknown'#line:2658
def systemInfo ():#line:2660
	OO0O0O0O000OO0O0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2674
	OOOO0000O0OO0O00O =[];OOOO000O00O0O00OO =0 #line:2675
	for OO0OOOO000OOOOOOO in OO0O0O0O000OO0O0O :#line:2676
		O0O0O00O0OO00OOOO =wiz .getInfo (OO0OOOO000OOOOOOO )#line:2677
		O00OOO000OOOO0OOO =0 #line:2678
		while O0O0O00O0OO00OOOO =="Busy"and O00OOO000OOOO0OOO <10 :#line:2679
			O0O0O00O0OO00OOOO =wiz .getInfo (OO0OOOO000OOOOOOO );O00OOO000OOOO0OOO +=1 ;wiz .log ("%s sleep %s"%(OO0OOOO000OOOOOOO ,str (O00OOO000OOOO0OOO )));xbmc .sleep (1000 )#line:2680
		OOOO0000O0OO0O00O .append (O0O0O00O0OO00OOOO )#line:2681
		OOOO000O00O0O00OO +=1 #line:2682
	O0OO000O0000O0OOO =OOOO0000O0OO0O00O [8 ]if 'Una'in OOOO0000O0OO0O00O [8 ]else wiz .convertSize (int (float (OOOO0000O0OO0O00O [8 ][:-8 ]))*1024 *1024 )#line:2683
	O00O0O0OOOO0OO00O =OOOO0000O0OO0O00O [9 ]if 'Una'in OOOO0000O0OO0O00O [9 ]else wiz .convertSize (int (float (OOOO0000O0OO0O00O [9 ][:-8 ]))*1024 *1024 )#line:2684
	O00O00O0OOOOOO000 =OOOO0000O0OO0O00O [10 ]if 'Una'in OOOO0000O0OO0O00O [10 ]else wiz .convertSize (int (float (OOOO0000O0OO0O00O [10 ][:-8 ]))*1024 *1024 )#line:2685
	OO0OOO0O0OO0O0OO0 =wiz .convertSize (int (float (OOOO0000O0OO0O00O [11 ][:-2 ]))*1024 *1024 )#line:2686
	OO0O0OO0OOO0O0000 =wiz .convertSize (int (float (OOOO0000O0OO0O00O [12 ][:-2 ]))*1024 *1024 )#line:2687
	OO00OO0000O000OOO =wiz .convertSize (int (float (OOOO0000O0OO0O00O [13 ][:-2 ]))*1024 *1024 )#line:2688
	O0000OOO0OO0OO0OO ,O0OOOO000000000O0 ,O0OO0O0000O0OOO0O =getIP ()#line:2689
	OO000O0O0O00000OO =[];OO0O00000OO0OO000 =[];O00000O00O0O0OOOO =[];O000OOO00OO0O00O0 =[];OO00O00OOO00O0O0O =[];O0O0O000OOO000O0O =[];OOO0O0O0OOOO000O0 =[]#line:2691
	O0OO000OOOO00OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2693
	for OOOO0OOO00OO00OO0 in sorted (O0OO000OOOO00OOOO ,key =lambda OO000O000O000OOO0 :OO000O000O000OOO0 ):#line:2694
		O000O0OO000000O0O =os .path .split (OOOO0OOO00OO00OO0 [:-1 ])[1 ]#line:2695
		if O000O0OO000000O0O =='packages':continue #line:2696
		OO00OOO000O000000 =os .path .join (OOOO0OOO00OO00OO0 ,'addon.xml')#line:2697
		if os .path .exists (OO00OOO000O000000 ):#line:2698
			O00O0OOO00O0OO0O0 =open (OO00OOO000O000000 )#line:2699
			OOO000OOO0OOOO0OO =O00O0OOO00O0OO0O0 .read ()#line:2700
			OO00000O00O0000OO =re .compile ("<provides>(.+?)</provides>").findall (OOO000OOO0OOOO0OO )#line:2701
			if len (OO00000O00O0000OO )==0 :#line:2702
				if O000O0OO000000O0O .startswith ('skin'):OOO0O0O0OOOO000O0 .append (O000O0OO000000O0O )#line:2703
				if O000O0OO000000O0O .startswith ('repo'):OO00O00OOO00O0O0O .append (O000O0OO000000O0O )#line:2704
				else :O0O0O000OOO000O0O .append (O000O0OO000000O0O )#line:2705
			elif not (OO00000O00O0000OO [0 ]).find ('executable')==-1 :O000OOO00OO0O00O0 .append (O000O0OO000000O0O )#line:2706
			elif not (OO00000O00O0000OO [0 ]).find ('video')==-1 :O00000O00O0O0OOOO .append (O000O0OO000000O0O )#line:2707
			elif not (OO00000O00O0000OO [0 ]).find ('audio')==-1 :OO0O00000OO0OO000 .append (O000O0OO000000O0O )#line:2708
			elif not (OO00000O00O0000OO [0 ]).find ('image')==-1 :OO000O0O0O00000OO .append (O000O0OO000000O0O )#line:2709
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2711
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0000O0OO0O00O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2712
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0000O0OO0O00O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2713
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2714
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0000O0OO0O00O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2715
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0000O0OO0O00O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2716
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2718
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0000O0OO0O00O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2719
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0000O0OO0O00O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2720
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2722
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000O0000O0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2723
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0OOOO0OO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2724
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O00O0OOOOOO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2725
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2727
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0O0OO0O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2728
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OO0OOO0O0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2729
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0000O000OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2730
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2732
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0000O0OO0O00O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2733
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OOO0OO0OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2734
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO000000000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2735
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O0000O0OOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2736
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0000O0OO0O00O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2737
	OOOOOOO000O00OOO0 =len (OO000O0O0O00000OO )+len (OO0O00000OO0OO000 )+len (O00000O00O0O0OOOO )+len (O000OOO00OO0O00O0 )+len (O0O0O000OOO000O0O )+len (OOO0O0O0OOOO000O0 )+len (OO00O00OOO00O0O0O )#line:2739
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOOOOOO000O00OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2740
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00000O00O0O0OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2741
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000OOO00OO0O00O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2742
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O00000OO0OO000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2743
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO000O0O0O00000OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2744
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O00OOO00O0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2745
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O0O0OOOO000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2746
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O000OOO000O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2747
def Menu ():#line:2748
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2749
def saveMenu ():#line:2751
	OOOO0000OOO0O000O ='[COLOR green]מופעל[/COLOR]';O000000O00OOOOO0O ='[COLOR red]מבוטל[/COLOR]'#line:2753
	O000O0OOO0O00OO00 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2754
	OO0O0O0O00O000OOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:2755
	OO00O000O00000OO0 ='true'if KEEPINFO =='true'else 'false'#line:2756
	O00OO0OO00O00OOOO ='true'if KEEPSOUND =='true'else 'false'#line:2758
	O0000000OOO0O0OO0 ='true'if KEEPVIEW =='true'else 'false'#line:2759
	OO0OOOO0OOOO0OOOO ='true'if KEEPSKIN =='true'else 'false'#line:2760
	O00O00OOOO0000O00 ='true'if KEEPSKIN2 =='true'else 'false'#line:2761
	OO0O0OOO00O0O00OO ='true'if KEEPSKIN3 =='true'else 'false'#line:2762
	O0O00O0OOOO000O0O ='true'if KEEPADDONS =='true'else 'false'#line:2763
	O0OOO0O0O00000OOO ='true'if KEEPPVR =='true'else 'false'#line:2764
	OOOOOO0O0000OOO0O ='true'if KEEPTVLIST =='true'else 'false'#line:2765
	O0OOOOOO0000000O0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2766
	O0000000OO0O00000 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2767
	O00O0O00OO0OOOOO0 ='true'if KEEPHUBTV =='true'else 'false'#line:2768
	OOO0O0OO0000OOO0O ='true'if KEEPHUBVOD =='true'else 'false'#line:2769
	O0OOOO00000000OOO ='true'if KEEPHUBKIDS =='true'else 'false'#line:2770
	OOOO000OOOO0O0O00 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2771
	OO0OOOOO00O00OOO0 ='true'if KEEPHUBMENU =='true'else 'false'#line:2772
	OO0O0OO0O00O00OO0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:2773
	O0O0000O000O0OO0O ='true'if KEEPTRAKT =='true'else 'false'#line:2774
	O0OOO00O0OOO00O0O ='true'if KEEPREAL =='true'else 'false'#line:2775
	OOO00OO0OO0O0O000 ='true'if KEEPRD2 =='true'else 'false'#line:2776
	O00OO0O0000O0O000 ='true'if KEEPTORNET =='true'else 'true'#line:2777
	OOO0OOO0O0OOOOO00 ='true'if KEEPLOGIN =='true'else 'false'#line:2778
	OO0000OOOO0OOO0O0 ='true'if KEEPSOURCES =='true'else 'false'#line:2779
	O0OO0OO000O0O0O00 ='true'if KEEPADVANCED =='true'else 'false'#line:2780
	OOO00O000O0O0000O ='true'if KEEPPROFILES =='true'else 'false'#line:2781
	O000O0OO00O000OO0 ='true'if KEEPFAVS =='true'else 'false'#line:2782
	O00OO0O00O0000OOO ='true'if KEEPREPOS =='true'else 'false'#line:2783
	O000O00OO0000OO00 ='true'if KEEPSUPER =='true'else 'false'#line:2784
	O0O00O0OO0000O00O ='true'if KEEPWHITELIST =='true'else 'false'#line:2785
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:2789
	if O0O00O0OO0000O00O =='true':#line:2790
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2791
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2792
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2793
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2794
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2795
	addFile ('%s התקנת קיר סרטים: '%O000O0OOO0O00OO00 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2797
	addFile ('%s שמירת חשבון RD: '%O0OOO00O0OOO00O0O .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2798
	addFile ('%s שמירת חשבון טראקט: '%O0O0000O000O0OO0O .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2799
	addFile ('%s שמירת מועדפים: '%O000O0OO00O000OO0 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2802
	addFile ('%s שמירת לקוח טלוויזיה: '%O0OOO0O0O00000OOO .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2803
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%OOOOOO0O0000OOO0O .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2804
	addFile ('%s שמירת אריח סרטים: '%O0OOOOOO0000000O0 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2805
	addFile ('%s שמירת אריח סדרות: '%O0000000OO0O00000 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2806
	addFile ('%s שמירת אריח טלויזיה: '%O00O0O00OO0OOOOO0 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2807
	addFile ('%s שמירת אריח תוכן ישראלי: '%OOO0O0OO0000OOO0O .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2808
	addFile ('%s שמירת אריח ילדים: '%O0OOOO00000000OOO .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2809
	addFile ('%s שמירת אריח מוסיקה: '%OOOO000OOOO0O0O00 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2810
	addFile ('%s שמירת תפריט אריחים ראשי: '%OO0OOOOO00O00OOO0 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2811
	addFile ('%s שמירת כל האריחים בסקין: '%OO0OOOO0OOOO0OOOO .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2812
	addFile ('%s שמירת הרחבות שהתקנתי: '%O0O00O0OOOO000O0O .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2819
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%OO00O000O00000OO0 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2820
	addFile ('%s שמירת ספריית סרטים וסדרות: '%OO0O0O0O00O000OOO .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2823
	addFile ('%s שמירת מקורות וידאו: '%OO0000OOOO0OOO0O0 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2824
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%O00OO0OO00O00OOOO .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2825
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%O0000000OOO0O0OO0 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2827
	addFile ('%s שמירת פליליסט לאודר: '%OO0O0OO0O00O00OO0 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2828
	addFile ('%s שמירת הרחבות ידנית: '%O0O00O0OO0000O00O .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2829
	addFile ('%s שמירת הגדרות באפר: '%O0OO0OO000O0O0O00 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2833
	addFile ('%s שמירת סופר מועדפים: '%O000O00OO0000OO00 .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2834
	addFile ('%s שמירת רשימות ריפו: '%O00OO0O00O0000OOO .replace ('true',OOOO0000OOO0O000O ).replace ('false',O000000O00OOOOO0O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2835
	setView ('files','viewType')#line:2837
def traktMenu ():#line:2839
	O00O00O0O0000OO00 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2840
	O00O0O0O0OOOOOO0O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2841
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2842
	addFile ('Save Trakt Data: %s'%O00O00O0O0000OO00 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2843
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O00O0O0O0OOOOOO0O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2844
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2845
	for O00O00O0O0000OO00 in traktit .ORDER :#line:2847
		O00O0O0O0O0O00000 =TRAKTID [O00O00O0O0000OO00 ]['name']#line:2848
		OOO0O0OOO00OOO0O0 =TRAKTID [O00O00O0O0000OO00 ]['path']#line:2849
		OOOOOOO000000OO00 =TRAKTID [O00O00O0O0000OO00 ]['saved']#line:2850
		OO0OO0000O0O0O000 =TRAKTID [O00O00O0O0000OO00 ]['file']#line:2851
		OOOO00OO000O0O0OO =wiz .getS (OOOOOOO000000OO00 )#line:2852
		O0OOOO0000000O0O0 =traktit .traktUser (O00O00O0O0000OO00 )#line:2853
		O00O0O0O0OO000OO0 =TRAKTID [O00O00O0O0000OO00 ]['icon']if os .path .exists (OOO0O0OOO00OOO0O0 )else ICONTRAKT #line:2854
		OO0O00OOOO000OOO0 =TRAKTID [O00O00O0O0000OO00 ]['fanart']if os .path .exists (OOO0O0OOO00OOO0O0 )else FANART #line:2855
		OOO0OOOOO0OO00O0O =createMenu ('saveaddon','Trakt',O00O00O0O0000OO00 )#line:2856
		O0O0OO0O00OOO00O0 =createMenu ('save','Trakt',O00O00O0O0000OO00 )#line:2857
		OOO0OOOOO0OO00O0O .append ((THEME2 %'%s Settings'%O00O0O0O0O0O00000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O00O00O0O0000OO00 )))#line:2858
		addFile ('[+]-> %s'%O00O0O0O0O0O00000 ,'',icon =O00O0O0O0OO000OO0 ,fanart =OO0O00OOOO000OOO0 ,themeit =THEME3 )#line:2860
		if not os .path .exists (OOO0O0OOO00OOO0O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O0O0O0OO000OO0 ,fanart =OO0O00OOOO000OOO0 ,menu =OOO0OOOOO0OO00O0O )#line:2861
		elif not O0OOOO0000000O0O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O00O00O0O0000OO00 ,icon =O00O0O0O0OO000OO0 ,fanart =OO0O00OOOO000OOO0 ,menu =OOO0OOOOO0OO00O0O )#line:2862
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OOOO0000000O0O0 ,'authtrakt',O00O00O0O0000OO00 ,icon =O00O0O0O0OO000OO0 ,fanart =OO0O00OOOO000OOO0 ,menu =OOO0OOOOO0OO00O0O )#line:2863
		if OOOO00OO000O0O0OO =="":#line:2864
			if os .path .exists (OO0OO0000O0O0O000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O00O00O0O0000OO00 ,icon =O00O0O0O0OO000OO0 ,fanart =OO0O00OOOO000OOO0 ,menu =O0O0OO0O00OOO00O0 )#line:2865
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O00O00O0O0000OO00 ,icon =O00O0O0O0OO000OO0 ,fanart =OO0O00OOOO000OOO0 ,menu =O0O0OO0O00OOO00O0 )#line:2866
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOO00OO000O0O0OO ,'',icon =O00O0O0O0OO000OO0 ,fanart =OO0O00OOOO000OOO0 ,menu =O0O0OO0O00OOO00O0 )#line:2867
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2869
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2870
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2871
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2872
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2873
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2874
	setView ('files','viewType')#line:2875
def realMenu ():#line:2877
	O0OOOOOO00O0O0000 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2878
	O0OOOO000OO0OO00O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2879
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2880
	addFile ('Save Real Debrid Data: %s'%O0OOOOOO00O0O0000 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2881
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0OOOO000OO0OO00O ),'',icon =ICONREAL ,themeit =THEME3 )#line:2882
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2883
	for OOOOOOOOOO0O000OO in debridit .ORDER :#line:2885
		O0O0O0000OOO0000O =DEBRIDID [OOOOOOOOOO0O000OO ]['name']#line:2886
		OO0000OOOOO0OO000 =DEBRIDID [OOOOOOOOOO0O000OO ]['path']#line:2887
		O0OOO0O0OOO0OO0O0 =DEBRIDID [OOOOOOOOOO0O000OO ]['saved']#line:2888
		O0OOOOO0O0000O0O0 =DEBRIDID [OOOOOOOOOO0O000OO ]['file']#line:2889
		OOO0O0O0000O0000O =wiz .getS (O0OOO0O0OOO0OO0O0 )#line:2890
		OOOOOO000OO000O00 =debridit .debridUser (OOOOOOOOOO0O000OO )#line:2891
		OO0O0O00000000OO0 =DEBRIDID [OOOOOOOOOO0O000OO ]['icon']if os .path .exists (OO0000OOOOO0OO000 )else ICONREAL #line:2892
		OOO00OOOO0OOO00O0 =DEBRIDID [OOOOOOOOOO0O000OO ]['fanart']if os .path .exists (OO0000OOOOO0OO000 )else FANART #line:2893
		OO0000OOO000OOOO0 =createMenu ('saveaddon','Debrid',OOOOOOOOOO0O000OO )#line:2894
		O00OOO0OOOO00O000 =createMenu ('save','Debrid',OOOOOOOOOO0O000OO )#line:2895
		OO0000OOO000OOOO0 .append ((THEME2 %'%s Settings'%O0O0O0000OOO0000O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOOOOOOOOO0O000OO )))#line:2896
		addFile ('[+]-> %s'%O0O0O0000OOO0000O ,'',icon =OO0O0O00000000OO0 ,fanart =OOO00OOOO0OOO00O0 ,themeit =THEME3 )#line:2898
		if not os .path .exists (OO0000OOOOO0OO000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0O0O00000000OO0 ,fanart =OOO00OOOO0OOO00O0 ,menu =OO0000OOO000OOOO0 )#line:2899
		elif not OOOOOO000OO000O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOOOOOOOOO0O000OO ,icon =OO0O0O00000000OO0 ,fanart =OOO00OOOO0OOO00O0 ,menu =OO0000OOO000OOOO0 )#line:2900
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOOO000OO000O00 ,'authdebrid',OOOOOOOOOO0O000OO ,icon =OO0O0O00000000OO0 ,fanart =OOO00OOOO0OOO00O0 ,menu =OO0000OOO000OOOO0 )#line:2901
		if OOO0O0O0000O0000O =="":#line:2902
			if os .path .exists (O0OOOOO0O0000O0O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOOOOOOOOO0O000OO ,icon =OO0O0O00000000OO0 ,fanart =OOO00OOOO0OOO00O0 ,menu =O00OOO0OOOO00O000 )#line:2903
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOOOOOOOOO0O000OO ,icon =OO0O0O00000000OO0 ,fanart =OOO00OOOO0OOO00O0 ,menu =O00OOO0OOOO00O000 )#line:2904
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0O0O0000O0000O ,'',icon =OO0O0O00000000OO0 ,fanart =OOO00OOOO0OOO00O0 ,menu =O00OOO0OOOO00O000 )#line:2905
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2907
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2908
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2909
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2910
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2911
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2912
	setView ('files','viewType')#line:2913
def loginMenu ():#line:2915
	O0O0OOOOOOO00O000 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:2916
	OOOO0OO00OO00O000 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:2917
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:2918
	addFile ('Save Login Data: %s'%O0O0OOOOOOO00O000 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:2919
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOO0OO00OO00O000 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2920
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2921
	for O0O0OOOOOOO00O000 in loginit .ORDER :#line:2923
		O00OOO00O0O000OOO =LOGINID [O0O0OOOOOOO00O000 ]['name']#line:2924
		OOO0O0OOOO00000OO =LOGINID [O0O0OOOOOOO00O000 ]['path']#line:2925
		O0O00OOOO00OO0000 =LOGINID [O0O0OOOOOOO00O000 ]['saved']#line:2926
		O0OO000O0OO0000O0 =LOGINID [O0O0OOOOOOO00O000 ]['file']#line:2927
		OO0O0O0OOO00OO0O0 =wiz .getS (O0O00OOOO00OO0000 )#line:2928
		O0OO000OOOOO0OOOO =loginit .loginUser (O0O0OOOOOOO00O000 )#line:2929
		O0OO000O0OOO0O0OO =LOGINID [O0O0OOOOOOO00O000 ]['icon']if os .path .exists (OOO0O0OOOO00000OO )else ICONLOGIN #line:2930
		OOOOOOOO00000O0OO =LOGINID [O0O0OOOOOOO00O000 ]['fanart']if os .path .exists (OOO0O0OOOO00000OO )else FANART #line:2931
		OOO000O00O0O0OOOO =createMenu ('saveaddon','Login',O0O0OOOOOOO00O000 )#line:2932
		O00O00OO0OO0O000O =createMenu ('save','Login',O0O0OOOOOOO00O000 )#line:2933
		OOO000O00O0O0OOOO .append ((THEME2 %'%s Settings'%O00OOO00O0O000OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0O0OOOOOOO00O000 )))#line:2934
		addFile ('[+]-> %s'%O00OOO00O0O000OOO ,'',icon =O0OO000O0OOO0O0OO ,fanart =OOOOOOOO00000O0OO ,themeit =THEME3 )#line:2936
		if not os .path .exists (OOO0O0OOOO00000OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OO000O0OOO0O0OO ,fanart =OOOOOOOO00000O0OO ,menu =OOO000O00O0O0OOOO )#line:2937
		elif not O0OO000OOOOO0OOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0O0OOOOOOO00O000 ,icon =O0OO000O0OOO0O0OO ,fanart =OOOOOOOO00000O0OO ,menu =OOO000O00O0O0OOOO )#line:2938
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OO000OOOOO0OOOO ,'authlogin',O0O0OOOOOOO00O000 ,icon =O0OO000O0OOO0O0OO ,fanart =OOOOOOOO00000O0OO ,menu =OOO000O00O0O0OOOO )#line:2939
		if OO0O0O0OOO00OO0O0 =="":#line:2940
			if os .path .exists (O0OO000O0OO0000O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0O0OOOOOOO00O000 ,icon =O0OO000O0OOO0O0OO ,fanart =OOOOOOOO00000O0OO ,menu =O00O00OO0OO0O000O )#line:2941
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0O0OOOOOOO00O000 ,icon =O0OO000O0OOO0O0OO ,fanart =OOOOOOOO00000O0OO ,menu =O00O00OO0OO0O000O )#line:2942
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0O0O0OOO00OO0O0 ,'',icon =O0OO000O0OOO0O0OO ,fanart =OOOOOOOO00000O0OO ,menu =O00O00OO0OO0O000O )#line:2943
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2945
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2946
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2947
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2948
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2949
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2950
	setView ('files','viewType')#line:2951
def fixUpdate ():#line:2953
	if KODIV <17 :#line:2954
		O00OO000OOOOOOOO0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:2955
		try :#line:2956
			os .remove (O00OO000OOOOOOOO0 )#line:2957
		except Exception as O00OOOO0O0O0OOOOO :#line:2958
			wiz .log ("Unable to remove %s, Purging DB"%O00OO000OOOOOOOO0 )#line:2959
			wiz .purgeDb (O00OO000OOOOOOOO0 )#line:2960
	else :#line:2961
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:2962
def removeAddonMenu ():#line:2964
	O0O0O0OOO0O00O0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2965
	OO000O0000OOOOO0O =[];OO0OO0O0O0O00O0OO =[]#line:2966
	for OO0OOO000O00OOOO0 in sorted (O0O0O0OOO0O00O0OO ,key =lambda OO0O0OOO00O000OOO :OO0O0OOO00O000OOO ):#line:2967
		O0000OO0OO0O0OOOO =os .path .split (OO0OOO000O00OOOO0 [:-1 ])[1 ]#line:2968
		if O0000OO0OO0O0OOOO in EXCLUDES :continue #line:2969
		elif O0000OO0OO0O0OOOO in DEFAULTPLUGINS :continue #line:2970
		elif O0000OO0OO0O0OOOO =='packages':continue #line:2971
		OOOOO000000O00OOO =os .path .join (OO0OOO000O00OOOO0 ,'addon.xml')#line:2972
		if os .path .exists (OOOOO000000O00OOO ):#line:2973
			O0O0OO00OOO0O0000 =open (OOOOO000000O00OOO )#line:2974
			OOOOO00OOOOO00O0O =O0O0OO00OOO0O0000 .read ()#line:2975
			OO000O0O0OOOOOOOO =wiz .parseDOM (OOOOO00OOOOO00O0O ,'addon',ret ='id')#line:2976
			OOOOOOOOOO00O00OO =O0000OO0OO0O0OOOO if len (OO000O0O0OOOOOOOO )==0 else OO000O0O0OOOOOOOO [0 ]#line:2978
			try :#line:2979
				OO0O000OOO0OOOOOO =xbmcaddon .Addon (id =OOOOOOOOOO00O00OO )#line:2980
				OO000O0000OOOOO0O .append (OO0O000OOO0OOOOOO .getAddonInfo ('name'))#line:2981
				OO0OO0O0O0O00O0OO .append (OOOOOOOOOO00O00OO )#line:2982
			except :#line:2983
				pass #line:2984
	if len (OO000O0000OOOOO0O )==0 :#line:2985
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:2986
		return #line:2987
	if KODIV >16 :#line:2988
		O00OOO0OOOOOO00OO =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO000O0000OOOOO0O )#line:2989
	else :#line:2990
		O00OOO0OOOOOO00OO =[];OOOO00OO0OO0OO00O =0 #line:2991
		O000O0O0O00OO0OO0 =["-- Click here to Continue --"]+OO000O0000OOOOO0O #line:2992
		while not OOOO00OO0OO0OO00O ==-1 :#line:2993
			OOOO00OO0OO0OO00O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O000O0O0O00OO0OO0 )#line:2994
			if OOOO00OO0OO0OO00O ==-1 :break #line:2995
			elif OOOO00OO0OO0OO00O ==0 :break #line:2996
			else :#line:2997
				OO0OOO0OO0OOO0O0O =(OOOO00OO0OO0OO00O -1 )#line:2998
				if OO0OOO0OO0OOO0O0O in O00OOO0OOOOOO00OO :#line:2999
					O00OOO0OOOOOO00OO .remove (OO0OOO0OO0OOO0O0O )#line:3000
					O000O0O0O00OO0OO0 [OOOO00OO0OO0OO00O ]=OO000O0000OOOOO0O [OO0OOO0OO0OOO0O0O ]#line:3001
				else :#line:3002
					O00OOO0OOOOOO00OO .append (OO0OOO0OO0OOO0O0O )#line:3003
					O000O0O0O00OO0OO0 [OOOO00OO0OO0OO00O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO000O0000OOOOO0O [OO0OOO0OO0OOO0O0O ])#line:3004
	if O00OOO0OOOOOO00OO ==None :return #line:3005
	if len (O00OOO0OOOOOO00OO )>0 :#line:3006
		wiz .addonUpdates ('set')#line:3007
		for O0O0O0000O0O00000 in O00OOO0OOOOOO00OO :#line:3008
			removeAddon (OO0OO0O0O0O00O0OO [O0O0O0000O0O00000 ],OO000O0000OOOOO0O [O0O0O0000O0O00000 ],True )#line:3009
		xbmc .sleep (1000 )#line:3011
		if INSTALLMETHOD ==1 :O0OO00O0O0OO0O0O0 =1 #line:3013
		elif INSTALLMETHOD ==2 :O0OO00O0O0OO0O0O0 =0 #line:3014
		else :O0OO00O0O0OO0O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3015
		if O0OO00O0O0OO0O0O0 ==1 :wiz .reloadFix ('remove addon')#line:3016
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3017
def removeAddonDataMenu ():#line:3019
	if os .path .exists (ADDOND ):#line:3020
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3021
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3022
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3023
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3024
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3025
		OOO0O0O0OOO00000O =glob .glob (os .path .join (ADDOND ,'*/'))#line:3026
		for OO00OO00OO00O0O0O in sorted (OOO0O0O0OOO00000O ,key =lambda O0OO00O0O00O0000O :O0OO00O0O00O0000O ):#line:3027
			OO00OOOOO000O0000 =OO00OO00OO00O0O0O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3028
			OOO0OO0OOOOOO0OOO =os .path .join (OO00OO00OO00O0O0O .replace (ADDOND ,ADDONS ),'icon.png')#line:3029
			O0OOO0OO00OOO0O0O =os .path .join (OO00OO00OO00O0O0O .replace (ADDOND ,ADDONS ),'fanart.png')#line:3030
			OOO0O00O0OOOO0OOO =OO00OOOOO000O0000 #line:3031
			O000O000O0OO0O00O ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3032
			for O00OO00O000000000 in O000O000O0OO0O00O :#line:3033
				OOO0O00O0OOOO0OOO =OOO0O00O0OOOO0OOO .replace (O00OO00O000000000 ,O000O000O0OO0O00O [O00OO00O000000000 ])#line:3034
			if OO00OOOOO000O0000 in EXCLUDES :OOO0O00O0OOOO0OOO ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOO0O00O0OOOO0OOO #line:3035
			else :OOO0O00O0OOOO0OOO ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOO0O00O0OOOO0OOO #line:3036
			addFile (' %s'%OOO0O00O0OOOO0OOO ,'removedata',OO00OOOOO000O0000 ,icon =OOO0OO0OOOOOO0OOO ,fanart =O0OOO0OO00OOO0O0O ,themeit =THEME2 )#line:3037
	else :#line:3038
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3039
	setView ('files','viewType')#line:3040
def enableAddons ():#line:3042
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3043
	OOOO00OO00O0OOO00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3044
	OO0O0OO00000000OO =0 #line:3045
	for OO00OOOO0O00O0O0O in sorted (OOOO00OO00O0OOO00 ,key =lambda O000OO0OO00OO000O :O000OO0OO00OO000O ):#line:3046
		OOO0OOO0000O0OO00 =os .path .split (OO00OOOO0O00O0O0O [:-1 ])[1 ]#line:3047
		if OOO0OOO0000O0OO00 in EXCLUDES :continue #line:3048
		if OOO0OOO0000O0OO00 in DEFAULTPLUGINS :continue #line:3049
		OO000OO0O0O0OOO0O =os .path .join (OO00OOOO0O00O0O0O ,'addon.xml')#line:3050
		if os .path .exists (OO000OO0O0O0OOO0O ):#line:3051
			OO0O0OO00000000OO +=1 #line:3052
			OOOO00OO00O0OOO00 =OO00OOOO0O00O0O0O .replace (ADDONS ,'')[1 :-1 ]#line:3053
			O0OO0OO0OOOO00O0O =open (OO000OO0O0O0OOO0O )#line:3054
			O0OO0OOOO00OOO00O =O0OO0OO0OOOO00O0O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3055
			O00OOOO0OOO00O00O =wiz .parseDOM (O0OO0OOOO00OOO00O ,'addon',ret ='id')#line:3056
			OO0O0OO0OO0O00O0O =wiz .parseDOM (O0OO0OOOO00OOO00O ,'addon',ret ='name')#line:3057
			try :#line:3058
				O000000OOO0OO00O0 =O00OOOO0OOO00O00O [0 ]#line:3059
				OOOOO00O00OO00O0O =OO0O0OO0OO0O00O0O [0 ]#line:3060
			except :#line:3061
				continue #line:3062
			try :#line:3063
				O0O00OOO0OOOOO0O0 =xbmcaddon .Addon (id =O000000OOO0OO00O0 )#line:3064
				OO0O00OOOO00OO0O0 ="[COLOR green][Enabled][/COLOR]"#line:3065
				OO0O00OOO0OO0O00O ="false"#line:3066
			except :#line:3067
				OO0O00OOOO00OO0O0 ="[COLOR red][Disabled][/COLOR]"#line:3068
				OO0O00OOO0OO0O00O ="true"#line:3069
				pass #line:3070
			O0OOO0OOO00000OOO =os .path .join (OO00OOOO0O00O0O0O ,'icon.png')if os .path .exists (os .path .join (OO00OOOO0O00O0O0O ,'icon.png'))else ICON #line:3071
			O000OO00OO00O0OO0 =os .path .join (OO00OOOO0O00O0O0O ,'fanart.jpg')if os .path .exists (os .path .join (OO00OOOO0O00O0O0O ,'fanart.jpg'))else FANART #line:3072
			addFile ("%s %s"%(OO0O00OOOO00OO0O0 ,OOOOO00O00OO00O0O ),'toggleaddon',OOOO00OO00O0OOO00 ,OO0O00OOO0OO0O00O ,icon =O0OOO0OOO00000OOO ,fanart =O000OO00OO00O0OO0 )#line:3073
			O0OO0OO0OOOO00O0O .close ()#line:3074
	if OO0O0OO00000000OO ==0 :#line:3075
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3076
	setView ('files','viewType')#line:3077
def changeFeq ():#line:3079
	OOO00OOOOO000O0OO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3080
	O00O0OOOOO0O0O00O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOO00OOOOO000O0OO )#line:3081
	if not O00O0OOOOO0O0O00O ==-1 :#line:3082
		wiz .setS ('autocleanfeq',str (O00O0OOOOO0O0O00O ))#line:3083
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOO00OOOOO000O0OO [O00O0OOOOO0O0O00O ]))#line:3084
def developer ():#line:3086
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3087
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3088
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3089
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3090
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3091
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3092
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3093
	setView ('files','viewType')#line:3095
def download (OOOO0O00O0000O00O ,OO00OO00OOO00OOO0 ):#line:3100
  OOOOO000OOOO0OOOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3101
  O0000OOOOOO0O0OO0 =xbmcgui .DialogProgress ()#line:3102
  O0000OOOOOO0O0OO0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3103
  OOOO0O0OOO00OOOOO =os .path .join (OOOOO000OOOO0OOOO ,'isr.zip')#line:3104
  OO0O0O0O0OO00O00O =urllib2 .Request (OOOO0O00O0000O00O )#line:3105
  O0OO000O0O00000OO =urllib2 .urlopen (OO0O0O0O0OO00O00O )#line:3106
  OOO00OOO0O0O00OO0 =xbmcgui .DialogProgress ()#line:3108
  OOO00OOO0O0O00OO0 .create ("Downloading","Downloading "+name )#line:3109
  OOO00OOO0O0O00OO0 .update (0 )#line:3110
  OOO0OO000O00OOOO0 =OO00OO00OOO00OOO0 #line:3111
  O0O0O00OO0O0OOOOO =open (OOOO0O0OOO00OOOOO ,'wb')#line:3112
  try :#line:3114
    OOO0000O00OO000OO =O0OO000O0O00000OO .info ().getheader ('Content-Length').strip ()#line:3115
    O0O0O000O0OOO00O0 =True #line:3116
  except AttributeError :#line:3117
        O0O0O000O0OOO00O0 =False #line:3118
  if O0O0O000O0OOO00O0 :#line:3120
        OOO0000O00OO000OO =int (OOO0000O00OO000OO )#line:3121
  OO0000OO00O0OOO0O =0 #line:3123
  O0OO0O0O00OO00O0O =time .time ()#line:3124
  while True :#line:3125
        O0000OO000O000OO0 =O0OO000O0O00000OO .read (8192 )#line:3126
        if not O0000OO000O000OO0 :#line:3127
            sys .stdout .write ('\n')#line:3128
            break #line:3129
        OO0000OO00O0OOO0O +=len (O0000OO000O000OO0 )#line:3131
        O0O0O00OO0O0OOOOO .write (O0000OO000O000OO0 )#line:3132
        if not O0O0O000O0OOO00O0 :#line:3134
            OOO0000O00OO000OO =OO0000OO00O0OOO0O #line:3135
        if OOO00OOO0O0O00OO0 .iscanceled ():#line:3136
           OOO00OOO0O0O00OO0 .close ()#line:3137
           try :#line:3138
            os .remove (OOOO0O0OOO00OOOOO )#line:3139
           except :#line:3140
            pass #line:3141
           break #line:3142
        O00O0OOO0O0O00OO0 =float (OO0000OO00O0OOO0O )/OOO0000O00OO000OO #line:3143
        O00O0OOO0O0O00OO0 =round (O00O0OOO0O0O00OO0 *100 ,2 )#line:3144
        OO00000O0OO0O00O0 =OO0000OO00O0OOO0O /(1024 *1024 )#line:3145
        O0O0OO0O0OOOOO0O0 =OOO0000O00OO000OO /(1024 *1024 )#line:3146
        O0OOOO0000O0O0OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00000O0OO0O00O0 ,'teal',O0O0OO0O0OOOOO0O0 )#line:3147
        if (time .time ()-O0OO0O0O00OO00O0O )>0 :#line:3148
          OO0O0000O00O00000 =OO0000OO00O0OOO0O /(time .time ()-O0OO0O0O00OO00O0O )#line:3149
          OO0O0000O00O00000 =OO0O0000O00O00000 /1024 #line:3150
        else :#line:3151
         OO0O0000O00O00000 =0 #line:3152
        OOO0OOOOOOO0OO0O0 ='KB'#line:3153
        if OO0O0000O00O00000 >=1024 :#line:3154
           OO0O0000O00O00000 =OO0O0000O00O00000 /1024 #line:3155
           OOO0OOOOOOO0OO0O0 ='MB'#line:3156
        if OO0O0000O00O00000 >0 and not O00O0OOO0O0O00OO0 ==100 :#line:3157
            OO0OOO0000O0OO0OO =(OOO0000O00OO000OO -OO0000OO00O0OOO0O )/OO0O0000O00O00000 #line:3158
        else :#line:3159
            OO0OOO0000O0OO0OO =0 #line:3160
        OOOO0O00O00O000OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O0000O00O00000 ,OOO0OOOOOOO0OO0O0 )#line:3161
        OOO00OOO0O0O00OO0 .update (int (O00O0OOO0O0O00OO0 ),"Downloading "+name ,O0OOOO0000O0O0OO0 ,OOOO0O00O00O000OO )#line:3163
  OO000O0O0OOO0O0OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3166
  O0O0O00OO0O0OOOOO .close ()#line:3168
  extract (OOOO0O0OOO00OOOOO ,OO000O0O0OOO0O0OO ,OOO00OOO0O0O00OO0 )#line:3170
  if os .path .exists (OO000O0O0OOO0O0OO +'/scakemyer-script.quasar.burst'):#line:3171
    if os .path .exists (OO000O0O0OOO0O0OO +'/script.quasar.burst'):#line:3172
     shutil .rmtree (OO000O0O0OOO0O0OO +'/script.quasar.burst',ignore_errors =False )#line:3173
    os .rename (OO000O0O0OOO0O0OO +'/scakemyer-script.quasar.burst',OO000O0O0OOO0O0OO +'/script.quasar.burst')#line:3174
  if os .path .exists (OO000O0O0OOO0O0OO +'/plugin.video.kmediatorrent-master'):#line:3176
    if os .path .exists (OO000O0O0OOO0O0OO +'/plugin.video.kmediatorrent'):#line:3177
     shutil .rmtree (OO000O0O0OOO0O0OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3178
    os .rename (OO000O0O0OOO0O0OO +'/plugin.video.kmediatorrent-master',OO000O0O0OOO0O0OO +'/plugin.video.kmediatorrent')#line:3179
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3180
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3181
  try :#line:3182
    os .remove (OOOO0O0OOO00OOOOO )#line:3183
  except :#line:3184
    pass #line:3185
  OOO00OOO0O0O00OO0 .close ()#line:3186
def dis_or_enable_addon (OO0O0OO0O000OOO00 ,O00O000O0O0OO00O0 ,enable ="true"):#line:3187
    import json #line:3188
    OOOOO0O00OO00O000 ='"%s"'%OO0O0OO0O000OOO00 #line:3189
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OO0O000OOO00 )and enable =="true":#line:3190
        logging .warning ('already Enabled')#line:3191
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O0OO0O000OOO00 )#line:3192
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OO0O000OOO00 )and enable =="false":#line:3193
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O0OO0O000OOO00 )#line:3194
    else :#line:3195
        O0OOO0O0O000000O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOOOO0O00OO00O000 ,enable )#line:3196
        O00OOOO000000OOO0 =xbmc .executeJSONRPC (O0OOO0O0O000000O0 )#line:3197
        OO00O00O0O0000OO0 =json .loads (O00OOOO000000OOO0 )#line:3198
        if enable =="true":#line:3199
            xbmc .log ("### Enabled %s, response = %s"%(OO0O0OO0O000OOO00 ,OO00O00O0O0000OO0 ))#line:3200
        else :#line:3201
            xbmc .log ("### Disabled %s, response = %s"%(OO0O0OO0O000OOO00 ,OO00O00O0O0000OO0 ))#line:3202
    if O00O000O0O0OO00O0 =='auto':#line:3203
     return True #line:3204
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3205
def chunk_report (O0O0OOOO0O0000O00 ,OOOOOOOOO0O0O00O0 ,OOOO0000O0OO00O0O ):#line:3206
   O0O0OO0OOO00OOO0O =float (O0O0OOOO0O0000O00 )/OOOO0000O0OO00O0O #line:3207
   O0O0OO0OOO00OOO0O =round (O0O0OO0OOO00OOO0O *100 ,2 )#line:3208
   if O0O0OOOO0O0000O00 >=OOOO0000O0OO00O0O :#line:3210
      sys .stdout .write ('\n')#line:3211
def chunk_read (O0OO0O00000O0O0OO ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3213
   import time #line:3214
   OO00O0OO00OOO0O00 =int (filesize )*1000000 #line:3215
   OO0OO00OO000OOO0O =0 #line:3217
   O0OO00000OO00O0O0 =time .time ()#line:3218
   OO0OO0OOOO00000OO =0 #line:3219
   logging .warning ('Downloading')#line:3221
   with open (destination ,"wb")as OOOOO0O00OOOO0OO0 :#line:3222
    while 1 :#line:3223
      OOOO00O0O000000OO =time .time ()-O0OO00000OO00O0O0 #line:3224
      O0OO0O0OOO0000O00 =int (OO0OO0OOOO00000OO *chunk_size )#line:3225
      OOOO0OO0OO00OOOOO =O0OO0O00000O0O0OO .read (chunk_size )#line:3226
      OOOOO0O00OOOO0OO0 .write (OOOO0OO0OO00OOOOO )#line:3227
      OOOOO0O00OOOO0OO0 .flush ()#line:3228
      OO0OO00OO000OOO0O +=len (OOOO0OO0OO00OOOOO )#line:3229
      O0000OOOOO0000O0O =float (OO0OO00OO000OOO0O )/OO00O0OO00OOO0O00 #line:3230
      O0000OOOOO0000O0O =round (O0000OOOOO0000O0O *100 ,2 )#line:3231
      if int (OOOO00O0O000000OO )>0 :#line:3232
        OO00O0OOOO00OOOOO =int (O0OO0O0OOO0000O00 /(1024 *OOOO00O0O000000OO ))#line:3233
      else :#line:3234
         OO00O0OOOO00OOOOO =0 #line:3235
      if OO00O0OOOO00OOOOO >1024 and not O0000OOOOO0000O0O ==100 :#line:3236
          OO00O0OOO00O0OO0O =int (((OO00O0OO00OOO0O00 -O0OO0O0OOO0000O00 )/1024 )/(OO00O0OOOO00OOOOO ))#line:3237
      else :#line:3238
          OO00O0OOO00O0OO0O =0 #line:3239
      if OO00O0OOO00O0OO0O <0 :#line:3240
        OO00O0OOO00O0OO0O =0 #line:3241
      dp .update (int (O0000OOOOO0000O0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0000OOOOO0000O0O ,O0OO0O0OOO0000O00 /(1024 *1024 ),OO00O0OO00OOO0O00 /(1000 *1000 ),OO00O0OOOO00OOOOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO00O0OOO00O0OO0O ,60 ))#line:3242
      if dp .iscanceled ():#line:3243
         dp .close ()#line:3244
         break #line:3245
      if not OOOO0OO0OO00OOOOO :#line:3246
         break #line:3247
      if report_hook :#line:3249
         report_hook (OO0OO00OO000OOO0O ,chunk_size ,OO00O0OO00OOO0O00 )#line:3250
      OO0OO0OOOO00000OO +=1 #line:3251
   logging .warning ('END Downloading')#line:3252
   return OO0OO00OO000OOO0O #line:3253
def googledrive_download (O0O000O0000OOO000 ,O0OOO00000OO00O0O ,OO0000O00OOO0OOO0 ,O0O0OO0O0O0O00O0O ):#line:3255
    O00O00OO000000O00 =[]#line:3259
    O00OO00OOOOOO0OO0 =O0O000O0000OOO000 .split ('=')#line:3260
    O0O000O0000OOO000 =O00OO00OOOOOO0OO0 [len (O00OO00OOOOOO0OO0 )-1 ]#line:3261
    def OO00OOOOOO0O00OOO (OO0OOOO000OOO00O0 ):#line:3263
        for OOOOOOOO000O0O00O in OO0OOOO000OOO00O0 :#line:3265
            logging .warning ('cookie.name')#line:3266
            logging .warning (OOOOOOOO000O0O00O .name )#line:3267
            O0OOO00000O0O0O0O =OOOOOOOO000O0O00O .value #line:3268
            if 'download_warning'in OOOOOOOO000O0O00O .name :#line:3269
                logging .warning (OOOOOOOO000O0O00O .value )#line:3270
                logging .warning ('cookie.value')#line:3271
                return OOOOOOOO000O0O00O .value #line:3272
            return O0OOO00000O0O0O0O #line:3273
        return None #line:3275
    def O0OO00O00O0OO0O00 (O0OO000000000O0O0 ,O0OOO00OOO0OOOO00 ):#line:3277
        O0OOO0OO00O00OO00 =32768 #line:3279
        O00O0OO00OOO000OO =time .time ()#line:3280
        with open (O0OOO00OOO0OOOO00 ,"wb")as OO0O000O0O00O00O0 :#line:3282
            O0O00O000000O0OO0 =1 #line:3283
            O0OOO0O00000O0000 =32768 #line:3284
            try :#line:3285
                O00O000OO0O0O00OO =int (O0OO000000000O0O0 .headers .get ('content-length'))#line:3286
                print ('file total size :',O00O000OO0O0O00OO )#line:3287
            except TypeError :#line:3288
                print ('using dummy length !!!')#line:3289
                O00O000OO0O0O00OO =int (O0O0OO0O0O0O00O0O )*1000000 #line:3290
            for OO0O0OOO000OOO000 in O0OO000000000O0O0 .iter_content (O0OOO0OO00O00OO00 ):#line:3291
                if OO0O0OOO000OOO000 :#line:3292
                    OO0O000O0O00O00O0 .write (OO0O0OOO000OOO000 )#line:3293
                    OO0O000O0O00O00O0 .flush ()#line:3294
                    OOOOOOOOOO000OO0O =time .time ()-O00O0OO00OOO000OO #line:3295
                    O0000O0O00OOO0OO0 =int (O0O00O000000O0OO0 *O0OOO0O00000O0000 )#line:3296
                    if OOOOOOOOOO000OO0O ==0 :#line:3297
                        OOOOOOOOOO000OO0O =0.1 #line:3298
                    OO0O0O0OOOOOOOO00 =int (O0000O0O00OOO0OO0 /(1024 *OOOOOOOOOO000OO0O ))#line:3299
                    OOO0O00OO0OO0O0O0 =int (O0O00O000000O0OO0 *O0OOO0O00000O0000 *100 /O00O000OO0O0O00OO )#line:3300
                    if OO0O0O0OOOOOOOO00 >1024 and not OOO0O00OO0OO0O0O0 ==100 :#line:3301
                      O0000O00OO0O00OOO =int (((O00O000OO0O0O00OO -O0000O0O00OOO0OO0 )/1024 )/(OO0O0O0OOOOOOOO00 ))#line:3302
                    else :#line:3303
                      O0000O00OO0O00OOO =0 #line:3304
                    OO0000O00OOO0OOO0 .update (int (OOO0O00OO0OO0O0O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO0O00OO0OO0O0O0 ,O0000O0O00OOO0OO0 /(1024 *1024 ),O00O000OO0O0O00OO /(1000 *1000 ),OO0O0O0OOOOOOOO00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0000O00OO0O00OOO ,60 ))#line:3306
                    O0O00O000000O0OO0 +=1 #line:3307
                    if OO0000O00OOO0OOO0 .iscanceled ():#line:3308
                     OO0000O00OOO0OOO0 .close ()#line:3309
                     break #line:3310
    OOOO0OOOO00O000OO ="https://docs.google.com/uc?export=download"#line:3311
    import urllib2 #line:3316
    import cookielib #line:3317
    from cookielib import CookieJar #line:3319
    OO0O0OO0O000OO00O =CookieJar ()#line:3321
    O00000OOOOOO0OO0O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO0O0OO0O000OO00O ))#line:3322
    O00O000O000OOOO0O ={'id':O0O000O0000OOO000 }#line:3324
    O00O00000O0OOO000 =urllib .urlencode (O00O000O000OOOO0O )#line:3325
    logging .warning (OOOO0OOOO00O000OO +'&'+O00O00000O0OOO000 )#line:3326
    OO000OO000OO0000O =O00000OOOOOO0OO0O .open (OOOO0OOOO00O000OO +'&'+O00O00000O0OOO000 )#line:3327
    O000OOO000O000O00 =OO000OO000OO0000O .read ()#line:3328
    for O0O0O000O0OOO0OOO in OO0O0OO0O000OO00O :#line:3330
         logging .warning (O0O0O000O0OOO0OOO )#line:3331
    OOO00OO0OO00OO0O0 =OO00OOOOOO0O00OOO (OO0O0OO0O000OO00O )#line:3332
    logging .warning (OOO00OO0OO00OO0O0 )#line:3333
    if OOO00OO0OO00OO0O0 :#line:3334
        OO000O0OO000O0000 ={'id':O0O000O0000OOO000 ,'confirm':OOO00OO0OO00OO0O0 }#line:3335
        O00OO0O0000O0OOOO ={'Access-Control-Allow-Headers':'Content-Length'}#line:3336
        O00O00000O0OOO000 =urllib .urlencode (OO000O0OO000O0000 )#line:3337
        OO000OO000OO0000O =O00000OOOOOO0OO0O .open (OOOO0OOOO00O000OO +'&'+O00O00000O0OOO000 )#line:3338
        chunk_read (OO000OO000OO0000O ,report_hook =chunk_report ,dp =OO0000O00OOO0OOO0 ,destination =O0OOO00000OO00O0O ,filesize =O0O0OO0O0O0O00O0O )#line:3339
    return (O00O00OO000000O00 )#line:3343
def kodi17Fix ():#line:3344
	O0O000000O0O0OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3345
	OOO00000OO0OO0000 =[]#line:3346
	for OOOO0O00000O0OOOO in sorted (O0O000000O0O0OOOO ,key =lambda OO0O00OOOOO0OO0O0 :OO0O00OOOOO0OO0O0 ):#line:3347
		O0O00OO000000OOOO =os .path .join (OOOO0O00000O0OOOO ,'addon.xml')#line:3348
		if os .path .exists (O0O00OO000000OOOO ):#line:3349
			O0O00O0O0000OOOO0 =OOOO0O00000O0OOOO .replace (ADDONS ,'')[1 :-1 ]#line:3350
			OO00O0OO00OOO00O0 =open (O0O00OO000000OOOO )#line:3351
			O0O000O0000OOOOOO =OO00O0OO00OOO00O0 .read ()#line:3352
			OOOO000OO0OO0OO0O =parseDOM (O0O000O0000OOOOOO ,'addon',ret ='id')#line:3353
			OO00O0OO00OOO00O0 .close ()#line:3354
			try :#line:3355
				OO0000O00OO00OO0O =xbmcaddon .Addon (id =OOOO000OO0OO0OO0O [0 ])#line:3356
			except :#line:3357
				try :#line:3358
					log ("%s was disabled"%OOOO000OO0OO0OO0O [0 ],xbmc .LOGDEBUG )#line:3359
					OOO00000OO0OO0000 .append (OOOO000OO0OO0OO0O [0 ])#line:3360
				except :#line:3361
					try :#line:3362
						log ("%s was disabled"%O0O00O0O0000OOOO0 ,xbmc .LOGDEBUG )#line:3363
						OOO00000OO0OO0000 .append (O0O00O0O0000OOOO0 )#line:3364
					except :#line:3365
						if len (OOOO000OO0OO0OO0O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0O00O0O0000OOOO0 ,xbmc .LOGERROR )#line:3366
						else :log ("Unabled to enable: %s"%OOOO0O00000O0OOOO ,xbmc .LOGERROR )#line:3367
	if len (OOO00000OO0OO0000 )>0 :#line:3368
		O0OO0OOOO0OOO00OO =0 #line:3369
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3370
		for OO000OO000O000O0O in OOO00000OO0OO0000 :#line:3371
			O0OO0OOOO0OOO00OO +=1 #line:3372
			O0OOO000O000OO000 =int (percentage (O0OO0OOOO0OOO00OO ,len (OOO00000OO0OO0000 )))#line:3373
			DP .update (O0OOO000O000OO000 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000OO000O000O0O ))#line:3374
			addonDatabase (OO000OO000O000O0O ,1 )#line:3375
			if DP .iscanceled ():break #line:3376
		if DP .iscanceled ():#line:3377
			DP .close ()#line:3378
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3379
			sys .exit ()#line:3380
		DP .close ()#line:3381
	forceUpdate ()#line:3382
def indicator ():#line:3383
       try :#line:3384
          import json #line:3385
          wiz .log ('FRESH MESSAGE')#line:3386
          OO0O0OO0OOOOO0O00 =(ADDON .getSetting ("user"))#line:3387
          O00000OO0OOOOO00O =(ADDON .getSetting ("pass"))#line:3388
          O000OO00OO000OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3389
          O0000OO0O000O000O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3390
          OOO00O0O0OO0000OO =OO0O0OO0OOOOO0O00 #line:3392
          O00OO0O0OOO00OOO0 =O00000OO0OOOOO00O #line:3393
          import socket #line:3394
          O0000OO0O000O000O =urllib2 .urlopen (O000OO00OO000OO00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOO00O0O0OO0000OO +' - '+O00OO0O0OOO00OOO0 ).readlines ()#line:3395
       except :pass #line:3397
def indicatorfastupdate ():#line:3398
       try :#line:3399
          import json #line:3400
          wiz .log ('FRESH MESSAGE')#line:3401
          OO00OOOO0000O0O00 =(ADDON .getSetting ("user"))#line:3402
          O0O0000O0O0OOO00O =(ADDON .getSetting ("pass"))#line:3403
          OO0OO0OO000OOO00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3405
          O00O000O0OOO0OOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3406
          OOOOOOOOOO0OO0OOO =str (json .loads (O00O000O0OOO0OOO0 )['ip'])#line:3407
          O00OOO0O0O0OO0OO0 =OO00OOOO0000O0O00 #line:3408
          O00O00000000O00OO =O0O0000O0O0OOO00O #line:3409
          import socket #line:3410
          O00O000O0OOO0OOO0 =urllib2 .urlopen (OO0OO0OO000OOO00O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00OOO0O0O0OO0OO0 +' - '+O00O00000000O00OO ).readlines ()#line:3411
       except :pass #line:3413
def skinfix18 ():#line:3414
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3415
		OO0OO0000OOO0OO00 =wiz .workingURL (SKINID18DDONXML )#line:3416
		if OO0OO0000OOO0OO00 ==True :#line:3417
			OOO0O0O0O00O0OOO0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3418
			if len (OOO0O0O0O00O0OOO0 )>0 :#line:3419
				OOOO0OOOO0O00OO0O ='%s-%s.zip'%(SKINID18 ,OOO0O0O0O00O0OOO0 [0 ])#line:3420
				O0OOO0O0O000OOOOO =wiz .workingURL (SKIN18ZIPURL +OOOO0OOOO0O00OO0O )#line:3421
				if O0OOO0O0O000OOOOO ==True :#line:3422
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3423
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3424
					OO00O0OO0OOOOO0O0 =os .path .join (PACKAGES ,OOOO0OOOO0O00OO0O )#line:3425
					try :os .remove (OO00O0OO0OOOOO0O0 )#line:3426
					except :pass #line:3427
					downloader .download (SKIN18ZIPURL +OOOO0OOOO0O00OO0O ,OO00O0OO0OOOOO0O0 ,DP )#line:3428
					extract .all (OO00O0OO0OOOOO0O0 ,HOME ,DP )#line:3429
					try :#line:3430
						OO0O0O0000OO000O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3431
						OOOOO0OOO0O0O0000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3432
						os .rename (OO0O0O0000OO000O0 ,OOOOO0OOO0O0O0000 )#line:3433
					except :#line:3434
						pass #line:3435
					try :#line:3436
						OOO000O00OOOO0O0O =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0O0OOO0OO000OOOO =OOO000O00OOOO0O0O .read ();OOO000O00OOOO0O0O .close ()#line:3437
						OO00OOOO0O0O000O0 =wiz .parseDOM (O0O0OOO0OO000OOOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3438
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOOO0O0O000O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3439
					except :#line:3440
						pass #line:3441
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3442
					DP .close ()#line:3443
					xbmc .sleep (500 )#line:3444
					wiz .forceUpdate (True )#line:3445
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3446
				else :#line:3447
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3448
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OOO0O0O000OOOOO ,xbmc .LOGERROR )#line:3449
			else :#line:3450
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3451
		else :#line:3452
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3453
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3454
def skinfix17 ():#line:3455
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3456
		O0OOO0OO00O0O00OO =wiz .workingURL (SKINID17DDONXML )#line:3457
		if O0OOO0OO00O0O00OO ==True :#line:3458
			OO0OO0OOOO00OO00O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3459
			if len (OO0OO0OOOO00OO00O )>0 :#line:3460
				O0OO0O0O0OO0000O0 ='%s-%s.zip'%(SKINID17 ,OO0OO0OOOO00OO00O [0 ])#line:3461
				OO0OO0O0OOOOOO000 =wiz .workingURL (SKIN17ZIPURL +O0OO0O0O0OO0000O0 )#line:3462
				if OO0OO0O0OOOOOO000 ==True :#line:3463
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3464
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3465
					O0000OOOOO00O0O0O =os .path .join (PACKAGES ,O0OO0O0O0OO0000O0 )#line:3466
					try :os .remove (O0000OOOOO00O0O0O )#line:3467
					except :pass #line:3468
					downloader .download (SKIN17ZIPURL +O0OO0O0O0OO0000O0 ,O0000OOOOO00O0O0O ,DP )#line:3469
					extract .all (O0000OOOOO00O0O0O ,HOME ,DP )#line:3470
					try :#line:3471
						O00OOO000OOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3472
						O000OO00O0O000000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3473
						os .rename (O00OOO000OOOO0OO0 ,O000OO00O0O000000 )#line:3474
					except :#line:3475
						pass #line:3476
					try :#line:3477
						OOOOO0000OO0OOO0O =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OOOOOO00OO0O0OO0O =OOOOO0000OO0OOO0O .read ();OOOOO0000OO0OOO0O .close ()#line:3478
						O000O000O00OOOOO0 =wiz .parseDOM (OOOOOO00OO0O0OO0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3479
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O000O00OOOOO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3480
					except :#line:3481
						pass #line:3482
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3483
					DP .close ()#line:3484
					xbmc .sleep (500 )#line:3485
					wiz .forceUpdate (True )#line:3486
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3487
				else :#line:3488
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3489
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0OO0O0OOOOOO000 ,xbmc .LOGERROR )#line:3490
			else :#line:3491
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3492
		else :#line:3493
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3494
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3495
def fix17update ():#line:3496
	if KODIV >=17 and KODIV <18 :#line:3497
		wiz .kodi17Fix ()#line:3498
		xbmc .sleep (4000 )#line:3499
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3500
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3501
		fixfont ()#line:3502
		O0000O000O000OOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3503
		try :#line:3505
			O00OOO0OOOO0O00O0 =open (O0000O000O000OOOO ,'r')#line:3506
			O0O0OOOO0OO000OO0 =O00OOO0OOOO0O00O0 .read ()#line:3507
			O00OOO0OOOO0O00O0 .close ()#line:3508
			O0O00O00O0OOOOO00 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3509
			OO00O000OOO00O000 =re .compile (O0O00O00O0OOOOO00 ).findall (O0O0OOOO0OO000OO0 )[0 ]#line:3510
			O00OOO0OOOO0O00O0 =open (O0000O000O000OOOO ,'w')#line:3511
			O00OOO0OOOO0O00O0 .write (O0O0OOOO0OO000OO0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO00O000OOO00O000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3512
			O00OOO0OOOO0O00O0 .close ()#line:3513
		except :#line:3514
				pass #line:3515
		wiz .kodi17Fix ()#line:3516
		O0000O000O000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3517
		try :#line:3518
			O00OOO0OOOO0O00O0 =open (O0000O000O000OOOO ,'r')#line:3519
			O0O0OOOO0OO000OO0 =O00OOO0OOOO0O00O0 .read ()#line:3520
			O00OOO0OOOO0O00O0 .close ()#line:3521
			O0O00O00O0OOOOO00 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3522
			OO00O000OOO00O000 =re .compile (O0O00O00O0OOOOO00 ).findall (O0O0OOOO0OO000OO0 )[0 ]#line:3523
			O00OOO0OOOO0O00O0 =open (O0000O000O000OOOO ,'w')#line:3524
			O00OOO0OOOO0O00O0 .write (O0O0OOOO0OO000OO0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO00O000OOO00O000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3525
			O00OOO0OOOO0O00O0 .close ()#line:3526
		except :#line:3527
				pass #line:3528
		swapSkins ('skin.Premium.mod')#line:3529
def fix18update ():#line:3531
	if KODIV >=18 :#line:3532
		xbmc .sleep (4000 )#line:3533
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3534
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3535
		fixfont ()#line:3536
		O0OOO000OO00OO00O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3537
		try :#line:3538
			O0O00OO0OOO00OO0O =open (O0OOO000OO00OO00O ,'r')#line:3539
			O00O0OO0OOO0O0OOO =O0O00OO0OOO00OO0O .read ()#line:3540
			O0O00OO0OOO00OO0O .close ()#line:3541
			OOOO00O0O0000000O ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3542
			OOO0OOO0O00OO00OO =re .compile (OOOO00O0O0000000O ).findall (O00O0OO0OOO0O0OOO )[0 ]#line:3543
			O0O00OO0OOO00OO0O =open (O0OOO000OO00OO00O ,'w')#line:3544
			O0O00OO0OOO00OO0O .write (O00O0OO0OOO0O0OOO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOO0OOO0O00OO00OO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3545
			O0O00OO0OOO00OO0O .close ()#line:3546
		except :#line:3547
				pass #line:3548
		wiz .kodi17Fix ()#line:3549
		O0OOO000OO00OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3550
		try :#line:3551
			O0O00OO0OOO00OO0O =open (O0OOO000OO00OO00O ,'r')#line:3552
			O00O0OO0OOO0O0OOO =O0O00OO0OOO00OO0O .read ()#line:3553
			O0O00OO0OOO00OO0O .close ()#line:3554
			OOOO00O0O0000000O ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3555
			OOO0OOO0O00OO00OO =re .compile (OOOO00O0O0000000O ).findall (O00O0OO0OOO0O0OOO )[0 ]#line:3556
			O0O00OO0OOO00OO0O =open (O0OOO000OO00OO00O ,'w')#line:3557
			O0O00OO0OOO00OO0O .write (O00O0OO0OOO0O0OOO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOO0OOO0O00OO00OO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3558
			O0O00OO0OOO00OO0O .close ()#line:3559
		except :#line:3560
				pass #line:3561
		swapSkins ('skin.Premium.mod')#line:3562
def buildWizard (O00OOO0O000O000OO ,O0O000O00OO0OOOO0 ,theme =None ,over =False ):#line:3565
	if over ==False :#line:3566
		O0OO0O000O0OO0OO0 =wiz .checkBuild (O00OOO0O000O000OO ,'url')#line:3567
		if O0OO0O000O0OO0OO0 ==False :#line:3569
			xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','אנא המתן')))#line:3573
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3574
			return #line:3575
		O00OO0O00OO0OO000 =wiz .workingURL (O0OO0O000O0OO0OO0 )#line:3576
		if O00OO0O00OO0OO000 ==False :#line:3577
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00OO0O00OO0OO000 ))#line:3578
			return #line:3579
	if O0O000O00OO0OOOO0 =='gui':#line:3580
		if O00OOO0O000O000OO ==BUILDNAME :#line:3581
			if over ==True :OO0O000OOO000OOO0 =1 #line:3582
			else :OO0O000OOO000OOO0 =1 #line:3583
		else :#line:3584
			OO0O000OOO000OOO0 =1 #line:3585
		if OO0O000OOO000OOO0 :#line:3586
			remove_addons ()#line:3587
			remove_addons2 ()#line:3588
			OOOOOOOO0O0000O0O =wiz .checkBuild (O00OOO0O000O000OO ,'gui')#line:3589
			OOOOO0O0O0OOO00OO =O00OOO0O000O000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3590
			if not wiz .workingURL (OOOOOOOO0O0000O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3591
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3592
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O000O000OO ),'','אנא המתן')#line:3593
			O00O00OOOOO0O0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOO0O0O0OOO00OO )#line:3594
			try :os .remove (O00O00OOOOO0O0OOO )#line:3595
			except :pass #line:3596
			logging .warning (OOOOOOOO0O0000O0O )#line:3597
			if 'google'in OOOOOOOO0O0000O0O :#line:3598
			   O0O000O0OO00O0000 =googledrive_download (OOOOOOOO0O0000O0O ,O00O00OOOOO0O0OOO ,DP ,wiz .checkBuild (O00OOO0O000O000OO ,'filesize'))#line:3599
			else :#line:3602
			  downloader .download (OOOOOOOO0O0000O0O ,O00O00OOOOO0O0OOO ,DP )#line:3603
			xbmc .sleep (100 )#line:3604
			OOO00OOO0O00OOOO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O000O000OO )#line:3605
			DP .update (0 ,OOO00OOO0O00OOOO0 ,'','אנא המתן')#line:3606
			extract .all (O00O00OOOOO0O0OOO ,HOME ,DP ,title =OOO00OOO0O00OOOO0 )#line:3607
			DP .close ()#line:3608
			wiz .defaultSkin ()#line:3609
			wiz .lookandFeelData ('save')#line:3610
			wiz .kodi17Fix ()#line:3611
			xbmc .executebuiltin ("ReloadSkin()")#line:3612
			if INSTALLMETHOD ==1 :O0OOOOOOO0OOOO0OO =1 #line:3613
			elif INSTALLMETHOD ==2 :O0OOOOOOO0OOOO0OO =0 #line:3614
			else :DP .close ()#line:3615
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3616
			indicatorfastupdate ()#line:3617
		else :#line:3619
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3620
	if O0O000O00OO0OOOO0 =='gui2':#line:3621
		if O00OOO0O000O000OO ==BUILDNAME :#line:3622
			if over ==True :OO0O000OOO000OOO0 =1 #line:3623
			else :OO0O000OOO000OOO0 =1 #line:3624
		else :#line:3625
			OO0O000OOO000OOO0 =1 #line:3626
		if OO0O000OOO000OOO0 :#line:3627
			remove_addons ()#line:3628
			remove_addons2 ()#line:3629
			OOOOOOOO0O0000O0O =wiz .checkBuild (O00OOO0O000O000OO ,'gui')#line:3630
			OOOOO0O0O0OOO00OO =O00OOO0O000O000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3631
			if not wiz .workingURL (OOOOOOOO0O0000O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3632
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3633
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O000O000OO ),'','אנא המתן')#line:3634
			O00O00OOOOO0O0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOO0O0O0OOO00OO )#line:3635
			try :os .remove (O00O00OOOOO0O0OOO )#line:3636
			except :pass #line:3637
			logging .warning (OOOOOOOO0O0000O0O )#line:3638
			if 'google'in OOOOOOOO0O0000O0O :#line:3639
			   O0O000O0OO00O0000 =googledrive_download (OOOOOOOO0O0000O0O ,O00O00OOOOO0O0OOO ,DP ,wiz .checkBuild (O00OOO0O000O000OO ,'filesize'))#line:3640
			else :#line:3643
			  downloader .download (OOOOOOOO0O0000O0O ,O00O00OOOOO0O0OOO ,DP )#line:3644
			xbmc .sleep (100 )#line:3645
			OOO00OOO0O00OOOO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O000O000OO )#line:3646
			DP .update (0 ,OOO00OOO0O00OOOO0 ,'','אנא המתן')#line:3647
			extract .all (O00O00OOOOO0O0OOO ,HOME ,DP ,title =OOO00OOO0O00OOOO0 )#line:3648
			DP .close ()#line:3649
			wiz .defaultSkin ()#line:3650
			wiz .lookandFeelData ('save')#line:3651
			if INSTALLMETHOD ==1 :O0OOOOOOO0OOOO0OO =1 #line:3654
			elif INSTALLMETHOD ==2 :O0OOOOOOO0OOOO0OO =0 #line:3655
			else :DP .close ()#line:3656
		else :#line:3658
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3659
	elif O0O000O00OO0OOOO0 =='fresh':#line:3660
		freshStart (O00OOO0O000O000OO )#line:3661
	elif O0O000O00OO0OOOO0 =='normal':#line:3662
		if url =='normal':#line:3663
			if KEEPTRAKT =='true':#line:3664
				traktit .autoUpdate ('all')#line:3665
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3666
			if KEEPREAL =='true':#line:3667
				debridit .autoUpdate ('all')#line:3668
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3669
			if KEEPLOGIN =='true':#line:3670
				loginit .autoUpdate ('all')#line:3671
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3672
		O0OO000OO0O00OO0O =int (KODIV );O0OOO00OOO0OOOO0O =int (float (wiz .checkBuild (O00OOO0O000O000OO ,'kodi')))#line:3673
		if not O0OO000OO0O00OO0O ==O0OOO00OOO0OOOO0O :#line:3674
			if O0OO000OO0O00OO0O ==16 and O0OOO00OOO0OOOO0O <=15 :O0000O0OOOO00O000 =False #line:3675
			else :O0000O0OOOO00O000 =True #line:3676
		else :O0000O0OOOO00O000 =False #line:3677
		if O0000O0OOOO00O000 ==True :#line:3678
			O0O0OO0O000OO0OO0 =1 #line:3679
		else :#line:3680
			if not over ==False :O0O0OO0O000OO0OO0 =1 #line:3681
			else :O0O0OO0O000OO0OO0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3682
		if O0O0OO0O000OO0OO0 :#line:3683
			wiz .clearS ('build')#line:3684
			OOOOOOOO0O0000O0O =wiz .checkBuild (O00OOO0O000O000OO ,'url')#line:3685
			OOOOO0O0O0OOO00OO =O00OOO0O000O000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3686
			if not wiz .workingURL (OOOOOOOO0O0000O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3687
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3688
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O000O000OO ,wiz .checkBuild (O00OOO0O000O000OO ,'version')),'','אנא המתן')#line:3689
			O00O00OOOOO0O0OOO =os .path .join (PACKAGES ,'%s.zip'%OOOOO0O0O0OOO00OO )#line:3690
			try :os .remove (O00O00OOOOO0O0OOO )#line:3691
			except :pass #line:3692
			logging .warning (OOOOOOOO0O0000O0O )#line:3693
			if 'google'in OOOOOOOO0O0000O0O :#line:3694
			   O0O000O0OO00O0000 =googledrive_download (OOOOOOOO0O0000O0O ,O00O00OOOOO0O0OOO ,DP ,wiz .checkBuild (O00OOO0O000O000OO ,'filesize'))#line:3695
			else :#line:3698
			  downloader .download (OOOOOOOO0O0000O0O ,O00O00OOOOO0O0OOO ,DP )#line:3699
			xbmc .sleep (1000 )#line:3700
			OOO00OOO0O00OOOO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O000O000OO ,wiz .checkBuild (O00OOO0O000O000OO ,'version'))#line:3701
			DP .update (0 ,OOO00OOO0O00OOOO0 ,'','Please Wait')#line:3702
			OOO0O00OO0OOOO00O ,O000O00O000O0O00O ,OOOO0O00O0OO0O00O =extract .all (O00O00OOOOO0O0OOO ,HOME ,DP ,title =OOO00OOO0O00OOOO0 )#line:3703
			if int (float (OOO0O00OO0OOOO00O ))>0 :#line:3704
				wiz .fixmetas ()#line:3705
				wiz .lookandFeelData ('save')#line:3706
				wiz .defaultSkin ()#line:3707
				wiz .setS ('buildname',O00OOO0O000O000OO )#line:3709
				wiz .setS ('buildversion',wiz .checkBuild (O00OOO0O000O000OO ,'version'))#line:3710
				wiz .setS ('buildtheme','')#line:3711
				wiz .setS ('latestversion',wiz .checkBuild (O00OOO0O000O000OO ,'version'))#line:3712
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3713
				wiz .setS ('installed','true')#line:3714
				wiz .setS ('extract',str (OOO0O00OO0OOOO00O ))#line:3715
				wiz .setS ('errors',str (O000O00O000O0O00O ))#line:3716
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO0O00OO0OOOO00O ,O000O00O000O0O00O ))#line:3717
				OOOOO00O000O0OO00 =(ADDON .getSetting ("gaiaseren"))#line:3719
				if OOOOO00O000O0OO00 =='true':#line:3720
					wiz .kodi17Fix ()#line:3721
				fastupdatefirstbuild (NOTEID )#line:3722
				skin_homeselect ()#line:3723
				skin_lower ()#line:3724
				rdbuildinstall ()#line:3725
				try :gaiaserenaddon ()#line:3727
				except :pass #line:3728
				adults18 ()#line:3729
				skinfix18 ()#line:3730
				try :os .remove (O00O00OOOOO0O0OOO )#line:3732
				except :pass #line:3733
				if OOOOO00O000O0OO00 =='true':#line:3735
					wiz .kodi17Fix ()#line:3736
				if int (float (O000O00O000O0O00O ))>0 :#line:3738
					OO0O000OOO000OOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O000O000OO ,wiz .checkBuild (O00OOO0O000O000OO ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO0O00OO0OOOO00O ,'%',COLOR1 ,O000O00O000O0O00O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3739
					if OO0O000OOO000OOO0 :#line:3740
						if isinstance (O000O00O000O0O00O ,unicode ):#line:3741
							OOOO0O00O0OO0O00O =OOOO0O00O0OO0O00O .encode ('utf-8')#line:3742
						wiz .TextBox (ADDONTITLE ,OOOO0O00O0OO0O00O )#line:3743
				DP .close ()#line:3744
				OOOO000O000O0OO00 =wiz .themeCount (O00OOO0O000O000OO )#line:3745
				indicator ()#line:3746
				if not OOOO000O000O0OO00 ==False :#line:3747
					buildWizard (O00OOO0O000O000OO ,'theme')#line:3748
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3749
				if INSTALLMETHOD ==1 :O0OOOOOOO0OOOO0OO =1 #line:3750
				elif INSTALLMETHOD ==2 :O0OOOOOOO0OOOO0OO =0 #line:3751
				else :resetkodi ()#line:3752
				if O0OOOOOOO0OOOO0OO ==1 :wiz .reloadFix ()#line:3754
				else :wiz .killxbmc (True )#line:3755
			else :#line:3756
				if isinstance (O000O00O000O0O00O ,unicode ):#line:3757
					OOOO0O00O0OO0O00O =OOOO0O00O0OO0O00O .encode ('utf-8')#line:3758
				OOOOO00O00OO0O0OO =open (O00O00OOOOO0O0OOO ,'r')#line:3759
				OOO000OOOOOOOOO00 =OOOOO00O00OO0O0OO .read ()#line:3760
				O00OO000O0OOO0000 =''#line:3761
				for OOOO00O00OOO000O0 in O0O000O0OO00O0000 :#line:3762
				  O00OO000O0OOO0000 ='key: '+O00OO000O0OOO0000 +'\n'+OOOO00O00OOO000O0 #line:3763
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OOOO0O00O0OO0O00O +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O00OO000O0OOO0000 )#line:3764
		else :#line:3765
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3766
	elif O0O000O00OO0OOOO0 =='theme':#line:3767
		if theme ==None :#line:3768
			OOOO000O000O0OO00 =wiz .checkBuild (O00OOO0O000O000OO ,'theme')#line:3769
			OOOO0000OO00OO000 =[]#line:3770
			if not OOOO000O000O0OO00 =='http://'and wiz .workingURL (OOOO000O000O0OO00 )==True :#line:3771
				OOOO0000OO00OO000 =wiz .themeCount (O00OOO0O000O000OO ,False )#line:3772
				if len (OOOO0000OO00OO000 )>0 :#line:3773
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O00OOO0O000O000OO ,COLOR1 ,len (OOOO0000OO00OO000 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3774
						wiz .log ("Theme List: %s "%str (OOOO0000OO00OO000 ))#line:3775
						OO00O0OO0000O0O0O =DIALOG .select (ADDONTITLE ,OOOO0000OO00OO000 )#line:3776
						wiz .log ("Theme install selected: %s"%OO00O0OO0000O0O0O )#line:3777
						if not OO00O0OO0000O0O0O ==-1 :theme =OOOO0000OO00OO000 [OO00O0OO0000O0O0O ];OO0OOO0O0O0O000OO =True #line:3778
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3779
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3780
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3781
		else :OO0OOO0O0O0O000OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O00OOO0O000O000OO ,wiz .checkBuild (O00OOO0O000O000OO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3782
		if OO0OOO0O0O0O000OO :#line:3783
			O0OO00O00OO0O0000 =wiz .checkTheme (O00OOO0O000O000OO ,theme ,'url')#line:3784
			OOOOO0O0O0OOO00OO =O00OOO0O000O000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3785
			if not wiz .workingURL (O0OO00O00OO0O0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3786
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3787
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3788
			O00O00OOOOO0O0OOO =os .path .join (PACKAGES ,'%s.zip'%OOOOO0O0O0OOO00OO )#line:3789
			try :os .remove (O00O00OOOOO0O0OOO )#line:3790
			except :pass #line:3791
			downloader .download (O0OO00O00OO0O0000 ,O00O00OOOOO0O0OOO ,DP )#line:3792
			xbmc .sleep (1000 )#line:3793
			DP .update (0 ,"","Installing %s "%O00OOO0O000O000OO )#line:3794
			O00OO0OOOOO00O000 =False #line:3795
			if url not in ["fresh","normal"]:#line:3796
				O00OO0OOOOO00O000 =testTheme (O00O00OOOOO0O0OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3797
				OOO00OO00000OOOO0 =testGui (O00O00OOOOO0O0OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3798
				if O00OO0OOOOO00O000 ==True :#line:3799
					wiz .lookandFeelData ('save')#line:3800
					O00O00O0O0O00OO00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3801
					O0O0O00000OOOO00O =xbmc .getSkinDir ()#line:3802
					skinSwitch .swapSkins (O00O00O0O0O00OO00 )#line:3804
					OO0O0OOO000000OOO =0 #line:3805
					xbmc .sleep (1000 )#line:3806
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OOO000000OOO <150 :#line:3807
						OO0O0OOO000000OOO +=1 #line:3808
						xbmc .sleep (1000 )#line:3809
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3810
						wiz .ebi ('SendClick(11)')#line:3811
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3812
					xbmc .sleep (1000 )#line:3813
			OOO00OOO0O00OOOO0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3814
			DP .update (0 ,OOO00OOO0O00OOOO0 ,'','אנא המתן')#line:3815
			OOO0O00OO0OOOO00O ,O000O00O000O0O00O ,OOOO0O00O0OO0O00O =extract .all (O00O00OOOOO0O0OOO ,HOME ,DP ,title =OOO00OOO0O00OOOO0 )#line:3816
			wiz .setS ('buildtheme',theme )#line:3817
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOO0O00OO0OOOO00O ,O000O00O000O0O00O ))#line:3818
			DP .close ()#line:3819
			if url not in ["fresh","normal"]:#line:3820
				wiz .forceUpdate ()#line:3821
				if KODIV >=17 :wiz .kodi17Fix ()#line:3822
				if OOO00OO00000OOOO0 ==True :#line:3823
					wiz .lookandFeelData ('save')#line:3824
					wiz .defaultSkin ()#line:3825
					O0O0O00000OOOO00O =wiz .getS ('defaultskin')#line:3826
					skinSwitch .swapSkins (O0O0O00000OOOO00O )#line:3827
					OO0O0OOO000000OOO =0 #line:3828
					xbmc .sleep (1000 )#line:3829
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OOO000000OOO <150 :#line:3830
						OO0O0OOO000000OOO +=1 #line:3831
						xbmc .sleep (1000 )#line:3832
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3834
						wiz .ebi ('SendClick(11)')#line:3835
					wiz .lookandFeelData ('restore')#line:3836
				elif O00OO0OOOOO00O000 ==True :#line:3837
					skinSwitch .swapSkins (O0O0O00000OOOO00O )#line:3838
					OO0O0OOO000000OOO =0 #line:3839
					xbmc .sleep (1000 )#line:3840
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OOO000000OOO <150 :#line:3841
						OO0O0OOO000000OOO +=1 #line:3842
						xbmc .sleep (1000 )#line:3843
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3845
						wiz .ebi ('SendClick(11)')#line:3846
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3847
					wiz .lookandFeelData ('restore')#line:3848
				else :#line:3849
					wiz .ebi ("ReloadSkin()")#line:3850
					xbmc .sleep (1000 )#line:3851
					wiz .ebi ("Container.Refresh")#line:3852
		else :#line:3853
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3854
def skin_homeselect ():#line:3858
	try :#line:3860
		O00000OOOO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3861
		O00O0O00O0OOOOOOO =open (O00000OOOO000000O ,'r')#line:3863
		O00000OO00O00OOOO =O00O0O00O0OOOOOOO .read ()#line:3864
		O00O0O00O0OOOOOOO .close ()#line:3865
		O000OO0000OOO00O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:3866
		OO0O00OO0OOO0O00O =re .compile (O000OO0000OOO00O0 ).findall (O00000OO00O00OOOO )[0 ]#line:3867
		O00O0O00O0OOOOOOO =open (O00000OOOO000000O ,'w')#line:3868
		O00O0O00O0OOOOOOO .write (O00000OO00O00OOOO .replace ('<setting id="HomeS" type="string%s/setting>'%OO0O00OO0OOO0O00O ,'<setting id="HomeS" type="string"></setting>'))#line:3869
		O00O0O00O0OOOOOOO .close ()#line:3870
	except :#line:3871
		pass #line:3872
def skin_lower ():#line:3875
	OOO00O000OOO0O0OO =(ADDON .getSetting ("lower"))#line:3876
	if OOO00O000OOO0O0OO =='true':#line:3877
		try :#line:3880
			OO00OO000OO0O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3881
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'r')#line:3883
			O00O00O0OO0OO00OO =O0OO0O0O0000O0OOO .read ()#line:3884
			O0OO0O0O0000O0OOO .close ()#line:3885
			OO000OOO0OO00OO0O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3886
			O00OOOOO0OOOO0O0O =re .compile (OO000OOO0OO00OO0O ).findall (O00O00O0OO0OO00OO )[0 ]#line:3887
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'w')#line:3888
			O0OO0O0O0000O0OOO .write (O00O00O0OO0OO00OO .replace ('<setting id="none_widget" type="bool%s/setting>'%O00OOOOO0OOOO0O0O ,'<setting id="none_widget" type="bool">true</setting>'))#line:3889
			O0OO0O0O0000O0OOO .close ()#line:3890
			OO00OO000OO0O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3892
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'r')#line:3894
			O00O00O0OO0OO00OO =O0OO0O0O0000O0OOO .read ()#line:3895
			O0OO0O0O0000O0OOO .close ()#line:3896
			OO000OOO0OO00OO0O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3897
			O00OOOOO0OOOO0O0O =re .compile (OO000OOO0OO00OO0O ).findall (O00O00O0OO0OO00OO )[0 ]#line:3898
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'w')#line:3899
			O0OO0O0O0000O0OOO .write (O00O00O0OO0OO00OO .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O00OOOOO0OOOO0O0O ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3900
			O0OO0O0O0000O0OOO .close ()#line:3901
			OO00OO000OO0O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3903
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'r')#line:3905
			O00O00O0OO0OO00OO =O0OO0O0O0000O0OOO .read ()#line:3906
			O0OO0O0O0000O0OOO .close ()#line:3907
			OO000OOO0OO00OO0O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:3908
			O00OOOOO0OOOO0O0O =re .compile (OO000OOO0OO00OO0O ).findall (O00O00O0OO0OO00OO )[0 ]#line:3909
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'w')#line:3910
			O0OO0O0O0000O0OOO .write (O00O00O0OO0OO00OO .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O00OOOOO0OOOO0O0O ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:3911
			O0OO0O0O0000O0OOO .close ()#line:3912
			OO00OO000OO0O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3916
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'r')#line:3918
			O00O00O0OO0OO00OO =O0OO0O0O0000O0OOO .read ()#line:3919
			O0OO0O0O0000O0OOO .close ()#line:3920
			OO000OOO0OO00OO0O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:3921
			O00OOOOO0OOOO0O0O =re .compile (OO000OOO0OO00OO0O ).findall (O00O00O0OO0OO00OO )[0 ]#line:3922
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'w')#line:3923
			O0OO0O0O0000O0OOO .write (O00O00O0OO0OO00OO .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O00OOOOO0OOOO0O0O ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:3924
			O0OO0O0O0000O0OOO .close ()#line:3925
			OO00OO000OO0O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3929
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'r')#line:3931
			O00O00O0OO0OO00OO =O0OO0O0O0000O0OOO .read ()#line:3932
			O0OO0O0O0000O0OOO .close ()#line:3933
			OO000OOO0OO00OO0O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:3934
			O00OOOOO0OOOO0O0O =re .compile (OO000OOO0OO00OO0O ).findall (O00O00O0OO0OO00OO )[0 ]#line:3935
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'w')#line:3936
			O0OO0O0O0000O0OOO .write (O00O00O0OO0OO00OO .replace ('<setting id="show.cdart" type="bool%s/setting>'%O00OOOOO0OOOO0O0O ,'<setting id="show.cdart" type="bool">false</setting>'))#line:3937
			O0OO0O0O0000O0OOO .close ()#line:3938
			OO00OO000OO0O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3942
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'r')#line:3944
			O00O00O0OO0OO00OO =O0OO0O0O0000O0OOO .read ()#line:3945
			O0OO0O0O0000O0OOO .close ()#line:3946
			OO000OOO0OO00OO0O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:3947
			O00OOOOO0OOOO0O0O =re .compile (OO000OOO0OO00OO0O ).findall (O00O00O0OO0OO00OO )[0 ]#line:3948
			O0OO0O0O0000O0OOO =open (OO00OO000OO0O0O00 ,'w')#line:3949
			O0OO0O0O0000O0OOO .write (O00O00O0OO0OO00OO .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O00OOOOO0OOOO0O0O ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:3950
			O0OO0O0O0000O0OOO .close ()#line:3951
		except :#line:3956
			pass #line:3957
def thirdPartyInstall (O00O0O0OOO00OOOO0 ,O00OO00O0000O0000 ):#line:3959
	if not wiz .workingURL (O00OO00O0000O0000 ):#line:3960
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:3961
	O0OOOOOOO0OOO00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0O0OOO00OOOO0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:3962
	if O0OOOOOOO0OOO00O0 ==1 :#line:3963
		freshStart ('third',True )#line:3964
	wiz .clearS ('build')#line:3965
	OO0O00000OO00OO00 =O00O0O0OOO00OOOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3966
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3967
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0OOO00OOOO0 ),'','אנא המתן')#line:3968
	OO0OO0000O00000O0 =os .path .join (PACKAGES ,'%s.zip'%OO0O00000OO00OO00 )#line:3969
	try :os .remove (OO0OO0000O00000O0 )#line:3970
	except :pass #line:3971
	downloader .download (O00OO00O0000O0000 ,OO0OO0000O00000O0 ,DP )#line:3972
	xbmc .sleep (1000 )#line:3973
	OO00OOO0OOOO000O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0OOO00OOOO0 )#line:3974
	DP .update (0 ,OO00OOO0OOOO000O0 ,'','אנא המתן')#line:3975
	OOO0O0O0OOO0O0000 ,OO00O0OO000O00OOO ,OOO00O0O0O0OOOOO0 =extract .all (OO0OO0000O00000O0 ,HOME ,DP ,title =OO00OOO0OOOO000O0 )#line:3976
	if int (float (OOO0O0O0OOO0O0000 ))>0 :#line:3977
		wiz .fixmetas ()#line:3978
		wiz .lookandFeelData ('save')#line:3979
		wiz .defaultSkin ()#line:3980
		wiz .setS ('installed','true')#line:3982
		wiz .setS ('extract',str (OOO0O0O0OOO0O0000 ))#line:3983
		wiz .setS ('errors',str (OO00O0OO000O00OOO ))#line:3984
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO0O0O0OOO0O0000 ,OO00O0OO000O00OOO ))#line:3985
		try :os .remove (OO0OO0000O00000O0 )#line:3986
		except :pass #line:3987
		if int (float (OO00O0OO000O00OOO ))>0 :#line:3988
			O00O0OO0O0OOOOO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0OOO00OOOO0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO0O0O0OOO0O0000 ,'%',COLOR1 ,OO00O0OO000O00OOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3989
			if O00O0OO0O0OOOOO0O :#line:3990
				if isinstance (OO00O0OO000O00OOO ,unicode ):#line:3991
					OOO00O0O0O0OOOOO0 =OOO00O0O0O0OOOOO0 .encode ('utf-8')#line:3992
				wiz .TextBox (ADDONTITLE ,OOO00O0O0O0OOOOO0 )#line:3993
	DP .close ()#line:3994
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3995
	if INSTALLMETHOD ==1 :O0OO0000OO0000O00 =1 #line:3996
	elif INSTALLMETHOD ==2 :O0OO0000OO0000O00 =0 #line:3997
	else :O0OO0000OO0000O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:3998
	if O0OO0000OO0000O00 ==1 :wiz .reloadFix ()#line:3999
	else :wiz .killxbmc (True )#line:4000
def testTheme (O0000O0O0O0OOO00O ):#line:4002
	O000OOO0O000OOO0O =zipfile .ZipFile (O0000O0O0O0OOO00O )#line:4003
	for OO0O0O000O0000O00 in O000OOO0O000OOO0O .infolist ():#line:4004
		if '/settings.xml'in OO0O0O000O0000O00 .filename :#line:4005
			return True #line:4006
	return False #line:4007
def testGui (O00000OOO0OO0O0OO ):#line:4009
	OOO0OOO0O00OOO00O =zipfile .ZipFile (O00000OOO0OO0O0OO )#line:4010
	for O0O00000O00OOOO00 in OOO0OOO0O00OOO00O .infolist ():#line:4011
		if '/guisettings.xml'in O0O00000O00OOOO00 .filename :#line:4012
			return True #line:4013
	return False #line:4014
def apkInstaller (O0O0O00O00OOOOOOO ,OO00O000O0O0O0O00 ):#line:4016
	wiz .log (O0O0O00O00OOOOOOO )#line:4017
	wiz .log (OO00O000O0O0O0O00 )#line:4018
	if wiz .platform ()=='android':#line:4019
		OOO000OOO0OOO0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O00O00OOOOOOO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4020
		if not OOO000OOO0OOO0000 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4021
		O0O00OOOOO000OOOO =O0O0O00O00OOOOOOO #line:4022
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4023
		if not wiz .workingURL (OO00O000O0O0O0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4024
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OOOOO000OOOO ),'','אנא המתן')#line:4025
		OO0O00OOO0000O0OO =os .path .join (PACKAGES ,"%s.apk"%O0O0O00O00OOOOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4026
		try :os .remove (OO0O00OOO0000O0OO )#line:4027
		except :pass #line:4028
		downloader .download (OO00O000O0O0O0O00 ,OO0O00OOO0000O0OO ,DP )#line:4029
		xbmc .sleep (100 )#line:4030
		DP .close ()#line:4031
		notify .apkInstaller (O0O0O00O00OOOOOOO )#line:4032
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO0O00OOO0000O0OO +'")')#line:4033
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4034
def createMenu (O00OO00OO00OO00OO ,OO00O00O000O0O0O0 ,OOOO00000OOO0O00O ):#line:4040
	if O00OO00OO00OO00OO =='saveaddon':#line:4041
		O0O0000O0O0OO0000 =[]#line:4042
		OOO0OO0O00OO0O0O0 =urllib .quote_plus (OO00O00O000O0O0O0 .lower ().replace (' ',''))#line:4043
		OO0OO00O00OO0OO0O =OO00O00O000O0O0O0 .replace ('Debrid','Real Debrid')#line:4044
		OOOO0OOOO0OOOOOOO =urllib .quote_plus (OOOO00000OOO0O00O .lower ().replace (' ',''))#line:4045
		OOOO00000OOO0O00O =OOOO00000OOO0O00O .replace ('url','URL Resolver')#line:4046
		O0O0000O0O0OO0000 .append ((THEME2 %OOOO00000OOO0O00O .title (),' '))#line:4047
		O0O0000O0O0OO0000 .append ((THEME3 %'Save %s Data'%OO0OO00O00OO0OO0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO0OO0O00OO0O0O0 ,OOOO0OOOO0OOOOOOO )))#line:4048
		O0O0000O0O0OO0000 .append ((THEME3 %'Restore %s Data'%OO0OO00O00OO0OO0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO0OO0O00OO0O0O0 ,OOOO0OOOO0OOOOOOO )))#line:4049
		O0O0000O0O0OO0000 .append ((THEME3 %'Clear %s Data'%OO0OO00O00OO0OO0O ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOO0OO0O00OO0O0O0 ,OOOO0OOOO0OOOOOOO )))#line:4050
	elif O00OO00OO00OO00OO =='save':#line:4051
		O0O0000O0O0OO0000 =[]#line:4052
		OOO0OO0O00OO0O0O0 =urllib .quote_plus (OO00O00O000O0O0O0 .lower ().replace (' ',''))#line:4053
		OO0OO00O00OO0OO0O =OO00O00O000O0O0O0 .replace ('Debrid','Real Debrid')#line:4054
		OOOO0OOOO0OOOOOOO =urllib .quote_plus (OOOO00000OOO0O00O .lower ().replace (' ',''))#line:4055
		OOOO00000OOO0O00O =OOOO00000OOO0O00O .replace ('url','URL Resolver')#line:4056
		O0O0000O0O0OO0000 .append ((THEME2 %OOOO00000OOO0O00O .title (),' '))#line:4057
		O0O0000O0O0OO0000 .append ((THEME3 %'Register %s'%OO0OO00O00OO0OO0O ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOO0OO0O00OO0O0O0 ,OOOO0OOOO0OOOOOOO )))#line:4058
		O0O0000O0O0OO0000 .append ((THEME3 %'Save %s Data'%OO0OO00O00OO0OO0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO0OO0O00OO0O0O0 ,OOOO0OOOO0OOOOOOO )))#line:4059
		O0O0000O0O0OO0000 .append ((THEME3 %'Restore %s Data'%OO0OO00O00OO0OO0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO0OO0O00OO0O0O0 ,OOOO0OOOO0OOOOOOO )))#line:4060
		O0O0000O0O0OO0000 .append ((THEME3 %'Import %s Data'%OO0OO00O00OO0OO0O ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOO0OO0O00OO0O0O0 ,OOOO0OOOO0OOOOOOO )))#line:4061
		O0O0000O0O0OO0000 .append ((THEME3 %'Clear Addon %s Data'%OO0OO00O00OO0OO0O ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOO0OO0O00OO0O0O0 ,OOOO0OOOO0OOOOOOO )))#line:4062
	elif O00OO00OO00OO00OO =='install':#line:4063
		O0O0000O0O0OO0000 =[]#line:4064
		OOOO0OOOO0OOOOOOO =urllib .quote_plus (OOOO00000OOO0O00O )#line:4065
		O0O0000O0O0OO0000 .append ((THEME2 %OOOO00000OOO0O00O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOOO0OOOO0OOOOOOO )))#line:4066
		O0O0000O0O0OO0000 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOOO0OOOO0OOOOOOO )))#line:4067
		O0O0000O0O0OO0000 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOOO0OOOO0OOOOOOO )))#line:4068
		O0O0000O0O0OO0000 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOOO0OOOO0OOOOOOO )))#line:4069
		O0O0000O0O0OO0000 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOOO0OOOO0OOOOOOO )))#line:4070
	O0O0000O0O0OO0000 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4071
	return O0O0000O0O0OO0000 #line:4072
def toggleCache (OO0000O0OO0O00OOO ):#line:4074
	O0OO0OO0O0OO000OO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4075
	OO0OOOOOOO0OO0OOO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4076
	if OO0000O0OO0O00OOO in ['true','false']:#line:4077
		for O0OOO0OOO0OO00O0O in O0OO0OO0O0OO000OO :#line:4078
			wiz .setS (O0OOO0OOO0OO00O0O ,OO0000O0OO0O00OOO )#line:4079
	else :#line:4080
		if not OO0000O0OO0O00OOO in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4081
			try :#line:4082
				O0OOO0OOO0OO00O0O =OO0OOOOOOO0OO0OOO [O0OO0OO0O0OO000OO .index (OO0000O0OO0O00OOO )]#line:4083
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0OOO0OOO0OO00O0O ))#line:4084
			except :#line:4085
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0000O0OO0O00OOO ))#line:4086
		else :#line:4087
			OO000OO0000O00O0O ='true'if wiz .getS (OO0000O0OO0O00OOO )=='false'else 'false'#line:4088
			wiz .setS (OO0000O0OO0O00OOO ,OO000OO0000O00O0O )#line:4089
def playVideo (OO0O00O0OO0O00OO0 ):#line:4091
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO0O00O0OO0O00OO0 )#line:4092
	if 'watch?v='in OO0O00O0OO0O00OO0 :#line:4093
		O0O0OO0OO000OO0OO ,OOOOO00OO000O0OOO =OO0O00O0OO0O00OO0 .split ('?')#line:4094
		OO000O0O00OOOO000 =OOOOO00OO000O0OOO .split ('&')#line:4095
		for OO0O00OO0000OOO0O in OO000O0O00OOOO000 :#line:4096
			if OO0O00OO0000OOO0O .startswith ('v='):#line:4097
				OO0O00O0OO0O00OO0 =OO0O00OO0000OOO0O [2 :]#line:4098
				break #line:4099
			else :continue #line:4100
	elif 'embed'in OO0O00O0OO0O00OO0 or 'youtu.be'in OO0O00O0OO0O00OO0 :#line:4101
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO0O00O0OO0O00OO0 )#line:4102
		O0O0OO0OO000OO0OO =OO0O00O0OO0O00OO0 .split ('/')#line:4103
		if len (O0O0OO0OO000OO0OO [-1 ])>5 :#line:4104
			OO0O00O0OO0O00OO0 =O0O0OO0OO000OO0OO [-1 ]#line:4105
		elif len (O0O0OO0OO000OO0OO [-2 ])>5 :#line:4106
			OO0O00O0OO0O00OO0 =O0O0OO0OO000OO0OO [-2 ]#line:4107
	wiz .log ("YouTube URL: %s"%OO0O00O0OO0O00OO0 )#line:4108
	yt .PlayVideo (OO0O00O0OO0O00OO0 )#line:4109
def viewLogFile ():#line:4111
	O00000O00OOOO000O =wiz .Grab_Log (True )#line:4112
	O0O0OO0OO00OOO000 =wiz .Grab_Log (True ,True )#line:4113
	OOO0OO000O000OOO0 =0 ;O0O0OOOO000000000 =O00000O00OOOO000O #line:4114
	if not O0O0OO0OO00OOO000 ==False and not O00000O00OOOO000O ==False :#line:4115
		OOO0OO000O000OOO0 =DIALOG .select (ADDONTITLE ,["View %s"%O00000O00OOOO000O .replace (LOG ,""),"View %s"%O0O0OO0OO00OOO000 .replace (LOG ,"")])#line:4116
		if OOO0OO000O000OOO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4117
	elif O00000O00OOOO000O ==False and O0O0OO0OO00OOO000 ==False :#line:4118
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4119
		return #line:4120
	elif not O00000O00OOOO000O ==False :OOO0OO000O000OOO0 =0 #line:4121
	elif not O0O0OO0OO00OOO000 ==False :OOO0OO000O000OOO0 =1 #line:4122
	O0O0OOOO000000000 =O00000O00OOOO000O if OOO0OO000O000OOO0 ==0 else O0O0OO0OO00OOO000 #line:4124
	O00000000O00000OO =wiz .Grab_Log (False )if OOO0OO000O000OOO0 ==0 else wiz .Grab_Log (False ,True )#line:4125
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0O0OOOO000000000 ),O00000000O00000OO )#line:4127
def errorChecking (log =None ,count =None ,all =None ):#line:4129
	if log ==None :#line:4130
		O0000O00OO0O000O0 =wiz .Grab_Log (True )#line:4131
		O0OO00OO0000000O0 =wiz .Grab_Log (True ,True )#line:4132
		if not O0OO00OO0000000O0 ==False and not O0000O00OO0O000O0 ==False :#line:4133
			OOO00O00OOO00OOO0 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0000O00OO0O000O0 .replace (LOG ,""),errorChecking (O0000O00OO0O000O0 ,True ,True )),"View %s: %s error(s)"%(O0OO00OO0000000O0 .replace (LOG ,""),errorChecking (O0OO00OO0000000O0 ,True ,True ))])#line:4134
			if OOO00O00OOO00OOO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4135
		elif O0000O00OO0O000O0 ==False and O0OO00OO0000000O0 ==False :#line:4136
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4137
			return #line:4138
		elif not O0000O00OO0O000O0 ==False :OOO00O00OOO00OOO0 =0 #line:4139
		elif not O0OO00OO0000000O0 ==False :OOO00O00OOO00OOO0 =1 #line:4140
		log =O0000O00OO0O000O0 if OOO00O00OOO00OOO0 ==0 else O0OO00OO0000000O0 #line:4141
	if log ==False :#line:4142
		if count ==None :#line:4143
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4144
			return False #line:4145
		else :#line:4146
			return 0 #line:4147
	else :#line:4148
		if os .path .exists (log ):#line:4149
			OOOOOOOO0OOOO0000 =open (log ,mode ='r');O00O0OOOOO0OOOO0O =OOOOOOOO0OOOO0000 .read ().replace ('\n','').replace ('\r','');OOOOOOOO0OOOO0000 .close ()#line:4150
			OOO00O0O0O00O0OO0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00O0OOOOO0OOOO0O )#line:4151
			if not count ==None :#line:4152
				if all ==None :#line:4153
					OO00O0000O00OO0O0 =0 #line:4154
					for O0000O0000O00O0O0 in OOO00O0O0O00O0OO0 :#line:4155
						if ADDON_ID in O0000O0000O00O0O0 :OO00O0000O00OO0O0 +=1 #line:4156
					return OO00O0000O00OO0O0 #line:4157
				else :return len (OOO00O0O0O00O0OO0 )#line:4158
			if len (OOO00O0O0O00O0OO0 )>0 :#line:4159
				OO00O0000O00OO0O0 =0 ;O0000OO00000OO0O0 =""#line:4160
				for O0000O0000O00O0O0 in OOO00O0O0O00O0OO0 :#line:4161
					if all ==None and not ADDON_ID in O0000O0000O00O0O0 :continue #line:4162
					else :#line:4163
						OO00O0000O00OO0O0 +=1 #line:4164
						O0000OO00000OO0O0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OO00O0000O00OO0O0 ,O0000O0000O00O0O0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4165
				if OO00O0000O00OO0O0 >0 :#line:4166
					wiz .TextBox (ADDONTITLE ,O0000OO00000OO0O0 )#line:4167
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4168
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4169
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4170
ACTION_PREVIOUS_MENU =10 #line:4172
ACTION_NAV_BACK =92 #line:4173
ACTION_MOVE_LEFT =1 #line:4174
ACTION_MOVE_RIGHT =2 #line:4175
ACTION_MOVE_UP =3 #line:4176
ACTION_MOVE_DOWN =4 #line:4177
ACTION_MOUSE_WHEEL_UP =104 #line:4178
ACTION_MOUSE_WHEEL_DOWN =105 #line:4179
ACTION_MOVE_MOUSE =107 #line:4180
ACTION_SELECT_ITEM =7 #line:4181
ACTION_BACKSPACE =110 #line:4182
ACTION_MOUSE_LEFT_CLICK =100 #line:4183
ACTION_MOUSE_LONG_CLICK =108 #line:4184
def LogViewer (default =None ):#line:4186
	class O000O00OOOOOO00O0 (xbmcgui .WindowXMLDialog ):#line:4187
		def __init__ (OO0O0O00000O00OO0 ,*OO0O00OOO00O0O0OO ,**O0O0OO0000OO0OO00 ):#line:4188
			OO0O0O00000O00OO0 .default =O0O0OO0000OO0OO00 ['default']#line:4189
		def onInit (O00OOOOOOOOOO00OO ):#line:4191
			O00OOOOOOOOOO00OO .title =101 #line:4192
			O00OOOOOOOOOO00OO .msg =102 #line:4193
			O00OOOOOOOOOO00OO .scrollbar =103 #line:4194
			O00OOOOOOOOOO00OO .upload =201 #line:4195
			O00OOOOOOOOOO00OO .kodi =202 #line:4196
			O00OOOOOOOOOO00OO .kodiold =203 #line:4197
			O00OOOOOOOOOO00OO .wizard =204 #line:4198
			O00OOOOOOOOOO00OO .okbutton =205 #line:4199
			O0OOOOOO000OO0O00 =open (O00OOOOOOOOOO00OO .default ,'r')#line:4200
			O00OOOOOOOOOO00OO .logmsg =O0OOOOOO000OO0O00 .read ()#line:4201
			O0OOOOOO000OO0O00 .close ()#line:4202
			O00OOOOOOOOOO00OO .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOOOOOOOOO00OO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4203
			O00OOOOOOOOOO00OO .showdialog ()#line:4204
		def showdialog (O00000OO0O0O0000O ):#line:4206
			O00000OO0O0O0000O .getControl (O00000OO0O0O0000O .title ).setLabel (O00000OO0O0O0000O .titlemsg )#line:4207
			O00000OO0O0O0000O .getControl (O00000OO0O0O0000O .msg ).setText (wiz .highlightText (O00000OO0O0O0000O .logmsg ))#line:4208
			O00000OO0O0O0000O .setFocusId (O00000OO0O0O0000O .scrollbar )#line:4209
		def onClick (OOOOOOO00OO00O000 ,OOOOOO000O000OO00 ):#line:4211
			if OOOOOO000O000OO00 ==OOOOOOO00OO00O000 .okbutton :OOOOOOO00OO00O000 .close ()#line:4212
			elif OOOOOO000O000OO00 ==OOOOOOO00OO00O000 .upload :OOOOOOO00OO00O000 .close ();uploadLog .Main ()#line:4213
			elif OOOOOO000O000OO00 ==OOOOOOO00OO00O000 .kodi :#line:4214
				O00O0000OOO00O00O =wiz .Grab_Log (False )#line:4215
				O00000OO0OOOOOOO0 =wiz .Grab_Log (True )#line:4216
				if O00O0000OOO00O00O ==False :#line:4217
					OOOOOOO00OO00O000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4218
					OOOOOOO00OO00O000 .getControl (OOOOOOO00OO00O000 .msg ).setText ("Log File Does Not Exists!")#line:4219
				else :#line:4220
					OOOOOOO00OO00O000 .titlemsg ="%s: %s"%(ADDONTITLE ,O00000OO0OOOOOOO0 .replace (LOG ,''))#line:4221
					OOOOOOO00OO00O000 .getControl (OOOOOOO00OO00O000 .title ).setLabel (OOOOOOO00OO00O000 .titlemsg )#line:4222
					OOOOOOO00OO00O000 .getControl (OOOOOOO00OO00O000 .msg ).setText (wiz .highlightText (O00O0000OOO00O00O ))#line:4223
					OOOOOOO00OO00O000 .setFocusId (OOOOOOO00OO00O000 .scrollbar )#line:4224
			elif OOOOOO000O000OO00 ==OOOOOOO00OO00O000 .kodiold :#line:4225
				O00O0000OOO00O00O =wiz .Grab_Log (False ,True )#line:4226
				O00000OO0OOOOOOO0 =wiz .Grab_Log (True ,True )#line:4227
				if O00O0000OOO00O00O ==False :#line:4228
					OOOOOOO00OO00O000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4229
					OOOOOOO00OO00O000 .getControl (OOOOOOO00OO00O000 .msg ).setText ("Log File Does Not Exists!")#line:4230
				else :#line:4231
					OOOOOOO00OO00O000 .titlemsg ="%s: %s"%(ADDONTITLE ,O00000OO0OOOOOOO0 .replace (LOG ,''))#line:4232
					OOOOOOO00OO00O000 .getControl (OOOOOOO00OO00O000 .title ).setLabel (OOOOOOO00OO00O000 .titlemsg )#line:4233
					OOOOOOO00OO00O000 .getControl (OOOOOOO00OO00O000 .msg ).setText (wiz .highlightText (O00O0000OOO00O00O ))#line:4234
					OOOOOOO00OO00O000 .setFocusId (OOOOOOO00OO00O000 .scrollbar )#line:4235
			elif OOOOOO000O000OO00 ==OOOOOOO00OO00O000 .wizard :#line:4236
				O00O0000OOO00O00O =wiz .Grab_Log (False ,False ,True )#line:4237
				O00000OO0OOOOOOO0 =wiz .Grab_Log (True ,False ,True )#line:4238
				if O00O0000OOO00O00O ==False :#line:4239
					OOOOOOO00OO00O000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4240
					OOOOOOO00OO00O000 .getControl (OOOOOOO00OO00O000 .msg ).setText ("Log File Does Not Exists!")#line:4241
				else :#line:4242
					OOOOOOO00OO00O000 .titlemsg ="%s: %s"%(ADDONTITLE ,O00000OO0OOOOOOO0 .replace (ADDONDATA ,''))#line:4243
					OOOOOOO00OO00O000 .getControl (OOOOOOO00OO00O000 .title ).setLabel (OOOOOOO00OO00O000 .titlemsg )#line:4244
					OOOOOOO00OO00O000 .getControl (OOOOOOO00OO00O000 .msg ).setText (wiz .highlightText (O00O0000OOO00O00O ))#line:4245
					OOOOOOO00OO00O000 .setFocusId (OOOOOOO00OO00O000 .scrollbar )#line:4246
		def onAction (O0O00OOOOO00O00OO ,OO0OO00O0O0O00OOO ):#line:4248
			if OO0OO00O0O0O00OOO ==ACTION_PREVIOUS_MENU :O0O00OOOOO00O00OO .close ()#line:4249
			elif OO0OO00O0O0O00OOO ==ACTION_NAV_BACK :O0O00OOOOO00O00OO .close ()#line:4250
	if default ==None :default =wiz .Grab_Log (True )#line:4251
	O0O0OOO0O00OO0O0O =O000O00OOOOOO00O0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4252
	O0O0OOO0O00OO0O0O .doModal ()#line:4253
	del O0O0OOO0O00OO0O0O #line:4254
def removeAddon (OOO00O0OO000OO00O ,OOO00OO0000O00000 ,over =False ):#line:4256
	if not over ==False :#line:4257
		O0OOO00O00000OO0O =1 #line:4258
	else :#line:4259
		O0OOO00O00000OO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO00OO0000O00000 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OOO00O0OO000OO00O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4260
	if O0OOO00O00000OO0O ==1 :#line:4261
		O00O0O0O00OO0O000 =os .path .join (ADDONS ,OOO00O0OO000OO00O )#line:4262
		wiz .log ("Removing Addon %s"%OOO00O0OO000OO00O )#line:4263
		wiz .cleanHouse (O00O0O0O00OO0O000 )#line:4264
		xbmc .sleep (1000 )#line:4265
		try :shutil .rmtree (O00O0O0O00OO0O000 )#line:4266
		except Exception as OOO0O00O0OOO00OO0 :wiz .log ("Error removing %s"%OOO00O0OO000OO00O ,xbmc .LOGNOTICE )#line:4267
		removeAddonData (OOO00O0OO000OO00O ,OOO00OO0000O00000 ,over )#line:4268
	if over ==False :#line:4269
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOO00OO0000O00000 ))#line:4270
def removeAddonData (OO0OO00OO0O0O0OOO ,name =None ,over =False ):#line:4272
	if OO0OO00OO0O0O0OOO =='all':#line:4273
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4274
			wiz .cleanHouse (ADDOND )#line:4275
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4276
	elif OO0OO00OO0O0O0OOO =='uninstalled':#line:4277
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4278
			OO0O00OO0O00OO000 =0 #line:4279
			for OO00OOO0O00OO0OO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4280
				O0O0O000O0O00O0O0 =OO00OOO0O00OO0OO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4281
				if O0O0O000O0O00O0O0 in EXCLUDES :pass #line:4282
				elif os .path .exists (os .path .join (ADDONS ,O0O0O000O0O00O0O0 )):pass #line:4283
				else :wiz .cleanHouse (OO00OOO0O00OO0OO0 );OO0O00OO0O00OO000 +=1 ;wiz .log (OO00OOO0O00OO0OO0 );shutil .rmtree (OO00OOO0O00OO0OO0 )#line:4284
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0O00OO0O00OO000 ))#line:4285
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4286
	elif OO0OO00OO0O0O0OOO =='empty':#line:4287
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4288
			OO0O00OO0O00OO000 =wiz .emptyfolder (ADDOND )#line:4289
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0O00OO0O00OO000 ))#line:4290
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4291
	else :#line:4292
		O0OOO000O0OOO0OOO =os .path .join (USERDATA ,'addon_data',OO0OO00OO0O0O0OOO )#line:4293
		if OO0OO00OO0O0O0OOO in EXCLUDES :#line:4294
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4295
		elif os .path .exists (O0OOO000O0OOO0OOO ):#line:4296
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OO00OO0O0O0OOO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4297
				wiz .cleanHouse (O0OOO000O0OOO0OOO )#line:4298
				try :#line:4299
					shutil .rmtree (O0OOO000O0OOO0OOO )#line:4300
				except :#line:4301
					wiz .log ("Error deleting: %s"%O0OOO000O0OOO0OOO )#line:4302
			else :#line:4303
				wiz .log ('Addon data for %s was not removed'%OO0OO00OO0O0O0OOO )#line:4304
	wiz .refresh ()#line:4305
def restoreit (O00O00O00OOO00OO0 ):#line:4307
	if O00O00O00OOO00OO0 =='build':#line:4308
		OO0000OOOOOO0OO00 =freshStart ('restore')#line:4309
		if OO0000OOOOOO0OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4310
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4311
		wiz .skinToDefault ()#line:4312
	wiz .restoreLocal (O00O00O00OOO00OO0 )#line:4313
def restoreextit (OO00OO0000000O00O ):#line:4315
	if OO00OO0000000O00O =='build':#line:4316
		O0O0000OOO00OOO00 =freshStart ('restore')#line:4317
		if O0O0000OOO00OOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4318
	wiz .restoreExternal (OO00OO0000000O00O )#line:4319
def buildInfo (O0OOO0OOO00O0O0O0 ):#line:4321
	if wiz .workingURL (SPEEDFILE )==True :#line:4322
		if wiz .checkBuild (O0OOO0OOO00O0O0O0 ,'url'):#line:4323
			O0OOO0OOO00O0O0O0 ,OOO00000OOO00O0OO ,OOOO00O0OOO0OOO00 ,O0OO00000000OOO0O ,O0OOO0000OOO00000 ,O0O0000OOOO0OOOO0 ,OOO000O0OO000O0OO ,OO0O0O00000OO0OOO ,O0000OOOOOOOOO00O ,OOOOOO00OO0O0O0O0 ,O000OOO000O000OO0 =wiz .checkBuild (O0OOO0OOO00O0O0O0 ,'all')#line:4324
			OOOOOO00OO0O0O0O0 ='Yes'if OOOOOO00OO0O0O0O0 .lower ()=='yes'else 'No'#line:4325
			O0O0O0OO00000OO0O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOO0OOO00O0O0O0 )#line:4326
			O0O0O0OO00000OO0O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO00000OOO00O0OO )#line:4327
			if not O0O0000OOOO0OOOO0 =="http://":#line:4328
				O00O00OO00O0O0OOO =wiz .themeCount (O0OOO0OOO00O0O0O0 ,False )#line:4329
				O0O0O0OO00000OO0O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O00O00OO00O0O0OOO ))#line:4330
			O0O0O0OO00000OO0O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOO0000OOO00000 )#line:4331
			O0O0O0OO00000OO0O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOOO00OO0O0O0O0 )#line:4332
			O0O0O0OO00000OO0O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000OOO000O000OO0 )#line:4333
			wiz .TextBox (ADDONTITLE ,O0O0O0OO00000OO0O )#line:4334
		else :wiz .log ("Invalid Build Name!")#line:4335
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4336
def buildVideo (O0OOOOO00OOOO0000 ):#line:4338
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4339
	if wiz .workingURL (SPEEDFILE )==True :#line:4340
		O00O000OO00O0O0OO =wiz .checkBuild (O0OOOOO00OOOO0000 ,'preview')#line:4341
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0OOOOO00OOOO0000 )#line:4342
		if O00O000OO00O0O0OO and not O00O000OO00O0O0OO =='http://':playVideo (O00O000OO00O0O0OO )#line:4343
		else :wiz .log ("[%s]Unable to find url for video preview"%O0OOOOO00OOOO0000 )#line:4344
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4345
def dependsList (O00O000OO00OOO0OO ):#line:4347
	OOOO0OO00OO00O00O =os .path .join (ADDONS ,O00O000OO00OOO0OO ,'addon.xml')#line:4348
	if os .path .exists (OOOO0OO00OO00O00O ):#line:4349
		OOO000OOO0000OOO0 =open (OOOO0OO00OO00O00O ,mode ='r');OOOOO0O0O0O0O0OOO =OOO000OOO0000OOO0 .read ();OOO000OOO0000OOO0 .close ();#line:4350
		OO00OO000O0O00O0O =wiz .parseDOM (OOOOO0O0O0O0O0OOO ,'import',ret ='addon')#line:4351
		OOO000O0OOOOOO000 =[]#line:4352
		for OO0O00OO00O0O0000 in OO00OO000O0O00O0O :#line:4353
			if not 'xbmc.python'in OO0O00OO00O0O0000 :#line:4354
				OOO000O0OOOOOO000 .append (OO0O00OO00O0O0000 )#line:4355
		return OOO000O0OOOOOO000 #line:4356
	return []#line:4357
def manageSaveData (OOOOO0OO00O000O00 ):#line:4359
	if OOOOO0OO00O000O00 =='import':#line:4360
		OOO0OOOOOOOOOO00O =os .path .join (ADDONDATA ,'temp')#line:4361
		if not os .path .exists (OOO0OOOOOOOOOO00O ):os .makedirs (OOO0OOOOOOOOOO00O )#line:4362
		O00OO0O00O0000OO0 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4363
		if not O00OO0O00O0000OO0 .endswith ('.zip'):#line:4364
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4365
			return #line:4366
		O0O0OO0OOOO0000O0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4367
		O0OO000000O00O0OO =xbmcvfs .copy (O00OO0O00O0000OO0 ,O0O0OO0OOOO0000O0 )#line:4368
		wiz .log ("%s"%str (O0OO000000O00O0OO ))#line:4369
		extract .all (xbmc .translatePath (O0O0OO0OOOO0000O0 ),OOO0OOOOOOOOOO00O )#line:4370
		OOO00O000O00O0O0O =os .path .join (OOO0OOOOOOOOOO00O ,'trakt')#line:4371
		O00OOO0OOOOOOO000 =os .path .join (OOO0OOOOOOOOOO00O ,'login')#line:4372
		OOO000OO0O0O000O0 =os .path .join (OOO0OOOOOOOOOO00O ,'debrid')#line:4373
		O0OO00O0O0O00OOOO =0 #line:4374
		if os .path .exists (OOO00O000O00O0O0O ):#line:4375
			O0OO00O0O0O00OOOO +=1 #line:4376
			OO0000O00O0OOO0O0 =os .listdir (OOO00O000O00O0O0O )#line:4377
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4378
			for OO000OO000OO0O0OO in OO0000O00O0OOO0O0 :#line:4379
				OOOOOO0O0O0OO0O0O =os .path .join (traktit .TRAKTFOLD ,OO000OO000OO0O0OO )#line:4380
				OO000OO0000O0000O =os .path .join (OOO00O000O00O0O0O ,OO000OO000OO0O0OO )#line:4381
				if os .path .exists (OOOOOO0O0O0OO0O0O ):#line:4382
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000OO000OO0O0OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4383
					else :os .remove (OOOOOO0O0O0OO0O0O )#line:4384
				shutil .copy (OO000OO0000O0000O ,OOOOOO0O0O0OO0O0O )#line:4385
			traktit .importlist ('all')#line:4386
			traktit .traktIt ('restore','all')#line:4387
		if os .path .exists (O00OOO0OOOOOOO000 ):#line:4388
			O0OO00O0O0O00OOOO +=1 #line:4389
			OO0000O00O0OOO0O0 =os .listdir (O00OOO0OOOOOOO000 )#line:4390
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4391
			for OO000OO000OO0O0OO in OO0000O00O0OOO0O0 :#line:4392
				OOOOOO0O0O0OO0O0O =os .path .join (loginit .LOGINFOLD ,OO000OO000OO0O0OO )#line:4393
				OO000OO0000O0000O =os .path .join (O00OOO0OOOOOOO000 ,OO000OO000OO0O0OO )#line:4394
				if os .path .exists (OOOOOO0O0O0OO0O0O ):#line:4395
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000OO000OO0O0OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4396
					else :os .remove (OOOOOO0O0O0OO0O0O )#line:4397
				shutil .copy (OO000OO0000O0000O ,OOOOOO0O0O0OO0O0O )#line:4398
			loginit .importlist ('all')#line:4399
			loginit .loginIt ('restore','all')#line:4400
		if os .path .exists (OOO000OO0O0O000O0 ):#line:4401
			O0OO00O0O0O00OOOO +=1 #line:4402
			OO0000O00O0OOO0O0 =os .listdir (OOO000OO0O0O000O0 )#line:4403
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4404
			for OO000OO000OO0O0OO in OO0000O00O0OOO0O0 :#line:4405
				OOOOOO0O0O0OO0O0O =os .path .join (debridit .REALFOLD ,OO000OO000OO0O0OO )#line:4406
				OO000OO0000O0000O =os .path .join (OOO000OO0O0O000O0 ,OO000OO000OO0O0OO )#line:4407
				if os .path .exists (OOOOOO0O0O0OO0O0O ):#line:4408
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000OO000OO0O0OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4409
					else :os .remove (OOOOOO0O0O0OO0O0O )#line:4410
				shutil .copy (OO000OO0000O0000O ,OOOOOO0O0O0OO0O0O )#line:4411
			debridit .importlist ('all')#line:4412
			debridit .debridIt ('restore','all')#line:4413
		wiz .cleanHouse (OOO0OOOOOOOOOO00O )#line:4414
		wiz .removeFolder (OOO0OOOOOOOOOO00O )#line:4415
		os .remove (O0O0OO0OOOO0000O0 )#line:4416
		if O0OO00O0O0O00OOOO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4417
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4418
	elif OOOOO0OO00O000O00 =='export':#line:4419
		OOOO0OO00O0000O00 =xbmc .translatePath (MYBUILDS )#line:4420
		OOOOO0OOO0OO0OOOO =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4421
		traktit .traktIt ('update','all')#line:4422
		loginit .loginIt ('update','all')#line:4423
		debridit .debridIt ('update','all')#line:4424
		O00OO0O00O0000OO0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4425
		O00OO0O00O0000OO0 =xbmc .translatePath (O00OO0O00O0000OO0 )#line:4426
		O0O0000O0O00OOO00 =os .path .join (OOOO0OO00O0000O00 ,'SaveData.zip')#line:4427
		O00000O00OOOO0OO0 =zipfile .ZipFile (O0O0000O0O00OOO00 ,mode ='w')#line:4428
		for O0OOO0OOO00O0000O in OOOOO0OOO0OO0OOOO :#line:4429
			if os .path .exists (O0OOO0OOO00O0000O ):#line:4430
				OO0000O00O0OOO0O0 =os .listdir (O0OOO0OOO00O0000O )#line:4431
				for O0O0OO0O000O00000 in OO0000O00O0OOO0O0 :#line:4432
					O00000O00OOOO0OO0 .write (os .path .join (O0OOO0OOO00O0000O ,O0O0OO0O000O00000 ),os .path .join (O0OOO0OOO00O0000O ,O0O0OO0O000O00000 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4433
		O00000O00OOOO0OO0 .close ()#line:4434
		if O00OO0O00O0000OO0 ==OOOO0OO00O0000O00 :#line:4435
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0000O0O00OOO00 ))#line:4436
		else :#line:4437
			try :#line:4438
				xbmcvfs .copy (O0O0000O0O00OOO00 ,os .path .join (O00OO0O00O0000OO0 ,'SaveData.zip'))#line:4439
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O00OO0O00O0000OO0 ,'SaveData.zip')))#line:4440
			except :#line:4441
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0000O0O00OOO00 ))#line:4442
def freshStart (install =None ,over =False ):#line:4447
	if USERNAME =='':#line:4448
		ADDON .openSettings ()#line:4449
		sys .exit ()#line:4450
	O00O0OO000OOOOOOO =u_list (SPEEDFILE )#line:4451
	(O00O0OO000OOOOOOO )#line:4452
	O0O0OO0OO0OO00000 =(wiz .workingURL (O00O0OO000OOOOOOO ))#line:4453
	(O0O0OO0OO0OO00000 )#line:4454
	if KEEPTRAKT =='true':#line:4455
		traktit .autoUpdate ('all')#line:4456
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4457
	if KEEPREAL =='true':#line:4458
		debridit .autoUpdate ('all')#line:4459
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4460
	if KEEPLOGIN =='true':#line:4461
		loginit .autoUpdate ('all')#line:4462
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4463
	if over ==True :OO0OOO0O00000O00O =1 #line:4464
	elif install =='restore':OO0OOO0O00000O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4465
	elif install :OO0OOO0O00000O00O =1 #line:4466
	else :OO0OOO0O00000O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4467
	if OO0OOO0O00000O00O :#line:4468
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4469
			OOOOO00O00000O0O0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4470
			skinSwitch .swapSkins (OOOOO00O00000O0O0 )#line:4473
			OOO0O0OOO0OOOO000 =0 #line:4474
			xbmc .sleep (1000 )#line:4475
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0O0OOO0OOOO000 <150 :#line:4476
				OOO0O0OOO0OOOO000 +=1 #line:4477
				xbmc .sleep (1000 )#line:4478
				wiz .ebi ('SendAction(Select)')#line:4479
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4480
				wiz .ebi ('SendClick(11)')#line:4481
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4482
			xbmc .sleep (1000 )#line:4483
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4484
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4485
			return #line:4486
		wiz .addonUpdates ('set')#line:4487
		O0OOOOOOOO0OOOO00 =os .path .abspath (HOME )#line:4488
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4489
		OOO000OOOO00OOO0O =sum ([len (O000O0000O000OOOO )for OOO00OO0000OO00OO ,OO00O00OOO0OOO0OO ,O000O0000O000OOOO in os .walk (O0OOOOOOOO0OOOO00 )]);OO0O0OOOOO0O00O00 =0 #line:4490
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4491
		EXCLUDES .append ('My_Builds')#line:4492
		EXCLUDES .append ('archive_cache')#line:4493
		EXCLUDES .append ('script.module.requests')#line:4494
		EXCLUDES .append ('myfav.anon')#line:4495
		if KEEPREPOS =='true':#line:4496
			O00OO0OOO0OO00OOO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4497
			for O000000O00O0OO0OO in O00OO0OOO0OO00OOO :#line:4498
				OOOO0OOO0OOOO00OO =os .path .split (O000000O00O0OO0OO [:-1 ])[1 ]#line:4499
				if not OOOO0OOO0OOOO00OO ==EXCLUDES :#line:4500
					EXCLUDES .append (OOOO0OOO0OOOO00OO )#line:4501
		if KEEPSUPER =='true':#line:4502
			EXCLUDES .append ('plugin.program.super.favourites')#line:4503
		if KEEPMOVIELIST =='true':#line:4504
			EXCLUDES .append ('plugin.video.metalliq')#line:4505
		if KEEPMOVIELIST =='true':#line:4506
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4507
		if KEEPADDONS =='true':#line:4508
			EXCLUDES .append ('addons')#line:4509
		if KEEPADDONS =='true':#line:4510
			EXCLUDES .append ('addon_data')#line:4511
		EXCLUDES .append ('plugin.video.elementum')#line:4514
		EXCLUDES .append ('script.elementum.burst')#line:4515
		EXCLUDES .append ('script.elementum.burst-master')#line:4516
		EXCLUDES .append ('plugin.video.quasar')#line:4517
		EXCLUDES .append ('script.quasar.burst')#line:4518
		EXCLUDES .append ('skin.estuary')#line:4519
		if KEEPWHITELIST =='true':#line:4522
			OO000O0OO000O0OO0 =''#line:4523
			O00OO000OO00000O0 =wiz .whiteList ('read')#line:4524
			if len (O00OO000OO00000O0 )>0 :#line:4525
				for O000000O00O0OO0OO in O00OO000OO00000O0 :#line:4526
					try :O000O0O00OOOOOO0O ,O0OO000O00000O000 ,OOO0O000O00O0O0OO =O000000O00O0OO0OO #line:4527
					except :pass #line:4528
					if OOO0O000O00O0O0OO .startswith ('pvr'):OO000O0OO000O0OO0 =O0OO000O00000O000 #line:4529
					OOOO0OOOO00OO0OOO =dependsList (OOO0O000O00O0O0OO )#line:4530
					for O0OO0O00OO0O0O0O0 in OOOO0OOOO00OO0OOO :#line:4531
						if not O0OO0O00OO0O0O0O0 in EXCLUDES :#line:4532
							EXCLUDES .append (O0OO0O00OO0O0O0O0 )#line:4533
						O0O0O00O0000O000O =dependsList (O0OO0O00OO0O0O0O0 )#line:4534
						for O0O00O0OOO0000000 in O0O0O00O0000O000O :#line:4535
							if not O0O00O0OOO0000000 in EXCLUDES :#line:4536
								EXCLUDES .append (O0O00O0OOO0000000 )#line:4537
					if not OOO0O000O00O0O0OO in EXCLUDES :#line:4538
						EXCLUDES .append (OOO0O000O00O0O0OO )#line:4539
				if not OO000O0OO000O0OO0 =='':wiz .setS ('pvrclient',OOO0O000O00O0O0OO )#line:4540
		if wiz .getS ('pvrclient')=='':#line:4541
			for O000000O00O0OO0OO in EXCLUDES :#line:4542
				if O000000O00O0OO0OO .startswith ('pvr'):#line:4543
					wiz .setS ('pvrclient',O000000O00O0OO0OO )#line:4544
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4545
		OO00O00000000O0O0 =wiz .latestDB ('Addons')#line:4546
		for OO0O0O0OOOOO000OO ,O0O00OOO00OOO00O0 ,O0OO000O0000OO00O in os .walk (O0OOOOOOOO0OOOO00 ,topdown =True ):#line:4547
			O0O00OOO00OOO00O0 [:]=[OOO00O0OO00OO0000 for OOO00O0OO00OO0000 in O0O00OOO00OOO00O0 if OOO00O0OO00OO0000 not in EXCLUDES ]#line:4548
			for O000O0O00OOOOOO0O in O0OO000O0000OO00O :#line:4549
				OO0O0OOOOO0O00O00 +=1 #line:4550
				OOO0O000O00O0O0OO =OO0O0O0OOOOO000OO .replace ('/','\\').split ('\\')#line:4551
				OOO0O0OOO0OOOO000 =len (OOO0O000O00O0O0OO )-1 #line:4553
				if OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4554
				elif O000O0O00OOOOOO0O =='MyVideos99.db'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4555
				elif O000O0O00OOOOOO0O =='MyVideos107.db'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4556
				elif O000O0O00OOOOOO0O =='MyVideos116.db'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4557
				elif O000O0O00OOOOOO0O =='MyVideos99.db'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4558
				elif O000O0O00OOOOOO0O =='MyVideos107.db'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4559
				elif O000O0O00OOOOOO0O =='MyVideos116.db'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4560
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4561
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'skin.anonymous.mod'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4562
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'skin.Premium.mod'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4563
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'skin.anonymous.nox'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4564
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'skin.phenomenal'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4565
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'plugin.video.metalliq'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4566
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'skin.titan'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4568
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'pvr.iptvsimple'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4569
				elif O000O0O00OOOOOO0O =='sources.xml'and OOO0O000O00O0O0OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4571
				elif O000O0O00OOOOOO0O =='quicknav.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4574
				elif O000O0O00OOOOOO0O =='x1101.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4575
				elif O000O0O00OOOOOO0O =='b-srtym-b.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4576
				elif O000O0O00OOOOOO0O =='x1102.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4577
				elif O000O0O00OOOOOO0O =='b-sdrvt-b.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4578
				elif O000O0O00OOOOOO0O =='x1112.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4579
				elif O000O0O00OOOOOO0O =='b-tlvvyzyh-b.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4580
				elif O000O0O00OOOOOO0O =='x1111.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4581
				elif O000O0O00OOOOOO0O =='b-tvknyshrly-b.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4582
				elif O000O0O00OOOOOO0O =='x1110.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4583
				elif O000O0O00OOOOOO0O =='b-yldym-b.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4584
				elif O000O0O00OOOOOO0O =='x1114.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4585
				elif O000O0O00OOOOOO0O =='b-mvzyqh-b.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4586
				elif O000O0O00OOOOOO0O =='mainmenu.DATA.xml'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4587
				elif O000O0O00OOOOOO0O =='skin.Premium.mod.properties'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4588
				elif O000O0O00OOOOOO0O =='favourites.xml'and OOO0O000O00O0O0OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4592
				elif O000O0O00OOOOOO0O =='guisettings.xml'and OOO0O000O00O0O0OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4594
				elif O000O0O00OOOOOO0O =='profiles.xml'and OOO0O000O00O0O0OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4595
				elif O000O0O00OOOOOO0O =='advancedsettings.xml'and OOO0O000O00O0O0OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4596
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4597
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'program.apollo'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4598
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4599
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'plugin.video.elementum'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4602
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4603
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4604
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'plugin.video.quasar'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4606
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'program.apollo'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4607
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4608
				elif OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -2 ]=='userdata'and OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOO0O000O00O0O0OO [OOO0O0OOO0OOOO000 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4609
				elif O000O0O00OOOOOO0O in LOGFILES :wiz .log ("Keep Log File: %s"%O000O0O00OOOOOO0O ,xbmc .LOGNOTICE )#line:4610
				elif O000O0O00OOOOOO0O .endswith ('.db'):#line:4611
					try :#line:4612
						if O000O0O00OOOOOO0O ==OO00O00000000O0O0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O000O0O00OOOOOO0O ,KODIV ),xbmc .LOGNOTICE )#line:4613
						else :os .remove (os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ))#line:4614
					except Exception as O00000000OOOO0O0O :#line:4615
						if not O000O0O00OOOOOO0O .startswith ('Textures13'):#line:4616
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4617
							wiz .log ("-> %s"%(str (O00000000OOOO0O0O )),xbmc .LOGNOTICE )#line:4618
							wiz .purgeDb (os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ))#line:4619
				else :#line:4620
					DP .update (int (wiz .percentage (OO0O0OOOOO0O00O00 ,OOO000OOOO00OOO0O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0O00OOOOOO0O ),'')#line:4621
					try :os .remove (os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ))#line:4622
					except Exception as O00000000OOOO0O0O :#line:4623
						wiz .log ("Error removing %s"%os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),xbmc .LOGNOTICE )#line:4624
						wiz .log ("-> / %s"%(str (O00000000OOOO0O0O )),xbmc .LOGNOTICE )#line:4625
			if DP .iscanceled ():#line:4626
				DP .close ()#line:4627
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4628
				return False #line:4629
		for OO0O0O0OOOOO000OO ,O0O00OOO00OOO00O0 ,O0OO000O0000OO00O in os .walk (O0OOOOOOOO0OOOO00 ,topdown =True ):#line:4630
			O0O00OOO00OOO00O0 [:]=[OO00000OO0000OO0O for OO00000OO0000OO0O in O0O00OOO00OOO00O0 if OO00000OO0000OO0O not in EXCLUDES ]#line:4631
			for O000O0O00OOOOOO0O in O0O00OOO00OOO00O0 :#line:4632
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O000O0O00OOOOOO0O ),'')#line:4633
			  if O000O0O00OOOOOO0O not in ["Database","userdata","temp","addons","addon_data"]:#line:4634
			   if not (O000O0O00OOOOOO0O =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4635
			    if not (O000O0O00OOOOOO0O =='skin.titan'and KEEPSKIN3 =='true'):#line:4637
			      if not (O000O0O00OOOOOO0O =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4638
			       if not (O000O0O00OOOOOO0O =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4639
			        if not (O000O0O00OOOOOO0O =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4640
			         if not (O000O0O00OOOOOO0O =='program.apollo'and KEEPINFO =='true'):#line:4641
			          if not (O000O0O00OOOOOO0O =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4642
			            if not (O000O0O00OOOOOO0O =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4644
			             if not (O000O0O00OOOOOO0O =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4645
			              if not (O000O0O00OOOOOO0O =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4646
			               if not (O000O0O00OOOOOO0O =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4647
			                if not (O000O0O00OOOOOO0O =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4648
			                 if not (O000O0O00OOOOOO0O =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4649
			                  if not (O000O0O00OOOOOO0O =='plugin.video.neptune'and KEEPINFO =='true'):#line:4650
			                   if not (O000O0O00OOOOOO0O =='plugin.video.youtube'and KEEPINFO =='true'):#line:4651
			                    if not (O000O0O00OOOOOO0O =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4652
			                     if not (O000O0O00OOOOOO0O =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4653
			                       if not (O000O0O00OOOOOO0O =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4655
			                           if not (O000O0O00OOOOOO0O =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4659
			                            if not (O000O0O00OOOOOO0O =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4660
			                             if not (O000O0O00OOOOOO0O =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4661
			                              if not (O000O0O00OOOOOO0O =='plugin.video.quasar'and KEEPINFO =='true'):#line:4662
			                               if not (O000O0O00OOOOOO0O =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4663
			                                  shutil .rmtree (os .path .join (OO0O0O0OOOOO000OO ,O000O0O00OOOOOO0O ),ignore_errors =True ,onerror =None )#line:4665
			if DP .iscanceled ():#line:4666
				DP .close ()#line:4667
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4668
				return False #line:4669
		DP .close ()#line:4670
		wiz .clearS ('build')#line:4671
		if over ==True :#line:4672
			return True #line:4673
		elif install =='restore':#line:4674
			return True #line:4675
		elif install :#line:4676
			buildWizard (install ,'normal',over =True )#line:4677
		else :#line:4678
			if INSTALLMETHOD ==1 :O00OOOO0000OOOO00 =1 #line:4679
			elif INSTALLMETHOD ==2 :O00OOOO0000OOOO00 =0 #line:4680
			else :O00OOOO0000OOOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4681
			if O00OOOO0000OOOO00 ==1 :wiz .reloadFix ('fresh')#line:4682
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4683
	else :#line:4684
		if not install =='restore':#line:4685
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4686
			wiz .refresh ()#line:4687
def clearCache ():#line:4692
		wiz .clearCache ()#line:4693
def fixwizard ():#line:4697
		wiz .fixwizard ()#line:4698
def totalClean ():#line:4700
		wiz .clearCache ()#line:4702
		wiz .clearPackages ('total')#line:4703
		clearThumb ('total')#line:4704
		cleanfornewbuild ()#line:4705
def cleanfornewbuild ():#line:4706
		try :#line:4707
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4708
		except :#line:4709
			pass #line:4710
		try :#line:4711
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4712
		except :#line:4713
			pass #line:4714
		try :#line:4715
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4716
		except :#line:4717
			pass #line:4718
def clearThumb (type =None ):#line:4719
	O000OO0O000000O0O =wiz .latestDB ('Textures')#line:4720
	if not type ==None :OOO0O000O000000OO =1 #line:4721
	else :OOO0O000O000000OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O000OO0O000000O0O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4722
	if OOO0O000O000000OO ==1 :#line:4723
		try :wiz .removeFile (os .join (DATABASE ,O000OO0O000000O0O ))#line:4724
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O000OO0O000000O0O )#line:4725
		wiz .removeFolder (THUMBS )#line:4726
	else :wiz .log ('Clear thumbnames cancelled')#line:4728
	wiz .redoThumbs ()#line:4729
def purgeDb ():#line:4731
	O0O0O0000OOO000O0 =[];OOO000OO0OO00000O =[]#line:4732
	for OOO00000OOO00O0O0 ,O00O0OOO000000O00 ,OO00OOO000OOO0OOO in os .walk (HOME ):#line:4733
		for O00O0OO000O0OOO0O in fnmatch .filter (OO00OOO000OOO0OOO ,'*.db'):#line:4734
			if O00O0OO000O0OOO0O !='Thumbs.db':#line:4735
				O0OO00O0O00O0OO0O =os .path .join (OOO00000OOO00O0O0 ,O00O0OO000O0OOO0O )#line:4736
				O0O0O0000OOO000O0 .append (O0OO00O0O00O0OO0O )#line:4737
				OO0OO0O0OO0OO0O0O =O0OO00O0O00O0OO0O .replace ('\\','/').split ('/')#line:4738
				OOO000OO0OO00000O .append ('(%s) %s'%(OO0OO0O0OO0OO0O0O [len (OO0OO0O0OO0OO0O0O )-2 ],OO0OO0O0OO0OO0O0O [len (OO0OO0O0OO0OO0O0O )-1 ]))#line:4739
	if KODIV >=16 :#line:4740
		OOOOOO0OO0OOOO000 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOO000OO0OO00000O )#line:4741
		if OOOOOO0OO0OOOO000 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4742
		elif len (OOOOOO0OO0OOOO000 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4743
		else :#line:4744
			for O0000O0OOO00O00O0 in OOOOOO0OO0OOOO000 :wiz .purgeDb (O0O0O0000OOO000O0 [O0000O0OOO00O00O0 ])#line:4745
	else :#line:4746
		OOOOOO0OO0OOOO000 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOO000OO0OO00000O )#line:4747
		if OOOOOO0OO0OOOO000 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4748
		else :wiz .purgeDb (O0O0O0000OOO000O0 [O0000O0OOO00O00O0 ])#line:4749
def fastupdatefirstbuild (OO000O0O00000O00O ):#line:4755
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:4756
	if ENABLE =='Yes':#line:4757
		if not NOTIFY =='true':#line:4758
			OO0OOOOO0O0O0O00O =wiz .workingURL (NOTIFICATION )#line:4759
			if OO0OOOOO0O0O0O00O ==True :#line:4760
				O0000OOOO00000OO0 ,O0O00O00OOOO00O0O =wiz .splitNotify (NOTIFICATION )#line:4761
				if not O0000OOOO00000OO0 ==False :#line:4763
					try :#line:4764
						O0000OOOO00000OO0 =int (O0000OOOO00000OO0 );OO000O0O00000O00O =int (OO000O0O00000O00O )#line:4765
						checkidupdate ()#line:4766
						wiz .setS ("notedismiss","true")#line:4767
						if O0000OOOO00000OO0 ==OO000O0O00000O00O :#line:4768
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0000OOOO00000OO0 ),xbmc .LOGNOTICE )#line:4769
						elif O0000OOOO00000OO0 >OO000O0O00000O00O :#line:4771
							wiz .log ("[Notifications] id: %s"%str (O0000OOOO00000OO0 ),xbmc .LOGNOTICE )#line:4772
							wiz .setS ('noteid',str (O0000OOOO00000OO0 ))#line:4773
							wiz .setS ("notedismiss","true")#line:4774
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4777
					except Exception as OO00O0OO00000OO00 :#line:4778
						wiz .log ("Error on Notifications Window: %s"%str (OO00O0OO00000OO00 ),xbmc .LOGERROR )#line:4779
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4781
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO0OOOOO0O0O0O00O ),xbmc .LOGNOTICE )#line:4782
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4783
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4784
def checkidupdate ():#line:4790
				wiz .setS ("notedismiss","true")#line:4792
				OOO0OO0O000O0OOOO =wiz .workingURL (NOTIFICATION )#line:4793
				O000OOOOOO0000O00 =" Kodi Premium"#line:4795
				OOOOOO000OOOOO00O =wiz .checkBuild (O000OOOOOO0000O00 ,'gui')#line:4796
				OOOO0OO000O00OOO0 =O000OOOOOO0000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4797
				if not wiz .workingURL (OOOOOO000OOOOO00O )==True :return #line:4798
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4799
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O000OOOOOO0000O00 ),'','אנא המתן')#line:4800
				O000O0000O0OO00O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO0OO000O00OOO0 )#line:4801
				try :os .remove (O000O0000O0OO00O0 )#line:4802
				except :pass #line:4803
				logging .warning (OOOOOO000OOOOO00O )#line:4804
				if 'google'in OOOOOO000OOOOO00O :#line:4805
				   OO0O0O0O00OOO0OOO =googledrive_download (OOOOOO000OOOOO00O ,O000O0000O0OO00O0 ,DP ,wiz .checkBuild (O000OOOOOO0000O00 ,'filesize'))#line:4806
				else :#line:4809
				  downloader .download (OOOOOO000OOOOO00O ,O000O0000O0OO00O0 ,DP )#line:4810
				xbmc .sleep (100 )#line:4811
				OO00OOO0OOOO0OO0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OOOOOO0000O00 )#line:4812
				DP .update (0 ,OO00OOO0OOOO0OO0O ,'','אנא המתן')#line:4813
				extract .all (O000O0000O0OO00O0 ,HOME ,DP ,title =OO00OOO0OOOO0OO0O )#line:4814
				DP .close ()#line:4815
				wiz .defaultSkin ()#line:4816
				wiz .lookandFeelData ('save')#line:4817
				if INSTALLMETHOD ==1 :OOO0OO0O0OOOOOO0O =1 #line:4820
				elif INSTALLMETHOD ==2 :OOO0OO0O0OOOOOO0O =0 #line:4821
				else :DP .close ()#line:4822
def gaiaserenaddon ():#line:4824
  O0O0O0OO000OO0O00 =(ADDON .getSetting ("gaiaseren"))#line:4825
  OOOOO0OOO00000OO0 =(ADDON .getSetting ("rdbuild"))#line:4826
  if O0O0O0OO000OO0O00 =='true'and OOOOO0OOO00000OO0 =='true':#line:4827
    OOO00OOO00OO0OO0O =(NEWFASTUPDATE )#line:4828
    O0OO00OO0O0OOO00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4829
    O000O00O00O0OOOOO =xbmcgui .DialogProgress ()#line:4830
    O000O00O00O0OOOOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4831
    OOO0OO0OO0OOOO0OO =os .path .join (PACKAGES ,'isr.zip')#line:4832
    OOOO00O0OO00O0OO0 =urllib2 .Request (OOO00OOO00OO0OO0O )#line:4833
    OO00OOOOOO00OO0O0 =urllib2 .urlopen (OOOO00O0OO00O0OO0 )#line:4834
    O0OO00000OOO0OO0O =xbmcgui .DialogProgress ()#line:4836
    O0OO00000OOO0OO0O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4837
    O0OO00000OOO0OO0O .update (0 )#line:4838
    O0OOO0000O0O0000O =open (OOO0OO0OO0OOOO0OO ,'wb')#line:4840
    try :#line:4842
      O000000OO0OOO0000 =OO00OOOOOO00OO0O0 .info ().getheader ('Content-Length').strip ()#line:4843
      OO0O0OOOOOO00OOOO =True #line:4844
    except AttributeError :#line:4845
          OO0O0OOOOOO00OOOO =False #line:4846
    if OO0O0OOOOOO00OOOO :#line:4848
          O000000OO0OOO0000 =int (O000000OO0OOO0000 )#line:4849
    OO0O00O0000000O00 =0 #line:4851
    OOOOO00OOO0OOOOOO =time .time ()#line:4852
    while True :#line:4853
          OOOO0000OO0OO0O00 =OO00OOOOOO00OO0O0 .read (8192 )#line:4854
          if not OOOO0000OO0OO0O00 :#line:4855
              sys .stdout .write ('\n')#line:4856
              break #line:4857
          OO0O00O0000000O00 +=len (OOOO0000OO0OO0O00 )#line:4859
          O0OOO0000O0O0000O .write (OOOO0000OO0OO0O00 )#line:4860
          if not OO0O0OOOOOO00OOOO :#line:4862
              O000000OO0OOO0000 =OO0O00O0000000O00 #line:4863
          if O0OO00000OOO0OO0O .iscanceled ():#line:4864
             O0OO00000OOO0OO0O .close ()#line:4865
             try :#line:4866
              os .remove (OOO0OO0OO0OOOO0OO )#line:4867
             except :#line:4868
              pass #line:4869
             break #line:4870
          OOO00OO00O0O0OO0O =float (OO0O00O0000000O00 )/O000000OO0OOO0000 #line:4871
          OOO00OO00O0O0OO0O =round (OOO00OO00O0O0OO0O *100 ,2 )#line:4872
          O0O0OOOO000OOOOOO =OO0O00O0000000O00 /(1024 *1024 )#line:4873
          OO00O00OO000OOO00 =O000000OO0OOO0000 /(1024 *1024 )#line:4874
          OO0O0OOO0OOO0O000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0OOOO000OOOOOO ,'teal',OO00O00OO000OOO00 )#line:4875
          if (time .time ()-OOOOO00OOO0OOOOOO )>0 :#line:4876
            OOO0OO0O0OOO0000O =OO0O00O0000000O00 /(time .time ()-OOOOO00OOO0OOOOOO )#line:4877
            OOO0OO0O0OOO0000O =OOO0OO0O0OOO0000O /1024 #line:4878
          else :#line:4879
           OOO0OO0O0OOO0000O =0 #line:4880
          OO000O00OOO0OO0OO ='KB'#line:4881
          if OOO0OO0O0OOO0000O >=1024 :#line:4882
             OOO0OO0O0OOO0000O =OOO0OO0O0OOO0000O /1024 #line:4883
             OO000O00OOO0OO0OO ='MB'#line:4884
          if OOO0OO0O0OOO0000O >0 and not OOO00OO00O0O0OO0O ==100 :#line:4885
              O0OO0OO0000000O0O =(O000000OO0OOO0000 -OO0O00O0000000O00 )/OOO0OO0O0OOO0000O #line:4886
          else :#line:4887
              O0OO0OO0000000O0O =0 #line:4888
          O00O0OOOO00O00OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0OO0O0OOO0000O ,OO000O00OOO0OO0OO )#line:4889
          O0OO00000OOO0OO0O .update (int (OOO00OO00O0O0OO0O ),OO0O0OOO0OOO0O000 ,O00O0OOOO00O00OO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4891
    OOOO0O00000000OO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4894
    O0OOO0000O0O0000O .close ()#line:4897
    extract .all (OOO0OO0OO0OOOO0OO ,OOOO0O00000000OO0 ,O0OO00000OOO0OO0O )#line:4898
    try :#line:4902
      os .remove (OOO0OO0OO0OOOO0OO )#line:4903
    except :#line:4904
      pass #line:4905
def testnotify ():#line:4907
	OOOO000O000O00000 =wiz .workingURL (NOTIFICATION )#line:4908
	if OOOO000O000O00000 ==True :#line:4909
		try :#line:4910
			OOO000000O0OO00O0 ,OOOO0O0O00OOO00OO =wiz .splitNotify (NOTIFICATION )#line:4911
			if OOO000000O0OO00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4912
			if STARTP2 ()=='ok':#line:4913
				notify .notification (OOOO0O0O00OOO00OO ,True )#line:4914
		except Exception as O0O00000O000O000O :#line:4915
			wiz .log ("Error on Notifications Window: %s"%str (O0O00000O000O000O ),xbmc .LOGERROR )#line:4916
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4917
def testnotify2 ():#line:4918
	OOO00OOOO0OO00000 =wiz .workingURL (NOTIFICATION2 )#line:4919
	if OOO00OOOO0OO00000 ==True :#line:4920
		try :#line:4921
			OOOO0O0OOO0O0O000 ,OO0OO000OOOOO0000 =wiz .splitNotify (NOTIFICATION2 )#line:4922
			if OOOO0O0OOO0O0O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4923
			if STARTP2 ()=='ok':#line:4924
				notify .notification2 (OO0OO000OOOOO0000 ,True )#line:4925
		except Exception as O00OO00OOOO00000O :#line:4926
			wiz .log ("Error on Notifications Window: %s"%str (O00OO00OOOO00000O ),xbmc .LOGERROR )#line:4927
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4928
def testnotify3 ():#line:4929
	OO0OOOO0O00OO000O =wiz .workingURL (NOTIFICATION3 )#line:4930
	if OO0OOOO0O00OO000O ==True :#line:4931
		try :#line:4932
			O000O0000O00O0O00 ,O0OOO00O0000OOOOO =wiz .splitNotify (NOTIFICATION3 )#line:4933
			if O000O0000O00O0O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4934
			if STARTP2 ()=='ok':#line:4935
				notify .notification3 (O0OOO00O0000OOOOO ,True )#line:4936
		except Exception as OOOOOO00O00O0O0OO :#line:4937
			wiz .log ("Error on Notifications Window: %s"%str (OOOOOO00O00O0O0OO ),xbmc .LOGERROR )#line:4938
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4939
def servicemanual ():#line:4940
	OO00O0O0O0OOOOO0O =wiz .workingURL (HELPINFO )#line:4941
	if OO00O0O0O0OOOOO0O ==True :#line:4942
		try :#line:4943
			O00000OOO0O000000 ,OO0O0O00O00O00000 =wiz .splitNotify (HELPINFO )#line:4944
			if O00000OOO0O000000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:4945
			notify .helpinfo (OO0O0O00O00O00000 ,True )#line:4946
		except Exception as O0OOOO00O00OOOO0O :#line:4947
			wiz .log ("Error on Notifications Window: %s"%str (O0OOOO00O00OOOO0O ),xbmc .LOGERROR )#line:4948
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:4949
def testupdate ():#line:4951
	if BUILDNAME =="":#line:4952
		notify .updateWindow ()#line:4953
	else :#line:4954
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:4955
def testfirst ():#line:4957
	notify .firstRun ()#line:4958
def testfirstRun ():#line:4960
	notify .firstRunSettings ()#line:4961
def fastinstall ():#line:4964
	notify .firstRuninstall ()#line:4965
def addDir (OOOO0O0OOOOOOOOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:4972
	OO0O0OO0OOO0O00OO =sys .argv [0 ]#line:4973
	if not mode ==None :OO0O0OO0OOO0O00OO +="?mode=%s"%urllib .quote_plus (mode )#line:4974
	if not name ==None :OO0O0OO0OOO0O00OO +="&name="+urllib .quote_plus (name )#line:4975
	if not url ==None :OO0O0OO0OOO0O00OO +="&url="+urllib .quote_plus (url )#line:4976
	O0OOOOO0OOO0OOO00 =True #line:4977
	if themeit :OOOO0O0OOOOOOOOO0 =themeit %OOOO0O0OOOOOOOOO0 #line:4978
	OOOOO000OOO00O0O0 =xbmcgui .ListItem (OOOO0O0OOOOOOOOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:4979
	OOOOO000OOO00O0O0 .setInfo (type ="Video",infoLabels ={"Title":OOOO0O0OOOOOOOOO0 ,"Plot":description })#line:4980
	OOOOO000OOO00O0O0 .setProperty ("Fanart_Image",fanart )#line:4981
	if not menu ==None :OOOOO000OOO00O0O0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:4982
	O0OOOOO0OOO0OOO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O0OO0OOO0O00OO ,listitem =OOOOO000OOO00O0O0 ,isFolder =True )#line:4983
	return O0OOOOO0OOO0OOO00 #line:4984
def addFile (O0000OO0OOOO00000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:4986
	OO0O00000O0000O0O =sys .argv [0 ]#line:4987
	if not mode ==None :OO0O00000O0000O0O +="?mode=%s"%urllib .quote_plus (mode )#line:4988
	if not name ==None :OO0O00000O0000O0O +="&name="+urllib .quote_plus (name )#line:4989
	if not url ==None :OO0O00000O0000O0O +="&url="+urllib .quote_plus (url )#line:4990
	OO000OO0OO000OO00 =True #line:4991
	if themeit :O0000OO0OOOO00000 =themeit %O0000OO0OOOO00000 #line:4992
	O00OOOO000OOO0000 =xbmcgui .ListItem (O0000OO0OOOO00000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:4993
	O00OOOO000OOO0000 .setInfo (type ="Video",infoLabels ={"Title":O0000OO0OOOO00000 ,"Plot":description })#line:4994
	O00OOOO000OOO0000 .setProperty ("Fanart_Image",fanart )#line:4995
	if not menu ==None :O00OOOO000OOO0000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:4996
	OO000OO0OO000OO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O00000O0000O0O ,listitem =O00OOOO000OOO0000 ,isFolder =False )#line:4997
	return OO000OO0OO000OO00 #line:4998
def get_params ():#line:5000
	OO00O00OO0OOOOOOO =[]#line:5001
	OO00O0OOO0000OOO0 =sys .argv [2 ]#line:5002
	if len (OO00O0OOO0000OOO0 )>=2 :#line:5003
		OO0OOO000O00O000O =sys .argv [2 ]#line:5004
		OO0OOOOO000OO0000 =OO0OOO000O00O000O .replace ('?','')#line:5005
		if (OO0OOO000O00O000O [len (OO0OOO000O00O000O )-1 ]=='/'):#line:5006
			OO0OOO000O00O000O =OO0OOO000O00O000O [0 :len (OO0OOO000O00O000O )-2 ]#line:5007
		O0OO0000OOO0OO000 =OO0OOOOO000OO0000 .split ('&')#line:5008
		OO00O00OO0OOOOOOO ={}#line:5009
		for OO0O0OO000O00O0O0 in range (len (O0OO0000OOO0OO000 )):#line:5010
			O0O0000O0OOO0OOOO ={}#line:5011
			O0O0000O0OOO0OOOO =O0OO0000OOO0OO000 [OO0O0OO000O00O0O0 ].split ('=')#line:5012
			if (len (O0O0000O0OOO0OOOO ))==2 :#line:5013
				OO00O00OO0OOOOOOO [O0O0000O0OOO0OOOO [0 ]]=O0O0000O0OOO0OOOO [1 ]#line:5014
		return OO00O00OO0OOOOOOO #line:5016
def remove_addons ():#line:5018
	try :#line:5019
			import json #line:5020
			O00000O00O0OO0O00 =urllib2 .urlopen (remove_url ).readlines ()#line:5021
			for OOO0O00OO0OOO000O in O00000O00O0OO0O00 :#line:5022
				O0O0OOO000OOO0O00 =OOO0O00OO0OOO000O .split (':')[1 ].strip ()#line:5024
				OO0OOO0000O0OO0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0O0OOO000OOO0O00 ,'false')#line:5025
				OO00O0O000O0O0O00 =xbmc .executeJSONRPC (OO0OOO0000O0OO0O0 )#line:5026
				O00O0O0O00O0O0OOO =json .loads (OO00O0O000O0O0O00 )#line:5027
				O000OOOO00OO00O0O =os .path .join (addons_folder ,O0O0OOO000OOO0O00 )#line:5029
				if os .path .exists (O000OOOO00OO00O0O ):#line:5031
					for O00O0000OO0O00O0O ,OOO0O000O00OO00O0 ,OO0OO00OO00OOOOOO in os .walk (O000OOOO00OO00O0O ):#line:5032
						for O000O0O0O0000O0OO in OO0OO00OO00OOOOOO :#line:5033
							os .unlink (os .path .join (O00O0000OO0O00O0O ,O000O0O0O0000O0OO ))#line:5034
						for O0000OOO000OO0O0O in OOO0O000O00OO00O0 :#line:5035
							shutil .rmtree (os .path .join (O00O0000OO0O00O0O ,O0000OOO000OO0O0O ))#line:5036
					os .rmdir (O000OOOO00OO00O0O )#line:5037
			xbmc .executebuiltin ('Container.Refresh')#line:5039
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5040
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5041
	except :pass #line:5042
def remove_addons2 ():#line:5043
	try :#line:5044
			import json #line:5045
			OO0OO0O0OO000O00O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5046
			for OO0O0OOOOO00O00O0 in OO0OO0O0OO000O00O :#line:5047
				O00000O0OOO0000O0 =OO0O0OOOOO00O00O0 .split (':')[1 ].strip ()#line:5049
				O00OOO0OOOOOOO00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O00000O0OOO0000O0 ,'false')#line:5050
				OO0OOO0O000OOO0OO =xbmc .executeJSONRPC (O00OOO0OOOOOOO00O )#line:5051
				OOOO0O00000OOO000 =json .loads (OO0OOO0O000OOO0OO )#line:5052
				OO00O0O00OOOOOOO0 =os .path .join (user_folder ,O00000O0OOO0000O0 )#line:5054
				if os .path .exists (OO00O0O00OOOOOOO0 ):#line:5056
					for OOO00O000OOO00OOO ,OOOO0OO0O0O00OO0O ,OOO00OOO000O00OO0 in os .walk (OO00O0O00OOOOOOO0 ):#line:5057
						for O0O000OOO00OOO00O in OOO00OOO000O00OO0 :#line:5058
							os .unlink (os .path .join (OOO00O000OOO00OOO ,O0O000OOO00OOO00O ))#line:5059
						for OOO0O0OOOOOOOO0OO in OOOO0OO0O0O00OO0O :#line:5060
							shutil .rmtree (os .path .join (OOO00O000OOO00OOO ,OOO0O0OOOOOOOO0OO ))#line:5061
					os .rmdir (OO00O0O00OOOOOOO0 )#line:5062
	except :pass #line:5064
params =get_params ()#line:5065
url =None #line:5066
name =None #line:5067
mode =None #line:5068
try :mode =urllib .unquote_plus (params ["mode"])#line:5070
except :pass #line:5071
try :name =urllib .unquote_plus (params ["name"])#line:5072
except :pass #line:5073
try :url =urllib .unquote_plus (params ["url"])#line:5074
except :pass #line:5075
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5077
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5078
def setView (O0OOOOOO0OOO0O0OO ,OOO0OOOO0OOO0OO0O ):#line:5079
	if wiz .getS ('auto-view')=='true':#line:5080
		O00O00O0OO0000000 =wiz .getS (OOO0OOOO0OOO0OO0O )#line:5081
		if O00O00O0OO0000000 =='50'and KODIV >=17 and SKIN =='skin.estuary':O00O00O0OO0000000 ='55'#line:5082
		if O00O00O0OO0000000 =='500'and KODIV >=17 and SKIN =='skin.estuary':O00O00O0OO0000000 ='50'#line:5083
		wiz .ebi ("Container.SetViewMode(%s)"%O00O00O0OO0000000 )#line:5084
if mode ==None :index ()#line:5086
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5088
elif mode =='builds':buildMenu ()#line:5089
elif mode =='viewbuild':viewBuild (name )#line:5090
elif mode =='buildinfo':buildInfo (name )#line:5091
elif mode =='buildpreview':buildVideo (name )#line:5092
elif mode =='install':buildWizard (name ,url )#line:5093
elif mode =='theme':buildWizard (name ,mode ,url )#line:5094
elif mode =='viewthirdparty':viewThirdList (name )#line:5095
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5096
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5097
elif mode =='maint':maintMenu (name )#line:5099
elif mode =='passpin':passandpin ()#line:5100
elif mode =='backmyupbuild':backmyupbuild ()#line:5101
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5102
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5103
elif mode =='advancedsetting':advancedWindow (name )#line:5104
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5105
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5106
elif mode =='asciicheck':wiz .asciiCheck ()#line:5107
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5108
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5109
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5110
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5111
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5112
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5113
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5114
elif mode =='currentsettings':viewAdvanced ()#line:5115
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5116
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5117
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5118
elif mode =='fixskin':backtokodi ()#line:5119
elif mode =='testcommand':testcommand ()#line:5120
elif mode =='rdon':rdon ()#line:5121
elif mode =='rdoff':rdoff ()#line:5122
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5123
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5124
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5125
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5126
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5127
elif mode =='freshstart':freshStart ()#line:5128
elif mode =='forceupdate':wiz .forceUpdate ()#line:5129
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5130
elif mode =='forceclose':wiz .killxbmc ()#line:5131
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5132
elif mode =='hidepassword':wiz .hidePassword ()#line:5133
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5134
elif mode =='enableaddons':enableAddons ()#line:5135
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5136
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5137
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5138
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5139
elif mode =='uploadlog':uploadLog .Main ()#line:5140
elif mode =='viewlog':LogViewer ()#line:5141
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5142
elif mode =='viewerrorlog':errorChecking (all =True )#line:5143
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5144
elif mode =='purgedb':purgeDb ()#line:5145
elif mode =='fixaddonupdate':fixUpdate ()#line:5146
elif mode =='removeaddons':removeAddonMenu ()#line:5147
elif mode =='removeaddon':removeAddon (name )#line:5148
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5149
elif mode =='removedata':removeAddonData (name )#line:5150
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5151
elif mode =='systeminfo':systemInfo ()#line:5152
elif mode =='restorezip':restoreit ('build')#line:5153
elif mode =='restoregui':restoreit ('gui')#line:5154
elif mode =='restoreaddon':restoreit ('addondata')#line:5155
elif mode =='restoreextzip':restoreextit ('build')#line:5156
elif mode =='restoreextgui':restoreextit ('gui')#line:5157
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5158
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5159
elif mode =='apk':apkMenu (name )#line:5161
elif mode =='apkscrape':apkScraper (name )#line:5162
elif mode =='apkinstall':apkInstaller (name ,url )#line:5163
elif mode =='speed':speedMenu ()#line:5164
elif mode =='net':net_tools ()#line:5165
elif mode =='GetList':GetList (url )#line:5166
elif mode =='youtube':youtubeMenu (name )#line:5167
elif mode =='viewVideo':playVideo (url )#line:5168
elif mode =='addons':addonMenu (name )#line:5170
elif mode =='addoninstall':addonInstaller (name ,url )#line:5171
elif mode =='savedata':saveMenu ()#line:5173
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5174
elif mode =='managedata':manageSaveData (name )#line:5175
elif mode =='whitelist':wiz .whiteList (name )#line:5176
elif mode =='trakt':traktMenu ()#line:5178
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5179
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5180
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5181
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5182
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5183
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5184
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5185
elif mode =='realdebrid':realMenu ()#line:5187
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5188
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5189
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5190
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5191
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5192
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5193
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5194
elif mode =='login':loginMenu ()#line:5196
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5197
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5198
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5199
elif mode =='clearlogin':loginit .clearSaved (name )#line:5200
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5201
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5202
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5203
elif mode =='contact':notify .contact (CONTACT )#line:5205
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5206
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5207
elif mode =='developer':developer ()#line:5209
elif mode =='converttext':wiz .convertText ()#line:5210
elif mode =='createqr':wiz .createQR ()#line:5211
elif mode =='testnotify':testnotify ()#line:5212
elif mode =='testnotify2':testnotify2 ()#line:5213
elif mode =='servicemanual':servicemanual ()#line:5214
elif mode =='fastinstall':fastinstall ()#line:5215
elif mode =='testupdate':testupdate ()#line:5216
elif mode =='testfirst':testfirst ()#line:5217
elif mode =='testfirstrun':testfirstRun ()#line:5218
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5219
elif mode =='bg':wiz .bg_install (name ,url )#line:5221
elif mode =='bgcustom':wiz .bg_custom ()#line:5222
elif mode =='bgremove':wiz .bg_remove ()#line:5223
elif mode =='bgdefault':wiz .bg_default ()#line:5224
elif mode =='rdset':rdsetup ()#line:5225
elif mode =='mor':morsetup ()#line:5226
elif mode =='mor2':morsetup2 ()#line:5227
elif mode =='resolveurl':resolveurlsetup ()#line:5228
elif mode =='urlresolver':urlresolversetup ()#line:5229
elif mode =='forcefastupdate':forcefastupdate ()#line:5230
elif mode =='traktset':traktsetup ()#line:5231
elif mode =='placentaset':placentasetup ()#line:5232
elif mode =='flixnetset':flixnetsetup ()#line:5233
elif mode =='reptiliaset':reptiliasetup ()#line:5234
elif mode =='yodasset':yodasetup ()#line:5235
elif mode =='numbersset':numberssetup ()#line:5236
elif mode =='uranusset':uranussetup ()#line:5237
elif mode =='genesisset':genesissetup ()#line:5238
elif mode =='fastupdate':fastupdate ()#line:5239
elif mode =='folderback':folderback ()#line:5240
elif mode =='menudata':Menu ()#line:5241
elif mode ==2 :#line:5243
        wiz .torent_menu ()#line:5244
elif mode ==3 :#line:5245
        wiz .popcorn_menu ()#line:5246
elif mode ==8 :#line:5247
        wiz .metaliq_fix ()#line:5248
elif mode ==9 :#line:5249
        wiz .quasar_menu ()#line:5250
elif mode ==5 :#line:5251
        swapSkins ('skin.Premium.mod')#line:5252
elif mode ==13 :#line:5253
        wiz .elementum_menu ()#line:5254
elif mode ==16 :#line:5255
        wiz .fix_wizard ()#line:5256
elif mode ==17 :#line:5257
        wiz .last_play ()#line:5258
elif mode ==18 :#line:5259
        wiz .normal_metalliq ()#line:5260
elif mode ==19 :#line:5261
        wiz .fast_metalliq ()#line:5262
elif mode ==20 :#line:5263
        wiz .fix_buffer2 ()#line:5264
elif mode ==21 :#line:5265
        wiz .fix_buffer3 ()#line:5266
elif mode ==11 :#line:5267
        wiz .fix_buffer ()#line:5268
elif mode ==15 :#line:5269
        wiz .fix_font ()#line:5270
elif mode ==14 :#line:5271
        wiz .clean_pass ()#line:5272
elif mode ==22 :#line:5273
        wiz .movie_update ()#line:5274
elif mode =='adv_settings':buffer1 ()#line:5275
elif mode =='getpass':getpass ()#line:5276
elif mode =='setpass':setpass ()#line:5277
elif mode =='setuname':setuname ()#line:5278
elif mode =='passandUsername':passandUsername ()#line:5279
elif mode =='9':disply_hwr ()#line:5280
elif mode =='99':disply_hwr2 ()#line:5281
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))