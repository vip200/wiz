# coding: utf-8
import xbmcaddon,base64

ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = 'Anonymous TV' 
EXCLUDES       = [ADDON_ID, 'repository.utv']
BUILDFILE      = 'aHR0cy9hcGkuc2RhcmHM6Ly9wYXN0ZWy9hcGkuc2RhcmJpbi5jb20vcmF3L1FwOTlaTWVB==99887766'
TMDB_NEW_API = 'aG9qaw=='
UPDATECHECK    = 0
APKFILE        = ''
PATH           = xbmcaddon.Addon().getAddonInfo('path')

F='aHR0cHM6Ly!9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3ZpcDIwMC93aXovbWFzdGVy$L3dpemFyZHVwZGF0ZS54bWw='
N='aHR0cHM6Ly9kaWdpdC5zZWVk!aG9zdC5ldS9rb2RpL3dpemFyZC90$eHQvZmFzdHVwZGF0ZS54bWw='
ICONBUILDS     = 'http://'
SPACER         = '[COLOR red]----------------------------------[/COLOR]'
COLOR1         = 'gold'
COLOR2         = 'white'
COLOR3         = 'red'
COLOR3         = 'blue'
THEME1         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
THEME4         = '[COLOR '+COLOR1+']%s[/COLOR] [COLOR '+COLOR2+'] :מספר גירסה[/COLOR]'
F=F.replace('!','').replace('$','')
CONTACTICON    = 'http://'
CONTACTFANART  = 'http://'
N=N.replace('!','').replace('$','')
#########################################################
WIZARDFILE     = base64.b64decode(F).decode('utf-8')#OLD WIZARDFILE
#.decode('utf-8')
#########################################################
WIZARDFILE_NEW     = 'aHR0mZS93a2tvZGkubGlmZS93aXphcmQmZS93al6YXJkdX==BkYmZS93=ahtbA=\=11223344'
SPEEDFILE      = 'aHR0ubGlmZcDovL2tvZGkubG==lmZS93aXphcmQvYnVpbGQueGubGlmZ1s=97===55=\=00112233'#decode('utf-8')
SPEED = 'aHR0cDZGkubovL2tvZGZGkubkubGlmZZGkubS93aXph54bWw=cmQvcGFzcy54bWw=937===535=\=55667722'#decode('utf-8')
UNAME = 'aHR0cDZGkubov5345ergubkubGlmZ43534gdfph54bWw=cmQv54dfgdfhy54bWw=947===545=\=00887766'
User_name = base64.b64decode('aHR0cDovL2tvZGkubGlmZS93aXphcmQvd2l6LnVzZXIueG1s').decode('utf-8')
Password_key=base64.b64decode('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbmV3X3Bhc3MueG1s').decode('utf-8')
Build_url=base64.b64decode('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbXlidWlsZDIueG1s').decode('utf-8')


# Url to notification file
NOTIFICATION   = base64.b64decode(N).decode('utf-8')

HEADERTYPE     = 'Image'
HEADERMESSAGE  = 'מה חדש בקודי אנונימוס:'
HEADERIMAGE    = base64.b64decode('aHR0cHM6Ly9wcmV2aWV3LmliYi5jby9oMnh6YlQvaWNvbi5wbmc=').decode('utf-8')
BACKGROUND     = 'https://euimages.urbanoutfitters.com/is/image/UrbanOutfittersEU/5123433451032_001_s'
#########################################################