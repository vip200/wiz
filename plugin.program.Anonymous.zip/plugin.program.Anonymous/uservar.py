# coding: utf-8
import xbmcaddon,base64

ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = 'Anonymous TV' 
EXCLUDES       = [ADDON_ID, 'repository.utv']
UPDATECHECK    = 0
APKFILE        = ''
PATH           = xbmcaddon.Addon().getAddonInfo('path')
F='aHR0cHM6Ly!9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3ZpcDIwMC93aXovbWFzdGVy$L3dpemFyZHVwZGF0ZS54bWw='

ICONBUILDS     = 'http://'
SPACER         = '[COLOR red]----------------------------------[/COLOR]'
COLOR1         = 'gold'
COLOR2         = 'white'
COLOR3         = 'red'
COLOR3         = 'blue'
THEME1         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
THEME4         = '[COLOR '+COLOR1+']%s[/COLOR] [COLOR '+COLOR2+'] :מספר גירסה[/COLOR]'
F=F.replace('!','').replace('$','')
CONTACTICON    = 'http://'
CONTACTFANART  = 'http://'

#########################################################
WIZARDFILE     = base64.b64decode(F).decode('utf-8')
NOTIFICATION   = 'http://v2202506280616350431.megasrv.de:8000/kodi/txt/fastupdate.xml'
HEADERTYPE     = 'Image'
HEADERMESSAGE  = ''
#########################################################