# coding: utf-8

import xbmc,xbmcaddon,xbmcgui,os,xbmcvfs,urllib,uservar

from resources.libs import wizard as wiz
from datetime import date, datetime, timedelta


que=urllib.parse.quote_plus
url_encode=urllib.parse.urlencode
ADDON_ID       = uservar.ADDON_ID
ADDON          = wiz.addonId(ADDON_ID)
VERSION        = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH      = wiz.addonInfo(ADDON_ID,'path')
ADDONTITLE     = uservar.ADDONTITLE
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME           = xbmcvfs.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
USERDATA       = os.path.join(HOME,     'userdata')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
FANART         = os.path.join(ADDONPATH,   'fanart.jpg')
TMDB_NEW_API     = uservar.TMDB_NEW_API
ICON           = os.path.join(ADDONPATH,   'icon.png')
ART            = os.path.join(ADDONPATH,   'resources', 'art')
NOTIFY         = wiz.getS('notify')
NOTEID         = wiz.getS('noteid')
NOTEDISMISS    = wiz.getS('notedismiss')
BUILDNAME      = wiz.getS('buildname')
BUILDVERSION   = wiz.getS('buildversion')
TODAY          = date.today()
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
TOMORROW       = TODAY + timedelta(days=1)
THREEDAYS      = TODAY + timedelta(days=0)
UPDATECHECK    = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
NEXTCHECK      = TODAY + timedelta(days=UPDATECHECK)
NOTIFICATION   = uservar.NOTIFICATION
HEADERTYPE     = uservar.HEADERTYPE if uservar.HEADERTYPE == 'Image' else 'Text'
HEADERMESSAGE  = uservar.HEADERMESSAGE
BACKGROUND     = uservar.BACKGROUND
HEADERIMAGE    = uservar.HEADERIMAGE
THEME1         = uservar.THEME1
THEME2         = uservar.THEME2
THEME3         = uservar.THEME3
THEME4         = uservar.THEME4
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
CONTACTFANART  = uservar.CONTACTFANART if not uservar.CONTACTFANART == 'http://' else FANART
if BACKGROUND == '': BACKGROUND = FANART
elif not wiz.workingURL(BACKGROUND): BACKGROUND = FANART

ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?
ACTION_MOUSE_LEFT_CLICK 		= 100
ACTION_MOUSE_LONG_CLICK 		= 108



def apkInstaller(apk):
    class APKInstaller(xbmcgui.WindowXMLDialog):
        def __init__(self,*args,**kwargs):
            self.shut=kwargs['close_time']
            xbmc.executebuiltin("Skin.Reset(AnimeWindowXMLDialogClose)")
            xbmc.executebuiltin("Skin.SetBool(AnimeWindowXMLDialogClose)")

        def onClick(self,controlID): self.CloseWindow()

        def onAction(self,action):
            if action in [ACTION_PREVIOUS_MENU, ACTION_BACKSPACE, ACTION_NAV_BACK, ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK, ACTION_MOUSE_LONG_CLICK]: self.CloseWindow()

        def CloseWindow(self):
            xbmc.executebuiltin("Skin.Reset(AnimeWindowXMLDialogClose)")
            xbmc.sleep(400)
            self.close()
    
    xbmc.executebuiltin('Skin.SetString(apkinstaller, אפליקציה %s ירדה למכשירך[CR]המשך להתקנה)' % apk)
    popup = APKInstaller('APK.xml', ADDON.getAddonInfo('path'), 'DefaultSkin', close_time=34)
    popup.doModal()
    del popup




def notification(msg='', test=False):
    class MyWindow(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            self.test = kwargs['test']
            self.message =  THEME2 % kwargs['msg']
        
        def onInit(self):
            self.image       = 101
            self.titlebox    = 102
            self.titleimage  = 103
            self.textbox     = 104
            self.scroller    = 105
            self.dismiss     = 201
            #self.remindme    = 202
            self.fastupdate  = 202
            self.showdialog()

        def showdialog(self):
            self.testimage = os.path.join(ART, 'text.png')
            self.getControl(self.image).setImage(BACKGROUND)
            self.getControl(self.image).setColorDiffuse('9FFFFFFF')
            self.getControl(self.textbox).setText(self.message)
            self.setFocusId(self.fastupdate)
            if HEADERTYPE == 'Text':
                self.getControl(self.titlebox).setLabel(THEME3 % HEADERMESSAGE)
            else:
                self.getControl(self.titleimage).setImage(HEADERIMAGE)
        def doFastupdate(self):
            if not test == True:
                wiz.setS("notedismiss","true")
            wiz.log("[Notification] NotifyID %s Dismissed" % wiz.getS('noteid'), 5)


            url = 'plugin://%s/?mode=install&name=%s&url=gui' % (ADDON_ID, que(BUILDNAME))
            xbmc.executebuiltin('RunPlugin(%s)' % url)
            self.close()

        def doRemindMeLater(self):
            if not test == True:
                wiz.setS("notedismiss","false")
            wiz.log("[Notification] NotifyID %s Remind Me Later" % wiz.getS('noteid'), 5)
            self.close()

        def doDismiss(self):
            if not test == True:
                wiz.setS("notedismiss","true")
            wiz.log("[Notification] NotifyID %s Dismissed" % wiz.getS('noteid'), 5)
            self.close()

        def onAction(self,action):
            if   action == ACTION_PREVIOUS_MENU: self.doRemindMeLater()
            elif action == ACTION_NAV_BACK: self.doRemindMeLater()

        def onClick(self, controlId):
            if (controlId == self.dismiss): self.doRemindMeLater()
            else: self.doFastupdate()
            
    xbmc.executebuiltin('Skin.SetString(headertexttype, %s)' % 'true' if HEADERTYPE == 'Text' else 'false')
    xbmc.executebuiltin('Skin.SetString(headerimagetype, %s)' % 'true' if HEADERTYPE == 'Image' else 'false')
    notify = MyWindow( "Notifications.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', msg=msg, test=test)
    notify.doModal()
    del notify


def updateinfo(msg='', test=False):
    class MyWindow(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            self.test = kwargs['test']
            self.message =  THEME2 % kwargs['msg']
        def background_skip(self):
            timeout=0
            break_jumpx=1
            time_left=999999
            while timeout<200:
                timeout+=1
                if break_jumpx==0:
                    break
                xbmc.sleep(60000)
                self.close()
        def onInit(self):
            self.image       = 101
            self.titlebox    = 102
            self.titleimage  = 103
            self.textbox     = 104
            self.scroller    = 105
            self.dismiss     = 201
            #self.remindme    = 202
            self.show_info  = 202
            self.showdialog()
            from threading import Thread
            Thread(target=self.background_skip).start()

        def showdialog(self):
            self.testimage = os.path.join(ART, 'text.png')
            self.getControl(self.image).setImage(CONTACTFANART)
            self.getControl(self.image).setColorDiffuse('9FFFFFFF')
            self.getControl(self.textbox).setText(self.message)
            self.setFocusId(self.dismiss)
            if HEADERTYPE == 'Text':
                self.getControl(self.titlebox).setLabel(THEME3 % HEADERMESSAGE)
            else:
                self.getControl(self.titleimage).setImage(HEADERIMAGE)
        def doFastupdate(self):
            if not test == True:
                wiz.setS("notedismiss","true")
            wiz.log("[Notification] NotifyID %s Dismissed" % wiz.getS('noteid'), 5)
            if KODIV>=18:
                    url = 'plugin://%s/?mode=install&name=%s&url=gui' % (ADDON_ID, que(BUILDNAME))
                    xbmc.executebuiltin('RunPlugin(%s)' % url)
                    self.close()
            if KODIV>=17 and KODIV<18:
                    wiz.ebi("PlayMedia(plugin://%s/?mode=install&name=%s&url=gui)" % (ADDON_ID, que(BUILDNAME))); wiz.log("[Installed Check] Guifix attempting to install")
                    self.close()
        def doRemindMeLater(self):
            # if not test == True:
                # wiz.setS("notedismiss","false")
            # wiz.log("[Notification] NotifyID %s Remind Me Later" % wiz.getS('noteid'), 5)
            self.close()

        def doDismiss(self):
            if test == True:
                wiz.setS("notedismiss","true")
            wiz.log("[Notification] NotifyID %s Dismissed" % wiz.getS('noteid'), 5)
            self.close()

        def onAction(self,action):
            if   action == ACTION_PREVIOUS_MENU:
                self.doRemindMeLater()
                if test == True:
                    xbmc.executebuiltin("ReloadSkin()")
            elif action == ACTION_NAV_BACK:
                self.doRemindMeLater()
                if test == True:
                    xbmc.executebuiltin("ReloadSkin()")
        def onClick(self, controlId):
            if (controlId == self.dismiss): 
                self.doRemindMeLater()
                if test == True:
                    xbmc.executebuiltin("ReloadSkin()")
            elif(controlId == self.show_info): 
               xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=205&url=www)")
               self.close()
            else: self.doFastupdate()
            
    xbmc.executebuiltin('Skin.SetString(headertexttype, %s)' % 'true' if HEADERTYPE == 'Text' else 'false')
    xbmc.executebuiltin('Skin.SetString(headerimagetype, %s)' % 'true' if HEADERTYPE == 'Image' else 'false')
    notify = MyWindow( "Infoupdate.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', msg=msg, test=test)
    notify.doModal()
    del notify



def updateWindow(name='Testing Window', current='1.0', new='1.1', icon=ICON, fanart=FANART):
    class MyWindow(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            self.name = 'Anonymous TV'#THEME3 % kwargs['name']
            self.current = kwargs['current']
            self.new = kwargs['new']
            self.icon = ICON#kwargs['icon']
            self.fanart = kwargs['fanart']
            self.msgupdate  = "עדכן לגירסה חדשה:\n[COLOR %s][/COLOR]\n v[COLOR %s]%s[/COLOR]:גירסה נוכחית\n v[COLOR %s]%s[/COLOR]:גירסה חדשה\n\n[COLOR %s] [/COLOR]" % (COLOR1, COLOR1, self.current, COLOR1, self.new, COLOR1)
            self.msgcurrent = "Running latest version of installed build:\n[COLOR %s]%s[/COLOR]\n\nCurrent Version: v[COLOR %s]%s[/COLOR]\nLatest Version: v[COLOR %s]%s[/COLOR]\n\n[COLOR %s]*Recommended: Fresh install[/COLOR]" % (COLOR1, self.name, COLOR1, self.current, COLOR1, self.new, COLOR1)
        
        def onInit(self):
            self.imagefanart = 101
            self.header      = 102
            self.textbox     = 103
            self.imageicon   = 104
            self.fresh       = 201
            self.normal      = 202
            self.ignore      = 203
            self.save        = 204
            self.showdialog()

        def showdialog(self):
            self.getControl(self.header).setLabel(self.name)
            self.getControl(self.textbox).setText(THEME2 % self.msgupdate if current < new else self.msgcurrent)
            self.getControl(self.imagefanart).setImage(self.fanart)
            self.getControl(self.imagefanart).setColorDiffuse('2FFFFFFF')
            self.getControl(self.imageicon).setImage(self.icon)
            self.setFocusId(self.fresh)

        def doFreshInstall(self):

            wiz.setS('lastbuildcheck', str(NEXTCHECK))
            self.close()
            url = 'plugin://%s/?mode=install&name=%s&url=fresh' % (ADDON_ID, que(BUILDNAME))
            xbmc.executebuiltin('RunPlugin(%s)' % url)

        def doNormalInstall(self):
            ADDON.openSettings()


        def doSavedata(self):
            xbmc.executebuiltin( "ActivateWindow(10001,plugin://plugin.program.Anonymous/?mode=savedata,return)" )
            self.close()
        def doIgnore(self):

            wiz.setS('lastbuildcheck', str(THREEDAYS))
            self.close()

        def onAction(self,action):
            if   action == ACTION_PREVIOUS_MENU: self.doIgnore()
            elif action == ACTION_NAV_BACK: self.doIgnore()

        def onClick(self, controlId):
            if   (controlId == self.fresh): self.doFreshInstall()
            elif (controlId == self.normal): self.doNormalInstall()
            elif (controlId == self.save): self.doSavedata()
            else: self.doIgnore()

    update = MyWindow( "BuildUpdate.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', name=name, current=current, new=new, icon=icon, fanart=fanart)
    update.doModal()
    del update