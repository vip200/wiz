import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs,urllib,re,time,json
import shutil,logging,platform,base64
import uservar
from resources.libs import wizard as wiz
translatepath=xbmcvfs.translatePath
ADDON_ID         = uservar.ADDON_ID
ADDON            = wiz.addonId(ADDON_ID)
HOME             = translatepath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
USERDATA         = os.path.join(HOME,      'userdata')
PACKAGES         = os.path.join(ADDONS,    'packages')
ADDOND           = os.path.join(USERDATA,  'addon_data')
THUMBS           = os.path.join(USERDATA,  'Thumbnails')
DATABASE         = os.path.join(USERDATA,  'Database')
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2

ADDONTITLE     = uservar.ADDONTITLE



def resetkodi():
    if xbmc.getCondVisibility('system.platform.windows'):
        DP = xbmcgui.DialogProgress()
        DP.create("ההתקנה תסגר אוטומטית", "אנא המתן 5 שניות"+'\n'+ ''+'\n'+
        "[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")
        DP.update(0)
        for s in range(5, -1, -1):
            time.sleep(1)
            try:
                DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר", 'בעוד {0} שניות'.format(s), '')
            except:
                DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n'+ '[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')
            if DP.iscanceled():
                from resources.libs import win
                return None, None
        from resources.libs import win
    else:
        DP = xbmcgui.DialogProgress()
        DP.create("ההתקנה תסגר אוטומטית", 
        "[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")
        DP.update(0)
        for s in range(5, -1, -1):
            time.sleep(1)
            DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n'+ '[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')
            if DP.iscanceled():
                from resources.libs import android
                return None, None
        from resources.libs import android



def set_fastupdate_date():
    try:
        setting_file=os.path.join(translatepath("special://home/"),"addons","skin.anonymoustv","xml","fastupdate_date.xml")

        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()

        regex='<!-- 2 --><label>(.+?)</label>'
        up=re.compile(regex).findall(file_data)[0]
        update='תאריך עדכון מערכת: '+up
        wiz.setS("update",update)
    except:pass
def swapSkins():
    query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.anonymoustv"}, "id":1}'

    response = xbmc.executeJSONRPC(query)
    x = 0
    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
        x += 1
        xbmc.sleep(1)
    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
        xbmc.executebuiltin('SendClick(11)')

def clearCache():
		wiz.clearCache()
def clearThumb(type=None):
	latest = wiz.latestDB('Textures')
	if not type == None: choice = 1
	else: choice = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to delete the %s and Thumbnails folder?' % (COLOR2, latest), "They will repopulate on the next startup[/COLOR]", nolabel='[B][COLOR red]Don\'t Delete[/COLOR][/B]', yeslabel='[B][COLOR green]Delete Thumbs[/COLOR][/B]')
	if choice == 1:
		try: wiz.removeFile(os.join(DATABASE, latest))
		except: wiz.log('Failed to delete, Purging DB.'); wiz.purgeDb(latest)
		wiz.removeFolder(THUMBS)
	else: wiz.log('Clear thumbnames cancelled')
	wiz.redoThumbs()
def cleanfornewbuild():
		try:
			os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))
		except:
			pass
		try:
			os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))
		except:
			pass
		try:
			os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.idanplus","series.json"))
		except:
			pass
def totalClean():
    from sqlite3 import dbapi2 as database
    try:
        cacheFile=(translatepath("special://userdata/addon_data/") + 'service.subtitles.All_Subs/cache_f/sources.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        table=(['subs'])
        for t in table:
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'DarkSubs'),'[COLOR %s]מנקה מטמון כתוביות[/COLOR]' % COLOR2,1500)
                dbcur.execute("DROP TABLE IF EXISTS %s" % t)
                dbcur.execute("VACUUM")
                dbcon.commit()
    except:
        pass
    try:
        cacheFile=(translatepath("special://userdata/addon_data/") + 'plugin.video.telemedia/cache_f/sources.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        table=(['posters','tmdblist','pages','subs','cookies','posters_n','last_view'])
        for t in table:
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'DarkSubs'),'[COLOR %s]מנקה מטמון טלמדיה[/COLOR]' % COLOR2,1500)
                dbcur.execute("DROP TABLE IF EXISTS %s" % t)
                dbcur.execute("VACUUM")
                dbcon.commit()
    except:
        pass
    try:
        if wiz.getS("dragon") =='true':
            cacheFile=(translatepath("special://userdata/addon_data/") + 'plugin.video.dreamspeed/cache_f/sources.db')
            dbcon = database.connect(cacheFile)
            dbcur = dbcon.cursor()
            table=(['pages'])
            for t in table:
                    
                    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'DarkSubs'),'[COLOR %s]מנקה מטמון Dragon[/COLOR]' % COLOR2,1500)
                    dbcur.execute("DROP TABLE IF EXISTS %s" % t)
                    dbcur.execute("VACUUM")
                    dbcon.commit()
    except:
        pass
    xbmc.executebuiltin( "RunPlugin(plugin://plugin.video.cobra/?mode=clear_all_cache)" )
    wiz.clearCache()
    wiz.clearPackages('total')
    clearThumb('total')
    cleanfornewbuild()
    wiz.emptyfolder(ADDOND)
    wiz.emptyfolder(ADDONS)
    xbmc.executebuiltin( "RunPlugin(plugin://plugin.video.cobra/?mode=check_corrupt_databases_cache)" )
    xbmc.executebuiltin( "RunPlugin(plugin://plugin.video.cobra/?mode=clean_databases_cache)" )
def clearPackagesStartup():
    from datetime import date, datetime, timedelta
    TEMP=os.path.join(ADDONS,'temp')
    start = datetime.utcnow() - timedelta(minutes=3)
    file_count = 0; cleanupsize = 0
    if os.path.exists(PACKAGES):
        pack = os.listdir(PACKAGES)
        pack.sort(key=lambda f: os.path.getmtime(os.path.join(PACKAGES, f)))
        for item in pack:
            file = os.path.join(PACKAGES, item)
            lastedit = datetime.utcfromtimestamp(os.path.getmtime(file))
            # if lastedit <= start:
            if os.path.isfile(file):
                file_count += 1
                os.unlink(file)
            elif os.path.isdir(file): 
                try:
                    shutil.rmtree(file)
                except :pass
    if os.path.exists(TEMP):
        pack = os.listdir(TEMP)
        pack.sort(key=lambda f: os.path.getmtime(os.path.join(TEMP, f)))
        for item in pack:
            file = os.path.join(TEMP, item)
            lastedit = datetime.utcfromtimestamp(os.path.getmtime(file))
            # if lastedit <= start:
            if os.path.isfile(file):
                file_count += 1

                os.unlink(file)
            elif os.path.isdir(file): 

                # cleanfiles, cleanfold = cleanHouse(file)
                # file_count += cleanfiles + cleanfold
                try:
                    shutil.rmtree(file)
                except :pass
def checkUpdate():
	DISABLEUPDATE  = wiz.getS('disableupdate')
	BUILDNAME      = wiz.getS('buildname')
	BUILDVERSION   = wiz.getS('buildversion')
	link           = wiz.openURL(ld(BL))
	link=link.text.replace('\n','').replace('\r','').replace('\t','')
	match          = re.compile('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"' % BUILDNAME).findall(link)
	if len(match) > 0:
		version = match[0][0]
		icon    = match[0][1]
		fanart  = match[0][2]
		wiz.setS('latestversion', version)
		if version > BUILDVERSION:
			if DISABLEUPDATE == 'false':
				wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window" % (BUILDVERSION, version), 5)
				notify.updateWindow(BUILDNAME, BUILDVERSION, version, icon, fanart)
			else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled" % (BUILDVERSION, version), 5)
		else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s]" % (BUILDVERSION, version), 5)
	else: wiz.log("[Check Updates] ERROR: Unable to find build version in build text file", 5)

def fix_gui():
    setting_file=os.path.join(translatepath("special://userdata"),"guisettings.xml")
    file = open(setting_file, 'r', encoding='utf-8') 
    file_data4= file.read()
    file.close()
    try:
        regex4='<setting id="videoscreen.screenmode">(.+?)</setting>'
        m4=re.compile(regex4).findall(file_data4)[0]
        file = open(setting_file, 'w', encoding='utf-8') 
        file.write(file_data4.replace('<setting id="videoscreen.screenmode">%s</setting>'%m4,'<setting id="videoscreen.screenmode" default="true">DESKTOP</setting>'))
        file.close()
    except:pass
def backtokodi():
    import shutil
    KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    from shutil import copyfile

    if  KODIV >= 20: # קודי 20
        src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"),"20","guisettings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
        copyfile(src,dst)
        xbmc.sleep(200)
        fix_gui()
        xbmc.sleep(200)
    resetkodi()
    
    
    
def SetAddonDisables():
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"service.xbmc.versioncheck","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"game.controller.default","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"game.controller.keyboard","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"game.controller.mouse","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"game.controller.snes","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"metadata.artists.universal","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"metadata.album.universal","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"metadata.common.fanart.tv","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"metadata.themoviedb.org.python","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"metadata.tvshows.themoviedb.org.python","enabled":false}}'
    xbmc.executeJSONRPC(do_json)