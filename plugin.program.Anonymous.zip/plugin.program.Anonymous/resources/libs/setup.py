import json,os,xbmcvfs,uservar,sys,time,base64,xbmc,re,logging,xbmcgui,subprocess,hashlib,urllib,xbmcaddon,shutil

from resources.libs import wizard as wiz
from resources.libs import downloader

from resources.libs.wizard import user_info_Window
from resources.libs.main import set_fastupdate_date,clearPackagesStartup,fix_gui,resetkodi,SetAddonDisables

from resources.libs import extract, downloader,notify
from resources.libs.utils import remove_addons,tdlib,skin_dragon_set,skin_homeselect,backup_setting_file
import threading
from threading import Thread
from datetime import date, datetime, timedelta
from resources.libs.send import send_user_info,get_version_update
from shutil import copyfile
from resources.libs.device_id import get_device_id


import urllib.request
import urllib.error


TODAY            = date.today()
TOMORROW         = TODAY + timedelta(days=1)
THREEDAYS        = TODAY + timedelta(days=3)
ONEWEEK        = TODAY + timedelta(days=7)
MONTH        = TODAY - timedelta(days=2)
LASTONEWEEK        = TODAY - timedelta(days=7)
BUILDNAME        = wiz.getS('buildname')
EXCLUDES         = uservar.EXCLUDES
UPDATECHECK      = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
NEXTCHECK        = TODAY + timedelta(days=UPDATECHECK)
NOTIFICATION     = uservar.NOTIFICATION
ADDON_ID         = uservar.ADDON_ID
ADDON            = wiz.addonId(ADDON_ID)
HOME             = xbmcvfs.translatePath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
PACKAGES         = os.path.join(ADDONS,    'packages')
DP               = xbmcgui.DialogProgress()
DP2              = xbmcgui.DialogProgressBG()
VERSION          = wiz.addonInfo(ADDON_ID,'version')
que=urllib.parse.quote_plus

BUILDVERSION     = wiz.getS('buildversion')
BUILDLATEST      = wiz.getS('latestversion')
NOTIFY           = wiz.getS('notify')
NOTEDISMISS      = wiz.getS('notedismiss')
NOTEID           = wiz.getS('noteid')
try:
    NOTEID = int(NOTEID)
except (ValueError, TypeError):
    NOTEID = 0

KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])

reset_kodi_update = base64.b64decode('aHR0cDovL3YyMjAyNTA2MjgwNjE2MzUwNDMxLm1lZ2FzcnYuZGU6ODAwMC9rb2RpL3R4dC9yZXNldF9rb2RpLnhtbA==').decode('utf-8')


class Thread (threading.Thread):
   def __init__(self, target, *args):
    super().__init__(target=target, args=args)
   def run(self, *args):
      
      self._target(*self._args)
      return 0

def make_setting_file():
    try:
        setting_file=os.path.join(xbmcvfs.translatePath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")
        setting_file2=os.path.join(xbmcvfs.translatePath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")
        # try:

        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        if file_data =='':
                copyfile(setting_file2,setting_file)
                xbmc.sleep(500)
                # send_user_info('channel_block_build','קובץ הגדרות תוקן')
    except:pass


# BASE_URL = "http://localhost:5000"  # כתובת השרת שלך
BASE_URL = "http://v2202506280616350431.megasrv.de:5000"
def post_json(url, payload, headers=None):
    if headers is None:
        headers = {"Content-Type": "application/json"}
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            error_body = e.read().decode("utf-8")
            return json.loads(error_body)
        except Exception:
            return {"success": False, "message": f"שגיאת HTTP: {e.code}"}
    except urllib.error.URLError as e:
        return {"success": False, "message": f"שגיאת רשת: {e.reason}"}
    except Exception as e:
        return {"success": False, "message": f"שגיאה לא ידועה: {e}"}


def authenticate_user(username, password):
    url = f"{BASE_URL}/auth"
    payload = {
        "username": username,
        "password": password,
        "device_id": get_device_id()
    }

    data = post_json(url, payload)

    if data.get("success"):
        turkish = data.get("turkish", False)
        
        wiz.setS("user", username)
        wiz.setS("password", password)
        wiz.setS("device_id", get_device_id())
        wiz.setS("dragon", "true" if turkish else "false")
        xbmc.executebuiltin("Skin.SetBool(homemenunocustom4button,false)" if turkish else
                            "Skin.SetBool(homemenunocustom4button,true)")
        wiz.setS("date_user", data.get("date"))
        wiz.setS("device", str(data.get("max_devices")))
        check_user_date()
        return data.get("download_url"), data.get("download_update_url")

    else:
        message = data.get("message", "האימות נכשל")
        if message == 'המנוי פג תוקף':
            wiz.setS("date_user", data.get("date"))
            check_user_date()
        else:
            check_user_date()
        if BUILDNAME == " Kodi Premium":
            blacklist = data.get("blacklist", {})

            if get_device_id() in blacklist:
                
                wiz.setS("buildname", '')
                
                xbmcgui.Dialog().ok("שגיאה", message)
                freshStart('clear')
                send_user_info('channel_block_build','מכשיר הוסר על ידי המשתמש ונמחק')
                return resetkodi()
        if message == 'שם המשתמש נחסם':
            
            wiz.setS("buildname", '')
            
            xbmcgui.Dialog().ok("שגיאה", message)
            freshStart('clear')
            send_user_info('channel_block_build','האפליקציה נמחקה!')
            return resetkodi()
        

        # טיפול בשגיאות נפוצות
        if message == 'סיסמה שגויה':
            wiz.setS("password", '')
            send_user_info('channel_new_install','סיסמה שגויה: '+str(password))
        elif message == 'המשתמש לא נמצא':
            wiz.setS("user", '')
            send_user_info('channel_new_install','שם משתמש שגוי: '+str(username))


        # אם מדובר בריבוי מכשירים - אך המכשיר הנוכחי כבר קיים ברשימה, לא ניכנס לכאן
        if message.startswith('נרשמו יותר מדי מכשירים'):

            # תוספת בדיקה: אם המכשיר הנוכחי כבר ברשימת devices, נמשיך
            current_id = get_device_id()
            devices = data.get("devices") or []
            send_user_info('channel_block_build','נרשמו יותר מדי מכשירים')
            if current_id in devices:
                return data.get("download_url"), data.get("download_update_url")
            if not BUILDNAME:
                confirm = xbmcgui.Dialog().yesno(
                    "הגעת למספר מקסימלי של מכשירים",
                    "האם תרצה להסיר מכשיר אחר במקום זה?",
                    yeslabel="[B]כן[/B]", nolabel="[B]לא[/B]"
                )
                if confirm:
                # אחרת – נציע להסיר מכשיר
                    remove_selected_device(username, password)
                else:return None, None
        if message.startswith('המנוי שלך מוגבל כעת'):
                confirm = xbmcgui.Dialog().yesno(
                   '',
                    message,
                    yeslabel="[B]בחר מכשיר להסיר[/B]", nolabel="[B]יציאה[/B]"
                )
                if confirm:
                # אחרת – נציע להסיר מכשיר
                    remove_selected_device(username, password)
                else:
                    resetkodi()
                    return None, None
        # אם חסום – נציע להסיר מהרשימה השחורה
        if 'המכשיר הזה נחסם בתאריך' in message:
            
            devices = data.get("devices") or []
            max_devices = data.get("max_devices") or 0
            if len(devices) >= max_devices:
                confirm = xbmcgui.Dialog().yesno(
                    "מכשיר חסום",
                    "המכשיר הזה חסום.\nהאם תרצה להסיר מכשיר אחר במקום?",
                    yeslabel="[B]כן[/B]", nolabel="[B]לא[/B]"
                )
                if confirm:
                    remove_selected_device(username, password)
            else:
                unblacklist_by_id(username, password, get_device_id())
        xbmcgui.Dialog().ok("שגיאה", message)
        return None, None




def get_device_list(username, password):
    url = f"{BASE_URL}/list_devices"
    payload = {
        "username": username,
        "password": password
    }

    try:
        res = post_json(url, payload)  # ← תקין
        data = res  # ← תקין
        if data.get("success"):
            devices_data = data.get("devices", [])
            if isinstance(devices_data, dict):
                return [f"{dev_id} ({added})" for dev_id, added in devices_data.items()]
            else:
                return devices_data
        else:
            xbmcgui.Dialog().ok("שגיאה", data.get("message", "נכשל"))
            return []
    except Exception as e:
        xbmcgui.Dialog().ok("שגיאה", f"שגיאה: {e}")
        return []


def remove_selected_device(username, password):
    devices = get_device_list(username, password)
    if not devices:
        xbmcgui.Dialog().ok("אין מכשירים", "לא נמצאו מכשירים")
        return

    # צור מיפוי של תצוגה → device_id אמיתי
    device_map = {}
    for entry in devices:
        if "(" in entry:
            dev_id = entry.split(" (")[0].strip()
        else:
            dev_id = entry.strip()
        device_map[entry] = dev_id

    choice = xbmcgui.Dialog().select("בחר מכשיר להסרה", list(device_map.keys()))
    if choice == -1:
        return

    selected_text = list(device_map.keys())[choice]
    selected_device = device_map[selected_text]

    # הוספת שאלה לאישור
    confirm = xbmcgui.Dialog().yesno(
        "אישור הסרה",
        f"האם אתה בטוח שברצונך להסיר את המכשיר הבא?\n[COLOR gold]{selected_text}[/COLOR]\n[COLOR red]הסרת מכשיר זה תחסום את הגישה לאפליקציה[/COLOR]",
        yeslabel="[B]כן[/B]",
        nolabel="[B]לא[/B]"
    )
    if not confirm:
        return

    url = f"{BASE_URL}/logout"
    payload = {
        "username": username,
        "password": password,
        "device_id": selected_device
    }

    try:
        res = post_json(url, payload)
        xbmcgui.Dialog().ok("תוצאה", res.get("message", "בוצע"))
    except Exception as e:
        xbmcgui.Dialog().ok("שגיאה", f"שגיאה: {e}")




def select_blacklisted_device(username, password):
    url = f"{BASE_URL}/blacklist"
    payload = {"username": username, "password": password}
    try:
        res = post_json(url, payload)
        data = res
        if not data.get("success"):
            xbmcgui.Dialog().ok("שגיאה", data.get("message", "נכשל"))
            return

        devices = data.get("devices", [])
        if not devices:
            xbmcgui.Dialog().ok("ריק", "אין מכשירים ברשימה השחורה")
            return

        # מיפוי להצגת תיאור לעומת device_id אמיתי
        device_map = {}
        for entry in devices:
            dev_id = entry.split(" (")[0].strip()
            device_map[entry] = dev_id

        idx = xbmcgui.Dialog().select("בחר מכשיר להסרה מהרשימה השחורה", list(device_map.keys()))
        if idx == -1:
            return

        selected_device_id = list(device_map.values())[idx]
        unblacklist_by_id(username, password, selected_device_id)

    except Exception as e:
        xbmcgui.Dialog().ok("שגיאה", f"שגיאה: {e}")


def unblacklist_by_id(username, password, device_id):
    url = f"{BASE_URL}/unblacklist"
    payload = {
        "username": username,
        "password": password,
        "device_id": device_id
    }

    try:
        res = post_json(url, payload)
        data = res
        xbmcgui.Dialog().ok("תוצאה", data.get("message", "בוצע"))
    except Exception as e:
        xbmcgui.Dialog().ok("שגיאה", f"שגיאה: {e}")


def check_user_date():
    import datetime, os, re
    TODAY = datetime.date.today()

    userdate = wiz.getS("date_user")

    if not userdate:
        return

    try:
        day, month, year = map(int, userdate.split('.'))
        user_date = datetime.date(year, month, day)
    except Exception as e:
        send_user_info('channel_block_build', f"שגיאת תאריך: {str(e)}")
        return

    delta_days = (user_date - TODAY).days

    # 🔒 נעילה אם תוקף פג
    if  TODAY >= user_date:
        

        # if BUILDNAME == " Kodi Premium":
            # send_user_info('channel_block_build', 'מנוי הסתיים - התקנה פעילה')

        if not xbmc.Player().isPlaying():
            if os.path.exists(os.path.join(ADDONS, 'skin.anonymoustv')):
                setting_file = os.path.join(
                    xbmcvfs.translatePath("special://userdata"),
                    "addon_data", "skin.anonymoustv", "settings.xml"
                )
                try:
                    with open(setting_file, 'r', encoding='utf-8') as file:
                        file_data = file.read()
                    match = re.search(r'<setting id="username" type="bool">(true|false)</setting>', file_data)
                    if match and match.group(1) == 'false':
                        xbmc.executebuiltin("Skin.ToggleSetting(username)")
                        msg = 'תקופת המנוי הסתיימה,\nהמערכת לא תתעדכן יותר\n'
                        msg += 'לחידוש יש לפנות למנהלים' if wiz.getS('dragon') == 'true' else \
                               'לחידוש לשנה נוספת יש לסרוק את הברקוד\nאו לפנות בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]'
                        wiz.contact_wiz(msg)
                        xbmc.executebuiltin("ActivateWindow(home)")
                        xbmc.executebuiltin("ReloadSkin()")
                        send_user_info('channel_block_build', 'מנוי ננעל')
                except Exception:
                    pass

        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    # 🛑 התקנה חדשה ללא BUILDNAME
    if not  BUILDNAME and TODAY >= user_date:
        msg = 'החשבון לא פעיל, \nיש לפנות למנהלים' if wiz.getS('dragon') == 'true' else \
              'החשבון לא פעיל, \nיש לסרוק את הברקוד\nאו לפנות בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]'
        wiz.contact_wiz(msg)
        send_user_info('channel_block_build', 'מנוי הסתיים - התקנה חדשה')

    # 🟡 התראה כל יום בשבוע האחרון – רק פעם ביום
    if  0 < delta_days <= 7 and not xbmc.Player().isPlaying():
        today_str = TODAY.strftime("%d.%m.%Y")
        last_alert = wiz.getS("alert_date")

        if last_alert == today_str:
            return  # התראה כבר נשלחה היום

        wiz.setS("alert_date", today_str)  # עדכן תאריך שליחה

        expire_msg = f"תקופת המנוי שלכם תסתיים בתאריך: [COLOR red]{userdate}[/COLOR]"
        if BUILDNAME == " Kodi Premium":
            extra = 'לחידוש יש לפנות למנהלים.' if wiz.getS('dragon') == 'true' else \
                    'לחידוש לשנה נוספת יש לסרוק את הברקוד\nאו לפנות בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]'
            wiz.contact_wiz(f"{expire_msg}\n{extra}")
        wiz.LogNotify3(
            f"[COLOR yellow]המנוי שלך יסתיים בעוד {delta_days} ימים[/COLOR]",
            '[COLOR white]לחידוש יש לפנות ל: https://t.me/xbmc19[/COLOR]'
        )
        send_user_info('channel_block_build', f'התראת סיום מנוי בעוד {delta_days} ימים')


def open_skin():
    if len(wiz.getS('user'))<1:
        username = xbmcgui.Dialog().input("שם משתמש")
    else:
        username=wiz.getS('user')
    if len(wiz.getS('password'))<1:
        password = xbmcgui.Dialog().input("סיסמה", option=xbmcgui.ALPHANUM_HIDE_INPUT)
    else:
        password=wiz.getS('password')
    zip_url, update_zip_url = authenticate_user(username, password)
    if zip_url:
        xbmc.executebuiltin( "Skin.ToggleSetting(username)" )
        xbmc.executebuiltin( "ActivateWindow(home)" )
        send_user_info('channel_block_build', f'החשבון נפתח ועודכן: '+ str(wiz.getS("date_user")))
        xbmcgui.Dialog().ok("החשבון עודכן!", 'תאריך: '+ str(wiz.getS("date_user")))
        # wiz.setS("device_id",get_device_id())
    else:
       # if wiz.getS("device_id")==get_device_id() or wiz.getS("device_id")=='':
            send_user_info('channel_block_build', f'המנוי שלכם עדיין לא עודכן והוא הסתיים בתאריך: '+wiz.getS("date_user"))
            if wiz.getS('dragon')=='true':
            
                wiz.contact_wiz('המנוי שלכם עדיין לא עודכן והוא הסתיים בתאריך: '+wiz.getS("date_user")+' \nלחידוש יש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR ffe52b50]https://t.me/hedva45[/COLOR]\n ')
            else:
                wiz.contact_wiz('המנוי שלכם עדיין לא עודכן והוא הסתיים בתאריך: '+wiz.getS("date_user")+' \nלחידוש לשנה נוספת יש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR ffe52b50]https://t.me/xbmc19[/COLOR]\n ')
       # else:
            # wiz.contact_wiz('המכשיר נעול, \nלפתיחת הנעילה יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR ffe52b50]https://t.me/xbmc19[/COLOR]\n ')
def check_if_copy_build():

    if not wiz.getS("device_id")==get_device_id() and not wiz.getS("device_id")=='':

      if os.path.exists(os.path.join(ADDONS, 'skin.anonymoustv')):
            setting_file=os.path.join(xbmcvfs.translatePath("special://userdata"),"addon_data", "skin.anonymoustv","settings.xml")
            file = open(setting_file, 'r', encoding='utf-8') 
            file_data= file.read()
            file.close()
            regex='<setting id="username" type="bool(.+?)/setting>'
            m=re.compile(regex).findall(file_data)[0]
            if 'false' in m:
                 xbmc.executebuiltin( "Skin.ToggleSetting(username)" )
                 wiz.contact_wiz('התקנה לא חוקית, \nיש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')
                 xbmc.executebuiltin( "ActivateWindow(home)" )
                 xbmc.executebuiltin("ReloadSkin()")
                 send_user_info('channel_block_build','ניסיון העתקה - מנוי ננעל')



def buildWizard(name, type, theme=None, over=False):
    title = '[COLOR gold]AnonymousTV[/COLOR]'

    SetAddonDisables()

    if BUILDNAME:
        dialog = xbmcgui.Dialog()
        choice = dialog.yesno(
            'Anonymous TV',
            f"[COLOR white]הבילד כבר מותקן, האם תרצה להתקין אותו שוב?[/COLOR]",
            yeslabel="[B]כן[/B]",
            nolabel="[B]לא[/B]"
        )
        if not choice:
            return  # במקום sys.exit(), עדיף לא לצאת בכוח

    # קלט שם משתמש
    username = wiz.getS('user')
    if not username:
        username = xbmcgui.Dialog().input("שם משתמש", type=xbmcgui.INPUT_ALPHANUM)
        if not username or not username.strip():
            xbmcgui.Dialog().ok("שגיאה", "יש להזין שם משתמש")
            return

    # קלט סיסמה
    password = wiz.getS('password')
    if not password:
        password = xbmcgui.Dialog().input("סיסמה", option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not password or not password.strip():
            xbmcgui.Dialog().ok("שגיאה", "יש להזין סיסמה")
            return

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')

    zip_url, update_zip_url = authenticate_user(username, password)
    if not zip_url:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        return


    if zip_url:
        buildzip = zip_url
        wiz.LogNotify("[COLOR gold]Anonymous TV[/COLOR]", "[COLOR white]ההתקנה מתחילה, אנא המתן...[/COLOR]", 1500)
        send_user_info('channel_new_install', 'ההתקנה אושרה')

        try:
            freshStart(name)
        except Exception as e:
            send_user_info('channel_new_install', str(e))

        t = Thread(target=tdlib)
        t.setDaemon(True)
        td_thread = [t]

        zipname = "Build.zip"
        os.makedirs(PACKAGES, exist_ok=True)
        lib = os.path.join(PACKAGES, zipname)

        try:
            os.remove(lib)
        except FileNotFoundError:
            pass

        DP.create('Anonymous TV', '[B]Downloading[/B]\nPlease Wait')
        try:
            downloader.download(buildzip, lib, DP)
        except Exception as e:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            send_user_info('channel_new_install', str(e))
            wiz.LogNotify("[COLOR gold]Anonymous TV[/COLOR]", "[COLOR white]לא ניתן להתקין - קיימת תקלה.[/COLOR]", 1500)
            return

        if DP.iscanceled():
            DP.close()
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            return

        DP.update(0, f'{title}\n\nאנא המתן...')

        percent, errors, error = extract.all(lib, HOME, DP, title=title)

        if int(float(percent)) > 0:
            fast_update_first_build(NOTEID, update_zip_url)
            set_fastupdate_date()
            wiz.setS('buildname', name)
            wiz.setS('lastbuildcheck', str(NEXTCHECK))
            skin_homeselect()

            if wiz.getS('dragon') == 'true':
                skin_dragon_set()

            try:
                os.remove(lib)
            except FileNotFoundError:
                pass

            DP.close()
            backup_setting_file()

            for td in td_thread:
                td.start()

            stop_time = time.time() + 60
            while any(t.is_alive() for t in td_thread) and time.time() < stop_time:
                time.sleep(1)
                wiz.LogNotify("[COLOR gold]Anonymous TV[/COLOR]", "[COLOR white]מוריד קבצי הפעלה...[/COLOR]", 1500)

            fix_gui()
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            send_user_info('channel_install_is_done', 'התקין')
            wiz.LogNotify("[COLOR gold]Anonymous TV[/COLOR]", "[COLOR white]ההתקנה הסתיימה.[/COLOR]", 1500)
            resetkodi()

        else:
            
            DP.close()
            wiz.LogNotify("[COLOR gold]Anonymous TV[/COLOR]", "[COLOR white]ההתקנה אינה זמינה כעת, נסו שוב מאוחר יותר.[/COLOR]", 1500)
            send_user_info('channel_new_install', 'ההתקנה לא זמינה כעת, נסו שוב מאוחר יותר')
            return
def freshStart(install=None, over=False):
    xbmcPath=os.path.abspath(HOME)
    DP.create('Anonymous TV','אנא המתן...')
    total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0
    DP.update(0, "[COLOR %s]Gathering Excludes list." % 'white')
    EXCLUDES.append('My_Builds')
    EXCLUDES.append('archive_cache')
    EXCLUDES.append('plugin.video.elementum')
    EXCLUDES.append('script.elementum.burst')
    EXCLUDES.append('script.elementum.burst-master')
    EXCLUDES.append('skin.estuary')
    EXCLUDES.append('game.controller.default')
    EXCLUDES.append('game.controller.keyboard')
    EXCLUDES.append('game.controller.mouse')
    EXCLUDES.append('game.controller.snes')
    EXCLUDES.append('metadata.album.universal')
    EXCLUDES.append('metadata.artists.universal')
    EXCLUDES.append('metadata.common.fanart.tv')
    EXCLUDES.append('metadata.themoviedb.org.python')
    EXCLUDES.append('metadata.tvshows.themoviedb.org.python')
    EXCLUDES.append('service.xbmc.versioncheck')
    DP.update(0, "[COLOR yellow]מנקה קבצים ותיקיות, אנא המתן...[/COLOR]")
    latestAddonDB = wiz.latestDB('Addons')
    for root, dirs, files in os.walk(xbmcPath,topdown=True):
        dirs[:] = [d for d in dirs if d not in EXCLUDES]
        for name in files:
            del_file += 1
            fold = root.replace('/','\\').split('\\')
            x = len(fold)-1
            if name.endswith('.db'):
                try:
                    if name == latestAddonDB and KODIV >= 17: wiz.log("Ignoring %s on v%s" % (name, KODIV), 5)
                    else: os.remove(os.path.join(root,name))
                except Exception as e: 
                    if not name.startswith('Textures13'):
                        wiz.log('Failed to delete, Purging DB', 5)
                        wiz.log("-> %s" % (str(e)), 5)
                        wiz.purgeDb(os.path.join(root,name))
            else:

                try: os.remove(os.path.join(root,name))
                except Exception as e: 
                    wiz.log("Error removing %s" % os.path.join(root, name), 5)
                    wiz.log("-> / %s" % (str(e)), 5)
        if DP.iscanceled(): 
            DP.close()
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'), "[COLOR %s]ההתקנה מבוטלת[/COLOR]" % 'white',1500)
            sys.exit()
            return False
    for root, dirs, files in os.walk(xbmcPath,topdown=True):
        dirs[:] = [d for d in dirs if d not in EXCLUDES]
        for name in dirs:
          DP.update(100, 'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]' % ('gold', name))
          if name not in ["Database","userdata","temp","addons","addon_data"]:
             shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
        if DP.iscanceled(): 
            DP.close()
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'), "[COLOR %s]ההתקנה מבוטלת.[/COLOR]" % 'white',1500)
            sys.exit()
    DP.close()

def fast_update_first_build(NOTEID,update_zip_url):

    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create('Anonymous TV','[COLOR %s][B]מוריד עדכון אחרון[/B][/COLOR][COLOR %s][/COLOR]' % ('gold', "Last Update"))
    lib=os.path.join(PACKAGES,"Update.zip")
    downloader.download(update_zip_url, lib, DP)
    xbmc.sleep(100)
    namex= 'עדכון אחרון'
    title = '[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]' % ('white', 'gold', namex)
    DP.update(0, title+'\n'+''+'\n'+ 'אנא המתן')
    extract.all(lib,HOME,DP, title=title)
    DP.close()
    try: os.remove(lib)
    except: pass
    wiz.setS("notedismiss","true")
    id, msg = wiz.splitNotify(NOTIFICATION)
    if not id == False:
        try:
            id = int(id); NOTEID = int(NOTEID)
            wiz.setS("notedismiss","true")
            if id == NOTEID:
                wiz.log("[Notifications] id[%s] Dismissed" % int(id), 5)
            elif id > NOTEID:
                wiz.log("[Notifications] id: %s" % str(id), 5)
                wiz.setS('noteid', str(id))
                wiz.setS("notedismiss","true")
                wiz.log("[Notifications] Complete", 5)
        except Exception as e:
            wiz.setS("notedismiss","false")
            wiz.log("Error on Notifications Window: %s" % str(e), 5)




def checkidupdatetele(zip_url,info=''):
    remove_addons()
    zipname =  "Update.zip"
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    lib=os.path.join(PACKAGES, zipname )
    downloader.download_update(zip_url, lib, DP2)
    xbmc.sleep(100)
    DP2.create('[B][COLOR=green]מתקין                         [/COLOR][/B]')
    DP2.update(100, message='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')
    extract.all2(lib,HOME,DP2)
    DP2.close()
    wiz.kodi17Fix()
    wiz.setS("notedismiss","true")
    backup_setting_file()
    ver=get_version_update()
    try: os.remove(lib)
    except: pass
    if not wiz.getS('ver')==ver or info=='ידני: ':
        from urllib.request import urlopen
        thread=[]
        t = Thread(target=send_user_info, *('channel_fast_update', 'עדכון מערכת: ' + info))
        t.start()
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'),'[COLOR %s]המערכת עודכנה בהצלחה![/COLOR]' % 'white',1500)
        infobuild(True)
        wiz.setS('ver',ver)
        remote_file = urlopen(reset_kodi_update)
        x=remote_file.readlines()
        for us in x:
            if us.decode('utf-8')=="reset_on":
                resetkodi()
    else:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'),'[COLOR %s]הושלם.[/COLOR]' % 'white',1500)
        thread=[]
        t = Thread(target=send_user_info, *('channel_fast_update', 'עדכון מערכת ברקע: ' + info))
        t.start()
def force_update():
    DIALOG         = xbmcgui.Dialog()
    if  KODIV >= 20: # קודי 20
        choice = DIALOG.yesno('Anonymous TV', "האם לבצע עדכון מערכת?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
        if choice == 1:
            if len(wiz.getS('user'))<1:
                username = xbmcgui.Dialog().input("שם משתמש")
            else:
                username=wiz.getS('user')
            if len(wiz.getS('password'))<1:
                password = xbmcgui.Dialog().input("סיסמה", option=xbmcgui.ALPHANUM_HIDE_INPUT)
            else:
                password=wiz.getS('password')

            zip_url,update_zip_url = authenticate_user(username, password)
            
            if update_zip_url:

        
                xbmc.executebuiltin( "ActivateWindow(home)" )
                id, msg = wiz.splitNotify(NOTIFICATION)
                wiz.setS('noteid', str(id))
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'), "[COLOR %s]מוריד עדכון[/COLOR]" % 'white',1500)
                try:
                    checkidupdatetele(update_zip_url,'ידני: ')
                except Exception as e:
                    wiz.setS('notedismiss', 'false')
                    thread=[]
                    thread.append(Thread(send_user_info,'howsentlog','בעיה בהורדת עדכון מערכת ידני: '+str(e)))
                    thread[0].start()
                    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'),'[COLOR %s]עדכון המערכת נכשל.[/COLOR]' % 'white',1500)
                    logging.warning(e)
    else:
        DIALOG.ok('Anonymous TV', 'העדכון תומך רק מקודי 20 ומעלה' +'\n'+' גרסת הקודי שלך היא: '+str(KODIV)+'\n'+'עליך למחוק ולהתקין מחדש.')

def auto_build_update(NOTEID):
    try:
        clearPackagesStartup()
    except:pass
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    if not xbmc.Player().isPlaying():
        if BUILDNAME == " Kodi Premium" or os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'skin.Premium.mod')or os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'skin.anonymoustv'):
            wiz.wizardUpdate('startup')

            if len(wiz.getS('user'))<1:
                username = xbmcgui.Dialog().input("שם משתמש")
            else:
                username=wiz.getS('user')
            if len(wiz.getS('password'))<1:
                password = xbmcgui.Dialog().input("סיסמה", option=xbmcgui.ALPHANUM_HIDE_INPUT)
            else:
                password=wiz.getS('password')
            # check_if_copy_build()
            
            zip_url,update_zip_url = authenticate_user(username, password)
            if update_zip_url:
                # check_user_date()
                if not NOTIFY == 'true':
                    id, msg = wiz.splitNotify(NOTIFICATION)
                    if not id == False:
                        try:
                            id = int(id); NOTEID = int(NOTEID)
                            if id == NOTEID:
                                if NOTEDISMISS == 'false':

                                    checkidupdatetele(update_zip_url,'אוטומטי: ')# notify.notification(msg)
                                else: wiz.log("[Notifications] id[%s] Dismissed" % int(id), 5)
                            elif id > NOTEID:

                                wiz.setS('noteid', str(id))
                                wiz.setS('notedismiss', 'false')
                                
                                checkidupdatetele(update_zip_url,'אוטומטי: ')

                        except Exception as e:
                            wiz.log("Error on Notifications Window: %s" % str(e), 5)
                            wiz.setS('notedismiss', 'false')
                            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'),'[COLOR %s]עדכון המערכת נכשל.[/COLOR]' % 'white',1500)
                            thread=[]
                            thread.append(Thread(send_user_info,'howsentlog','בעיה בהורדת עדכון מערכת אוטומטי: '+str(e)))
                            thread[0].start()
                                


def infobuild(test=''):
    try:
        id, msg = wiz.splitNotify(NOTIFICATION)
        if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'), "[COLOR %s]אין עדכון מהיר[/COLOR]" % 'white',1500); return
        notify.updateinfo(msg, test)
    except Exception as e:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'), "[COLOR %s]אין עדכון מהיר[/COLOR]" % 'white',1500)
def infoupdate_busydialog(test=''):
    try:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        id, msg = wiz.splitNotify(NOTIFICATION)
        notify.updateinfo(msg, test)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    except Exception as e:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'), "[COLOR %s]אין מידע[/COLOR]" % 'white',1500)


def startup():
   try:
        send_user_info('channel_new_install','התקנה חדשה')
   except: 
        pass
        