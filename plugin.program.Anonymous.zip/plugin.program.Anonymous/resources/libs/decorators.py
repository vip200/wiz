# coding: utf-8
from functools import wraps
import xbmc,xbmcvfs
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
if KODI_VERSION<=18:
    translatepath=xbmc.translatePath
else:#קודי19
    translatepath=xbmcvfs.translatePath

def http_connection(timeout):
    # import requests
    import sys
    path1=translatepath('special://home/addons/script.module.requests/lib')
    sys.path.append( path1)
    path1=translatepath('special://home/addons/script.module.urllib3/lib')
    sys.path.append( path1)
    path1=translatepath('special://home/addons/script.module.chardet/lib')
    sys.path.append( path1)
    path1=translatepath('special://home/addons/script.module.certifi/lib')
    sys.path.append( path1)
    path1=translatepath('special://home/addons/script.module.idna/lib')
    sys.path.append( path1)
    path1=translatepath('special://home/addons/script.module.futures/lib')
    sys.path.append( path1)
    import requests
    """
    Decorator function that injects a requests.Session instance into
    the decorated function's actual parameters if not given.
    """
    def wrapper(f):
        def wrapped(*args, **kwargs):
            if not ('connection' in kwargs) or not kwargs['connection']:
                connection = requests.Session()
                kwargs['connection'] = connection
            else:
                connection = kwargs['connection']
            connection.timeout = timeout
            connection.headers.update({'Content-type': 'application/json'})
     
            return f(*args, **kwargs)
        return wraps(f)(wrapped)
    return wrapper
