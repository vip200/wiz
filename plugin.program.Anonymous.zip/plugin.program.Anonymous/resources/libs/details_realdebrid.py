# -*- coding: utf-8 -*-
"""
	My Accounts
"""

import json,xbmcaddon,xbmcgui,os,xbmcvfs,xbmc
from resources.libs import wizard as wiz
import requests,logging
# from myaccounts.modules import control
# from myaccounts.modules import log_utils

FormatDateTime = "%Y-%m-%dT%H:%M:%S.%fZ"
rest_base_url = 'https://api.real-debrid.com/rest/1.0/'
oauth_base_url = 'https://api.real-debrid.com/oauth/v2/'
device_code_url = 'device/code?%s'
credentials_url = 'device/credentials?%s'
rd_icon = ''#control.joinPath(control.artPath(), 'realdebrid.png')
if os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'script.module.myaccounts'):
    control=xbmcaddon.Addon('script.module.myaccounts')
    token = control.getSetting('realdebrid.token')
    client_ID = control.getSetting('realdebrid.client_id')
    secret = control.getSetting('realdebrid.secret')
elif os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'plugin.video.cobra'):
    control=xbmcaddon.Addon('plugin.video.cobra')
    token = control.getSetting('rd.token')
    client_ID = control.getSetting('rd.client_id')
    secret = control.getSetting('rd.secret')
dialog = xbmcgui.Dialog()

class RealDebrid:
	name = "Real-Debrid"

	def __init__(self):
		self.token = token
		self.client_ID = client_ID
		if self.client_ID == '':
			self.client_ID = 'X245A4XAIBGVM'
		self.secret = secret
		self.device_code = ''
		self.auth_timeout = 0
		self.auth_step = 0

	def _get(self, url, fail_check=False, token_ck=False):
		try:
			original_url = url
			url = rest_base_url + url
			if self.token == '':

				logging.warning('No Real Debrid Token Found')
				return None
			# if not fail_check: # with fail_check=True new token does not get added
			if '?' not in url:
				url += "?auth_token=%s" % self.token
			else:
				url += "&auth_token=%s" % self.token
			response = requests.get(url, timeout=15).json()
            
			if 'bad_token' in str(response) or 'Bad Request' in str(response):
				
				if not fail_check:

					if self.refresh_token() and token_ck:

						return
					response = self._get(original_url, fail_check=True)
			return response
		except Exception as e:
				logging.warning('_get: '+str(e))
		return None
	def set_points(self):

		x=requests.post("https://api.real-debrid.com/rest/1.0/settings/convertPoints/"+'?auth_token='+self.token)
		if x.status_code== 204:
			from datetime import datetime
			import time,re
			userInfo = self.account_info()
			expires = userInfo['expiration']
			regex='(.+?)T'
			m=re.compile(regex).findall(userInfo['expiration'])[0]
			Y, M, D = m.split('-')
			date = D+'.'+M+'.'+Y
			wiz.LogNotify('Anonymous TV','הושלם, חשבון RD מסתיים ב: '+date,8000)

		else:
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', x.json()),'[COLOR %s]רק מעל 1000 נקודות ניתן לממש[/COLOR]' % 'white',3500)

	def _post(self, url, data):
		original_url = url
		url = rest_base_url + url
		if self.token == '':

			logging.warning('No Real Debrid Token Found')
			return None
		if '?' not in url:
			url += "?auth_token=%s" % self.token
		else:
			url += "&auth_token=%s" % self.token
		response = requests.post(url, data=data, timeout=15).text
		if 'bad_token' in response or 'Bad Request' in response:
			self.refresh_token()
			response = self._post(original_url, data)
		elif 'error' in response:
			response = json.loads(response)

			return None
		try:
			return json.loads(response)
		except:
			return response

	def auth_loop(self):
		xbmc.sleep(500)
		url = 'client_id=%s&code=%s' % (self.client_ID, self.device_code)
		url = oauth_base_url + credentials_url % url
		response = json.loads(requests.get(url).text)
		if 'error' in response:
			return #
		else:
			try:

				self.client_ID = response['client_id']
				self.secret = response['client_secret']
			except Exception as e:
				logging.warning('auth_loop: '+str(e))


			return




	def account_info(self):
		return self._get('user')

	def account_info_to_dialog(self):
		from datetime import datetime
		import time,re,logging
		# try:
		if 1:
			userInfo = self.account_info()
			# logging.warning(userInfo)
			expires = userInfo['expiration']
			regex='(.+?)T'
			m=re.compile(regex).findall(userInfo['expiration'])[0]
			
			if userInfo['points']>=1000:
				xbmc.executebuiltin('Skin.SetString(points, true)')
				
			else:
				xbmc.executebuiltin('Skin.SetString(points, true)')#
				# xbmc.executebuiltin('Skin.SetString(points,)')

			Y, M, D = m.split('-')
			date = D+'.'+M+'.'+Y

			
			return 'מסתיים בתאריך: '+str(date),'נקודות: '+str(userInfo['points'])
		# except:
			# log_utils.error()
		return

	def refresh_token(self):
		try:

			self.client_ID = control.getSetting('rd.client_id')
			self.secret = control.getSetting('rd.secret')
			self.device_code = control.getSetting('rd.refresh')

			if not self.client_ID or not self.secret or not self.device_code: return False # avoid if previous refresh attempt revoked accnt, loops twice.
			logging.warning('Refreshing Expired Real Debrid Token: | %s | %s |' % (self.client_ID, self.device_code))

			success, error = self.get_token()

			if not success:
				if not 'Temporarily Down For Maintenance' in error:
					if any(value == error.get('error_code') for value in [9, 12, 13, 14]):
						self.revoke() # empty all auth settings to force a re-auth on next use


				logging.warning('Unable to Refresh Real Debrid Token: %s' % error.get('error'))
				return False
			else:

				logging.warning('Real Debrid Token Successfully Refreshed')
				return True
		except Exception as e:
			logging.warning('refresh_token: '+str(e))
			return False

	def get_token(self):
		try:
			url = oauth_base_url + 'token'
			postData = {'client_id': self.client_ID, 'client_secret': self.secret, 'code': self.device_code, 'grant_type': 'http://oauth.net/grant_type/device/1.0'}
			response = requests.post(url, data=postData)
			logging.warning('Authorizing Real Debrid Result: | %s |' % response)
			if '[204]' in str(response): return False, str(response)
			if 'Temporarily Down For Maintenance' in response.text:


				logging.warning('Real-Debrid Temporarily Down For Maintenance')
				return False, response.text
			else: response = response.json()

			if 'error' in str(response):
				logging.warning('response=%s' % str(response))

				message = response.get('error')

				logging.warning('Real-Debrid Error:  %s' % message)

				return False, response

			self.token = response['access_token']
			xbmc.sleep(500)
			account_info = self.account_info()
			username = account_info['username']
			control.setSetting('rd.username', username)
			control.setSetting('rd.client_id', self.client_ID)
			control.setSetting('rd.secret', self.secret,)
			control.setSetting('rd.token', self.token)
			control.setSetting('rd.refresh', response['refresh_token'])
			return True, None
		except Exception as e:
			logging.warning('Real Debrid Authorization Failed : '+str(e))
			return False, None

	def revoke(self):
		try:
			control.setSetting('realdebrid.client_id', '')
			control.setSetting('realdebrid.secret', '')
			control.setSetting('realdebrid.token', '')
			control.setSetting('realdebrid.refresh', '')
			control.setSetting('realdebrid.username', '')

		except Exception as e:
			logging.warning('revoke: '+str(e))