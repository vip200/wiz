# -*- coding: utf-8 -*-
"""
	My Accounts
"""

import json, xbmcaddon, xbmcgui, os, xbmcvfs, xbmc
from resources.libs import wizard as wiz
import urllib.request, urllib.parse, logging
from datetime import datetime
import time, re

FormatDateTime = "%Y-%m-%dT%H:%M:%S.%fZ"
rest_base_url = 'https://api.real-debrid.com/rest/1.0/'
oauth_base_url = 'https://api.real-debrid.com/oauth/v2/'
device_code_url = 'device/code?%s'
credentials_url = 'device/credentials?%s'
rd_icon = ''

if os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'script.module.myaccounts'):
    control = xbmcaddon.Addon('script.module.myaccounts')
    token = control.getSetting('realdebrid.token')
    client_ID = control.getSetting('realdebrid.client_id')
    secret = control.getSetting('realdebrid.secret')
elif os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'plugin.video.cobra'):
    control = xbmcaddon.Addon('plugin.video.cobra')
    token = control.getSetting('rd.token')
    client_ID = control.getSetting('rd.client_id')
    secret = control.getSetting('rd.secret')

dialog = xbmcgui.Dialog()


class RealDebrid:
    name = "Real-Debrid"

    def __init__(self):
        self.token = token
        self.client_ID = client_ID or 'X245A4XAIBGVM'
        self.secret = secret
        self.device_code = ''
        self.auth_timeout = 0
        self.auth_step = 0

    def _get(self, url, fail_check=False, token_ck=False):
        try:
            original_url = url
            url = rest_base_url + url
            if not self.token:
                logging.warning('No Real Debrid Token Found')
                return None
            sep = "&" if "?" in url else "?"
            url += f"{sep}auth_token={self.token}"
            with urllib.request.urlopen(url, timeout=15) as response:
                data = response.read().decode()
                result = json.loads(data)
                if 'bad_token' in data or 'Bad Request' in data:
                    if not fail_check:
                        if self.refresh_token() and token_ck:
                            return
                        return self._get(original_url, fail_check=True)
                return result
        except Exception as e:
            logging.warning('_get: ' + str(e))
            return None

    def _post(self, url, data):
        try:
            original_url = url
            url = rest_base_url + url
            sep = "&" if "?" in url else "?"
            url += f"{sep}auth_token={self.token}"
            encoded_data = urllib.parse.urlencode(data).encode()
            req = urllib.request.Request(url, data=encoded_data)
            with urllib.request.urlopen(req, timeout=15) as response:
                text = response.read().decode()
                if 'bad_token' in text or 'Bad Request' in text:
                    self.refresh_token()
                    return self._post(original_url, data)
                if 'error' in text:
                    return None
                return json.loads(text)
        except Exception as e:
            logging.warning('_post: ' + str(e))
            return None

    def auth_loop(self):
        xbmc.sleep(500)
        url = f'client_id={self.client_ID}&code={self.device_code}'
        url = oauth_base_url + credentials_url % url
        try:
            with urllib.request.urlopen(url) as response:
                data = json.loads(response.read().decode())
                if 'error' not in data:
                    self.client_ID = data.get('client_id', self.client_ID)
                    self.secret = data.get('client_secret', self.secret)
        except Exception as e:
            logging.warning('auth_loop: ' + str(e))

    def account_info(self):
        return self._get('user')

    def account_info_to_dialog(self):
        try:
            userInfo = self.account_info()
            expires = userInfo['expiration']
            m = re.findall('(.+?)T', expires)[0]
            if userInfo['points'] >= 1000:
                xbmc.executebuiltin('Skin.SetString(points, true)')
            else:
                xbmc.executebuiltin('Skin.SetString(points, true)')
            Y, M, D = m.split('-')
            date = f'{D}.{M}.{Y}'
            return f'מסתיים בתאריך: {date}', f'נקודות: {userInfo["points"]}'
        except Exception as e:
            logging.warning('account_info_to_dialog: ' + str(e))
            return

    def set_points(self):
        try:
            url = f"https://api.real-debrid.com/rest/1.0/settings/convertPoints/?auth_token={self.token}"
            req = urllib.request.Request(url, method="POST")
            with urllib.request.urlopen(req) as resp:
                if resp.status == 204:
                    userInfo = self.account_info()
                    m = re.findall('(.+?)T', userInfo['expiration'])[0]
                    Y, M, D = m.split('-')
                    date = f'{D}.{M}.{Y}'
                    wiz.LogNotify('Anonymous TV', 'הושלם, חשבון RD מסתיים ב: ' + date, 8000)
                    return
        except urllib.error.HTTPError as e:
            try:
                err = json.loads(e.read().decode())
                wiz.LogNotify("[COLOR gold]%s[/COLOR]" % err, '[COLOR white]רק מעל 1000 נקודות ניתן לממש[/COLOR]', 3500)
            except:
                pass

    def refresh_token(self):
        try:
            self.client_ID = control.getSetting('rd.client_id')
            self.secret = control.getSetting('rd.secret')
            self.device_code = control.getSetting('rd.refresh')
            if not self.client_ID or not self.secret or not self.device_code:
                return False
            logging.warning(f'Refreshing RD Token: | {self.client_ID} | {self.device_code} |')
            success, error = self.get_token()
            if not success:
                if error and not 'Temporarily Down For Maintenance' in error:
                    if error.get('error_code') in [9, 12, 13, 14]:
                        self.revoke()
                logging.warning('Unable to refresh RD token: ' + str(error))
                return False
            logging.warning('RD Token successfully refreshed')
            return True
        except Exception as e:
            logging.warning('refresh_token: ' + str(e))
            return False

    def get_token(self):
        try:
            url = oauth_base_url + 'token'
            postData = {
                'client_id': self.client_ID,
                'client_secret': self.secret,
                'code': self.device_code,
                'grant_type': 'http://oauth.net/grant_type/device/1.0'
            }
            encoded_data = urllib.parse.urlencode(postData).encode()
            req = urllib.request.Request(url, data=encoded_data)
            with urllib.request.urlopen(req) as response:
                resp_data = json.loads(response.read().decode())
                if 'error' in resp_data:
                    return False, resp_data
                self.token = resp_data['access_token']
                xbmc.sleep(500)
                account_info = self.account_info()
                username = account_info['username']
                control.setSetting('rd.username', username)
                control.setSetting('rd.client_id', self.client_ID)
                control.setSetting('rd.secret', self.secret)
                control.setSetting('rd.token', self.token)
                control.setSetting('rd.refresh', resp_data['refresh_token'])
                return True, None
        except Exception as e:
            logging.warning('get_token: ' + str(e))
            return False, None

    def revoke(self):
        try:
            for key in ['client_id', 'secret', 'token', 'refresh', 'username']:
                control.setSetting(f'realdebrid.{key}', '')
        except Exception as e:
            logging.warning('revoke: ' + str(e))
