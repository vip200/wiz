import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,zipfile ,json ,base64 #line:21
import shutil ,logging #line:22
import errno #line:23
import string #line:24
import random #line:25
import urllib #line:26
import re ,socket #line:27
import uservar #line:29
try :#line:30
  import downloader ,downloaderbg ,downloaderwiz ,extract ,skinSwitch #line:31
except :#line:32
  from resources .libs import downloader ,downloaderbg ,downloaderwiz ,extract ,skinSwitch #line:33
import time #line:35
from urllib .parse import quote #line:37
from urllib .parse import urlparse #line:38
from html .parser import HTMLParser #line:39
from urllib .request import urlopen #line:41
from urllib .request import Request #line:42
from datetime import date ,datetime ,timedelta #line:44
try :from sqlite3 import dbapi2 as database #line:45
except :from pysqlite2 import dbapi2 as database #line:46
from string import digits #line:47
try :#line:48
    from urllib .parse import quote_plus #line:49
except :pass #line:50
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:51
import zipfile #line:53
translatepath =xbmcvfs .translatePath #line:56
que =urllib .parse .quote_plus #line:58
url_encode =urllib .parse .urlencode #line:59
ADDON_ID =uservar .ADDON_ID #line:61
ADDONTITLE =uservar .ADDONTITLE #line:62
ADDON =xbmcaddon .Addon (ADDON_ID )#line:63
VERSION =ADDON .getAddonInfo ('version')#line:64
USER_AGENT ='Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'#line:65
DIALOG =xbmcgui .Dialog ()#line:66
DP =xbmcgui .DialogProgress ()#line:67
DP2 =xbmcgui .DialogProgressBG ()#line:68
HOME =translatepath ('special://home/')#line:69
XBMC =translatepath ('special://xbmc/')#line:70
LOG =translatepath ('special://logpath/')#line:71
PROFILE =translatepath ('special://profile/')#line:72
SOURCE =translatepath ('source://')#line:73
ADDONS =os .path .join (HOME ,'addons')#line:74
USERDATA =os .path .join (HOME ,'userdata')#line:75
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:76
PACKAGES =os .path .join (ADDONS ,'packages')#line:77
ADDOND =os .path .join (USERDATA ,'addon_data')#line:78
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:79
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:80
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:81
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:82
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:83
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:84
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:85
DATABASE =os .path .join (USERDATA ,'Database')#line:86
FANART =os .path .join (PLUGIN ,'fanart.jpg')#line:87
ICON =os .path .join (PLUGIN ,'icon.png')#line:88
ART =os .path .join (PLUGIN ,'resources','art')#line:89
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:90
WHITELIST =os .path .join (ADDONDATA ,'whitelist.txt')#line:91
QRCODES =os .path .join (ADDONDATA ,'QRCodes')#line:92
SKIN =xbmc .getSkinDir ()#line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
MONTH =TODAY -timedelta (days =2 )#line:99
LASTONEWEEK =TODAY -timedelta (days =7 )#line:100
EXCLUDES =uservar .EXCLUDES #line:101
APKFILE =uservar .APKFILE #line:102
YOUTUBEFILE =uservar .YOUTUBEFILE #line:103
ADDONFILE =uservar .ADDONFILE #line:104
ADVANCEDFILE =uservar .ADVANCEDFILE #line:105
AUTOUPDATE =uservar .AUTOUPDATE #line:106
WIZARDFILE =uservar .WIZARDFILE #line:107
NOTIFICATION =uservar .NOTIFICATION #line:108
NOTIFICATION2 =uservar .NOTIFICATION2 #line:109
NOTIFICATION3 =uservar .NOTIFICATION3 #line:110
ENABLE =uservar .ENABLE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOADDONXML =uservar .REPOADDONXML #line:113
REPOZIPURL =uservar .REPOZIPURL #line:114
CONTACT =uservar .CONTACT #line:115
COLOR1 =uservar .COLOR1 #line:116
COLOR2 =uservar .COLOR2 #line:117
HARDWAER =ADDON .getSetting ('action')#line:118
INCLUDEVIDEO =ADDON .getSetting ('includevideo')#line:119
INCLUDEALL =ADDON .getSetting ('includeall')#line:120
INCLUDEBOB =ADDON .getSetting ('includebob')#line:121
INCLUDEPHOENIX =ADDON .getSetting ('includephoenix')#line:122
INCLUDESPECTO =ADDON .getSetting ('includespecto')#line:123
INCLUDEGENESIS =ADDON .getSetting ('includegenesis')#line:124
INCLUDEEXODUS =ADDON .getSetting ('includeexodus')#line:125
INCLUDEONECHAN =ADDON .getSetting ('includeonechan')#line:126
INCLUDESALTS =ADDON .getSetting ('includesalts')#line:127
INCLUDESALTSHD =ADDON .getSetting ('includesaltslite')#line:128
SHOWADULT =ADDON .getSetting ('adult')#line:129
WIZDEBUGGING =ADDON .getSetting ('addon_debug')#line:130
DEBUGLEVEL =ADDON .getSetting ('debuglevel')#line:131
ENABLEWIZLOG =ADDON .getSetting ('wizardlog')#line:132
CLEANWIZLOG =ADDON .getSetting ('autocleanwiz')#line:133
CLEANWIZLOGBY =ADDON .getSetting ('wizlogcleanby')#line:134
CLEANDAYS =ADDON .getSetting ('wizlogcleandays')#line:135
CLEANSIZE =ADDON .getSetting ('wizlogcleansize')#line:136
CLEANLINES =ADDON .getSetting ('wizlogcleanlines')#line:137
INSTALLMETHOD =ADDON .getSetting ('installmethod')#line:138
DEVELOPER =ADDON .getSetting ('developer')#line:139
THIRDPARTY =ADDON .getSetting ('enable3rd')#line:140
THIRD1NAME =ADDON .getSetting ('wizard1name')#line:141
THIRD1URL =ADDON .getSetting ('wizard1url')#line:142
THIRD2NAME =ADDON .getSetting ('wizard2name')#line:143
THIRD2URL =ADDON .getSetting ('wizard2url')#line:144
THIRD3NAME =ADDON .getSetting ('wizard3name')#line:145
THIRD3URL =ADDON .getSetting ('wizard3url')#line:146
BUILDNAME =ADDON .getSetting ('buildname')#line:147
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:148
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:149
THEME3 =uservar .THEME3 #line:150
THEME2 =uservar .THEME2 #line:151
PS_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvd2l6LnVzZXIueG1s').decode ('utf-8')#line:152
US_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbmV3X3Bhc3MueG1s').decode ('utf-8')#line:153
BL_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbXlidWlsZDIueG1s').decode ('utf-8')#line:154
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:156
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:157
LOGFILES =['log','xbmc.old.log','kodi.log','kodi.old.log','spmc.log','spmc.old.log','tvmc.log','tvmc.old.log']#line:158
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:159
MAXWIZSIZE =[100 ,200 ,300 ,400 ,500 ,1000 ]#line:160
MAXWIZLINES =[100 ,200 ,300 ,400 ,500 ]#line:161
MAXWIZDATES =[1 ,2 ,3 ,7 ]#line:162
import threading #line:163
from threading import Thread #line:164
socket .setdefaulttimeout (10 )#line:165
class Thread (threading .Thread ):#line:168
   def __init__ (OO00OO0OO0OO0O0OO ,OO0O000000O0O000O ,*O00O0OO0OOOOO0OOO ):#line:169
    super ().__init__ (target =OO0O000000O0O000O ,args =O00O0OO0OOOOO0OOO )#line:170
   def run (OOO0O000O0O0O0O0O ,*OOO0O00OOO000000O ):#line:171
      OOO0O000O0O0O0O0O ._target (*OOO0O000O0O0O0O0O ._args )#line:173
      return 0 #line:174
def platform_d ():#line:179
    if xbmc .getCondVisibility ('system.platform.android'):return 'android'#line:180
    elif xbmc .getCondVisibility ('system.platform.linux'):return 'linux'#line:181
    elif xbmc .getCondVisibility ('system.platform.linux.Raspberrypi'):return 'linux'#line:182
    elif xbmc .getCondVisibility ('system.platform.windows'):return 'windows'#line:183
    elif xbmc .getCondVisibility ('system.platform.osx'):return 'osx'#line:184
    elif xbmc .getCondVisibility ('system.platform.atv2'):return 'atv2'#line:185
    elif xbmc .getCondVisibility ('system.platform.ios'):return 'ios'#line:186
    elif xbmc .getCondVisibility ('system.platform.darwin'):return 'ios'#line:187
def getS (OOOO00O0O0O00OO0O ):#line:188
    try :return ADDON .getSetting (OOOO00O0O0O00OO0O )#line:189
    except :return False #line:190
def setS (O0O0OOO0O00000O0O ,OO0OOO00OOOOOOO00 ):#line:192
    try :ADDON .setSetting (O0O0OOO0O00000O0O ,OO0OOO00OOOOOOO00 )#line:193
    except :return False #line:194
def openS (name =""):#line:196
    ADDON .openSettings ()#line:197
def clearS (O0OOO00000000O00O ):#line:199
    O000O0O0OOOOOOOO0 ={'buildname':'','buildversion':'','buildtheme':'','latestversion':'','lastbuildcheck':'2016-01-01'}#line:200
    OOOO0O0OOO0O0OOO0 ={'installed':'false','extract':'','errors':''}#line:201
    OO00O0O00O0O00OO0 ={'defaultskinignore':'false','defaultskin':'','defaultskinname':''}#line:202
    O00OO000OO0000OO0 =['default.enablerssfeeds','default.font','default.rssedit','default.skincolors','default.skintheme','default.skinzoom','default.soundskin','default.startupwindow','default.stereostrength']#line:203
    if O0OOO00000000O00O =='build':#line:204
        for O0OO00000OOO000OO in O000O0O0OOOOOOOO0 :#line:205
            setS (O0OO00000OOO000OO ,O000O0O0OOOOOOOO0 [O0OO00000OOO000OO ])#line:206
        for O0OO00000OOO000OO in OOOO0O0OOO0O0OOO0 :#line:207
            setS (O0OO00000OOO000OO ,OOOO0O0OOO0O0OOO0 [O0OO00000OOO000OO ])#line:208
        for O0OO00000OOO000OO in OO00O0O00O0O00OO0 :#line:209
            setS (O0OO00000OOO000OO ,OO00O0O00O0O00OO0 [O0OO00000OOO000OO ])#line:210
        for O0OO00000OOO000OO in O00OO000OO0000OO0 :#line:211
            setS (O0OO00000OOO000OO ,'')#line:212
    elif O0OOO00000000O00O =='default':#line:213
        for O0OO00000OOO000OO in OO00O0O00O0O00OO0 :#line:214
            setS (O0OO00000OOO000OO ,OO00O0O00O0O00OO0 [O0OO00000OOO000OO ])#line:215
        for O0OO00000OOO000OO in O00OO000OO0000OO0 :#line:216
            setS (O0OO00000OOO000OO ,'')#line:217
    elif O0OOO00000000O00O =='install':#line:218
        for O0OO00000OOO000OO in OOOO0O0OOO0O0OOO0 :#line:219
            setS (O0OO00000OOO000OO ,OOOO0O0OOO0O0OOO0 [O0OO00000OOO000OO ])#line:220
    elif O0OOO00000000O00O =='lookfeel':#line:221
        for O0OO00000OOO000OO in O00OO000OO0000OO0 :#line:222
            setS (O0OO00000OOO000OO ,'')#line:223
theme_nox ='https://zxcsd-3bae5-default-rtdb.firebaseio.com'#line:239
theme_dragon ='https://dragon-user-default-rtdb.firebaseio.com'#line:250
ACTION_PREVIOUS_MENU =10 #line:251
ACTION_NAV_BACK =92 #line:252
ACTION_MOVE_LEFT =1 #line:253
ACTION_MOVE_RIGHT =2 #line:254
ACTION_MOVE_UP =3 #line:255
ACTION_MOVE_DOWN =4 #line:256
ACTION_MOUSE_WHEEL_UP =104 #line:257
ACTION_MOUSE_WHEEL_DOWN =105 #line:258
ACTION_MOVE_MOUSE =107 #line:259
ACTION_SELECT_ITEM =7 #line:260
ACTION_BACKSPACE =110 #line:261
ACTION_MOUSE_LEFT_CLICK =100 #line:262
ACTION_MOUSE_LONG_CLICK =108 #line:263
def TextBox (O0OO0000OOOO0000O ,OO000O0O000O0OO0O ):#line:264
    class O0000O0000O0OO0OO (xbmcgui .WindowXMLDialog ):#line:265
        def onInit (O0000O0O00OO0OO00 ):#line:266
            O0000O0O00OO0OO00 .title =101 #line:267
            O0000O0O00OO0OO00 .msg =102 #line:268
            O0000O0O00OO0OO00 .scrollbar =103 #line:269
            O0000O0O00OO0OO00 .okbutton =201 #line:270
            O0000O0O00OO0OO00 .showdialog ()#line:271
        def showdialog (OOOOO00OO00OO0O00 ):#line:273
            OOOOO00OO00OO0O00 .getControl (OOOOO00OO00OO0O00 .title ).setLabel (O0OO0000OOOO0000O )#line:274
            OOOOO00OO00OO0O00 .getControl (OOOOO00OO00OO0O00 .msg ).setText (OO000O0O000O0OO0O )#line:275
            OOOOO00OO00OO0O00 .setFocusId (OOOOO00OO00OO0O00 .scrollbar )#line:276
        def onClick (O00OOOOO00O00OO0O ,OO0O00O00OOO0OOOO ):#line:278
            if (OO0O00O00OOO0OOOO ==O00OOOOO00O00OO0O .okbutton ):#line:279
                O00OOOOO00O00OO0O .close ()#line:280
        def onAction (O00O000OOO0OOOOOO ,O0OO0O000OO0OOO00 ):#line:282
            if O0OO0O000OO0OOO00 ==ACTION_PREVIOUS_MENU :O00O000OOO0OOOOOO .close ()#line:283
            elif O0OO0O000OO0OOO00 ==ACTION_NAV_BACK :O00O000OOO0OOOOOO .close ()#line:284
    O00000O0OOO0O0OOO =O0000O0000O0OO0OO ("Textbox.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =O0OO0000OOOO0000O ,msg =OO000O0O000O0OO0O )#line:286
    O00000O0OOO0O0OOO .doModal ()#line:287
    del O00000O0OOO0O0OOO #line:288
def ForceFastUpDate (OOO0OOO0O000O0OO0 ,OOO0O00OO00000O00 ,forceUpdate =False ):#line:289
    class O000OO0O0OO000OOO (xbmcgui .WindowXMLDialog ):#line:290
        def onInit (OOO0O0O0000O00O00 ):#line:291
            OOO0O0O0000O00O00 .title =101 #line:292
            OOO0O0O0000O00O00 .msg =102 #line:293
            OOO0O0O0000O00O00 .scrollbar =103 #line:294
            OOO0O0O0000O00O00 .okbutton =201 #line:295
            OOO0O0O0000O00O00 .updateP =202 #line:296
            OOO0O0O0000O00O00 .updateX =203 #line:297
            OOO0O0O0000O00O00 .showdialog ()#line:298
        def showdialog (O0O0O0OO0000000OO ):#line:300
            O0O0O0OO0000000OO .getControl (O0O0O0OO0000000OO .title ).setLabel (OOO0OOO0O000O0OO0 )#line:301
            O0O0O0OO0000000OO .getControl (O0O0O0OO0000000OO .msg ).setText (OOO0O00OO00000O00 )#line:302
            O0O0O0OO0000000OO .setFocusId (O0O0O0OO0000000OO .okbutton )#line:303
        def doupdateP (O00O00OOO000O0000 ):#line:304
            xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:305
            O00O00OOO000O0000 .close ()#line:306
        def doupdateX (O000O0OOO00O0O0O0 ):#line:307
            xbmc .executebuiltin ("RunPlugin(PlayMedia(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium+18&url=gui)")#line:308
            O000O0OOO00O0O0O0 .close ()#line:309
        def onClick (O0O0000000000000O ,O0O0O00O0000OO000 ):#line:310
            if (O0O0O00O0000OO000 ==O0O0000000000000O .okbutton ):#line:311
                O0O0000000000000O .close ()#line:312
            elif (O0O0O00O0000OO000 ==O0O0000000000000O .updateP ):O0O0000000000000O .doupdateP ()#line:313
            elif (O0O0O00O0000OO000 ==O0O0000000000000O .updateX ):O0O0000000000000O .doupdateX ()#line:315
        def onAction (O000O00O0OOOO0OOO ,O0OO0OOOO000O0O0O ):#line:317
            if O0OO0OOOO000O0O0O ==ACTION_PREVIOUS_MENU :O000O00O0OOOO0OOO .close ()#line:318
            elif O0OO0OOOO000O0O0O ==ACTION_NAV_BACK :O000O00O0OOOO0OOO .close ()#line:319
    OO0000OOO0OOOO000 =O000OO0O0OO000OOO ("FastUpDate.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =OOO0OOO0O000O0OO0 ,msg =OOO0O00OO00000O00 )#line:321
    OO0000OOO0OOOO000 .doModal ()#line:322
    del OO0000OOO0OOOO000 #line:323
def highlightText (O00OOOO0OO00OOO00 ):#line:325
    O00OOOO0OO00OOO00 =O00OOOO0OO00OOO00 .replace ('\n','[NL]')#line:326
    O000O0O0OO00OOO00 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00OOOO0OO00OOO00 )#line:327
    for OOOOOOO0OOOOOO0O0 in O000O0O0OO00OOO00 :#line:328
        OO000O000OOOO0O0O ='-->Python callback/script returned the following error<--%s-->End of Python script error report<--'%OOOOOOO0OOOOOO0O0 #line:329
        O00OOOO0OO00OOO00 =O00OOOO0OO00OOO00 .replace (OO000O000OOOO0O0O ,'[COLOR red]%s[/COLOR]'%OO000O000OOOO0O0O )#line:330
    O00OOOO0OO00OOO00 =O00OOOO0OO00OOO00 .replace ('WARNING','[COLOR yellow]WARNING[/COLOR]').replace ('ERROR','[COLOR red]ERROR[/COLOR]').replace ('[NL]','\n').replace (': Exception as e Thrown (PythonToCppException) :','[COLOR red]: Exception as e Thrown (PythonToCppException) :[/COLOR]')#line:331
    O00OOOO0OO00OOO00 =O00OOOO0OO00OOO00 .replace ('\\\\','\\').replace (HOME ,'')#line:332
    return O00OOOO0OO00OOO00 #line:333
def LogNotify (O0O000OOOOOO0OOO0 ,O000O0OO0O0O000OO ,times =1500 ,icon =ICON ,sound =False ):#line:335
    DIALOG .notification (O0O000OOOOOO0OOO0 ,O000O0OO0O0O000OO ,icon ,int (times ),sound )#line:336
def LogNotify2 (OO0O00OO0O000O0OO ,O00000O0OO00OO0O0 ,times =9000 ,icon =ICON ,sound =False ):#line:338
    DIALOG .notification (OO0O00OO0O000O0OO ,O00000O0OO00OO0O0 ,icon ,int (times ),sound )#line:339
def LogNotify3 (O000OO0O0O0OO0000 ,O00O0OO00O00O0O0O ,times =5000 ,icon =ICON ,sound =False ):#line:340
    DIALOG .notification (O000OO0O0O0OO0000 ,O00O0OO00O00O0O0O ,icon ,int (times ),sound )#line:341
def percentage (OO0OOO0O00OO00OO0 ,OOOOOO0OO0OOOO00O ):#line:342
    return 100 *float (OO0OOO0O00OO00OO0 )/float (OOOOOO0OO0OOOO00O )#line:343
def read_skin (OOO0O0O000OOOO00O ):#line:344
    from resources .libs import firebase #line:345
    firebase =firebase .FirebaseApplication (theme_nox ,None )#line:346
    OOOOOOO000000OO00 =firebase .get ('/',None )#line:347
    if OOO0O0O000OOOO00O in OOOOOOO000000OO00 :#line:348
        return OOOOOOO000000OO00 [OOO0O0O000OOOO00O ]#line:349
    else :#line:350
        return {}#line:351
def read_skin_dragon (OOOO0OOOOO00O0O00 ):#line:352
    from resources .libs import firebase #line:353
    firebase =firebase .FirebaseApplication (theme_dragon ,None )#line:354
    OO000OOO0OO00O0OO =firebase .get ('/',None )#line:355
    if OOOO0OOOOO00O0O00 in OO000OOO0OO00O0OO :#line:356
        return OO000OOO0OO00O0OO [OOOO0OOOOO00O0O00 ]#line:357
    else :#line:358
        return {}#line:359
PS ='&eJwFwUEKwCAMBMAfZe_-RkjQ0Balu6L09Z3p0mQBPFvKGOF9UBYL1_DEzq--Dh1hVtLOc__fqRL8$'#line:360
US ='&eJwFwVEKgEAIBcAb-f67TaCkVLjoW1r29M04OfoANK6gtJl6NsUm7tTAF_ssBRcx20rW-_zf9hME$'#line:361
BL ='&eJwFwUEOgCAMBMAfde_-RtNGNmIwdAnE1zNTpC8PwHlTlhFeWspi4GlOTP5nd2gJ12D1tPXWDQbwE8g=$'#line:362
def addonUpdates (do =None ):#line:363
    OO0O000OOOOOOO00O ='"general.addonupdates"'#line:364
    if do =='set':#line:365
        OO0OO000OOO0OOOO0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0O000OOOOOOO00O )#line:366
        OO000OOO00O0OOO0O =xbmc .executeJSONRPC (OO0OO000OOO0OOOO0 )#line:367
        OOOOO00OO00OOO000 =re .compile ('{"value":(.+?)}').findall (OO000OOO00O0OOO0O )#line:368
        if len (OOOOO00OO00OOO000 )>0 :OOOO0OO0OO0OO000O =OOOOO00OO00OOO000 [0 ]#line:369
        else :OOOO0OO0OO0OO000O =0 #line:370
        setS ('default.addonupdate',str (OOOO0OO0OO0OO000O ))#line:371
        OO0OO000OOO0OOOO0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0O000OOOOOOO00O ,'2')#line:372
        OO000OOO00O0OOO0O =xbmc .executeJSONRPC (OO0OO000OOO0OOOO0 )#line:373
    elif do =='reset':#line:374
        try :#line:375
            O00OO0O0OOOO0000O =int (float (getS ('default.addonupdate')))#line:376
        except :#line:377
            O00OO0O0OOOO0000O =0 #line:378
        if not O00OO0O0OOOO0000O in [0 ,1 ,2 ]:O00OO0O0OOOO0000O =0 #line:379
        OO0OO000OOO0OOOO0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0O000OOOOOOO00O ,O00OO0O0OOOO0000O )#line:380
        OO000OOO00O0OOO0O =xbmc .executeJSONRPC (OO0OO000OOO0OOOO0 )#line:381
dr ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNHPztSryM0BALmUEhk=$'#line:382
def ld (OOO000OO00OOO0O0O ):#line:387
    import base64 #line:388
    import zlib #line:389
    OO00O00O0000O0O0O =OOO000OO00OOO0O0O #line:390
    OO00O00O0000O0O0O .replace ('$','').replace ('&','')#line:391
    O00O00OOOO000OO00 =zlib .decompress (base64 .urlsafe_b64decode (OO00O00O0000O0O0O )).decode ('utf-8')#line:393
    return O00O00OOOO000OO00 #line:394
def checkBuild (OO00OO0OO0OO000O0 ,OOO0O000O00OO0OO0 ):#line:395
    if not workingURL (ld (BL ))==True :return False #line:402
    OOOOOO0OOOO0O0O00 =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:403
    OOOO000OO0OO000O0 ='160'#line:404
    if 'filesize'in OOOOOO0OOOO0O0O00 :#line:405
     O00O0OO0OO0O0O0OO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)".+?ilesize="(.+?)".+?pdatesize="(.+?)"'%OO00OO0OO0OO000O0 ).findall (OOOOOO0OOOO0O0O00 )#line:406
     if len (O00O0OO0OO0O0O0OO )>0 :#line:407
        for O0O00OO00O0OO000O ,OOOO00OO0OO0OO00O ,O0000O0O0O0O000OO ,O0O0000O0OO0O00O0 ,OO0OOOO0OOOOO0000 ,OO000O00O0O0OOOO0 ,O0OO00O0OOO0O0O00 ,O000OO0OO00O0O0OO ,OOOOO0OOO000000OO ,OOO00O0000O0O00O0 ,OOOO000OO0OO000O0 ,OOOO0O0OOO0000O0O in O00O0OO0OO0O0O0OO :#line:409
            if OOO0O000O00OO0OO0 =='version':return O0O00OO00O0OO000O #line:411
            elif OOO0O000O00OO0OO0 =='url':return ld (OOOO00OO0OO0OO00O )#line:412
            elif OOO0O000O00OO0OO0 =='gui':return ld (O0000O0O0O0O000OO )#line:413
            elif OOO0O000O00OO0OO0 =='kodi':return O0O0000O0OO0O00O0 #line:414
            elif OOO0O000O00OO0OO0 =='theme':return OO0OOOO0OOOOO0000 #line:415
            elif OOO0O000O00OO0OO0 =='icon':return OO000O00O0O0OOOO0 #line:416
            elif OOO0O000O00OO0OO0 =='fanart':return O0OO00O0OOO0O0O00 #line:417
            elif OOO0O000O00OO0OO0 =='preview':return O000OO0OO00O0O0OO #line:418
            elif OOO0O000O00OO0OO0 =='adult':return OOOOO0OOO000000OO #line:419
            elif OOO0O000O00OO0OO0 =='description':return OOO00O0000O0O00O0 #line:420
            elif OOO0O000O00OO0OO0 =='filesize':return OOOO000OO0OO000O0 #line:421
            elif OOO0O000O00OO0OO0 =='updatesize':return OOOO0O0OOO0000O0O #line:422
            elif OOO0O000O00OO0OO0 =='all':return OO00OO0OO0OO000O0 ,O0O00OO00O0OO000O ,ld (OOOO00OO0OO0OO00O ),ld (O0000O0O0O0O000OO ),O0O0000O0OO0O00O0 ,OO0OOOO0OOOOO0000 ,OO000O00O0O0OOOO0 ,O0OO00O0OOO0O0O00 ,O000OO0OO00O0O0OO ,OOOOO0OOO000000OO ,OOO00O0000O0O00O0 ,OOOO0O0OOO0000O0O ,OOOO000OO0OO000O0 #line:423
     else :return False #line:424
    else :#line:425
     O00O0OO0OO0O0O0OO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00OO0OO0OO000O0 ).findall (OOOOOO0OOOO0O0O00 )#line:427
     if len (O00O0OO0OO0O0O0OO )>0 :#line:428
        for O0O00OO00O0OO000O ,OOOO00OO0OO0OO00O ,O0000O0O0O0O000OO ,O0O0000O0OO0O00O0 ,OO0OOOO0OOOOO0000 ,OO000O00O0O0OOOO0 ,O0OO00O0OOO0O0O00 ,O000OO0OO00O0O0OO ,OOOOO0OOO000000OO ,OOO00O0000O0O00O0 in O00O0OO0OO0O0O0OO :#line:429
            if OOO0O000O00OO0OO0 =='version':return O0O00OO00O0OO000O #line:430
            elif OOO0O000O00OO0OO0 =='url':return ld (OOOO00OO0OO0OO00O )#line:431
            elif OOO0O000O00OO0OO0 =='gui':return ld (O0000O0O0O0O000OO )#line:432
            elif OOO0O000O00OO0OO0 =='kodi':return O0O0000O0OO0O00O0 #line:433
            elif OOO0O000O00OO0OO0 =='theme':return OO0OOOO0OOOOO0000 #line:434
            elif OOO0O000O00OO0OO0 =='icon':return OO000O00O0O0OOOO0 #line:435
            elif OOO0O000O00OO0OO0 =='fanart':return O0OO00O0OOO0O0O00 #line:436
            elif OOO0O000O00OO0OO0 =='preview':return O000OO0OO00O0O0OO #line:437
            elif OOO0O000O00OO0OO0 =='adult':return OOOOO0OOO000000OO #line:438
            elif OOO0O000O00OO0OO0 =='description':return OOO00O0000O0O00O0 #line:439
            elif OOO0O000O00OO0OO0 =='all':return OO00OO0OO0OO000O0 ,O0O00OO00O0OO000O ,ld (OOOO00OO0OO0OO00O ),ld (O0000O0O0O0O000OO ),O0O0000O0OO0O00O0 ,OO0OOOO0OOOOO0000 ,OO000O00O0O0OOOO0 ,O0OO00O0OOO0O0O00 ,O000OO0OO00O0O0OO ,OOOOO0OOO000000OO ,OOO00O0000O0O00O0 #line:440
            elif OOO0O000O00OO0OO0 =='filesize':return '587'#line:441
     else :return False #line:442
def no_u ():#line:443
       try :#line:444
          import json ,platform ,requests #line:445
          O0OO0000OOO0OO0OO =(ADDON .getSetting ("user"))#line:446
          O0OO000000O000000 =(ADDON .getSetting ("pass"))#line:447
          O0OO00O0O0O00O0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:448
          O00OOOOOOOO0000O0 =platform .uname ()#line:449
          O0000O0000OOO00O0 =O00OOOOOOOO0000O0 [1 ]#line:450
          OOO0O0O0OO0O0O0OO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUwMTAzMTU5OTM6QUFHNVJOaVdkTjRMZXB5VGdQNjFEb1JlTTg5SG9MeVVDdGcvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTY5NzU2NTc4OSZ0ZXh0PQ==').decode ('utf-8')#line:451
          O0O000O0O00O0O000 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:452
          O000OO00OOOOOOO0O =O0OO0000OOO0OO0OO #line:454
          OOO0000OOOO00O000 =O0OO000000O000000 #line:455
          O0OOOO00O00OOO0O0 =requests .get (OOO0O0O0OO0O0O0OO +que ('בעיה במנוי ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O000OO00OOOOOOO0O +que (' סיסמה: ')+OOO0000OOOO00O000 +que (' קודי: ')+O0OO00O0O0O00O0O0 +que (' כתובת: ')+O0O000O0O00O0O000 +que (' מערכת הפעלה: ')+platform_d ()+que (' שם המערכת: ')+O0000O0000OOO00O0 +que (' גירסת ויזארד: ')+VERSION ).json ()#line:457
       except :pass #line:459
def checkTheme (O00000000O0OO0O00 ,OOOO0000000O00O0O ,OOOO00OO000O00OOO ):#line:463
    OOO0000O0OO00O000 =checkBuild (O00000000O0OO0O00 ,'theme')#line:464
    if not workingURL (OOO0000O0OO00O000 )==True :return False #line:465
    O000O0OOO00O0OO0O =openURL (OOO0000O0OO00O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:466
    OOOO0O0OO00O00000 =re .compile ('name="%s".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult=(.+?).+?escription="(.+?)"'%OOOO0000000O00O0O ).findall (O000O0OOO00O0OO0O )#line:467
    if len (OOOO0O0OO00O00000 )>0 :#line:468
        for O0OO000OO0O0OO0O0 ,OO000O0000OOO000O ,OO0OOO000O0O0OOO0 ,OO0OOOO00OO0O0O0O ,OO00OOO00O0O00OOO in OOOO0O0OO00O00000 :#line:469
            if OOOO00OO000O00OOO =='url':return O0OO000OO0O0OO0O0 #line:470
            elif OOOO00OO000O00OOO =='icon':return OO000O0000OOO000O #line:471
            elif OOOO00OO000O00OOO =='fanart':return OO0OOO000O0O0OOO0 #line:472
            elif OOOO00OO000O00OOO =='adult':return OO0OOOO00OO0O0O0O #line:473
            elif OOOO00OO000O00OOO =='description':return OO00OOO00O0O00OOO #line:474
            elif OOOO00OO000O00OOO =='all':return O00000000O0OO0O00 ,OOOO0000000O00O0O ,O0OO000OO0O0OO0O0 ,OO000O0000OOO000O ,OO0OOO000O0O0OOO0 ,OO0OOOO00OO0O0O0O ,OO00OOO00O0O00OOO #line:475
    else :return False #line:476
def fix ():#line:477
    xbmc .executebuiltin ('UpdateLocalAddons()')#line:478
    xbmc .sleep (1000 )#line:479
    xbmc .executeJSONRPC ('{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":true}},"id":1}}'.format ('repository.gaia.2'))#line:480
def kilxz ():#line:481
  try :#line:482
    O000OOOOO0O0O0O00 =False #line:483
    import json ,platform ,requests #line:484
    OO00O0OO00O0O0OOO =(ADDON .getSetting ("user"))#line:485
    OOO0O000O0000OO0O =(ADDON .getSetting ("pass"))#line:486
    O000000O0O000OO00 =ld (dr )#line:487
    OOO0O0OO0O00O0O0O =urlopen (O000000O0O000OO00 )#line:488
    OO000O0OO00OOO0OO =OOO0O0OO0O00O0O0O .readlines ()#line:489
    OO000O0OO00OOO0OO =[OO00O0OOO00000OOO .rstrip ()for OO00O0OOO00000OOO in OO000O0OO00OOO0OO ]#line:490
    OOOO0OOO000OOOO00 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:491
    O0OOOO0OOOOO0O000 =platform .uname ()#line:493
    OO0000OOOO00O00OO =O0OOOO0OOOOO0O000 [1 ]#line:494
    OOOO00OOOO0OO0O0O =0 #line:495
    for OO0O00OOOO0O0O000 in OO000O0OO00OOO0OO :#line:496
        if OOOO0OOO000OOOO00 ==OO0O00OOOO0O0O000 .decode ('utf-8').split (' ==')[0 ]:#line:497
            OOOO00OOOO0OO0O0O =1 #line:498
            break #line:499
        if OO0000OOOO00O00OO ==OO0O00OOOO0O0O000 .decode ('utf-8').split (' ==')[0 ]:#line:500
            OOOO00OOOO0OO0O0O =1 #line:501
            break #line:502
        if OO0O00OOOO0O0O000 .decode ('utf-8').split (' ==')[0 ]==OO00O0OO00O0O0OOO or OO0O00OOOO0O0O000 .decode ('utf-8').split ()[0 ]==OO00O0OO00O0O0OOO or OO0O00OOOO0O0O000 .decode ('utf-8').split ()[0 ]==OOO0O000O0000OO0O :#line:503
            OOOO00OOOO0OO0O0O =1 #line:504
            break #line:505
    if OOOO00OOOO0OO0O0O ==0 :#line:506
       sys .exit ()#line:507
    else :#line:508
      Account_Send (que (' הוסר '),'')#line:509
      OO000OOO00OOO0OOO =os .path .join (HOME )#line:510
      if os .path .exists (OO000OOO00OOO0OOO ):#line:511
            for OOO0O0O0O0O00OOO0 ,O00O0O0OOO0O0O00O ,O0O00OOO0O00O0OOO in os .walk (OO000OOO00OOO0OOO ):#line:512
                for O0OO000OOOOOO0O0O in O0O00OOO0O00O0OOO :#line:513
                    try :#line:514
                        os .unlink (os .path .join (OOO0O0O0O0O00OOO0 ,O0OO000OOOOOO0O0O ))#line:515
                    except :pass #line:516
                for OOOO0OOOOO00OOO00 in O00O0O0OOO0O0O00O :#line:517
                    try :#line:518
                        shutil .rmtree (os .path .join (OOO0O0O0O0O00OOO0 ,OOOO0OOOOO00OOO00 ))#line:519
                    except :pass #line:520
  except :pass #line:521
def gdrive ():#line:522
    OO000O0OO0OOOOOO0 ='https://github.com/vip200/victory/blob/master/n.zip?raw=true'#line:523
    OOO0O0000O00O0000 =translatepath (os .path .join ('special://home/addons','packages'))#line:524
    O000OOOO00OO0OO00 =os .path .join (PACKAGES ,'isr.zip')#line:525
    OOOOO0000OO00OO00 =Request (OO000O0OO0OOOOOO0 )#line:526
    OOOO00OO00O0O0OO0 =urlopen (OOOOO0000OO00OO00 )#line:527
    OOO0O0O0O0O0000OO =open (O000OOOO00OO0OO00 ,'wb')#line:528
    try :#line:529
      OOO0OO0O0O00OO0OO =OOOO00OO00O0O0OO0 .info ().getheader ('Content-Length').strip ()#line:530
      OO0OO0O0000OOO00O =True #line:531
    except AttributeError :#line:532
          OO0OO0O0000OOO00O =False #line:533
    if OO0OO0O0000OOO00O :#line:534
          OOO0OO0O0O00OO0OO =int (OOO0OO0O0O00OO0OO )#line:535
    OO0OO000OO0OOO0OO =0 #line:536
    O0OOOOO0000OOO00O =time .time ()#line:537
    while True :#line:538
          O0O0OOOOOO0000O0O =OOOO00OO00O0O0OO0 .read (8192 )#line:539
          if not O0O0OOOOOO0000O0O :#line:540
              sys .stdout .write ('\n')#line:541
              break #line:542
          OO0OO000OO0OOO0OO +=len (O0O0OOOOOO0000O0O )#line:544
          OOO0O0O0O0O0000OO .write (O0O0OOOOOO0000O0O )#line:545
    O00O00OOO0O0OO00O =translatepath (os .path .join ('special://home/addons'))#line:547
    OOO0O0O0O0O0000OO .close ()#line:548
    O000O0OOO00O0O000 =zipfile .ZipFile (O000OOOO00OO0OO00 ,'r')#line:550
    O000O0OOO00O0O000 .extractall (O00O00OOO0O0OO00O )#line:551
    try :#line:553
      os .remove (O000OOOO00OO0OO00 )#line:554
    except :#line:555
      pass #line:556
    fix ()#line:558
def contact_wiz (msg =""):#line:559
    class O00OOOOOO000OO000 (xbmcgui .WindowXMLDialog ):#line:560
        def __init__ (O00O0000OOOO0O00O ,*O0OOOOO0OO0O0000O ,**OOOOO000000O00OOO ):#line:561
            O00O0000OOOO0O00O .title =THEME3 %OOOOO000000O00OOO ["title"]#line:562
            O00O0000OOOO0O00O .image =OOOOO000000O00OOO ["image"]#line:563
            O00O0000OOOO0O00O .fanart =OOOOO000000O00OOO ["fanart"]#line:564
            O00O0000OOOO0O00O .msg =THEME2 %OOOOO000000O00OOO ["msg"]#line:565
        def onInit (O0OOO000000O0OO0O ):#line:567
            O0OOO000000O0OO0O .fanartimage =101 #line:568
            O0OOO000000O0OO0O .titlebox =102 #line:569
            O0OOO000000O0OO0O .imagecontrol =103 #line:570
            O0OOO000000O0OO0O .textbox =104 #line:571
            O0OOO000000O0OO0O .scrollcontrol =105 #line:572
            O0OOO000000O0OO0O .closebutton =106 #line:573
            O0OOO000000O0OO0O .showdialog ()#line:574
        def showdialog (O000O000O0OOO000O ):#line:576
            O000O000O0OOO000O .getControl (O000O000O0OOO000O .imagecontrol ).setImage (O000O000O0OOO000O .image )#line:577
            O000O000O0OOO000O .getControl (O000O000O0OOO000O .fanartimage ).setImage (O000O000O0OOO000O .fanart )#line:578
            O000O000O0OOO000O .getControl (O000O000O0OOO000O .fanartimage ).setColorDiffuse ('9FFFFFFF')#line:579
            O000O000O0OOO000O .getControl (O000O000O0OOO000O .textbox ).setText (O000O000O0OOO000O .msg )#line:580
            O000O000O0OOO000O .getControl (O000O000O0OOO000O .titlebox ).setLabel (O000O000O0OOO000O .title )#line:581
            O000O000O0OOO000O .setFocusId (O000O000O0OOO000O .closebutton )#line:582
        def onClick (O0O0O00000O00O00O ,O0O0OO0OO0O000000 ):#line:583
            if O0O0OO0OO0O000000 ==O0O0O00000O00O00O .closebutton :O0O0O00000O00O00O .close ()#line:584
        def onAction (O0O0OO0O0OO000OOO ,OOO0000OOOOOO000O ):#line:585
            if OOO0000OOOOOO000O ==O0O0OO0O0OO000OOO .closebutton :O0O0OO0O0OO000OOO .close ()#line:586
            elif OOO0000OOOOOO000O ==ACTION_PREVIOUS_MENU :O0O0OO0O0OO000OOO .close ()#line:587
            elif OOO0000OOOOOO000O ==ACTION_NAV_BACK :O0O0OO0O0OO000OOO .close ()#line:588
    if getS ('dragon')=='true':#line:589
        OOOO0000O00O000O0 =O00OOOOOO000OO000 ("ContactDragon.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='Kodi Dragon',fanart =CONTACTFANART ,image =CONTACTICON ,msg =msg )#line:590
    else :#line:591
        OOOO0000O00O000O0 =O00OOOOOO000OO000 ("Contact.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='ANONYMOUS TV',fanart =CONTACTFANART ,image =CONTACTICON ,msg =msg )#line:592
    OOOO0000O00O000O0 .doModal ()#line:593
    del OOOO0000O00O000O0 #line:594
def user_info_Window (OO00OO0O0O0OO0O0O ,O0O0OOO00OOOO0O0O ,O0000000O0OOOOO00 ,OOO0OO0OO0O0OOO00 ,OOO000O000OOOOOOO ,OOO0OO0OOO000O0O0 ):#line:595
    class OOOO0OOO00OOO000O (xbmcgui .WindowXMLDialog ):#line:596
        def __init__ (OO000OO00O00OO0O0 ,*O00OO00OO0O0OO0OO ,**OOO00OO0000000O0O ):#line:597
            OO000OO00O00OO0O0 .title =THEME3 %OOO00OO0000000O0O ["title"]#line:598
            OO000OO00O00OO0O0 .image =OOO00OO0000000O0O ["image"]#line:599
            OO000OO00O00OO0O0 .fanart =OOO00OO0000000O0O ["fanart"]#line:600
            OO000OO00O00OO0O0 .tele =OOO00OO0000000O0O ["tele"]#line:601
            OO000OO00O00OO0O0 .update =OOO00OO0000000O0O ["update"]#line:602
            OO000OO00O00OO0O0 .rd =OOO00OO0000000O0O ["rd"]#line:603
            OO000OO00O00OO0O0 .userdate =OOO00OO0000000O0O ["userdate"]#line:604
            OO000OO00O00OO0O0 .username =OOO00OO0000000O0O ["username"]#line:605
            OO000OO00O00OO0O0 .device =OOO00OO0000000O0O ["device"]#line:606
        def onInit (OOO0O0O0OOOO00O00 ):#line:608
            OOO0O0O0OOOO00O00 .username_title =100 #line:609
            OOO0O0O0OOOO00O00 .fanartimage =101 #line:610
            OOO0O0O0OOOO00O00 .titlebox =102 #line:611
            OOO0O0O0OOOO00O00 .imagecontrol =103 #line:612
            OOO0O0O0OOOO00O00 .textbox =104 #line:613
            OOO0O0O0OOOO00O00 .scrollcontrol =105 #line:614
            OOO0O0O0OOOO00O00 .closebutton =106 #line:615
            OOO0O0O0OOOO00O00 .tele_title =107 #line:616
            OOO0O0O0OOOO00O00 .update_title =108 #line:617
            OOO0O0O0OOOO00O00 .rd_title =109 #line:618
            OOO0O0O0OOOO00O00 .device_cunt =110 #line:619
            OOO0O0O0OOOO00O00 .userdate_title =111 #line:620
            OOO0O0O0OOOO00O00 .showdialog ()#line:622
        def showdialog (O0O00O0O0OO0OOOO0 ):#line:624
            O0O00O0O0OO0OOOO0 .getControl (O0O00O0O0OO0OOOO0 .username_title ).setLabel (O0O00O0O0OO0OOOO0 .username )#line:625
            O0O00O0O0OO0OOOO0 .getControl (O0O00O0O0OO0OOOO0 .device_cunt ).setLabel (O0O00O0O0OO0OOOO0 .device )#line:626
            O0O00O0O0OO0OOOO0 .getControl (O0O00O0O0OO0OOOO0 .imagecontrol ).setImage (O0O00O0O0OO0OOOO0 .image )#line:628
            O0O00O0O0OO0OOOO0 .getControl (O0O00O0O0OO0OOOO0 .fanartimage ).setImage (O0O00O0O0OO0OOOO0 .fanart )#line:629
            O0O00O0O0OO0OOOO0 .getControl (O0O00O0O0OO0OOOO0 .fanartimage ).setColorDiffuse ('9FFFFFFF')#line:630
            O0O00O0O0OO0OOOO0 .getControl (O0O00O0O0OO0OOOO0 .tele_title ).setLabel (O0O00O0O0OO0OOOO0 .tele )#line:633
            O0O00O0O0OO0OOOO0 .getControl (O0O00O0O0OO0OOOO0 .update_title ).setLabel (O0O00O0O0OO0OOOO0 .update )#line:634
            O0O00O0O0OO0OOOO0 .getControl (O0O00O0O0OO0OOOO0 .rd_title ).setLabel (O0O00O0O0OO0OOOO0 .rd )#line:635
            O0O00O0O0OO0OOOO0 .getControl (O0O00O0O0OO0OOOO0 .userdate_title ).setLabel (O0O00O0O0OO0OOOO0 .userdate )#line:636
            O0O00O0O0OO0OOOO0 .setFocusId (O0O00O0O0OO0OOOO0 .closebutton )#line:638
        def onClick (O0OOOO0OO00O000OO ,OOO0O00OOO0O000O0 ):#line:640
            if OOO0O00OOO0O000O0 ==O0OOOO0OO00O000OO .closebutton :O0OOOO0OO00O000OO .close ()#line:641
        def onAction (O000O00000O0O0OOO ,OO0OO00OO0OOOOO00 ):#line:642
            if OO0OO00OO0OOOOO00 ==O000O00000O0O0OOO .closebutton :O000O00000O0O0OOO .close ()#line:643
            elif OO0OO00OO0OOOOO00 ==ACTION_PREVIOUS_MENU :O000O00000O0O0OOO .close ()#line:644
            elif OO0OO00OO0OOOOO00 ==ACTION_NAV_BACK :O000O00000O0O0OOO .close ()#line:645
    if getS ('dragon')=='true':#line:646
        OOOOOO00O0OOOOO0O =OOOO0OOO00OOO000O ("userinfoDragon.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='Kodi Dragon',fanart =CONTACTFANART ,image =CONTACTICON ,tele =OO00OO0O0O0OO0O0O ,userdate =OOO0OO0OO0O0OOO00 ,update =O0O0OOO00OOOO0O0O ,rd =O0000000O0OOOOO00 ,username =OOO000O000OOOOOOO ,device =OOO0OO0OOO000O0O0 )#line:647
    else :#line:648
        OOOOOO00O0OOOOO0O =OOOO0OOO00OOO000O ("userinfo.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='ANONYMOUS TV',fanart =CONTACTFANART ,image =CONTACTICON ,tele =OO00OO0O0O0OO0O0O ,userdate =OOO0OO0OO0O0OOO00 ,update =O0O0OOO00OOOO0O0O ,rd =O0000000O0OOOOO00 ,username =OOO000O000OOOOOOO ,device =OOO0OO0OOO000O0O0 )#line:649
    OOOOOO00O0OOOOO0O .doModal ()#line:650
    del OOOOOO00O0OOOOO0O #line:651
def req ():#line:652
    import sys #line:653
    OOOO000O00000O000 =translatepath ('special://home/addons/script.module.requests/lib')#line:654
    sys .path .append (OOOO000O00000O000 )#line:655
    OOOO000O00000O000 =translatepath ('special://home/addons/script.module.urllib3/lib')#line:656
    sys .path .append (OOOO000O00000O000 )#line:657
    OOOO000O00000O000 =translatepath ('special://home/addons/script.module.chardet/lib')#line:658
    sys .path .append (OOOO000O00000O000 )#line:659
    OOOO000O00000O000 =translatepath ('special://home/addons/script.module.certifi/lib')#line:660
    sys .path .append (OOOO000O00000O000 )#line:661
    OOOO000O00000O000 =translatepath ('special://home/addons/script.module.idna/lib')#line:662
    sys .path .append (OOOO000O00000O000 )#line:663
    OOOO000O00000O000 =translatepath ('special://home/addons/script.module.futures/lib')#line:664
    sys .path .append (OOOO000O00000O000 )#line:665
def getHwAddr (OO0OOOOOO0OOO0000 ):#line:666
   import subprocess ,time #line:667
   if xbmc .getCondVisibility ('system.platform.android'):#line:668
     OO00O00O000000000 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:669
     OO0OOOOO00OO0000O =re .compile ('link/ether (.+?) brd').findall (str (OO00O00O000000000 ))#line:670
     O0O0OOO00OO00O0OO =0 #line:671
     for O0OO0O0OOO0OO0O00 in OO0OOOOO00OO0000O :#line:672
      if OO0OOOOO00OO0000O !='00:00:00:00:00:00':#line:673
          OOO0O00O00OOOO00O =O0OO0O0OOO0OO0O00 #line:674
          O0O0OOO00OO00O0OO =O0O0OOO00OO00O0OO +int (OOO0O00O00OOOO00O .replace (':',''),16 )#line:675
          break #line:676
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:677
       OOOOO000O00O0OO00 =0 #line:678
       O0O0OOO00OO00O0OO =0 #line:679
       OOO0O000O0O00OO0O =[]#line:680
       OOOOO0OOOO00000OO =os .popen ("getmac").read ()#line:681
       OOOOO0OOOO00000OO =OOOOO0OOOO00000OO .split ("\n")#line:682
       for O000OOO0OOOO0O0OO in OOOOO0OOOO00000OO :#line:683
            OO0O00000OOO0O0O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O000OOO0OOOO0O0OO ,re .I )#line:684
            if OO0O00000OOO0O0O0 :#line:685
                OO0OOOOO00OO0000O =OO0O00000OOO0O0O0 .group ().replace ('-',':')#line:686
                OOO0O000O0O00OO0O .append (OO0OOOOO00OO0000O )#line:687
                O0O0OOO00OO00O0OO =O0O0OOO00OO00O0OO +int (OO0OOOOO00OO0000O .replace (':',''),16 )#line:688
                break #line:689
   elif xbmc .getCondVisibility ('system.platform.linux'):#line:690
       O0O0OOO00OO00O0OO =0 #line:691
       import uuid #line:692
       OO0OOOOO00OO0000O =hex (uuid .getnode ())#line:693
       O0O0OOO00OO00O0OO =O0O0OOO00OO00O0OO +int (OO0OOOOO00OO0000O .replace (':',''),16 )#line:694
   else :#line:695
       O0O0OOO00OO00O0OO =0 #line:696
       import uuid #line:697
       OO0OOOOO00OO0000O =hex (uuid .getnode ())#line:698
       O0O0OOO00OO00O0OO =O0O0OOO00OO00O0OO +int (OO0OOOOO00OO0000O .replace (':',''),16 )#line:699
   try :#line:714
    return O0O0OOO00OO00O0OO #line:715
   except :pass #line:716
def user_info ():#line:717
    xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:718
    OOO0O00000O00OOO0 =xbmcaddon .Addon ('plugin.video.telemedia')#line:719
    O00OOO0O000O00000 =OOO0O00000O00OOO0 .getSetting ('port')#line:720
    OO00OOOOOO0000000 =(ADDON .getSetting ("user"))#line:721
    O00O00OO0OOOOOOO0 =[]#line:722
    OOO0OO0OO00000O0O =[]#line:723
    O0OOO0O0O00OO0OO0 =[]#line:724
    try :#line:726
        OO00O00O00O000O0O =read_skin ('playback')#line:727
        OO000O0O0OOOOOOOO =read_skin_dragon ('playback')#line:728
        O0OOO0000O00000O0 =[OO00O00O00O000O0O ,OO000O0O0OOOOOOOO ]#line:729
        for OO00OOO0OOOO0O00O in O0OOO0000O00000O0 :#line:730
            for OO0OOOOO0000OO000 in OO00OOO0OOOO0O00O :#line:731
                O0O0OOOO0000O0OO0 =OO00OOO0OOOO0O00O [OO0OOOOO0000OO000 ]#line:732
                try :#line:733
                    OOO0OO0OO00000O0O .append ((O0O0OOOO0000O0OO0 ['name'],O0O0OOOO0000O0OO0 ['date'],O0O0OOOO0000O0OO0 ['sync'],O0O0OOOO0000O0OO0 ['dragon'],O0O0OOOO0000O0OO0 ['device'],O0O0OOOO0000O0OO0 ['rduser'],O0O0OOOO0000O0OO0 ['rdpass'],O0O0OOOO0000O0OO0 ['telegram_user'],O0O0OOOO0000O0OO0 ['p1'],O0O0OOOO0000O0OO0 ['p2'],O0O0OOOO0000O0OO0 ['p3']))#line:734
                except :#line:735
                    O0OOO0O0O00OO0OO0 .append ((O0O0OOOO0000O0OO0 ['name'],O0O0OOOO0000O0OO0 ['date'],O0O0OOOO0000O0OO0 ['sync'],O0O0OOOO0000O0OO0 ['dragon'],O0O0OOOO0000O0OO0 ['device']))#line:736
        for O00O0OO0O0O0OOO00 ,OOO00OO000OO00OOO ,OO00OOOOO0OOOO000 ,OO00OOOOOO00O000O ,OOO0OOO0O000O0O00 ,O00OOOO00000O0000 ,OO0O0OO00O0OO0O0O ,O0O000O0OO0O0OOO0 ,OO00OO0OO000O0OOO ,OOO00OOOO00OOO00O ,O000O00000OOO0OO0 in OOO0OO0OO00000O0O :#line:738
            if O00O0OO0O0O0OOO00 .split ()[0 ].lower ()==OO00OOOOOO0000000 :#line:740
                O0OO000OO00OO0OOO =1 #line:741
                setS ("date_user",OOO00OO000OO00OOO .replace (' ',''))#line:742
        for O00O0OO0O0O0OOO00 ,OOO00OO000OO00OOO ,OO00OOOOO0OOOO000 ,OO00OOOOOO00O000O ,OOO0OOO0O000O0O00 in O0OOO0O0O00OO0OO0 :#line:743
            if O00O0OO0O0O0OOO00 .split ()[0 ].lower ()==OO00OOOOOO0000000 :#line:745
                O0OO000OO00OO0OOO =1 #line:746
                setS ("date_user",OOO00OO000OO00OOO .replace (' ',''))#line:747
    except :pass #line:748
    try :#line:749
        import random #line:750
        import requests #line:752
        OO00000000O0OO00O =random .randint (1 ,1001 )#line:753
        O0O00OO00O0O0OOO0 ={'type':'td_send','info':json .dumps ({'@type':'getOption','name':'my_id','@extra':OO00000000O0OO00O })}#line:756
        OO0O0O00O00O0O0OO =requests .post ('http://127.0.0.1:%s/'%O00OOO0O000O00000 ,json =O0O00OO00O0O0OOO0 ).json ()#line:757
        O000OOO00OOO00000 =OO0O0O00O00O0O0OO ['value']#line:758
        if '1229060184'==O000OOO00OOO00000 or '838481324'==O000OOO00OOO00000 or '5667480303'==O000OOO00OOO00000 :#line:759
          OOO00O0O00O00O000 ='חשבון טלמדיה: VIP פעיל'#line:760
        else :#line:761
          OOO00O0O00O00O000 ='חשבון טלמדיה: אישי'#line:762
    except :#line:763
          OOO00O0O00O00O000 ='חשבון טלמדיה: אינו פעיל'#line:764
    if getS ('dragon')=='true':#line:765
        OO0O0O00OOO000OO0 ='תקופת המנוי ב Kodi Dragon תסתיים בתאריך: '+getS ("date_user")#line:766
    else :#line:767
        OO0O0O00OOO000OO0 ='תקופת המנוי Anonymous TV תסתיים בתאריך: '+getS ("date_user")#line:768
    OOOOOO0O000OOO0O0 =os .path .join (translatepath ("special://home/"),"addons","skin.Premium.mod","16x9","Includes_Home.xml")#line:769
    OOO00O00OO00OOO0O =open (OOOOOO0O000OOO0O0 ,'r',encoding ='utf-8')#line:771
    O00O0OOO00OOO0OO0 =OOO00O00OO00OOO0O .read ()#line:772
    OOO00O00OO00OOO0O .close ()#line:773
    OO00O00OOO00O0OO0 ='<!-- 2 --><label>(.+?)</label>'#line:775
    OOOOO00OOO00O0O00 =re .compile (OO00O00OOO00O0OO0 ).findall (O00O0OOO00OOO0OO0 )[0 ]#line:776
    O00O0O00OO0O000O0 =''#line:777
    if os .path .exists (translatepath ("special://home/addons/")+'plugin.video.kitana'):#line:778
        OOO0O00000O00OOO0 =xbmcaddon .Addon ('plugin.video.kitana')#line:779
        if len (OOO0O00000O00OOO0 .getSetting ('rd.token'))>0 :#line:781
            O00O0O00OO0O000O0 ='true'#line:782
    if O00O0O00OO0O000O0 =='true':#line:783
        try :#line:784
            O0O00O0OO0O00OO0O =OOO0O00000O00OOO0 .getSetting ('rd.auth')#line:785
            OOO0O00OOOOOOO00O ='https://api.real-debrid.com/rest/1.0/user?auth_token=%s'%O0O00O0OO0O00OO0O #line:786
            import requests #line:788
            OO00OO0OO00O0O000 =requests .get (OOO0O00OOOOOOO00O ,timeout =15 ).json ()#line:789
            OO00O00OOO00O0OO0 ='(.+?)T'#line:790
            OO0OO00O0OOO0O00O =re .compile (OO00O00OOO00O0OO0 ).findall (OO00OO0OO00O0O000 ['expiration'])[0 ]#line:791
            from datetime import datetime #line:792
            O0000O0000000O0OO ,OO000OO0OO00000OO ,OOO0OO0O0OOOO0O0O =OO0OO00O0OOO0O00O .split ('-')#line:793
            OOO00OO000OO00OOO =OOO0OO0O0OOOO0O0O +'.'+OO000OO0OO00000OO +'.'+O0000O0000000O0OO #line:794
            OOO0000000O0000OO ='שירות Real-Debrid פעיל ומסתיים בתאריך: '+str (OOO00OO000OO00OOO )#line:795
        except :#line:796
            OOO0000000O0000OO ='שירות Real-Debrid פעיל'#line:797
    else :#line:798
      OOO0000000O0000OO ='שירות Real-Debrid: אינו פעיל'#line:799
    O0000OOOOO000OO0O ='תאריך עדכון מערכת: '+OOOOO00OOO00O0O00 #line:800
    OOO0OOOOOO000OOOO ='שם משתמש: '+getS ('user')#line:802
    OOO0OOO0O000O0O00 ='כמות מכשירים: '+getS ("device")#line:805
    xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:806
    user_info_Window (OOO00O0O00O00O000 ,O0000OOOOO000OO0O ,OOO0000000O0000OO ,OO0O0O00OOO000OO0 ,OOO0OOOOOO000OOOO ,OOO0OOO0O000O0O00 )#line:808
TMDB_NEW_API =uservar .TMDB_NEW_API #line:809
def user_sync ():#line:810
    O0O0OO00O0O00O000 =getS ("sync_user")#line:811
    try :#line:812
        O0O00OO0O0OOOO000 =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:813
        O0O00OO0O0OOOO000 .setSetting ('firebase',O0O0OO00O0O00O000 )#line:814
    except :pass #line:816
    try :#line:817
        OO00OOO0O0OOOO0OO =xbmcaddon .Addon ('plugin.video.telemedia')#line:818
        OO00OOO0O0OOOO0OO .setSetting ('firebase',O0O0OO00O0O00O000 )#line:819
        OO00OOO0O0OOOO0OO .setSetting ('sync_mod','true')#line:820
    except :pass #line:821
    try :#line:822
        O00O000O0OO0OOOO0 =xbmcaddon .Addon ('plugin.video.mando')#line:823
        O00O000O0OO0OOOO0 .setSetting ('firebase',O0O0OO00O0O00O000 )#line:824
        O00O000O0OO0OOOO0 .setSetting ('sync_mod','true')#line:825
    except :pass #line:826
    try :#line:827
        OO0OO0O000OOO00O0 =xbmcaddon .Addon ('script.module.xtvsh')#line:828
        OO0OO0O000OOO00O0 .setSetting ('firebase',O0O0OO00O0O00O000 )#line:829
        OO0OO0O000OOO00O0 .setSetting ('sync_mod','true')#line:830
    except :pass #line:831
    try :#line:832
        O0O0000OOOO0OOO00 =xbmcaddon .Addon ('plugin.video.thorrent')#line:833
        O0O0000OOOO0OOO00 .setSetting ('firebase',O0O0OO00O0O00O000 )#line:834
        O0O0000OOOO0OOO00 .setSetting ('sync_mod','true')#line:835
    except :pass #line:836
    try :#line:837
        O000OOOOOOOOOOO00 =xbmcaddon .Addon ('context.myfav')#line:838
        O000OOOOOOOOOOO00 .setSetting ('firebase',O0O0OO00O0O00O000 )#line:839
        O000OOOOOOOOOOO00 .setSetting ('sync_mod','true')#line:840
    except :pass #line:841
def make_setting_file ():#line:844
    OOO00O0OO0O0OO000 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")#line:845
    OO0O0OOO0O00OOOO0 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")#line:846
    try :#line:847
        O00OO0000OOO0OO0O =open (OOO00O0OO0O0OO000 ,'r',encoding ='utf-8')#line:849
        OO0OOOO00OOO0O0OO =O00OO0000OOO0OO0O .read ()#line:850
        O00OO0000OOO0OO0O .close ()#line:851
        if OO0OOOO00OOO0O0OO =='':#line:852
                copyfile (OO0O0OOO0O00OOOO0 ,OOO00O0OO0O0OO000 )#line:854
    except :#line:855
       os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.program.Anonymous","settings.xml"))#line:856
def decode (OO00OO000OOOOO00O ,OO0OOO0O000O0OO0O ):#line:857
    import base64 #line:858
    O000O0OOOO00OO0OO =[]#line:859
    if (len (OO00OO000OOOOO00O ))!=4 :#line:861
     return 10 #line:862
    OO0OOO0O000O0OO0O =base64 .urlsafe_b64decode (OO0OOO0O000O0OO0O )#line:863
    for OOO00O00O000O0OOO in range (len (OO0OOO0O000O0OO0O )):#line:865
        O0O0O0O000O0O0OO0 =OO00OO000OOOOO00O [OOO00O00O000O0OOO %len (OO00OO000OOOOO00O )]#line:866
        try :#line:867
          OO0OO000O0OO00OOO =chr ((256 +ord (OO0OOO0O000O0OO0O [OOO00O00O000O0OOO ])-ord (O0O0O0O000O0O0OO0 ))%256 )#line:868
        except :#line:869
          OO0OO000O0OO00OOO =chr ((256 +(OO0OOO0O000O0OO0O [OOO00O00O000O0OOO ])-ord (O0O0O0O000O0O0OO0 ))%256 )#line:870
        O000O0OOOO00OO0OO .append (OO0OO000O0OO00OOO )#line:871
    return "".join (O000O0OOOO00OO0OO )#line:872
def checkWizard (O0000OO000O00O0OO ):#line:880
    if not workingURL (WIZARDFILE )==True :return False #line:881
    OOO0O000O0O0O0OO0 =openURL (WIZARDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:882
    OOOOO0OO0000OOO00 =re .compile ('id="%s".+?ersion="(.+?)".+?ip="(.+?)"'%ADDON_ID ).findall (OOO0O000O0O0O0OO0 )#line:883
    if len (OOOOO0OO0000OOO00 )>0 :#line:884
        for OOOO000000O0O0OOO ,OOOOO0OOOO000O00O in OOOOO0OO0000OOO00 :#line:885
            if O0000OO000O00O0OO =='version':return OOOO000000O0O0OOO #line:886
            elif O0000OO000O00O0OO =='zip':return OOOOO0OOOO000O00O #line:887
            elif O0000OO000O00O0OO =='all':return ADDON_ID ,OOOO000000O0O0OOO ,OOOOO0OOOO000O00O #line:888
    else :return False #line:889
def buildCount (ver =None ):#line:891
    O0OOOO0OOO0000O0O =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:892
    OO0OOOO000000OOO0 =re .compile ('name="(.+?)".+?odi="(.+?)".+?dult="(.+?)"').findall (O0OOOO0OOO0000O0O )#line:893
    OO00OOOO00O0O000O =0 ;OO0O0OO0O000000OO =0 ;OOOOOOO0O0OOO00OO =0 ;OO0OO000OOOO00000 =0 ;OO000OOOOOO0OOOO0 =0 ;OO0O000OO0O00O0O0 =0 ;O00O0OOOOOO000O00 =0 #line:894
    if len (OO0OOOO000000OOO0 )>0 :#line:895
        for OOO0OO000000OO000 ,OO0O0OO0OOO00O0OO ,OO0O0000O00O00OOO in OO0OOOO000000OOO0 :#line:896
            if not SHOWADULT =='true'and OO0O0000O00O00OOO .lower ()=='yes':OO0O000OO0O00O0O0 +=1 ;O00O0OOOOOO000O00 +=1 ;continue #line:897
            if not DEVELOPER =='true'and strTest (OOO0OO000000OO000 ):OO0O000OO0O00O0O0 +=1 ;continue #line:898
            OO0O0OO0OOO00O0OO =int (float (OO0O0OO0OOO00O0OO ))#line:899
            OO00OOOO00O0O000O +=1 #line:900
            if OO0O0OO0OOO00O0OO ==18 :OO000OOOOOO0OOOO0 +=1 #line:901
            elif OO0O0OO0OOO00O0OO ==17 :OO0OO000OOOO00000 +=1 #line:902
            elif OO0O0OO0OOO00O0OO ==16 :OOOOOOO0O0OOO00OO +=1 #line:903
            elif OO0O0OO0OOO00O0OO <=15 :OO0O0OO0O000000OO +=1 #line:904
    return OO00OOOO00O0O000O ,OO0O0OO0O000000OO ,OOOOOOO0O0OOO00OO ,OO0OO000OOOO00000 ,OO000OOOOOO0OOOO0 ,O00O0OOOOOO000O00 ,OO0O000OO0O00O0O0 #line:905
def strTest (OO000O00O0O0O0OO0 ):#line:907
    O0O00O000O0000O00 =(OO000O00O0O0O0OO0 .lower ()).split (' ')#line:908
    if 'test'in O0O00O000O0000O00 :return True #line:909
    else :return False #line:910
def themeCount (OO00O0OO0OO000OO0 ,count =True ):#line:912
    O0O0000OO0OOOOO0O =checkBuild (OO00O0OO0OO000OO0 ,'theme')#line:913
    if O0O0000OO0OOOOO0O =='http://':return False #line:914
    O000O0O0O00O00OOO =openURL (O0O0000OO0OOOOO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:915
    OO0O00000OOO00OOO =re .compile ('name="(.+?)".+?dult="(.+?)"').findall (O000O0O0O00O00OOO )#line:916
    if len (OO0O00000OOO00OOO )==0 :return False #line:917
    O00O00OO0OOOOO000 =[]#line:918
    for O0O0OOO00000OOO00 ,OOO00000OO00OOOO0 in OO0O00000OOO00OOO :#line:919
        if not SHOWADULT =='true'and OOO00000OO00OOOO0 .lower ()=='yes':continue #line:920
        O00O00OO0OOOOO000 .append (O0O0OOO00000OOO00 )#line:921
    if len (O00O00OO0OOOOO000 )>0 :#line:922
        if count ==True :return len (O00O00OO0OOOOO000 )#line:923
        else :return O00O00OO0OOOOO000 #line:924
    else :return False #line:925
def thirdParty (url =None ):#line:927
    if url ==None :return #line:928
    O00OOO0O0OOOO00OO =openURL (url ).replace ('\n','').replace ('\r','').replace ('\t','')#line:929
    O0OOOOO000O0O000O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?odi="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OOO0O0OOOO00OO )#line:930
    O0O0O00OO0OO00O00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00OOO0O0OOOO00OO )#line:931
    if len (O0OOOOO000O0O000O )>0 :#line:932
        return True ,O0OOOOO000O0O000O #line:933
    elif len (O0O0O00OO0OO00O00 )>0 :#line:934
        return False ,O0O0O00OO0OO00O00 #line:935
    else :#line:936
        return False ,[]#line:937
def workingURL (OOO0O00O00OO0O00O ):#line:943
    if OOO0O00O00OO0O00O in ['http://','https://','']:return False #line:944
    O00OO0OO0O00O0OO0 =0 ;O000O00OO0OOOOO00 =''#line:945
    while O00OO0OO0O00O0OO0 <3 :#line:946
        O00OO0OO0O00O0OO0 +=1 #line:947
        try :#line:948
            O00000OO00O00OOOO =Request (OOO0O00O00OO0O00O )#line:949
            O00000OO00O00OOOO .add_header ('User-Agent',USER_AGENT )#line:950
            OOOO0O00OO000O0O0 =urlopen (O00000OO00O00OOOO )#line:951
            OOOO0O00OO000O0O0 .close ()#line:952
            O000O00OO0OOOOO00 =True #line:953
            break #line:954
        except Exception as OO0OOO0O00OO0OOO0 :#line:955
            O000O00OO0OOOOO00 =str (OO0OOO0O00OO0OOO0 )#line:956
            log ("Working Url Error: %s [%s]"%(OO0OOO0O00OO0OOO0 ,OOO0O00O00OO0O00O ))#line:957
            xbmc .sleep (500 )#line:958
    return O000O00OO0OOOOO00 #line:959
def openURL (O0OOOOOO00O00O0OO ):#line:961
    O0OOO00O0O00OOO0O =Request (O0OOOOOO00O00O0OO )#line:962
    O0OOO00O0O00OOO0O .add_header ('User-Agent',USER_AGENT )#line:963
    OO00OO000OO0O00O0 =urlopen (O0OOO00O0O00OOO0O )#line:964
    OOOOOO0OOO00O0O00 =OO00OO000OO0O00O0 .read ()#line:965
    OO00OO000OO0O00O0 .close ()#line:966
    return OOOOOO0OOO00O0O00 .decode ('utf-8')#line:968
def getKeyboard (default ="",heading ="",hidden =False ):#line:973
    OO0OOO00O0O0OOO0O =xbmc .Keyboard (default ,heading ,hidden )#line:974
    OO0OOO00O0O0OOO0O .doModal ()#line:975
    if OO0OOO00O0O0OOO0O .isConfirmed ():#line:976
        return unicode (OO0OOO00O0O0OOO0O .getText (),"utf-8")#line:977
    return default #line:978
def getSize (O0OO00000000O0OO0 ,total =0 ):#line:980
    for OO0OOOOOO00OOO0O0 ,O00OOO0O0O0OO00OO ,OO000O0OOO0OO00OO in os .walk (O0OO00000000O0OO0 ):#line:981
        for OOOOOO0O000OOOOO0 in OO000O0OOO0OO00OO :#line:982
            OO000OOOOO0OO0OOO =os .path .join (OO0OOOOOO00OOO0O0 ,OOOOOO0O000OOOOO0 )#line:983
            total +=os .path .getsize (OO000OOOOO0OO0OOO )#line:984
    return total #line:985
def convertSize (O0O0OO00OOO0O00O0 ,suffix ='B'):#line:987
    for O0000OOOOO0OOO000 in ['','K','M','G']:#line:988
        if abs (O0O0OO00OOO0O00O0 )<1024.0 :#line:989
            return "%3.02f %s%s"%(O0O0OO00OOO0O00O0 ,O0000OOOOO0OOO000 ,suffix )#line:990
        O0O0OO00OOO0O00O0 /=1024.0 #line:991
    return "%.02f %s%s"%(O0O0OO00OOO0O00O0 ,'G',suffix )#line:992
def getCacheSize ():#line:994
    O0O0000O00O00OOOO =os .path .join (PROFILE ,'addon_data')#line:995
    OO00000O0OOOO0O00 =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:1004
    OO0O0000OO0OOO0O0 =[(O0O0000O00O00OOOO ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'script.module.simple.downloader')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (O0O0000O00O00OOOO ,'script.module.simple.downloader')),(os .path .join (O0O0000O00O00OOOO ,'plugin.video.itv','Images'))]#line:1015
    OOOOO0OOO0O000000 =0 #line:1017
    for O0O0O00O0OO0O0O0O in OO0O0000OO0OOO0O0 :#line:1019
        if os .path .exists (O0O0O00O0OO0O0O0O )and not O0O0O00O0OO0O0O0O in [ADDONDATA ,O0O0000O00O00OOOO ]:#line:1020
            OOOOO0OOO0O000000 =getSize (O0O0O00O0OO0O0O0O ,OOOOO0OOO0O000000 )#line:1021
        else :#line:1022
            for O0O0O0O00OO0000OO ,O00OOO000OOOO0O00 ,O00O0000O00O0O00O in os .walk (O0O0O00O0OO0O0O0O ):#line:1023
                for O0OOO0OOOOOOO0OO0 in O00OOO000OOOO0O00 :#line:1024
                    if 'cache'in O0OOO0OOOOOOO0OO0 .lower ()and not O0OOO0OOOOOOO0OO0 .lower ()=='meta_cache':OOOOO0OOO0O000000 =getSize (os .path .join (O0O0O0O00OO0000OO ,O0OOO0OOOOOOO0OO0 ),OOOOO0OOO0O000000 )#line:1025
    if INCLUDEVIDEO =='true':#line:1027
        O00O0000O00O0O00O =[]#line:1028
        if INCLUDEALL =='true':O00O0000O00O0O00O =OO00000O0OOOO0O00 #line:1029
        else :#line:1030
            if INCLUDEBOB =='true':O00O0000O00O0O00O .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:1031
            if INCLUDEPHOENIX =='true':O00O0000O00O0O00O .append (os .path .join (ADDONDATA ,'plugin.video.phstreams','cache.db'))#line:1032
            if INCLUDESPECTO =='true':O00O0000O00O0O00O .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:1033
            if INCLUDEGENESIS =='true':O00O0000O00O0O00O .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:1034
            if INCLUDEEXODUS =='true':O00O0000O00O0O00O .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:1035
            if INCLUDEONECHAN =='true':O00O0000O00O0O00O .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:1036
            if INCLUDESALTS =='true':O00O0000O00O0O00O .append (os .path .join (DATABASE ,'saltscache.db'))#line:1037
            if INCLUDESALTSHD =='true':O00O0000O00O0O00O .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:1038
        if len (O00O0000O00O0O00O )>0 :#line:1039
            for O0O0O00O0OO0O0O0O in O00O0000O00O0O00O :OOOOO0OOO0O000000 =getSize (O0O0O00O0OO0O0O0O ,OOOOO0OOO0O000000 )#line:1040
        else :log ("Clear Cache: Clear Video Cache Not Enabled",5 )#line:1041
    return OOOOO0OOO0O000000 #line:1042
def getInfo (O0O0000OO0OO0O00O ):#line:1044
    try :return xbmc .getInfoLabel (O0O0000OO0OO0O00O )#line:1045
    except :return False #line:1046
def removeFolder (OOO00O00OOO0O00O0 ):#line:1048
    log ("Deleting Folder: %s"%OOO00O00OOO0O00O0 ,5 )#line:1049
    try :shutil .rmtree (OOO00O00OOO0O00O0 ,ignore_errors =True ,onerror =None )#line:1050
    except :return False #line:1051
def removeFile (O00000000O0O00O00 ):#line:1053
    log ("Deleting File: %s"%O00000000O0O00O00 ,5 )#line:1054
    try :os .remove (O00000000O0O00O00 )#line:1055
    except :return False #line:1056
def currSkin ():#line:1058
    return xbmc .getSkinDir ()#line:1059
def cleanHouse (OO000OOOOO00000OO ,ignore =False ):#line:1061
    log (OO000OOOOO00000OO )#line:1062
    O0OOO00O0O0O00O00 =0 ;O0OO0OO0000000O00 =0 #line:1063
    for O00O00O00OO0O0O0O ,OO00O0OOO00O0O0OO ,OO000OOO0O00OO0OO in os .walk (OO000OOOOO00000OO ):#line:1064
        if ignore ==False :OO00O0OOO00O0O0OO [:]=[O00O0O00OOOO0O00O for O00O0O00OOOO0O00O in OO00O0OOO00O0O0OO if O00O0O00OOOO0O00O not in EXCLUDES ]#line:1065
        O00000OO00O00OOO0 =0 #line:1066
        O00000OO00O00OOO0 +=len (OO000OOO0O00OO0OO )#line:1067
        if O00000OO00O00OOO0 >=0 :#line:1068
            for O0O0OOO0O0OO0OOO0 in OO000OOO0O00OO0OO :#line:1069
                try :#line:1070
                    os .unlink (os .path .join (O00O00O00OO0O0O0O ,O0O0OOO0O0OO0OOO0 ))#line:1071
                    O0OOO00O0O0O00O00 +=1 #line:1072
                except :#line:1073
                    try :#line:1074
                        shutil .rmtree (os .path .join (O00O00O00OO0O0O0O ,O0O0OOO0O0OO0OOO0 ))#line:1075
                    except :#line:1076
                        log ("Error Deleting %s"%O0O0OOO0O0OO0OOO0 ,5 )#line:1077
            for OOO00O0O0OOO0OO0O in OO00O0OOO00O0O0OO :#line:1078
                O0OO0OO0000000O00 +=1 #line:1079
                try :#line:1080
                    shutil .rmtree (os .path .join (O00O00O00OO0O0O0O ,OOO00O0O0OOO0OO0O ))#line:1081
                    O0OO0OO0000000O00 +=1 #line:1082
                except :#line:1083
                    log ("Error Deleting %s"%OOO00O0O0OOO0OO0O ,5 )#line:1084
    return O0OOO00O0O0O00O00 ,O0OO0OO0000000O00 #line:1085
def emptyfolder (O0O00OO0O0OO0O0O0 ):#line:1087
    OOO0OOOO0000OOO0O =0 #line:1088
    for OO0O0O00OOO00O0OO ,O000000O0O0O00O00 ,OO00OO0OOOO0OO00O in os .walk (O0O00OO0O0OO0O0O0 ,topdown =True ):#line:1089
        O000000O0O0O00O00 [:]=[OOO000OO00OOOO0O0 for OOO000OO00OOOO0O0 in O000000O0O0O00O00 if OOO000OO00OOOO0O0 not in EXCLUDES ]#line:1090
        O000000O0O0OOO000 =0 #line:1091
        O000000O0O0OOO000 +=len (OO00OO0OOOO0OO00O )+len (O000000O0O0O00O00 )#line:1092
        if O000000O0O0OOO000 ==0 :#line:1093
            shutil .rmtree (os .path .join (OO0O0O00OOO00O0OO ))#line:1094
            OOO0OOOO0000OOO0O +=1 #line:1095
            log ("Empty Folder: %s"%OO0O0O00OOO00O0OO ,5 )#line:1096
    return OOO0OOOO0000OOO0O #line:1097
def log (O00OO0O00OOOO00OO ,level =5 ):#line:1099
    if not os .path .exists (ADDONDATA ):#line:1101
      try :#line:1102
        os .makedirs (ADDONDATA )#line:1103
      except :pass #line:1104
    if not os .path .exists (WIZLOG ):OO0OO00O00O00O000 =open (WIZLOG ,'w');OO0OO00O00O00O000 .close ()#line:1105
    if WIZDEBUGGING =='false':return False #line:1106
    if DEBUGLEVEL =='0':return False #line:1107
    if DEBUGLEVEL =='1'and not level in [5 ,5 ,xbmc .LOGSEVERE ,xbmc .LOGFATAL ]:return False #line:1108
    if DEBUGLEVEL =='2':level =5 #line:1109
    try :#line:1110
        try :#line:1111
            if isinstance (O00OO0O00OOOO00OO ,unicode ):#line:1112
                O00OO0O00OOOO00OO ='%s'%(O00OO0O00OOOO00OO .encode ('utf-8'))#line:1113
            xbmc .log ('%s: %s'%(ADDONTITLE ,O00OO0O00OOOO00OO ),level )#line:1114
        except :#line:1115
            if isinstance (O00OO0O00OOOO00OO ,str ):#line:1116
                O00OO0O00OOOO00OO ='%s'%(O00OO0O00OOOO00OO .encode ('utf-8'))#line:1117
            xbmc .log ('%s: %s'%(ADDONTITLE ,O00OO0O00OOOO00OO ),level )#line:1118
    except Exception as OO0OOO0000OO00OOO :#line:1119
        try :xbmc .log ('Logging Failure: %s'%(OO0OOO0000OO00OOO ),level )#line:1120
        except :pass #line:1121
    if ENABLEWIZLOG =='true':#line:1122
        O00000O00O0O0OO0O =getS ('nextcleandate')if not getS ('nextcleandate')==''else str (TODAY )#line:1123
        if CLEANWIZLOG =='true'and O00000O00O0O0OO0O <=str (TODAY ):checkLog ()#line:1124
        with open (WIZLOG ,'a')as OO0OO00O00O00O000 :#line:1125
            OO0000OOO0O0OOOOO ="[%s %s] %s"%(datetime .now ().date (),str (datetime .now ().time ())[:8 ],O00OO0O00OOOO00OO )#line:1126
            OO0OO00O00O00O000 .write (OO0000OOO0O0OOOOO .rstrip ('\r\n')+'\n')#line:1127
def checkLog ():#line:1129
    try :#line:1130
        O0OO00OO000OO0OO0 =getS ('nextcleandate')#line:1131
        OO000000OOO0OOOO0 =TOMORROW #line:1132
        if CLEANWIZLOGBY =='0':#line:1133
            O0000O000OO0000OO =TODAY -timedelta (days =MAXWIZDATES [int (float (CLEANDAYS ))])#line:1134
            O0OOO0O0O000OO000 =0 #line:1135
            O00OO00O00OO0O0O0 =open (WIZLOG );OO0OOO0O0OO000000 =O00OO00O00OO0O0O0 .read ();O00OO00O00OO0O0O0 .close ();OOO00OO0OOOOOO0OO =OO0OOO0O0OO000000 .split ('\n')#line:1136
            for O000O00O00000O00O in OOO00OO0OOOOOO0OO :#line:1137
                if str (O000O00O00000O00O [1 :11 ])>=str (O0000O000OO0000OO ):#line:1138
                    break #line:1139
                O0OOO0O0O000OO000 +=1 #line:1140
            OOO0OO0000O00O00O =OOO00OO0OOOOOO0OO [O0OOO0O0O000OO000 :]#line:1141
            OO0000OO0OOO0O000 ='\n'.join (OOO0OO0000O00O00O )#line:1142
            O00OO00O00OO0O0O0 =open (WIZLOG ,'w');O00OO00O00OO0O0O0 .write (OO0000OO0OOO0O000 );O00OO00O00OO0O0O0 .close ()#line:1143
        elif CLEANWIZLOGBY =='1':#line:1144
            OOOOOO00O0O00O000 =MAXWIZSIZE [int (float (CLEANSIZE ))]*1024 #line:1145
            O00OO00O00OO0O0O0 =open (WIZLOG );OO0OOO0O0OO000000 =O00OO00O00OO0O0O0 .read ();O00OO00O00OO0O0O0 .close ();OOO00OO0OOOOOO0OO =OO0OOO0O0OO000000 .split ('\n')#line:1146
            if os .path .getsize (WIZLOG )>=OOOOOO00O0O00O000 :#line:1147
                O000O0OO0OOO0O0OO =len (OOO00OO0OOOOOO0OO )/2 #line:1148
                OOO0OO0000O00O00O =OOO00OO0OOOOOO0OO [O000O0OO0OOO0O0OO :]#line:1149
                OO0000OO0OOO0O000 ='\n'.join (OOO0OO0000O00O00O )#line:1150
                O00OO00O00OO0O0O0 =open (WIZLOG ,'w');O00OO00O00OO0O0O0 .write (OO0000OO0OOO0O000 );O00OO00O00OO0O0O0 .close ()#line:1151
        elif CLEANWIZLOGBY =='2':#line:1152
            O00OO00O00OO0O0O0 =open (WIZLOG );OO0OOO0O0OO000000 =O00OO00O00OO0O0O0 .read ();O00OO00O00OO0O0O0 .close ();OOO00OO0OOOOOO0OO =OO0OOO0O0OO000000 .split ('\n')#line:1153
            OO000O00OOO0000O0 =MAXWIZLINES [int (float (CLEANLINES ))]#line:1154
            if len (OOO00OO0OOOOOO0OO )>OO000O00OOO0000O0 :#line:1155
                O000O0OO0OOO0O0OO =len (OOO00OO0OOOOOO0OO )-int (OO000O00OOO0000O0 /2 )#line:1156
                OOO0OO0000O00O00O =OOO00OO0OOOOOO0OO [O000O0OO0OOO0O0OO :]#line:1157
                OO0000OO0OOO0O000 ='\n'.join (OOO0OO0000O00O00O )#line:1158
                O00OO00O00OO0O0O0 =open (WIZLOG ,'w');O00OO00O00OO0O0O0 .write (OO0000OO0OOO0O000 );O00OO00O00OO0O0O0 .close ()#line:1159
        setS ('nextcleandate',str (OO000000OOO0OOOO0 ))#line:1160
    except :pass #line:1161
def latestDB (OO0000OOO000OOOOO ):#line:1162
    if OO0000OOO000OOOOO in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:1163
        OOO0OOOOO000OOO00 =glob .glob (os .path .join (DATABASE ,'%s*.db'%OO0000OOO000OOOOO ))#line:1164
        OO0000OO0O0OO0O00 ='%s(.+?).db'%OO0000OOO000OOOOO [1 :]#line:1165
        OOOOO0OOOO00O0O0O =0 #line:1166
        for O000OOOOO0O00O000 in OOO0OOOOO000OOO00 :#line:1167
            try :OOO000OOO00OOOOOO =int (re .compile (OO0000OO0O0OO0O00 ).findall (O000OOOOO0O00O000 )[0 ])#line:1168
            except :OOO000OOO00OOOOOO =0 #line:1169
            if OOOOO0OOOO00O0O0O <OOO000OOO00OOOOOO :#line:1170
                OOOOO0OOOO00O0O0O =OOO000OOO00OOOOOO #line:1171
        return '%s%s.db'%(OO0000OOO000OOOOO ,OOOOO0OOOO00O0O0O )#line:1172
    else :return False #line:1173
def addonId (OOOO0OOOO00000OOO ):#line:1175
    try :#line:1176
        return xbmcaddon .Addon (id =OOOO0OOOO00000OOO )#line:1177
    except :#line:1178
        return False #line:1179
def toggleDependency (OOO0O000OO00OO0O0 ,DP =None ):#line:1181
    OO000O00000O00OOO =os .path .join (ADDONS ,OOO0O000OO00OO0O0 ,'addon.xml')#line:1182
    if os .path .exists (OO000O00000O00OOO ):#line:1183
        OOOOO000OO0OOOO0O =open (OO000O00000O00OOO ,mode ='r');O00OO00O00O00OO0O =OOOOO000OO0OOOO0O .read ();OOOOO000OO0OOOO0O .close ();#line:1184
        OOOO0OOO0O0OO0O00 =parseDOM (O00OO00O00O00OO0O ,'import',ret ='addon')#line:1185
        for O00O00O000OOOO0OO in OOOO0OOO0O0OO0O00 :#line:1186
            if not 'xbmc.python'in O00O00O000OOOO0OO :#line:1187
                OO0OOO000O0000O0O =os .path .join (ADDONS ,O00O00O000OOOO0OO )#line:1188
                if not DP ==None :#line:1189
                    DP .update ("","Checking Dependency [COLOR yellow]%s[/COLOR] for [COLOR yellow]%s[/COLOR]"%(O00O00O000OOOO0OO ,OOO0O000OO00OO0O0 ),"")#line:1190
                if os .path .exists (OO0OOO000O0000O0O ):#line:1191
                    toggleAddon (OOO0O000OO00OO0O0 ,'true')#line:1192
            xbmc .sleep (100 )#line:1193
def toggleAdult ():#line:1195
    OO0OO000OOOO00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Enable[/COLOR] or [COLOR %s]Disable[/COLOR] all Adult addons?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Enable[/COLOR][/B]",nolabel ="[B][COLOR red]Disable[/COLOR][/B]")#line:1196
    O0OOOOO000O00O000 ='true'if OO0OO000OOOO00O0O ==1 else 'false'#line:1197
    OO00OO0OO0O00000O ='Enabling'if OO0OO000OOOO00O0O ==1 else 'Disabling'#line:1198
    O00OOO00OOO0O00OO =openURL ('http://noobsandnerds.com/TI/AddonPortal/adult.php').replace ('\n','').replace ('\r','').replace ('\t','')#line:1199
    OOOOOO00OO00O00OO =re .compile ('i="(.+?)"').findall (O00OOO00OOO0O00OO )#line:1200
    O0000OO00OOO0OOOO =[]#line:1201
    for OOOOOO0OO00000O00 in OOOOOO00OO00O00OO :#line:1202
        O0O0O0000O00OOOO0 =os .path .join (ADDONS ,OOOOOO0OO00000O00 )#line:1203
        if os .path .exists (O0O0O0000O00OOOO0 ):#line:1204
            O0000OO00OOO0OOOO .append (OOOOOO0OO00000O00 )#line:1205
            toggleAddon (OOOOOO0OO00000O00 ,O0OOOOO000O00O000 ,True )#line:1206
            log ("[Toggle Adult] %s %s"%(OO00OO0OO0O00000O ,OOOOOO0OO00000O00 ),5 )#line:1207
    if len (O0000OO00OOO0OOOO )>0 :#line:1208
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to view a list of the addons that where %s?[/COLOR]"%(COLOR2 ,OO00OO0OO0O00000O .replace ('ing','ed')),yeslabel ="[B][COLOR green]View List[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:1209
            O0000O00000OOO0OO ='[CR]'.join (O0000OO00OOO0OOOO )#line:1210
            TextBox (ADDONTITLE ,"[COLOR %s]Here are a list of the addons that where %s for Adult Content:[/COLOR][CR][CR][COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OO0OO0O00000O .replace ('ing','ed'),COLOR2 ,O0000O00000OOO0OO ))#line:1211
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s][COLOR %s]%d[/COLOR] Adult Addons %s[/COLOR]"%(COLOR2 ,COLOR1 ,count ,OO00OO0OO0O00000O .replace ('ing','ed')))#line:1212
        forceUpdate (True )#line:1213
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Adult Addons Found[/COLOR]"%COLOR2 )#line:1214
def toggleAddon (OOO0OOO0O000O00O0 ,OO0OO0OO0OO000OOO ,over =None ):#line:1217
    if KODIV >=17 :#line:1218
        addonDatabase (OOO0OOO0O000O00O0 ,OO0OO0OO0OO000OOO )#line:1219
        return #line:1220
    O0OOOO0OOOOOOO000 =OOO0OOO0O000O00O0 #line:1221
    O00OOO0OOOOOO000O =os .path .join (ADDONS ,OOO0OOO0O000O00O0 ,'addon.xml')#line:1222
    if os .path .exists (O00OOO0OOOOOO000O ):#line:1223
        OOO000OO0O000OOOO =open (O00OOO0OOOOOO000O )#line:1224
        OOOO0000000O0O0OO =OOO000OO0O000OOOO .read ()#line:1225
        O0O00OOO00OO0O000 =parseDOM (OOOO0000000O0O0OO ,'addon',ret ='id')#line:1226
        O00OO0OOOO0O00OOO =parseDOM (OOOO0000000O0O0OO ,'addon',ret ='name')#line:1227
        O00O0OOO0O000OOO0 =parseDOM (OOOO0000000O0O0OO ,'extension',ret ='library',attrs ={'point':'xbmc.service'})#line:1228
        try :#line:1229
            if len (O0O00OOO00OO0O000 )>0 :#line:1230
                O0OOOO0OOOOOOO000 =O0O00OOO00OO0O000 [0 ]#line:1231
            if len (O00O0OOO0O000OOO0 )>0 :#line:1232
                log ("We got a live one, stopping script: %s"%match [0 ],5 )#line:1233
                ebi ('StopScript(%s)'%os .path .join (ADDONS ,O0OOOO0OOOOOOO000 ))#line:1234
                ebi ('StopScript(%s)'%O0OOOO0OOOOOOO000 )#line:1235
                ebi ('StopScript(%s)'%os .path .join (ADDONS ,O0OOOO0OOOOOOO000 ,O00O0OOO0O000OOO0 [0 ]))#line:1236
                xbmc .sleep (500 )#line:1237
        except :#line:1238
            pass #line:1239
    O000000O00O0O00OO ='{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}, "id":1}'%(O0OOOO0OOOOOOO000 ,OO0OO0OO0OO000OOO )#line:1240
    OO00O0O0000O0OOOO =xbmc .executeJSONRPC (O000000O00O0O00OO )#line:1241
    if 'error'in OO00O0O0000O0OOOO and over ==None :#line:1242
        OO0OOOOOOO00OO00O ='Enabling'if OO0OO0OO0OO000OOO =='true'else 'Disabling'#line:1243
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error %s [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,OO0OOOOOOO00OO00O ,OOO0OOO0O000O00O0 ),"Check to make sure the addon list is upto date and try again.[/COLOR]")#line:1244
        forceUpdate ()#line:1245
def addonInfo (O00O00000OOO0O000 ,O0OOO0OO00O00O0OO ):#line:1247
    OO0O000O0000O00OO =addonId (O00O00000OOO0O000 )#line:1248
    if OO0O000O0000O00OO :return OO0O000O0000O00OO .getAddonInfo (O0OOO0OO00O00O0OO )#line:1249
    else :return False #line:1250
def whileWindow (O00OOO000OO0OOOO0 ,active =False ,count =0 ,counter =15 ):#line:1252
    OO00OO0OOOO00O0OO =getCond ('Window.IsActive(%s)'%O00OOO000OO0OOOO0 )#line:1253
    log ("%s is %s"%(O00OOO000OO0OOOO0 ,OO00OO0OOOO00O0OO ),5 )#line:1254
    while not OO00OO0OOOO00O0OO and count <counter :#line:1255
        log ("%s is %s(%s)"%(O00OOO000OO0OOOO0 ,OO00OO0OOOO00O0OO ,count ))#line:1256
        OO00OO0OOOO00O0OO =getCond ('Window.IsActive(%s)'%O00OOO000OO0OOOO0 )#line:1257
        count +=1 #line:1258
        xbmc .sleep (500 )#line:1259
    while OO00OO0OOOO00O0OO :#line:1261
        active =True #line:1262
        log ("%s is %s"%(O00OOO000OO0OOOO0 ,OO00OO0OOOO00O0OO ),5 )#line:1263
        OO00OO0OOOO00O0OO =getCond ('Window.IsActive(%s)'%O00OOO000OO0OOOO0 )#line:1264
        xbmc .sleep (250 )#line:1265
    return active #line:1266
def id_generator (size =6 ,chars =string .ascii_uppercase +string .digits ):#line:1268
    return ''.join (random .choice (chars )for _O000OOOOO0O000OOO in range (size ))#line:1269
def generateQR (O0000O0000O00O0OO ,O0O0O00OO0O00O00O ):#line:1271
    if not os .path .exists (QRCODES ):os .makedirs (QRCODES )#line:1272
    O0OO0000O0000O0O0 =os .path .join (QRCODES ,'%s.png'%O0O0O00OO0O00O00O )#line:1273
    O00OOO00000OOOOO0 =pyqrcode .create (O0000O0000O00O0OO )#line:1274
    O00OOO00000OOOOO0 .png (O0OO0000O0000O0O0 ,scale =10 )#line:1275
    return O0OO0000O0000O0O0 #line:1276
def createQR ():#line:1278
    O0O0O000O0OOO000O =getKeyboard ('',"%s: Insert the URL for the QRCode."%ADDONTITLE )#line:1279
    if O0O0O000O0OOO000O =="":LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Create QR Code Cancelled![/COLOR]'%COLOR2 );return #line:1280
    if not O0O0O000O0OOO000O .startswith ('http://')and not O0O0O000O0OOO000O .startswith ('https://'):LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:1281
    if O0O0O000O0OOO000O =='http://'or O0O0O000O0OOO000O =='https://':LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:1282
    OO0O000OOO00OO000 =workingURL (O0O0O000O0OOO000O )#line:1283
    if not OO0O000OOO00OO000 ==True :#line:1284
        if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems the your enter isnt working, Would you like to create it anyways?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O000OOO00OO000 ),yeslabel ="[B][COLOR red]Yes Create[/COLOR][/B]",nolabel ="[B][COLOR green]No Cancel[/COLOR][/B]"):#line:1285
            return #line:1286
    O000O0O0OO0OOO0O0 =getKeyboard ('',"%s: Insert the name for the QRCode."%ADDONTITLE )#line:1287
    O000O0O0OO0OOO0O0 ="QrImage_%s"%id_generator (6 )if O000O0O0OO0OOO0O0 ==""else O000O0O0OO0OOO0O0 #line:1288
    O0000O0OOOOOO0OOO =generateQR (O0O0O000O0OOO000O ,O000O0O0OO0OOO0O0 )#line:1289
    DIALOG .ok (ADDONTITLE ,"[COLOR %s]The QRCode image has been created and is located in the addondata directory:[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O0OOOOOO0OOO .replace (HOME ,'')))#line:1290
def cleanupBackup ():#line:1292
    O0OO0OO0000O0OOOO =translatepath (MYBUILDS )#line:1293
    O0O000O00O0O0OOOO =glob .glob (os .path .join (O0OO0OO0000O0OOOO ,"*"))#line:1294
    OO0O0O00O000O00OO =[];O0OO0O0000OOO0OOO =[]#line:1295
    if len (O0O000O00O0O0OOOO )==0 :#line:1296
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Backup Location: Empty[/COLOR]"%(COLOR2 ))#line:1297
        return #line:1298
    for OO0O00000O00OO0OO in sorted (O0O000O00O0O0OOOO ,key =os .path .getmtime ):#line:1299
        O0OO0O0000OOO0OOO .append (OO0O00000O00OO0OO )#line:1300
        OOOOOO00000O0OO00 =OO0O00000O00OO0OO .replace (O0OO0OO0000O0OOOO ,'')#line:1301
        if os .path .isdir (OO0O00000O00OO0OO ):#line:1302
            OO0O0O00O000O00OO .append ('/%s/'%OOOOOO00000O0OO00 )#line:1303
        elif os .path .isfile (OO0O00000O00OO0OO ):#line:1304
            OO0O0O00O000O00OO .append (OOOOOO00000O0OO00 )#line:1305
    OO0O0O00O000O00OO =['--- Remove All Items ---']+OO0O0O00O000O00OO #line:1306
    OOOO0O0OOO000OO0O =DIALOG .select ("%s: Select the items to remove from 'MyBuilds'."%ADDONTITLE ,OO0O0O00O000O00OO )#line:1307
    if OOOO0O0OOO000OO0O ==-1 :#line:1309
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1310
    elif OOOO0O0OOO000OO0O ==0 :#line:1311
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to clean up all items in your 'My_Builds' folder?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,MYBUILDS ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1312
            OOO0O00O000OOOOOO ,OO00OO0OOOOO0O00O =cleanHouse (translatepath (MYBUILDS ))#line:1313
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Removed Files: [COLOR %s]%s[/COLOR] / Folders:[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0O00O000OOOOOO ,COLOR1 ,OO00OO0OOOOO0O00O ))#line:1314
        else :#line:1315
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1316
    else :#line:1317
        O0OOOO0000OOOO0OO =O0OO0O0000OOO0OOO [OOOO0O0OOO000OO0O -1 ];OOO00OOOO0O00OOO0 =False #line:1318
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove [COLOR %s]%s[/COLOR] from 'My_Builds' folder?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0O0O00O000O00OO [OOOO0O0OOO000OO0O ]),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO0000OOOO0OO ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1319
            if os .path .isfile (O0OOOO0000OOOO0OO ):#line:1320
                try :#line:1321
                    os .remove (O0OOOO0000OOOO0OO )#line:1322
                    OOO00OOOO0O00OOO0 =True #line:1323
                except :#line:1324
                    log ("Unable to remove: %s"%O0OOOO0000OOOO0OO )#line:1325
            else :#line:1326
                cleanHouse (O0OOOO0000OOOO0OO )#line:1327
                try :#line:1328
                    shutil .rmtree (O0OOOO0000OOOO0OO )#line:1329
                    OOO00OOOO0O00OOO0 =True #line:1330
                except Exception as OO0O0O0OOOO0OO0O0 :#line:1331
                    log ("Error removing %s"%O0OOOO0000OOOO0OO ,5 )#line:1332
            if OOO00OOOO0O00OOO0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed![/COLOR]"%(COLOR2 ,OO0O0O00O000O00OO [OOOO0O0OOO000OO0O ]))#line:1333
            else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Removing %s![/COLOR]"%(COLOR2 ,OO0O0O00O000O00OO [OOOO0O0OOO000OO0O ]))#line:1334
        else :#line:1335
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1336
def getCond (O00OOOO0OOOO0OOOO ):#line:1338
    return xbmc .getCondVisibility (O00OOOO0OOOO0OOOO )#line:1339
def ebi (OOOO0OO0OO0OO0O0O ):#line:1341
    xbmc .executebuiltin (OOOO0OO0OO0OO0O0O )#line:1342
def refresh ():#line:1344
    ebi ('Container.Refresh()')#line:1345
def splitNotify (O0O0O0OO00O0OOOO0 ):#line:1347
    OOO00OOOO0OOOOOO0 =openURL (O0O0O0OO00O0OOOO0 ).replace ('\r','').replace ('\t','').replace ('\n','[CR]')#line:1348
    if OOO00OOOO0OOOOOO0 .find ('|||')==-1 :return False ,False #line:1349
    OO0O0OOOOOOOOO0O0 ,O0OOOO0000O0O00O0 =OOO00OOOO0OOOOOO0 .split ('|||')#line:1350
    if O0OOOO0000O0O00O0 .startswith ('[CR]'):O0OOOO0000O0O00O0 =O0OOOO0000O0O00O0 [4 :]#line:1351
    return OO0O0OOOOOOOOO0O0 .replace ('[CR]',''),O0OOOO0000O0O00O0 #line:1352
def forceUpdate (silent =False ):#line:1354
    ebi ('UpdateAddonRepos()')#line:1355
    ebi ('UpdateLocalAddons()')#line:1356
def convertSpecial (OOOO0OO0O00000OOO ,over =False ):#line:1360
    O00OO00O000OO00O0 =fileCount (OOOO0OO0O00000OOO );OOOOO000O0OO0OOO0 =0 #line:1361
    DP .create (ADDONTITLE ,"[COLOR %s]Changing Physical Paths To Special"%COLOR2 ,"","Please Wait[/COLOR]")#line:1362
    for O0O00OOO00OOO0O00 ,O00O0O00O00O00OOO ,O0OO00O0OO0O0000O in os .walk (OOOO0OO0O00000OOO ):#line:1363
        for OOOOOOO0OOO0OO00O in O0OO00O0OO0O0000O :#line:1364
            OOOOO000O0OO0OOO0 +=1 #line:1365
            OO00O0O0OO000OO0O =int (percentage (OOOOO000O0OO0OOO0 ,O00OO00O000OO00O0 ))#line:1366
            if OOOOOOO0OOO0OO00O .endswith (".xml")or OOOOOOO0OOO0OO00O .endswith (".hash")or OOOOOOO0OOO0OO00O .endswith ("properies"):#line:1367
                DP .update (OO00O0O0OO000OO0O ,"[COLOR %s]Scanning: [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,O0O00OOO00OOO0O00 .replace (HOME ,'')),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOO0OOO0OO00O ),"Please Wait[/COLOR]")#line:1368
                OOO000O00O000OOO0 =open (os .path .join (O0O00OOO00OOO0O00 ,OOOOOOO0OOO0OO00O )).read ()#line:1369
                O0OO00OO00000OOOO =urllib .quote (HOME )#line:1370
                O0O0000OO000OO000 =urllib .quote (HOME ).replace ('%3A','%3a').replace ('%5C','%5c')#line:1371
                O00O000000OO0O0O0 =OOO000O00O000OOO0 .replace (HOME ,'special://home/').replace (O0OO00OO00000OOOO ,'special://home/').replace (O0O0000OO000OO000 ,'special://home/')#line:1372
                O0O00O00O0OOOOO0O =open ((os .path .join (O0O00OOO00OOO0O00 ,OOOOOOO0OOO0OO00O )),mode ='w')#line:1373
                O0O00O00O0OOOOO0O .write (str (O00O000000OO0O0O0 ))#line:1374
                O0O00O00O0OOOOO0O .close ()#line:1375
    DP .close ()#line:1376
    log ("[Convert Paths to Special] Complete",5 )#line:1377
    if over ==False :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Convert Paths to Special: Complete![/COLOR]"%COLOR2 )#line:1378
def clearCrash ():#line:1380
    OO000O000O0O00000 =[]#line:1381
    for O00OOO0O0OO0OOO0O in glob .glob (os .path .join (LOG ,'*crashlog*.*')):#line:1382
        OO000O000O0O00000 .append (O00OOO0O0OO0OOO0O )#line:1383
    if len (OO000O000O0O00000 )>0 :#line:1384
        if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the Crash logs?'%COLOR2 ,'[COLOR %s]%s[/COLOR] Files Found[/COLOR]'%(COLOR1 ,len (OO000O000O0O00000 )),yeslabel ="[B][COLOR green]Remove Logs[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Logs[/COLOR][/B]"):#line:1385
            for O00OO00OO00O00O0O in OO000O000O0O00000 :#line:1386
                os .remove (O00OO00OO00O00O0O )#line:1387
            LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]%s Crash Logs Removed[/COLOR]'%(COLOR2 ,len (OO000O000O0O00000 )))#line:1388
        else :LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Crash Logs Cancelled[/COLOR]'%COLOR2 )#line:1389
    else :LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]No Crash Logs Found[/COLOR]'%COLOR2 )#line:1390
def hidePassword ():#line:1392
    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]hide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Hide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1393
        O0O0000O000OOOOOO =0 #line:1394
        for OO00OOOOO00OOOOO0 in glob .glob (os .path .join (ADDONS ,'*/')):#line:1395
            O0000OO0OO0OO00OO =os .path .join (OO00OOOOO00OOOOO0 ,'resources','settings.xml')#line:1396
            if os .path .exists (O0000OO0OO0OO00OO ):#line:1397
                OO0OOOO0OO00OO0OO =open (O0000OO0OO0OO00OO ).read ()#line:1398
                O0OOOOO0OO0O0O0O0 =parseDOM (OO0OOOO0OO00OO0OO ,'addon',ret ='id')#line:1399
                for O000000OO0OOOOO00 in O0OOOOO0OO0O0O0O0 :#line:1400
                    if 'pass'in O000000OO0OOOOO00 :#line:1401
                        if not 'option="hidden"'in O000000OO0OOOOO00 :#line:1402
                            try :#line:1403
                                O000O0OO0O00OOO0O =O000000OO0OOOOO00 .replace ('/','option="hidden" /')#line:1404
                                OO0OOOO0OO00OO0OO .replace (O000000OO0OOOOO00 ,O000O0OO0O00OOO0O )#line:1405
                                O0O0000O000OOOOOO +=1 #line:1406
                                log ("[Hide Passwords] found in %s on %s"%(O0000OO0OO0OO00OO .replace (HOME ,''),O000000OO0OOOOO00 ),5 )#line:1407
                            except :#line:1408
                                pass #line:1409
                OOOOOOOOO0000O00O =open (O0000OO0OO0OO00OO ,mode ='w');OOOOOOOOO0000O00O .write (OO0OOOO0OO00OO0OO );OOOOOOOOO0000O00O .close ()#line:1410
        LogNotify ("[COLOR %s]Hide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,O0O0000O000OOOOOO ))#line:1411
        log ("[Hide Passwords] %s items changed"%O0O0000O000OOOOOO ,5 )#line:1412
    else :log ("[Hide Passwords] Cancelled",5 )#line:1413
def unhidePassword ():#line:1415
    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]unhide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Unhide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1416
        O0O00O0OOO000O0O0 =0 #line:1417
        for O00O00000OOO00000 in glob .glob (os .path .join (ADDONS ,'*/')):#line:1418
            OO0O0O00O000OOO00 =os .path .join (O00O00000OOO00000 ,'resources','settings.xml')#line:1419
            if os .path .exists (OO0O0O00O000OOO00 ):#line:1420
                OOO00O0OOOO00O00O =open (OO0O0O00O000OOO00 ).read ()#line:1421
                OOOO0O00OO0O0OOOO =parseDOM (OOO00O0OOOO00O00O ,'addon',ret ='id')#line:1422
                for O00O0OOOOOOO0OO0O in OOOO0O00OO0O0OOOO :#line:1423
                    if 'pass'in O00O0OOOOOOO0OO0O :#line:1424
                        if 'option="hidden"'in O00O0OOOOOOO0OO0O :#line:1425
                            try :#line:1426
                                OO0O00OOOO0O00OOO =O00O0OOOOOOO0OO0O .replace ('option="hidden"','')#line:1427
                                OOO00O0OOOO00O00O .replace (O00O0OOOOOOO0OO0O ,OO0O00OOOO0O00OOO )#line:1428
                                O0O00O0OOO000O0O0 +=1 #line:1429
                                log ("[Unhide Passwords] found in %s on %s"%(OO0O0O00O000OOO00 .replace (HOME ,''),O00O0OOOOOOO0OO0O ),5 )#line:1430
                            except :#line:1431
                                pass #line:1432
                O0000OO0000OOOOOO =open (OO0O0O00O000OOO00 ,mode ='w');O0000OO0000OOOOOO .write (OOO00O0OOOO00O00O );O0000OO0000OOOOOO .close ()#line:1433
        LogNotify ("[COLOR %s]Unhide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,O0O00O0OOO000O0O0 ))#line:1434
        log ("[Unhide Passwords] %s items changed"%O0O00O0OOO000O0O0 ,5 )#line:1435
    else :log ("[Unhide Passwords] Cancelled",5 )#line:1436
def chunk_report (O000000000O00O0OO ,O00OO00O0O0O0O000 ,O00OOO00O0O00O00O ):#line:1437
   OOO00OO0O0OO00O0O =float (O000000000O00O0OO )/O00OOO00O0O00O00O #line:1438
   OOO00OO0O0OO00O0O =round (OOO00OO0O0OO00O0O *100 ,2 )#line:1439
   if O000000000O00O0OO >=O00OOO00O0O00O00O :#line:1441
      sys .stdout .write ('\n')#line:1442
def chunk_read (OO0O00O000O00OO00 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:1444
   import time #line:1445
   O000O000O00OO0O00 =100 #line:1446
   O0000OO0O00O0OOOO =0 #line:1448
   O00OOOO00OOO0O00O =time .time ()#line:1449
   OO0O00OO00OOOO0O0 =0 #line:1450
   with open (destination ,"wb")as O0O00O0O0O0OO0OO0 :#line:1453
    while 1 :#line:1454
      OO00OO0OO00OO0OO0 =time .time ()-O00OOOO00OOO0O00O #line:1455
      O0O0OOOO0O00000OO =int (OO0O00OO00OOOO0O0 *chunk_size )#line:1456
      OOO00OO0OOO00000O =OO0O00O000O00OO00 .read (chunk_size )#line:1457
      O0O00O0O0O0OO0OO0 .write (OOO00OO0OOO00000O )#line:1458
      O0O00O0O0O0OO0OO0 .flush ()#line:1459
      O0000OO0O00O0OOOO +=len (OOO00OO0OOO00000O )#line:1460
      OO000OO0000O0OO00 =float (O0000OO0O00O0OOOO )/O000O000O00OO0O00 #line:1461
      OO000OO0000O0OO00 =round (OO000OO0000O0OO00 *100 ,2 )#line:1462
      if int (OO00OO0OO00OO0OO0 )>0 :#line:1463
        O0O000O0O00000000 =int (O0O0OOOO0O00000OO /(1024 *OO00OO0OO00OO0OO0 ))#line:1464
      else :#line:1465
         O0O000O0O00000000 =0 #line:1466
      if O0O000O0O00000000 >1024 and not OO000OO0000O0OO00 ==100 :#line:1467
          OO0O0OO00000O000O =int (((O000O000O00OO0O00 -O0O0OOOO0O00000OO )/1024 )/(O0O000O0O00000000 ))#line:1468
      else :#line:1469
          OO0O0OO00000O000O =0 #line:1470
      if OO0O0OO00000O000O <0 :#line:1471
        OO0O0OO00000O000O =0 #line:1472
      dp .update (int (OO000OO0000O0OO00 ),"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO000OO0000O0OO00 ,O0O0OOOO0O00000OO /(1024 *1024 ),O000O000O00OO0O00 /(1000 *1000 ),O0O000O0O00000000 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0O0OO00000O000O ,60 ))#line:1473
      if dp .iscanceled ():#line:1474
         dp .close ()#line:1475
         break #line:1476
      if not OOO00OO0OOO00000O :#line:1477
         break #line:1478
      if report_hook :#line:1480
         report_hook (O0000OO0O00O0OOOO ,chunk_size ,O000O000O00OO0O00 )#line:1481
      OO0O00OO00OOOO0O0 +=1 #line:1482
   return O0000OO0O00O0OOOO #line:1484
server ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNFPyklMztaryM0BAPI5E0I=$'#line:1485
def googledrive_download (O0O00O0O00O0O00OO ,O00OOO0O00O0O0OOO ,OO00O00OO0OOO0O00 ,O0O0OOOO0OO0OOO0O ):#line:1486
    OO000O00O0O000OO0 =[]#line:1490
    OOOOOO0OOO0OOO0OO =O0O00O0O00O0O00OO .split ('=')#line:1491
    O0O00O0O00O0O00OO =OOOOOO0OOO0OOO0OO [len (OOOOOO0OOO0OOO0OO )-1 ]#line:1492
    def O00OOOOOO00OOOOO0 (O000O0OOO000O0O0O ):#line:1494
        for OOOO000O0O0O0O00O in O000O0OOO000O0O0O :#line:1496
            OO0OO0OOOOOOOO0OO =OOOO000O0O0O0O00O .value #line:1499
            if 'download_warning'in OOOO000O0O0O0O00O .name :#line:1500
                return OOOO000O0O0O0O00O .value #line:1503
            return OO0OO0OOOOOOOO0OO #line:1504
        return None #line:1506
    def OOOO0O00000OO000O (O00OO0OOO0OOOOOOO ,O0OO00O0000OOO000 ):#line:1508
        OOO00O0O0OOOOO000 =32768 #line:1510
        O0O000000O0OO00OO =time .time ()#line:1511
        with open (O0OO00O0000OOO000 ,"wb")as O0O00O00OO0O0O00O :#line:1513
            OO0OO000O000O00OO =1 #line:1514
            OO000OO0O0O000O0O =32768 #line:1515
            try :#line:1516
                O000O0OOO000OOOO0 =int (O00OO0OOO0OOOOOOO .headers .get ('content-length'))#line:1517
                print ('file total size :',O000O0OOO000OOOO0 )#line:1518
            except TypeError :#line:1519
                print ('using dummy length !!!')#line:1520
                O000O0OOO000OOOO0 =int (O0O0OOOO0OO0OOO0O )*1000000 #line:1521
            for O0O00O0O000OOOOOO in O00OO0OOO0OOOOOOO .iter_content (OOO00O0O0OOOOO000 ):#line:1522
                if O0O00O0O000OOOOOO :#line:1523
                    O0O00O00OO0O0O00O .write (O0O00O0O000OOOOOO )#line:1524
                    O0O00O00OO0O0O00O .flush ()#line:1525
                    O00O0O00OO000OO00 =time .time ()-O0O000000O0OO00OO #line:1526
                    O00O000OO000O00O0 =int (OO0OO000O000O00OO *OO000OO0O0O000O0O )#line:1527
                    if O00O0O00OO000OO00 ==0 :#line:1528
                        O00O0O00OO000OO00 =0.1 #line:1529
                    O0OOOO0OOO00O00OO =int (O00O000OO000O00O0 /(1024 *O00O0O00OO000OO00 ))#line:1530
                    O00O0O00OO00O00OO =int (OO0OO000O000O00OO *OO000OO0O0O000O0O *100 /O000O0OOO000OOOO0 )#line:1531
                    if O0OOOO0OOO00O00OO >1024 and not O00O0O00OO00O00OO ==100 :#line:1532
                      OO0O0O0OO00OO0O00 =int (((O000O0OOO000OOOO0 -O00O000OO000O00O0 )/1024 )/(O0OOOO0OOO00O00OO ))#line:1533
                    else :#line:1534
                      OO0O0O0OO00OO0O00 =0 #line:1535
                    OO00O00OO0OOO0O00 .update (int (O00O0O00OO00O00OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00O0O00OO00O00OO ,O00O000OO000O00O0 /(1024 *1024 ),O000O0OOO000OOOO0 /(1000 *1000 ),O0OOOO0OOO00O00OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0O0O0OO00OO0O00 ,60 ))#line:1537
                    OO0OO000O000O00OO +=1 #line:1538
                    if OO00O00OO0OOO0O00 .iscanceled ():#line:1539
                     OO00O00OO0OOO0O00 .close ()#line:1540
                     break #line:1541
    O00O0OO0O0O000O0O ="https://docs.google.com/uc?export=download"#line:1542
    import urllib2 #line:1547
    import cookielib #line:1548
    from cookielib import CookieJar #line:1550
    O00O000O00OOO0O00 =CookieJar ()#line:1552
    O0O0OOO00OOOOO0O0 =build_opener (HTTPCookieProcessor (O00O000O00OOO0O00 ))#line:1553
    O00OO00O0000OO000 ={'id':O0O00O0O00O0O00OO }#line:1555
    OO0O0O000O0O00OOO =urllib .urlencode (O00OO00O0000OO000 )#line:1556
    OOO0OOOOOO0O0O0O0 =O0O0OOO00OOOOO0O0 .open (O00O0OO0O0O000O0O +'&'+OO0O0O000O0O00OOO )#line:1558
    O00OO0O0OOO0OOO0O =OOO0OOOOOO0O0O0O0 .read ()#line:1559
    OO00OO000OOO0O0OO =O00OOOOOO00OOOOO0 (O00O000O00OOO0O00 )#line:1563
    if OO00OO000OOO0O0OO :#line:1565
        OOO0000000OO0OO0O ={'id':O0O00O0O00O0O00OO ,'confirm':OO00OO000OOO0O0OO }#line:1566
        OO0O000OOOOOOOO00 ={'Access-Control-Allow-Headers':'Content-Length'}#line:1567
        OO0O0O000O0O00OOO =urllib .urlencode (OOO0000000OO0OO0O )#line:1568
        OOO0OOOOOO0O0O0O0 =O0O0OOO00OOOOO0O0 .open (O00O0OO0O0O000O0O +'&'+OO0O0O000O0O00OOO )#line:1569
        chunk_read (OOO0OOOOOO0O0O0O0 ,report_hook =chunk_report ,dp =OO00O00OO0OOO0O00 ,destination =O00OOO0O00O0O0OOO ,filesize =O0O0OOOO0OO0OOO0O )#line:1570
    return (OO000O00O0O000OO0 )#line:1574
def resetkodi ():#line:1575
        if xbmc .getCondVisibility ('system.platform.windows'):#line:1576
            O0OOOO00000OO0O0O =xbmcgui .DialogProgress ()#line:1577
            try :#line:1578
                O0OOOO00000OO0O0O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות",'',"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1580
            except :#line:1581
                O0OOOO00000OO0O0O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1583
            O0OOOO00000OO0O0O .update (0 )#line:1584
            for O00OO00O0OO0000O0 in range (5 ,-1 ,-1 ):#line:1585
                time .sleep (1 )#line:1586
                try :#line:1587
                    O0OOOO00000OO0O0O .update (int ((5 -O00OO00O0OO0000O0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O00OO00O0OO0000O0 ),'')#line:1588
                except :#line:1589
                    O0OOOO00000OO0O0O .update (int ((5 -O00OO00O0OO0000O0 )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (O00OO00O0OO0000O0 )+'\n'+'[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')#line:1590
                if O0OOOO00000OO0O0O .iscanceled ():#line:1591
                    from resources .libs import win #line:1592
                    return None ,None #line:1593
            from resources .libs import win #line:1594
        else :#line:1595
            O0OOOO00000OO0O0O =xbmcgui .DialogProgress ()#line:1596
            try :#line:1597
                O0OOOO00000OO0O0O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות",'',"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1599
            except :#line:1600
                O0OOOO00000OO0O0O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1602
            O0OOOO00000OO0O0O .update (0 )#line:1603
            for O00OO00O0OO0000O0 in range (5 ,-1 ,-1 ):#line:1604
                time .sleep (1 )#line:1605
                try :#line:1606
                    O0OOOO00000OO0O0O .update (int ((5 -O00OO00O0OO0000O0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O00OO00O0OO0000O0 ),'')#line:1607
                except :#line:1608
                    O0OOOO00000OO0O0O .update (int ((5 -O00OO00O0OO0000O0 )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (O00OO00O0OO0000O0 )+'\n'+'')#line:1609
                if O0OOOO00000OO0O0O .iscanceled ():#line:1610
                    from resources .libs import android #line:1612
                    return None ,None #line:1613
            from resources .libs import android #line:1614
def wizardUpdate (startup =None ):#line:1617
    if not xbmc .Player ().isPlaying ():#line:1618
        if workingURL (WIZARDFILE ):#line:1619
            O000O00OOO00O0000 =checkWizard ('version')#line:1620
            OOO0O00000OOOOOO0 =checkWizard ('zip')#line:1621
            if O000O00OOO00O0000 !=False and str (O000O00OOO00O0000 )>str (VERSION ):#line:1624
                O0O000O00000O0O0O =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,str (O000O00OOO00O0000 )))#line:1626
                try :os .remove (O0O000O00000O0O0O )#line:1627
                except :pass #line:1628
                if 'google'in OOO0O00000OOOOOO0 :#line:1629
                    O00O0OO00OOOOO000 =googledrive_download (OOO0O00000OOOOOO0 ,O0O000O00000O0O0O ,DP2 ,checkWizard ('filesize'))#line:1630
                else :#line:1631
                    downloaderwiz .download4 (OOO0O00000OOOOOO0 ,O0O000O00000O0O0O ,DP2 )#line:1632
                xbmc .sleep (1000 )#line:1633
                DP2 .create ('מתקין')#line:1634
                DP2 .update (100 ,message ='אנא המתן ...')#line:1635
                extract .all (O0O000O00000O0O0O ,ADDONS )#line:1636
                DP2 .close ()#line:1637
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:1639
                log ("[Auto Update Wizard] Wizard updated to v%s"%str (O000O00OOO00O0000 ),5 )#line:1640
                return #line:1642
            else :#line:1643
                if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:1644
                log ("[Auto Update Wizard] No New Version v%s"%str (O000O00OOO00O0000 ),5 )#line:1645
        else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,5 )#line:1646
def wizardUpdateDP (startup =None ):#line:1648
    if workingURL (WIZARDFILE ):#line:1649
        OOO0OOO0O0OOO0OO0 =checkWizard ('version')#line:1650
        OO000OOOO00OOOOO0 =checkWizard ('zip')#line:1651
        if OOO0OOO0O0OOO0OO0 !=False and str (OOO0OOO0O0OOO0OO0 )>str (VERSION ):#line:1652
            log ("[Auto Update Wizard] Installing wizard v%s"%str (OOO0OOO0O0OOO0OO0 ),5 )#line:1655
            DP .create (ADDONTITLE ,'[COLOR %s]מוריד גירסה חדשה יותר של Wizard'%COLOR2 +'\n'+''+'\n'+'אנא המתן[/COLOR]')#line:1657
            O0O0OO00OOOO0O0O0 =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,str (OOO0OOO0O0OOO0OO0 )))#line:1658
            try :os .remove (O0O0OO00OOOO0O0O0 )#line:1659
            except :pass #line:1660
            if 'google'in OO000OOOO00OOOOO0 :#line:1661
                O000OO0000OOOOO00 =googledrive_download (OO000OOOO00OOOOO0 ,O0O0OO00OOOO0O0O0 ,DP ,checkWizard ('filesize'))#line:1662
            downloader .download (OO000OOOO00OOOOO0 ,O0O0OO00OOOO0O0O0 ,DP )#line:1663
            xbmc .sleep (1000 )#line:1664
            DP .update (0 ,"Installing %s update"%ADDONTITLE )#line:1666
            O0000O00O0O0O0O00 ,O0O0O0000OOO00OO0 ,O00OO0O0OO000OO00 =extract .all (O0O0OO00OOOO0O0O0 ,ADDONS ,DP ,True )#line:1667
            DP .close ()#line:1668
            return #line:1672
        else :#line:1673
            if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:1674
            log ("[Auto Update Wizard] No New Version v%s"%str (OOO0OOO0O0OOO0OO0 ),5 )#line:1675
    else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,5 )#line:1676
def convertText ():#line:1678
    O0O0O00OOO00OOO00 =os .path .join (ADDONDATA ,'TextFiles')#line:1679
    if not os .path .exists (O0O0O00OOO00OOO00 ):os .makedirs (O0O0O00OOO00OOO00 )#line:1680
    DP .create (ADDONTITLE ,'[COLOR %s][B]Converting Text:[/B][/COLOR]'%(COLOR2 ),'','Please Wait')#line:1682
    if not ld (BL )=='http://':#line:1684
        OOOO0OO0OOOOOO0O0 =os .path .join (O0O0O00OOO00OOO00 ,'builds.txt')#line:1685
        OOOO000OO00OO0OO0 ='';OOOO00O00O0OOOOOO =0 #line:1686
        O000OO0O000000O0O =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:1687
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Builds.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1688
        if WIZARDFILE ==ld (BL ):#line:1689
            try :#line:1690
                OOO00O00OOOOO0OOO ,O0O0O000OOO0OO0O0 ,OO0O0O00OO000O000 =checkWizard ('all')#line:1691
                OOOO000OO00OO0OO0 ='id="%s"\n'%OOO00O00OOOOO0OOO #line:1692
                OOOO000OO00OO0OO0 +='version="%s"\n'%O0O0O000OOO0OO0O0 #line:1693
                OOOO000OO00OO0OO0 +='zip="%s"\n'%OO0O0O00OO000O000 #line:1694
            except :#line:1695
                pass #line:1696
        OO0OO000OOOOO000O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O000OO0O000000O0O )#line:1697
        OO00OOO00000O0O0O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OO0O000000O0O )#line:1698
        if len (OO00OOO00000O0O0O )==0 :#line:1699
            for OO0O00O0000O00000 ,O0O0O000OOO0OO0O0 ,OO0O0O00OO000O000 ,O0000O0OO00O000O0 ,OOO00OO000OO0O0OO ,OOOO00OO00O0000O0 ,O0OO0O0OO0O0O0000 ,O0O00OO00OOOO00OO in OO0OO000OOOOO000O :#line:1700
                OOOO00O00O0OOOOOO +=1 #line:1701
                DP .update (int (percentage (OOOO00O00O0OOOOOO ,len (OO00OOO00000O0O0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0000O00000 ))#line:1702
                if not OOOO000OO00OO0OO0 =='':OOOO000OO00OO0OO0 +='\n'#line:1703
                OOOO000OO00OO0OO0 +='name="%s"\n'%OO0O00O0000O00000 #line:1704
                OOOO000OO00OO0OO0 +='version="%s"\n'%O0O0O000OOO0OO0O0 #line:1705
                OOOO000OO00OO0OO0 +='url="%s"\n'%OO0O0O00OO000O000 #line:1706
                OOOO000OO00OO0OO0 +='gui="%s"\n'%O0000O0OO00O000O0 #line:1707
                OOOO000OO00OO0OO0 +='kodi="%s"\n'%OOO00OO000OO0O0OO #line:1708
                OOOO000OO00OO0OO0 +='theme="%s"\n'%OOOO00OO00O0000O0 #line:1709
                OOOO000OO00OO0OO0 +='icon="%s"\n'%O0OO0O0OO0O0O0000 #line:1710
                OOOO000OO00OO0OO0 +='fanart="%s"\n'%O0O00OO00OOOO00OO #line:1711
                OOOO000OO00OO0OO0 +='preview="http://"\n'#line:1712
                OOOO000OO00OO0OO0 +='adult="no"\n'#line:1713
                OOOO000OO00OO0OO0 +='description="Download %s from %s"\n'%(OO0O00O0000O00000 ,ADDONTITLE )#line:1714
                if not OOOO00OO00O0000O0 =='http://':#line:1715
                    OOO0000OOOOOO0OOO =os .path .join (O0O0O00OOO00OOO00 ,'%s_theme.txt'%OO0O00O0000O00000 )#line:1716
                    O00O000O00O000000 ='';OO0O000000OO00O00 =0 #line:1717
                    O000OO0O000000O0O =openURL (OOOO00OO00O0000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1718
                    DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00O0000O00000 ),'','Please Wait')#line:1719
                    OOOOOOOOO000O0OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000OO0O000000O0O )#line:1720
                    for OO0O00O0000O00000 ,OO0O0O00OO000O000 ,O0OO0O0OO0O0O0000 ,O0O00OO00OOOO00OO ,O00OOOOOOO000000O in OOOOOOOOO000O0OO0 :#line:1721
                        OO0O000000OO00O00 +=1 #line:1722
                        DP .update (int (percentage (OO0O000000OO00O00 ,len (OO00OOO00000O0O0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0000O00000 ))#line:1723
                        if not O00O000O00O000000 =='':O00O000O00O000000 +='\n'#line:1724
                        O00O000O00O000000 +='name="%s"\n'%OO0O00O0000O00000 #line:1725
                        O00O000O00O000000 +='url="%s"\n'%OO0O0O00OO000O000 #line:1726
                        O00O000O00O000000 +='icon="%s"\n'%O0OO0O0OO0O0O0000 #line:1727
                        O00O000O00O000000 +='fanart="%s"\n'%O0O00OO00OOOO00OO #line:1728
                        O00O000O00O000000 +='adult="no"\n'#line:1729
                        O00O000O00O000000 +='description="%s"\n'%O00OOOOOOO000000O #line:1730
                    OOOO00O000OO00OO0 =open (OOO0000OOOOOO0OOO ,'w');OOOO00O000OO00OO0 .write (O00O000O00O000000 );OOOO00O000OO00OO0 .close ()#line:1731
        else :#line:1732
            for OO0O00O0000O00000 ,O0O0O000OOO0OO0O0 ,OO0O0O00OO000O000 ,O0000O0OO00O000O0 ,OOO00OO000OO0O0OO ,OOOO00OO00O0000O0 ,O0OO0O0OO0O0O0000 ,O0O00OO00OOOO00OO ,O00OO000O0OO00O00 ,O00OOOOOOO000000O in OO00OOO00000O0O0O :#line:1733
                OOOO00O00O0OOOOOO +=1 #line:1734
                DP .update (int (percentage (OOOO00O00O0OOOOOO ,len (OO00OOO00000O0O0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0000O00000 ))#line:1735
                if not OOOO000OO00OO0OO0 =='':OOOO000OO00OO0OO0 +='\n'#line:1736
                OOOO000OO00OO0OO0 +='name="%s"\n'%OO0O00O0000O00000 #line:1737
                OOOO000OO00OO0OO0 +='version="%s"\n'%O0O0O000OOO0OO0O0 #line:1738
                OOOO000OO00OO0OO0 +='url="%s"\n'%OO0O0O00OO000O000 #line:1739
                OOOO000OO00OO0OO0 +='gui="%s"\n'%O0000O0OO00O000O0 #line:1740
                OOOO000OO00OO0OO0 +='kodi="%s"\n'%OOO00OO000OO0O0OO #line:1741
                OOOO000OO00OO0OO0 +='theme="%s"\n'%OOOO00OO00O0000O0 #line:1742
                OOOO000OO00OO0OO0 +='icon="%s"\n'%O0OO0O0OO0O0O0000 #line:1743
                OOOO000OO00OO0OO0 +='fanart="%s"\n'%O0O00OO00OOOO00OO #line:1744
                OOOO000OO00OO0OO0 +='preview="http://"\n'#line:1745
                OOOO000OO00OO0OO0 +='adult="%s"\n'%O00OO000O0OO00O00 #line:1746
                OOOO000OO00OO0OO0 +='description="%s"\n'%O00OOOOOOO000000O #line:1747
                if not OOOO00OO00O0000O0 =='http://':#line:1748
                    OOO0000OOOOOO0OOO =os .path .join (O0O0O00OOO00OOO00 ,'%s_theme.txt'%OO0O00O0000O00000 )#line:1749
                    O00O000O00O000000 ='';OO0O000000OO00O00 =0 #line:1750
                    O000OO0O000000O0O =openURL (OOOO00OO00O0000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1751
                    DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00O0000O00000 ),'','Please Wait')#line:1752
                    OOOOOOOOO000O0OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000OO0O000000O0O )#line:1753
                    for OO0O00O0000O00000 ,OO0O0O00OO000O000 ,O0OO0O0OO0O0O0000 ,O0O00OO00OOOO00OO ,O00OOOOOOO000000O in OOOOOOOOO000O0OO0 :#line:1754
                        OO0O000000OO00O00 +=1 #line:1755
                        DP .update (int (percentage (OO0O000000OO00O00 ,len (OO00OOO00000O0O0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0000O00000 ))#line:1756
                        if not O00O000O00O000000 =='':O00O000O00O000000 +='\n'#line:1757
                        O00O000O00O000000 +='name="%s"\n'%OO0O00O0000O00000 #line:1758
                        O00O000O00O000000 +='url="%s"\n'%OO0O0O00OO000O000 #line:1759
                        O00O000O00O000000 +='icon="%s"\n'%O0OO0O0OO0O0O0000 #line:1760
                        O00O000O00O000000 +='fanart="%s"\n'%O0O00OO00OOOO00OO #line:1761
                        O00O000O00O000000 +='adult="no"\n'#line:1762
                        O00O000O00O000000 +='description="%s"\n'%O00OOOOOOO000000O #line:1763
                    OOOO00O000OO00OO0 =open (OOO0000OOOOOO0OOO ,'w');OOOO00O000OO00OO0 .write (O00O000O00O000000 );OOOO00O000OO00OO0 .close ()#line:1764
        OOOO00O000OO00OO0 =open (OOOO0OO0OOOOOO0O0 ,'w');OOOO00O000OO00OO0 .write (OOOO000OO00OO0OO0 );OOOO00O000OO00OO0 .close ()#line:1765
    if not APKFILE =='http://':#line:1767
        OOOO0OO0OOOOOO0O0 =os .path .join (O0O0O00OOO00OOO00 ,'apks.txt')#line:1768
        OOOO000OO00OO0OO0 ='';OOOO00O00O0OOOOOO =0 #line:1769
        O000OO0O000000O0O =openURL (APKFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1770
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Apks.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1771
        OO0OO000OOOOO000O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O000OO0O000000O0O )#line:1772
        OO00OOO00000O0O0O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OO0O000000O0O )#line:1773
        if len (OO00OOO00000O0O0O )==0 :#line:1774
            for OO0O00O0000O00000 ,OO0O0O00OO000O000 ,O0OO0O0OO0O0O0000 ,O0O00OO00OOOO00OO in OO0OO000OOOOO000O :#line:1775
                OOOO00O00O0OOOOOO +=1 #line:1776
                DP .update (int (percentage (OOOO00O00O0OOOOOO ,len (OO0OO000OOOOO000O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0000O00000 ))#line:1777
                if not OOOO000OO00OO0OO0 =='':OOOO000OO00OO0OO0 +='\n'#line:1778
                OOOO000OO00OO0OO0 +='name="%s"\n'%OO0O00O0000O00000 #line:1779
                OOOO000OO00OO0OO0 +='section="no"'#line:1780
                OOOO000OO00OO0OO0 +='url="%s"\n'%OO0O0O00OO000O000 #line:1781
                OOOO000OO00OO0OO0 +='icon="%s"\n'%O0OO0O0OO0O0O0000 #line:1782
                OOOO000OO00OO0OO0 +='fanart="%s"\n'%O0O00OO00OOOO00OO #line:1783
                OOOO000OO00OO0OO0 +='adult="no"\n'#line:1784
                OOOO000OO00OO0OO0 +='description="Download %s from %s"\n'%(OO0O00O0000O00000 ,ADDONTITLE )#line:1785
        else :#line:1786
            for OO0O00O0000O00000 ,OO0O0O00OO000O000 ,O0OO0O0OO0O0O0000 ,O0O00OO00OOOO00OO ,O00OO000O0OO00O00 ,O00OOOOOOO000000O in OO00OOO00000O0O0O :#line:1787
                OOOO00O00O0OOOOOO +=1 #line:1788
                DP .update (int (percentage (OOOO00O00O0OOOOOO ,len (OO00OOO00000O0O0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0000O00000 ))#line:1789
                if not OOOO000OO00OO0OO0 =='':OOOO000OO00OO0OO0 +='\n'#line:1790
                OOOO000OO00OO0OO0 +='name="%s"\n'%OO0O00O0000O00000 #line:1791
                OOOO000OO00OO0OO0 +='section="no"'#line:1792
                OOOO000OO00OO0OO0 +='url="%s"\n'%OO0O0O00OO000O000 #line:1793
                OOOO000OO00OO0OO0 +='icon="%s"\n'%O0OO0O0OO0O0O0000 #line:1794
                OOOO000OO00OO0OO0 +='fanart="%s"\n'%O0O00OO00OOOO00OO #line:1795
                OOOO000OO00OO0OO0 +='adult="%s"\n'%O00OO000O0OO00O00 #line:1796
                OOOO000OO00OO0OO0 +='description="%s"\n'%O00OOOOOOO000000O #line:1797
        OOOO00O000OO00OO0 =open (OOOO0OO0OOOOOO0O0 ,'w');OOOO00O000OO00OO0 .write (OOOO000OO00OO0OO0 );OOOO00O000OO00OO0 .close ()#line:1798
    if not YOUTUBEFILE =='http://':#line:1800
        OOOO0OO0OOOOOO0O0 =os .path .join (O0O0O00OOO00OOO00 ,'youtube.txt')#line:1801
        OOOO000OO00OO0OO0 ='';OOOO00O00O0OOOOOO =0 #line:1802
        O000OO0O000000O0O =openURL (YOUTUBEFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1803
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]YouTube.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1804
        OO0OO000OOOOO000O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000OO0O000000O0O )#line:1805
        for OO0O00O0000O00000 ,OO0O0O00OO000O000 ,O0OO0O0OO0O0O0000 ,O0O00OO00OOOO00OO ,O00OOOOOOO000000O in OO0OO000OOOOO000O :#line:1806
            OOOO00O00O0OOOOOO +=1 #line:1807
            DP .update (int (percentage (OOOO00O00O0OOOOOO ,len (OO0OO000OOOOO000O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0000O00000 ))#line:1808
            if not OOOO000OO00OO0OO0 =='':OOOO000OO00OO0OO0 +='\n'#line:1809
            OOOO000OO00OO0OO0 +='name="%s"\n'%OO0O00O0000O00000 #line:1810
            OOOO000OO00OO0OO0 +='section="no"'#line:1811
            OOOO000OO00OO0OO0 +='url="%s"\n'%OO0O0O00OO000O000 #line:1812
            OOOO000OO00OO0OO0 +='icon="%s"\n'%O0OO0O0OO0O0O0000 #line:1813
            OOOO000OO00OO0OO0 +='fanart="%s"\n'%O0O00OO00OOOO00OO #line:1814
            OOOO000OO00OO0OO0 +='description="%s"\n'%O00OOOOOOO000000O #line:1815
        OOOO00O000OO00OO0 =open (OOOO0OO0OOOOOO0O0 ,'w');OOOO00O000OO00OO0 .write (OOOO000OO00OO0OO0 );OOOO00O000OO00OO0 .close ()#line:1816
    if not ADVANCEDFILE =='http://':#line:1818
        OOOO0OO0OOOOOO0O0 =os .path .join (O0O0O00OOO00OOO00 ,'advancedsettings.txt')#line:1819
        OOOO000OO00OO0OO0 ='';OOOO00O00O0OOOOOO =0 #line:1820
        O000OO0O000000O0O =openURL (ADVANCEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1821
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]AdvancedSettings.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1822
        OO0OO000OOOOO000O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000OO0O000000O0O )#line:1823
        for OO0O00O0000O00000 ,OO0O0O00OO000O000 ,O0OO0O0OO0O0O0000 ,O0O00OO00OOOO00OO ,O00OOOOOOO000000O in OO0OO000OOOOO000O :#line:1824
            OOOO00O00O0OOOOOO +=1 #line:1825
            DP .update (int (percentage (OOOO00O00O0OOOOOO ,len (OO0OO000OOOOO000O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0000O00000 ))#line:1826
            if not OOOO000OO00OO0OO0 =='':OOOO000OO00OO0OO0 +='\n'#line:1827
            OOOO000OO00OO0OO0 +='name="%s"\n'%OO0O00O0000O00000 #line:1828
            OOOO000OO00OO0OO0 +='section="no"'#line:1829
            OOOO000OO00OO0OO0 +='url="%s"\n'%OO0O0O00OO000O000 #line:1830
            OOOO000OO00OO0OO0 +='icon="%s"\n'%O0OO0O0OO0O0O0000 #line:1831
            OOOO000OO00OO0OO0 +='fanart="%s"\n'%O0O00OO00OOOO00OO #line:1832
            OOOO000OO00OO0OO0 +='description="%s"\n'%O00OOOOOOO000000O #line:1833
        OOOO00O000OO00OO0 =open (OOOO0OO0OOOOOO0O0 ,'w');OOOO00O000OO00OO0 .write (OOOO000OO00OO0OO0 );OOOO00O000OO00OO0 .close ()#line:1834
    DP .close ()#line:1836
    DIALOG .ok (ADDONTITLE ,'[COLOR %s]Your text files have been converted to 0.1.7 and are location in the [COLOR %s]/addon_data/%s/[/COLOR] folder[/COLOR]'%(COLOR2 ,COLOR1 ,ADDON_ID ))#line:1837
def reloadProfile (profile =None ):#line:1839
    if profile ==None :#line:1840
        ebi ('LoadProfile(Master user)')#line:1847
    else :ebi ('LoadProfile(%s)'%profile )#line:1848
def chunks (O0O0O0O0OOO0O0O0O ,O0O0OOOOO000O0OOO ):#line:1850
    for O000O0O00O00OO0O0 in range (0 ,len (O0O0O0O0OOO0O0O0O ),O0O0OOOOO000O0OOO ):#line:1851
        yield O0O0O0O0OOO0O0O0O [O000O0O00O00OO0O0 :O000O0O00O00OO0O0 +O0O0OOOOO000O0OOO ]#line:1852
def asciiCheck (use =None ,over =False ):#line:1854
    if use ==None :#line:1855
        O0O0OOO000OO0OO00 =DIALOG .browse (3 ,'[COLOR %s]Select the folder you want to scan[/COLOR]'%COLOR2 ,'files','',False ,False ,HOME )#line:1856
        if over ==True :#line:1857
            O00OO0O0O00OOO00O =1 #line:1858
        else :#line:1859
            O00OO0O0O00OOO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Do you want to [COLOR %s]delete[/COLOR] all filenames with special characters or would you rather just [COLOR %s]scan and view[/COLOR] the results in the log?[/COLOR]'%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ='[B][COLOR green]Delete[/COLOR][/B]',nolabel ='[B][COLOR red]Scan[/COLOR][/B]')#line:1860
    else :#line:1861
        O0O0OOO000OO0OO00 =use #line:1862
        O00OO0O0O00OOO00O =1 #line:1863
    if O0O0OOO000OO0OO00 =="":#line:1865
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: Cancelled[/COLOR]"%COLOR2 )#line:1866
        return #line:1867
    OOO0OOOOOOO0O000O =os .path .join (ADDONDATA ,'asciifiles.txt')#line:1869
    OO00OO0O000OO0OOO =os .path .join (ADDONDATA ,'asciifails.txt')#line:1870
    OOOOOO0OOOO0OO0OO =open (OOO0OOOOOOO0O000O ,mode ='w+')#line:1871
    OOOO0OO0O0OO0OOO0 =open (OO00OO0O000OO0OOO ,mode ='w+')#line:1872
    O0O000O00OOOO00OO =0 ;O000OO000OO0O000O =0 #line:1873
    O0OOO00000OO00OO0 =fileCount (O0O0OOO000OO0OO00 )#line:1874
    OOO0O000OO0O000O0 =''#line:1875
    OOO0O0OO0O000O0OO =[]#line:1876
    log ("Source file: (%s)"%str (O0O0OOO000OO0OO00 ),5 )#line:1877
    DP .create (ADDONTITLE ,'Please wait...')#line:1879
    for OOOOOO0OO0OOO0000 ,OOO00O0O0O0OO0O0O ,O0O0OO0O0O0O00O00 in os .walk (O0O0OOO000OO0OO00 ):#line:1880
        OOO00O0O0O0OO0O0O [:]=[O0OOO0O0OOOOOO0O0 for O0OOO0O0OOOOOO0O0 in OOO00O0O0O0OO0O0O ]#line:1881
        O0O0OO0O0O0O00O00 [:]=[OO000OOOO000OO0OO for OO000OOOO000OO0OO in O0O0OO0O0O0O00O00 ]#line:1882
        for O0OOOO0OOO0O0OOO0 in O0O0OO0O0O0O00O00 :#line:1883
            OOO0O0OO0O000O0OO .append (O0OOOO0OOO0O0OOO0 )#line:1884
            O0000000OO00000OO =int (len (OOO0O0OO0O000O0OO )/float (O0OOO00000OO00OO0 )*100 )#line:1885
            DP .update (O0000000OO00000OO ,"[COLOR %s]Checking for non ASCII files"%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,d ),'Please Wait[/COLOR]')#line:1886
            try :#line:1887
                O0OOOO0OOO0O0OOO0 .encode ('ascii')#line:1888
            except UnicodeDecodeError :#line:1889
                O00OOO00O0O0O0O0O =os .path .join (OOOOOO0OO0OOO0000 ,O0OOOO0OOO0O0OOO0 )#line:1890
                if O00OO0O0O00OOO00O :#line:1891
                    try :#line:1892
                        os .remove (O00OOO00O0O0O0O0O )#line:1893
                        for OOO00OO0O00OOOO0O in chunks (O00OOO00O0O0O0O0O ,75 ):#line:1894
                            OOOOOO0OOOO0OO0OO .write (OOO00OO0O00OOOO0O +'\n')#line:1895
                        OOOOOO0OOOO0OO0OO .write ('\n')#line:1896
                        O0O000O00OOOO00OO +=1 #line:1897
                        log ("[ASCII Check] File Removed: %s "%O00OOO00O0O0O0O0O ,5 )#line:1898
                    except :#line:1899
                        for OOO00OO0O00OOOO0O in chunks (O00OOO00O0O0O0O0O ,75 ):#line:1900
                            OOOO0OO0O0OO0OOO0 .write (OOO00OO0O00OOOO0O +'\n')#line:1901
                        OOOO0OO0O0OO0OOO0 .write ('\n')#line:1902
                        O000OO000OO0O000O +=1 #line:1903
                        log ("[ASCII Check] File Failed: %s "%O00OOO00O0O0O0O0O ,5 )#line:1904
                else :#line:1905
                    for OOO00OO0O00OOOO0O in chunks (O00OOO00O0O0O0O0O ,75 ):#line:1906
                        OOOOOO0OOOO0OO0OO .write (OOO00OO0O00OOOO0O +'\n')#line:1907
                    OOOOOO0OOOO0OO0OO .write ('\n')#line:1908
                    O0O000O00OOOO00OO +=1 #line:1909
                    log ("[ASCII Check] File Found: %s "%O00OOO00O0O0O0O0O ,5 )#line:1910
                pass #line:1911
    DP .close ();OOOOOO0OOOO0OO0OO .close ();OOOO0OO0O0OO0OOO0 .close ()#line:1912
    OOOOOO00OO0OOO0OO =int (O0O000O00OOOO00OO )+int (O000OO000OO0O000O )#line:1913
    if OOOOOO00OO0OOO0OO >0 :#line:1914
        if os .path .exists (OOO0OOOOOOO0O000O ):OOOOOO0OOOO0OO0OO =open (OOO0OOOOOOO0O000O ,mode ='r');OOO0O000OO0O000O0 =OOOOOO0OOOO0OO0OO .read ();OOOOOO0OOOO0OO0OO .close ()#line:1915
        if os .path .exists (OO00OO0O000OO0OOO ):OOOO0OO0O0OO0OOO0 =open (OO00OO0O000OO0OOO ,mode ='r');OOO00OO0O0OO0OOOO =OOOO0OO0O0OO0OOO0 .read ();OOOO0OO0O0OO0OOO0 .close ()#line:1916
        if O00OO0O0O00OOO00O :#line:1917
            if use :#line:1918
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: %s Removed / %s Failed.[/COLOR]"%(COLOR2 ,O0O000O00OOOO00OO ,O000OO000OO0O000O ))#line:1919
            else :#line:1920
                TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Removed:[/B][/COLOR]\n %s\n\n[COLOR yellow][B]%s Files Failed:[B][/COLOR]\n %s"%(O0O000O00OOOO00OO ,OOO0O000OO0O000O0 ,O000OO000OO0O000O ,OOO00OO0O0OO0OOOO ))#line:1921
        else :#line:1922
            TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Found:[/B][/COLOR]\n %s"%(O0O000O00OOOO00OO ,OOO0O000OO0O000O0 ))#line:1923
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: None Found.[/COLOR]"%COLOR2 )#line:1924
def fileCount (O0OOOO00O00O0O00O ,excludes =True ):#line:1926
    OO00OO000OOOO0O0O =[ADDON_ID ,'cache','system','packages','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:1927
    OO0OOOOO000000OOO =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:1928
    OO00OOOOOOO0O0OOO =[]#line:1929
    for O0000000O0000O00O ,OO0O0OOOO0O00O000 ,OOOO00O00OO0OOOO0 in os .walk (O0OOOO00O00O0O00O ):#line:1930
        if excludes :#line:1931
            OO0O0OOOO0O00O000 [:]=[O00OO000O000OO0OO for O00OO000O000OO0OO in OO0O0OOOO0O00O000 if O00OO000O000OO0OO not in OO00OO000OOOO0O0O ]#line:1932
            OOOO00O00OO0OOOO0 [:]=[OOO00O00OOO00O0O0 for OOO00O00OOO00O0O0 in OOOO00O00OO0OOOO0 if OOO00O00OOO00O0O0 not in OO0OOOOO000000OOO ]#line:1933
        for OO00O0O000OOOOOOO in OOOO00O00OO0OOOO0 :#line:1934
            OO00OOOOOOO0O0OOO .append (OO00O0O000OOOOOOO )#line:1935
    return len (OO00OOOOOOO0O0OOO )#line:1936
def defaultSkin ():#line:1938
    log ("[Default Skin Check]",5 )#line:1939
    OO0O0OOOOOO0OOO0O =os .path .join (USERDATA ,'guitemp.xml')#line:1940
    O0O0OOOO0O0O0OOO0 =OO0O0OOOOOO0OOO0O if os .path .exists (OO0O0OOOOOO0OOO0O )else GUISETTINGS #line:1941
    if not os .path .exists (O0O0OOOO0O0O0OOO0 ):return False #line:1942
    log ("Reading gui file: %s"%O0O0OOOO0O0O0OOO0 ,5 )#line:1943
    OO0O0O0OOOOOOO0OO =open (O0O0OOOO0O0O0OOO0 ,'r+')#line:1944
    O0O0000000O0OO0O0 =OO0O0O0OOOOOOO0OO .read ().replace ('\n','').replace ('\r','').replace ('\t','').replace ('    ','');OO0O0O0OOOOOOO0OO .close ()#line:1945
    log ("Opening gui settings",5 )#line:1946
    OOOOO0O00OO000000 =re .compile ('<lookandfeel>.+?<ski.+?>(.+?)</skin>.+?</lookandfeel>').findall (O0O0000000O0OO0O0 )#line:1947
    log ("Matches: %s"%str (OOOOO0O00OO000000 ),5 )#line:1948
    if len (OOOOO0O00OO000000 )>0 :#line:1949
        OOO00O0O0000O0OO0 =OOOOO0O00OO000000 [0 ]#line:1950
        OO0O0OO00000OOO00 =os .path .join (ADDONS ,OOOOO0O00OO000000 [0 ],'addon.xml')#line:1951
        if os .path .exists (OO0O0OO00000OOO00 ):#line:1952
            O0OO000O00O0OO0OO =open (OO0O0OO00000OOO00 ,'r+')#line:1953
            OO00OO00O0OO00OOO =O0OO000O00O0OO0OO .read ();O0OO000O00O0OO0OO .close ()#line:1954
            OO0OO0OO000OOOOOO =parseDOM (OO00OO00O0OO00OOO ,'addon',ret ='name')#line:1955
            if len (OO0OO0OO000OOOOOO )>0 :O0O00O0O0000O0000 =OO0OO0OO000OOOOOO [0 ]#line:1956
            else :O0O00O0O0000O0000 ='no match'#line:1957
        else :O0O00O0O0000O0000 ='no file'#line:1958
        log ("[Default Skin Check] Skin name: %s"%O0O00O0O0000O0000 ,5 )#line:1959
        log ("[Default Skin Check] Skin id: %s"%OOO00O0O0000O0OO0 ,5 )#line:1960
        setS ('defaultskin',OOO00O0O0000O0OO0 )#line:1961
        setS ('defaultskinname',O0O00O0O0000O0000 )#line:1962
        setS ('defaultskinignore','false')#line:1963
    if os .path .exists (OO0O0OOOOOO0OOO0O ):#line:1964
        log ("Deleting Temp Gui File.",5 )#line:1965
        os .remove (OO0O0OOOOOO0OOO0O )#line:1966
    log ("[Default Skin Check] End",5 )#line:1967
def lookandFeelData (do ='save'):#line:1969
    OO0O0OO0O0OOO0O0O =['lookandfeel.enablerssfeeds','lookandfeel.font','lookandfeel.rssedit','lookandfeel.skincolors','lookandfeel.skintheme','lookandfeel.skinzoom','lookandfeel.soundskin','lookandfeel.startupwindow','lookandfeel.stereostrength']#line:1970
    if do =='save':#line:1971
        for OO0O0O00OO00OOOOO in OO0O0OO0O0OOO0O0O :#line:1972
            O0OOO0O00O000000O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":"%s"}, "id":1}'%(OO0O0O00OO00OOOOO )#line:1973
            O0OO000OOOO0OOO00 =xbmc .executeJSONRPC (O0OOO0O00O000000O )#line:1974
            if not 'error'in O0OO000OOOO0OOO00 :#line:1975
                O0O0OO0OOO0O0O000 =re .compile ('{"value":(.+?)}').findall (str (O0OO000OOOO0OOO00 ))#line:1976
                setS (OO0O0O00OO00OOOOO .replace ('lookandfeel','default'),O0O0OO0OOO0O0O000 [0 ])#line:1977
                log ("%s saved to %s"%(OO0O0O00OO00OOOOO ,O0O0OO0OOO0O0O000 [0 ]),5 )#line:1978
    else :#line:1979
        for OO0O0O00OO00OOOOO in OO0O0OO0O0OOO0O0O :#line:1980
            O0OOOO000OOOOOOOO =getS (OO0O0O00OO00OOOOO .replace ('lookandfeel','default'))#line:1981
            O0OOO0O00O000000O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"%s","value":%s}, "id":1}'%(OO0O0O00OO00OOOOO ,O0OOOO000OOOOOOOO )#line:1982
            O0OO000OOOO0OOO00 =xbmc .executeJSONRPC (O0OOO0O00O000000O )#line:1983
            log ("%s restored to %s"%(OO0O0O00OO00OOOOO ,O0OOOO000OOOOOOOO ),5 )#line:1984
def sep (middle =''):#line:1986
    O0OOO0OO0O00OOOO0 =uservar .SPACER #line:1987
    O000O0O0O0OOO0O0O =O0OOO0OO0O00OOOO0 *40 #line:1988
    if not middle =='':#line:1989
        middle ='[ %s ]'%middle #line:1990
        OO0O00O0OO0OO0OO0 =int ((40 -len (middle ))/2 )#line:1991
        O000O0O0O0OOO0O0O ="%s%s%s"%(O000O0O0O0OOO0O0O [:OO0O00O0OO0OO0OO0 ],middle ,O000O0O0O0OOO0O0O [:OO0O00O0OO0OO0OO0 +2 ])#line:1992
    return O000O0O0O0OOO0O0O [:40 ]#line:1993
def convertAdvanced ():#line:1995
    if os .path .exists (ADVANCED ):#line:1996
        O0O0OOOOO0OOO00O0 =open (ADVANCED )#line:1997
        OOO0000OO000OO0O0 =O0O0OOOOO0OOO00O0 .read ()#line:1998
        if KODIV >=17 :#line:1999
            return #line:2000
        else :#line:2001
            return #line:2002
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2003
def backUpOptions (OOOOOO000O0O00O0O ,name =""):#line:2008
    OO000O000000OO0OO =[ADDON_ID ,'cache','system','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:2009
    OO00OOO000O00O000 =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:2010
    O00O000000O0OOOO0 =[os .path .join (DATABASE ,'onechannelcache.db'),os .path .join (DATABASE ,'saltscache.db'),os .path .join (DATABASE ,'saltscache.db-shm'),os .path .join (DATABASE ,'saltscache.db-wal'),os .path .join (DATABASE ,'saltshd.lite.db'),os .path .join (DATABASE ,'saltshd.lite.db-shm'),os .path .join (DATABASE ,'saltshd.lite.db-wal'),os .path .join (ADDOND ,'script.trakt','queue.db'),os .path .join (HOME ,'cache','commoncache.db'),os .path .join (ADDOND ,'script.module.dudehere.routines','access.log'),os .path .join (ADDOND ,'script.module.dudehere.routines','trakt.db'),os .path .join (ADDOND ,'script.module.metahandler','meta_cache','video_cache.db')]#line:2022
    OO00O00O0O0O0OOO0 =translatepath (BACKUPLOCATION )#line:2024
    OOOO00O0O000OO0OO =translatepath (MYBUILDS )#line:2025
    try :#line:2026
        if not os .path .exists (OO00O00O0O0O0OOO0 ):xbmcvfs .mkdirs (OO00O00O0O0O0OOO0 )#line:2027
        if not os .path .exists (OOOO00O0O000OO0OO ):xbmcvfs .mkdirs (OOOO00O0O000OO0OO )#line:2028
    except Exception as OOOO0000000OOO0OO :#line:2029
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OOOO0000000OOO0OO )))#line:2030
        return #line:2031
    if OOOOOO000O0O00O0O =="build":#line:2032
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם ברצונך לגבות את הבילד?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR red]ביטול[/COLOR][/B]",yeslabel ="[B][COLOR green]גיבוי[/COLOR][/B]"):#line:2033
            if name =="":#line:2034
                name =getKeyboard ("","אנא הכנס שם ל %s באנגלית"%OOOOOO000O0O00O0O )#line:2035
                if not name :return False #line:2036
                name =name .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2037
            name =urllib .quote_plus (name );OOOOO0OOOOO0OOOO0 =''#line:2038
            O0OOOOOO00OO00OOO =os .path .join (OOOO00O0O000OO0OO ,'%s.zip'%name )#line:2039
            OOOO00000O0OOOO0O =0 #line:2040
            OOOOO000000OOOO0O =[]#line:2041
            if not DIALOG .yesno (ADDONTITLE ,"האם לשמור את תיקית האדון דאטה?",yeslabel ='[B][COLOR green]שמור[/COLOR][/B]',nolabel ='[B][COLOR red]לא לשמור[/COLOR][/B]'):#line:2042
                OO000O000000OO0OO .append ('addon_data')#line:2043
            convertSpecial (HOME ,True )#line:2044
            asciiCheck (HOME ,True )#line:2045
            try :#line:2046
                OO0000OO000O0OOO0 =zipfile .ZipFile (translatepath (O0OOOOOO00OO00OOO ),mode ='w')#line:2047
            except :#line:2048
                try :#line:2049
                    OOOOO0OOOOO0OOOO0 =os .path .join (PACKAGES ,'%s.zip'%name )#line:2050
                    OO0000OO000O0OOO0 =zipfile .ZipFile (OOOOO0OOOOO0OOOO0 ,mode ='w')#line:2051
                except :#line:2052
                    log ("Unable to create %s.zip"%name ,5 )#line:2053
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2054
                        openS ()#line:2055
                        return #line:2056
                    else :#line:2057
                        return #line:2058
            DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:2059
            for O00O0O00O0O000OO0 ,O00O0O0OOOOOO00O0 ,OOOO00000OOOO0O0O in os .walk (HOME ):#line:2060
                O00O0O0OOOOOO00O0 [:]=[OO00O000OOO00OOOO for OO00O000OOO00OOOO in O00O0O0OOOOOO00O0 if OO00O000OOO00OOOO not in OO000O000000OO0OO ]#line:2061
                OOOO00000OOOO0O0O [:]=[OOO0O0000OO0O00OO for OOO0O0000OO0O00OO in OOOO00000OOOO0O0O if OOO0O0000OO0O00OO not in OO00OOO000O00O000 ]#line:2062
                for O0O00OO00000O0O00 in OOOO00000OOOO0O0O :#line:2063
                    OOOOO000000OOOO0O .append (O0O00OO00000O0O00 )#line:2064
            OOO0O0O000OO0O0OO =len (OOOOO000000OOOO0O )#line:2065
            for O00O0O00O0O000OO0 ,O00O0O0OOOOOO00O0 ,OOOO00000OOOO0O0O in os .walk (HOME ):#line:2066
                O00O0O0OOOOOO00O0 [:]=[O000O00O00OO00O0O for O000O00O00OO00O0O in O00O0O0OOOOOO00O0 if O000O00O00OO00O0O not in OO000O000000OO0OO ]#line:2067
                OOOO00000OOOO0O0O [:]=[O00OOOO0OO0OOO0O0 for O00OOOO0OO0OOO0O0 in OOOO00000OOOO0O0O if O00OOOO0OO0OOO0O0 not in OO00OOO000O00O000 ]#line:2068
                for O0O00OO00000O0O00 in OOOO00000OOOO0O0O :#line:2069
                    try :#line:2070
                        OOOO00000O0OOOO0O +=1 #line:2071
                        O0OO0OOOOOO0OOOOO =percentage (OOOO00000O0OOOO0O ,OOO0O0O000OO0O0OO )#line:2072
                        DP .update (int (O0OO0OOOOOO0OOOOO ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO00000O0OOOO0O ,COLOR1 ,OOO0O0O000OO0O0OO ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00OO00000O0O00 ),'')#line:2073
                        O0O00O0O0OO0O000O =os .path .join (O00O0O00O0O000OO0 ,O0O00OO00000O0O00 )#line:2074
                        if O0O00OO00000O0O00 in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 );continue #line:2075
                        elif os .path .join (O00O0O00O0O000OO0 ,O0O00OO00000O0O00 )in O00O000000O0OOOO0 :log ("[Back Up] Type = '%s': Ignore %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 );continue #line:2076
                        elif os .path .join ('addons','packages')in O0O00O0O0OO0O000O :log ("[Back Up] Type = '%s': Ignore %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 );continue #line:2077
                        elif O0O00OO00000O0O00 .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 );continue #line:2078
                        elif O0O00OO00000O0O00 .endswith ('.pyo'):continue #line:2079
                        elif O0O00OO00000O0O00 .endswith ('.db')and 'Database'in O00O0O00O0O000OO0 :#line:2080
                            O00O000O0O00O0OOO =O0O00OO00000O0O00 .replace ('.db','')#line:2081
                            O00O000O0O00O0OOO =''.join ([OOO0OO0OOOOOO0OOO for OOO0OO0OOOOOO0OOO in O00O000O0O00O0OOO if not OOO0OO0OOOOOO0OOO .isdigit ()])#line:2082
                            if O00O000O0O00O0OOO in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:2083
                                if not O0O00OO00000O0O00 ==latestDB (O00O000O0O00O0OOO ):log ("[Back Up] Type = '%s': Ignore %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 );continue #line:2084
                        try :#line:2085
                            OO0000OO000O0OOO0 .write (O0O00O0O0OO0O000O ,O0O00O0O0OO0O000O [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2086
                        except :pass #line:2087
                    except :pass #line:2088
            OO0000OO000O0OOO0 .close ()#line:2089
            xbmc .sleep (500 )#line:2090
            DP .update (100 ,"Creating %s_guisettings.zip"%name ,"","")#line:2091
            backUpOptions ('guifix',name )#line:2092
            if not OOOOO0OOOOO0OOOO0 =='':#line:2093
                OO00O000OO000OOOO =xbmcvfs .rename (OOOOO0OOOOO0OOOO0 ,O0OOOOOO00OO00OOO )#line:2094
                if OO00O000OO000OOOO ==0 :#line:2095
                    xbmcvfs .copy (OOOOO0OOOOO0OOOO0 ,O0OOOOOO00OO00OOO )#line:2096
                    xbmcvfs .delete (OOOOO0OOOOO0OOOO0 )#line:2097
            DP .close ()#line:2098
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR] [COLOR %s]backup successful:[/COLOR]"%(COLOR1 ,name ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOOO00OO00OOO ))#line:2099
    elif OOOOOO000O0O00O0O =="guifix":#line:2100
        if name =="":#line:2101
            OOOO0OOOOO0O0O0OO =getKeyboard ("","Please enter a name for the %s zip"%OOOOOO000O0O00O0O )#line:2102
            if not OOOO0OOOOO0O0O0OO :return False #line:2103
            convertSpecial (USERDATA ,True )#line:2104
            asciiCheck (USERDATA ,True )#line:2105
        else :OOOO0OOOOO0O0O0OO =name #line:2106
        OOOO0OOOOO0O0O0OO =urllib .quote_plus (OOOO0OOOOO0O0O0OO );O000OOO00OO0OOOO0 =''#line:2107
        O0000000000O0OO00 =translatepath (os .path .join (OOOO00O0O000OO0OO ,'%s_guisettings.zip'%OOOO0OOOOO0O0O0OO ))#line:2108
        if os .path .exists (GUISETTINGS ):#line:2109
            try :#line:2110
                OO0000OO000O0OOO0 =zipfile .ZipFile (O0000000000O0OO00 ,mode ='w')#line:2111
            except :#line:2112
                try :#line:2113
                    O000OOO00OO0OOOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO0OOOOO0O0O0OO )#line:2114
                    OO0000OO000O0OOO0 =zipfile .ZipFile (O000OOO00OO0OOOO0 ,mode ='w')#line:2115
                except :#line:2116
                    log ("Unable to create %s_guisettings.zip"%OOOO0OOOOO0O0O0OO ,5 )#line:2117
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2118
                        openS ()#line:2119
                        return #line:2120
                    else :#line:2121
                        return #line:2122
            try :#line:2123
                OO0000OO000O0OOO0 .write (GUISETTINGS ,'guisettings.xml',zipfile .ZIP_DEFLATED )#line:2124
                OO0000OO000O0OOO0 .write (PROFILES ,'profiles.xml',zipfile .ZIP_DEFLATED )#line:2125
                O00OO0O00000OO0O0 =glob .glob (os .path .join (ADDOND ,'skin.*',''))#line:2126
                log (str (O00OO0O00000OO0O0 ),5 )#line:2127
                for OO00O0O0OO0000O0O in O00OO0O00000OO0O0 :#line:2128
                    OOOOO0000O00O0O00 =os .path .split (OO00O0O0OO0000O0O [:-1 ])[1 ]#line:2129
                    if not OOOOO0000O00O0O00 in ['skin.confluence','skin.re-touch','skin.estuary','skin.myconfluence','skin.estouchy','skin.anonymous.mod','skin.anonymous.nox','skin.Premium.mod']:#line:2130
                        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to add the following skin folder to the GuiFix Zip File?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO0000O00O0O00 ),yeslabel ="[B][COLOR green]Add Skin[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Skin[/COLOR][/B]"):#line:2131
                            for O00O0O00O0O000OO0 ,O00O0O0OOOOOO00O0 ,OOOO00000OOOO0O0O in os .walk (os .path .join (ADDOND ,OO00O0O0OO0000O0O )):#line:2132
                                OOOO00000OOOO0O0O [:]=[OO00O0000O0000O0O for OO00O0000O0000O0O in OOOO00000OOOO0O0O if OO00O0000O0000O0O not in OO00OOO000O00O000 ]#line:2133
                                for O0O00OO00000O0O00 in OOOO00000OOOO0O0O :#line:2134
                                    O0O00O0O0OO0O000O =os .path .join (O00O0O00O0O000OO0 ,O0O00OO00000O0O00 )#line:2135
                                    OO0000OO000O0OOO0 .write (O0O00O0O0OO0O000O ,O0O00O0O0OO0O000O [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:2136
                            O00OO0O00000OO0O0 =parseDOM (link ,'import',ret ='addon')#line:2137
                            if 'script.skinshortcuts'in O00OO0O00000OO0O0 :#line:2138
                                for O00O0O00O0O000OO0 ,O00O0O0OOOOOO00O0 ,OOOO00000OOOO0O0O in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:2139
                                    OOOO00000OOOO0O0O [:]=[O000OOO00OO0OO00O for O000OOO00OO0OO00O in OOOO00000OOOO0O0O if O000OOO00OO0OO00O not in OO00OOO000O00O000 ]#line:2140
                                    for O0O00OO00000O0O00 in OOOO00000OOOO0O0O :#line:2141
                                        O0O00O0O0OO0O000O =os .path .join (O00O0O00O0O000OO0 ,O0O00OO00000O0O00 )#line:2142
                                        OO0000OO000O0OOO0 .write (O0O00O0O0OO0O000O ,O0O00O0O0OO0O000O [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:2143
                        else :log ("[Back Up] Type = '%s': %s ignored"%(OOOOOO000O0O00O0O ,OO00O0O0OO0000O0O ),5 )#line:2144
            except Exception as OOOO0000000OOO0OO :#line:2145
                log ("[Back Up] Type = '%s': %s"%(OOOOOO000O0O00O0O ,OOOO0000000OOO0OO ),5 )#line:2146
                pass #line:2147
            OO0000OO000O0OOO0 .close ()#line:2148
            if not O000OOO00OO0OOOO0 =='':#line:2149
                OO00O000OO000OOOO =xbmcvfs .rename (O000OOO00OO0OOOO0 ,O0000000000O0OO00 )#line:2150
                if OO00O000OO000OOOO ==0 :#line:2151
                    xbmcvfs .copy (O000OOO00OO0OOOO0 ,O0000000000O0OO00 )#line:2152
                    xbmcvfs .delete (O000OOO00OO0OOOO0 )#line:2153
        else :log ("[Back Up] Type = '%s': guisettings.xml not found"%OOOOOO000O0O00O0O ,5 )#line:2154
        if name =="":#line:2155
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]GuiFix backup successful:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000000000O0OO00 ))#line:2156
    elif OOOOOO000O0O00O0O =="theme":#line:2157
        if not DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to create a theme backup?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Continue[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):LogNotify ("Theme Backup","Cancelled!");return False #line:2158
        if name =="":#line:2159
            OOOOOO00OO0000OOO =getKeyboard ("","Please enter a name for the %s zip"%OOOOOO000O0O00O0O )#line:2160
            if not OOOOOO00OO0000OOO :return False #line:2161
        else :OOOOOO00OO0000OOO =name #line:2162
        OOOOOO00OO0000OOO =urllib .quote_plus (OOOOOO00OO0000OOO );OOOOO0OOOOO0OOOO0 =''#line:2163
        O0OOOOOO00OO00OOO =os .path .join (OOOO00O0O000OO0OO ,'%s.zip'%OOOOOO00OO0000OOO )#line:2164
        try :#line:2165
            OO0000OO000O0OOO0 =zipfile .ZipFile (translatepath (O0OOOOOO00OO00OOO ),mode ='w')#line:2166
        except :#line:2167
            try :#line:2168
                OOOOO0OOOOO0OOOO0 =os .path .join (PACKAGES ,'%s.zip'%OOOOOO00OO0000OOO )#line:2169
                OO0000OO000O0OOO0 =zipfile .ZipFile (OOOOO0OOOOO0OOOO0 ,mode ='w')#line:2170
            except :#line:2171
                log ("Unable to create %s.zip"%OOOOOO00OO0000OOO ,5 )#line:2172
                if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2173
                    openS ()#line:2174
                    return #line:2175
                else :#line:2176
                    return #line:2177
        convertSpecial (USERDATA ,True )#line:2178
        asciiCheck (USERDATA ,True )#line:2179
        try :#line:2180
            if not SKIN =='skin.confluence':#line:2181
                OO0O0000O0O00OO0O =os .path .join (ADDONS ,SKIN ,'media')#line:2182
                O0000OO0OOOOO0O00 =glob .glob (os .path .join (OO0O0000O0O00OO0O ,'*.xbt'))#line:2183
                if len (O0000OO0OOOOO0O00 )>1 :#line:2184
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go through the Texture Files for?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2185
                        OO0O0000O0O00OO0O =os .path .join (ADDONS ,SKIN ,'media')#line:2186
                        O0000OO0OOOOO0O00 =glob .glob (os .path .join (OO0O0000O0O00OO0O ,'*.xbt'))#line:2187
                        for OO00OOO00O0000OOO in O0000OO0OOOOO0O00 :#line:2188
                            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR1 ,COLOR2 ,OO00OOO00O0000OOO .replace (OO0O0000O0O00OO0O ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2189
                                O0O00O0O0OO0O000O =OO00OOO00O0000OOO #line:2190
                                O0OO0O0OO000O000O =O0O00O0O0OO0O000O .replace (HOME ,"")#line:2191
                                OO0000OO000O0OOO0 .write (O0O00O0O0OO0O000O ,O0OO0O0OO000O000O ,zipfile .ZIP_DEFLATED )#line:2192
                else :#line:2193
                    for OO00OOO00O0000OOO in O0000OO0OOOOO0O00 :#line:2194
                        if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR2 ,COLOR1 ,OO00OOO00O0000OOO .replace (OO0O0000O0O00OO0O ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2195
                            O0O00O0O0OO0O000O =OO00OOO00O0000OOO #line:2196
                            O0OO0O0OO000O000O =O0O00O0O0OO0O000O .replace (HOME ,"")#line:2197
                            OO0000OO000O0OOO0 .write (O0O00O0O0OO0O000O ,O0OO0O0OO000O000O ,zipfile .ZIP_DEFLATED )#line:2198
                OO0O00O0OO0OOO0OO =os .path .join (ADDOND ,SKIN ,'settings.xml')#line:2199
                if os .path .exists (OO0O00O0OO0OOO0OO ):#line:2200
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] in [COLOR %s]/addon_data/[/COLOR] for?"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:2201
                        OO0O0000O0O00OO0O =os .path .join (ADDOND ,SKIN )#line:2202
                        OO0000OO000O0OOO0 .write (OO0O00O0OO0OOO0OO ,OO0O00O0OO0OOO0OO .replace (HOME ,""),zipfile .ZIP_DEFLATED )#line:2203
                OOO0O00OO0O0OOO0O =open (os .path .join (ADDONS ,SKIN ,'addon.xml'));O0O00O00O00OOOOO0 =OOO0O00OO0O0OOO0O .read ();OOO0O00OO0O0OOO0O .close ()#line:2204
                O00OO0O00000OO0O0 =parseDOM (O0O00O00O00OOOOO0 ,'import',ret ='addon')#line:2205
                if 'script.skinshortcuts'in O00OO0O00000OO0O0 :#line:2206
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] for [COLOR %s]script.skinshortcuts[/COLOR]?"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:2207
                        for O00O0O00O0O000OO0 ,O00O0O0OOOOOO00O0 ,OOOO00000OOOO0O0O in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:2208
                            OOOO00000OOOO0O0O [:]=[O00OO000O0OO0O0O0 for O00OO000O0OO0O0O0 in OOOO00000OOOO0O0O if O00OO000O0OO0O0O0 not in OO00OOO000O00O000 ]#line:2209
                            for O0O00OO00000O0O00 in OOOO00000OOOO0O0O :#line:2210
                                O0O00O0O0OO0O000O =os .path .join (O00O0O00O0O000OO0 ,O0O00OO00000O0O00 )#line:2211
                                OO0000OO000O0OOO0 .write (O0O00O0O0OO0O000O ,O0O00O0O0OO0O000O [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2212
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include a [COLOR %s]Backgrounds[/COLOR] folder?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2213
                O0O00O0O0OO0O000O =DIALOG .browse (0 ,'Select location of backgrounds','files','',True ,False ,HOME ,False )#line:2214
                if not O0O00O0O0OO0O000O ==HOME :#line:2215
                    for O00O0O00O0O000OO0 ,O00O0O0OOOOOO00O0 ,OOOO00000OOOO0O0O in os .walk (O0O00O0O0OO0O000O ):#line:2216
                        O00O0O0OOOOOO00O0 [:]=[OOO00OO0OO000OOO0 for OOO00OO0OO000OOO0 in O00O0O0OOOOOO00O0 if OOO00OO0OO000OOO0 not in OO000O000000OO0OO ]#line:2217
                        OOOO00000OOOO0O0O [:]=[OOOO0OOO0OO00O000 for OOOO0OOO0OO00O000 in OOOO00000OOOO0O0O if OOOO0OOO0OO00O000 not in OO00OOO000O00O000 ]#line:2218
                        for O0O00OO00000O0O00 in OOOO00000OOOO0O0O :#line:2219
                            try :#line:2220
                                O0OO0O0OO000O000O =os .path .join (O00O0O00O0O000OO0 ,O0O00OO00000O0O00 )#line:2221
                                OO0000OO000O0OOO0 .write (O0OO0O0OO000O000O ,O0OO0O0OO000O000O [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2222
                            except Exception as OOOO0000000OOO0OO :#line:2223
                                log ("[Back Up] Type = '%s': Unable to backup %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 )#line:2224
                                log ("Backup Error: %s"%str (OOOO0000000OOO0OO ),5 )#line:2225
                OO00O000O000000OO =latestDB ('Textures')#line:2226
                if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00O000O000000OO ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2227
                    OO0000OO000O0OOO0 .write (os .path .join (DATABASE ,OO00O000O000000OO ),'/userdata/Database/%s'%OO00O000O000000OO ,zipfile .ZIP_DEFLATED )#line:2228
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include any addons?[/COLOR]"%(COLOR2 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2229
                OO00O0O0OO0000O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2230
                O0O000OO000O0O0O0 =[];OO0000OOOOOOO0O0O =[]#line:2231
                for OO0O000000O0OOO0O in sorted (OO00O0O0OO0000O0O ,key =lambda OOO0OO0OOO0OOO000 :OOO0OO0OOO0OOO000 ):#line:2232
                    O00OOOOOO00000O00 =os .path .split (OO0O000000O0OOO0O [:-1 ])[1 ]#line:2233
                    if O00OOOOOO00000O00 in EXCLUDES :continue #line:2234
                    elif O00OOOOOO00000O00 in DEFAULTPLUGINS :continue #line:2235
                    elif O00OOOOOO00000O00 =='packages':continue #line:2236
                    O0O0O0000O0O000OO =os .path .join (OO0O000000O0OOO0O ,'addon.xml')#line:2237
                    if os .path .exists (O0O0O0000O0O000OO ):#line:2238
                        OOO0O00OO0O0OOO0O =open (O0O0O0000O0O000OO )#line:2239
                        OO00OO00OOOO0000O =OOO0O00OO0O0OOO0O .read ()#line:2240
                        O00OO0O00000OO0O0 =parseDOM (OO00OO00OOOO0000O ,'addon',ret ='name')#line:2241
                        if len (O00OO0O00000OO0O0 )>0 :#line:2242
                            O0O000OO000O0O0O0 .append (O00OO0O00000OO0O0 [0 ])#line:2243
                            OO0000OOOOOOO0O0O .append (O00OOOOOO00000O00 )#line:2244
                        else :#line:2245
                            O0O000OO000O0O0O0 .append (O00OOOOOO00000O00 )#line:2246
                            OO0000OOOOOOO0O0O .append (O00OOOOOO00000O00 )#line:2247
                if KODIV >16 :#line:2248
                    OOO0OO00O0OOOOO0O =DIALOG .multiselect ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,O0O000OO000O0O0O0 )#line:2249
                else :#line:2250
                    OOO0OO00O0OOOOO0O =[];OO0000O0OOOO00O0O =0 #line:2251
                    OOOO000O0O0O0O0OO =["-- Click here to Continue --"]+O0O000OO000O0O0O0 #line:2252
                    while not OO0000O0OOOO00O0O ==-1 :#line:2253
                        OO0000O0OOOO00O0O =DIALOG .select ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,OOOO000O0O0O0O0OO )#line:2254
                        if OO0000O0OOOO00O0O ==-1 :break #line:2255
                        elif OO0000O0OOOO00O0O ==0 :break #line:2256
                        else :#line:2257
                            O0O000O0O0O0OO00O =(OO0000O0OOOO00O0O -1 )#line:2258
                            if O0O000O0O0O0OO00O in OOO0OO00O0OOOOO0O :#line:2259
                                OOO0OO00O0OOOOO0O .remove (O0O000O0O0O0OO00O )#line:2260
                                OOOO000O0O0O0O0OO [OO0000O0OOOO00O0O ]=O0O000OO000O0O0O0 [O0O000O0O0O0OO00O ]#line:2261
                            else :#line:2262
                                OOO0OO00O0OOOOO0O .append (O0O000O0O0O0OO00O )#line:2263
                                OOOO000O0O0O0O0OO [OO0000O0OOOO00O0O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0O000OO000O0O0O0 [O0O000O0O0O0OO00O ])#line:2264
                if len (OOO0OO00O0OOOOO0O )>0 :#line:2265
                    for OOOO00O0OO0000O0O in OOO0OO00O0OOOOO0O :#line:2266
                        for O00O0O00O0O000OO0 ,O00O0O0OOOOOO00O0 ,OOOO00000OOOO0O0O in os .walk (os .path .join (ADDONS ,OO0000OOOOOOO0O0O [OOOO00O0OO0000O0O ])):#line:2267
                            OOOO00000OOOO0O0O [:]=[OO0OO0O0OO00OO0O0 for OO0OO0O0OO00OO0O0 in OOOO00000OOOO0O0O if OO0OO0O0OO00OO0O0 not in OO00OOO000O00O000 ]#line:2268
                            for O0O00OO00000O0O00 in OOOO00000OOOO0O0O :#line:2269
                                if O0O00OO00000O0O00 .endswith ('.pyo'):continue #line:2270
                                O0O00O0O0OO0O000O =os .path .join (O00O0O00O0O000OO0 ,O0O00OO00000O0O00 )#line:2271
                                OO0000OO000O0OOO0 .write (O0O00O0O0OO0O000O ,O0O00O0O0OO0O000O [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2272
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]guisettings.xml[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2273
                OO0000OO000O0OOO0 .write (GUISETTINGS ,'/userdata/guisettings.xml',zipfile .ZIP_DEFLATED )#line:2274
        except Exception as OOOO0000000OOO0OO :#line:2275
            OO0000OO000O0OOO0 .close ()#line:2276
            log ("[Back Up] Type = '%s': %s"%(OOOOOO000O0O00O0O ,str (OOOO0000000OOO0OO )),5 )#line:2277
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip failed:[/COLOR]"%(COLOR1 ,OOOOOO00OO0000OOO ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OOOO0000000OOO0OO )))#line:2278
            if not OOOOO0OOOOO0OOOO0 =='':#line:2279
                try :os .remove (translatepath (OOOOO0OOOOO0OOOO0 ))#line:2280
                except Exception as OOOO0000000OOO0OO :log (str (OOOO0000000OOO0OO ))#line:2281
            else :#line:2282
                try :os .remove (translatepath (O0OOOOOO00OO00OOO ))#line:2283
                except Exception as OOOO0000000OOO0OO :log (str (OOOO0000000OOO0OO ))#line:2284
            return #line:2285
        OO0000OO000O0OOO0 .close ()#line:2286
        if not OOOOO0OOOOO0OOOO0 =='':#line:2287
            OO00O000OO000OOOO =xbmcvfs .rename (OOOOO0OOOOO0OOOO0 ,O0OOOOOO00OO00OOO )#line:2288
            if OO00O000OO000OOOO ==0 :#line:2289
                xbmcvfs .copy (OOOOO0OOOOO0OOOO0 ,O0OOOOOO00OO00OOO )#line:2290
                xbmcvfs .delete (OOOOO0OOOOO0OOOO0 )#line:2291
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip successful:[/COLOR]"%(COLOR1 ,OOOOOO00OO0000OOO ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOOO00OO00OOO ))#line:2292
    elif OOOOOO000O0O00O0O =="addondata":#line:2293
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]לבצע גיבוי הגדרות?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR white]ביטול [/COLOR][/B]",yeslabel ="[B][COLOR green]אישור[/COLOR][/B]"):#line:2294
            if name =="":#line:2295
                name =getKeyboard ("","הכנס שם באנגלית לקובץ הגיבוי")#line:2296
                if not name :return False #line:2297
                name =urllib .quote_plus (name )#line:2298
            name ='%s_addondata.zip'%name ;OOOOO0OOOOO0OOOO0 =''#line:2299
            O0OOOOOO00OO00OOO =os .path .join (OOOO00O0O000OO0OO ,name )#line:2300
            try :#line:2301
                OO0000OO000O0OOO0 =zipfile .ZipFile (translatepath (O0OOOOOO00OO00OOO ),mode ='w')#line:2302
            except :#line:2303
                try :#line:2304
                    OOOOO0OOOOO0OOOO0 =os .path .join (PACKAGES ,'%s.zip'%name )#line:2305
                    OO0000OO000O0OOO0 =zipfile .ZipFile (OOOOO0OOOOO0OOOO0 ,mode ='w')#line:2306
                except :#line:2307
                    log ("Unable to create %s_addondata.zip"%name ,5 )#line:2308
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]אין באפשרותנו לכתוב לספריית הגיבוי הנוכחית, האם ברצונך לשנות את המיקום?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]אישור[/COLOR][/B]",nolabel ="[B][COLOR white]ביטול[/COLOR][/B]"):#line:2309
                        openS ()#line:2310
                        return #line:2311
                    else :#line:2312
                        return #line:2313
            OOOO00000O0OOOO0O =0 #line:2314
            OOOOO000000OOOO0O =[]#line:2315
            convertSpecial (ADDOND ,True )#line:2316
            asciiCheck (ADDOND ,True )#line:2317
            DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:2318
            for O00O0O00O0O000OO0 ,O00O0O0OOOOOO00O0 ,OOOO00000OOOO0O0O in os .walk (ADDOND ):#line:2319
                O00O0O0OOOOOO00O0 [:]=[OOO00OO0OO0OO0OOO for OOO00OO0OO0OO0OOO in O00O0O0OOOOOO00O0 if OOO00OO0OO0OO0OOO not in OO000O000000OO0OO ]#line:2320
                OOOO00000OOOO0O0O [:]=[OOO0OO000O0OO0000 for OOO0OO000O0OO0000 in OOOO00000OOOO0O0O if OOO0OO000O0OO0000 not in OO00OOO000O00O000 ]#line:2321
                for O0O00OO00000O0O00 in OOOO00000OOOO0O0O :#line:2322
                    OOOOO000000OOOO0O .append (O0O00OO00000O0O00 )#line:2323
            OOO0O0O000OO0O0OO =len (OOOOO000000OOOO0O )#line:2324
            for O00O0O00O0O000OO0 ,O00O0O0OOOOOO00O0 ,OOOO00000OOOO0O0O in os .walk (ADDOND ):#line:2325
                O00O0O0OOOOOO00O0 [:]=[OOO00O00O00000O0O for OOO00O00O00000O0O in O00O0O0OOOOOO00O0 if OOO00O00O00000O0O not in OO000O000000OO0OO ]#line:2326
                OOOO00000OOOO0O0O [:]=[O0OOOO0O00O0O00OO for O0OOOO0O00O0O00OO in OOOO00000OOOO0O0O if O0OOOO0O00O0O00OO not in OO00OOO000O00O000 ]#line:2327
                for O0O00OO00000O0O00 in OOOO00000OOOO0O0O :#line:2328
                    try :#line:2329
                        OOOO00000O0OOOO0O +=1 #line:2330
                        O0OO0OOOOOO0OOOOO =percentage (OOOO00000O0OOOO0O ,OOO0O0O000OO0O0OO )#line:2331
                        DP .update (int (O0OO0OOOOOO0OOOOO ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO00000O0OOOO0O ,COLOR1 ,OOO0O0O000OO0O0OO ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00OO00000O0O00 ),'')#line:2332
                        O0O00O0O0OO0O000O =os .path .join (O00O0O00O0O000OO0 ,O0O00OO00000O0O00 )#line:2333
                        if O0O00OO00000O0O00 in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 );continue #line:2334
                        elif os .path .join (O00O0O00O0O000OO0 ,O0O00OO00000O0O00 )in O00O000000O0OOOO0 :log ("[Back Up] Type = '%s': Ignore %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 );continue #line:2335
                        elif os .path .join ('addons','packages')in O0O00O0O0OO0O000O :log ("[Back Up] Type = '%s': Ignore %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 );continue #line:2336
                        elif O0O00OO00000O0O00 .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 );continue #line:2337
                        elif O0O00OO00000O0O00 .endswith ('.db')and 'Database'in O00O0O00O0O000OO0 :#line:2338
                            O00O000O0O00O0OOO =O0O00OO00000O0O00 .replace ('.db','')#line:2339
                            O00O000O0O00O0OOO =''.join ([OOO00OOO00OOO0OOO for OOO00OOO00OOO0OOO in O00O000O0O00O0OOO if not OOO00OOO00OOO0OOO .isdigit ()])#line:2340
                            if O00O000O0O00O0OOO in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:2341
                                if not O0O00OO00000O0O00 ==latestDB (O00O000O0O00O0OOO ):log ("[Back Up] Type = '%s': Ignore %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 );continue #line:2342
                        try :#line:2343
                            OO0000OO000O0OOO0 .write (O0O00O0O0OO0O000O ,O0O00O0O0OO0O000O [len (ADDOND ):],zipfile .ZIP_DEFLATED )#line:2344
                        except Exception as OOOO0000000OOO0OO :#line:2345
                            log ("[Back Up] Type = '%s': Unable to backup %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 )#line:2346
                            log ("Backup Error: %s"%str (OOOO0000000OOO0OO ),5 )#line:2347
                    except Exception as OOOO0000000OOO0OO :#line:2348
                        log ("[Back Up] Type = '%s': Unable to backup %s"%(OOOOOO000O0O00O0O ,O0O00OO00000O0O00 ),5 )#line:2349
                        log ("Backup Error: %s"%str (OOOO0000000OOO0OO ),5 )#line:2350
            OO0000OO000O0OOO0 .close ()#line:2351
            if not OOOOO0OOOOO0OOOO0 =='':#line:2352
                OO00O000OO000OOOO =xbmcvfs .rename (OOOOO0OOOOO0OOOO0 ,O0OOOOOO00OO00OOO )#line:2353
                if OO00O000OO000OOOO ==0 :#line:2354
                    xbmcvfs .copy (OOOOO0OOOOO0OOOO0 ,O0OOOOOO00OO00OOO )#line:2355
                    xbmcvfs .delete (OOOOO0OOOOO0OOOO0 )#line:2356
            DP .close ()#line:2357
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]הגיבוי בוצע בהצלחה![/COLOR]"%(COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOOO00OO00OOO ))#line:2358
def restoreLocal (O0OO0O0O0O00O0OO0 ):#line:2360
    O0000OOOO00OOO000 =translatepath (BACKUPLOCATION )#line:2361
    O0OOOOO00O0O00O00 =translatepath (MYBUILDS )#line:2362
    try :#line:2363
        if not os .path .exists (O0000OOOO00OOO000 ):xbmcvfs .mkdirs (O0000OOOO00OOO000 )#line:2364
        if not os .path .exists (O0OOOOO00O0O00O00 ):xbmcvfs .mkdirs (O0OOOOO00O0O00O00 )#line:2365
    except Exception as OO00OOOOOO00OOO0O :#line:2366
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OO00OOOOOO00OOO0O )))#line:2367
        return #line:2368
    O00OO000OO00000O0 =DIALOG .browse (1 ,'[COLOR %s]בחר את הקובץ שתרצה לשחזר[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2369
    log ("[RESTORE BACKUP %s] File: %s "%(O0OO0O0O0O00O0OO0 .upper (),O00OO000OO00000O0 ),5 )#line:2370
    if O00OO000OO00000O0 ==""or not O00OO000OO00000O0 .endswith ('.zip'):#line:2371
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore: Cancelled[/COLOR]"%COLOR2 )#line:2372
        return #line:2373
    DP .create (ADDONTITLE ,'[COLOR %s]Installing Local Backup'%COLOR2 ,'','Please Wait[/COLOR]')#line:2374
    if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:2375
    if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:2376
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2377
    if O0OO0O0O0O00O0OO0 =="gui":OOOO000O0000OOOOO =USERDATA #line:2378
    elif O0OO0O0O0O00O0OO0 =="addondata":#line:2379
        OOOO000O0000OOOOO =ADDOND #line:2380
    else :OOOO000O0000OOOOO =HOME #line:2381
    log ("Restoring to %s"%OOOO000O0000OOOOO ,5 )#line:2382
    O0OOO0OO00O00OO0O =os .path .split (O00OO000OO00000O0 )#line:2383
    OO0OO00OOO0OOOOOO =O0OOO0OO00O00OO0O [1 ]#line:2384
    try :#line:2385
        zipfile .ZipFile (O00OO000OO00000O0 ,'r')#line:2386
    except :#line:2387
        DP .update (0 ,'[COLOR %s]Unable to read zipfile from current location.'%COLOR2 ,'Copying file to packages')#line:2388
        O00O0000OOO0000O0 =os .path .join ('special://home','addons','packages',OO0OO00OOO0OOOOOO )#line:2389
        xbmcvfs .copy (O00OO000OO00000O0 ,O00O0000OOO0000O0 )#line:2390
        O00OO000OO00000O0 =translatepath (O00O0000OOO0000O0 )#line:2391
        DP .update (0 ,'','Copying file to packages: Complete')#line:2392
        zipfile .ZipFile (O00OO000OO00000O0 ,'r')#line:2393
    OO00000O0OOO00OO0 ,OO0O0OOOO0O0000O0 ,O000OO0O0O0OOO00O =extract .all (O00OO000OO00000O0 ,OOOO000O0000OOOOO ,DP )#line:2394
    clearS ('build')#line:2395
    DP .close ()#line:2396
    defaultSkin ()#line:2397
    lookandFeelData ('save')#line:2398
    if not O00OO000OO00000O0 .find ('packages')==-1 :#line:2399
        try :os .remove (O00OO000OO00000O0 )#line:2400
        except :pass #line:2401
    if int (OO0O0OOOO0O0000O0 )>=1 :#line:2402
        O00OO0OO00000000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO00OOO0OOOOOO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00000O0OOO00OO0 ,'%',COLOR1 ,OO0O0OOOO0O0000O0 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2403
        if O00OO0OO00000000O :#line:2404
            if isinstance (OO0O0OOOO0O0000O0 ,unicode ):#line:2405
                O000OO0O0O0OOO00O =O000OO0O0O0OOO00O .encode ('utf-8')#line:2406
            TextBox (ADDONTITLE ,O000OO0O0O0OOO00O .replace ('\t',''))#line:2407
    setS ('installed','true')#line:2408
    setS ('extract',str (OO00000O0OOO00OO0 ))#line:2409
    setS ('errors',str (OO0O0OOOO0O0000O0 ))#line:2410
    if INSTALLMETHOD ==1 :OOOOO0O000O00OO0O =1 #line:2411
    elif INSTALLMETHOD ==2 :OOOOO0O000O00OO0O =0 #line:2412
    else :DIALOG .ok (ADDONTITLE ,"[COLOR %s]השחזור בוצע בהצלחה![/COLOR]"%COLOR2 );killxbmc ('true')#line:2413
    if OOOOO0O000O00OO0O ==1 :reloadFix ()#line:2414
    else :killxbmc (True )#line:2415
def restoreExternal (O0000OOO000O0OOO0 ):#line:2417
    O00OO0OO0OOOOOOO0 =DIALOG .browse (1 ,'[COLOR %s]Select the backup file you want to restore[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2418
    if O00OO0OO0OOOOOOO0 ==""or not O00OO0OO0OOOOOOO0 .endswith ('.zip'):#line:2419
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Cancelled[/COLOR]"%COLOR2 )#line:2420
        return #line:2421
    if not O00OO0OO0OOOOOOO0 .startswith ('http'):#line:2422
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Invalid URL[/COLOR]"%COLOR2 )#line:2423
        return #line:2424
    try :#line:2425
        OOO0OO0000O0O000O =workingURL (O00OO0OO0OOOOOOO0 )#line:2426
    except :#line:2427
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Error Valid URL[/COLOR]"%COLOR2 )#line:2428
        log ("Not a working url, if source was local then use local restore option",5 )#line:2429
        log ("External Source: %s"%O00OO0OO0OOOOOOO0 ,5 )#line:2430
        return #line:2431
    log ("[RESTORE EXT BACKUP %s] File: %s "%(O0000OOO000O0OOO0 .upper (),O00OO0OO0OOOOOOO0 ),5 )#line:2432
    O0OO00OOOO00O0OO0 =os .path .split (O00OO0OO0OOOOOOO0 );OO0O00OOO0OO0OO00 =O0OO00OOOO00O0OO0 [1 ]#line:2433
    DP .create (ADDONTITLE ,'[COLOR %s]Downloading Zip file'%COLOR2 ,'','Please Wait[/COLOR]')#line:2434
    if O0000OOO000O0OOO0 =="gui":OO000OOO00O00O000 =USERDATA #line:2435
    elif O0000OOO000O0OOO0 =="addondata":OO000OOO00O00O000 =ADDOND #line:2436
    else :OO000OOO00O00O000 =HOME #line:2437
    if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:2438
    if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:2439
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2440
    O0O00OOO000O00000 =os .path .join (PACKAGES ,OO0O00OOO0OO0OO00 )#line:2441
    downloader .download (O00OO0OO0OOOOOOO0 ,O0O00OOO000O00000 ,DP )#line:2442
    DP .update (0 ,'Installing External Backup','','Please Wait')#line:2443
    O00OOOO000OOO00OO ,OOOO0000O00000000 ,O0O00O000O00OOOOO =extract .all (O0O00OOO000O00000 ,OO000OOO00O00O000 ,DP )#line:2444
    clearS ('build')#line:2445
    DP .close ()#line:2446
    defaultSkin ()#line:2447
    lookandFeelData ('save')#line:2448
    if int (OOOO0000O00000000 )>=1 :#line:2449
        O0O0000O0OOOO0OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00OOO0OO0OO00 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O00OOOO000OOO00OO ,'%',COLOR1 ,OOOO0000O00000000 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2450
        if O0O0000O0OOOO0OOO :#line:2451
            TextBox (ADDONTITLE ,O0O00O000O00OOOOO .replace ('\t',''))#line:2452
    setS ('installed','true')#line:2453
    setS ('extract',str (O00OOOO000OOO00OO ))#line:2454
    setS ('errors',str (OOOO0000O00000000 ))#line:2455
    try :os .remove (O0O00OOO000O00000 )#line:2456
    except :pass #line:2457
    if INSTALLMETHOD ==1 :O0O0000OO00OO0000 =1 #line:2458
    elif INSTALLMETHOD ==2 :O0O0000OO00OO0000 =0 #line:2459
    else :O0O0000OO00OO0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR green]Force Close[/COLOR][/B]")#line:2460
    if O0O0000OO00OO0000 ==1 :reloadFix ()#line:2461
    else :killxbmc (True )#line:2462
def Grab_Log (file =False ,old =False ,wizard =False ):#line:2478
    if wizard ==True :#line:2479
        if not os .path .exists (WIZLOG ):return False #line:2480
        else :#line:2481
            if file ==True :#line:2482
                return WIZLOG #line:2483
            else :#line:2484
                OOO0O0OOOOO00OOO0 =open (WIZLOG ,'r')#line:2485
                OOO0O00O0O0OO0O00 =OOO0O0OOOOO00OOO0 .read ()#line:2486
                OOO0O0OOOOO00OOO0 .close ()#line:2487
                return OOO0O00O0O0OO0O00 #line:2488
    O0000000OOOO00OOO =0 #line:2489
    O000000OO0O0000O0 =os .listdir (LOG )#line:2490
    O00O000OO0OO0O000 =[]#line:2491
    for OO0O00OOO0OO000OO in O000000OO0O0000O0 :#line:2493
        if old ==True and OO0O00OOO0OO000OO .endswith ('.old.log'):O00O000OO0OO0O000 .append (os .path .join (LOG ,OO0O00OOO0OO000OO ))#line:2494
        elif old ==False and OO0O00OOO0OO000OO .endswith ('.log')and not OO0O00OOO0OO000OO .endswith ('.old.log'):O00O000OO0OO0O000 .append (os .path .join (LOG ,OO0O00OOO0OO000OO ))#line:2495
    if len (O00O000OO0OO0O000 )>0 :#line:2497
        O00O000OO0OO0O000 .sort (key =lambda OOOO0O000O00OOO0O :os .path .getmtime (OOOO0O000O00OOO0O ))#line:2498
        if file ==True :return O00O000OO0OO0O000 [-1 ]#line:2499
        else :#line:2500
            OOO0O0OOOOO00OOO0 =open (O00O000OO0OO0O000 [-1 ],'r')#line:2501
            OOO0O00O0O0OO0O00 =OOO0O0OOOOO00OOO0 .read ()#line:2502
            OOO0O0OOOOO00OOO0 .close ()#line:2503
            return OOO0O00O0O0OO0O00 #line:2504
    else :#line:2505
        return False #line:2506
def whiteList (O0O0OO0OO0O0OOOOO ):#line:2508
    OO0000OO0OO0O0OO0 =translatepath (BACKUPLOCATION )#line:2509
    OOO0OO0O00000O00O =translatepath (MYBUILDS )#line:2510
    if O0O0OO0OO0O0OOOOO =='edit':#line:2511
        OO000OOO00O000O00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2512
        O0OO0OO00O00OO0O0 =[];O0OO0O0O00000O000 =[];OO0O0OO00O0000OO0 =[]#line:2513
        for O0000O0O0OO00O000 in sorted (OO000OOO00O000O00 ,key =lambda O0000OO0OO00O00OO :O0000OO0OO00O00OO ):#line:2514
            OOO00OO00O000O000 =os .path .split (O0000O0O0OO00O000 [:-1 ])[1 ]#line:2515
            if OOO00OO00O000O000 in EXCLUDES :continue #line:2516
            elif OOO00OO00O000O000 in DEFAULTPLUGINS :continue #line:2517
            elif OOO00OO00O000O000 =='packages':continue #line:2518
            OOOO0000O0OOO0O00 =os .path .join (O0000O0O0OO00O000 ,'addon.xml')#line:2519
            if os .path .exists (OOOO0000O0OOO0O00 ):#line:2520
                OOOO0O00O0O0OOOO0 =open (OOOO0000O0OOO0O00 )#line:2521
                OOOO0000O0OO00OO0 =OOOO0O00O0O0OOOO0 .read ()#line:2522
                OOOO0O00O0O0OOOO0 .close ()#line:2523
                OO00OOOO0OO0000O0 =parseDOM (OOOO0000O0OO00OO0 ,'addon',ret ='id')#line:2524
                OOO0OOO000O0OO0O0 =parseDOM (OOOO0000O0OO00OO0 ,'addon',ret ='name')#line:2525
                OOOO0O0O00O0000O0 =OOO00OO00O000O000 if len (OO00OOOO0OO0000O0 )==0 else OO00OOOO0OO0000O0 [0 ]#line:2526
                O00OO0OO000OO0000 =OOO00OO00O000O000 if len (OOO0OOO000O0OO0O0 )==0 else OOO0OOO000O0OO0O0 [0 ]#line:2527
                OO0O00OOO0OO0OOOO =O00OO0OO000OO0000 .replace ('[','<').replace (']','>')#line:2528
                OO0O00OOO0OO0OOOO =re .sub ('<[^<]+?>','',OO0O00OOO0OO0OOOO )#line:2529
                O0OO0OO00O00OO0O0 .append (OO0O00OOO0OO0OOOO )#line:2530
                O0OO0O0O00000O000 .append (OOOO0O0O00O0000O0 )#line:2531
                OO0O0OO00O0000OO0 .append (OOO00OO00O000O000 )#line:2532
        O00OO0O0O0OO0OOO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:2533
        for O0000O0O0OO00O000 in sorted (O00OO0O0O0OO0OOO0 ,key =lambda O000O0O0OOO00OO0O :O000O0O0OOO00OO0O ):#line:2534
            OOO00OO00O000O000 =os .path .split (O0000O0O0OO00O000 [:-1 ])[1 ]#line:2535
            if OOO00OO00O000O000 in OO0O0OO00O0000OO0 :continue #line:2536
            if OOO00OO00O000O000 in EXCLUDES :continue #line:2537
            OOOO0000O0OOO0O00 =os .path .join (ADDONS ,OOO00OO00O000O000 ,'addon.xml')#line:2538
            O0O0000O0O000OO0O =os .path .join (XBMC ,'addons',OOO00OO00O000O000 ,'addon.xml')#line:2539
            if os .path .exists (OOOO0000O0OOO0O00 ):#line:2540
                OOOO0O00O0O0OOOO0 =open (OOOO0000O0OOO0O00 )#line:2541
            elif os .path .exists (O0O0000O0O000OO0O ):#line:2542
                OOOO0O00O0O0OOOO0 =open (O0O0000O0O000OO0O )#line:2543
            else :continue #line:2544
            OOOO0000O0OO00OO0 =OOOO0O00O0O0OOOO0 .read ()#line:2545
            OOOO0O00O0O0OOOO0 .close ()#line:2546
            OO00OOOO0OO0000O0 =parseDOM (OOOO0000O0OO00OO0 ,'addon',ret ='id')#line:2547
            OOO0OOO000O0OO0O0 =parseDOM (OOOO0000O0OO00OO0 ,'addon',ret ='name')#line:2548
            OOOO0O0O00O0000O0 =OOO00OO00O000O000 if len (OO00OOOO0OO0000O0 )==0 else OO00OOOO0OO0000O0 [0 ]#line:2549
            O00OO0OO000OO0000 =OOO00OO00O000O000 if len (OOO0OOO000O0OO0O0 )==0 else OOO0OOO000O0OO0O0 [0 ]#line:2550
            OO0O00OOO0OO0OOOO =O00OO0OO000OO0000 .replace ('[','<').replace (']','>')#line:2551
            OO0O00OOO0OO0OOOO =re .sub ('<[^<]+?>','',OO0O00OOO0OO0OOOO )#line:2552
            O0OO0OO00O00OO0O0 .append (OO0O00OOO0OO0OOOO )#line:2553
            O0OO0O0O00000O000 .append (OOOO0O0O00O0000O0 )#line:2554
            OO0O0OO00O0000OO0 .append (OOO00OO00O000O000 )#line:2555
        OO0OOO000000O00OO =[];O0O0O00OO00O0O0O0 =0 #line:2556
        O0O0OO0O0O000000O =["-- לחץ כאן להמשך --"]+O0OO0OO00O00OO0O0 #line:2557
        OO00OO0OOO0OOOO0O =whiteList ('read')#line:2558
        for O00OO0O0O000O0O00 in OO00OO0OOO0OOOO0O :#line:2559
            log (str (O00OO0O0O000O0O00 ),5 )#line:2560
            try :O000O00OO00OOOOOO ,O0OOO0O00O0OO0000 ,OO000OOO00O000O00 =O00OO0O0O000O0O00 #line:2561
            except Exception as OOOOOO000O0OO0000 :log (str (OOOOOO000O0OO0000 ))#line:2562
            if O0OOO0O00O0OO0000 in O0OO0O0O00000O000 :#line:2563
                O0OOO0OOO0OOO0OOO =O0OO0O0O00000O000 .index (O0OOO0O00O0OO0000 )+1 #line:2564
                OO0OOO000000O00OO .append (O0OOO0OOO0OOO0OOO -1 )#line:2565
                O0O0OO0O0O000000O [O0OOO0OOO0OOO0OOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O000O00OO00OOOOOO )#line:2566
            else :#line:2567
                O0OO0O0O00000O000 .append (O0OOO0O00O0OO0000 )#line:2568
                O0OO0OO00O00OO0O0 .append (O000O00OO00OOOOOO )#line:2569
                O0O0OO0O0O000000O .append ("[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O000O00OO00OOOOOO ))#line:2570
        O0O0O00OO00O0O0O0 =1 #line:2571
        while not O0O0O00OO00O0O0O0 in [-1 ,0 ]:#line:2572
            O0O0O00OO00O0O0O0 =DIALOG .select ("%s: בחר הרחבות לשמירה ."%ADDONTITLE ,O0O0OO0O0O000000O )#line:2573
            if O0O0O00OO00O0O0O0 ==-1 :break #line:2574
            elif O0O0O00OO00O0O0O0 ==0 :break #line:2575
            else :#line:2576
                OO000OO0O00O0O0OO =(O0O0O00OO00O0O0O0 -1 )#line:2577
                if OO000OO0O00O0O0OO in OO0OOO000000O00OO :#line:2578
                    OO0OOO000000O00OO .remove (OO000OO0O00O0O0OO )#line:2579
                    O0O0OO0O0O000000O [O0O0O00OO00O0O0O0 ]=O0OO0OO00O00OO0O0 [OO000OO0O00O0O0OO ]#line:2580
                else :#line:2581
                    OO0OOO000000O00OO .append (OO000OO0O00O0O0OO )#line:2582
                    O0O0OO0O0O000000O [O0O0O00OO00O0O0O0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OO0OO00O00OO0O0 [OO000OO0O00O0O0OO ])#line:2583
        O00000OOO0OOOO0OO =[]#line:2584
        if len (OO0OOO000000O00OO )>0 :#line:2585
            for OOO00OO0OO0OO0000 in OO0OOO000000O00OO :#line:2586
                O00000OOO0OOOO0OO .append ("['%s', '%s', '%s']"%(O0OO0OO00O00OO0O0 [OOO00OO0OO0OO0000 ],O0OO0O0O00000O000 [OOO00OO0OO0OO0000 ],OO0O0OO00O0000OO0 [OOO00OO0OO0OO0000 ]))#line:2587
            OOO00OOO000OOO00O ='\n'.join (O00000OOO0OOOO0OO )#line:2588
            OOOO0O00O0O0OOOO0 =open (WHITELIST ,'w');OOOO0O00O0O0OOOO0 .write (OOO00OOO000OOO00O );OOOO0O00O0O0OOOO0 .close ()#line:2589
        else :#line:2590
            try :os .remove (WHITELIST )#line:2591
            except :pass #line:2592
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Addons in White List[/COLOR]"%(COLOR2 ,len (OO0OOO000000O00OO )))#line:2593
    elif O0O0OO0OO0O0OOOOO =='read':#line:2594
        O00000000O000O00O =[]#line:2595
        if os .path .exists (WHITELIST ):#line:2596
            OOOO0O00O0O0OOOO0 =open (WHITELIST )#line:2597
            OOOO0000O0OO00OO0 =OOOO0O00O0O0OOOO0 .read ()#line:2598
            OOOO0O00O0O0OOOO0 .close ()#line:2599
            OO00O000OO0O000O0 =OOOO0000O0OO00OO0 .split ('\n')#line:2600
            for O00OO0O0O000O0O00 in OO00O000OO0O000O0 :#line:2601
                try :#line:2602
                    O000O00OO00OOOOOO ,O0OOO0O00O0OO0000 ,OO000OOO00O000O00 =eval (O00OO0O0O000O0O00 )#line:2603
                    O00000000O000O00O .append (eval (O00OO0O0O000O0O00 ))#line:2604
                except :#line:2605
                    pass #line:2606
        return O00000000O000O00O #line:2607
    elif O0O0OO0OO0O0OOOOO =='view':#line:2608
        OOOO0O0OOOO00O00O =whiteList ('read')#line:2609
        if len (OOOO0O0OOOO00O00O )>0 :#line:2610
            OOOO00OOO0000OO00 ="רשימת הרחבות שסימנתם שלא ימחקו בהתקנה נקיה או רגילה.[CR][CR]"#line:2611
            for O00OO0O0O000O0O00 in OOOO0O0OOOO00O00O :#line:2612
                try :O000O00OO00OOOOOO ,O0OOO0O00O0OO0000 ,OO000OOO00O000O00 =O00OO0O0O000O0O00 #line:2613
                except Exception as OOOOOO000O0OO0000 :log (str (OOOOOO000O0OO0000 ))#line:2614
                OOOO00OOO0000OO00 +="[COLOR %s]%s[/COLOR] [COLOR %s]\"%s\"[/COLOR][CR]"%(COLOR1 ,O000O00OO00OOOOOO ,COLOR2 ,O0OOO0O00O0OO0000 )#line:2615
            TextBox ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),OOOO00OOO0000OO00 )#line:2616
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No items in White List[/COLOR]"%COLOR2 )#line:2617
    elif O0O0OO0OO0O0OOOOO =='import':#line:2618
        O0O0OOO0OO0O0OOOO =DIALOG .browse (1 ,'[COLOR %s]Select the whitelist file to import[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:2619
        log (str (O0O0OOO0OO0O0OOOO ))#line:2620
        if not O0O0OOO0OO0O0OOOO .endswith ('.txt'):#line:2621
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Cancelled![/COLOR]"%COLOR2 )#line:2622
            return #line:2623
        OOOO0O00O0O0OOOO0 =xbmcvfs .File (O0O0OOO0OO0O0OOOO )#line:2624
        OOOO0000O0OO00OO0 =OOOO0O00O0O0OOOO0 .read ()#line:2625
        OOOO0O00O0O0OOOO0 .close ()#line:2626
        OOO0000OOOO000O00 =whiteList ('read');O00O0O0O0O00O0OOO =[];OO000O000O0OOO000 =0 #line:2627
        for O00OO0O0O000O0O00 in OOO0000OOOO000O00 :#line:2628
            O000O00OO00OOOOOO ,O0OOO0O00O0OO0000 ,OO000OOO00O000O00 =O00OO0O0O000O0O00 #line:2629
            O00O0O0O0O00O0OOO .append (O0OOO0O00O0OO0000 )#line:2630
        OO00O000OO0O000O0 =OOOO0000O0OO00OO0 .split ('\n')#line:2631
        with open (WHITELIST ,'a')as OOOO0O00O0O0OOOO0 :#line:2632
            for O00OO0O0O000O0O00 in OO00O000OO0O000O0 :#line:2633
                try :#line:2634
                    O000O00OO00OOOOOO ,O0OOO0O00O0OO0000 ,O0000O0O0OO00O000 =eval (O00OO0O0O000O0O00 )#line:2635
                except Exception as OOOOOO000O0OO0000 :#line:2636
                    log ("Error Adding: '%s' / %s"%(O00OO0O0O000O0O00 ,str (OOOOOO000O0OO0000 )),5 )#line:2637
                    continue #line:2638
                log ("%s / %s / %s"%(O000O00OO00OOOOOO ,O0OOO0O00O0OO0000 ,O0000O0O0OO00O000 ),5 )#line:2639
                if not O0OOO0O00O0OO0000 in O00O0O0O0O00O0OOO :#line:2640
                    OO000O000O0OOO000 +=1 #line:2641
                    OOO00OOO000OOO00O ="['%s', '%s', '%s']"%(O000O00OO00OOOOOO ,O0OOO0O00O0OO0000 ,O0000O0O0OO00O000 )#line:2642
                    if len (O00O0O0O0O00O0OOO )+OO000O000O0OOO000 >1 :OOO00OOO000OOO00O ="\n%s"%OOO00OOO000OOO00O #line:2643
                    OOOO0O00O0O0OOOO0 .write (OOO00OOO000OOO00O )#line:2644
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Item(s) Added[/COLOR]"%(COLOR2 ,OO000O000O0OOO000 ))#line:2645
    elif O0O0OO0OO0O0OOOOO =='export':#line:2646
        O0O0OOO0OO0O0OOOO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the whitelist file[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:2647
        log (str (O0O0OOO0OO0O0OOOO ),5 )#line:2648
        try :#line:2649
            xbmcvfs .copy (WHITELIST ,os .path .join (O0O0OOO0OO0O0OOOO ,'whitelist.txt'))#line:2650
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]Whitelist has been exported to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0O0OOO0OO0O0OOOO ,'whitelist.txt')))#line:2651
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Exported[/COLOR]"%(COLOR2 ))#line:2652
        except Exception as OOOOOO000O0OO0000 :#line:2653
            log ("Export Error: %s"%str (OOOOOO000O0OO0000 ),5 )#line:2654
            if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The location you selected isnt writable would you like to select another one?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Location[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:2655
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Export Cancelled[/COLOR]"%(COLOR2 ,OOOOOO000O0OO0000 ))#line:2656
            else :#line:2657
                O00000OOO0OOOO0OO (export )#line:2658
    elif O0O0OO0OO0O0OOOOO =='clear':#line:2659
        if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Are you sure you want to clear your whitelist?"%COLOR2 ,"This process can't be undone.[/COLOR]",yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:2660
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clear Whitelist Cancelled[/COLOR]"%(COLOR2 ))#line:2661
            return #line:2662
        try :#line:2663
            os .remove (WHITELIST )#line:2664
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Cleared[/COLOR]"%(COLOR2 ))#line:2665
        except :#line:2666
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Clearing Whitelist![/COLOR]"%(COLOR2 ))#line:2667
def clearPackages (over =None ):#line:2669
    try :#line:2670
        CleanPYO ()#line:2671
    except :pass #line:2672
    if os .path .exists (PACKAGES ):#line:2673
        try :#line:2674
            for OO00000O0000O0OOO ,O0O0000O0O0OO0O0O ,OO000O0O000000OOO in os .walk (PACKAGES ):#line:2675
                O0OO0O00OOOOO000O =0 #line:2676
                O0OO0O00OOOOO000O +=len (OO000O0O000000OOO )#line:2677
                if O0OO0O00OOOOO000O >0 :#line:2678
                    OOO00OO0O0O00000O =convertSize (getSize (PACKAGES ))#line:2679
                    if over :O0OO0OOOOO0OOO00O =1 #line:2680
                    else :O0OO0OOOOO0OOO00O =1 #line:2681
                    if O0OO0OOOOO0OOO00O :#line:2682
                        for OO0O00O000OO0OO00 in OO000O0O000000OOO :os .unlink (os .path .join (OO00000O0000O0OOO ,OO0O00O000OO0OO00 ))#line:2683
                        for O000OO0O0O0OO0O00 in O0O0000O0O0OO0O0O :shutil .rmtree (os .path .join (OO00000O0000O0OOO ,O000OO0O0O0OO0O00 ))#line:2684
        except Exception as O00OOO0OO0OOOOO0O :#line:2687
            log ("Clear Packages Error: %s"%str (O00OOO0OO0OOOOO0O ),5 )#line:2689
def clearPackagesStartup ():#line:2692
    OO0O0O0O0O0OO0O0O =datetime .utcnow ()-timedelta (minutes =3 )#line:2693
    OOOO00000000OOO00 =0 ;OOO0O0O0OO00O0OO0 =0 #line:2694
    if os .path .exists (PACKAGES ):#line:2695
        OOO000OO0OOOO0OO0 =os .listdir (PACKAGES )#line:2696
        OOO000OO0OOOO0OO0 .sort (key =lambda OOO0OO0O00O00OOOO :os .path .getmtime (os .path .join (PACKAGES ,OOO0OO0O00O00OOOO )))#line:2697
        try :#line:2698
            for OO000OOO00OO0O0OO in OOO000OO0OOOO0OO0 :#line:2699
                OOOO00O0O0O00O0OO =os .path .join (PACKAGES ,OO000OOO00OO0O0OO )#line:2700
                OO0OOO0O0O0000OOO =datetime .utcfromtimestamp (os .path .getmtime (OOOO00O0O0O00O0OO ))#line:2701
                if OO0OOO0O0O0000OOO <=OO0O0O0O0O0OO0O0O :#line:2702
                    if os .path .isfile (OOOO00O0O0O00O0OO ):#line:2703
                        OOOO00000000OOO00 +=1 #line:2704
                        OOO0O0O0OO00O0OO0 +=os .path .getsize (OOOO00O0O0O00O0OO )#line:2705
                        os .unlink (OOOO00O0O0O00O0OO )#line:2706
                    elif os .path .isdir (OOOO00O0O0O00O0OO ):#line:2707
                        OOO0O0O0OO00O0OO0 +=getSize (OOOO00O0O0O00O0OO )#line:2708
                        OOOO00O000OO0OOO0 ,OO00OOO0O0OO0O0O0 =cleanHouse (OOOO00O0O0O00O0OO )#line:2709
                        OOOO00000000OOO00 +=OOOO00O000OO0OOO0 +OO00OOO0O0OO0O0O0 #line:2710
                        try :#line:2711
                            shutil .rmtree (OOOO00O0O0O00O0OO )#line:2712
                        except Exception as OO0O0OOOOO00OO0OO :#line:2713
                            log ("Failed to remove %s: %s"%(OOOO00O0O0O00O0OO ,str (OO0O0OOOOO00OO0OO ),5 ))#line:2714
            if OOOO00000000OOO00 >0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success: %s[/COLOR]'%(COLOR2 ,convertSize (OOO0O0O0OO00O0OO0 )))#line:2715
            else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2716
        except Exception as OO0O0OOOOO00OO0OO :#line:2717
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:2718
            log ("Clear Packages Error: %s"%str (OO0O0OOOOO00OO0OO ),5 )#line:2719
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2720
def clearCache (over =None ):#line:2722
    O000OO0OO0O00OO00 =os .path .join (PROFILE ,'addon_data')#line:2733
    O00OO00O00O0O0OOO =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:2742
    OOOOO0O0O00O0OO0O =[(O000OO0OO0O00OO00 ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),os .path .join (translatepath ('special://profile/addon_data/plugin.program.autocompletion/Google'),''),os .path .join (translatepath ('special://profile/addon_data/script.skin.helper.colorpicker/colors'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.All_Subs/temp_wizdom'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.All_Subs/temp'),''),os .path .join (translatepath ('special://profile/addon_data/script.colorbox'),''),os .path .join (translatepath ('special://profile/addon_data/script.module.metadatautils/animatedgifs'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/ArtistInformation'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/ArtistSlideshow'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/merge'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/temp'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/transition'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/resources'),''),os .path .join (translatepath ('special://profile/addon_data/plugin.video.movixws/logos'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.subscenter/temp'),''),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONS ,'temp')),(os .path .join (O000OO0OO0O00OO00 ,'script.module.simple.downloader')),(os .path .join (O000OO0OO0O00OO00 ,'plugin.video.itv','Images'))]#line:2771
    OOOO00OOO0O0O0OO0 =0 #line:2772
    O00000O00OOOOO000 =['meta_cache','archive_cache']#line:2773
    for OOOO0O0O00OO0O0OO in OOOOO0O0O00O0OO0O :#line:2774
        if os .path .exists (OOOO0O0O00OO0O0OO )and not OOOO0O0O00OO0O0OO in [ADDONDATA ,O000OO0OO0O00OO00 ]:#line:2775
            for OOOOO00OO0000O000 ,OO0OOO0OO00000000 ,OO0OO0OOOO00OOOOO in os .walk (OOOO0O0O00OO0O0OO ):#line:2776
                OO0OOO0OO00000000 [:]=[O0O0O00OO0OOO0OO0 for O0O0O00OO0OOO0OO0 in OO0OOO0OO00000000 if O0O0O00OO0OOO0OO0 not in O00000O00OOOOO000 ]#line:2777
                O0OO00O000000OOOO =0 #line:2778
                O0OO00O000000OOOO +=len (OO0OO0OOOO00OOOOO )#line:2779
                if O0OO00O000000OOOO >0 :#line:2780
                    for OO0O0O0O00O000O0O in OO0OO0OOOO00OOOOO :#line:2781
                        if not OO0O0O0O00O000O0O in LOGFILES :#line:2782
                            try :#line:2783
                                os .unlink (os .path .join (OOOOO00OO0000O000 ,OO0O0O0O00O000O0O ))#line:2784
                                log ("[Wiped] %s"%os .path .join (OOOOO00OO0000O000 ,OO0O0O0O00O000O0O ),5 )#line:2785
                                OOOO00OOO0O0O0OO0 +=1 #line:2786
                            except :#line:2787
                                pass #line:2788
                        else :log ('Ignore Log File: %s'%OO0O0O0O00O000O0O ,5 )#line:2789
                    for O0OO00000OOO0000O in OO0OOO0OO00000000 :#line:2790
                        try :#line:2791
                            shutil .rmtree (os .path .join (OOOOO00OO0000O000 ,O0OO00000OOO0000O ))#line:2792
                            OOOO00OOO0O0O0OO0 +=1 #line:2793
                            log ("[Success] cleared %s files from %s"%(str (O0OO00O000000OOOO ),os .path .join (OOOO0O0O00OO0O0OO ,O0OO00000OOO0000O )),5 )#line:2794
                        except :#line:2795
                            log ("[Failed] to wipe cache in: %s"%os .path .join (OOOO0O0O00OO0O0OO ,O0OO00000OOO0000O ),5 )#line:2796
    if os .path .exists (PACKAGES ):#line:2808
        try :#line:2809
            for OOOOO00OO0000O000 ,OO0OOO0OO00000000 ,OO0OO0OOOO00OOOOO in os .walk (PACKAGES ):#line:2810
                O0OO00O000000OOOO =0 #line:2811
                O0OO00O000000OOOO +=len (OO0OO0OOOO00OOOOO )#line:2812
                if O0OO00O000000OOOO >0 :#line:2813
                    OO000O0OO0O00000O =convertSize (getSize (PACKAGES ))#line:2814
                    if over :O000O0O0O0O00OOO0 =1 #line:2815
                    else :O000O0O0O0O00OOO0 =1 #line:2816
                    if O000O0O0O0O00OOO0 :#line:2817
                        for OO0O0O0O00O000O0O in OO0OO0OOOO00OOOOO :os .unlink (os .path .join (OOOOO00OO0000O000 ,OO0O0O0O00O000O0O ))#line:2818
                        for O0OO00000OOO0000O in OO0OOO0OO00000000 :shutil .rmtree (os .path .join (OOOOO00OO0000O000 ,O0OO00000OOO0000O ))#line:2819
        except Exception as O0O0O0O0OOOOOOOOO :#line:2822
            log ("Clear Packages Error: %s"%str (O0O0O0O0OOOOOOOOO ),5 )#line:2824
    if INCLUDEVIDEO =='true'and over ==None :#line:2826
        OO0OO0OOOO00OOOOO =[]#line:2827
        if INCLUDEALL =='true':OO0OO0OOOO00OOOOO =O00OO00O00O0O0OOO #line:2828
        else :#line:2829
            if INCLUDEBOB =='true':OO0OO0OOOO00OOOOO .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:2830
            if INCLUDEPHOENIX =='true':OO0OO0OOOO00OOOOO .append (os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db'))#line:2831
            if INCLUDESPECTO =='true':OO0OO0OOOO00OOOOO .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:2832
            if INCLUDEGENESIS =='true':OO0OO0OOOO00OOOOO .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:2833
            if INCLUDEEXODUS =='true':OO0OO0OOOO00OOOOO .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:2834
            if INCLUDEONECHAN =='true':OO0OO0OOOO00OOOOO .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:2835
            if INCLUDESALTS =='true':OO0OO0OOOO00OOOOO .append (os .path .join (DATABASE ,'saltscache.db'))#line:2836
            if INCLUDESALTSHD =='true':OO0OO0OOOO00OOOOO .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:2837
        if len (OO0OO0OOOO00OOOOO )>0 :#line:2838
            for OOOO0O0O00OO0O0OO in OO0OO0OOOO00OOOOO :#line:2839
                if os .path .exists (OOOO0O0O00OO0O0OO ):#line:2840
                    OOOO00OOO0O0O0OO0 +=1 #line:2841
                    try :#line:2842
                        O00O00O0000000000 =database .connect (OOOO0O0O00OO0O0OO )#line:2843
                        O00O0O00O0O0OOO00 =O00O00O0000000000 .cursor ()#line:2844
                    except Exception as O0O0O0O0OOOOOOOOO :#line:2845
                        log ("DB Connection error: %s"%str (O0O0O0O0OOOOOOOOO ),5 )#line:2846
                        continue #line:2847
                    if 'Database'in OOOO0O0O00OO0O0OO :#line:2848
                        try :#line:2849
                            O00O0O00O0O0OOO00 .execute ("DELETE FROM url_cache")#line:2850
                            O00O0O00O0O0OOO00 .execute ("VACUUM")#line:2851
                            O00O00O0000000000 .commit ()#line:2852
                            O00O0O00O0O0OOO00 .close ()#line:2853
                            log ("[Success] wiped %s"%OOOO0O0O00OO0O0OO ,5 )#line:2854
                        except Exception as O0O0O0O0OOOOOOOOO :#line:2855
                            log ("[Failed] wiped %s: %s"%(OOOO0O0O00OO0O0OO ,str (O0O0O0O0OOOOOOOOO )),5 )#line:2856
                    else :#line:2857
                        O00O0O00O0O0OOO00 .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:2858
                        for O0OOOOO0OOO0000OO in O00O0O00O0O0OOO00 .fetchall ():#line:2859
                            try :#line:2860
                                O00O0O00O0O0OOO00 .execute ("DELETE FROM %s"%O0OOOOO0OOO0000OO [0 ])#line:2861
                                O00O0O00O0O0OOO00 .execute ("VACUUM")#line:2862
                                O00O00O0000000000 .commit ()#line:2863
                                log ("[Success] wiped %s in %s"%(O0OOOOO0OOO0000OO ,OOOO0O0O00OO0O0OO ),5 )#line:2864
                            except Exception as O0O0O0O0OOOOOOOOO :#line:2865
                                log ("[Failed] wiped %s in %s: %s"%(O0OOOOO0OOO0000OO ,OOOO0O0O00OO0O0OO ,str (O0O0O0O0OOOOOOOOO )),5 )#line:2866
                        O00O0O00O0O0OOO00 .close ()#line:2867
        else :log ("Clear Cache: Clear Video Cache Not Enabled",5 )#line:2868
def clearCache3 ():#line:2871
    O0OOO000O0O00000O =os .path .join (PROFILE ,'addon_data')#line:2873
    O0OOOO000OO0OO0O0 =[(O0OOO000O0O00000O ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.bob.unleashed','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.covenant','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.elementum','app.db-wal')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db')),(os .path .join (O0OOO000O0O00000O ,'script.module.simple.downloader')),(os .path .join (O0OOO000O0O00000O ,'plugin.video.itv','Images'))]#line:2893
    O000OOO0OO0O000O0 =0 #line:2895
    for O0O0000OOO00OOOOO in O0OOOO000OO0OO0O0 :#line:2897
        if os .path .exists (O0O0000OOO00OOOOO )and not O0O0000OOO00OOOOO in [ADDONDATA ,O0OOO000O0O00000O ]:#line:2898
            for O00OO000OO0OOO0OO ,O00000O0O0OOO000O ,OOO0O0OO0O00OO000 in os .walk (O0O0000OOO00OOOOO ):#line:2899
                O000OOOO0O0O0O0OO =0 #line:2900
                O000OOOO0O0O0O0OO +=len (OOO0O0OO0O00OO000 )#line:2901
                if O000OOOO0O0O0O0OO >0 :#line:2902
                    for O00OOO00OOO0OOO00 in OOO0O0OO0O00OO000 :#line:2903
                        if not O00OOO00OOO0OOO00 in ['kodi.log','tvmc.log','spmc.log','xbmc.log']:#line:2904
                            try :#line:2905
                                os .unlink (os .path .join (O00OO000OO0OOO0OO ,O00OOO00OOO0OOO00 ))#line:2906
                            except :#line:2907
                                pass #line:2908
                        else :log ('Ignore Log File: %s'%O00OOO00OOO0OOO00 )#line:2909
                    for OOO000OO000OO0O0O in O00000O0O0OOO000O :#line:2910
                        try :#line:2911
                            shutil .rmtree (os .path .join (O00OO000OO0OOO0OO ,OOO000OO000OO0O0O ))#line:2912
                            O000OOO0OO0O000O0 +=1 #line:2913
                            log ("[COLOR red][Success]  %s Files Removed From %s [/COLOR]"%(str (O000OOOO0O0O0O0OO ),os .path .join (O0O0000OOO00OOOOO ,OOO000OO000OO0O0O )))#line:2914
                        except :#line:2915
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (O0O0000OOO00OOOOO ,OOO000OO000OO0O0O ))#line:2916
        else :#line:2917
            for O00OO000OO0OOO0OO ,O00000O0O0OOO000O ,OOO0O0OO0O00OO000 in os .walk (O0O0000OOO00OOOOO ):#line:2918
                for OOO000OO000OO0O0O in O00000O0O0OOO000O :#line:2919
                    if 'cache'in OOO000OO000OO0O0O .lower ():#line:2920
                        try :#line:2921
                            shutil .rmtree (os .path .join (O00OO000OO0OOO0OO ,OOO000OO000OO0O0O ))#line:2922
                            O000OOO0OO0O000O0 +=1 #line:2923
                            log ("[COLOR white][Success] Wiped %s [/COLOR]"%os .path .join (O0O0000OOO00OOOOO ,OOO000OO000OO0O0O ))#line:2924
                        except :#line:2925
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (O0O0000OOO00OOOOO ,OOO000OO000OO0O0O ))#line:2926
    LogNotify (ADDONTITLE ,'[COLOR white]Cache:[/COLOR] [COLOR red] %s Items Removed[/COLOR]'%O000OOO0OO0O000O0 )#line:2928
origfolder =(translatepath ("special://home/addons"))#line:2929
def CleanPYO ():#line:2930
    OOOO000O0OOO0000O =0 #line:2931
    for (O000O000OO0OO00O0 ,OO0OO0O0OO00000OO ,OO000O0OOO00000O0 )in os .walk (origfolder ):#line:2932
       for OOOO0OO0O0O00O000 in OO000O0OOO00000O0 :#line:2933
          if OOOO0OO0O0O00O000 .endswith ('.pyo'):#line:2934
               os .remove (os .path .join (O000O000OO0OO00O0 ,OOOO0OO0O0O00O000 ))#line:2936
          if OOOO0OO0O0O00O000 .endswith ('.pyc'):#line:2937
               os .remove (os .path .join (O000O000OO0OO00O0 ,OOOO0OO0O0O00O000 ))#line:2939
def fixwizard (over =None ):#line:2940
    OOO0O0OOO0000000O =os .path .join (PROFILE ,'addon_data')#line:2942
    OO00OOO000O00O0OO =[(OOO0O0OOO0000000O ),(ADDONDATA ),os .path .join (translatepath ('special://profile/addon_data/plugin.program.Anonymous'),'')]#line:2947
    OOO00000OOOO0OOO0 =0 #line:2948
    O0O0OO0OO0O00OO00 =['meta_cache','archive_cache']#line:2949
    for OOOO0000O0OOOOO0O in OO00OOO000O00O0OO :#line:2950
        if os .path .exists (OOOO0000O0OOOOO0O )and not OOOO0000O0OOOOO0O in [ADDONDATA ,OOO0O0OOO0000000O ]:#line:2951
            for O0O0000000OO0O00O ,OOO00OO00OOO0O00O ,O0OO0OOO00O000OOO in os .walk (OOOO0000O0OOOOO0O ):#line:2952
                OOO00OO00OOO0O00O [:]=[OOO0000OOO00000OO for OOO0000OOO00000OO in OOO00OO00OOO0O00O if OOO0000OOO00000OO not in O0O0OO0OO0O00OO00 ]#line:2953
                O0O0OO00O0O0OO0O0 =0 #line:2954
                O0O0OO00O0O0OO0O0 +=len (O0OO0OOO00O000OOO )#line:2955
                if O0O0OO00O0O0OO0O0 >0 :#line:2956
                    for OOOO00OOOOOOO0OOO in O0OO0OOO00O000OOO :#line:2957
                        if not OOOO00OOOOOOO0OOO in LOGFILES :#line:2958
                            try :#line:2959
                                os .unlink (os .path .join (O0O0000000OO0O00O ,OOOO00OOOOOOO0OOO ))#line:2960
                                log ("[Wiped] %s"%os .path .join (O0O0000000OO0O00O ,OOOO00OOOOOOO0OOO ),5 )#line:2961
                                OOO00000OOOO0OOO0 +=1 #line:2962
                            except :#line:2963
                                pass #line:2964
                        else :log ('Ignore Log File: %s'%OOOO00OOOOOOO0OOO ,5 )#line:2965
                    for O0OO0OOO0O00OO000 in OOO00OO00OOO0O00O :#line:2966
                        try :#line:2967
                            shutil .rmtree (os .path .join (O0O0000000OO0O00O ,O0OO0OOO0O00OO000 ))#line:2968
                            OOO00000OOOO0OOO0 +=1 #line:2969
                            log ("[Success] cleared %s files from %s"%(str (O0O0OO00O0O0OO0O0 ),os .path .join (OOOO0000O0OOOOO0O ,O0OO0OOO0O00OO000 )),5 )#line:2970
                        except :#line:2971
                            log ("[Failed] to wipe cache in: %s"%os .path .join (OOOO0000O0OOOOO0O ,O0OO0OOO0O00OO000 ),5 )#line:2972
        else :#line:2973
            for O0O0000000OO0O00O ,OOO00OO00OOO0O00O ,O0OO0OOO00O000OOO in os .walk (OOOO0000O0OOOOO0O ):#line:2974
                OOO00OO00OOO0O00O [:]=[O0OO00O0O0OO000OO for O0OO00O0O0OO000OO in OOO00OO00OOO0O00O if O0OO00O0O0OO000OO not in O0O0OO0OO0O00OO00 ]#line:2975
                for O0OO0OOO0O00OO000 in OOO00OO00OOO0O00O :#line:2976
                    if not str (O0OO0OOO0O00OO000 .lower ()).find ('cache')==-1 :#line:2977
                        try :#line:2978
                            shutil .rmtree (os .path .join (O0O0000000OO0O00O ,O0OO0OOO0O00OO000 ))#line:2979
                            OOO00000OOOO0OOO0 +=1 #line:2980
                            log ("[Success] wiped %s "%os .path .join (O0O0000000OO0O00O ,O0OO0OOO0O00OO000 ),5 )#line:2981
                        except :#line:2982
                            log ("[Failed] to wipe cache in: %s"%os .path .join (OOOO0000O0OOOOO0O ,O0OO0OOO0O00OO000 ),5 )#line:2983
    if os .path .exists (PACKAGES ):#line:2984
        try :#line:2985
            for O0O0000000OO0O00O ,OOO00OO00OOO0O00O ,O0OO0OOO00O000OOO in os .walk (PACKAGES ):#line:2986
                O0O0OO00O0O0OO0O0 =0 #line:2987
                O0O0OO00O0O0OO0O0 +=len (O0OO0OOO00O000OOO )#line:2988
                if O0O0OO00O0O0OO0O0 >0 :#line:2989
                    OOO000OO0OOOO0OOO =convertSize (getSize (PACKAGES ))#line:2990
                    if over :O0O0O00OO00OOOOO0 =1 #line:2991
                    else :O0O0O00OO00OOOOO0 =1 #line:2992
                    if O0O0O00OO00OOOOO0 :#line:2993
                        for OOOO00OOOOOOO0OOO in O0OO0OOO00O000OOO :os .unlink (os .path .join (O0O0000000OO0O00O ,OOOO00OOOOOOO0OOO ))#line:2994
                        for O0OO0OOO0O00OO000 in OOO00OO00OOO0O00O :shutil .rmtree (os .path .join (O0O0000000OO0O00O ,O0OO0OOO0O00OO000 ))#line:2995
                        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success![/COLOR]'%COLOR2 )#line:2996
        except Exception as OO00O00OO00O00O00 :#line:2998
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:2999
            log ("Clear Packages Error: %s"%str (OO00O00OO00O00O00 ),5 )#line:3000
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:3001
    LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]איפוס עבר בהצלחה %s Files[/COLOR]'%(COLOR2 ,OOO00000OOOO0OOO0 ))#line:3003
def checkSources ():#line:3005
    if not os .path .exists (SOURCES ):#line:3006
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Sources.xml File Found![/COLOR]"%COLOR2 )#line:3007
        return False #line:3008
    OO0O00O0OOOOO000O =0 #line:3009
    OOO0OOOOO0OOOOOO0 =[]#line:3010
    OO00000000000OOO0 =[]#line:3011
    O0000OOO00OOOO000 =open (SOURCES )#line:3012
    O00O0000OO00OO0OO =O0000OOO00OOOO000 .read ()#line:3013
    O0OOOO0O0OOO0O0OO =O00O0000OO00OO0OO .replace ('\r','').replace ('\n','').replace ('\t','')#line:3014
    O0OOOO0OO00OOOO00 =re .compile ('<files>.+?</files>').findall (O0OOOO0O0OOO0O0OO )#line:3015
    O0000OOO00OOOO000 .close ()#line:3016
    if len (O0OOOO0OO00OOOO00 )>0 :#line:3017
        O0O00OO0O00OOOOO0 =re .compile ('<source>.+?<name>(.+?)</name>.+?<path pathversion="1">(.+?)</path>.+?<allowsharing>(.+?)</allowsharing>.+?</source>').findall (O0OOOO0OO00OOOO00 [0 ])#line:3018
        DP .create (ADDONTITLE ,"[COLOR %s]Scanning Sources for Broken links[/COLOR]"%COLOR2 )#line:3019
        for OO000OOOO0000000O ,O0O0OOO0OO00000O0 ,O0O0OO000O00OOOO0 in O0O00OO0O00OOOOO0 :#line:3020
            OO0O00O0OOOOO000O +=1 #line:3021
            O000O00O00O0OO0O0 =int (percentage (OO0O00O0OOOOO000O ,len (O0O00OO0O00OOOOO0 )))#line:3022
            DP .update (O000O00O00O0OO0O0 ,'',"[COLOR %s]Checking [COLOR %s]%s[/COLOR]:[/COLOR]"%(COLOR2 ,COLOR1 ,OO000OOOO0000000O ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OOO0OO00000O0 ))#line:3023
            if 'http'in O0O0OOO0OO00000O0 :#line:3024
                OOO00OO0OOOOO0O00 =workingURL (O0O0OOO0OO00000O0 )#line:3025
                if not OOO00OO0OOOOO0O00 ==True :#line:3026
                    OOO0OOOOO0OOOOOO0 .append ([OO000OOOO0000000O ,O0O0OOO0OO00000O0 ,O0O0OO000O00OOOO0 ,OOO00OO0OOOOO0O00 ])#line:3027
        log ("Bad Sources: %s"%len (OOO0OOOOO0OOOOOO0 ),5 )#line:3029
        if len (OOO0OOOOO0OOOOOO0 )>0 :#line:3030
            O0O000OO000O000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] Source(s) have been found Broken"%(COLOR1 ,len (OOO0OOOOO0OOOOOO0 ),COLOR2 ),"Would you like to Remove all or choose one by one?[/COLOR]",yeslabel ="[B][COLOR green]Remove All[/COLOR][/B]",nolabel ="[B][COLOR red]Choose to Delete[/COLOR][/B]")#line:3031
            if O0O000OO000O000O0 ==1 :#line:3032
                OO00000000000OOO0 =OOO0OOOOO0OOOOOO0 #line:3033
            else :#line:3034
                for OO000OOOO0000000O ,O0O0OOO0OO00000O0 ,O0O0OO000O00OOOO0 ,OOO00OO0OOOOO0O00 in OOO0OOOOO0OOOOOO0 :#line:3035
                    log ("%s sources: %s, %s"%(OO000OOOO0000000O ,O0O0OOO0OO00000O0 ,OOO00OO0OOOOO0O00 ),5 )#line:3036
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] was reported as non working"%(COLOR1 ,OO000OOOO0000000O ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OOO0OO00000O0 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00OO0OOOOO0O00 ),yeslabel ="[B][COLOR green]Remove Source[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Source[/COLOR][/B]"):#line:3037
                        OO00000000000OOO0 .append ([OO000OOOO0000000O ,O0O0OOO0OO00000O0 ,O0O0OO000O00OOOO0 ,OOO00OO0OOOOO0O00 ])#line:3038
                        log ("Removing Source %s"%OO000OOOO0000000O ,5 )#line:3039
                    else :log ("Source %s was not removed"%OO000OOOO0000000O ,5 )#line:3040
            if len (OO00000000000OOO0 )>0 :#line:3041
                for OO000OOOO0000000O ,O0O0OOO0OO00000O0 ,O0O0OO000O00OOOO0 ,OOO00OO0OOOOO0O00 in OO00000000000OOO0 :#line:3042
                    O00O0000OO00OO0OO =O00O0000OO00OO0OO .replace ('\n        <source>\n            <name>%s</name>\n            <path pathversion="1">%s</path>\n            <allowsharing>%s</allowsharing>\n        </source>'%(OO000OOOO0000000O ,O0O0OOO0OO00000O0 ,O0O0OO000O00OOOO0 ),'')#line:3043
                    log ("Removing Source %s"%OO000OOOO0000000O ,5 )#line:3044
                O0000OOO00OOOO000 =open (SOURCES ,mode ='w')#line:3046
                O0000OOO00OOOO000 .write (str (O00O0000OO00OO0OO ))#line:3047
                O0000OOO00OOOO000 .close ()#line:3048
                O000000OO00O0O0O0 =len (O0OOOO0OO00OOOO00 )-len (OOO0OOOOO0OOOOOO0 )#line:3049
                OO00O0O0000O0OOO0 =len (OOO0OOOOO0OOOOOO0 )-len (OO00000000000OOO0 )#line:3050
                OO00O00OO0O00000O =len (OO00000000000OOO0 )#line:3051
                DIALOG .ok (ADDONTITLE ,"[COLOR %s]Checking sources for broken paths has been completed"%COLOR2 ,"Working: [COLOR %s]%s[/COLOR] | Kept: [COLOR %s]%s[/COLOR] | Removed: [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR2 ,COLOR1 ,O000000OO00O0O0O0 ,COLOR1 ,OO00O0O0000O0OOO0 ,COLOR1 ,OO00O00OO0O00000O ))#line:3052
            else :log ("No Bad Sources to be removed.",5 )#line:3053
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Sources Are Working[/COLOR]"%COLOR2 )#line:3054
    else :log ("No Sources Found",5 )#line:3055
def checkRepos ():#line:3057
    DP .create (ADDONTITLE ,'[COLOR %s]Checking Repositories...[/COLOR]'%COLOR2 )#line:3058
    O0OO000OO0OO0O0OO =[]#line:3059
    ebi ('UpdateAddonRepos')#line:3060
    O000O0OOO0O000000 =glob .glob (os .path .join (ADDONS ,'repo*'))#line:3061
    if len (O000O0OOO0O000000 )==0 :#line:3062
        DP .close ()#line:3063
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Repositories Found![/COLOR]"%COLOR2 )#line:3064
        return #line:3065
    O0OOO00OOOO00000O =len (O000O0OOO0O000000 );OO0O0OOO0O0000O00 =0 ;#line:3066
    while OO0O0OOO0O0000O00 <O0OOO00OOOO00000O :#line:3067
        OO0O0OOO0O0000O00 +=1 #line:3068
        if DP .iscanceled ():break #line:3069
        O0O00000O0OO000OO =int (percentage (OO0O0OOO0O0000O00 ,O0OOO00OOOO00000O ))#line:3070
        DP .update (O0O00000O0OO000OO ,'','[COLOR %s]Checking: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0OOO0O000000 [OO0O0OOO0O0000O00 -1 ].replace (ADDONS ,'')[1 :]))#line:3071
        xbmc .sleep (1000 )#line:3072
    if DP .iscanceled ():#line:3073
        DP .close ()#line:3074
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled[/COLOR]"%COLOR2 )#line:3075
        sys .exit ()#line:3076
    DP .close ()#line:3077
    OOOO000OOOO000000 =Grab_Log (False )#line:3078
    OOOOO0O0O0OOOO000 =re .compile ('CRepositoryUpdateJob(.+?)failed').findall (OOOO000OOOO000000 )#line:3079
    for OO00O0OO00O00OOOO in OOOOO0O0O0OOOO000 :#line:3080
        log ("Bad Repository: %s "%OO00O0OO00O00OOOO ,5 )#line:3081
        O000OOOO000O00OO0 =OO00O0OO00O00OOOO .replace ('[','').replace (']','').replace (' ','').replace ('/','').replace ('\\','')#line:3082
        if not O000OOOO000O00OO0 in O0OO000OO0OO0O0OO :#line:3083
            O0OO000OO0OO0O0OO .append (O000OOOO000O00OO0 )#line:3084
    if len (O0OO000OO0OO0O0OO )>0 :#line:3085
        OO0O00OOOOO0O0O0O ="[COLOR %s]Below is a list of Repositories that did not resolve.  This does not mean that they are Depreciated, sometimes hosts go down for a short period of time.  Please do serveral scans of your repository list before removing a repository just to make sure it is broken.[/COLOR][CR][CR][COLOR %s]"%(COLOR2 ,COLOR1 )#line:3086
        OO0O00OOOOO0O0O0O +='[CR]'.join (O0OO000OO0OO0O0OO )#line:3087
        OO0O00OOOOO0O0O0O +='[/COLOR]'#line:3088
        TextBox ("%s: Bad Repositories"%ADDONTITLE ,OO0O00OOOOO0O0O0O )#line:3089
    else :#line:3090
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Repositories Working![/COLOR]"%COLOR2 )#line:3091
def killxbmc (over =None ):#line:3097
        log ("Force Closing Kodi: Platform[%s]"%str (platform_d ()),5 )#line:3098
        os ._exit (1 )#line:3099
def redoThumbs ():#line:3101
    if not os .path .exists (THUMBS ):os .makedirs (THUMBS )#line:3102
    OO0OOO00O0OO0OO0O ='0123456789abcdef'#line:3103
    OO00OO0OO0OO0O00O =os .path .join (THUMBS ,'Video','Bookmarks')#line:3104
    for OO0OO0OOOOO00O000 in OO0OOO00O0OO0OO0O :#line:3105
        OOOOO0000O00O0OO0 =os .path .join (THUMBS ,OO0OO0OOOOO00O000 )#line:3106
        if not os .path .exists (OOOOO0000O00O0OO0 ):os .makedirs (OOOOO0000O00O0OO0 )#line:3107
    if not os .path .exists (OO00OO0OO0OO0O00O ):os .makedirs (OO00OO0OO0OO0O00O )#line:3108
def reloadFix (default =None ):#line:3110
    DIALOG .ok (ADDONTITLE ,"[COLOR %s]WARNING: Sometimes Reloading the Profile causes Kodi to crash.  While Kodi is Reloading the Profile Please Do Not Press Any Buttons![/COLOR]"%COLOR2 )#line:3111
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3112
    if default ==None :#line:3113
        lookandFeelData ('save')#line:3114
    redoThumbs ()#line:3115
    ebi ('ActivateWindow(Home)')#line:3116
    xbmc .sleep (10000 )#line:3118
    if KODIV >=17 :kodi17Fix ()#line:3119
    if default ==None :#line:3120
        log ("Switching to: %s"%getS ('defaultskin'))#line:3121
        O0O000OOOO00OO0OO =getS ('defaultskin')#line:3122
        skinSwitch .swapSkins (O0O000OOOO00OO0OO )#line:3123
        O0O000OOOOO000O0O =0 #line:3124
        while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O000OOOOO000O0O <150 :#line:3125
            O0O000OOOOO000O0O +=1 #line:3126
            xbmc .sleep (200 )#line:3127
        if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3128
            ebi ('SendClick(11)')#line:3129
        lookandFeelData ('restore')#line:3130
    addonUpdates ('reset')#line:3131
    forceUpdate ()#line:3132
    ebi ("ReloadSkin()")#line:3133
def skinToDefault ():#line:3135
    if not currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary']:#line:3136
        O0OOO0O0OOO000000 ='skin.confluence'if KODIV <17 else 'skin.estuary'#line:3137
    swapSkins (O0OOO0O0OOO000000 )#line:3138
def swapSkins (OO00OO0OO0O0O000O ):#line:3140
    skinSwitch .swapSkins (OO00OO0OO0O0O000O )#line:3141
    O0O0OOO0O0OOO0O0O =0 #line:3142
    xbmc .sleep (1000 )#line:3143
    while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OOO0O0OOO0O0O <150 :#line:3144
        O0O0OOO0O0OOO0O0O +=1 #line:3145
        xbmc .sleep (100 )#line:3146
        ebi ('SendAction(Select)')#line:3147
    if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3149
        ebi ('SendClick(11)')#line:3150
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Fresh Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:3151
    xbmc .sleep (500 )#line:3152
def mediaCenter ():#line:3154
    if str (HOME ).lower ().find ('kodi'):#line:3155
        return 'Kodi'#line:3156
    elif str (HOME ).lower ().find ('spmc'):#line:3157
        return 'SPMC'#line:3158
    else :#line:3159
        return 'Unknown Fork'#line:3160
def kodi17Fix ():#line:3162
    O0OOO000O00OOO0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3163
    O0OOO0O0O000OOOO0 =[]#line:3164
    for OOO0O0000000O00OO in sorted (O0OOO000O00OOO0OO ,key =lambda O0O0OOOOO0OOOOOOO :O0O0OOOOO0OOOOOOO ):#line:3165
        OO00O00O000000OOO =os .path .join (OOO0O0000000O00OO ,'addon.xml')#line:3166
        if os .path .exists (OO00O00O000000OOO ):#line:3167
            O000OOO0O000OO0O0 =OOO0O0000000O00OO .replace (ADDONS ,'')[1 :-1 ]#line:3168
            try :#line:3169
                O00O000000OO0OOO0 =open (OO00O00O000000OOO )#line:3170
                OOO0OO0OOO000OO0O =O00O000000OO0OOO0 .read ()#line:3171
                O0O00O00OO0OOOOOO =parseDOM (OOO0OO0OOO000OO0O ,'addon',ret ='id')#line:3172
                O00O000000OO0OOO0 .close ()#line:3173
            except :#line:3174
                O00O000000OO0OOO0 =open (OO00O00O000000OOO ,encoding ='utf-8')#line:3175
                OOO0OO0OOO000OO0O =O00O000000OO0OOO0 .read ()#line:3176
                O0O00O00OO0OOOOOO =parseDOM (OOO0OO0OOO000OO0O ,'addon',ret ='id')#line:3177
                O00O000000OO0OOO0 .close ()#line:3178
            try :#line:3179
                O0O00O0OO0000OO00 =xbmcaddon .Addon (id =O0O00O00OO0OOOOOO [0 ])#line:3180
            except :#line:3181
                try :#line:3182
                    O0OOO0O0O000OOOO0 .append (O0O00O00OO0OOOOOO [0 ])#line:3184
                except :#line:3185
                    try :#line:3186
                        O0OOO0O0O000OOOO0 .append (O000OOO0O000OO0O0 )#line:3188
                    except :#line:3189
                        if len (O0O00O00OO0OOOOOO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O000OOO0O000OO0O0 ,5 )#line:3190
                        else :log ("Unabled to enable: %s"%OOO0O0000000O00OO ,5 )#line:3191
    if len (O0OOO0O0O000OOOO0 )>0 :#line:3192
        O00OO0OO00OOOO000 =0 #line:3193
        if not BUILDNAME =="":#line:3194
            DP .create (ADDONTITLE ,'[COLOR %s]מעדכן הרחבות'%COLOR2 +'\n'+''+'\n'+'אנא המתן[/COLOR]')#line:3196
            for O0O00O0OO0OO000OO in O0OOO0O0O000OOOO0 :#line:3198
                if 'service.xbmc.versioncheck'in O0O00O0OO0OO000OO :#line:3199
                   continue #line:3200
                if 'metadata.themoviedb.org.python'in O0O00O0OO0OO000OO :#line:3201
                   continue #line:3202
                if 'metadata.tvshows.themoviedb.org.python'in O0O00O0OO0OO000OO :#line:3203
                   continue #line:3204
                if 'game.controller.default'in O0O00O0OO0OO000OO :#line:3205
                   continue #line:3206
                if 'game.controller.snes'in O0O00O0OO0OO000OO :#line:3207
                   continue #line:3208
                if 'metadata.album.universal'in O0O00O0OO0OO000OO :#line:3209
                   continue #line:3210
                if 'metadata.artists.universal'in O0O00O0OO0OO000OO :#line:3211
                   continue #line:3212
                if 'metadata.common.imdb.com'in O0O00O0OO0OO000OO :#line:3213
                   continue #line:3214
                if 'metadata.common.themoviedb.org'in O0O00O0OO0OO000OO :#line:3215
                   continue #line:3216
                if 'metadata.tvshows.themoviedb.org'in O0O00O0OO0OO000OO :#line:3217
                   continue #line:3218
                O00OO0OO00OOOO000 +=1 #line:3219
                OOOOO000OO000O000 =int (percentage (O00OO0OO00OOOO000 ,len (O0OOO0O0O000OOOO0 )))#line:3220
                try :#line:3221
                   DP .update (OOOOO000OO000O000 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00O0OO0OO000OO ))#line:3222
                except :#line:3223
                   DP .update (OOOOO000OO000O000 ,"Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00O0OO0OO000OO ))#line:3224
                addonDatabase (O0O00O0OO0OO000OO ,1 )#line:3225
                if DP .iscanceled ():break #line:3226
            if DP .iscanceled ():#line:3227
                DP .close ()#line:3228
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3229
                sys .exit ()#line:3230
            DP .close ()#line:3231
        else :#line:3232
          for O0O00O0OO0OO000OO in O0OOO0O0O000OOOO0 :#line:3233
            if 'service.xbmc.versioncheck'in O0O00O0OO0OO000OO :#line:3234
               continue #line:3235
            if 'metadata.themoviedb.org.python'in O0O00O0OO0OO000OO :#line:3236
               continue #line:3237
            if 'metadata.tvshows.themoviedb.org.python'in O0O00O0OO0OO000OO :#line:3238
               continue #line:3239
            if 'game.controller.default'in O0O00O0OO0OO000OO :#line:3240
               continue #line:3241
            if 'game.controller.snes'in O0O00O0OO0OO000OO :#line:3242
               continue #line:3243
            if 'metadata.album.universal'in O0O00O0OO0OO000OO :#line:3244
               continue #line:3245
            if 'metadata.artists.universal'in O0O00O0OO0OO000OO :#line:3246
               continue #line:3247
            if 'metadata.common.imdb.com'in O0O00O0OO0OO000OO :#line:3248
               continue #line:3249
            if 'metadata.common.themoviedb.org'in O0O00O0OO0OO000OO :#line:3250
               continue #line:3251
            if 'metadata.tvshows.themoviedb.org'in O0O00O0OO0OO000OO :#line:3252
               continue #line:3253
            addonDatabase (O0O00O0OO0OO000OO ,1 )#line:3255
    forceUpdate ()#line:3256
def addonDatabase (addon =None ,state =1 ):#line:3259
    O0000O00O00O0O0OO =latestDB ('Addons')#line:3260
    O0000O00O00O0O0OO =os .path .join (DATABASE ,O0000O00O00O0O0OO )#line:3261
    O00OOO000O000OO0O =str (datetime .now ())[:-7 ]#line:3262
    if os .path .exists (O0000O00O00O0O0OO ):#line:3263
        try :#line:3264
            OO00000O0O0O0OO00 =database .connect (O0000O00O00O0O0OO )#line:3265
            OOO00OO000OOOO00O =OO00000O0O0O0OO00 .cursor ()#line:3266
        except Exception as OOOO0000O0OO0OOOO :#line:3267
            log ("DB Connection Error: %s"%str (OOOO0000O0OO0OOOO ),5 )#line:3268
            return False #line:3269
    else :return False #line:3270
    if state ==2 :#line:3271
        try :#line:3272
            OOO00OO000OOOO00O .execute ("DELETE FROM installed WHERE addonID = ?",(addon ,))#line:3273
            OO00000O0O0O0OO00 .commit ()#line:3274
            OOO00OO000OOOO00O .close ()#line:3275
        except Exception as OOOO0000O0OO0OOOO :#line:3276
            log ("Error Removing %s from DB"%addon )#line:3277
        return True #line:3278
    try :#line:3279
        OOO00OO000OOOO00O .execute ("SELECT id, addonID, enabled FROM installed WHERE addonID = ?",(addon ,))#line:3280
        OO0000OO0OO00O000 =OOO00OO000OOOO00O .fetchone ()#line:3281
        if OO0000OO0OO00O000 ==None :#line:3282
            OOO00OO000OOOO00O .execute ('INSERT INTO installed (addonID , enabled, installDate) VALUES (?,?,?)',(addon ,state ,O00OOO000O000OO0O ,))#line:3283
            log ("Insert %s into db"%addon )#line:3284
        else :#line:3285
            OO000OO0O0000O00O ,O0O0OO00O0OO0OOO0 ,OO00OO00000O00O00 =OO0000OO0OO00O000 #line:3286
            OOO00OO000OOOO00O .execute ('UPDATE installed SET enabled = ? WHERE id = ? ',(state ,OO000OO0O0000O00O ,))#line:3287
            log ("Updated %s in db"%addon )#line:3288
        OO00000O0O0O0OO00 .commit ()#line:3289
        OOO00OO000OOOO00O .close ()#line:3290
    except Exception as OOOO0000O0OO0OOOO :#line:3291
        log ("Erroring enabling addon: %s"%addon )#line:3292
def purgeDb (OO00OO00OO0000O0O ):#line:3297
    log ('Purging DB %s.'%OO00OO00OO0000O0O ,5 )#line:3301
    if os .path .exists (OO00OO00OO0000O0O ):#line:3302
        try :#line:3303
            OO0O0O0OOO00O0O0O =database .connect (OO00OO00OO0000O0O )#line:3304
            O0O0000O0O0000O0O =OO0O0O0OOO00O0O0O .cursor ()#line:3305
        except Exception as O0000000OOOO00O0O :#line:3306
            log ("DB Connection Error: %s"%str (O0000000OOOO00O0O ),5 )#line:3307
            return False #line:3308
    else :log ('%s not found.'%OO00OO00OO0000O0O ,5 );return False #line:3309
    O0O0000O0O0000O0O .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:3310
    for OO0OOOO00000O0O0O in O0O0000O0O0000O0O .fetchall ():#line:3311
        if OO0OOOO00000O0O0O [0 ]=='version':#line:3312
            log ('Data from table `%s` skipped.'%OO0OOOO00000O0O0O [0 ],5 )#line:3313
        else :#line:3314
            try :#line:3315
                O0O0000O0O0000O0O .execute ("DELETE FROM %s"%OO0OOOO00000O0O0O [0 ])#line:3316
                OO0O0O0OOO00O0O0O .commit ()#line:3317
                log ('Data from table `%s` cleared.'%OO0OOOO00000O0O0O [0 ],5 )#line:3318
            except Exception as O0000000OOOO00O0O :log ("DB Remove Table `%s` Error: %s"%(OO0OOOO00000O0O0O [0 ],str (O0000000OOOO00O0O )),5 )#line:3319
    O0O0000O0O0000O0O .close ()#line:3320
    log ('%s DB Purging Complete.'%OO00OO00OO0000O0O ,5 )#line:3321
    O0000OO00O0OOO000 =OO00OO00OO0000O0O .replace ('\\','/').split ('/')#line:3322
    LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]%s Complete[/COLOR]"%(COLOR2 ,O0000OO00O0OOO000 [len (O0000OO00O0OOO000 )-1 ]))#line:3323
def oldThumbs ():#line:3325
    O00OOO0O0O000OO00 =os .path .join (DATABASE ,latestDB ('Textures'))#line:3326
    O0OOOO00O00OOOO0O =10 #line:3327
    OO0OO000OOOO0O0OO =TODAY -timedelta (days =7 )#line:3328
    O0O0O00O00OOOOOO0 =[]#line:3329
    OOOO0OOOOOO0OO0O0 =[]#line:3330
    OO0O00O000O000000 =0 #line:3331
    if os .path .exists (O00OOO0O0O000OO00 ):#line:3332
        try :#line:3333
            O0O00O000OOO0O00O =database .connect (O00OOO0O0O000OO00 )#line:3334
            OO0O00O00OO0OO0O0 =O0O00O000OOO0O00O .cursor ()#line:3335
        except Exception as O00O0OO00O000O0O0 :#line:3336
            log ("DB Connection Error: %s"%str (O00O0OO00O000O0O0 ),5 )#line:3337
            return False #line:3338
    else :log ('%s not found.'%O00OOO0O0O000OO00 ,5 );return False #line:3339
    OO0O00O00OO0OO0O0 .execute ("SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?",(O0OOOO00O00OOOO0O ,str (OO0OO000OOOO0O0OO )))#line:3340
    OO0O00O00O00O000O =OO0O00O00OO0OO0O0 .fetchall ()#line:3341
    for OOO00OO0OO0OOO0OO in OO0O00O00O00O000O :#line:3342
        O0O0OOOOOO000OOO0 =OOO00OO0OO0OOO0OO [0 ]#line:3343
        O0O0O00O00OOOOOO0 .append (O0O0OOOOOO000OOO0 )#line:3344
        OO0O00O00OO0OO0O0 .execute ("SELECT cachedurl FROM texture WHERE id = ?",(O0O0OOOOOO000OOO0 ,))#line:3345
        O0O000OO0O0O00OO0 =OO0O00O00OO0OO0O0 .fetchall ()#line:3346
        for O0OO00O0O00000OOO in O0O000OO0O0O00OO0 :#line:3347
            OOOO0OOOOOO0OO0O0 .append (O0OO00O0O00000OOO [0 ])#line:3348
    log ("%s total thumbs cleaned up."%str (len (OOOO0OOOOOO0OO0O0 )),5 )#line:3349
    for O00OO00OO0000O00O in O0O0O00O00OOOOOO0 :#line:3350
        OO0O00O00OO0OO0O0 .execute ("DELETE FROM sizes   WHERE idtexture = ?",(O00OO00OO0000O00O ,))#line:3351
        OO0O00O00OO0OO0O0 .execute ("DELETE FROM texture WHERE id        = ?",(O00OO00OO0000O00O ,))#line:3352
    OO0O00O00OO0OO0O0 .execute ("VACUUM")#line:3353
    O0O00O000OOO0O00O .commit ()#line:3354
    OO0O00O00OO0OO0O0 .close ()#line:3355
    for O00O00O0O0O00O000 in OOOO0OOOOOO0OO0O0 :#line:3356
        O0000O0O0000OO0O0 =os .path .join (THUMBS ,O00O00O0O0O00O000 )#line:3357
        try :#line:3358
            O0O0000OOOOOO0O0O =os .path .getsize (O0000O0O0000OO0O0 )#line:3359
            os .remove (O0000O0O0000OO0O0 )#line:3360
            OO0O00O000O000000 +=O0O0000OOOOOO0O0O #line:3361
        except :#line:3362
            pass #line:3363
    O0OOO00O00OOOO0O0 =convertSize (OO0O00O000O000000 )#line:3364
    if len (OOOO0OOOOOO0OO0O0 )>0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: %s Files / %s MB[/COLOR]!'%(COLOR2 ,str (len (OOOO0OOOOOO0OO0O0 )),O0OOO00O00OOOO0O0 ))#line:3365
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: None Found![/COLOR]'%COLOR2 )#line:3366
def parseDOM (OO00O0OOOOOOO0OOO ,name =u"",attrs ={},ret =False ):#line:3368
    if isinstance (OO00O0OOOOOOO0OOO ,str ):#line:3371
        try :#line:3372
            OO00O0OOOOOOO0OOO =[OO00O0OOOOOOO0OOO .decode ("utf-8")]#line:3373
        except :#line:3374
            OO00O0OOOOOOO0OOO =[OO00O0OOOOOOO0OOO ]#line:3375
    elif isinstance (OO00O0OOOOOOO0OOO ,unicode ):#line:3376
        OO00O0OOOOOOO0OOO =[OO00O0OOOOOOO0OOO ]#line:3377
    elif not isinstance (OO00O0OOOOOOO0OOO ,list ):#line:3378
        return u""#line:3379
    if not name .strip ():#line:3381
        return u""#line:3382
    OO00OO000O00OO0O0 =[]#line:3384
    for O00OO0O0000O0O00O in OO00O0OOOOOOO0OOO :#line:3385
        O00OO000000000O0O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O00OO0O0000O0O00O )#line:3386
        for O00O0O0OOOOO0OO0O in O00OO000000000O0O :#line:3387
            O00OO0O0000O0O00O =O00OO0O0000O0O00O .replace (O00O0O0OOOOO0OO0O ,O00O0O0OOOOO0OO0O .replace ("\n"," "))#line:3388
        O0O00O0O0OOOOOO00 =[]#line:3390
        for OOOOOOOOOO000O0O0 in attrs :#line:3391
            O0O00000O0O0000O0 =re .compile ('(<'+name +'[^>]*?(?:'+OOOOOOOOOO000O0O0 +'=[\'"]'+attrs [OOOOOOOOOO000O0O0 ]+'[\'"].*?>))',re .M |re .S ).findall (O00OO0O0000O0O00O )#line:3392
            if len (O0O00000O0O0000O0 )==0 and attrs [OOOOOOOOOO000O0O0 ].find (" ")==-1 :#line:3393
                O0O00000O0O0000O0 =re .compile ('(<'+name +'[^>]*?(?:'+OOOOOOOOOO000O0O0 +'='+attrs [OOOOOOOOOO000O0O0 ]+'.*?>))',re .M |re .S ).findall (O00OO0O0000O0O00O )#line:3394
            if len (O0O00O0O0OOOOOO00 )==0 :#line:3396
                O0O00O0O0OOOOOO00 =O0O00000O0O0000O0 #line:3397
                O0O00000O0O0000O0 =[]#line:3398
            else :#line:3399
                OO000O000O0O000O0 =range (len (O0O00O0O0OOOOOO00 ))#line:3400
                OO000O000O0O000O0 .reverse ()#line:3401
                for OO0OOO00O000OOO0O in OO000O000O0O000O0 :#line:3402
                    if not O0O00O0O0OOOOOO00 [OO0OOO00O000OOO0O ]in O0O00000O0O0000O0 :#line:3403
                        del (O0O00O0O0OOOOOO00 [OO0OOO00O000OOO0O ])#line:3404
        if len (O0O00O0O0OOOOOO00 )==0 and attrs =={}:#line:3406
            O0O00O0O0OOOOOO00 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O00OO0O0000O0O00O )#line:3407
            if len (O0O00O0O0OOOOOO00 )==0 :#line:3408
                O0O00O0O0OOOOOO00 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O00OO0O0000O0O00O )#line:3409
        if isinstance (ret ,str ):#line:3411
            O0O00000O0O0000O0 =[]#line:3412
            for O00O0O0OOOOO0OO0O in O0O00O0O0OOOOOO00 :#line:3413
                OOOOOOO0OOOO0O00O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O00O0O0OOOOO0OO0O )#line:3414
                if len (OOOOOOO0OOOO0O00O )==0 :#line:3415
                    OOOOOOO0OOOO0O00O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O00O0O0OOOOO0OO0O )#line:3416
                for OOOO0OO0O0000OOO0 in OOOOOOO0OOOO0O00O :#line:3417
                    O00OO0OO0OO000O0O =OOOO0OO0O0000OOO0 [0 ]#line:3418
                    if O00OO0OO0OO000O0O in "'\"":#line:3419
                        if OOOO0OO0O0000OOO0 .find ('='+O00OO0OO0OO000O0O ,OOOO0OO0O0000OOO0 .find (O00OO0OO0OO000O0O ,1 ))>-1 :#line:3420
                            OOOO0OO0O0000OOO0 =OOOO0OO0O0000OOO0 [:OOOO0OO0O0000OOO0 .find ('='+O00OO0OO0OO000O0O ,OOOO0OO0O0000OOO0 .find (O00OO0OO0OO000O0O ,1 ))]#line:3421
                        if OOOO0OO0O0000OOO0 .rfind (O00OO0OO0OO000O0O ,1 )>-1 :#line:3423
                            OOOO0OO0O0000OOO0 =OOOO0OO0O0000OOO0 [1 :OOOO0OO0O0000OOO0 .rfind (O00OO0OO0OO000O0O )]#line:3424
                    else :#line:3425
                        if OOOO0OO0O0000OOO0 .find (" ")>0 :#line:3426
                            OOOO0OO0O0000OOO0 =OOOO0OO0O0000OOO0 [:OOOO0OO0O0000OOO0 .find (" ")]#line:3427
                        elif OOOO0OO0O0000OOO0 .find ("/")>0 :#line:3428
                            OOOO0OO0O0000OOO0 =OOOO0OO0O0000OOO0 [:OOOO0OO0O0000OOO0 .find ("/")]#line:3429
                        elif OOOO0OO0O0000OOO0 .find (">")>0 :#line:3430
                            OOOO0OO0O0000OOO0 =OOOO0OO0O0000OOO0 [:OOOO0OO0O0000OOO0 .find (">")]#line:3431
                    O0O00000O0O0000O0 .append (OOOO0OO0O0000OOO0 .strip ())#line:3433
            O0O00O0O0OOOOOO00 =O0O00000O0O0000O0 #line:3434
        else :#line:3435
            O0O00000O0O0000O0 =[]#line:3436
            for O00O0O0OOOOO0OO0O in O0O00O0O0OOOOOO00 :#line:3437
                OO0O0OOOO0O0O00O0 =u"</"+name #line:3438
                OOOO00000O0OOO0OO =O00OO0O0000O0O00O .find (O00O0O0OOOOO0OO0O )#line:3440
                O0O00O00OOO00OOOO =O00OO0O0000O0O00O .find (OO0O0OOOO0O0O00O0 ,OOOO00000O0OOO0OO )#line:3441
                O0O00000000O0O0OO =O00OO0O0000O0O00O .find ("<"+name ,OOOO00000O0OOO0OO +1 )#line:3442
                while O0O00000000O0O0OO <O0O00O00OOO00OOOO and O0O00000000O0O0OO !=-1 :#line:3444
                    O000O000O00OO00OO =O00OO0O0000O0O00O .find (OO0O0OOOO0O0O00O0 ,O0O00O00OOO00OOOO +len (OO0O0OOOO0O0O00O0 ))#line:3445
                    if O000O000O00OO00OO !=-1 :#line:3446
                        O0O00O00OOO00OOOO =O000O000O00OO00OO #line:3447
                    O0O00000000O0O0OO =O00OO0O0000O0O00O .find ("<"+name ,O0O00000000O0O0OO +1 )#line:3448
                if OOOO00000O0OOO0OO ==-1 and O0O00O00OOO00OOOO ==-1 :#line:3450
                    O00OO0O000OO0000O =u""#line:3451
                elif OOOO00000O0OOO0OO >-1 and O0O00O00OOO00OOOO >-1 :#line:3452
                    O00OO0O000OO0000O =O00OO0O0000O0O00O [OOOO00000O0OOO0OO +len (O00O0O0OOOOO0OO0O ):O0O00O00OOO00OOOO ]#line:3453
                elif O0O00O00OOO00OOOO >-1 :#line:3454
                    O00OO0O000OO0000O =O00OO0O0000O0O00O [:O0O00O00OOO00OOOO ]#line:3455
                elif OOOO00000O0OOO0OO >-1 :#line:3456
                    O00OO0O000OO0000O =O00OO0O0000O0O00O [OOOO00000O0OOO0OO +len (O00O0O0OOOOO0OO0O ):]#line:3457
                if ret :#line:3459
                    OO0O0OOOO0O0O00O0 =O00OO0O0000O0O00O [O0O00O00OOO00OOOO :O00OO0O0000O0O00O .find (">",O00OO0O0000O0O00O .find (OO0O0OOOO0O0O00O0 ))+1 ]#line:3460
                    O00OO0O000OO0000O =O00O0O0OOOOO0OO0O +O00OO0O000OO0000O +OO0O0OOOO0O0O00O0 #line:3461
                O00OO0O0000O0O00O =O00OO0O0000O0O00O [O00OO0O0000O0O00O .find (O00OO0O000OO0000O ,O00OO0O0000O0O00O .find (O00O0O0OOOOO0OO0O ))+len (O00OO0O000OO0000O ):]#line:3463
                O0O00000O0O0000O0 .append (O00OO0O000OO0000O )#line:3464
            O0O00O0O0OOOOOO00 =O0O00000O0O0000O0 #line:3465
        OO00OO000O00OO0O0 +=O0O00O0O0OOOOOO00 #line:3466
    return OO00OO000O00OO0O0 #line:3468
def replaceHTMLCodes (O00OO0O0O0O000OOO ):#line:3471
    O00OO0O0O0O000OOO =re .sub ("(&#[0-9]+)([^;^0-9]+)","\\1;\\2",O00OO0O0O0O000OOO )#line:3472
    O00OO0O0O0O000OOO =HTMLParser .HTMLParser ().unescape (O00OO0O0O0O000OOO )#line:3473
    O00OO0O0O0O000OOO =O00OO0O0O0O000OOO .replace ("&quot;","\"")#line:3474
    O00OO0O0O0O000OOO =O00OO0O0O0O000OOO .replace ("&amp;","&")#line:3475
    return O00OO0O0O0O000OOO #line:3476
import os #line:3478
from shutil import *#line:3479
def copytree (OO0000OO0OOOOO0O0 ,O0O0OOOO00OO0OOO0 ,symlinks =False ,ignore =None ):#line:3480
    O00OOO0000O0OO000 =os .listdir (OO0000OO0OOOOO0O0 )#line:3481
    if ignore is not None :#line:3482
        OO0O000O000OOOO0O =ignore (OO0000OO0OOOOO0O0 ,O00OOO0000O0OO000 )#line:3483
    else :#line:3484
        OO0O000O000OOOO0O =set ()#line:3485
    if not os .path .isdir (O0O0OOOO00OO0OOO0 ):#line:3486
        os .makedirs (O0O0OOOO00OO0OOO0 )#line:3487
    OO00OOOOO000OO000 =[]#line:3488
    for OO0OO00OOO000OO00 in O00OOO0000O0OO000 :#line:3489
        if OO0OO00OOO000OO00 in OO0O000O000OOOO0O :#line:3490
            continue #line:3491
        O00OOO00000O0OOO0 =os .path .join (OO0000OO0OOOOO0O0 ,OO0OO00OOO000OO00 )#line:3492
        OO00OO000O0O0OOOO =os .path .join (O0O0OOOO00OO0OOO0 ,OO0OO00OOO000OO00 )#line:3493
        try :#line:3494
            if symlinks and os .path .islink (O00OOO00000O0OOO0 ):#line:3495
                O00O0OOOOOOOOO000 =os .readlink (O00OOO00000O0OOO0 )#line:3496
                os .symlink (O00O0OOOOOOOOO000 ,OO00OO000O0O0OOOO )#line:3497
            elif os .path .isdir (O00OOO00000O0OOO0 ):#line:3498
                copytree (O00OOO00000O0OOO0 ,OO00OO000O0O0OOOO ,symlinks ,ignore )#line:3499
            else :#line:3500
                copy2 (O00OOO00000O0OOO0 ,OO00OO000O0O0OOOO )#line:3501
        except Error as OOOO0000O00O00O00 :#line:3502
            OO00OOOOO000OO000 .extend (OOOO0000O00O00O00 .args [0 ])#line:3503
        except EnvironmentError as O0000000OO0O000OO :#line:3504
            OO00OOOOO000OO000 .append ((O00OOO00000O0OOO0 ,OO00OO000O0O0OOOO ,str (O0000000OO0O000OO )))#line:3505
    try :#line:3506
        copystat (OO0000OO0OOOOO0O0 ,O0O0OOOO00OO0OOO0 )#line:3507
    except OSError as O0000000OO0O000OO :#line:3508
        OO00OOOOO000OO000 .extend ((OO0000OO0OOOOO0O0 ,O0O0OOOO00OO0OOO0 ,str (O0000000OO0O000OO )))#line:3509
