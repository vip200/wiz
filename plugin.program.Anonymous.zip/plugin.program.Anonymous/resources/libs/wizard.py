# coding: utf-8

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob, zipfile, json,base64
import shutil,logging,random,urllib,re,uservar,time,subprocess,hashlib,codecs



from html.parser import HTMLParser
from urllib.request import urlopen
from urllib.request import Request
from datetime import date, datetime, timedelta
try:    from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database

from urllib.parse import quote_plus

translatepath=xbmcvfs.translatePath

que=urllib.parse.quote_plus
url_encode=urllib.parse.urlencode

ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
ADDON          = xbmcaddon.Addon(ADDON_ID)
VERSION        = ADDON.getAddonInfo('version')
USER_AGENT     = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
DP2              = xbmcgui.DialogProgressBG()
HOME           = translatepath('special://home/')
XBMC           = translatepath('special://xbmc/')
LOG            = translatepath('special://logpath/')
PROFILE        = translatepath('special://profile/')

ADDONS         = os.path.join(HOME,      'addons')
USERDATA       = os.path.join(HOME,      'userdata')
PLUGIN         = os.path.join(ADDONS,    ADDON_ID)
PACKAGES       = os.path.join(ADDONS,    'packages')
ADDOND         = os.path.join(USERDATA,  'addon_data')
ADDONDATA      = os.path.join(USERDATA,  'addon_data', ADDON_ID)
THUMBS         = os.path.join(USERDATA,  'Thumbnails')
DATABASE       = os.path.join(USERDATA,  'Database')
FANART         = os.path.join(PLUGIN,    'fanart.jpg')
ICON           = os.path.join(PLUGIN,    'icon.png')
DEBUGLEVEL     = ADDON.getSetting('debuglevel')
ENABLEWIZLOG   = ADDON.getSetting('wizardlog')
WIZLOG         = os.path.join(ADDONDATA, 'wizard.log')
TODAY          = date.today()
TOMORROW       = TODAY + timedelta(days=1)
TWODAYS        = TODAY + timedelta(days=2)
THREEDAYS      = TODAY + timedelta(days=3)
ONEWEEK        = TODAY + timedelta(days=7)
MONTH        = TODAY - timedelta(days=2)
LASTONEWEEK        = TODAY - timedelta(days=7)
EXCLUDES       = uservar.EXCLUDES
WIZARDFILE     = uservar.WIZARDFILE
NOTIFICATION   = uservar.NOTIFICATION
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
HARDWAER       = ADDON.getSetting('action')
BUILDNAME        = ADDON.getSetting('buildname')
CONTACTICON    = uservar.CONTACTICON if not uservar.CONTACTICON == 'http://' else ICON 
CONTACTFANART  = uservar.CONTACTFANART if not uservar.CONTACTFANART == 'http://' else FANART
THEME3         = uservar.THEME3
THEME2         = uservar.THEME2
PS_ = base64.b64decode('aHR0cDovL2tvZGkubGlmZS93aXphcmQvd2l6LnVzZXIueG1s').decode('utf-8')#.decode('utf-8')
US_=base64.b64decode('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbmV3X3Bhc3MueG1s').decode('utf-8')#.decode('utf-8')
BL_=base64.b64decode('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbXlidWlsZDIueG1s').decode('utf-8')#.decode('utf-8')
PS            = '&eJwFwUEKgtJl6NwCAMBMAfZe_-RkjQ0Balu6L09Z3p0mQBPFvKGOF9UBYL1_DEzq--Dh1hVtLOc__fqRL8$'
US = '&eJwFwVEKgEAIBcAgtJl6Nb-f67TaCkVLjoW1r29M04OfoANK6gtJl6NsUm7tTAF_ssBRcx20rW-_zf9hME$'
dr='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNHPztSryM0BALmUEhk=$'
LOGFILES       = ['log', 'xbmc.old.log', 'kodi.log', 'kodi.old.log', 'spmc.log', 'spmc.old.log', 'tvmc.log', 'tvmc.old.log']

USER_AGENT = ('Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36'
                   ' (KHTML, like Gecko) Chrome/35.0.1916.153 Safari'
                   '/537.36 SE 2.X MetaSr 1.0')
def openURL(url, stream=False, check=False, cred=None, count=0):
    
    import requests
    user_agent = {'user-agent': USER_AGENT}     
    response = requests.get(url, headers=user_agent, timeout=60.000, stream=stream, auth=cred)
    return response

def platform_d():
    if xbmc.getCondVisibility('system.platform.android'):             return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):             return 'linux'
    elif xbmc.getCondVisibility('system.platform.linux.Raspberrypi'): return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):           return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):               return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):              return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):               return 'ios'
    elif xbmc.getCondVisibility('system.platform.darwin'):            return 'ios'

def getS(name):
    try: return ADDON.getSetting(name)
    except: return False

def setS(name, value):
    try: ADDON.setSetting(name, value)
    except: return False

def openS(name=""):
    ADDON.openSettings()

def clearS(type):
    build    = {'buildname':'', 'buildversion':'', 'latestversion':'', 'lastbuildcheck':'2016-01-01'}
    if type == 'build':
        for set in build:
            setS(set, build[set])
theme_nox='https://zxcsd-3bae5-default-rtdb.firebaseio.com'
theme_dragon='https://dragon-user-default-rtdb.firebaseio.com'
ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?
ACTION_MOUSE_LEFT_CLICK 		= 100
ACTION_MOUSE_LONG_CLICK 		= 108

def LogNotify(title, message, times, icon=ICON,sound=False):
    DIALOG.notification(title, message, icon, int(times), sound)
    #ebi('XBMC.Notification(%s, %s, %s, %s)' % (title, message, times, icon))
def LogNotify2(title, message, times=9000, icon=ICON,sound=False):
    DIALOG.notification(title, message, icon, int(times), sound)
def LogNotify3(title, message, times=5000, icon=ICON,sound=False):
    DIALOG.notification(title, message, icon, int(times), sound)
def percentage(part, whole):
    return 100 * float(part)/float(whole)

def log(msg, level=5):
    
    if not os.path.exists(ADDONDATA):
      try:
        os.makedirs(ADDONDATA)
      except:pass
    if not os.path.exists(WIZLOG): f = open(WIZLOG, 'w'); f.close()

    if DEBUGLEVEL == '0': return False
    if DEBUGLEVEL == '1' and not level in [5, 5, xbmc.LOGSEVERE, xbmc.LOGFATAL]: return False
    if DEBUGLEVEL == '2': level = 5
    try:
        try:
            if isinstance(msg, unicode):
                msg = '%s' % (msg.encode('utf-8'))
            xbmc.log('%s: %s' % (ADDONTITLE, msg), level)
        except:
            if isinstance(msg, str):
                msg = '%s' % (msg.encode('utf-8'))
            xbmc.log('%s: %s' % (ADDONTITLE, msg), level)
    except Exception as e:
        try: xbmc.log('Logging Failure: %s' % (e), level)
        except: pass

def fix():
    xbmc.executebuiltin('UpdateLocalAddons()')
    xbmc.sleep(1000)
    xbmc.executeJSONRPC('{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":true}},"id":1}}'.format('repository.gaia.2'))

def contact_wiz(msg=""):
    class MyWindow(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            self.title = THEME3 % kwargs["title"]
            self.image = kwargs["image"]
            self.fanart = kwargs["fanart"]
            self.msg = THEME2 % kwargs["msg"]

        def onInit(self):
            self.fanartimage = 101
            self.titlebox = 102
            self.imagecontrol = 103
            self.textbox = 104
            self.scrollcontrol = 105
            self.closebutton = 106
            self.showdialog()

        def showdialog(self):
            self.getControl(self.imagecontrol).setImage(self.image)
            self.getControl(self.fanartimage).setImage(self.fanart)
            self.getControl(self.fanartimage).setColorDiffuse('9FFFFFFF')
            self.getControl(self.textbox).setText(self.msg)
            self.getControl(self.titlebox).setLabel(self.title)
            self.setFocusId(self.closebutton)
        def onClick(self, controlId):
            if   controlId == self.closebutton: self.close()
        def onAction(self,action):
            if   action == self.closebutton: self.close()
            elif   action == ACTION_PREVIOUS_MENU: self.close()
            elif action == ACTION_NAV_BACK: self.close()
    if getS('dragon')=='true':
        cw = MyWindow( "ContactDragon.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', title='Kodi Dragon', fanart=CONTACTFANART, image=CONTACTICON, msg=msg)
    else:
        cw = MyWindow( "Contact.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', title='ANONYMOUS TV', fanart=CONTACTFANART, image=CONTACTICON, msg=msg)
    cw.doModal()
    del cw
def user_info_Window(tele,update,rd,userdate,username,device,device_backup,serialnumber):
    class MyWindow(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            self.title = THEME3 % kwargs["title"]
            self.image = kwargs["image"]
            self.fanart = kwargs["fanart"]
            self.tele = kwargs["tele"]
            self.update = kwargs["update"]
            self.rd = kwargs["rd"]
            self.userdate = kwargs["userdate"]
            self.username = kwargs["username"]
            self.device = kwargs["device"]
            self.device_backup = kwargs["device_backup"]
            self.serialnumber = kwargs["serialnumber"]
        def onInit(self):
            self.username_title = 100
            self.fanartimage = 101
            self.titlebox = 102
            self.imagecontrol = 103
            self.textbox = 104
            self.scrollcontrol = 105
            self.closebutton = 106
            self.tele_title = 107
            self.update_title = 108
            self.rd_title = 109
            # self.device_cunt = 110
            
            self.device_backup_name = 110#112
            self.serialnumber_name= 111
            self.serialnumberbutton = 202
            self.userdate_title = 120
            self.showdialog()

        def showdialog(self):
            self.getControl(self.username_title).setLabel(self.username)
            # self.getControl(self.device_cunt).setLabel(self.device)
            
            self.getControl(self.imagecontrol).setImage(self.image)
            self.getControl(self.fanartimage).setImage(self.fanart)
            self.getControl(self.fanartimage).setColorDiffuse('9FFFFFFF')
            # self.getControl(self.textbox).setText(self.msg)
            # self.getControl(self.titlebox).setLabel(self.title)
            self.getControl(self.tele_title).setLabel(self.tele)
            self.getControl(self.update_title).setLabel(self.update)
            self.getControl(self.rd_title).setLabel(self.rd)
            self.getControl(self.userdate_title).setLabel(self.userdate)
            self.getControl(self.device_backup_name).setLabel(self.device_backup)
            self.getControl(self.serialnumber_name).setLabel(self.serialnumber)
            self.setFocusId(self.closebutton)
            
        def onClick(self, controlId):
            if   controlId == self.closebutton: self.close()
            if   controlId == self.serialnumberbutton: 
                url = 'plugin://%s/?mode=check_id' % (ADDON_ID)
                xbmc.executebuiltin('RunPlugin(%s)' % url)
                self.close()
        def onAction(self,action):
            if   action == self.closebutton: self.close()
            elif   action == ACTION_PREVIOUS_MENU: self.close()
            elif action == ACTION_NAV_BACK: self.close()
    if getS('dragon')=='true':
        cw = MyWindow( "userinfoDragon.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', title='Kodi Dragon', fanart=CONTACTFANART, image=CONTACTICON, tele=tele,userdate=userdate,update=update,rd=rd,username=username,device=device,device_backup=device_backup,serialnumber=serialnumber)
    else:
        cw = MyWindow( "userinfo.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', title='ANONYMOUS TV', fanart=CONTACTFANART, image=CONTACTICON, tele=tele,userdate=userdate,update=update,rd=rd,username=username,device=device,device_backup=device_backup,serialnumber=serialnumber)
    if getS('serialnumber')=='':
        xbmc.executebuiltin('Skin.SetString(serial, true)')
    else:
        xbmc.executebuiltin('Skin.SetString(serial,)')
    cw.doModal()
    del cw

def checkWizard(ret):
    if not workingURL(WIZARDFILE) == True: return False
    link = openURL(WIZARDFILE)
    link=link.text.replace('\n','').replace('\r','').replace('\t','')
    match = re.compile('id="%s".+?ersion="(.+?)".+?ip="(.+?)"' % ADDON_ID).findall(link)
    if len(match) > 0:
        for version, zip in match:
            if ret   == 'version':       return version
            elif ret == 'zip':           return zip
            elif ret == 'all':           return ADDON_ID, version, zip
    else: return False

def workingURL(url):
    if url in ['http://', 'https://', '']: return False
    check = 0; status = ''
    while check < 3:
        check += 1
        try:
            req = Request(url)
            req.add_header('User-Agent', USER_AGENT)
            response = urlopen(req)
            response.close()
            status = True
            break
        except Exception as e:
            status = str(e)
            log("Working Url Error: %s [%s]" % (e, url))
            xbmc.sleep(500)
    return status
 
def openURL_old(url):
    try:
        req = Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urlopen(req)
        link=response.read()
        response.close()
        # return link kodi17
        return link.decode('utf-8')#kodi19
    except Exception as e:
        logging.warning('אין חיבור לאינטרנט'+str(e))
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין חיבור לאינטרנט[/COLOR]" % COLOR2,1500)
def getKeyboard( default="", heading="", hidden=False ):
    keyboard = xbmc.Keyboard( default, heading, hidden )
    keyboard.doModal()
    if keyboard.isConfirmed():
        return unicode( keyboard.getText(), "utf-8" )
    return default

def getSize(path, total=0):
    for dirpath, dirnames, filenames in os.walk(path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total += os.path.getsize(fp)
    return total

def convertSize(num, suffix='B'):
    for unit in ['', 'K', 'M', 'G']:
        if abs(num) < 1024.0:
            return "%3.02f %s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.02f %s%s" % (num, 'G', suffix)

def getCacheSize():
    PROFILEADDONDATA = os.path.join(PROFILE,'addon_data')
    dbfiles   = [
        (os.path.join(ADDONDATA, 'plugin.video.HebDub.movies', 'database.db')),
        (os.path.join(ADDONDATA, 'plugin.video.bob', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.specto', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.genesis', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.exodus', 'cache.db')),
        (os.path.join(DATABASE,  'onechannelcache.db')),
        (os.path.join(DATABASE,  'saltscache.db')),
        (os.path.join(DATABASE,  'saltshd.lite.db'))]
    cachelist = [
        (PROFILEADDONDATA),
        (ADDONDATA),
        (os.path.join(HOME,'cache')),
        (os.path.join(HOME,'temp')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')),
        (os.path.join(ADDONDATA,'script.module.simple.downloader')),
        (os.path.join(ADDONDATA,'plugin.video.itv','Images')),
        (os.path.join(PROFILEADDONDATA,'script.module.simple.downloader')),
        (os.path.join(PROFILEADDONDATA,'plugin.video.itv','Images'))]
        
    totalsize = 0

    for item in cachelist:
        if os.path.exists(item) and not item in [ADDONDATA, PROFILEADDONDATA]:
            totalsize = getSize(item, totalsize)
        else:
            for root, dirs, files in os.walk(item):
                for d in dirs:
                    if 'cache' in d.lower() and not d.lower() == 'meta_cache': totalsize = getSize(os.path.join(root, d), totalsize)
    

    return totalsize

def getInfo(label):
    try: return xbmc.getInfoLabel(label)
    except: return False

def removeFolder(path):
    log("Deleting Folder: %s" % path, 5)
    try: shutil.rmtree(path,ignore_errors=True, onerror=None)
    except: return False

def removeFile(path):
    log("Deleting File: %s" % path, 5)
    try:    os.remove(path)
    except: return False

def currSkin():
    return xbmc.getSkinDir()

def cleanHouse(folder, ignore=False):
    log(folder)
    total_files = 0; total_folds = 0
    for root, dirs, files in os.walk(folder):
        if ignore == False: dirs[:] = [d for d in dirs if d not in EXCLUDES]
        file_count = 0
        file_count += len(files)
        if file_count >= 0:
            for f in files:
                try: 
                    os.unlink(os.path.join(root, f))
                    total_files += 1
                except: 
                    try:
                        shutil.rmtree(os.path.join(root, f))
                    except:
                        log("Error Deleting %s" % f, 5)
            for d in dirs:
                total_folds += 1
                try: 
                    shutil.rmtree(os.path.join(root, d))
                    total_folds += 1
                except: 
                    log("Error Deleting %s" % d, 5)
    return total_files, total_folds

def emptyfolder(folder):
    total = 0
    for root, dirs, files in os.walk(folder, topdown=True):
        dirs[:] = [d for d in dirs if d not in EXCLUDES]
        file_count = 0
        file_count += len(files) + len(dirs)
        if file_count == 0:
            shutil.rmtree(os.path.join(root))
            total += 1
            log("Empty Folder: %s" % root, 5)
    return total


def latestDB(DB):
    if DB in ['Addons', 'ADSP', 'Epg', 'MyMusic', 'MyVideos', 'Textures', 'TV', 'ViewModes']:
        match = glob.glob(os.path.join(DATABASE,'%s*.db' % DB))
        comp = '%s(.+?).db' % DB[1:]
        highest = 0
        for file in match :
            try: check = int(re.compile(comp).findall(file)[0])
            except: check = 0
            if highest < check :
                highest = check
        return '%s%s.db' % (DB, highest)
    else: return False

def addonId(add):
    try: 
        return xbmcaddon.Addon(id=add)
    except:
        return False


def addonInfo(add, info):
    addon = addonId(add)
    if addon: return addon.getAddonInfo(info)
    else: return False


def getCond(type):
    return xbmc.getCondVisibility(type)

def ebi(proc):
    xbmc.executebuiltin(proc)

def refresh():
    ebi('Container.Refresh()')

def splitNotify_old(notify):
    link = openURL(notify).replace('\r','').replace('\t','').replace('\n', '[CR]')
    
    if link.find('|||') == -1: return False, False
    id, msg = link.split('|||')
    if msg.startswith('[CR]'): msg = msg[4:]
    return id.replace('[CR]', ''), msg
def splitNotify(notify):
    response = openURL(notify)
    if response:
        link = response.text
        try:
            link = response.text.decode('utf-8')
        except:
            pass
        link = link.replace('\r', '').replace('\t', '    ').replace('\n', '[CR]')
        if link.find('|||') == -1:
            return False, False
        _id, msg = link.split('|||')
        _id = _id.replace('[CR]', '')
        if msg.startswith('[CR]'):
            msg = msg[4:]
        return _id, msg
    else:
        return False, False
def forceUpdate(silent=False):
    ebi('UpdateAddonRepos()')
    ebi('UpdateLocalAddons()')


def clearCrash():  
    files = []
    for file in glob.glob(os.path.join(LOG, '*crashlog*.*')):
        files.append(file)
    if len(files) > 0:
        if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to delete the Crash logs?' % COLOR2, '[COLOR %s]%s[/COLOR] Files Found[/COLOR]' % (COLOR1, len(files)), yeslabel="[B][COLOR green]Remove Logs[/COLOR][/B]", nolabel="[B][COLOR red]Keep Logs[/COLOR][/B]"):
            for f in files:
                os.remove(f)
            LogNotify('[COLOR %s]Clear Crash Logs[/COLOR]' % COLOR1, '[COLOR %s]%s Crash Logs Removed[/COLOR]' % (COLOR2, len(files)),1500)
        else: LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, ADDONTITLE), '[COLOR %s]Clear Crash Logs Cancelled[/COLOR]' % COLOR2,1500)
    else: LogNotify('[COLOR %s]Clear Crash Logs[/COLOR]' % COLOR1, '[COLOR %s]No Crash Logs Found[/COLOR]' % COLOR2,1500)

def chunk_report(bytes_so_far, chunk_size, total_size):
   percent = float(bytes_so_far) / total_size
   percent = round(percent*100, 2)

   if bytes_so_far >= total_size:
      sys.stdout.write('\n')

def chunk_read(response, chunk_size=8192, report_hook=None,dp=None,destination='',filesize=1000000):
   import time
   total_size = 100

   bytes_so_far = 0
   start_time = time.time()
   count=0
   
   #logging.warning('Downloading')
   with open(destination, "wb") as f:
    while 1:
      duration = time.time() - start_time
      progress_size = int(count * chunk_size)
      chunk = response.read(chunk_size)
      f.write(chunk)
      f.flush()
      bytes_so_far += len(chunk)
      percent = float(bytes_so_far) / total_size
      percent = round(percent*100, 2)
      if int(duration)>0: 
        speed = int(progress_size / (1024 * duration))
      else:
         speed=0
      if speed > 1024 and not percent == 100:
          eta =int(( (total_size - progress_size)/1024) / (speed) )
      else:
          eta=0
      if eta<0:
        eta=0
      dp.update(int(percent), "\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),total_size/(1000 * 1000), speed), '[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]' % divmod(eta, 60))
      if dp.iscanceled():
         dp.close()
         break
      if not chunk:
         break

      if report_hook:
         report_hook(bytes_so_far, chunk_size, total_size)
      count += 1
   #logging.warning('END Downloading')
   return bytes_so_far
server='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNFPyklMztaryM0BAPI5E0I=$'
def googledrive_download(id, destination,dp,filesize):

    keys=[]
    id_pre=id.split('=')
    id=id_pre[len(id_pre)-1]

    def get_confirm_token(response):
        
        for cookie in response:

            backup_cookie= cookie.value
            if 'download_warning' in cookie.name:

                return cookie.value
            return backup_cookie

        return None

    def save_response_content(response, destination):
        
        CHUNK_SIZE = 32768
        start_time = time.time()
     
        with open(destination, "wb") as f:
            count = 1
            block_size = 32768
            try:
                total_size = int(response.headers.get('content-length'))
                print ('file total size :',total_size)
            except TypeError:
                print ('using dummy length !!!')
                total_size = int(filesize)*1000000
            for chunk in response.iter_content(CHUNK_SIZE):
                if chunk: # filter out keep-alive new chunks
                    f.write(chunk)
                    f.flush()
                    duration = time.time() - start_time
                    progress_size = int(count * block_size)
                    if duration == 0:
                        duration = 0.1
                    speed = int(progress_size / (1024 * duration))
                    percent = int(count * block_size * 100 / total_size)
                    if speed > 1024 and not percent == 100:
                      eta =int(( (total_size - progress_size)/1024) / (speed) )
                    else:
                      eta=0
                    #sys.stdout.write("\r...%d%%, %d MB, %d KB/s, %d seconds passed" %(percent, progress_size / (1024 * 1024), speed, duration))
                    dp.update(int(percent),name, "\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),total_size/(1000 * 1000), speed), '[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]' % divmod(eta, 60))
                    count += 1
                    if dp.iscanceled():
                     dp.close()
                     break
    URL = "https://docs.google.com/uc?export=download"

    import urllib2
    import cookielib

    from cookielib import CookieJar

    cj = CookieJar()
    opener = build_opener(HTTPCookieProcessor(cj))
    # input-type values from the html form
    formdata =  { 'id' : id }
    data_encoded = urllib.urlencode(formdata)
    #logging.warning(URL+'&'+ data_encoded)
    response = opener.open(URL+'&'+ data_encoded)
    content = response.read()

    token = get_confirm_token(cj)

    if token:
        params = { 'id' : id, 'confirm' : token }
        headers = {'Access-Control-Allow-Headers': 'Content-Length'}
        data_encoded = urllib.urlencode(params)
        response = opener.open(URL+'&'+ data_encoded)
        chunk_read(response, report_hook=chunk_report,dp=dp,destination=destination,filesize=filesize)
        
    return(keys)

def wizardUpdate(startup=None):
    try:
        if not xbmc.Player().isPlaying():
            ver = checkWizard('version')
            zip = checkWizard('zip')
            
            # if str(ver) > str(VERSION):
            if ver!= False and str(ver) > str(VERSION):
                from resources.libs import extract
                from resources.libs import downloader
                lib=os.path.join(PACKAGES, '%s-%s.zip' % (ADDON_ID, str(ver)))
                try: os.remove(lib)
                except: pass
                downloader.download_WizardBG(zip, lib, DP2)
                xbmc.sleep(500)
                DP2.create('מתקין')
                DP2.update(100, message='אנא המתן ...')
                extract.all(lib, ADDONS)
                DP2.close()
                
                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]' % COLOR2,1500)
                log("[Auto Update Wizard] Wizard updated to v%s" % str(ver), 5)
               
                return
            else: 
                if not startup: LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]No New Version of Wizard[/COLOR]" % COLOR2,1500)
                log("[Auto Update Wizard] No New Version v%s" % str(ver), 5)
    except Exception as e:
            from resources.default import send_user_info
            send_user_info('channel_new_install','עדכון ויזארד נכשל :'+str(e))
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]עדכון ויזארד נכשל[/COLOR]' % COLOR2,1500)

def wizardUpdateDP(startup=None):
    try:
        ver = checkWizard('version')
        zip = checkWizard('zip')
        
        # if str(ver) > str(VERSION):
        if ver!= False and str(ver) > str(VERSION):
            from resources.libs import extract
            from resources.libs import downloader
            lib=os.path.join(PACKAGES, '%s-%s.zip' % (ADDON_ID, str(ver)))
            try: os.remove(lib)
            except: pass
            downloader.download_WizardBG(zip, lib, DP2)
            xbmc.sleep(500)
            DP2.create('מתקין')
            DP2.update(100, message='אנא המתן ...')
            extract.all(lib, ADDONS)
            DP2.close()

            return
        else: 
            if not startup: LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]No New Version of Wizard[/COLOR]" % COLOR2,1500)
            log("[Auto Update Wizard] No New Version v%s" % str(ver), 5)
    except Exception as e:
            from resources.default import send_user_info
            send_user_info('channel_new_install','עדכון ויזארד נכשל - התקנה חדשה: '+str(e))
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]עדכון ויזארד נכשל[/COLOR]' % COLOR2,1500)
def reloadProfile(profile=None):
    if profile == None: 

        ebi('LoadProfile(Master user)')
    else: ebi('LoadProfile(%s)' % profile)

def chunks(s, n):
    for start in range(0, len(s), n):
        yield s[start:start+n]

def fileCount(home, excludes=True):
    exclude_dirs  = [ADDON_ID, 'cache', 'system', 'packages', 'Thumbnails', 'peripheral_data', 'temp', 'My_Builds', 'library', 'keymaps']
    exclude_files = ['Textures13.db', '.DS_Store', 'advancedsettings.xml', 'Thumbs.db', '.gitignore']
    item = []
    for base, dirs, files in os.walk(home):
        if excludes:
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            files[:] = [f for f in files if f not in exclude_files]
        for file in files:
            item.append(file)
    return len(item)

def sep(middle=''):
    char = uservar.SPACER
    ret = char * 40
    if not middle == '': 
        middle = '[ %s ]' % middle
        fluff = int((40 - len(middle))/2)
        ret = "%s%s%s" % (ret[:fluff], middle, ret[:fluff+2])
    return ret[:40]

def clearPackages(over=None):
    try:
        CleanPYO()
    except: pass
    if os.path.exists(PACKAGES):
        try:
            for root, dirs, files in os.walk(PACKAGES):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    size = convertSize(getSize(PACKAGES))
                    if over: yes=1
                    else: yes=1
                    if yes:
                        for f in files: os.unlink(os.path.join(root, f))
                        for d in dirs: shutil.rmtree(os.path.join(root, d))

        except Exception as e:

            log("Clear Packages Error: %s" % str(e), 5)


def clearPackagesStartup():
    start = datetime.utcnow() - timedelta(minutes=3)
    file_count = 0; cleanupsize = 0
    if os.path.exists(PACKAGES):
        pack = os.listdir(PACKAGES)
        pack.sort(key=lambda f: os.path.getmtime(os.path.join(PACKAGES, f)))
        try:
            for item in pack:
                file = os.path.join(PACKAGES, item)
                lastedit = datetime.utcfromtimestamp(os.path.getmtime(file))
                if lastedit <= start:
                    if os.path.isfile(file):
                        file_count += 1
                        cleanupsize += os.path.getsize(file)
                        os.unlink(file)
                    elif os.path.isdir(file): 
                        cleanupsize += getSize(file)
                        cleanfiles, cleanfold = cleanHouse(file)
                        file_count += cleanfiles + cleanfold
                        try:
                            shutil.rmtree(file)
                        except Exception as e:
                            log("Failed to remove %s: %s" % (file, str(e), 5))
            if file_count > 0: LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Clear Packages: Success: %s[/COLOR]' % (COLOR2, convertSize(cleanupsize)),1500)
            else: LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Clear Packages: None Found![/COLOR]' % COLOR2,1500)
        except Exception as e:
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Clear Packages: Error![/COLOR]' % COLOR2,1500)
            log("Clear Packages Error: %s" % str(e), 5)
    else: LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Clear Packages: None Found![/COLOR]' % COLOR2,1500)

def clearCache(over=None):

    PROFILEADDONDATA = os.path.join(PROFILE,'addon_data')
    dbfiles   = [
        (os.path.join(ADDONDATA, 'plugin.video.HebDub.movies', 'database.db')),
        (os.path.join(ADDONDATA, 'plugin.video.bob', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.specto', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.genesis', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.exodus', 'cache.db')),
        (os.path.join(DATABASE,  'onechannelcache.db')),
        (os.path.join(DATABASE,  'saltscache.db')),
        (os.path.join(DATABASE,  'saltshd.lite.db'))]
    cachelist = [
        (PROFILEADDONDATA),
        (ADDONDATA),
        (os.path.join(HOME,'cache')),
        (os.path.join(HOME,'cache')),
        (os.path.join(HOME,'temp')),
        os.path.join(translatepath('special://profile/addon_data/plugin.program.autocompletion/Google'), ''),
        # os.path.join(translatepath('special://profile/addon_data/plugin.video.telemedia/database/thumbnails'), ''),
        # os.path.join(translatepath('special://profile/addon_data/plugin.video.telemedia/logo'), ''),
        os.path.join(translatepath('special://profile/addon_data/script.skin.helper.colorpicker/colors'), ''),
        # os.path.join(translatepath('special://profile/addon_data/service.subtitles.All_Subs/aa_buff'), ''),
        os.path.join(translatepath('special://profile/addon_data/service.subtitles.All_Subs/temp_wizdom'), ''),
        os.path.join(translatepath('special://profile/addon_data/service.subtitles.All_Subs/temp'), ''),
        os.path.join(translatepath('special://profile/addon_data/script.colorbox'), ''),
        os.path.join(translatepath('special://profile/addon_data/script.module.metadatautils/animatedgifs'), ''),
        os.path.join(translatepath('special://profile/addon_data/script.artistslideshow/ArtistInformation'), ''),
        os.path.join(translatepath('special://profile/addon_data/script.artistslideshow/ArtistSlideshow'), ''),
        os.path.join(translatepath('special://profile/addon_data/script.artistslideshow/merge'), ''),
        os.path.join(translatepath('special://profile/addon_data/script.artistslideshow/temp'), ''),
        os.path.join(translatepath('special://profile/addon_data/script.artistslideshow/transition'), ''),
        os.path.join(translatepath('special://profile/addon_data/script.artistslideshow/resources'), ''),
        os.path.join(translatepath('special://profile/addon_data/plugin.video.movixws/logos'), ''),
        os.path.join(translatepath('special://profile/addon_data/service.subtitles.subscenter/temp'), ''),
        # os.path.join(translatepath('special://profile/addon_data/plugin.video.idanplus/epg.json'), ''),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')),
        (os.path.join(ADDONS,'temp')),
        (os.path.join(PROFILEADDONDATA,'script.module.simple.downloader')),
        (os.path.join(PROFILEADDONDATA,'plugin.video.itv','Images'))]
    delfiles = 0
    excludes = ['meta_cache', 'archive_cache']
    for item in cachelist:
        if os.path.exists(item) and not item in [ADDONDATA, PROFILEADDONDATA]:
            for root, dirs, files in os.walk(item):
                dirs[:] = [d for d in dirs if d not in excludes]
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        if not f in LOGFILES:
                            try:
                                os.unlink(os.path.join(root, f))
                                log("[Wiped] %s" % os.path.join(root, f), 5)
                                delfiles += 1
                            except:
                                pass
                        else: log('Ignore Log File: %s' % f, 5)
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                            delfiles += 1
                            log("[Success] cleared %s files from %s" % (str(file_count), os.path.join(item,d)), 5)
                        except:
                            log("[Failed] to wipe cache in: %s" % os.path.join(item,d), 5)

    if os.path.exists(PACKAGES):
        try:
            for root, dirs, files in os.walk(PACKAGES):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    size = convertSize(getSize(PACKAGES))
                    if over: yes=1
                    else: yes=1
                    if yes:
                        for f in files: os.unlink(os.path.join(root, f))
                        for d in dirs: shutil.rmtree(os.path.join(root, d))

        except Exception as e:

            log("Clear Packages Error: %s" % str(e), 5)



def clearCache3():

    PROFILEADDONDATA = os.path.join(PROFILE,'addon_data')
    cachelist = [
        (PROFILEADDONDATA),
        (ADDONDATA),
        (os.path.join(HOME,'cache')),
        (os.path.join(HOME,'temp')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')),
        (os.path.join(ADDONDATA, 'plugin.video.bob', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.bob.unleashed', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.specto', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.genesis', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.exodus', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.covenant', 'cache.db')),
        (os.path.join(ADDONDATA, 'plugin.video.elementum', 'app.db-wal')),
        (os.path.join(ADDONDATA, 'plugin.video.itv','Images')),
        (os.path.join(DATABASE,  'onechannelcache.db')),
        (os.path.join(DATABASE,  'saltscache.db')),
        (os.path.join(DATABASE,  'saltshd.lite.db')),
        (os.path.join(PROFILEADDONDATA,'script.module.simple.downloader')),
        (os.path.join(PROFILEADDONDATA,'plugin.video.itv','Images'))]

    delfiles = 0

    for item in cachelist:
        if os.path.exists(item) and not item in [ADDONDATA, PROFILEADDONDATA]:
            for root, dirs, files in os.walk(item):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        if not f in ['kodi.log', 'tvmc.log', 'spmc.log', 'xbmc.log']:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
                                pass
                        else: log('Ignore Log File: %s' % f)
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                            delfiles += 1
                            log("[COLOR red][Success]  %s Files Removed From %s [/COLOR]" % (str(file_count), os.path.join(item,d)))
                        except:
                            log("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]" % os.path.join(item,d))
        else:
            for root, dirs, files in os.walk(item):
                for d in dirs:
                    if 'cache' in d.lower():
                        try:
                            shutil.rmtree(os.path.join(root, d))
                            delfiles += 1
                            log("[COLOR white][Success] Wiped %s [/COLOR]" % os.path.join(item,d))
                        except:
                            log("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]" % os.path.join(item,d))

    LogNotify(ADDONTITLE,'[COLOR white]Cache:[/COLOR] [COLOR red] %s Items Removed[/COLOR]' % delfiles)
origfolder = (translatepath("special://home/addons"))
def CleanPYO():
    count = 0
    for (dirname, dirs, files) in os.walk(origfolder):
       for filename in files:
          if filename.endswith('.pyo'):
            # if filename!=('uservar.pyo'):
               os.remove(os.path.join(dirname, filename))
          if filename.endswith('.pyc'):
            # if filename!=('uservar.pyo'):
               os.remove(os.path.join(dirname, filename))

def killxbmc(over=None):

        os._exit(1)
def redoThumbs():
    if not os.path.exists(THUMBS): os.makedirs(THUMBS)
    thumbfolders = '0123456789abcdef'
    videos = os.path.join(THUMBS, 'Video', 'Bookmarks')
    for item in thumbfolders:
        foldname = os.path.join(THUMBS, item)
        if not os.path.exists(foldname): os.makedirs(foldname)
    if not os.path.exists(videos): os.makedirs(videos)

def kodi17Fix():
    addonlist = glob.glob(os.path.join(ADDONS, '*/'))
    disabledAddons = []
    for folder in sorted(addonlist, key = lambda x: x):
        addonxml = os.path.join(folder, 'addon.xml')
        if os.path.exists(addonxml):
            fold   = folder.replace(ADDONS, '')[1:-1]
            try:
                f      = open(addonxml)
                a      = f.read()
                aid    = parseDOM(a, 'addon', ret='id')
                f.close()
            except:
                f      = open(addonxml, encoding='utf-8')
                a      = f.read()
                aid    = parseDOM(a, 'addon', ret='id')
                f.close()
            try:
                add    = xbmcaddon.Addon(id=aid[0])
            except:
                try:
                    # log("%s was disabled" % aid[0], 5)
                    disabledAddons.append(aid[0])
                except:
                    try:
                        # log("%s was disabled" % fold, 5)
                        disabledAddons.append(fold)
                    except:
                        if len(aid) == 0: log("Unabled to enable: %s(Cannot Determine Addon ID)" % fold, 5)
                        else: log("Unabled to enable: %s" % folder, 5)
    if len(disabledAddons) > 0:
        x = 0
        if not BUILDNAME == "":
        
            DP.create(ADDONTITLE,'[COLOR %s]מעדכן הרחבות' % COLOR2+'\n'+''+'\n'+ 'אנא המתן[/COLOR]')

            for item in disabledAddons: 

                if 'service.xbmc.versioncheck' in item:
                   continue
                if 'metadata.themoviedb.org.python' in item:
                   continue
                if 'metadata.tvshows.themoviedb.org.python' in item:
                   continue
                if 'game.controller.default' in item:
                   continue
                if 'game.controller.snes' in item:
                   continue
                if 'metadata.album.universal' in item:
                   continue
                if 'metadata.artists.universal' in item:
                   continue
                if 'metadata.common.imdb.com' in item:
                   continue
                if 'metadata.common.themoviedb.org' in item:
                   continue
                if 'metadata.tvshows.themoviedb.org' in item:
                   continue
                if 'script.skinshortcuts' in item:
                   continue
                if 'script.subskeys' in item:
                   continue
                x += 1
                prog = int(percentage(x, len(disabledAddons)))
                try:
                   DP.update(prog, "", "Enabling: [COLOR %s]%s[/COLOR]" % (COLOR1, item))
                except:
                   DP.update(prog, "Enabling: [COLOR %s]%s[/COLOR]" % (COLOR1, item))
                addonDatabase(item, 1)
                if DP.iscanceled(): break
            if DP.iscanceled(): 
                DP.close()
                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Enabling Addons Cancelled![/COLOR]" % COLOR2,1500)
                sys.exit()
            DP.close()
        else:
          for item in disabledAddons:
            if 'service.xbmc.versioncheck' in item:
               continue
            if 'metadata.themoviedb.org.python' in item:
               continue
            if 'metadata.tvshows.themoviedb.org.python' in item:
               continue
            if 'game.controller.default' in item:
               continue
            if 'game.controller.snes' in item:
               continue
            if 'metadata.album.universal' in item:
               continue
            if 'metadata.artists.universal' in item:
               continue
            if 'metadata.common.imdb.com' in item:
               continue
            if 'metadata.common.themoviedb.org' in item:
               continue
            if 'metadata.tvshows.themoviedb.org' in item:
               continue
            if 'script.skinshortcuts' in item:
               continue
            if 'script.subskeys' in item:
               continue
            addonDatabase(item, 1)
    forceUpdate()
#	ebi("ReloadSkin()")

def addonDatabase(addon=None, state=1):
    dbfile = latestDB('Addons')
    dbfile = os.path.join(DATABASE, dbfile)
    installedtime = str(datetime.now())[:-7]
    if os.path.exists(dbfile):
        try:
            textdb = database.connect(dbfile)
            textexe = textdb.cursor()
        except Exception as e:
            log("DB Connection Error: %s" % str(e), 5)
            return False
    else: return False
    if state == 2:
        try:
            textexe.execute("DELETE FROM installed WHERE addonID = ?", (addon,))
            textdb.commit()
            textexe.close()
        except Exception as e:
            log("Error Removing %s from DB" % addon)
        return True
    try:
        textexe.execute("SELECT id, addonID, enabled FROM installed WHERE addonID = ?", (addon,))
        found = textexe.fetchone()
        if found == None:
            textexe.execute('INSERT INTO installed (addonID , enabled, installDate) VALUES (?,?,?)', (addon, state, installedtime,))
            log("Insert %s into db" % addon)
        else:
            tid, taddonid, tenabled = found
            textexe.execute('UPDATE installed SET enabled = ? WHERE id = ? ', (state, tid,))
            log("Updated %s in db" % addon)
        textdb.commit()
        textexe.close()
    except Exception as e:
        log("Erroring enabling addon: %s" % addon)

##########################
### PURGE DATABASE #######
##########################
def purgeDb(name):

    log('Purging DB %s.' % name, 5)
    if os.path.exists(name):
        try:
            textdb = database.connect(name)
            textexe = textdb.cursor()
        except Exception as e:
            log("DB Connection Error: %s" % str(e), 5)
            return False
    else: log('%s not found.' % name, 5); return False
    textexe.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
    for table in textexe.fetchall():
        if table[0] == 'version': 
            log('Data from table `%s` skipped.' % table[0], 5)
        else:
            try:
                textexe.execute("DELETE FROM %s" % table[0])
                textdb.commit()
                log('Data from table `%s` cleared.' % table[0], 5)
            except Exception as e: log("DB Remove Table `%s` Error: %s" % (table[0], str(e)), 5)
    textexe.close()
    log('%s DB Purging Complete.' % name, 5)
    show = name.replace('\\', '/').split('/')
    LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]%s Complete[/COLOR]" % (COLOR2, show[len(show)-1]),1500)



def parseDOM(html, name=u"", attrs={}, ret=False):
    # Copyright (C) 2010-2011 Tobias Ussing And Henrik Mosgaard Jensen

    if isinstance(html, str):
        try:
            html = [html.decode("utf-8")]
        except:
            html = [html]
    elif isinstance(html, unicode):
        html = [html]
    elif not isinstance(html, list):
        return u""

    if not name.strip():
        return u""

    ret_lst = []
    for item in html:
        temp_item = re.compile('(<[^>]*?\n[^>]*?>)').findall(item)
        for match in temp_item:
            item = item.replace(match, match.replace("\n", " "))

        lst = []
        for key in attrs:
            lst2 = re.compile('(<' + name + '[^>]*?(?:' + key + '=[\'"]' + attrs[key] + '[\'"].*?>))', re.M | re.S).findall(item)
            if len(lst2) == 0 and attrs[key].find(" ") == -1:
                lst2 = re.compile('(<' + name + '[^>]*?(?:' + key + '=' + attrs[key] + '.*?>))', re.M | re.S).findall(item)

            if len(lst) == 0:
                lst = lst2
                lst2 = []
            else:
                test = range(len(lst))
                test.reverse()
                for i in test:
                    if not lst[i] in lst2:
                        del(lst[i])

        if len(lst) == 0 and attrs == {}:
            lst = re.compile('(<' + name + '>)', re.M | re.S).findall(item)
            if len(lst) == 0:
                lst = re.compile('(<' + name + ' .*?>)', re.M | re.S).findall(item)

        if isinstance(ret, str):
            lst2 = []
            for match in lst:
                attr_lst = re.compile('<' + name + '.*?' + ret + '=([\'"].[^>]*?[\'"])>', re.M | re.S).findall(match)
                if len(attr_lst) == 0:
                    attr_lst = re.compile('<' + name + '.*?' + ret + '=(.[^>]*?)>', re.M | re.S).findall(match)
                for tmp in attr_lst:
                    cont_char = tmp[0]
                    if cont_char in "'\"":
                        if tmp.find('=' + cont_char, tmp.find(cont_char, 1)) > -1:
                            tmp = tmp[:tmp.find('=' + cont_char, tmp.find(cont_char, 1))]

                        if tmp.rfind(cont_char, 1) > -1:
                            tmp = tmp[1:tmp.rfind(cont_char)]
                    else:
                        if tmp.find(" ") > 0:
                            tmp = tmp[:tmp.find(" ")]
                        elif tmp.find("/") > 0:
                            tmp = tmp[:tmp.find("/")]
                        elif tmp.find(">") > 0:
                            tmp = tmp[:tmp.find(">")]

                    lst2.append(tmp.strip())
            lst = lst2
        else:
            lst2 = []
            for match in lst:
                endstr = u"</" + name

                start = item.find(match)
                end = item.find(endstr, start)
                pos = item.find("<" + name, start + 1 )

                while pos < end and pos != -1:
                    tend = item.find(endstr, end + len(endstr))
                    if tend != -1:
                        end = tend
                    pos = item.find("<" + name, pos + 1)

                if start == -1 and end == -1:
                    temp = u""
                elif start > -1 and end > -1:
                    temp = item[start + len(match):end]
                elif end > -1:
                    temp = item[:end]
                elif start > -1:
                    temp = item[start + len(match):]

                if ret:
                    endstr = item[end:item.find(">", item.find(endstr)) + 1]
                    temp = match + temp + endstr

                item = item[item.find(temp, item.find(match)) + len(temp):]
                lst2.append(temp)
            lst = lst2
        ret_lst += lst

    return ret_lst


def replaceHTMLCodes(txt):
    txt = re.sub("(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt)
    txt = HTMLParser.HTMLParser().unescape(txt)
    txt = txt.replace("&quot;", "\"")
    txt = txt.replace("&amp;", "&")
    return txt

