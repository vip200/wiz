# -*- coding: utf-8 -*-
import requests,re,urllib,logging,xbmcaddon,xbmcgui,time,xbmc,os
from resources.libs import wizard as wiz
BUILDNAME      = wiz.getS('buildname')
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
COLOR1         = 'gold'
COLOR2         = 'white'
ADDONTITLE     = 'מסנכרן את חשבון טראקט'
DIALOG         = xbmcgui.Dialog()
PLUGIN         = os.path.join(ADDONS,    ADDONTITLE)
ICON           = os.path.join(PLUGIN,    'icon.png')

moviebox=xbmcaddon.Addon('plugin.video.moviebox')


Addon = xbmcaddon.Addon()
if os.path.exists(os.path.join(ADDONS, 'plugin.video.gaia')):
 gaia=xbmcaddon.Addon('plugin.video.gaia')
if os.path.exists(os.path.join(ADDONS, 'plugin.video.allmoviesin')):
 victory=xbmcaddon.Addon('plugin.video.allmoviesin')
if os.path.exists(os.path.join(ADDONS, 'plugin.video.seren')):
 seren=xbmcaddon.Addon('plugin.video.seren')
if os.path.exists(os.path.join(ADDONS, 'plugin.video.exodusredux')):
 exodusredux=xbmcaddon.Addon('plugin.video.exodusredux')

def call_trakt(path, params={}, data=None, is_delete=False, with_auth=True, pagination = False, page = 1):
    
    import urllib
    params = dict([(k, (v).encode('utf8')) for k, v in params.items() if v])
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': CLIENT_ID
    }


    API_ENDPOINT = "https://api-v2launch.trakt.tv"
    
    def send_query():
        if with_auth:
            try:
                expires_at = int(Addon.getSetting(SETTING_TRAKT_EXPIRES_AT))
                if time.time() > expires_at:
                    trakt_refresh_token()
            except:
                pass
            token =unicode( Addon.getSetting(SETTING_TRAKT_ACCESS_TOKEN))
            if token:
                headers['Authorization'] = 'Bearer ' + token
        if data is not None:
            assert not params
            return requests.post("{0}/{1}".format(API_ENDPOINT, path), json=(data), headers=headers)
        elif is_delete:
            return requests.delete("{0}/{1}".format(API_ENDPOINT, path), headers=headers)
        else:
            return requests.get("{0}/{1}".format(API_ENDPOINT, path), params, headers=headers)

    def paginated_query(page):
        lists = []
        params['page'] = page
        results = send_query()
        if with_auth and results.status_code == 401 and xbmcgui.Dialog().yesno(("Authenticate Trakt"), ("You must authenticate with Trakt. Do you want to authenticate now?")) and trakt_authenticate():
            response = paginated_query(1)
            return response
        results.raise_for_status()
        results.encoding = 'utf-8'
        lists.extend(results.json())
        return lists, results.headers["X-Pagination-Page-Count"]

    if pagination == False:
        response = send_query()
        if Addon.getSetting("auto_trk")=='true':
            check=True
        else:
            check=xbmcgui.Dialog().yesno(("Authenticate Trakt"),("You must authenticate with Trakt. Do you want to authenticate now?"))
        if with_auth and response.status_code == 401 and check and trakt_authenticate():
            response = send_query()
        response.raise_for_status()
        response.encoding = 'utf-8'
        return response.json()
    else:
        
        (response, numpages) = paginated_query(page)
        return response, numpages
BASE_URL = 'http://api.trakt.tv'
SETTING_TRAKT_EXPIRES_AT = "trakt_expires_at"
SETTING_TRAKT_ACCESS_TOKEN = "trakt_access_token"
SETTING_TRAKT_REFRESH_TOKEN = "trakt_refresh_token"


EXUDOS_TRAKT_EXPIRES_AT = "trakt.user"
EXUDOS_TRAKT_ACCESS_TOKEN = "trakt.token"
EXUDOS_TRAKT_REFRESH_TOKEN = "trakt.refresh"

SEREN_TRAKT_EXPIRES_AT = "trakt.username"
SEREN_TRAKT_ACCESS_TOKEN = "trakt.auth"
SEREN_TRAKT_REFRESH_TOKEN = "trakt.refresh"

GAIA_TRAKT_EXPIRES_AT = "accounts.informants.trakt.user"
GAIA_TRAKT_ACCESS_TOKEN = "accounts.informants.trakt.token"
GAIA_TRAKT_REFRESH_TOKEN = "accounts.informants.trakt.refresh"

VICTORY_TRAKT_EXPIRES_AT = "trakt_expires_at"
VICTORY_TRAKT_ACCESS_TOKEN = "trakt_access_token"
VICTORY_TRAKT_REFRESH_TOKEN = "trakt_refresh_token"




CLIENT_ID = "8ed545c0b7f92cc26d1ecd6326995c6cf0053bd7596a98e962a472bee63274e6"
CLIENT_SECRET = "1ec4f37e5743e3086abace0c83444c25d9b655d1d77b793806b2c8205a510426"
SEREN_CLIENT_ID = "4dd60d1ccb4b5c79aba64313467f6fefbda570605a927639549e8668558ce37e"
SEREN_CLIENT_SECRET = "d4dd35c0c1b0ec21b7b0cc7085011833c32bc28a0a62b454f4777d745aea07aa"
EXUDOS_CLIENT_ID = "c1d7d1519b5d70158fc568c42b8c7a39b4f73a73e17e25c0e85152a542cd1664"
EXUDOS_SECRET = "3f1c01e94538cf23aaed1d2d86ec5ac0909d1ce4cd0f436a6a3d9eb5c1ed24ce"
GAIA_CLIENT_ID = "45702b1a4293cf1b10f55a4ba918855356bb005f41e2c3682e2090028368e6f9"
GAIA_SECRET = "a60e1ee268b3ab53879923aba023fe85406c3ab5478276a26a3007f4b7b0743e"

def LogNotify(title, message, times=10500, icon=ICON,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
def trakt_get_device_code():
    data = { 'client_id': CLIENT_ID}
    return call_trakt("oauth/device/code", data=data, with_auth=False)

def trakt_get_device_code_seren():
    data = { 'client_id': SEREN_CLIENT_ID}
    return call_trakt("oauth/device/code", data=data, with_auth=False)

def trakt_get_device_code_exudos():
    data = { 'client_id': EXUDOS_CLIENT_ID}
    return call_trakt("oauth/device/code", data=data, with_auth=False)

def trakt_get_device_code_gaia():
    data = { 'client_id': GAIA_CLIENT_ID}
    return call_trakt("oauth/device/code", data=data, with_auth=False)





def testcommand():
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]אנא המתן מספר רגעים...[/COLOR]' % COLOR2)
  
    code = trakt_get_device_code()
    token = trakt_get_device_token(code)
    xbmc.sleep(500)
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.seren')):
       code_seren = trakt_get_device_code_seren()
       token_seren = trakt_get_device_token(code_seren)
       xbmc.sleep(500)
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.exodusredux')):
       code_exudos = trakt_get_device_code_exudos()
       token_exudos = trakt_get_device_token(code_exudos)
       xbmc.sleep(500)
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.gaia')):
       code_gaia = trakt_get_device_code_gaia()
       token_gaia = trakt_get_device_token(code_gaia)
       xbmc.sleep(500)
    
    if token:
        expires_at = time.time() + 60*60*24*30#*3
        username = Addon.getSetting("trk_user")
        Addon.setSetting(SETTING_TRAKT_EXPIRES_AT, str(expires_at))
        Addon.setSetting(SETTING_TRAKT_ACCESS_TOKEN, token["access_token"])
        Addon.setSetting(SETTING_TRAKT_REFRESH_TOKEN, token["refresh_token"])
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.moviebox')):
            moviebox.setSetting(SETTING_TRAKT_EXPIRES_AT, str(expires_at))
            moviebox.setSetting(SETTING_TRAKT_ACCESS_TOKEN, token["access_token"])
            moviebox.setSetting(SETTING_TRAKT_REFRESH_TOKEN, token["refresh_token"])
        
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.seren')):
            seren.setSetting(SEREN_TRAKT_EXPIRES_AT, str(username))
            seren.setSetting(SEREN_TRAKT_ACCESS_TOKEN, token_seren["access_token"])
            seren.setSetting(SEREN_TRAKT_REFRESH_TOKEN, token_seren["refresh_token"])
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.victory')):
            victory.setSetting(SETTING_TRAKT_EXPIRES_AT, str(expires_at))
            victory.setSetting(SETTING_TRAKT_ACCESS_TOKEN, token["access_token"])
            victory.setSetting(SETTING_TRAKT_REFRESH_TOKEN, token["refresh_token"])
            victory.setSetting('use_trak', 'true')
        
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.gaia')):
            gaia.setSetting(GAIA_TRAKT_EXPIRES_AT, str(username))
            gaia.setSetting(GAIA_TRAKT_ACCESS_TOKEN, token_gaia["access_token"])
            gaia.setSetting(GAIA_TRAKT_REFRESH_TOKEN, token_gaia["refresh_token"])
            gaia.setSetting('accounts.informants.trakt.enabled', 'true')
            
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.exodusredux')):
            exodusredux.setSetting(EXUDOS_TRAKT_EXPIRES_AT, str(username))
            exodusredux.setSetting(EXUDOS_TRAKT_ACCESS_TOKEN, token_exudos["access_token"])
            exodusredux.setSetting(EXUDOS_TRAKT_REFRESH_TOKEN, token_exudos["refresh_token"])
        
        return True
    return False

def trakt_get_device_token(device_codes):
    
    data = {
        "code": device_codes["device_code"],
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET
    }
    start=time.time()
    expires_in = device_codes["expires_in"]
    if Addon.getSetting("auto_trk")=='true':
        auto_trk_auth
        auto_trk_auth(str(device_codes["user_code"]))
    else:
        progress_dialog = xbmcgui.DialogProgress()
        progress_dialog.create(("Authenticate Trakt"), ("Please go to https://trakt.tv/activate and enter the code"),str(device_codes["user_code"])    )
    
        
    try:
        time_passed = 0
        while not xbmc.abortRequested and  time_passed < expires_in:        
            if Addon.getSetting("auto_trk")=='false':
                if progress_dialog.iscanceled():
                    break
            try:
                response = call_trakt("oauth/device/token", data=data, with_auth=False)
            except requests.HTTPError, e:
                if e.response.status_code != 400:
                    raise e
                if Addon.getSetting("auto_trk")=='false':
                    progress = int(100 * time_passed / expires_in)
                    progress_dialog.update(progress)
                xbmc.sleep(max(device_codes["interval"], 1)*1000)
            else:
                return response
            time_passed = time.time() - start
    finally:
        if Addon.getSetting("auto_trk")=='false':
            progress_dialog.close()
            del progress_dialog
    return None















def auto_trk_auth(key):
        import xbmcgui,xbmcaddon

        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מאשר אנא המתן', key,'')
        dp.update(0, 'אנא המתן','מאשר אנא המתן', key )
        user=Addon.getSetting("trk_user")
        passward=Addon.getSetting("trk_pass")
        cookies = {
            'user_data_version': '3',
        }

        headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        response = requests.get('https://trakt.tv/auth/signin', headers=headers, cookies=cookies)
        regex='name="csrf-token" content="(.+?)"'
        m=re.compile(regex).findall(response.content)[0]
        cookies = {
            'user_data_version': '3',
            
            'webp_supported': 'true',
            'watchnow_country': 'il',
            '_traktsession':response.cookies['_traktsession'],
            
          
        }
  
        dp.update(0, 'אנא המתן','נכנס לחשבון', user )
        headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'Origin': 'https://trakt.tv',
            'Upgrade-Insecure-Requests': '1',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Referer': 'https://trakt.tv/auth/signin',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        data = {
          'utf8': '\u2713',
          'authenticity_token': m,
          'user[login]': user,
          'user[password]': passward,
          'user[remember_me]': '1'
        }

        response = requests.post('https://trakt.tv/auth/signin', headers=headers, cookies=cookies, data=data)
        
        regex='id="meta-username" type="hidden" value="(.+?)"'
        user_n=re.compile(regex).findall(response.content)[0]

        regex='name="csrf-token" content="(.+?)"'
        m=re.compile(regex).findall(response.content)[0]
        us_token=response.cookies['remember_user_token']
        cookies = {
            'user_data_version': '3',
          
            'webp_supported': 'true',
            'watchnow_country': 'il',
            
            '_gat': '1',
            '_gali': 'new_user',
            'trakt_username': user_n,
            'trakt_userslug': user_n.lower(),
            'remember_user_token':us_token,
            '_traktsession':response.cookies['_traktsession'],
        }

        headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Referer': 'https://trakt.tv/auth/signin',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        response = requests.get('https://trakt.tv/activate', headers=headers, cookies=cookies)
       
        dp.update(0, 'אנא המתן','מפעיל', user )
        m=re.compile(regex).findall(response.content)[0]

        cookies = {
            'user_data_version': '3',
          
            'webp_supported': 'true',
            'watchnow_country': 'il',
           
            '_gat': '1',
            'trakt_username': user_n,
            'trakt_userslug': user_n.lower(),
            'remember_user_token':us_token,
            '_traktsession':response.cookies['_traktsession'],
        }

        headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'Origin': 'https://trakt.tv',
            'Upgrade-Insecure-Requests': '1',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Referer': 'https://trakt.tv/activate',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        data = {
          'utf8': '\u2713',
          'authenticity_token': m,
          'code': key,
          'commit': 'Continue'
        }

        response = requests.post('https://trakt.tv/activate', headers=headers, cookies=response.cookies, data=data)
        m=re.compile(regex).findall(response.content)[0]
        


        headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'Origin': 'https://trakt.tv',
            'Upgrade-Insecure-Requests': '1',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Referer': 'https://trakt.tv/activate/authorize',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        data = {
          'utf8': '\u2713',
          'authenticity_token': m,
          'commit': 'Yes'
        }

        response = requests.post('https://trakt.tv/activate/authorize', headers=headers, cookies=response.cookies, data=data)
        logging.warning(response.cookies)
        logging.warning(response.headers)
        #logging.warning(response.content)
        dp.close()
testcommand()