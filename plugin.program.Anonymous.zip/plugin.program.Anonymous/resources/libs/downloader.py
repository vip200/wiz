import xbmc, xbmcgui, sys, time, threading, uservar
import urllib.request

ADDONTITLE     = uservar.ADDONTITLE
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2

from resources.libs import wizard as wiz

# ====== TUNE HERE ======
PARALLEL_CONNECTIONS = 4     # נסה 4, אם עדיין איטי תעלה ל-6 או 8
CHUNK_SIZE = 1024 * 1024      # 256KB
UI_UPDATE_EVERY = 0       # עדכון UI כל 0.35 שניות (כדי שה-ETA יהיה "חי")
USER_AGENT = 'Mozilla/5.0 (Kodi) AppleWebKit/537.36 (KHTML, like Gecko) Safari'
# =======================


def _head_total_and_ranges(url, timeout=30):
    """
    מחזיר (total:int|None, accept_ranges:bool)
    """
    try:
        req = urllib.request.Request(url, method='HEAD', headers={'User-Agent': USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            total = r.headers.get('Content-Length')
            ar = (r.headers.get('Accept-Ranges') or '').lower()
            return (int(total) if total else None), ('bytes' in ar)
    except Exception:
        return None, False


def _format_progress(downloaded, total, start_time):
    """
    מחזיר (done_percent:int, currently_downloaded_str:str, speed_str:str)
    תואם 1:1 לסגנון המקורי שלך
    """
    mb = 1024 * 1024.0
    done = int(100 * downloaded / total) if total else 0

    # speed + ETA בדיוק כמו אצלך
    elapsed = max(0.001, (time.time() - start_time))
    kbps_speed = downloaded / elapsed  # bytes/sec
    if kbps_speed > 0 and not done >= 100:
        eta = (total - downloaded) / kbps_speed
    else:
        eta = 0

    kbps_speed = kbps_speed / 1024.0
    type_speed = 'KB'
    if kbps_speed >= 1024:
        kbps_speed = kbps_speed / 1024.0
        type_speed = 'MB'

    currently_downloaded = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % (
        COLOR2, COLOR1, downloaded / mb, COLOR1, total / mb
    )

    speed = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % (
        COLOR2, COLOR1, kbps_speed, type_speed
    )
    div = divmod(int(eta), 60)
    speed += '[B]ETA:[/B] [COLOR %s]%02d:%02d[/COLOR][/COLOR]' % (COLOR1, div[0], div[1])

    return done, currently_downloaded, speed


def _parallel_download(url, dest, dp, show_text=True):
    """
    מוריד את הקובץ במקביל עם Range, ומעדכן dp כמו המקורי (כולל ETA).
    """
    total, accept_ranges = _head_total_and_ranges(url)

    # אם אין total או אין ranges -> fallback: חיבור יחיד (עדיין עם ETA)
    if not total or not accept_ranges or PARALLEL_CONNECTIONS < 2 or total < (2 * 1024 * 1024):
        return _single_stream_download(url, dest, dp, show_text=show_text)

    # pre-allocate
    with open(dest, 'wb') as f:
        f.truncate(total)

    # ranges
    conns = PARALLEL_CONNECTIONS
    part = total // conns
    ranges = []
    for i in range(conns):
        start = i * part
        end = (start + part - 1) if i < conns - 1 else (total - 1)
        ranges.append((start, end))

    downloaded_total = 0
    downloaded_lock = threading.Lock()
    file_lock = threading.Lock()
    stop = {'flag': False}
    err = {'e': None}

    start_time = time.time()
    last_ui = 0.0

    def worker(start, end):
        nonlocal downloaded_total
        try:
            headers = {
                'User-Agent': USER_AGENT,
                'Range': 'bytes=%d-%d' % (start, end)
            }
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=60) as r:
                pos = start
                while True:
                    if stop['flag']:
                        return
                    chunk = r.read(CHUNK_SIZE)
                    if not chunk:
                        break

                    # write at offset
                    with file_lock:
                        with open(dest, 'r+b') as f:
                            f.seek(pos)
                            f.write(chunk)
                    pos += len(chunk)

                    with downloaded_lock:
                        downloaded_total += len(chunk)

        except Exception as e:
            err['e'] = e
            stop['flag'] = True

    threads = []
    for (s, e) in ranges:
        t = threading.Thread(target=worker, args=(s, e))
        t.daemon = True
        t.start()
        threads.append(t)

    # UI loop
    while any(t.is_alive() for t in threads):
        if err['e']:
            break

        if hasattr(dp, "iscanceled") and dp.iscanceled():

            stop['flag'] = True
            for t in threads:
                t.join(timeout=1)
            dp.close()
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),
                          "[COLOR %s]Download Cancelled[/COLOR]" % COLOR2, 1500)
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            sys.exit()

        now = time.time()
        if now - last_ui >= UI_UPDATE_EVERY:
            with downloaded_lock:
                d = downloaded_total

            done, currently_downloaded, speed = _format_progress(d, total, start_time)

            if show_text:
                dp.update(done, '\n' + str(currently_downloaded) + '\n' + str(speed))
            else:
                dp.update(done)

            last_ui = now

        xbmc.sleep(80)

    # finalize
    for t in threads:
        t.join(timeout=2)

    if err['e']:
        try:
            dp.close()
        except:
            pass
        wiz.log("parallel download error: %s" % err['e'])
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),
                      "[COLOR %s]הורדה נכשלה[/COLOR]" % COLOR2, 1500)
        return False

    dp.update(100)
    return True


def _single_stream_download(url, dest, dp, show_text=True):
    """
    fallback חיבור יחיד – אבל עם אותו ETA/Speed כמו המקורי
    """
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=60) as r, open(dest, 'wb') as f:
            total = r.headers.get('Content-Length')
            total = int(total) if total else None
            if not total:
                # בלי total – אין ETA אמיתי
                f.write(r.read())
                dp.update(100)
                return True

            downloaded = 0
            start_time = time.time()
            last_ui = 0.0

            while True:
                chunk = r.read(CHUNK_SIZE)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)

                if hasattr(dp, "iscanceled") and dp.iscanceled():

                    dp.close()
                    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),
                                  "[COLOR %s]Download Cancelled[/COLOR]" % COLOR2, 1500)
                    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                    sys.exit()

                now = time.time()
                if now - last_ui >= UI_UPDATE_EVERY:
                    done, currently_downloaded, speed = _format_progress(downloaded, total, start_time)
                    if show_text:
                        dp.update(done, '\n' + str(currently_downloaded) + '\n' + str(speed))
                    else:
                        dp.update(done)
                    last_ui = now

            dp.update(100)
            return True

    except Exception as e:
        wiz.log("single download error: %s" % e)
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),
                      "[COLOR %s]הורדה נכשלה[/COLOR]" % COLOR2, 1500)
        return False


# =========================
#  API כמו אצלך (אותו שם)
# =========================

def download(url, dest, dp=None):
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create(ADDONTITLE, "Downloading Content", " ", " ")
    dp.update(0)

    ok = _parallel_download(url, dest, dp, show_text=True)
    if ok:
        dp.close()
    return ok


def download_update(url, dest, dp=None):
    dp = xbmcgui.DialogProgressBG()
    dp.create('[B][COLOR=white] מוריד עדכון מערכת [/COLOR][/B]', '[B][COLOR=silver]אנא המתן....[/COLOR][/B]')

    # BG פחות צריך טקסט מלא, אבל אפשר להשאיר רק אחוזים
    # אם אתה רוצה גם שם ETA, שנה show_text=True ואז להשתמש ב-DialogProgress (לא BG)
    ok = _parallel_download(url, dest, dp, show_text=False)
    dp.close()
    return ok


def download_WizardBG(url, dest, dp=None):
    dp = xbmcgui.DialogProgressBG()
    dp.create('[B] Download Wizard Update [/B]', '[B][COLOR=yellow]אנא המתן....[/COLOR][/B]')

    ok = _parallel_download(url, dest, dp, show_text=False)
    dp.close()
    return ok
